"""Browser-only video proxies. Masters and their edit/export timing stay untouched."""
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time
import uuid

VERSION = 1
_LOCKS = [threading.RLock() for _ in range(32)]
_ENCODER = threading.BoundedSemaphore(1)
MESSAGE = 'This video preview could not be prepared. The original file and previous scene were kept.'


class PreviewError(ValueError):
    pass


def _run(args, timeout=60):
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)
    try:
        result = subprocess.run(args, capture_output=True, timeout=timeout, creationflags=flags)
        if result.returncode:
            raise PreviewError(MESSAGE)
        return result.stdout
    except (OSError, subprocess.SubprocessError) as exc:
        raise PreviewError(MESSAGE) from exc


def probe(source):
    try:
        data = json.loads(_run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(source)]))
        streams = data.get('streams', [])
        video = next(s for s in streams if s.get('codec_type') == 'video' and not s.get('disposition', {}).get('attached_pic'))
        audio = next((s for s in streams if s.get('codec_type') == 'audio'), None)
        duration = float(video.get('duration') or data['format']['duration'])
        if not math.isfinite(duration) or duration <= 0 or not 0 < video['width'] <= 16384 or not 0 < video['height'] <= 16384:
            raise ValueError('Invalid video')
        a, b = video.get('avg_frame_rate', '0/1').split('/')
        fps = float(a) / float(b) if float(b) else 0
        if not math.isfinite(fps) or fps <= 0:
            fps = 30
        rotation = float(next((s['rotation'] for s in video.get('side_data_list', []) if 'rotation' in s), video.get('tags', {}).get('rotate', 0))) % 360
        return dict(video=video, audio=audio, duration=duration, fps=fps, rotation=rotation)
    except (KeyError, TypeError, ValueError, StopIteration) as exc:
        raise PreviewError(MESSAGE) from exc


def _compatible(info):
    v = info['video']
    return (v.get('codec_name') == 'h264' and v.get('pix_fmt') == 'yuv420p'
            and max(v['width'], v['height']) <= 1920 and min(v['width'], v['height']) <= 1080
            and info['fps'] <= 60.01 and info['rotation'] == 0
            and v.get('color_transfer') not in ('smpte2084', 'arib-std-b67'))


def _paths(source, directory):
    source = Path(source).resolve()
    stat = source.stat()
    stamp = [VERSION, str(source).casefold(), stat.st_size, stat.st_mtime_ns]
    key = hashlib.sha256(json.dumps(stamp).encode()).hexdigest()[:24]
    directory = Path(directory)
    return source, stamp, directory / (key + '.json'), directory / (key + '.mp4'), _LOCKS[int(key[:8], 16) % len(_LOCKS)]


def _cached(source, stamp, record, target):
    try:
        row = json.loads(record.read_text('utf8'))
        if row.get('stamp') != stamp:
            return None
        if row.get('error_until', 0) > time.time():
            raise PreviewError(MESSAGE)
        if row.get('original'):
            return source
        if row.get('size') and target.stat().st_size == row['size']:
            return target
    except PreviewError:
        raise
    except (OSError, ValueError, TypeError):
        return None
    return None


def _save(path, value):
    tmp = path.with_name('.bv-' + uuid.uuid4().hex[:12] + '.tmp')
    try:
        tmp.write_text(json.dumps(value), 'utf8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def prepare(source, directory):
    """Full-length, aspect-preserving AVC/AAC playback; never fall back to unsafe raw bytes."""
    source, stamp, record, target, lock = _paths(source, directory)
    with lock:
        cached = _cached(source, stamp, record, target)
        if cached:
            return cached
        record.parent.mkdir(parents=True, exist_ok=True)
        part = target.with_name('.bv-' + uuid.uuid4().hex[:12] + '.part.mp4')
        try:
            with _ENCODER:
                info = probe(source)
                video_ok = _compatible(info)
                a = info['audio']
                audio_ok = not a or (a.get('codec_name') == 'aac' and a.get('channels', 2) <= 2)
                if source.suffix.lower() == '.mp4' and video_ok and audio_ok:
                    _save(record, dict(stamp=stamp, original=True))
                    return source
                args = ['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-filter_threads', '1',
                        '-i', str(source), '-map', '0:v:0', '-map', '0:a:0?', '-map_metadata', '-1']
                if video_ok:
                    args += ['-c:v', 'copy']
                else:
                    filters = []
                    if info['video'].get('color_transfer') in ('smpte2084', 'arib-std-b67'):
                        filters += ['zscale=t=linear:npl=100', 'format=gbrpf32le', 'zscale=p=bt709',
                                    'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv']
                    filters += ["scale=w='if(gte(iw,ih),min(1920,iw),min(1080,iw))':h='if(gte(iw,ih),min(1080,ih),min(1920,ih))':force_original_aspect_ratio=decrease:force_divisible_by=2:out_range=tv"]
                    if info['fps'] > 60.01:
                        filters.append('fps=60')
                    args += ['-vf', ','.join(filters), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
                             '-pix_fmt', 'yuv420p', '-color_range', 'tv', '-threads', '2', '-fps_mode', 'vfr']
                args += ['-c:a', 'aac', '-ac', '2', '-b:a', '192k', '-movflags', '+faststart', '-n', str(part)]
                _run(args, timeout=900)
                actual = probe(part)
                if (not _compatible(actual) or bool(actual['audio']) != bool(info['audio'])
                        or abs(actual['duration'] - info['duration']) > max(.15, 3 / min(info['fps'], 60))):
                    raise PreviewError(MESSAGE)
                if _paths(source, directory)[1] != stamp:
                    raise PreviewError(MESSAGE)
                os.replace(part, target)
                _save(record, dict(stamp=stamp, original=False, size=target.stat().st_size))
                return target
        except (OSError, PreviewError) as exc:
            _save(record, dict(stamp=stamp, error_until=time.time() + 60))
            raise PreviewError(MESSAGE) from exc
        finally:
            part.unlink(missing_ok=True)


def copy_cached(source, destination, source_cache, destination_cache):
    """The importer has already copied the unchanged master: carry its verified proxy with it."""
    src, stamp, record, target, lock = _paths(source, source_cache)
    with lock:
        ready = _cached(src, stamp, record, target)
        if not ready:
            raise PreviewError(MESSAGE)
    dst, new_stamp, new_record, new_target, new_lock = _paths(destination, destination_cache)
    if src.stat().st_size != dst.stat().st_size:
        raise PreviewError(MESSAGE)
    with new_lock:
        new_record.parent.mkdir(parents=True, exist_ok=True)
        if ready == src:
            _save(new_record, dict(stamp=new_stamp, original=True))
            return
        part = new_target.with_name('.bv-' + uuid.uuid4().hex[:12] + '.tmp')
        try:
            shutil.copyfile(ready, part)
            os.replace(part, new_target)
            _save(new_record, dict(stamp=new_stamp, original=False, size=new_target.stat().st_size))
        finally:
            part.unlink(missing_ok=True)
