"""
Server-side MP4 render — turns the dashboard's rough-cut preview into ONE finished
file the user can download and upload straight to YouTube.

What it renders is exactly what the preview plays, because both are driven by the
same timeline dict (see app._build_timeline): the same scene media at the same
audio-driven time ranges, the same scene-split captions, the same voice-over, and
the same emotion-segmented music at the same per-segment levels.

Output: 1920x1080 @ 60 fps H.264 — the SAME spec as the Premiere export (premiere_export.FPS
/ SEQ_W / SEQ_H), so the delivered MP4 and the editable timeline match frame for frame.
Captions are BURNED IN (libass), because a YouTube upload can't carry a sidecar SRT.

Everything is done in ONE ffmpeg pass:
  video  each scene -> scaled/padded to the canvas at exactly its scene duration, concat
  subs   generated .ass (explicit PlayRes so font size is deterministic), burned on the concat
  audio  voice-over + one delayed/faded music stream per segment, amix normalize=0

The filter graph is written to a FILE (-filter_complex_script) rather than the command
line: a 40-scene VSL builds a graph well past the Windows 32 KB argv limit.
"""
import re, math, subprocess, shutil
from pathlib import Path

# Hide the console window ffmpeg would otherwise pop up on every call (the dashboard
# itself runs windowless, so children have no console to inherit).
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

from premiere_export import FPS, SEQ_W, SEQ_H, ZOOM_PCT_PER_SEC, XFADE_SEC

# x264 settings for a final YouTube deliverable. CRF 17 at 1080p60 is visually
# transparent; "medium" keeps a long VSL to a sane render time (slower presets buy
# file size, not picture, at this CRF).
CRF = "17"
PRESET = "medium"
AUDIO_BITRATE = "320k"

# Burned-caption look — matches .pv-caption in static/style.css (white text in a
# 62%-black box, centred, just above the bottom edge) at 1080p scale.
FONT_NAME = "Arial"
FONT_SIZE = 46
BOX_ALPHA = 0x61          # ASS alpha: 0x00 opaque .. 0xFF clear; 0x61 ~= the CSS .62
MARGIN_V = 48             # ~4.5% up from the bottom, as in the preview
SIDE_MARGIN = 140         # keeps lines off the extreme edges (title-safe-ish)


def _snap(sec):
    """Snap a time to the nearest video frame. Caption cues and scene boundaries come from the
    forced-alignment/scene-split (arbitrary sub-frame times); snapping BOTH to the same frame grid
    makes the burned subtitle change land on the very frame the scene/image changes, instead of the
    ~1-2 frame drift you get when a raw cue time rounds onto a neighbouring frame."""
    return round(max(0.0, float(sec)) * FPS) / FPS


def _t(sec):
    """Seconds -> ASS timestamp H:MM:SS.cc. FLOOR to centiseconds: a frame-aligned cue time
    (frame/60) then lands on its exact video frame instead of possibly rounding up a frame."""
    sec = math.floor(max(0.0, float(sec)) * 100) / 100
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def _ass_color(hex_color):
    """#RRGGBB -> ASS &H00BBGGRR& (ASS colour is BGR)."""
    h = (hex_color or "#ffffff").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        r, g, b = 255, 255, 255
    return f"&H00{b:02X}{g:02X}{r:02X}&"


def _round_rect_path(w, h, r):
    """ASS \\p1 drawing path for a (rounded) rectangle, top-left at 0,0."""
    if r <= 0:
        return f"m 0 0 l {w} 0 l {w} {h} l 0 {h}"
    return (f"m {r} 0 l {w-r} 0 b {w} 0 {w} 0 {w} {r} "
            f"l {w} {h-r} b {w} {h} {w} {h} {w-r} {h} "
            f"l {r} {h} b 0 {h} 0 {h} 0 {h-r} "
            f"l 0 {r} b 0 0 0 0 {r} 0")


def _ost_events(scenes):
    """Animated on-screen-text overlay events. Styled per scene (font/weight/size/colour/style flags/
    letter-spacing/rotation/stroke/shadow/background box), placed top|center|bottom with custom line
    spacing (each line is its own centred event so leading is honoured), an entrance animation that
    ALWAYS also fades in, and an optional exit fade-out — matches the preview."""
    out = []
    cx, off = SEQ_W // 2, 90
    def _cf(v, d):                                # clamp a 0..1 fraction
        try: return min(1.0, max(0.0, float(v)))
        except (TypeError, ValueError): return d
    items = []                                    # flatten: each scene → its overlays, each with ITS OWN window
    for _scene in (scenes or []):
        _s0, _e0 = float(_scene["start"]), float(_scene["end"])
        _dur = max(0.0, _e0 - _s0)
        for _ov in (_scene.get("texts") or []):
            _a = _s0 + _dur * _cf(_ov.get("text_in"), 0.0)
            _b = _s0 + _dur * _cf(_ov.get("text_out"), 1.0)
            if _b <= _a:                          # keep at least a sliver
                _b = min(_e0, _a + 0.1)
            items.append((_ov, _t(_a), _t(_b)))
    for sc, st, en in items:                      # sc = one overlay's text_* dict
        txt = (sc.get("text") or "").strip()
        if not txt:
            continue
        font = (sc.get("text_font") or "Arial").replace("{", "").replace("}", "")
        size = int(sc.get("text_size") or 56)
        col = _ass_color(sc.get("text_color") or "#ffffff")
        fill_a = "" if sc.get("text_fill", True) else "\\1a&HFF&"   # Fill off → transparent glyph (stroke only)
        anim = sc.get("text_anim") or "fade"
        out_anim = sc.get("text_out_anim") or "none"
        # drop shadow: colour (\4c) + alpha (\4a) + depth (\shad). ASS casts down-right only (no direction).
        if sc.get("text_shadow", True):
            shad_depth = max(0, int(sc.get("text_shadow_size") or 0)) or 2
            shad_op = max(0, min(100, int(sc.get("text_shadow_opacity") or 0)))
            shad_alpha = max(0, min(255, 255 - int(round(shad_op / 100.0 * 255))))
            shadow_tag = f"\\shad{shad_depth}\\4c{_ass_color(sc.get('text_shadow_color') or '#000000')}\\4a&H{shad_alpha:02X}&"
        else:
            shadow_tag = "\\shad0"
        try:
            weight = int(sc.get("text_weight") or 400)
        except (TypeError, ValueError):
            weight = 400
        # Weight: libass reads \b with a hundreds value (100..900) as an exact font weight — it sets a
        # variable font's `wght` axis (Montserrat/Inter/OpenSans/NotoSerif/Roboto are VFs here) or picks
        # the closest static face (Poppins/Geomini/GoogleSans). This keeps ExtraBold=800 etc. from
        # collapsing to plain bold. If a libass build ignores the value it degrades to bold-on (no worse).
        eff_w = 700 if (sc.get("text_bold") and weight < 700) else weight
        if eff_w in (100, 200, 300, 400, 500, 600, 700, 800, 900):
            bold_tag = f"\\b{eff_w}"
        else:
            bold_tag = "\\b1" if eff_w >= 600 else "\\b0"
        italic = 1 if sc.get("text_italic") else 0
        under = 1 if sc.get("text_underline") else 0
        upper = bool(sc.get("text_upper"))
        letter = int(sc.get("text_letter") or 0)
        rot = int(sc.get("text_rotation") or 0)
        stroke_w = int(sc.get("text_stroke_w") or 0) if sc.get("text_stroke", True) else 0
        stroke_c = _ass_color(sc.get("text_stroke_color") or "#000000")
        place = sc.get("text_place") or "top"
        leading = float(sc.get("text_leading") or 1.15)
        x_off, y_off = int(sc.get("text_x") or 0), int(sc.get("text_y") or 0)
        cxp = cx + x_off
        lines = [ln.replace("{", "(").replace("}", ")") for ln in re.split(r"\s*\n\s*", txt) if ln.strip()]
        if upper:
            lines = [ln.upper() for ln in lines]
        if not lines:
            continue
        n, line_h = len(lines), size * leading
        if place == "center":
            first = SEQ_H * 0.5 - (n - 1) / 2.0 * line_h
        elif place == "bottom":
            first = SEQ_H * 0.86 - (n - 1) * line_h
        else:                                            # top
            first = SEQ_H * 0.15
        border = (f"\\bord{stroke_w}\\3c{stroke_c}" if stroke_w > 0 else "\\bord0")
        frz = f"\\frz{(-rot) % 360}" if rot else ""     # ASS rotates CCW; negate to match CSS (CW)
        fsp = f"\\fsp{letter}" if letter else ""
        out_ms = 400 if (out_anim and out_anim != "none") else 0
        # background box (approx): filled rounded rect behind the whole block. Text width is estimated
        # from a per-char advance (~0.6*size); the exact box is preview-only, pad/radius are adjustable.
        if sc.get("text_bg") and int(sc.get("text_bg_opacity") or 0) > 0:
            pad, rad = int(sc.get("text_bg_pad") or 0), int(sc.get("text_bg_radius") or 0)
            max_chars = max((len(ln) for ln in lines), default=1)
            tw = max_chars * size * 0.60 + max(0, max_chars - 1) * letter
            th = (n - 1) * line_h + size * 1.15
            W, H = int(tw + 2 * pad), int(th + 2 * pad)
            r = max(0, min(rad, W // 2, H // 2))
            bcy = int(round(first + (n - 1) / 2.0 * line_h)) + y_off
            op = max(0, min(100, int(sc.get("text_bg_opacity") or 0)))
            alpha = max(0, min(255, 255 - int(round(op / 100.0 * 255))))
            bg_tag = (f"\\an5\\pos({cxp},{bcy})\\bord0\\shad0{frz}"
                      f"\\1c{_ass_color(sc.get('text_bg_color') or '#000000')}\\1a&H{alpha:02X}&"
                      f"\\fad(400,{out_ms})\\p1")
            out.append(f"Dialogue: 0,{st},{en},OST,,0,0,0,,{{{bg_tag}}}{_round_rect_path(W, H, r)}{{\\p0}}")
        for i, line in enumerate(lines):
            y = int(round(first + i * line_h)) + y_off   # each line is centre-anchored (\an5) at its y
            base = f"\\an5\\q2\\fn{font}\\fs{size}\\c{col}{fill_a}{bold_tag}\\i{italic}\\u{under}{fsp}{frz}{border}{shadow_tag}"
            if anim == "none":
                tag = f"{base}\\pos({cxp},{y})" + (f"\\fad(0,{out_ms})" if out_ms else "")
            elif anim == "popup":
                tag = f"{base}\\pos({cxp},{y})\\fad(250,{out_ms})\\fscx50\\fscy50\\t(0,400,\\fscx100\\fscy100)"
            elif anim == "slide-left":
                tag = f"{base}\\move({cxp - off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-right":
                tag = f"{base}\\move({cxp + off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-top":
                tag = f"{base}\\move({cxp},{y - off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-bottom":
                tag = f"{base}\\move({cxp},{y + off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            else:
                tag = f"{base}\\pos({cxp},{y})\\fad(500,{out_ms})"
            out.append(f"Dialogue: 1,{st},{en},OST,,0,0,0,,{{{tag}}}{line}")
    return out


def build_ass(captions, scenes, path):
    """Write the caption cues + on-screen-text overlays as an .ass subtitle file.

    We generate ASS rather than handing the .srt to ffmpeg because ffmpeg's SRT->ASS
    conversion picks its own PlayRes, which makes the resulting on-screen font size
    depend on the ffmpeg build. With an explicit PlayResX/Y the size is exact.
    """
    head = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {SEQ_W}\n"
        f"PlayResY: {SEQ_H}\n"
        "WrapStyle: 0\n"
        "ScaledBorderAndShadow: yes\n"
        "\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        # BorderStyle=3 -> the caption box. libass draws that box in OutlineColour (NOT
        # BackColour, which is the drop shadow), so the CSS background alpha goes there.
        # Outline=6 is the box padding; Alignment=2 -> bottom-centre.
        f"Style: Def,{FONT_NAME},{FONT_SIZE},&H00FFFFFF,&H00FFFFFF,&H{BOX_ALPHA:02X}000000,"
        f"&H{BOX_ALPHA:02X}000000,0,0,0,0,100,100,0,0,3,6,0,2,"
        f"{SIDE_MARGIN},{SIDE_MARGIN},{MARGIN_V},1\n"
        # OST = on-screen text overlay: outline (BorderStyle=1), no box, top-centre. Per-scene
        # font/size/colour + animation come from inline override tags (see _ost_events).
        f"Style: OST,Arial,56,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,1,0,0,0,100,100,0,0,1,3,2,8,12,12,60,1\n"
        "\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    lines = []
    for c in captions:
        txt = (c.get("text") or "").strip()
        if not txt:
            continue
        # ASS reserves braces for override tags, and needs \N for a hard line break
        txt = txt.replace("{", "(").replace("}", ")")
        txt = re.sub(r"\s*\n\s*", r"\\N", txt)
        lines.append(f"Dialogue: 0,{_t(_snap(c['start']))},{_t(_snap(c['end']))},Def,,0,0,0,,{txt}")
    lines += _ost_events(scenes)                     # animated on-screen text on top of the captions
    Path(path).write_text(head + "\n".join(lines) + "\n", encoding="utf-8")


def _fit(label, upscaling):
    """Scale to the canvas preserving aspect, pad the rest black, square pixels.

    lanczos when shrinking (2K stills -> 1080p: keeps them crisp), bicubic when
    enlarging (720p clips -> 1080p: lanczos rings on upscale).
    """
    flags = "bicubic" if upscaling else "lanczos"
    return (f"[{label}]scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=decrease:flags={flags},"
            f"pad={SEQ_W}:{SEQ_H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps={FPS}")


# Ken-Burns works on an oversized canvas, this many times the output. zoompan places its
# crop window on WHOLE pixels of that canvas, so the canvas resolution — not any output
# super-sampling — sets the step size of the move. Our zoom is slow (1.4 %/sec), so on a
# small canvas the window advances well under a pixel per frame, freezes, then jumps: the
# shake. Measured (frame-to-frame diff; evenness = coefficient of variation, lower = smoother):
#     2x  6 % frames frozen, CV 42 %   <- the shake
#     3x  0 % frozen,        CV 26 %
#     4x  0 % frozen,        CV 10 %
#     5x  0 % frozen,        CV  8 %   <- and lowest fine-detail shimmer of the set
# The lever is this input canvas; super-sampling the zoom OUTPUT and downscaling was
# measured to NOT reduce the shake, only the render time. 5x is the practical floor.
KEN_CANVAS = 5


def _kenburns_fit(label, dur):
    """Scale a still onto the oversized Ken-Burns canvas, then zoom in at a constant
    1.4 %/sec — the same speed as the Premiere export's Ken Burns.

    COVER the canvas (scale up to fill, crop the small overflow), NOT fit-and-black-pad:
    with pad, zoompan at zoom=1 showed the whole padded frame, so a still that wasn't
    exactly 16:9 opened with black bars top/bottom that "filled in" as the zoom cropped
    inward. increase+crop makes frame 1 already fill the frame; the zoom then starts from
    there identically.

    bicubic, not lanczos, for the enlargement: we scale a ~2K still up past 4K, and lanczos
    rings on enlargement — that ringing crawls as shimmer during the slow zoom (measured
    lower shimmer with bicubic). This also scales once, straight from the source, so no
    2K -> 1080p -> canvas round-trip throws away the detail the image generator gave us.
    """
    kw, kh = SEQ_W * KEN_CANVAS, SEQ_H * KEN_CANVAS
    frames = max(1, int(round(dur * FPS)))
    z = ZOOM_PCT_PER_SEC / 100.0
    return (f"[{label}]scale={kw}:{kh}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={kw}:{kh},setsar=1,fps={FPS},"
            f"zoompan=z='1+{z:.5f}*on/{FPS}':d={frames}:s={SEQ_W}x{SEQ_H}:fps={FPS}"
            f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'")


def _exact(dur):
    """Force a segment to be EXACTLY dur long: hold the last frame if the source ran
    out (a clip shorter than its spoken line), cut it if it ran over."""
    # 5 dp: the timeline hands us frame-quantized durations (frame/60), so keep that precision
    # here — each clip is then an exact whole-frame count and the clips don't drift when concatenated
    return (f",tpad=stop_mode=clone:stop_duration={dur:.5f},"
            f"trim=duration={dur:.5f},setpts=PTS-STARTPTS")

# per-scene transition key -> ffmpeg xfade transition name (slide render has no blur; the
# preview adds blur via CSS). "none" = a hard cut (a 1-frame xfade, imperceptible).
XFADE_NAMES = {
    "crossfade": "fade", "dip-black": "fadeblack", "dip-white": "fadewhite",
    "slide-left": "slideleft", "slide-right": "slideright",
    "slide-up": "slideup", "slide-down": "slidedown",
}
TX_SEC = 0.4          # scene-transition length (short; NOT XFADE_SEC, which is the 3s music cross-fade)


def build_graph(timeline, opts):
    """Return (ffmpeg input args, filter-graph text, output map labels).

    Scene media become real -i inputs; gaps and blank scenes become in-graph color
    sources (no input slot needed).
    """
    ken = bool(opts.get("kenburns"))
    xfade = XFADE_SEC if opts.get("crossfade", True) else 0.0
    total = float(timeline["total"])

    inputs, graph = [], []
    idx = 0                       # next ffmpeg input index

    # 1) resolve every segment (scene clip, or black for a gap/blank) with its duration and
    #    the transition INTO the next segment (the outgoing scene owns the handoff).
    segs = []                     # each: {"kind","src","dur","trans"}
    cursor = 0.0
    for sc in timeline["scenes"]:
        start, end = _snap(sc["start"]), _snap(sc["end"])   # frame-align so the xfade boundary lands on the same frame as the (also snapped) caption cue
        if start - cursor > 0.02:                 # nothing scheduled here -> black filler (hard cut)
            segs.append({"kind": "black", "src": None, "dur": start - cursor, "trans": "none"})
        dur = end - start
        cursor = end
        if dur <= 0:
            continue
        kind, src = sc.get("kind"), sc.get("path")
        trans = sc.get("transition") or "none"
        if kind == "video" and src:
            segs.append({"kind": "video", "src": src, "dur": dur, "trans": trans})
        elif kind == "image" and src:
            segs.append({"kind": "image", "src": src, "dur": dur, "trans": trans})
        else:
            segs.append({"kind": "black", "src": None, "dur": dur, "trans": "none"})
    if total - cursor > 0.02:                      # voice-over runs past the last scene
        segs.append({"kind": "black", "src": None, "dur": total - cursor, "trans": "none"})

    if not segs:
        raise RuntimeError("Nothing to render — no scene has an approved image or video yet.")

    # transitions on only when the user asked AND some non-last segment actually has one
    use_tx = bool(opts.get("transitions", True)) and len(segs) > 1 and \
        any(s["trans"] != "none" for s in segs[:-1])
    HARD = 1.0 / FPS               # a "none" handoff = a 1-frame xfade (a clean cut)

    # overlap AFTER each segment (into the next). Clamp so a transition never exceeds half of
    # either adjacent clip — otherwise a short scene's xfade would run past the clip and break.
    def _dout(i):
        if not use_tx or i >= len(segs) - 1:
            return 0.0
        if segs[i]["trans"] == "none":
            return HARD
        return max(HARD, min(TX_SEC, 0.5 * segs[i]["dur"], 0.5 * segs[i + 1]["dur"]))
    douts = [_dout(i) for i in range(len(segs))]

    # 2) build each segment; a transitioning clip is extended by its overlap so the total
    #    duration (and every scene start) stays exactly aligned with the audio/captions.
    for i, s in enumerate(segs):
        seglen = s["dur"] + douts[i]
        if s["kind"] == "video":
            inputs += ["-i", str(s["src"])]
            graph.append(_fit(f"{idx}:v", upscaling=True) + _exact(seglen) + f"[v{i}]")
            idx += 1
        elif s["kind"] == "image":
            inputs += ["-loop", "1", "-framerate", str(FPS), "-t", f"{seglen + 0.5:.3f}", "-i", str(s["src"])]
            chain = _kenburns_fit(f"{idx}:v", seglen) if ken else _fit(f"{idx}:v", upscaling=False)
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        else:
            graph.append(f"color=c=black:s={SEQ_W}x{SEQ_H}:r={FPS}:d={seglen:.5f},setsar=1[v{i}]")

    # 3) join: a plain concat when there are no transitions, else an xfade chain. Each xfade
    #    starts at the (original) scene boundary; the outgoing clip's extension covers the overlap.
    slide_windows = []                             # (start_t, dur, transition) → motion-blur the slide
    if not use_tx:
        graph.append(f"{''.join(f'[v{i}]' for i in range(len(segs)))}concat=n={len(segs)}:v=1:a=0[vcat]")
    else:
        acc, cum = "v0", segs[0]["dur"]            # cum = start time of the next segment
        for i in range(1, len(segs)):
            trans = segs[i - 1]["trans"]
            D = douts[i - 1]                        # same overlap the outgoing clip was extended by
            name = XFADE_NAMES.get(trans, "fade")
            out = "vcat" if i == len(segs) - 1 else f"xf{i}"
            graph.append(f"[{acc}][v{i}]xfade=transition={name}:duration={D:.5f}:offset={cum:.5f}[{out}]")
            if trans.startswith("slide-"):
                slide_windows.append((cum, D, trans))
            acc = out
            cum += segs[i]["dur"]
    # Motion blur on slides, matching the preview's blurred push. A single box blur looks blocky/"cheap",
    # so we run TWO smaller box passes (≈ a smooth gaussian) along the slide axis only, gated to each
    # slide's time window. One filter chain per direction keeps a video with many slides light.
    vsrc = "vcat"
    if slide_windows:
        rad = max(2, round(SEQ_W / 150))           # per-pass radius (~13 at 1080p, ~9 at 720p)
        groups = ((True,  [w for w in slide_windows if w[2] in ("slide-left", "slide-right")]),
                  (False, [w for w in slide_windows if w[2] in ("slide-up", "slide-down")]))
        k = 0
        for horiz, group in groups:
            if not group:
                continue
            conds = "+".join(f"between(t,{c0:.5f},{c0 + d:.5f})" for (c0, d, tr) in group)
            sx, sy = (rad, 1) if horiz else (1, rad)
            for _ in range(2):                     # two passes → smooth (gaussian-like), not boxy
                nxt = f"vb{k}"; k += 1
                graph.append(f"[{vsrc}]avgblur=sizeX={sx}:sizeY={sy}:enable='{conds}'[{nxt}]")
                vsrc = nxt
    # burn subs.ass if captions are on OR on-screen text is on and some scene has overlay text
    # (overlay text burns even when "Burn Subtitles" is off). relative filename — ffmpeg runs with cwd = the work dir.
    has_ost = bool(opts.get("onscreentext", True)) and any(
        (ov.get("text") or "").strip() for s in timeline["scenes"] for ov in (s.get("texts") or []))
    if opts.get("burnsubs", True) or has_ost:
        graph.append(f"[{vsrc}]ass=subs.ass:fontsdir=fonts[vout]")
    else:
        graph.append(f"[{vsrc}]null[vout]")            # clean render, no captions, no overlay text

    # ---- audio: voice-over + one stream per music segment ----
    inputs += ["-i", str(timeline["vo"])]
    vo_idx = idx; idx += 1
    graph.append(f"[{vo_idx}:a]aresample=48000,asetpts=PTS-STARTPTS[avo]")
    alabels = ["[avo]"]

    # music off -> no music streams at all, so the mix below is voice-over only
    music_segs = (timeline.get("music") or []) if opts.get("music", True) else []
    last = len(music_segs) - 1
    for i, seg in enumerate(music_segs):
        if not seg.get("path"):
            continue
        s, e = float(seg["start"]), float(seg["end"])
        span = e - s
        if span <= 0.05:
            continue
        # Cross-fade COMPLETES at the boundary (matches the Premiere export): a non-first segment
        # PRE-ROLLS by xfade — it starts xfade before its boundary and fades up to full exactly AT
        # the boundary, while the previous segment fades out over its last xfade ending at the same
        # boundary. So when the new scene starts the new music is already at full, the old one gone.
        pre = xfade if (xfade and i > 0) else 0.0
        placed_start = max(0.0, s - pre)
        placed_dur = span + (s - placed_start)
        fin = (s - placed_start) if i > 0 else min(1.5, span)          # reaches full at the boundary
        fout = xfade if (i < last and xfade) else min(2.0, placed_dur)  # last segment gets a longer outro
        # -stream_loop so a segment longer than its track doesn't fall silent
        inputs += ["-stream_loop", "-1", "-i", str(seg["path"])]
        chain = (f"[{idx}:a]aresample=48000,atrim=duration={placed_dur:.3f},asetpts=PTS-STARTPTS,"
                 f"volume={float(seg.get('level') or 0.15):.4f},"
                 f"afade=t=in:st=0:d={max(0.05, fin):.3f},"
                 f"afade=t=out:st={max(0.0, placed_dur - fout):.3f}:d={max(0.05, fout):.3f}")
        delay = int(round(placed_start * 1000))
        chain += f",adelay={delay}|{delay}[am{i}]"
        graph.append(chain)
        alabels.append(f"[am{i}]")
        idx += 1

    if len(alabels) > 1:
        # normalize=0: the VO is already at -16 LUFS and each music segment already carries
        # its measured -33 LUFS gain, so amix must NOT re-level them. alimiter is a safety
        # net against the rare sum overshooting 0 dBFS.
        graph.append(f"{''.join(alabels)}amix=inputs={len(alabels)}:duration=longest:normalize=0,"
                     f"alimiter=limit=0.97[aout]")
    else:
        graph.append("[avo]alimiter=limit=0.97[aout]")

    return inputs, ";\n".join(graph), ("[vout]", "[aout]")


def render(timeline, out_path, workdir, opts=None, progress=None, on_proc=None):
    """Render the timeline to out_path. `progress(pct, seconds_done)` is called as it runs.
    `on_proc(popen)` is called once with the ffmpeg process so the caller can cancel it.

    Returns the output Path. Raises RuntimeError with ffmpeg's tail on failure.
    """
    opts = opts or {}
    # Fast "test render": drop to 720p30 + x264 ultrafast + higher CRF for a quick sync/timing check.
    # These are module-level constants the filter builders read by name, so override them only while we
    # build the graph/subs/command, then restore (the ffmpeg subprocess itself uses the already-built cmd).
    global FPS, SEQ_W, SEQ_H, PRESET, CRF
    _saved = (FPS, SEQ_W, SEQ_H, PRESET, CRF)
    if opts.get("fast"):
        FPS, SEQ_W, SEQ_H, PRESET, CRF = 30, 1280, 720, "ultrafast", "28"
    try:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Bundle the on-screen-text fonts into the work dir so libass can find them — most of the
        # chosen fonts (Montserrat, Poppins, Flatshoes, …) are NOT installed system-wide. A relative
        # fontsdir=fonts (cwd is the work dir) sidesteps Windows filter-path escaping.
        try:
            _fsrc = Path(__file__).parent / "static" / "fonts"
            if _fsrc.is_dir():
                _fdst = workdir / "fonts"; _fdst.mkdir(exist_ok=True)
                for _f in _fsrc.iterdir():
                    if _f.suffix.lower() in (".ttf", ".otf"):
                        shutil.copy2(_f, _fdst / _f.name)
        except Exception:
            pass

        # captions only when "Burn Subtitles" is on; on-screen text overlays only when "On-screen Text" is on
        caps = (timeline.get("captions") or []) if opts.get("burnsubs", True) else []
        scenes_for_ass = timeline.get("scenes") or []
        if not opts.get("onscreentext", True):
            scenes_for_ass = [{**s, "texts": []} for s in scenes_for_ass]   # drop overlays so they don't burn
        build_ass(caps, scenes_for_ass, workdir / "subs.ass")
        inputs, graph, (vlab, alab) = build_graph(timeline, opts)
        (workdir / "filter.txt").write_text(graph, encoding="utf-8")

        total = float(timeline["total"])
        cmd = (["ffmpeg", "-y", "-hide_banner", "-nostats"] + inputs +
               ["-filter_complex_script", "filter.txt", "-map", vlab, "-map", alab,
                "-t", f"{total:.3f}",
                "-c:v", "libx264", "-preset", PRESET, "-crf", CRF,
                "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.2",
                "-r", str(FPS), "-g", str(FPS * 2),
                "-c:a", "aac", "-b:a", AUDIO_BITRATE, "-ar", "48000", "-ac", "2",
                "-movflags", "+faststart",
                "-progress", "pipe:1", str(out_path)])
    finally:
        FPS, SEQ_W, SEQ_H, PRESET, CRF = _saved   # restore before the (slow) ffmpeg run

    # stderr goes STRAIGHT to the log file, not a pipe: ffmpeg is chatty, and a pipe we
    # only drain after wait() fills its buffer and deadlocks the render. stdout stays a
    # pipe because that's the -progress stream we read live.
    log = workdir / "render.log"
    with open(log, "w", encoding="utf-8", errors="ignore") as errf:
        proc = subprocess.Popen(cmd, cwd=str(workdir), stdout=subprocess.PIPE,
                                stderr=errf, text=True, encoding="utf-8",
                                errors="ignore", bufsize=1, creationflags=_NO_WINDOW)
        if on_proc:
            on_proc(proc)          # hand the process to the caller so a cancel can kill it
        try:
            for line in proc.stdout:
                m = re.match(r"out_time_us=(\d+)", line.strip())
                if m and progress and total > 0:
                    done = int(m.group(1)) / 1_000_000.0
                    progress(min(99, int(done / total * 100)), done)
        finally:
            proc.wait()

    tail = []
    try:
        err = log.read_text(encoding="utf-8", errors="ignore")
        tail = [ln for ln in err.strip().splitlines() if ln.strip()][-6:]
    except Exception:
        pass

    if proc.returncode != 0 or not out_path.exists():
        why = " | ".join(tail) if tail else f"exit {proc.returncode}; see {log}"
        raise RuntimeError(f"ffmpeg failed: {why}")
    if progress:
        progress(100, total)
    return out_path
