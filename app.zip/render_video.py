"""
Server-side MP4 render — turns the dashboard's rough-cut preview into ONE finished
file the user can download and upload straight to YouTube.

What it renders is exactly what the preview plays, because both are driven by the
same timeline dict (see app._build_timeline): the same scene media at the same
audio-driven time ranges, the same scene-split captions, the same voice-over, and
the same emotion-segmented music at the same per-segment levels.

Output: 1920x1080 @ 60 fps H.264 — the SAME spec as the Premiere export (premiere_export.FPS
/ SEQ_W / SEQ_H), so the delivered MP4 and the editable timeline match frame for frame.
Captions are BURNED IN (libass), because a YouTube upload can't carry a sidecar SRT.

Everything is done in ONE ffmpeg pass:
  video  each scene -> scaled/padded to the canvas at exactly its scene duration, concat
  subs   generated .ass (explicit PlayRes so font size is deterministic), burned on the concat
  audio  voice-over + one delayed/faded music stream per segment, amix normalize=0

The filter graph is written to a FILE (-filter_complex_script) rather than the command
line: a 40-scene VSL builds a graph well past the Windows 32 KB argv limit.
"""
import os, re, math, subprocess, shutil, threading
import numpy as np
from pathlib import Path
from quietlog import quiet

# Hide the console window ffmpeg would otherwise pop up on every call (the dashboard
# itself runs windowless, so children have no console to inherit).
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_RENDER_PREP_LOCK = threading.Lock()

_NVENC = None
def _has_nvenc():
    """True if this ffmpeg has the NVIDIA h264_nvenc encoder (cached)."""
    global _NVENC
    if _NVENC is None:
        try:
            out = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True,
                                  text=True, timeout=15, creationflags=_NO_WINDOW).stdout or ""
            _NVENC = "h264_nvenc" in out
        except Exception:
            _NVENC = False
    return _NVENC

from premiere_export import FPS, SEQ_W, SEQ_H, zoom_pct, XFADE_SEC, icon_onscreen, is_badge, ffprobe_media, _UTX, _UTX_DIR, utx_sfx_level
from premiere_export import _icon_hue_file, _icon_geom, _ICON_ONSCREEN, _VFX, _MOV_OFF, _movfx_alpha_file, _vfx_mode
import premiere_export
import project_canvas
import media_delivery

try:
    import parallax                          # depth-warped stills (optional; falls back to flat Ken Burns)
except Exception:
    parallax = None
try:
    import caption_layer                     # browser-rendered caption/OST layer (pixel-identical to preview)
except Exception:
    caption_layer = None

# x264 settings for a final YouTube deliverable. CRF 17 at 1080p60 is visually
# transparent; "medium" keeps a long VSL to a sane render time (slower presets buy
# file size, not picture, at this CRF).
CRF = "17"
PRESET = "medium"
AUDIO_BITRATE = "320k"

# Burned-caption look — matches .pv-caption in static/style.css (white text in a
# 62%-black box, centred, just above the bottom edge) at 1080p scale.
FONT_NAME = "Arial"
FONT_SIZE = 46
BOX_ALPHA = 0x61          # ASS alpha: 0x00 opaque .. 0xFF clear; 0x61 ~= the CSS .62
MARGIN_V = 48             # ~4.5% up from the bottom, as in the preview
SIDE_MARGIN = 140         # keeps lines off the extreme edges (title-safe-ish)


def _snap(sec):
    """Snap a time to the nearest video frame. Caption cues and scene boundaries come from the
    forced-alignment/scene-split (arbitrary sub-frame times); snapping BOTH to the same frame grid
    makes the burned subtitle change land on the very frame the scene/image changes, instead of the
    ~1-2 frame drift you get when a raw cue time rounds onto a neighbouring frame."""
    return premiere_export.frame_time(sec, FPS)


def _t(sec):
    """Seconds -> ASS timestamp H:MM:SS.cc. FLOOR to centiseconds: a frame-aligned cue time
    (frame/60) then lands on its exact video frame instead of possibly rounding up a frame."""
    sec = math.floor(max(0.0, float(sec)) * 100) / 100
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def _ass_color(hex_color):
    """#RRGGBB -> ASS &H00BBGGRR& (ASS colour is BGR)."""
    h = (hex_color or "#ffffff").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        r, g, b = 255, 255, 255
    return f"&H00{b:02X}{g:02X}{r:02X}&"


def _round_rect_path(w, h, r):
    """ASS \\p1 drawing path for a (rounded) rectangle, top-left at 0,0."""
    if r <= 0:
        return f"m 0 0 l {w} 0 l {w} {h} l 0 {h}"
    return (f"m {r} 0 l {w-r} 0 b {w} 0 {w} 0 {w} {r} "
            f"l {w} {h-r} b {w} {h} {w} {h} {w-r} {h} "
            f"l {r} {h} b 0 {h} 0 {h} 0 {h-r} "
            f"l 0 {r} b 0 0 0 0 {r} 0")


def _ost_events(scenes):
    """Animated on-screen-text overlay events. Styled per scene (font/weight/size/colour/style flags/
    letter-spacing/rotation/stroke/shadow/background box), placed top|center|bottom with custom line
    spacing (each line is its own centred event so leading is honoured), an entrance animation that
    ALWAYS also fades in, and an optional exit fade-out — matches the preview."""
    def _cf(v, d):                                # clamp a 0..1 fraction
        try: return min(1.0, max(0.0, float(v)))
        except (TypeError, ValueError): return d
    items = []                                    # flatten: each scene → its overlays, each with ITS OWN window
    for _scene in (scenes or []):
        _s0, _e0 = float(_scene["start"]), float(_scene["end"])
        _dur = max(0.0, _e0 - _s0)
        for _ov in (_scene.get("texts") or []):
            _a = _s0 + _dur * _cf(_ov.get("text_in"), 0.0)
            _b = _s0 + _dur * _cf(_ov.get("text_out"), 1.0)
            if _b <= _a:                          # keep at least a sliver
                _b = min(_e0, _a + 0.1)
            items.append((_ov, _t(_a), _t(_b)))
    return _emit_text_items(items)


def _emit_text_items(items):
    """Render a flat list of (text_* dict, start, end) into ASS Dialogue lines on the OST style —
    shared by the on-screen-text overlays and the global-styled subtitle captions."""
    SEQ_W, SEQ_H = project_canvas.size()
    out = []
    cx, off = SEQ_W // 2, 90
    for sc, st, en in items:                      # sc = one overlay's text_* dict
        txt = (sc.get("text") or "").strip()
        if not txt:
            continue
        font = (sc.get("text_font") or "Arial").replace("{", "").replace("}", "")
        size = int(sc.get("text_size") or 56)
        col = _ass_color(sc.get("text_color") or "#ffffff")
        fill_a = "" if sc.get("text_fill", True) else "\\1a&HFF&"   # Fill off → transparent glyph (stroke only)
        anim = sc.get("text_anim") or "fade"
        out_anim = sc.get("text_out_anim") or "none"
        # Preserve the legacy ASS fallback; an explicit Distance uses directional x/y shadow tags.
        if sc.get("text_shadow", True):
            shad_depth = max(0, int(sc.get("text_shadow_size") or 0)) or 2
            shad_op = max(0, min(100, int(sc.get("text_shadow_opacity") or 0)))
            shad_alpha = max(0, min(255, 255 - int(round(shad_op / 100.0 * 255))))
            shadow_tag = f"\\shad{shad_depth}\\4c{_ass_color(sc.get('text_shadow_color') or '#000000')}\\4a&H{shad_alpha:02X}&"
            if sc.get("text_shadow_distance") is not None:
                distance = float(sc["text_shadow_distance"])
                direction = math.radians(float(sc.get("text_shadow_dir", 135)))
                shadow_tag += f"\\xshad{distance * math.cos(direction):.2f}\\yshad{distance * math.sin(direction):.2f}"
        else:
            shadow_tag = "\\shad0"
        try:
            weight = int(sc.get("text_weight") or 400)
        except (TypeError, ValueError):
            weight = 400
        # Weight: \b with a hundreds value (100..900) is honoured only by *some* libass builds; others
        # render ANY non-zero \b as full bold — which made a normal 400 caption come out bold in the
        # render while the browser preview showed it normal. Use the portable on/off form so render ==
        # preview everywhere: normal (<600) vs bold (>=600).
        eff_w = 700 if (sc.get("text_bold") and weight < 700) else weight
        bold_tag = "\\b1" if eff_w >= 600 else "\\b0"
        italic = 1 if sc.get("text_italic") else 0
        under = 1 if sc.get("text_underline") else 0
        upper = bool(sc.get("text_upper"))
        letter = int(sc.get("text_letter") or 0)
        rot = int(sc.get("text_rotation") or 0)
        stroke_w = int(sc.get("text_stroke_w") or 0) if sc.get("text_stroke", True) else 0
        stroke_c = _ass_color(sc.get("text_stroke_color") or "#000000")
        place = sc.get("text_place") or "top"
        leading = float(1.15 if sc.get("text_leading") is None else sc["text_leading"])
        x_off, y_off = float(sc.get("text_x") or 0), float(sc.get("text_y") or 0)
        cxp = cx + x_off
        lines = [ln.replace("{", "(").replace("}", ")") for ln in re.split(r"\s*\n\s*", txt) if ln.strip()]
        if SEQ_W != 1920 and not sc.get("_caption"):
            # Fallback used only when a browser caption renderer is unavailable.
            import textwrap
            limit = max(4, int(SEQ_W * .94 / max(1, size * .60 + letter)))
            lines = [part for line in lines for part in textwrap.wrap(line, width=limit)]
        if upper:
            lines = [ln.upper() for ln in lines]
        if not lines:
            continue
        n, line_h = len(lines), size * leading
        if place == "center":
            first = SEQ_H * 0.5 - (n - 1) / 2.0 * line_h
        elif place == "bottom":
            # captions sit lower (matches the preview's .pv-caption at ~4.5% from the bottom);
            # on-screen-text overlays keep the higher 14%-from-bottom anchor.
            _bfrac = 0.925 if sc.get("_caption") else 0.86
            first = SEQ_H * _bfrac - max(0, (n - 1) * line_h)
        else:                                            # top
            first = SEQ_H * 0.15 - min(0, (n - 1) * line_h)
        border = (f"\\bord{stroke_w}\\3c{stroke_c}" if stroke_w > 0 else "\\bord0")
        frz = f"\\frz{(-rot) % 360}" if rot else ""     # ASS rotates CCW; negate to match CSS (CW)
        fsp = f"\\fsp{letter}" if letter else ""
        out_ms = 400 if (out_anim and out_anim != "none") else 0
        # background box (approx): filled rounded rect behind the whole block. Text width is estimated
        # from a per-char advance (~0.6*size); the exact box is preview-only, pad/radius are adjustable.
        if sc.get("text_bg") and int(sc.get("text_bg_opacity") or 0) > 0:
            pad, rad = int(sc.get("text_bg_pad") or 0), int(sc.get("text_bg_radius") or 0)
            max_chars = max((len(ln) for ln in lines), default=1)
            tw = max_chars * size * 0.60 + max(0, max_chars - 1) * letter
            th = abs((n - 1) * line_h) + size * 1.15
            W, H = int(tw + 2 * pad), int(th + 2 * pad)
            r = max(0, min(rad, W // 2, H // 2))
            bcy = int(round(first + (n - 1) / 2.0 * line_h)) + y_off
            op = max(0, min(100, int(sc.get("text_bg_opacity") or 0)))
            alpha = max(0, min(255, 255 - int(round(op / 100.0 * 255))))
            bg_tag = (f"\\an5\\pos({cxp},{bcy})\\bord0\\shad0{frz}"
                      f"\\1c{_ass_color(sc.get('text_bg_color') or '#000000')}\\1a&H{alpha:02X}&"
                      f"\\fad(400,{out_ms})\\p1")
            if sc.get("text_bg_shadow"):
                distance = float(sc.get("text_bg_shadow_distance", 8))
                direction = math.radians(float(sc.get("text_bg_shadow_dir", 135)))
                sx, sy = cxp + distance * math.cos(direction), bcy + distance * math.sin(direction)
                opacity = max(0, min(100, float(sc.get("text_bg_shadow_opacity", 60))))
                shade_alpha = 255 - round(opacity * 2.55)
                blur = max(0, float(sc.get("text_bg_shadow_size", 12))) / 2
                shade_tag = (f"\\an5\\pos({sx:.2f},{sy:.2f})\\bord0\\shad0{frz}\\blur{blur:g}"
                             f"\\1c{_ass_color(sc.get('text_bg_shadow_color') or '#000000')}\\1a&H{shade_alpha:02X}&"
                             f"\\fad(400,{out_ms})\\p1")
                out.append(f"Dialogue: 0,{st},{en},OST,,0,0,0,,{{{shade_tag}}}{_round_rect_path(W, H, r)}{{\\p0}}")
            out.append(f"Dialogue: 0,{st},{en},OST,,0,0,0,,{{{bg_tag}}}{_round_rect_path(W, H, r)}{{\\p0}}")
        alignment=sc.get('text_align') if sc.get('text_align') in ('left','center','right') else 'center'
        anchor={'left':4,'center':5,'right':6}[alignment]
        if alignment!='center':
            max_chars=max(map(len,lines))
            width=max_chars*size*.60+max(0,max_chars-1)*letter
            cxp+=(-width/2 if alignment=='left' else width/2)
        for i, line in enumerate(lines):
            y = int(round(first + i * line_h)) + y_off   # each line is centre-anchored (\an5) at its y
            base = f"\\an{anchor}\\q2\\fn{font}\\fs{size}\\c{col}{fill_a}{bold_tag}\\i{italic}\\u{under}{fsp}{frz}{border}{shadow_tag}"
            if anim == "none":
                tag = f"{base}\\pos({cxp},{y})" + (f"\\fad(0,{out_ms})" if out_ms else "")
            elif anim == "popup":
                tag = f"{base}\\pos({cxp},{y})\\fad(250,{out_ms})\\fscx50\\fscy50\\t(0,400,\\fscx100\\fscy100)"
            elif anim == "slide-left":
                tag = f"{base}\\move({cxp - off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-right":
                tag = f"{base}\\move({cxp + off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-top":
                tag = f"{base}\\move({cxp},{y - off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-bottom":
                tag = f"{base}\\move({cxp},{y + off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            else:
                tag = f"{base}\\pos({cxp},{y})\\fad(500,{out_ms})"
            out.append(f"Dialogue: 1,{st},{en},OST,,0,0,0,,{{{tag}}}{line}")
    return out


def _snum(v, d):
    try: return float(v)
    except (TypeError, ValueError): return d


# A MARK STAYS WITH ITS WORD (mirror of subtitle/vsl_align_srt.py _bind and app.js capBind): French sets
# ? ! : ; » € % apart with a space ("chez moi ? »", "120 €"), so a plain wrap could open a line on "»" or "€".
# A closing mark belongs to the word before it, an opening mark («, ¿, ( …) to the word after it, a thousands
# group to its number ("96 400"). Dashes and a free-standing … are real break points; " “ ‘ are ambiguous.
_CAP_CLOSE, _CAP_OPEN, _CAP_CUR = set("?!:;,.»›”’)]}%‰°"), set("«‹„‚¿¡([{"), set("€$£¥₺₽")


def _cap_bind(toks, k):
    s = (toks[k] or "").strip()
    if not s:
        return None
    prev = toks[k - 1].strip() if k > 0 else ""
    if re.match(r"^\d{3}[.,;:!?%)\]]*$", s) and re.match(r"^[(\[]?\d{1,3}$", prev):
        return "back"
    if re.search(r"\w", s):
        return None                                   # a word, not a mark
    if all(c in _CAP_CUR for c in s):                 # € $ £ follow the amount in French, lead it in English
        nxt = toks[k + 1].strip() if k + 1 < len(toks) else ""
        if re.search(r"\d[\d.,]*$", prev):
            return "back"
        return "fwd" if re.match(r"\d", nxt) else "back"
    if "…" in s or ".." in s:
        return None
    if all(c in _CAP_CLOSE or c in _CAP_CUR for c in s):
        return "back"
    if all(c in _CAP_OPEN for c in s):
        return "fwd"
    return None


def cap_units(text):
    """The caption's words with every mark joined to its word by a no-break space - wrap on these, never
    inside one. Mirrors app.js capUnits."""
    toks, out = (text or "").split(), []
    for k, t in enumerate(toks):
        if out and (_cap_bind(toks, k) == "back" or _cap_bind(toks, k - 1) == "fwd"):
            out[-1] += "\u00a0" + t
        else:
            out.append(t)
    return out


def _sub_wrap_lines(text, style):
    """Split a caption into balanced lines per the global subtitle style — width (% of frame) sets how
    many characters fit; 'lines' picks Auto / 1 / 2. Balanced splits avoid a lone word on the last line.
    Returns a list of line strings. Same logic is mirrored in app.js (wrapSub) so preview == render."""
    SEQ_W, SEQ_H = project_canvas.size()
    if "\n" in str(text) or "\r" in str(text):
        return [" ".join(cap_units(line)) for line in str(text).replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    words = cap_units(text)                           # a unit is a word + the marks that belong to it
    text = " ".join(words)
    if not text:
        return []
    width = max(20.0, min(100.0, _snum(style.get("sub_width"), 86)))
    size = max(1.0, _snum(style.get("ost_size"), 46))
    mode = str(style.get("sub_lines") or "auto")
    cpl = max(6, int(SEQ_W * width / 100.0 / (0.5 * size)))   # ~chars per line at this width+size

    def greedy(cap):
        lines, cur = [], ""
        for w in words:
            if cur and len(cur) + 1 + len(w) > cap:
                lines.append(cur); cur = w
            else:
                cur = (cur + " " + w) if cur else w
        if cur:
            lines.append(cur)
        return lines or [text]

    def balance(n):
        if n <= 1 or len(words) < 2:
            return [text]
        total = len(text)
        target = total / n
        lines, cur = [], []
        for idx, w in enumerate(words):
            cur.append(w)
            cur_len = len(" ".join(cur))
            words_left = len(words) - idx - 1
            lines_left = n - len(lines) - 1
            if len(lines) < n - 1 and cur_len >= target and words_left >= lines_left:
                lines.append(" ".join(cur)); cur = []
        if cur:
            lines.append(" ".join(cur))
        return lines

    if mode == "1":
        return [text]                                 # force ONE line — never wrap (box hugs it)
    if mode == "2":
        return [text] if len(text) <= cpl else balance(2)
    # auto: fill each line up to the "Line" width (greedy → text reaches the edges); mirrors app.js wrapSubLines
    if len(text) <= cpl:
        return [text]
    out = greedy(cpl)
    # ...but never strand a word on its own line: two lines with a stub at the end become two even ones
    if len(out) == 2 and len(out[-1]) < 0.35 * cpl:
        out = balance(2)
    return out


def _style_to_text(style, text):
    """Map the global subtitle style (ost_* keys) onto the text_* shape _emit_text_items consumes."""
    g = (style or {}).get
    return {
        "text": text,
        "text_font": g("ost_font", "Arial"), "text_size": g("ost_size", 46),
        "text_color": g("ost_color", "#ffffff"), "text_fill": g("ost_fill", True),
        "text_weight": g("ost_weight", "400"), "text_bold": g("ost_bold", False),
        "text_italic": g("ost_italic", False), "text_underline": g("ost_underline", False),
        "text_upper": g("ost_upper", False), "text_letter": g("ost_letter", 0),
        "text_leading": g("ost_leading", 1.15), "text_place": g("ost_place", "bottom"),
        "text_align": g("ost_align", "center"),
        "text_x": g("ost_x", 0), "text_y": g("ost_y", 0), "text_rotation": g("ost_rotation", 0),
        "text_stroke": g("ost_stroke", False), "text_stroke_w": g("ost_stroke_w", 0),
        "text_stroke_color": g("ost_stroke_color", "#000000"),
        "text_bg": g("ost_bg", True), "text_bg_color": g("ost_bg_color", "#000000"),
        "text_bg_opacity": g("ost_bg_opacity", 62), "text_bg_pad": g("ost_bg_pad", 14),
        "text_bg_radius": g("ost_bg_radius", 10),
        "text_shadow": g("ost_shadow", False), "text_shadow_color": g("ost_shadow_color", "#000000"),
        "text_shadow_opacity": g("ost_shadow_opacity", 80), "text_shadow_size": g("ost_shadow_size", 6),
        "text_shadow_dir": g("ost_shadow_dir", 135),
        "text_shadow_distance": g("ost_shadow_distance", None),
        "text_bg_shadow": g("ost_bg_shadow", False),
        "text_bg_shadow_color": g("ost_bg_shadow_color", '#000000'),
        "text_bg_shadow_opacity": g("ost_bg_shadow_opacity", 60),
        "text_bg_shadow_size": g("ost_bg_shadow_size", 12),
        "text_bg_shadow_distance": g("ost_bg_shadow_distance", 8),
        "text_bg_shadow_dir": g("ost_bg_shadow_dir", 135),
        "text_anim": g("ost_anim", "fade"), "text_out_anim": g("ost_out_anim", "none"),
        "_caption": True,   # positions like the preview caption (lower) + not an on-screen overlay
    }


def _caption_events(captions, style):
    """Render captions through the on-screen-text engine using the one global subtitle style."""
    if not style:
        return []
    items = []
    for c in captions:
        lines = str(c.get('text') or '').replace('\r\n','\n').replace('\r','\n').split('\n') if c.get('_caption_policy') == 'speech-v998' else _sub_wrap_lines((c.get("text") or "").strip(), style)
        if not lines:
            continue
        ov = _style_to_text(style, "\n".join(lines))     # _emit_text_items splits on \n into centred lines
        items.append((ov, _t(_snap(float(c["start"]))), _t(_snap(float(c["end"])))))
    return _emit_text_items(items)


def _browser_items(captions, scenes, sub_style, opts):
    """Flatten captions + on-screen-text overlays into the item shape caption_layer.build_clips wants.
    Captions carry the one global subtitle style; each OST overlay carries its own text_* style (mapped
    back to the ost_* keys the browser CSS mirror reads). Times match the libass path exactly."""
    items = []
    rng = opts.get("range")
    rs, re_ = (float(rng[0]), float(rng[1])) if rng else (None, None)

    def _in_range(a, b):
        return rng is None or (b > rs and a < re_)   # overlaps the rendered slice

    # Animated captions measure and wrap in SubtitleMotion, just like the preview.
    # Only authored newlines may reach it: Classic's balancing would wrap twice.
    if opts.get("burnsubs", True) and sub_style:
        for c in (captions or []):
            cs, ce = _snap(float(c["start"])), _snap(float(c["end"]))
            if not _in_range(cs, ce):
                continue                              # outside the rendered slice — the output-seek would cut it anyway
            text = (c.get("text") or "").strip()
            if not text:
                continue
            from caption_layer import motion_enabled
            if not motion_enabled(sub_style) and c.get('_caption_policy') != 'speech-v998':
                text = "\n".join(_sub_wrap_lines(text, sub_style))
            items.append({
                "text": text, "style": dict(sub_style), "kind": "caption",
                "place": sub_style.get("ost_place", "bottom"),
                "x": sub_style.get("ost_x", 0), "y": sub_style.get("ost_y", 0),
                "rotation": sub_style.get("ost_rotation", 0),
                "sub_width": sub_style.get("sub_width", 86),
                "oneline": str(sub_style.get("sub_lines") or "auto") == "1",
                "anim": sub_style.get("ost_anim", "fade"), "out_anim": sub_style.get("ost_out_anim", "none"),
                "start": cs, "end": ce, "words": c.get("words") or [],
                "_caption_policy": c.get('_caption_policy'),
            })
    # on-screen text — each scene's overlays, each with its own window (mirrors _ost_events)
    if opts.get("onscreentext", True):
        def _cf(v, d):
            try: return min(1.0, max(0.0, float(v)))
            except (TypeError, ValueError): return d
        for sc in (scenes or []):
            s0, e0 = float(sc["start"]), float(sc["end"])
            dur = max(0.0, e0 - s0)
            ranks=project_canvas.overlay_ranks(sc)
            for ov in (sc.get("texts") or []):
                txt = ov.get("text") or ""
                if not txt.strip():
                    continue
                style = {("ost_" + k[5:]): v for k, v in ov.items()
                         if k.startswith("text_") and k not in
                         ("text_place", "text_x", "text_y", "text_rotation", "text_anim", "text_out_anim")}
                a = s0 + dur * _cf(ov.get("text_in"), 0.0)
                b = s0 + dur * _cf(ov.get("text_out"), 1.0)
                if b <= a:
                    b = min(e0, a + 0.1)
                if not _in_range(a, b):
                    continue                          # outside the rendered slice
                items.append({
                    "text": txt, "style": style, "kind": "ost",
                    "overlay_rank": ranks.get(id(ov)) if ranks is not None else None,
                    "place": ov.get("text_place", "top"),
                    "x": ov.get("text_x", 0), "y": ov.get("text_y", 0), "rotation": ov.get("text_rotation", 0),
                    "anim": ov.get("text_anim", "fade"), "out_anim": ov.get("text_out_anim", "fade") if round(b*60) < round(e0*60) else "none",
                    "start": a, "end": b,
                })
    return sorted(items,key=lambda it:it.get("kind")=="caption")


def build_ass(captions, scenes, path, sub_style=None):
    """Write the caption cues + on-screen-text overlays as an .ass subtitle file.

    We generate ASS rather than handing the .srt to ffmpeg because ffmpeg's SRT->ASS
    conversion picks its own PlayRes, which makes the resulting on-screen font size
    depend on the ffmpeg build. With an explicit PlayResX/Y the size is exact.
    """
    SEQ_W, SEQ_H = project_canvas.size()
    head = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {SEQ_W}\n"
        f"PlayResY: {SEQ_H}\n"
        "WrapStyle: 0\n"
        "ScaledBorderAndShadow: yes\n"
        "\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        # BorderStyle=3 -> the caption box. libass draws that box in OutlineColour (NOT
        # BackColour, which is the drop shadow), so the CSS background alpha goes there.
        # Outline=6 is the box padding; Alignment=2 -> bottom-centre.
        f"Style: Def,{FONT_NAME},{FONT_SIZE},&H00FFFFFF,&H00FFFFFF,&H{BOX_ALPHA:02X}000000,"
        f"&H{BOX_ALPHA:02X}000000,0,0,0,0,100,100,0,0,3,6,0,2,"
        f"{SIDE_MARGIN},{SIDE_MARGIN},{MARGIN_V},1\n"
        # OST = on-screen text overlay: outline (BorderStyle=1), no box, top-centre. Per-scene
        # font/size/colour + animation come from inline override tags (see _ost_events).
        f"Style: OST,Arial,56,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,1,0,0,0,100,100,0,0,1,3,2,8,12,12,60,1\n"
        "\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    lines = []
    if sub_style:
        # Global subtitle style set → render captions through the on-screen-text engine (full control
        # over font/colour/box/stroke/placement + balanced width-aware wrapping).
        lines += _caption_events(captions, sub_style)
    else:
        for c in captions:
            txt = (c.get("text") or "").strip()
            if not txt:
                continue
            # ASS reserves braces for override tags, and needs \N for a hard line break
            txt = txt.replace("{", "(").replace("}", ")")
            txt = re.sub(r"\s*\n\s*", r"\\N", txt)
            lines.append(f"Dialogue: 0,{_t(_snap(c['start']))},{_t(_snap(c['end']))},Def,,0,0,0,,{txt}")
    # Reserve higher ASS layers for subtitles in the fallback renderer too.
    lines=[re.sub(r"^Dialogue: (\d+),",lambda m:"Dialogue: "+str(int(m[1])+10)+",",line) for line in lines]
    lines += _ost_events(scenes)
    Path(path).write_text(head + "\n".join(lines) + "\n", encoding="utf-8")


# Ken-Burns works on an oversized canvas, this many times the output. zoompan places its
# crop window on WHOLE pixels of that canvas, so the canvas resolution — not any output
# super-sampling — sets the step size of the move. Our zoom is slow (1.4 %/sec), so on a
# small canvas the window advances well under a pixel per frame, freezes, then jumps: the
# shake. Measured (frame-to-frame diff; evenness = coefficient of variation, lower = smoother):
#     2x  6 % frames frozen, CV 42 %   <- the shake
#     3x  0 % frozen,        CV 26 %
#     4x  0 % frozen,        CV 10 %
#     5x  0 % frozen,        CV  8 %   <- and lowest fine-detail shimmer of the set
# The lever is this input canvas; super-sampling the zoom OUTPUT and downscaling was
# measured to NOT reduce the shake, only the render time. 5x is the practical floor.
KEN_CANVAS = 5


def _cover(label, upscaling=False):
    """Scale a STILL to COVER the canvas (fill, crop the small overflow) instead of fit-and-pad.

    The image model returns 2752x1536 (1.792) and sometimes 2816x1536 (1.833) - never a true 1.778 - so
    fitting one inside the frame leaves a black band, which reads as a fault. Losing 1-3% off the edges
    does not. This is what _kenburns_fit already does; the no-zoom path was the odd one out.
    """
    flags = "bicubic" if upscaling else "lanczos"
    return (f"[{label}]scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase:flags={flags},"
            f"crop={SEQ_W}:{SEQ_H},setsar=1,fps={FPS}")


HOLD_ZOOM_FACTOR = 0.35     # a "hold" still creeps, at about a third of a push - never a frozen frame


def _kenburns_fit(label, dur, move="push", zrate=None):
    """Scale a still onto the oversized Ken-Burns canvas, then zoom at a constant rate.

    A PULL starts at the far end of the same travel and walks back to 1.0, so a zoom out really is a
    zoom out. It used to zoom IN whatever the scene asked for, which is why an episode of mixed moves
    came back as forty pushes. A HOLD creeps at HOLD_ZOOM_FACTOR of that, because a drawn frame with no
    camera on it at all reads as a still photograph dropped into a film.

    COVER the canvas (scale up to fill, crop the small overflow), NOT fit-and-black-pad:
    with pad, zoompan at zoom=1 showed the whole padded frame, so a still that wasn't
    exactly 16:9 opened with black bars top/bottom that "filled in" as the zoom cropped
    inward. increase+crop makes frame 1 already fill the frame; the zoom then starts from
    there identically.

    bicubic, not lanczos, for the enlargement: we scale a ~2K still up past 4K, and lanczos
    rings on enlargement — that ringing crawls as shimmer during the slow zoom (measured
    lower shimmer with bicubic). This also scales once, straight from the source, so no
    2K -> 1080p -> canvas round-trip throws away the detail the image generator gave us.
    """
    kw, kh = SEQ_W * KEN_CANVAS, SEQ_H * KEN_CANVAS
    frames = max(1, int(round(dur * FPS)))
    z = (zoom_pct() if zrate is None else zrate) / 100.0 * (HOLD_ZOOM_FACTOR if move == "hold" else 1.0)
    if move == "pull":
        zexpr = f"{1.0 + z * dur:.5f}-{z:.5f}*on/{FPS}"     # begins wide enough to have somewhere to go
    else:
        zexpr = f"1+{z:.5f}*on/{FPS}"
    return (f"[{label}]scale={kw}:{kh}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={kw}:{kh},setsar=1,fps={FPS},"
            f"zoompan=z='{zexpr}':d={frames}:s={SEQ_W}x{SEQ_H}:fps={FPS}"
            f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'")


def _slow_pre(slow):
    """setpts prefix that stretches a clip to `slow`x its length (slow>1 = slower). Applied FIRST so the
    fps resample fills the extra time and any Ken-Burns `t` ramps over the stretched (final) duration."""
    return f"setpts={slow:.6f}*PTS," if (slow and slow > 1.0001) else ""


def _video_cover(label, slow=1.0):
    """Scale a video clip to COVER the canvas (fill, crop the small overflow) instead of fit-and-pad.
    grok 1.5 delivers 1920x1088; padding would letterbox those 8px, cover crops them so the clip fills
    the 1080 frame edge-to-edge — matching the still + the preview (object-fit:cover). bicubic: clips are
    usually upscaled (720p/1088 -> 1080). `slow`>1 stretches a short clip to fill its scene."""
    return (f"[{label}]{_slow_pre(slow)}scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={SEQ_W}:{SEQ_H},setsar=1,fps={FPS}")


def _video_kenburns(label, slow=1.0, zrate=None):
    """COVER the canvas, then slow-zoom the MOVING clip at the same constant 1.4 %/sec as the stills'
    Ken Burns (locked-camera clips need the motion). Time-based centre crop + rescale; t is the clip's own
    time and starts at 0, so frame 1 is at zoom 1.0 and it grows from there — identical ramp to _kenburns_fit.
    `slow`>1 stretches a short clip to fill its scene (applied before the zoom so the ramp covers the fill)."""
    z = (zoom_pct() if zrate is None else zrate) / 100.0
    # Use zoompan (NOT a time-varying crop): a filter's output size must stay constant, so crop=w='iw/(1+..t)'
    # is invalid — its w/h can't change per frame, which aborted the whole render. zoompan keeps a constant
    # output and slides a shrinking zoom window. THE SHIMMER FIX: zoompan rounds its crop window to WHOLE INPUT
    # pixels each frame, so at output resolution the ~1.4 %/sec creep jumps a full pixel every few frames ->
    # visible shimmer/jitter. Feeding it an OVER-SIZED canvas (2x) makes each jump a half output-pixel -> smooth.
    # (Stills use 5x; video can't afford 25x pixels per frame, but 2x kills most of the shake at 4x the cost.)
    kw, kh = SEQ_W * 2, SEQ_H * 2
    return (f"[{label}]{_slow_pre(slow)}scale={kw}:{kh}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={kw}:{kh},setsar=1,fps={FPS},"
            f"zoompan=z='1+{z:.5f}*on/{FPS}':d=1:s={SEQ_W}x{SEQ_H}:fps={FPS}"
            f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',setsar=1")


def _exact(dur):
    """Bound pictures by frame count, including after an overlay changes timebase.

    Decimal-duration trims retain an extra picture for some framed/portrait
    inputs. Their inherited timestamps then make later cuts drift away from the
    frame-clock used by captions and effect envelopes.
    """
    frames = max(1, round(float(dur) * FPS))
    return (f",tpad=stop_mode=clone:stop={frames},"
            f"trim=end_frame={frames},settb=expr=1/{FPS},setpts=N,format=gbrp")

# per-scene transition key -> ffmpeg xfade transition name (slide render has no blur; the
# preview adds blur via CSS). "none" uses a true hard cut, with no overlap.
XFADE_NAMES = {
    "crossfade": "fade", "dip-black": "fadeblack", "dip-white": "fadewhite",
    "slide-left": "slideleft", "slide-right": "slideright",
    "slide-up": "slideup", "slide-down": "slidedown",
}
TX_SEC = 0.4          # scene-transition length (short; NOT XFADE_SEC, which is the 3s music cross-fade)
# A dip is NOT a cross-dissolve. xfade=fadeblack starts AT the cut and runs into the new scene, so the
# black lands a third of a second after the change and the new shot arrives out of the dark. A dip is a
# hard cut with the picture faded DOWN into the boundary and back UP out of it - black exactly ON the
# cut, half the time in the outgoing shot and half in the incoming one, and no scene's content shifted.
DIP_SEC = 0.7         # total length of a dip-to-black / dip-to-white (half either side of the cut)

# ---------------------------------------------------------------- making a still behave like a shot
# A Ken-Burns zoom scales the whole picture as one flat plane, and the eye reads that as a photograph.
# Two things fix it, and neither touches a video clip (those already carry a real camera):
#   HANDHELD - a slow, sub-pixel-ish float. No photograph ever drifts, so any drift at all says "camera".
#   PARALLAX - a slowly changing PERSPECTIVE. Honest description: this tilts the plane, it does not
#              separate foreground from background - that would need a depth model, which is not
#              installed here. What it buys is the feeling of moving THROUGH the frame rather than
#              zooming into it, which is most of the effect for none of the machinery.
# Both work inside a margin added around the frame, so nothing ever samples past the edge.
CAM_MARGIN = 40       # px of headroom scaled in before the drift, cropped away after
FLOAT_AMP = (2.6, 1.5)          # px, two incommensurate sines so the drift never repeats visibly
FLOAT_HZ = (0.13, 0.31)
PARALLAX_PX = 26.0    # how far the top and bottom edges swing apart, end to end of a shot


def _still_camera(lbl, idx, dur=4.0, floaty=True, parallax=True):
    """Wrap a still's chain in the margin, drift it, and crop back to frame.

    This is the flat stand-in for the depth warp, used when the model or onnxruntime is not there. The
    drift was a 9 px sine at one swing per 18 seconds, sampled at a per-shot phase: a four-second cut
    covered a fifth of a cycle and one that began near the peak hardly moved, so the parallax was
    invisible on exactly the short scenes an episode is made of. It now sweeps the same distance across
    every shot whatever its length, alternating direction so consecutive cuts do not all slide one way.
    """
    if not (floaty or parallax):
        return ""
    ph = (idx * 1.7) % 6.283, (idx * 2.9) % 6.283   # each shot floats its own way
    out = f",scale={SEQ_W + 2 * CAM_MARGIN}:{SEQ_H + 2 * CAM_MARGIN}:flags=bicubic,setsar=1"
    if parallax:
        w, h = SEQ_W + 2 * CAM_MARGIN, SEQ_H + 2 * CAM_MARGIN
        span = max(1.0, float(dur or 4.0) * FPS)
        amp = PARALLAX_PX * (1 if idx % 2 == 0 else -1)
        d = f"({amp:.2f}*(2*on/{span:.1f}-1))"
        out += (f",perspective=eval=frame:sense=destination:"
                f"x0='0-{d}':y0='0':x1='{w}+{d}':y1='0':"
                f"x2='0+{d}':y2='{h}':x3='{w}-{d}':y3='{h}'")
    if floaty:
        a1, a2 = FLOAT_AMP
        f1, f2 = FLOAT_HZ
        x = f"{CAM_MARGIN}+{a1}*sin(2*PI*{f1}*t+{ph[0]:.3f})+{a2}*sin(2*PI*{f2}*t+{ph[1]:.3f})"
        y = f"{CAM_MARGIN}+{a1}*sin(2*PI*{f2}*t+{ph[1]:.3f})+{a2}*sin(2*PI*{f1}*t+{ph[0]:.3f})"
        out += f",crop={SEQ_W}:{SEQ_H}:x='{x}':y='{y}'"
    else:
        out += f",crop={SEQ_W}:{SEQ_H}:{CAM_MARGIN}:{CAM_MARGIN}"
    return out
_DIP_COLOR = {"dip-black": "black", "dip-white": "white"}


# ============================ ON-SCREEN ICON OVERLAYS (render) ============================
# Draw the same X / arrow / check / sparkle / pain-burst + animated video icons the Premiere XML export and the
# preview show. STATIC icons are PIL-composited to a full-frame transparent PNG (recoloured + sized + rotated +
# positioned with the SAME _icon_geom / _ICON_ONSCREEN math as the export, so placement is WYSIWYG) and overlaid
# as a still with a short fade-in over the icon's window. ANIMATED video icons (_VFX: arrows/hands/etc.) are
# overlaid LOOPING (mirrors the XML "loop, never freeze" behaviour). Heavy work is done in render() (where the
# work dir + PIL live) and the resolved specs are wired into the filtergraph by build_graph().
def _icon_still_png(kind, ix, iy, size, rot, flip, hue, workdir, tag, icon_dir):
    """Composite ONE static icon onto a full-frame transparent PNG at (ix,iy). Returns the path, or None."""
    try:
        from PIL import Image
    except Exception:
        return None
    canvas = Image.new("RGBA", (SEQ_W, SEQ_H), (0, 0, 0, 0))

    def _place(base, art, cx, cy):
        aw, ah = art.size
        layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
        layer.paste(art, (int(round(cx - aw / 2)), int(round(cy - ah / 2))))   # Preserve straight alpha; a mask here applies alpha twice and darkens soft edges.
        return Image.alpha_composite(base, layer)

    try:
        if kind == "burst":
            rp = Path(icon_dir) / "icon_ring.png"
            if not rp.exists():
                return None
            rp = _icon_hue_file(rp, hue or 0)
            ring = Image.open(rp).convert("RGBA")
            af, _cx, _cy = _icon_geom(rp)
            base_w = SEQ_W * 0.17 * size                            # widest ring ~17% of the frame
            for scl, al in ((1.0, 235), (0.66, 150), (0.42, 95)):   # a few concentric rings = a static "pain burst"
                wpx = max(6.0, base_w * scl)
                k = wpx / ((af or 0.3) * ring.width)
                r2 = ring.resize((max(1, int(ring.width * k)), max(1, int(ring.height * k))), Image.LANCZOS)
                a = r2.split()[3].point(lambda p: int(p * al / 255))
                r2.putalpha(a)
                canvas = _place(canvas, r2, ix * SEQ_W, iy * SEQ_H)
        else:
            files = {"x": "icon_x.png", "arrow": "icon_arrow.png", "check": "icon_check.png", "sparkle": "icon_sparkle.png"}
            fn = files.get(kind)
            if kind == "arrow" and flip:
                fn = "icon_arrow_flip.png"
            if not fn and re.fullmatch(r"[a-z0-9_]{1,32}", str(kind or "")):
                fn = "icon_%s.png" % kind        # still art that just drops into Icons/ by name (badges)
            if not fn:
                return None
            ip = premiere_export.logo_art_file(kind) if premiere_export.is_logo(kind) else Path(icon_dir) / fn
            if not ip.exists():
                return None
            finished_art = is_badge(kind) or premiere_export.is_logo(kind)
            if not finished_art:                 # keep the supplied logo/background colours
                ip = _icon_hue_file(ip, hue or 0)
            art = Image.open(ip).convert("RGBA")
            if flip and kind != "arrow":
                from PIL import ImageOps
                art=ImageOps.mirror(art)
            af, _cx, _cy = _icon_geom(ip)
            want = SEQ_W * icon_onscreen(kind) * size    # width on screen (art is pre-centred in the PNG)
            # a badge is a 1024-square picture whose preview thumbnail is the whole canvas: the preview (and the
            # XML) show the CANVAS at 18%, so size the canvas; the line icons' thumbnails are cropped to the art
            k = want / ((1.0 if finished_art else (af or 0.2)) * art.width)
            art = art.resize((max(1, int(art.width * k)), max(1, int(art.height * k))), Image.LANCZOS)
            if abs(rot) > 0.5:
                art = art.rotate(-rot, resample=Image.BICUBIC, expand=True)   # PIL rotates CCW+, preview/CSS CW+ -> negate
            canvas = _place(canvas, art, ix * SEQ_W, iy * SEQ_H)
        out = Path(workdir) / f"ico_{tag}.png"
        canvas.save(out)
        return out
    except Exception:
        return None


def _build_icon_specs(scenes, workdir, canvas=None, key_asset=None):
    """Build overlay specs for every scene's on-screen icons (matches the XML export + preview placement).
    Static -> a composited PNG shown as a still; video (_VFX) -> the looping clip. Returns a list of dicts."""
    specs = []
    width, height = canvas or (SEQ_W, SEQ_H)
    try:
        icon_dir = Path(premiere_export.__file__).resolve().parent / "Icons"
    except Exception:
        return specs
    n = 0
    for s in (scenes or []):
        if s.get("kind") not in ("image", "video"):       # icons only over real footage (never on blanks)
            continue
        icons = s.get("icons")
        if not isinstance(icons, list) or not icons:
            continue
        try:
            s0, s1 = float(s["start"]), float(s["end"])
        except Exception:
            continue
        span = s1 - s0
        if span <= 0:
            continue
        ranks=project_canvas.overlay_ranks(s)
        for it in icons:
            before=len(specs)
            if not isinstance(it, dict):
                continue
            kind = (it.get("type") or it.get("icon") or "").strip().lower()
            if not kind:
                continue
            ix = float(it.get("x") if it.get("x") is not None else .5); iy = float(it.get("y") if it.get("y") is not None else .5)
            size = premiere_export.icon_size(it.get("size", 1.0), kind)
            rot = float(it.get("rot", 0) or 0); flip = bool(it.get("flip"))
            hue = premiere_export.icon_colors.choice(it)
            in_f = min(1.0, max(0.0, float(it.get("in", 0) or 0)))
            out_f = min(1.0, max(0.0, float(it.get("out") if it.get("out") is not None else 1.0)))
            # XML authors placement on its native frame grid, including half-frame ties.
            sframe= premiere_export.frame_number(s0,premiere_export.FPS)
            eframe= premiere_export.frame_number(s1,premiere_export.FPS)
            first=sframe+int(round((eframe-sframe)*in_f))
            last=sframe+int(round((eframe-sframe)*out_f)) if out_f<.999 else eframe
            st,en=first/premiere_export.FPS,last/premiere_export.FPS
            if last-first < premiere_export.frame_number(.4,premiere_export.FPS):
                continue
            n += 1
            fade_out = premiere_export.icon_exit_seconds(st, en, s1, kind)
            if kind in _VFX:                               # animated video icon -> loop the clip
                blend, fnm = _VFX[kind]
                mv = icon_dir / fnm
                if not mv.exists():
                    continue
                try:
                    if blend == "key" and kind not in premiere_export._VFX_SCREEN:
                        mv = (key_asset or _movfx_alpha_file)(mv, hue)
                    if blend=='alpha' and premiere_export.icon_colors.normalize(hue) and premiere_export.icon_colors.allowed(kind):
                        mv=premiere_export.icon_colors.video(mv,hue)
                    _vd, vw, vh = ffprobe_media(mv)
                except Exception:
                    continue
                vw = vw or width; vh = vh or height
                scale, mx, my = premiere_export.icon_video_geometry(kind, vw, vh, ix, iy, size, canvas=(width, height), rotation=rot, flip=flip)
                scw = max(2, round(vw * scale / 100)); sch = max(2, round(vh * scale / 100))
                from icon_geometry import bounds
                rw,rh=bounds(scw,sch,rot)
                cx = width / 2 + mx * vw; cy = height / 2 + my * vh
                visible_end=en
                source_frames=premiere_export.frame_number(_vd or 5,premiere_export.FPS)
                if _vfx_mode(kind)!='once' and source_frames:
                    tail=(last-first)%source_frames
                    if 0<tail<premiere_export.frame_number(.2,premiere_export.FPS):visible_end=(last-tail)/premiere_export.FPS
                specs.append({"video": True, "src": str(mv), "w": scw, "h": sch,
                              "rotate":rot,"flip":flip,"rotated_w":rw,"rotated_h":rh,
                              "hold_at":premiere_export._VFX_HOLD.get(kind),
                              "blend":"screen" if kind in premiere_export._VFX_SCREEN else "normal",
                              "fade_in":.15,"source_duration":premiere_export.frame_time(_vd,FPS),
                              "x": int(round(cx - rw / 2)), "y": int(round(cy - rh / 2)),
                              "start": st, "end": visible_end,"window_end":en, "fade_out": fade_out,
                              "loop": _vfx_mode(kind) != "once"})   # "once" -> play then FREEZE last frame (no repeat)
            else:
                import icon_motion
                specs.extend(icon_motion.static_specs(kind,ix,iy,size,rot,flip,hue,st,en,s1,workdir,icon_dir,(width,height),FPS))
            for spec in specs[before:]:spec['overlay_rank']=ranks.get(id(it)) if ranks is not None else None
    return specs


# THE FILM LOOK. Two clips out of Visual Effects/, both plain video on BLACK - no alpha - so they go on
# with a SCREEN blend, where black is a no-op and only the bright specks and grain survive. Dust runs over
# effect1/effect2 scenes; grain only over the shots the effects pass called historical or grim.
#   * strength dims the clip BEFORE the blend, which is exactly an opacity control for screen.
#   * everything happens in RGB (gbrp). blend=screen in YUV screen-blends the chroma planes too and the
#     black padding then tints the whole picture magenta - the same trap the user transitions hit.
_DUST_FILE, _GRAIN_FILE = "dust.mov", "filmgrain.mp4"
# filmgrain.mp4 carries flecks and scratches but no actual grain (99% of every frame is pure black), so
# the grain itself is generated: mid-grey noise blended in OVERLAY mode, where 50% grey is a perfect
# no-op - which is exactly what lets the same stream be padded with grey outside the window and leave
# every frame out there untouched.
_GRAIN_NOISE = 16
# dust.mov is a busy texture whose average sits around 15/255, so half of it is already a real veil.
# filmgrain.mp4 is the opposite - pure black with very sparse bright flecks (99% of every frame is 0) -
# so dimming it at all made it invisible; it goes on at full strength and still reads as scratches.
_DUST_STRENGTH, _GRAIN_STRENGTH = 0.45, 1.0


def _film_clip(name):
    p = Path(__file__).resolve().parent / "Visual Effects" / name   # same folder effect1/effect2 come from
    return p if p.exists() else None


def _grain_windows(timeline):
    """The scene ranges that asked for grain, with touching ones merged - one merged window is one
    filter stage, and a run of grim scenes should not cost five of them."""
    out = []
    for sc in timeline.get("scenes", []):
        if not sc.get("grain"):
            continue
        a, b = float(sc.get("start") or 0), float(sc.get("end") or 0)
        if b - a <= 0.05:
            continue
        if out and a - out[-1][1] < 0.05:
            out[-1][1] = b
        else:
            out.append([a, b])
    return [(round(a, 3), round(b, 3)) for a, b in out]



# ---------------------------------------------------------------- weather in the frame
# Fog, rain, snow and embers, chosen per scene by the same vision pass that picks the grain. Each is a
# TILEABLE plate drawn once with PIL and then scrolled: the plate is one tile stacked twice, so the
# scroll wraps at the seam and never repeats visibly within a shot. All of them are bright-on-black and
# go on with a SCREEN blend, gated to their own scenes by the timeline so nothing leaks into a shot that
# did not ask for weather.
ATMO_KINDS = ("fog", "rain", "snow", "embers")
_ATMO_SPEC = {                       # (scroll px/s, +1 down / -1 up / 0 sideways, strength)
    "fog":    (14.0, 0, 0.30),
    "rain":   (1100.0, 1, 0.38),
    "snow":   (95.0, 1, 0.50),
    "embers": (70.0, -1, 0.55),
}


def _atmo_plate(kind, workdir):
    """One tileable plate per kind, cached in the work dir. Vertical kinds are (W, 2H) - the same tile
    stacked - so a scroll of H lands exactly back where it started. Fog is (2W, H) for the same reason."""
    from PIL import Image
    out = Path(workdir) / f"_atmo_{kind}_{SEQ_W}x{SEQ_H}.png"
    if out.exists():
        return out
    rng = np.random.default_rng({"fog": 11, "rain": 22, "snow": 33, "embers": 44}[kind])
    W, H = SEQ_W, SEQ_H
    if kind == "fog":
        # Fog is a VEIL, not a pattern: two very coarse octaves, blurred hard, then squeezed into a
        # narrow band of brightness. The first attempt used a fine grid and a contrast stretch and came
        # out looking like leopard print - visibly repeating, and far too strong to screen over a shot.
        from PIL import ImageFilter
        acc = np.zeros((H, 2 * W), np.float32)
        for gy, gx, wgt in ((3, 5, 1.0), (5, 9, 0.45)):
            g = rng.random((gy, gx)).astype(np.float32)
            g = np.hstack([g, g])                               # horizontally periodic
            up = Image.fromarray((g * 255).astype(np.uint8)).resize((2 * W, H), Image.BICUBIC)
            up = up.filter(ImageFilter.GaussianBlur(max(2, W // 24)))
            acc += np.asarray(up).astype(np.float32) / 255.0 * wgt
        acc /= 1.45
        acc = (acc - acc.min()) / max(1e-6, acc.max() - acc.min())
        acc = 0.18 + 0.42 * acc                                 # a gentle haze, never opaque
        tile = (acc * 255).astype(np.uint8)
    else:
        tile = np.zeros((H, W), np.float32)
        if kind == "rain":
            for _ in range(1400):
                x, y = rng.integers(0, W), rng.integers(0, H)
                ln, sl = rng.integers(26, 70), rng.uniform(-0.10, 0.02)
                v = rng.uniform(0.35, 1.0)
                for k in range(int(ln)):
                    yy, xx = (y + k) % H, int(x + k * sl) % W
                    tile[yy, xx] = max(tile[yy, xx], v)
        elif kind == "snow":
            for _ in range(700):
                x, y = rng.integers(0, W), rng.integers(0, H)
                r, v = rng.uniform(1.0, 3.4), rng.uniform(0.5, 1.0)
                ri = int(r) + 1
                for dy in range(-ri, ri + 1):
                    for dx in range(-ri, ri + 1):
                        dd = (dx * dx + dy * dy) ** 0.5
                        if dd <= r:
                            yy, xx = (y + dy) % H, (x + dx) % W
                            tile[yy, xx] = max(tile[yy, xx], v * (1.0 - dd / (r + 0.6)))
        else:                                                    # embers
            for _ in range(420):
                x, y = rng.integers(0, W), rng.integers(0, H)
                r, v = rng.uniform(0.8, 2.6), rng.uniform(0.45, 1.0)
                ri = int(r) + 1
                for dy in range(-ri, ri + 1):
                    for dx in range(-ri, ri + 1):
                        dd = (dx * dx + dy * dy) ** 0.5
                        if dd <= r:
                            yy, xx = (y + dy) % H, (x + dx) % W
                            tile[yy, xx] = max(tile[yy, xx], v * (1.0 - dd / (r + 0.6)))
        tile = (np.clip(tile, 0, 1) * 255).astype(np.uint8)
        tile = np.vstack([tile, tile])                           # stacked twice -> the scroll wraps
    im = Image.fromarray(tile, "L").convert("RGB")
    if kind == "embers":                                         # warm, not white
        r, g, b = im.split()
        im = Image.merge("RGB", (r, g.point(lambda v: int(v * 0.62)), b.point(lambda v: int(v * 0.22))))
    elif kind == "fog":
        im = Image.merge("RGB", [c.point(lambda v: int(v * f)) for c, f in zip(im.split(), (0.92, 0.95, 1.0))])
    im.save(out)
    return out


def _atmo_windows(timeline):
    """{kind: [(start, end), ...]} with touching scenes merged - one merged run is one filter stage."""
    out = {}
    for sc in timeline.get("scenes", []):
        k = sc.get("atmo")
        if k not in ATMO_KINDS:
            continue
        a, b = float(sc.get("start") or 0), float(sc.get("end") or 0)
        if b - a <= 0.05:
            continue
        w = out.setdefault(k, [])
        if w and a - w[-1][1] < 0.05:
            w[-1][1] = b
        else:
            w.append([a, b])
    return {k: [(round(a, 3), round(b, 3)) for a, b in v] for k, v in out.items()}

def _join_speaker_segments(segs):
    """Keep adjacent source-contiguous speaker cards on one decoder/FPS clock."""
    out=[]
    for segment in segs:
        current=dict(segment)
        previous=out[-1] if out else None
        a=(previous or {}).get("speaker_clip") or {}
        b=current.get("speaker_clip") or {}
        if (previous and a and b and previous["kind"]==current["kind"]=="video"
                and previous["src"]==current["src"] and a.get("file")==b.get("file")
                and isinstance(a.get("fps"),(int,float)) and a["fps"]>0 and a["fps"]==b.get("fps")
                and isinstance(a.get("source_out_frame"),int) and isinstance(b.get("source_out_frame"),int)
                and a["source_out_frame"]==b.get("source_in_frame") and b["source_out_frame"]>b["source_in_frame"]
                and previous.get("trans")=="none" and previous.get("framing")==current.get("framing")
                and previous.get("no_zoom")==current.get("no_zoom")):
            previous["dur"]+=current["dur"]
            previous["trans"]=current["trans"]
            previous["speaker_clip"]={**a,"source_out_frame":b["source_out_frame"]}
        else:
            out.append(current)
    return out


def _audio_graph(timeline, opts, idx=0):
    """The single continuous master mix, shared by full and cached preview renders."""
    import voice_master
    prepared_vo=voice_master.is_prepared(timeline.get('vo'))
    limiter='alimiter=limit=0.97'+(':level=false' if prepared_vo else '')
    total = float(timeline["total"])
    inputs, graph = [], []
    inputs += ["-i", str(timeline["vo"])]
    vo_idx = idx; idx += 1
    # YouTube plays everything at about -14 LUFS: a quieter master is simply turned up on the way out,
    # so mastering quiet gains nothing and only costs headroom. The voice-over is measured and lifted to
    # sit where it should in the finished mix; the music rides under it at its own fixed level and the
    # limiter after the mix catches the sum.
    vo_gain = 0.0 if prepared_vo else float(opts.get("vo_gain_db") or 0.0)
    gain = f"volume={vo_gain:.2f}dB," if abs(vo_gain) > 0.05 else ""
    graph.append(f"[{vo_idx}:a]aresample=48000,{gain}asetpts=PTS-STARTPTS[avo]")
    alabels = ["[avo]"]
    music_labels=[]

    # music off -> no music streams at all, so the mix below is voice-over only
    music_segs = (timeline.get("music") or []) if opts.get("music", True) else []
    last = len(music_segs) - 1
    for i, seg in enumerate(music_segs):
        if not seg.get("path"):
            continue
        s, e = float(seg["start"]), float(seg["end"])
        span = e - s
        if span <= 0.05:
            continue
        # Every section starts at full level and ends with one linear release.
        # The last section uses the shared four-second closing release, not two
        # multiplied envelopes. XML exports its two endpoints directly.
        placed_start,placed_dur=s,span
        fout=premiere_export.music_fade_out(s,e,total)
        source_start=float(seg.get('source_start') or 0)
        source_frames=premiere_export._f(premiere_export.audio_duration(seg['path']) or 0) if source_start else 0
        usable_frames=source_frames-premiere_export._f(source_start)
        if source_start and 0<usable_frames<premiere_export._f(span):
            # Repeat the audible portion, just like each native XML clip. Seeking
            # once on a stream_loop input only skips silence on its first pass.
            # Independent trimmed inputs avoid buffering an entire long song.
            parts=[];remaining=premiere_export._f(span)
            while remaining>0:
                length=min(usable_frames,remaining)/premiere_export.FPS
                label=f"amloop{i}_{len(parts)}"
                inputs += ['-ss',f'{source_start:.6f}','-i',str(seg['path'])]
                graph.append(f"[{idx}:a]aresample=48000,atrim=duration={length:.6f},asetpts=PTS-STARTPTS,"
                             f"apad=whole_dur={length:.6f},atrim=duration={length:.6f}[{label}]")
                parts.append(f'[{label}]');idx+=1;remaining-=min(usable_frames,remaining)
            graph.append(f"{''.join(parts)}concat=n={len(parts)}:v=0:a=1[amloops{i}]")
            chain=f"[amloops{i}]volume={float(seg.get('level') or 0.15):.4f}"
        else:
            inputs += ['-stream_loop','-1','-i',str(seg['path'])]
            chain=(f"[{idx}:a]aresample=48000,atrim=start={source_start:.6f}:duration={placed_dur:.6f},asetpts=PTS-STARTPTS,"
                   f"volume={float(seg.get('level') or 0.15):.4f}")
            idx+=1
        if fout>0:
            chain+=f",afade=t=out:st={max(0.0,placed_dur-fout):.3f}:d={fout:.3f}"
        delay = int(round(placed_start * 1000))
        chain += f",adelay={delay}|{delay}[am{i}]"
        graph.append(chain)
        music_labels.append(f"[am{i}]")

    # Exact same source, VO anchor and envelope as XML and Assemble. Hits are
    # mixed after the closing voice-over fade so that no master ramp reshapes them.
    hit_labels=[]
    from editorial_policy import delivery_sfx
    for sn,spec in enumerate(delivery_sfx(timeline.get('sfx'),opts) + ((timeline.get('transition_sfx') or []) if opts.get('transitions',True) else [])):
        duration=spec['end']-spec['start']
        inputs += ['-i',str(spec['path'])]
        delay=round(spec['start']*1000)
        chain=(f"[{idx}:a]aresample=48000,atrim=duration={duration:.6f},asetpts=PTS-STARTPTS,"
               f"volume={spec['level']:.4f}")
        if spec['fade_in']>0:chain+=f",afade=t=in:st=0:d={spec['fade_in']:.6f}"
        if spec['fade_out']>0:chain+=f",afade=t=out:st={duration-spec['fade_out']:.6f}:d={spec['fade_out']:.6f}"
        graph.append(chain+f",adelay={delay}|{delay}[ssfx{sn}]")
        (hit_labels if spec.get('kind')=='hit' else alabels).append(f'[ssfx{sn}]'); idx+=1

    if len(alabels) > 1:
        # normalize=0: the VO is already at -16 LUFS and each music segment already carries
        # its measured -33 LUFS gain, so amix must NOT re-level them. alimiter is a safety
        # net against the rare sum overshooting 0 dBFS.
        graph.append(f"{''.join(alabels)}amix=inputs={len(alabels)}:duration=longest:normalize=0,"
                     f"{limiter}[aout]")
    else:
        graph.append(f"[avo]{limiter}[aout]")

    alab = "[aout]"
    outro = float(opts.get("outro_fade") or 0)
    if outro > .05 and total > outro + 1:
        graph.append(f"[aout]afade=t=out:st={total-outro:.3f}:d={outro:.3f}[aoutf]")
        alab = "[aoutf]"
    final_labels=[alab,*hit_labels]
    if music_labels:
        graph.append(f"{''.join(music_labels)}amix=inputs={len(music_labels)}:duration=longest:normalize=0[musicend]")
        final_labels.append('[musicend]')
    if len(final_labels)>1:
        graph.append(f"{''.join(final_labels)}amix=inputs={len(final_labels)}:duration=longest:normalize=0,{limiter}[aend]")
        alab="[aend]"
    return inputs, graph, alab


def build_graph(timeline, opts):
    """Return (ffmpeg input args, filter-graph text, output map labels).

    Scene media become real -i inputs; gaps and blank scenes become in-graph color
    sources (no input slot needed).
    """
    ken = bool(opts.get("kenburns"))
    px_clips = opts.get("parallax_clips") or {}      # scene id -> a still already warped by depth
    cam_float = bool(timeline.get("cam_float"))      # the handheld drift (stills only)
    cam_parallax = bool(timeline.get("parallax"))    # the slow perspective (stills only)
    # Which product is this? The same answer the Premiere export reaches, so a project looks the same
    # whichever way it leaves the app. VSL keeps every setting it has always had.
    yt = bool(timeline.get("youtube"))
    zrate = zoom_pct(yt)
    film_grade = bool(timeline.get("grade"))         # vignette + one colour grade over the whole episode
    kenv = bool(opts.get("kenburns_video"))      # zoom the CLIPS too (off: they already move)
    xfade = XFADE_SEC if opts.get("crossfade", True) else 0.0
    total = float(timeline["total"])

    inputs, graph = [], []
    idx = 0                       # next ffmpeg input index

    # 1) resolve every segment (scene clip, or black for a gap/blank) with its duration and
    #    the transition INTO the next segment (the outgoing scene owns the handoff).
    segs = []                     # each: {"kind","src","dur","trans"}
    cursor = 0.0
    for sc in timeline["scenes"]:
        start, end = _snap(sc["start"]), _snap(sc["end"])   # frame-align so the xfade boundary lands on the same frame as the (also snapped) caption cue
        if round((start - cursor)*FPS) > 0:                 # nothing scheduled here -> black filler (hard cut)
            segs.append({"kind": "black", "src": None, "dur": start - cursor, "trans": "none"})
        dur = end - start
        cursor = end
        if dur <= 0:
            continue
        kind, src = sc.get("kind"), sc.get("path")
        trans = sc.get("transition") or "none"
        if kind == "video" and src:
            media_info=media_delivery.probe(src)
            portrait=media_delivery.automatic_portrait(media_info['width'],media_info['height'],SEQ_W,SEQ_H,sc.get('framing'),bool(sc.get('speaker_clip')))
            segs.append({"kind": "video", "src": src, "dur": dur, "trans": trans, "video_start": sc.get("video_start", 0), "speaker_clip": sc.get("speaker_clip"), "framing": sc.get("framing"), "no_zoom": bool(sc.get("no_zoom")) or sc.get("framing") is not None, "portrait":portrait,"media_info":media_info})
        elif kind == "image" and src:
            segs.append({"kind": "image", "src": src, "dur": dur, "trans": trans,
                         "framing": sc.get("framing"), "no_zoom": bool(sc.get("no_zoom")) or sc.get("framing") is not None, "move": sc.get("move") or "hold",
                         "px": px_clips.get(str(sc.get("id"))), "framed_zoom": bool(sc.get("framed_zoom")), "camera_index": sc.get("_camera_index")})
        else:
            segs.append({"kind": "black", "src": None, "dur": dur, "trans": "none"})
    if round((total - cursor)*FPS) > 0:                      # voice-over runs past the last scene
        segs.append({"kind": "black", "src": None, "dur": total - cursor, "trans": "none"})

    if not segs:
        raise RuntimeError("Nothing to render — no scene has an approved image or video yet.")

    segs = _join_speaker_segments(segs)

    # transitions on only when the user asked AND some non-last segment actually has one
    use_tx = bool(opts.get("transitions", True)) and len(segs) > 1 and \
        any(s["trans"] != "none" for s in segs[:-1])

    # overlap AFTER each segment (into the next). Clamp so a transition never exceeds half of
    # either adjacent clip — otherwise a short scene's xfade would run past the clip and break.
    def _dout(i):
        if not use_tx or i >= len(segs) - 1:
            return 0.0
        # dips and user clips both play over a HARD cut - the dip is drawn afterwards, centred on it
        if segs[i]["trans"] in ("none", "dip-black", "dip-white") or segs[i]["trans"] in _UTX:
            return 0.0
        if segs[i]['trans']=='crossfade':
            current=segs[i];info=current.get('media_info') or {}
            offset=project_canvas.timeline_video_start(current,info.get('duration')) if current['kind']=='video' else 0
            return media_delivery.crossfade_seconds(current['kind'],info.get('duration'),current['dur'],segs[i+1]['dur'],offset,FPS)
        return max(1.0 / FPS, min(TX_SEC, 0.5 * segs[i]["dur"], 0.5 * segs[i + 1]["dur"]))
    douts = [_dout(i) for i in range(len(segs))]

    # user-transition events: (key, cut_time). The clip's hit frame (60 fps, normal speed) is later aligned to the
    # cut; `speed` re-times it so the effective hit lands at hit/speed. Only when transitions are enabled.
    utx_events = []
    if bool(opts.get("transitions", True)) and len(segs) > 1:
        _acc = 0.0
        for i in range(len(segs) - 1):
            _acc += segs[i]["dur"]
            if segs[i]["trans"] in _UTX:
                
                if premiere_export.transition_window(segs[i]["trans"],_acc,total):
                    utx_events.append((segs[i]["trans"], _acc))

    if "_user_transition_events" in timeline:
        utx_events = [(e["key"], e["cut"]) for e in timeline["_user_transition_events"]]
    if opts.get('_live_overlay_base'):
        utx_events = []

    # 2) build each segment; a transitioning clip is extended by its overlap so the total
    #    duration (and every scene start) stays exactly aligned with the audio/captions.
    for i, s in enumerate(segs):
        seglen = s["dur"] + douts[i]
        if s['kind']=='video' and s.get('portrait'):
            vdur=s['media_info']['duration'];offset=project_canvas.timeline_video_start(s,vdur)
            if offset:inputs+=['-ss',f'{offset:.9f}']
            inputs+=['-i',str(s['src'])];remaining=max(0,vdur-offset)
            slow=s['dur']/remaining if remaining and remaining<s['dur']-1/FPS else 1
            graph.append(media_delivery.portrait_graph(f'{idx}:v',f'portrait{i}',SEQ_W,SEQ_H,f'pt{i}',clock=f'setpts=(PTS-STARTPTS)*{slow:.9f},fps={FPS},'))
            graph.append(f'[portrait{i}]format=yuv420p'+_exact(seglen)+f'[v{i}]');idx+=1
        elif s["kind"] in ("video", "image") and project_canvas.clean_framing(s.get("framing")) is not None:
            if s["kind"] == "image":
                inputs += ["-loop", "1", "-framerate", str(FPS), "-t", f"{seglen + .5:.3f}"]
            vdur, mw, mh = ffprobe_media(s["src"])
            offset = project_canvas.timeline_video_start(s,vdur) if s["kind"] == "video" else 0
            if offset: inputs += ["-ss", f"{offset:.9f}"]
            inputs += ["-i", str(s["src"])]
            if vdur: vdur -= offset
            slow = s["dur"] / vdur if not s.get("speaker_clip") and s["kind"] == "video" and vdur and 0 < vdur < s["dur"] - 1/FPS else 1
            frame = project_canvas.clean_framing(s["framing"])
            scale, left, top = project_canvas.frame_geometry(mw, mh, SEQ_W, SEQ_H, frame)
            moving = s["kind"] == "image" and ken and s.get("framed_zoom")
            factor = KEN_CANVAS if moving else 1
            fw, fh = max(2, round(mw*scale*factor)), max(2, round(mh*scale*factor))
            chain=f"[{idx}:v]setpts=(PTS-STARTPTS)*{slow:.9f},fps={FPS},scale={fw}:{fh}:flags=lanczos,setsar=1,format=rgba"
            c=s.get('speaker_clip') or {}
            if c.get('delivery_clock'):
                valid=(c['source_out_frame']-c['source_in_frame'])/c['fps']
                chain += f",trim=duration={valid:.9f},tpad=stop_mode=add:color=black:stop_duration={max(0,seglen-valid)+.1:.9f}"
            graph.append(chain + _exact(seglen) + f"[fr{i}]")
            graph.append(f"color=c=black:s={SEQ_W*factor}x{SEQ_H*factor}:r={FPS}:d={seglen+.1:.5f},format=rgba[fb{i}]")
            chain=f"[fb{i}][fr{i}]overlay=x={left*factor:.6f}:y={top*factor:.6f}:format=rgb:shortest=1,format=yuv420p"
            if moving:
                rate=(zoom_pct() if zrate is None else zrate)/100.0
                chain+=f",zoompan=z='1+{rate:.8f}*on/{FPS}':d=1:s={SEQ_W}x{SEQ_H}:fps={FPS}:x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2'"
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        elif s["kind"] == "video":
            # if the clip is SHORTER than the scene it must fill, slow it to fill exactly (no last-frame
            # freeze). factor = target / clip-length; probed once per clip. clip >= scene -> no slow (1.0).
            vdur = s.get("dur_src")
            if vdur is None:
                d, _w, _h = ffprobe_media(s["src"])
                vdur = d or 0.0
            offset = project_canvas.timeline_video_start(s,vdur)
            if offset: inputs += ["-ss", f"{offset:.9f}"]
            inputs += ["-i", str(s["src"])]
            vdur = max(0, vdur-offset)
            # Match Preview/XML speed over the VO scene. A transition handle is
            # extra tail padding, not extra time to stretch the whole source into.
            slow = (s["dur"] / vdur) if (not s.get("speaker_clip") and vdur and vdur > 0 and vdur < s["dur"] - 1.0 / FPS) else 1.0
            # clips are NOT zoomed by default - the model already moved the camera inside them
            _kv = ken and kenv and not s.get("no_zoom")
            chain = _video_kenburns(f"{idx}:v", slow, zrate) if _kv else _video_cover(f"{idx}:v", slow)
            c=s.get('speaker_clip') or {}
            if c.get('delivery_clock'):
                valid=(c['source_out_frame']-c['source_in_frame'])/c['fps']
                chain += f",trim=duration={valid:.9f},tpad=stop_mode=add:color=black:stop_duration={max(0,seglen-valid)+.1:.9f}"
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        elif s["kind"] == "image" and s.get("px"):
            # the depth warp already baked in the zoom OR the handheld and the parallax - all in one
            # resample. Nothing else may touch this clip's framing.
            inputs += ["-i", str(s["px"])]
            graph.append(_video_cover(f"{idx}:v", 1.0) + _exact(seglen) + f"[v{i}]")
            idx += 1
        elif s["kind"] == "image":
            inputs += ["-loop", "1", "-framerate", str(FPS), "-t", f"{seglen + 0.5:.3f}", "-i", str(s["src"])]
            # COVER, not contain: the image model returns 1.79-1.83 rather than a true 1.778, and a
            # black band across the top reads as a fault while a 2% crop is invisible.
            # No depth clip for this one (the model is missing, or parallax is off). Fall back to the
            # flat path - and still honour the ONE-move rule: a push or a pull zooms and does not float,
            # a hold floats and does not zoom.
            mv = s.get("move") or "hold"
            # EVERY still moves. A hold used to get no zoom at all and only the (invisible) drift, which
            # is why whole stretches of an episode came back looking like photographs.
            zoom_it = ken and not s.get("no_zoom")
            chain = _kenburns_fit(f"{idx}:v", seglen, mv, zrate) if zoom_it else _cover(f"{idx}:v")
            if not s.get("no_zoom"):
                chain += _still_camera(f"v{i}", s["camera_index"] if s.get("camera_index") is not None else i, seglen, floaty=cam_float, parallax=cam_parallax)
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        else:
            graph.append(f"color=c=black:s={SEQ_W}x{SEQ_H}:r={FPS}:d={seglen:.5f},setsar=1[v{i}]")

    # 3) join: a plain concat when there are no transitions, else an xfade chain. Each xfade
    #    starts at the (original) scene boundary; the outgoing clip's extension covers the overlap.
    slide_windows = []                             # (start_t, dur, transition) → motion-blur the slide
    dip_cuts = []                                  # (cut_time, colour) → the dip is drawn after the concat
    if not use_tx:
        graph.append(f"{''.join(f'[v{i}]' for i in range(len(segs)))}concat=n={len(segs)}:v=1:a=0,settb=1/{FPS},setpts=N[vcat]")
    else:
        acc, cum = "v0", segs[0]["dur"]            # cum = start time of the next segment
        for i in range(1, len(segs)):
            trans = segs[i - 1]["trans"]
            if trans in _DIP_COLOR:
                dip_cuts.append((cum, _DIP_COLOR[trans]))
            D = douts[i - 1]                        # same overlap the outgoing clip was extended by
            # a dip is drawn afterwards, so here it is a plain hard cut - leaving it as "fadeblack" put a
            # single black-ish frame on the boundary, which is the very flash we are trying to avoid
            name = "fade" if trans in _DIP_COLOR else XFADE_NAMES.get(trans, "fade")
            out = "vcat" if i == len(segs) - 1 else f"xf{i}"
            if D <= 0:
                # A one-frame xfade still emits the outgoing image at the cut.
                # Concatenate hard cuts even when another scene has a transition.
                # Restore the frame timebase for a possible following xfade.
                graph.append(f"[{acc}][v{i}]concat=n=2:v=1:a=0,settb=1/{FPS},setpts=N[{out}]")
            else:
                graph.append(f"[{acc}][v{i}]xfade=transition={name}:duration={D:.5f}:offset={cum:.5f}[{out}]")
            if trans.startswith("slide-"):
                slide_windows.append((cum, D, trans))
            acc = out
            cum += segs[i]["dur"]
    # Motion blur on slides, matching the preview's blurred push. A single box blur looks blocky/"cheap",
    # so we run TWO smaller box passes (≈ a smooth gaussian) along the slide axis only, gated to each
    # slide's time window. One filter chain per direction keeps a video with many slides light.
    # Pin the base conversion: an xfade in a different scene must not change
    # chroma negotiation for this scene or its independently cached preview.
    graph.append("[vcat]format=yuv420p[vbase]")
    vsrc = "vbase"
    # the dips: fade down over the half-second before the boundary, black ON it, back up after. Every
    # scene keeps its own start time - nothing is shifted, so the pictures stay with their voice-over.
    # ONE grade over the whole episode, and a vignette. This is not about looking cinematic - it is about
    # coherence: images that came out of the model at different times drift in palette, and a single pass
    # makes them read as one production. It sits UNDER the captions on purpose, so the white text is not
    # tinted and the vignette does not darken the corners of the subtitle plate.
    if film_grade:
        # The look was tuned for a YOUTUBE episode and stays there. Measured over twelve of its frames,
        # the pictures came out of the model FLAT rather than harsh: black point 24 (no real black
        # anywhere), white stopping at 243, saturation 44/255. The curve pulls the toe down and the
        # shoulder up for a true black and a clean white without crushing (0.3% of the frame at or below
        # 2, the same as the source): black 24 -> 12, saturation 44 -> 64. The vignette was measured on a
        # white frame as corner brightness against the centre - PI/14 = 90% (invisible), PI/9 = 76%
        # (still unnoticed on moving footage), PI/7 = 64% (where it reads), PI/5 = 39% (a heavy frame).
        # A VSL keeps the gentler grade it has always had - see the note on the zoom constants.
        if yt:
            graph.append(f"[{vsrc}]curves=all='0/0 0.10/0.035 0.5/0.505 0.90/0.955 1/1',"
                         "eq=saturation=1.18,"
                         "colorbalance=rs=-0.028:bs=0.048:rh=0.040:bh=-0.032,"
                         "vignette=a=PI/7:eval=init:dither=0[vgrade]")
        else:
            graph.append(f"[{vsrc}]eq=contrast=1.05:saturation=1.04:gamma=0.99,"
                         "colorbalance=rs=-0.015:bs=0.030:rh=0.025:bh=-0.020,"
                         "vignette=a=PI/14:eval=init:dither=0[vgrade]")
        vsrc = "vgrade"
    # Weather, under the captions so the text is never behind rain. Each kind is ONE looping plate,
    # scrolled by a wrapping crop, screened over just the scenes that asked for it. The whole block runs
    # in RGB: screen in YUV blends the chroma planes too and tints the picture.
    if slide_windows:
        rad = max(2, round(SEQ_W / 150))           # per-pass radius (~13 at 1080p, ~9 at 720p)
        groups = ((True,  [w for w in slide_windows if w[2] in ("slide-left", "slide-right")]),
                  (False, [w for w in slide_windows if w[2] in ("slide-up", "slide-down")]))
        k = 0
        for horiz, group in groups:
            if not group:
                continue
            conds = "+".join(f"between(t,{c0:.5f},{c0 + d:.5f})" for (c0, d, tr) in group)
            sx, sy = (rad, 1) if horiz else (1, rad)
            for _ in range(2):                     # two passes → smooth (gaussian-like), not boxy
                nxt = f"vb{k}"; k += 1
                graph.append(f"[{vsrc}]avgblur=sizeX={sx}:sizeY={sy}:enable='{conds}'[{nxt}]")
                vsrc = nxt
    for vn,spec in enumerate(timeline.get('visuals') or []):
        st,en=spec['start'],spec['end'];placed=max(0.,st);dur=min(total,en)-placed
        phase=max(0.,-st)*float(spec['speed'])
        if phase:
            natural=ffprobe_media(spec['path'])[0] or 0
            if natural:phase%=natural
        # Decode only a short source preroll, preserving the original sub-frame
        # phase through FPS conversion (important for 25/30 fps effect assets).
        seek=max(0.,phase-1.)
        inputs += ['-stream_loop','-1'] + (['-ss',f'{seek:.9f}'] if seek else []) + ['-i',str(spec['path'])]
        vi=idx;idx+=1
        has_fade=bool(spec.get('fade_in') or spec.get('fade_out'))
        graph.append(f"[{vsrc}]format=gbrp"+(f",split=2[vsoriginal{vn}][vsbase{vn}]" if has_fade else f"[vsbase{vn}]"))
        clock=(f"setpts=(PTS-{phase-seek:.9f}/TB)/{spec['speed']:.6f},fps={FPS},trim=start=0," if phase else
               f"setpts=(PTS-STARTPTS)/{spec['speed']:.6f},fps={FPS},")
        graph.append(f"[{vi}:v]{clock}"
                     f"scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase,crop={SEQ_W}:{SEQ_H},setsar=1,"
                     f"trim=duration={dur:.5f},setpts=PTS-STARTPTS,format=gbrp,"
                     f"tpad=start_duration={placed:.9f}:start_mode=clone:stop_duration={max(.1,total-en+.5):.9f}:stop_mode=clone[vsp{vn}]")
        mode='normal' if spec['blend']=='normal' else spec['blend']
        graph.append(f"[vsbase{vn}][vsp{vn}]blend=all_mode={mode}:all_opacity={spec['level']:.5f}:"
                     f"enable='gte(t,{st:.5f})*lt(t,{en:.5f})',format=gbrp[vscene{vn}]")
        vsrc=f'vscene{vn}'
        if has_fade:
            import effect_timing
            alpha=effect_timing.fade_expression(spec)
            graph.append(f"[vsoriginal{vn}][{vsrc}]blend=all_expr='A*(1-({alpha}))+B*({alpha})'[vsfade{vn}]")
            vsrc=f'vsfade{vn}'

    # Plate alpha is a shared OST-relative envelope, never a whole-scene dim.
    for pn,plate in enumerate((timeline.get('ost_plates') or []) if opts.get('onscreentext',True) and not opts.get('_live_overlay_base') else []):
        st,en=plate['start'],plate['end'];dur=en-st
        fades=''
        if plate['fade_in']: fades+=f"fade=t=in:st=0:d={plate['fade_in']:.6f}:alpha=1,"
        if plate['fade_out']: fades+=f"fade=t=out:st={dur-plate['fade_out']:.6f}:d={plate['fade_out']:.6f}:alpha=1,"
        if st<0:
            # A plate spanning a cache boundary keeps its original linear
            # envelope without generating all its preceding full-frame pixels.
            import effect_timing
            alpha=effect_timing.fade_expression(plate)
            graph.append(f"color=c=black:s={SEQ_W}x{SEQ_H}:r={FPS}:d={min(total,en):.9f},format=rgba,"
                         f"geq=r=0:g=0:b=0:a='255*{plate['level']}*({alpha})',settb=expr=1/{FPS},setpts=N[plate{pn}]")
        else:
            graph.append(f"color=c=black@{plate['level']}:s={SEQ_W}x{SEQ_H}:r={FPS}:d={dur:.6f},format=rgba,"
                         f"{fades}settb=expr=1/{FPS},setpts=PTS-STARTPTS+{round(st*FPS)}[plate{pn}]")
        graph.append(f"[{vsrc}][plate{pn}]overlay=format=rgb:eof_action=pass:enable='gte(t,{st:.6f})*lt(t,{en:.6f})'[vplate{pn}]")
        vsrc=f'vplate{pn}'

    # On-screen ICON overlays — wired UNDER the caption/OST layer so the text always sits on top (matches the
    # XML track order: icons below, text above). render() pre-built the specs (PIL stills + resolved video clips)
    # into opts["icon_specs"]. Static icons fade in; animated video icons loop to the icon's window end.
    def paint_icon(spec,vsrc):
        nonlocal inputs,idx
        src = spec["src"]; st = float(spec["start"]); en = float(spec["end"]); dur = max(0.1, en - st)
        icon_start= premiere_export.frame_number(st,FPS)
        icon_end= premiere_export.frame_number(en,FPS)
        fade_out = float(spec.get("fade_out") or 0)
        fade_origin=float(spec.get('window_end',en))-st-fade_out
        exit_fade = f"fade=t=out:st={max(0,fade_origin):.10f}:d={fade_out:.10f}:alpha=1," if fade_out else ""
        vloop = spec.get("loop", True)                         # "once" icons (chkg/xv*/cancel/warn/ques) don't repeat
        if spec.get("video"):
            if vloop:
                inputs += ["-stream_loop", "-1", "-t", f"{dur:.4f}", "-i", src]
            else:
                inputs += ["-i", src]                          # play ONCE; tpad below freezes the last frame for the rest
        else:
            inputs += ["-loop", "1", "-t", f"{dur:.4f}", "-i", src]
        ci = idx; idx += 1
        if spec.get("video"):
            _hold = "" if vloop else f"tpad=stop_mode=clone:stop_duration={dur:.4f},"   # freeze last frame to fill the window
            # Freeze the same populated source frame as the preview/XML, before its baked outro/repeat.
            cutoff=f"trim=end_frame={round(float(spec['hold_at'])*FPS)+1}," if not vloop and spec.get('hold_at') is not None else ""
            reflect="hflip," if spec.get('flip') else ""
            rotate=f"rotate={math.radians(spec['rotate']):.12f}:ow={spec['rotated_w']}:oh={spec['rotated_h']}:c=none," if spec.get('rotate') else ""
            # XML fades each native-speed movie tile in, while a once/hold icon only enters once.
            entrance=''
            if spec.get('fade_in'):
                phase=f"mod(T,{spec['source_duration']:.10f})" if vloop and spec.get('source_duration') else 'T'
                entrance=f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*min(1,({phase})/{spec['fade_in']:.10f})',"
            graph.append(f"[{ci}:v]fps={FPS},format=rgba,{cutoff}scale={spec['w']}:{spec['h']},{reflect}{rotate}{_hold}{entrance}{exit_fade}"
                         f"settb=1/{FPS},setpts=N+{icon_start}[ico{ci}]")
            oxy = f"x={spec['x']}:y={spec['y']}"
        elif spec.get('motion'):
            import icon_motion
            chain,x,y=icon_motion.filters(spec,(SEQ_W,SEQ_H),FPS)
            graph.append(f"[{ci}:v]{chain}settb=1/{FPS},setpts=N+{icon_start}[ico{ci}]")
            oxy=f"x='{x}':y='{y}'"
        else:
            graph.append(f"[{ci}:v]fps={FPS},format=rgba,fade=t=in:st=0:d=0.18:alpha=1,{exit_fade}"
                         f"settb=1/{FPS},setpts=N+{icon_start}[ico{ci}]")
            oxy = "x=0:y=0"                                     # static PNG is full-frame, icon already at its place
        nxt = f"ivc{ci}"
        if spec.get('blend',spec.get('motion',{}).get('blend'))=='screen':
            graph.append(f"color=c=black:s={SEQ_W}x{SEQ_H}:r={FPS}:d={total:.10f}[icoblack{ci}]")
            graph.append(f"[icoblack{ci}][ico{ci}]overlay={oxy}:format=rgb:eof_action=pass:enable='gte(round(t*{FPS}),{icon_start})*lt(round(t*{FPS}),{icon_end})',format=gbrp[icoplane{ci}]")
            graph.append(f"[{vsrc}]format=gbrp[icobase{ci}]")
            graph.append(f"[icobase{ci}][icoplane{ci}]blend=all_mode=screen:shortest=1[{nxt}]")
        else:
            graph.append(f"[{vsrc}][ico{ci}]overlay={oxy}:format=rgb:eof_action=pass:enable='gte(round(t*{FPS}),{icon_start})*lt(round(t*{FPS}),{icon_end})'[{nxt}]")
        vsrc = nxt

        return vsrc
    for spec in ([] if opts.get('_live_overlay_base') else (opts.get('icon_specs') or [])):
        if spec.get('overlay_rank') is None:vsrc=paint_icon(spec,vsrc)

    graph.append(f"[{vsrc}]null[vcap]")

    # USER transition clips: place each over its cut with the HIT frame aligned. speed re-times it (setpts), blend
    # is NORMAL (alpha overlay — the clip carries alpha) or SCREEN (black-pad to full length + blend=screen).
    # ALL of this runs in RGB (gbrp): blend=screen in YUV screen-blends the CHROMA planes too, and the full-length
    # black padding then shifts every frame's colour -> a magenta cast over the whole video. In RGB, black is a
    # true screen no-op, so outside the short transition window the picture is untouched.
    speaker_gate='*'.join(f"not(gte(t,{s['start']:.8f})*lt(t,{s['end']:.8f}))" for s in timeline['scenes'] if s.get('speaker_clip')) or '1'
    if utx_events:
        graph.append("[vcap]format=gbrp[vrgb]")
        cur = "vrgb"
        for n, (key, cut_t) in enumerate(utx_events):
            spec = _UTX[key]
            fn = _UTX_DIR / spec["file"]
            if not fn.exists():
                continue
            vdur, _vw, _vh = ffprobe_media(fn)
            if not vdur:
                continue
            sp = spec["speed"]
            placed = vdur / sp                              # placed duration (s) after the speed change
            s0 = max(0.0, cut_t - spec["hit"] / 60.0)       # hit measured on the final (sped) clip, 60 fps timebase
            inputs += ["-i", str(fn)]
            ti = idx; idx += 1
            spd = f"setpts=PTS/{sp:.5f}," if abs(sp - 1.0) > 1e-3 else ""
            if spec["blend"] == "screen":
                pad_end = max(0.1, total - s0 - placed + 0.5)
                graph.append(f"[{ti}:v]{spd}fps={FPS},scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase,crop={SEQ_W}:{SEQ_H},setsar=1,format=gbrp,"
                             f"tpad=start_duration={s0:.4f}:start_mode=add:color=black:"
                             f"stop_duration={pad_end:.4f}:stop_mode=add:color=black[utf{n}]")
                nxt = f"uv{n}"
                # ,format=gbrp AFTER the blend keeps the chain in RGB: with several transitions, overlay (below)
                # outputs yuv420 by default, and the NEXT screen-blend in YUV would shift chroma -> magenta.
                graph.append(f"[{cur}][utf{n}]blend=all_mode=screen:shortest=1:enable='{speaker_gate}',format=gbrp[{nxt}]")
            else:                                           # NORMAL: alpha overlay (keep the clip's alpha channel)
                end = s0 + placed
                graph.append(f"[{ti}:v]{spd}fps={FPS},scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase,crop={SEQ_W}:{SEQ_H},setsar=1,format=gbrap,"
                             f"setpts=PTS-STARTPTS+{s0:.4f}/TB[utf{n}]")
                nxt = f"uv{n}"
                graph.append(f"[{cur}][utf{n}]overlay=format=rgb:eof_action=pass:enable='between(t,{s0:.4f},{end:.4f})*({speaker_gate})',format=gbrp[{nxt}]")
            cur = nxt
        graph.append(f"[{cur}]format=gbrp[vfx0]")
    else:
        graph.append("[vcap]format=gbrp[vfx0]")

    # ---- finish the scene-scoped visual composite ----
    fcur, fn = "vfx0", 0
    graph.append(f"[{fcur}]format=yuv420p[vout]")

    # Video chunks never open embedded/source audio. Their one continuous master
    # is rendered separately through the exact same mix graph as a full render.
    alab = None
    if not opts.get("_video_only"):
        audio_inputs, audio_filters, alab = _audio_graph(timeline, opts, idx)
        inputs += audio_inputs
        graph += audio_filters
        idx += audio_inputs.count("-i")
    vlab = "[vout]"
    outro = float(opts.get("outro_fade") or 0)
    full_total = float(timeline.get("_full_total", total))
    origin = float(timeline.get("_timeline_origin", 0))
    if outro > .05 and full_total > outro + 1 and not opts.get('_live_overlay_base'):
        st = full_total - outro - origin
        graph.append(f"[vout]fade=t=out:st={st:.9f}:d={outro:.9f}[voutf]")
        vlab = "[voutf]"
    vsrc=vlab[1:-1]
    # Caption / on-screen-text layer. Preferred: overlay the browser-rendered clips (pixel-identical to
    # the preview) each at its own [start,end] window — the clips are 1920x1080 transparent + positioned,
    # so they blend straight onto the picture (scaled to the output size for the 720p test render).
    caption_clips = [] if opts.get('_live_overlay_base') else (opts.get("caption_clips") or [])
    has_ost = bool(opts.get("onscreentext", True)) and any(
        (ov.get("text") or "").strip() for s in timeline["scenes"] for ov in (s.get("texts") or []))
    sx = SEQ_W / project_canvas.size()[0]
    def paint_text(clip,cur):
        nonlocal inputs,idx
        mov,cstart,cend,cx,cy=clip
        inputs += ["-i", str(mov)]
        ci = idx; idx += 1
        if (SEQ_W, SEQ_H) == project_canvas.size():
            pre, ox, oy = "", int(cx), int(cy)
        else:
            pre = f"scale=iw*{sx:.6f}:ih*{sx:.6f},"
            ox, oy = int(round(cx * sx)), int(round(cy * sx))
        sf,ef=premiere_export.frame_number(cstart,FPS),premiere_export.frame_number(cend,FPS)
        graph.append(f"[{ci}:v]{pre}settb=expr=1/{FPS},setpts=PTS-STARTPTS+{sf}[cc{ci}]")
        nxt = f"cv{ci}"
        graph.append(f"[{cur}][cc{ci}]overlay=x={ox}:y={oy}:format=rgb:eof_action=pass:"
                     f"enable='gte(n,{sf})*lt(n,{ef})'[{nxt}]")
        cur = nxt

        return cur
    ordered=[] if opts.get('_live_overlay_base') else (
        [(v['overlay_rank'],'icon',v) for v in opts.get('icon_specs',[]) if v.get('overlay_rank') is not None]+
        [(rank,'text',clip) for rank,clip in opts.get('ordered_text_clips',[])])
    for rank,kind,value in sorted(ordered,key=lambda v:v[0]):
        vsrc=paint_icon(value,vsrc) if kind=='icon' else paint_text(value,vsrc)
    if caption_clips:
        cur = vsrc
        sx = SEQ_W / project_canvas.size()[0]                        # clips are authored at 1920x1080; scale crop + position for 720p test
        for clip in caption_clips:cur=paint_text(clip,cur)
        if opts.get("ass_captions_with_browser"):
            graph.append(f"[{cur}]ass=subs.ass:fontsdir=fonts[basecaps]")
            cur="basecaps"
        graph.append(f"[{cur}]null[topcaps]")
    elif not opts.get('_live_overlay_base') and (opts.get("ass_captions_with_browser") or (not opts.get("ordered_text_clips") and (opts.get("burnsubs", True) or has_ost))):
        # libass fallback (no browser present). relative filename — ffmpeg runs with cwd = the work dir.
        graph.append(f"[{vsrc}]ass=subs.ass:fontsdir=fonts[topcaps]")
    else:
        graph.append(f"[{vsrc}]null[topcaps]")            # clean render, no captions, no overlay text

    # White fades otherwise promote only some graphs to RGB. Keep the same
    # final color conversion even when this neighborhood contains no dip.
    graph.append("[topcaps]format=gbrp[finalrgb]")
    vlab="[finalrgb]"
    if opts.get('transitions',True) and not opts.get('_live_overlay_base'):
        cur='finalrgb'
        for n,event in enumerate(timeline.get('_dip_windows', premiere_export.dip_windows(timeline['scenes'],total))):
            a,p,b=(event[k] for k in ('start','peak','end'));h=event.get('hold_until',p);col=event['color'];filters=[]
            if p>a:
                filters.append(f"fade=t=out:st={a:.8f}:d={p-a:.8f}:color={col}:enable='gte(t,{a:.8f})*lte(t,{p:.8f})'")
            if h>p:
                filters.append(f"drawbox=x=0:y=0:w=iw:h=ih:color={col}:t=fill:enable='gte(t,{p:.8f})*lt(t,{h:.8f})'")
            if b>h:
                filters.append(f"fade=t=in:st={h:.8f}:d={b-h:.8f}:color={col}:enable='gte(t,{h:.8f})*lt(t,{b:.8f})'")
            nxt=f'finaldip{n}';graph.append(f"[{cur}]"+','.join(filters)+f'[{nxt}]');cur=nxt
        vlab=f'[{cur}]' 
    # Avoid truncated right-edge pixels in automatic YUV -> planar RGB conversions
    # at non-aligned widths (including the 1080-wide portrait/square canvases).
    return inputs, "sws_flags=accurate_rnd+bitexact;\n" + ";\n".join(graph), (vlab, alab)


VO_TARGET_LUFS = -15.5     # where the narration sits so the finished programme lands near YouTube's -14


def _measure_lufs(path):
    """Integrated loudness of an audio file, or None if it cannot be read."""
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
                            "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                           capture_output=True, text=True, timeout=180, creationflags=_NO_WINDOW)
        hits = re.findall(r"I:\s*(-?[\d.]+)\s*LUFS", r.stderr)
        return float(hits[-1]) if hits else None
    except Exception:
        return None


@project_canvas.job("timeline")
def render(timeline, out_path, workdir, opts=None, progress=None, on_proc=None, on_status=None, should_cancel=None):
    """Render the timeline to out_path. `progress(pct, seconds_done)` is called as it runs.
    `on_proc(popen)` is called once with the ffmpeg process so the caller can cancel it.
    `on_status(text)` (optional) reports the current phase label (e.g. "Preparing captions…").
    `should_cancel()` (optional) — checked during the caption-prep phase so Stop works before ffmpeg starts.

    Returns the output Path. Raises RuntimeError with ffmpeg's tail on failure.
    """
    opts = dict(opts or {})
    import voice_master
    if voice_master.is_prepared(timeline.get('vo')):
        opts['vo_gain_db']=0.0
    if opts.get('_live_overlay_base'):
        opts.update(burnsubs=False, onscreentext=False)
    if opts.get("_audio_only"):
        return render_audio(timeline, out_path, workdir, opts, progress, on_proc, on_status, should_cancel)
    # Where the narration should sit. Measured once here rather than guessed: a voice-over that came in
    # quiet used to stay quiet all the way to YouTube, which then turns the whole video up and brings the
    # noise floor with it. Only ever a correction of a few dB - if the measurement fails, nothing moves.
    if "vo_gain_db" not in opts and not opts.get("_video_only"):
        _vo = (timeline.get("voiceover") or timeline.get("vo") or {})
        _vp = _vo.get("path") if isinstance(_vo, dict) else _vo
        if _vp and Path(_vp).exists():
            _lu = _measure_lufs(_vp)
            if _lu is not None and -40 < _lu < 0:
                opts["vo_gain_db"] = max(-6.0, min(9.0, VO_TARGET_LUFS - _lu))
    # Fast "test render": drop to 720p30 + x264 ultrafast + higher CRF for a quick sync/timing check.
    # These are module-level constants the filter builders read by name, so override them only while we
    # build the graph/subs/command, then restore (the ffmpeg subprocess itself uses the already-built cmd).
    global FPS, SEQ_W, SEQ_H, PRESET, CRF
    while not _RENDER_PREP_LOCK.acquire(timeout=0.1):
        if should_cancel and should_cancel():
            raise RuntimeError("cancelled")
    _saved = (FPS, SEQ_W, SEQ_H, PRESET, CRF)
    native_w, native_h = project_canvas.dimensions(timeline)
    SEQ_W, SEQ_H = project_canvas.dimensions(timeline, bool(opts.get("fast") or opts.get("final_preview")))
    if opts.get("final_preview"):
        FPS, PRESET, CRF = (30 if opts.get("preview_fps") == 30 else 60), "ultrafast", "22"
    if opts.get("fast"):
        FPS, PRESET, CRF = 30, "ultrafast", "28"
    try:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Bundle the on-screen-text fonts into the work dir so libass can find them — most of the
        # chosen fonts (Montserrat, Poppins, Flatshoes, …) are NOT installed system-wide. A relative
        # fontsdir=fonts (cwd is the work dir) sidesteps Windows filter-path escaping.
        try:
            _fsrc = Path(__file__).parent / "static" / "fonts"
            if _fsrc.is_dir():
                _fdst = workdir / "fonts"; _fdst.mkdir(exist_ok=True)
                for _f in _fsrc.iterdir():
                    if _f.suffix.lower() in (".ttf", ".otf"):
                        shutil.copy2(_f, _fdst / _f.name)
        except Exception as _qe:
            quiet(_qe, "render")

        # captions only when "Burn Subtitles" is on; on-screen text overlays only when "On-screen Text" is on
        caps = (timeline.get("captions") or []) if opts.get("burnsubs", True) else []
        scenes_for_ass = timeline.get("scenes") or []
        if not opts.get("onscreentext", True):
            scenes_for_ass = [{**s, "texts": []} for s in scenes_for_ass]   # drop overlays so they don't burn

        # Preferred path: render captions + on-screen text through the SAME engine as the preview
        # (headless browser) so the burned-in text is pixel-identical — font weight, line spacing and the
        # text-hugging box all match. Falls back to libass (build_ass) when no browser is present.
        caption_clips = []; ordered_text_clips=[]
        has_order=any(project_canvas.overlay_ranks(sc) is not None for sc in scenes_for_ass)
        if has_order and caption_layer is None:raise RuntimeError("Overlay ordering requires the caption renderer.")
        if caption_layer is None and any(o.get("text_runs") for sc in scenes_for_ass for o in sc.get("texts",[])):
            raise RuntimeError("Styled on-screen text requires the caption renderer. Restart or update the app and retry.")
        if caption_layer is not None and not opts.get('_live_overlay_base'):
            try:
                _items = _browser_items(timeline.get("captions") or [], scenes_for_ass,
                                        timeline.get("sub_style"), opts)
                if _items:
                    if on_status:
                        on_status("Preparing captions…")
                    def _cap_prog(done, tot):
                        if on_status:
                            on_status(f"Preparing captions… {done}/{tot}")
                    groups={}
                    for item in _items:groups.setdefault(item.get('overlay_rank'),[]).append(item)
                    done=0
                    for rank,group in groups.items():
                        clips=caption_layer.build_clips(group,workdir,FPS,native_w,native_h,
                            lambda n,tot:_cap_prog(done+n,len(_items)),should_cancel) or []
                        if rank is not None and not clips:raise RuntimeError("Ordered text could not be rendered.")
                        if rank is None:caption_clips.extend(clips)
                        else:ordered_text_clips.extend((rank,clip) for clip in clips)
                        done+=len(group)
            except Exception:
                if has_order or any(o.get("text_runs") for sc in scenes_for_ass for o in sc.get("texts",[])) or (opts.get("burnsubs", True) and caption_layer.motion_enabled(timeline.get("sub_style"))):
                    raise
                caption_clips = []
        if should_cancel and should_cancel():          # Stop pressed during caption prep → bail before ffmpeg
            raise RuntimeError("cancelled")
        # ffmpeg runs with cwd=workdir → pass caption clips as RELATIVE paths so hundreds of "-i" args
        # don't blow past Windows' ~32K command-line limit (WinError 206 on a full VSL's ~220 captions).
        _wd = Path(workdir)
        caption_clips = [(Path(os.path.relpath(m, _wd)).as_posix(), s, e, x, y)
                         for (m, s, e, x, y) in caption_clips]
        ordered_text_clips=[(rank,(Path(os.path.relpath(m,_wd)).as_posix(),a,b,x,y)) for rank,(m,a,b,x,y) in ordered_text_clips]
        ass_captions_with_browser = bool((caption_clips or ordered_text_clips) and caps and not timeline.get("sub_style"))
        opts = {**opts, "ordered_text_clips":ordered_text_clips, "caption_clips": caption_clips, "ass_captions_with_browser": ass_captions_with_browser}
        # On-screen icons -> transparent overlay clips (PIL stills + looping video icons), built here where the
        # work dir + PIL live; build_graph() wires them under the caption layer. Never fatal — icons are cosmetic.
        try:
            opts = {**opts, "icon_specs": [] if opts.get('_live_overlay_base') else _build_icon_specs(timeline.get("scenes") or [], workdir)}
        except Exception:
            opts = {**opts, "icon_specs": []}
        # Depth-warped stills. Each one is a short clip with the camera already baked in, cached on a
        # hash of the picture + duration + move, so a re-render only rebuilds what changed. Never fatal:
        # with no model or no OpenCV the flat Ken-Burns path takes over.
        try:
            if timeline.get("parallax") and parallax is not None and parallax.runnable():
                if not parallax.have_model():
                    # first run on this machine: fetch the depth model once, with the render's own
                    # status bar as the progress bar. If it cannot be had, the flat path takes over.
                    if on_status:
                        on_status("Downloading the depth model (99 MB, once)…")
                    parallax.ensure_model(
                        progress=(lambda p: on_status("Downloading the depth model…" + (f" {p}%" if p is not None else ""))) if on_status else None)
            if timeline.get("parallax") and parallax is not None and parallax.available():
                # Only the stills the render will actually show. A partial render used to warp every
                # still in the episode - the longest step in the job, spent on frames it then discarded.
                _rng = opts.get("range")
                _rs, _re = (float(_rng[0]), float(_rng[1])) if _rng else (None, None)

                def _shown(sc):
                    if _rng is None:
                        return True
                    return float(sc.get("end", 0)) > _rs and float(sc.get("start", 0)) < _re

                todo = [sc for sc in (timeline.get("scenes") or [])
                        if sc.get("kind") == "image" and sc.get("path") and not sc.get("no_zoom")
                        and _shown(sc)]
                if _rng is not None and on_status:
                    on_status("Adding depth to the %d still(s) in this slice…" % len(todo))
                made = {}
                for n, sc in enumerate(todo):
                    if should_cancel and should_cancel():
                        raise RuntimeError("cancelled")
                    if on_status:
                        on_status(f"Adding depth to the stills… {n + 1}/{len(todo)}")
                    dur = float(sc["end"]) - float(sc["start"]) + 0.8      # a little tail for the overlap
                    key = parallax.clip_key(sc["path"], dur, sc.get("move") or "hold", sc.get("id") or n,
                                            native_w, native_h, FPS)
                    out = Path(workdir) / f"_px_{key}.mp4"
                    got = parallax.build_clip(sc["path"], out, dur, FPS, native_w, native_h,
                                              move=sc.get("move") or "hold", seed=int(sc.get("id") or n),
                                              cache=workdir)
                    if got:
                        made[str(sc.get("id"))] = str(got)
                if made:
                    opts = {**opts, "parallax_clips": made}
        except RuntimeError:
            raise
        except Exception as _qe:
            quiet(_qe, "render")
        # the weather plates: one per kind actually used, drawn once and cached in the work dir
        try:
            _kinds = set() if "visuals" in timeline else set(_atmo_windows(timeline).keys())
            if _kinds:
                if on_status:
                    on_status("Preparing weather…")
                opts = {**opts, "atmo_plates": {k: str(_atmo_plate(k, workdir)) for k in _kinds}}
        except Exception as _qe:
            quiet(_qe, "render")
        if ass_captions_with_browser:
            build_ass(caps, [], workdir / "subs.ass")  # OST is already in the browser clips; never draw it twice
        elif not caption_clips and not ordered_text_clips: # full libass fallback when the browser produced nothing
            build_ass(caps, scenes_for_ass, workdir / "subs.ass", timeline.get("sub_style"))
        inputs, graph, (vlab, alab) = build_graph(timeline, opts)
        (workdir / "filter.txt").write_text(graph, encoding="utf-8")

        total = float(timeline["total"])
        # Optional partial render: only encode a [start, end] slice of the finished timeline (output
        # seeking on the full graph — the picture/captions/music stay correct; "first N seconds" also
        # renders faster because ffmpeg stops once the output reaches its duration).
        r_start, r_dur = 0.0, total
        rng = opts.get("range")
        if rng:
            try:
                _rs = max(0.0, float(rng[0])); _re = min(total, float(rng[1]))
                if _re > _rs + 0.05:
                    r_start, r_dur = _rs, _re - _rs
            except (TypeError, ValueError) as _qe:
                quiet(_qe, "render")
        prog_total = r_dur
        seek = (["-ss", f"{r_start:.9f}"] if r_start > 0.001 else [])
        # GPU (NVENC) encode when asked AND available; otherwise fall back to x264 silently.
        if opts.get("gpu") and _has_nvenc():
            _cq = "28" if opts.get("fast") else "20"
            vcodec = ["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr",
                      "-cq", _cq, "-b:v", "0", "-pix_fmt", "yuv420p", "-profile:v", "high"]
        else:
            vcodec = ["-c:v", "libx264", "-preset", PRESET, "-crf", CRF,
                      "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.2"]
        # "Easy on the CPU": cap threads so the machine stays responsive during a render.
        threads = (["-threads", "2"] if opts.get("final_preview") else (["-threads", str(max(1, (os.cpu_count() or 4) // 2))] if opts.get("low_priority") else []))
        if opts.get("final_preview"):
            bounded=[]
            for arg in inputs:
                if arg=="-i":bounded.extend(["-threads","1"])
                bounded.append(arg)
            inputs=bounded
        filters=["-filter_complex_threads","2"] if opts.get("final_preview") else []
        maps = ["-map", vlab] + (["-map", alab] if alab else [])
        audio_codec = (["-c:a", "aac", "-b:a", AUDIO_BITRATE, "-ar", "48000", "-ac", "2"] if alab else ["-an"])
        cmd = (["ffmpeg", "-y", "-hide_banner", "-nostats"] + filters + inputs +
               ["-filter_complex_script", "filter.txt"] + maps + seek + threads +
               ["-t", f"{r_dur:.9f}"] + vcodec +
               ["-r", str(FPS), "-g", str(FPS * 2),
                ] + audio_codec + ["-movflags", "+faststart",
                "-progress", "pipe:1", str(out_path)])
    finally:
        FPS, SEQ_W, SEQ_H, PRESET, CRF = _saved   # restore before the (slow) ffmpeg run
        _RENDER_PREP_LOCK.release()

    # stderr goes STRAIGHT to the log file, not a pipe: ffmpeg is chatty, and a pipe we
    # only drain after wait() fills its buffer and deadlocks the render. stdout stays a
    # pipe because that's the -progress stream we read live.
    log = workdir / "render.log"
    with open(log, "w", encoding="utf-8", errors="ignore") as errf:
        _prio = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x4000) if opts.get("low_priority") else 0
        proc = subprocess.Popen(cmd, cwd=str(workdir), stdout=subprocess.PIPE,
                                stderr=errf, text=True, encoding="utf-8",
                                errors="ignore", bufsize=1, creationflags=_NO_WINDOW | _prio)
        if on_proc:
            on_proc(proc)          # hand the process to the caller so a cancel can kill it
        try:
            for line in proc.stdout:
                m = re.match(r"out_time_us=(\d+)", line.strip())
                if m and progress and prog_total > 0:
                    done = int(m.group(1)) / 1_000_000.0
                    progress(min(99, int(done / prog_total * 100)), done)
        finally:
            proc.wait()

    tail = []
    try:
        err = log.read_text(encoding="utf-8", errors="ignore")
        tail = [ln for ln in err.strip().splitlines() if ln.strip()][-6:]
    except Exception as _qe:
        quiet(_qe, "render")

    if proc.returncode != 0 or not out_path.exists():
        why = " | ".join(tail) if tail else f"exit {proc.returncode}; see {log}"
        raise RuntimeError(f"ffmpeg failed: {why}")
    if progress:
        progress(100, prog_total)
    return out_path


def render_audio(timeline, out_path, workdir, opts=None, progress=None, on_proc=None, on_status=None, should_cancel=None):
    """Encode one AAC master; no scene/video/caption decoder is opened."""
    opts = dict(opts or {})
    import voice_master
    if voice_master.is_prepared(timeline.get('vo')):
        opts['vo_gain_db']=0.0
    if should_cancel and should_cancel(): raise RuntimeError("cancelled")
    if "vo_gain_db" not in opts:
        value = _measure_lufs(timeline.get("vo"))
        if value is not None and -40 < value < 0:
            opts["vo_gain_db"] = max(-6., min(9., VO_TARGET_LUFS-value))
    inputs, graph, label = _audio_graph(timeline, opts)
    wd=Path(workdir); wd.mkdir(parents=True, exist_ok=True)
    target=Path(out_path); target.parent.mkdir(parents=True, exist_ok=True)
    (wd/'audio-filter.txt').write_text(';\n'.join(graph), 'utf8')
    bounded=[]
    for arg in inputs:
        if arg=='-i': bounded.extend(['-threads','1'])
        bounded.append(arg)
    cmd=['ffmpeg','-y','-hide_banner','-nostats','-filter_complex_threads','2',*bounded,
         '-filter_complex_script','audio-filter.txt','-map',label,'-vn','-threads','2',
         '-t',f"{float(timeline['total']):.9f}",'-c:a','aac','-b:a',AUDIO_BITRATE,
         '-ar','48000','-ac','2','-movflags','+faststart','-progress','pipe:1',str(target)]
    log=wd/'audio-render.log'
    with log.open('w',encoding='utf8') as err:
        proc=subprocess.Popen(cmd,cwd=str(wd),stdout=subprocess.PIPE,stderr=err,text=True,
                              encoding='utf8',errors='replace',creationflags=_NO_WINDOW)
        if on_proc: on_proc(proc)
        try:
            for line in proc.stdout:
                if should_cancel and should_cancel(): proc.terminate()
                match=re.match(r'out_time_us=(\d+)',line)
                if match and progress:
                    done=int(match[1])/1e6
                    progress(min(99,int(done/float(timeline['total'])*100)),done)
        finally: proc.wait()
    if proc.returncode or not target.is_file():
        raise RuntimeError('Audio render failed: '+log.read_text('utf8',errors='replace')[-1200:])
    if should_cancel and should_cancel(): raise RuntimeError('cancelled')
    if progress: progress(100,float(timeline['total']))
    return target
