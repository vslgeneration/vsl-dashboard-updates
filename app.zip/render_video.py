"""
Server-side MP4 render — turns the dashboard's rough-cut preview into ONE finished
file the user can download and upload straight to YouTube.

What it renders is exactly what the preview plays, because both are driven by the
same timeline dict (see app._build_timeline): the same scene media at the same
audio-driven time ranges, the same scene-split captions, the same voice-over, and
the same emotion-segmented music at the same per-segment levels.

Output: 1920x1080 @ 60 fps H.264 — the SAME spec as the Premiere export (premiere_export.FPS
/ SEQ_W / SEQ_H), so the delivered MP4 and the editable timeline match frame for frame.
Captions are BURNED IN (libass), because a YouTube upload can't carry a sidecar SRT.

Everything is done in ONE ffmpeg pass:
  video  each scene -> scaled/padded to the canvas at exactly its scene duration, concat
  subs   generated .ass (explicit PlayRes so font size is deterministic), burned on the concat
  audio  voice-over + one delayed/faded music stream per segment, amix normalize=0

The filter graph is written to a FILE (-filter_complex_script) rather than the command
line: a 40-scene VSL builds a graph well past the Windows 32 KB argv limit.
"""
import os, re, math, subprocess, shutil
from pathlib import Path

# Hide the console window ffmpeg would otherwise pop up on every call (the dashboard
# itself runs windowless, so children have no console to inherit).
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_NVENC = None
def _has_nvenc():
    """True if this ffmpeg has the NVIDIA h264_nvenc encoder (cached)."""
    global _NVENC
    if _NVENC is None:
        try:
            out = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True,
                                  text=True, timeout=15, creationflags=_NO_WINDOW).stdout or ""
            _NVENC = "h264_nvenc" in out
        except Exception:
            _NVENC = False
    return _NVENC

from premiere_export import FPS, SEQ_W, SEQ_H, ZOOM_PCT_PER_SEC, XFADE_SEC, ffprobe_media, _UTX, _UTX_DIR, _UTX_SFX_LEVEL
from premiere_export import _icon_hue_file, _icon_geom, _ICON_ONSCREEN, _VFX, _MOV_OFF, _movfx_alpha_file, _vfx_mode
import premiere_export

try:
    import caption_layer                     # browser-rendered caption/OST layer (pixel-identical to preview)
except Exception:
    caption_layer = None

# x264 settings for a final YouTube deliverable. CRF 17 at 1080p60 is visually
# transparent; "medium" keeps a long VSL to a sane render time (slower presets buy
# file size, not picture, at this CRF).
CRF = "17"
PRESET = "medium"
AUDIO_BITRATE = "320k"

# Burned-caption look — matches .pv-caption in static/style.css (white text in a
# 62%-black box, centred, just above the bottom edge) at 1080p scale.
FONT_NAME = "Arial"
FONT_SIZE = 46
BOX_ALPHA = 0x61          # ASS alpha: 0x00 opaque .. 0xFF clear; 0x61 ~= the CSS .62
MARGIN_V = 48             # ~4.5% up from the bottom, as in the preview
SIDE_MARGIN = 140         # keeps lines off the extreme edges (title-safe-ish)


def _snap(sec):
    """Snap a time to the nearest video frame. Caption cues and scene boundaries come from the
    forced-alignment/scene-split (arbitrary sub-frame times); snapping BOTH to the same frame grid
    makes the burned subtitle change land on the very frame the scene/image changes, instead of the
    ~1-2 frame drift you get when a raw cue time rounds onto a neighbouring frame."""
    return round(max(0.0, float(sec)) * FPS) / FPS


def _t(sec):
    """Seconds -> ASS timestamp H:MM:SS.cc. FLOOR to centiseconds: a frame-aligned cue time
    (frame/60) then lands on its exact video frame instead of possibly rounding up a frame."""
    sec = math.floor(max(0.0, float(sec)) * 100) / 100
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def _ass_color(hex_color):
    """#RRGGBB -> ASS &H00BBGGRR& (ASS colour is BGR)."""
    h = (hex_color or "#ffffff").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        r, g, b = 255, 255, 255
    return f"&H00{b:02X}{g:02X}{r:02X}&"


def _round_rect_path(w, h, r):
    """ASS \\p1 drawing path for a (rounded) rectangle, top-left at 0,0."""
    if r <= 0:
        return f"m 0 0 l {w} 0 l {w} {h} l 0 {h}"
    return (f"m {r} 0 l {w-r} 0 b {w} 0 {w} 0 {w} {r} "
            f"l {w} {h-r} b {w} {h} {w} {h} {w-r} {h} "
            f"l {r} {h} b 0 {h} 0 {h} 0 {h-r} "
            f"l 0 {r} b 0 0 0 0 {r} 0")


def _ost_events(scenes):
    """Animated on-screen-text overlay events. Styled per scene (font/weight/size/colour/style flags/
    letter-spacing/rotation/stroke/shadow/background box), placed top|center|bottom with custom line
    spacing (each line is its own centred event so leading is honoured), an entrance animation that
    ALWAYS also fades in, and an optional exit fade-out — matches the preview."""
    def _cf(v, d):                                # clamp a 0..1 fraction
        try: return min(1.0, max(0.0, float(v)))
        except (TypeError, ValueError): return d
    items = []                                    # flatten: each scene → its overlays, each with ITS OWN window
    for _scene in (scenes or []):
        _s0, _e0 = float(_scene["start"]), float(_scene["end"])
        _dur = max(0.0, _e0 - _s0)
        for _ov in (_scene.get("texts") or []):
            _a = _s0 + _dur * _cf(_ov.get("text_in"), 0.0)
            _b = _s0 + _dur * _cf(_ov.get("text_out"), 1.0)
            if _b <= _a:                          # keep at least a sliver
                _b = min(_e0, _a + 0.1)
            items.append((_ov, _t(_a), _t(_b)))
    return _emit_text_items(items)


def _emit_text_items(items):
    """Render a flat list of (text_* dict, start, end) into ASS Dialogue lines on the OST style —
    shared by the on-screen-text overlays and the global-styled subtitle captions."""
    out = []
    cx, off = SEQ_W // 2, 90
    for sc, st, en in items:                      # sc = one overlay's text_* dict
        txt = (sc.get("text") or "").strip()
        if not txt:
            continue
        font = (sc.get("text_font") or "Arial").replace("{", "").replace("}", "")
        size = int(sc.get("text_size") or 56)
        col = _ass_color(sc.get("text_color") or "#ffffff")
        fill_a = "" if sc.get("text_fill", True) else "\\1a&HFF&"   # Fill off → transparent glyph (stroke only)
        anim = sc.get("text_anim") or "fade"
        out_anim = sc.get("text_out_anim") or "none"
        # drop shadow: colour (\4c) + alpha (\4a) + depth (\shad). ASS casts down-right only (no direction).
        if sc.get("text_shadow", True):
            shad_depth = max(0, int(sc.get("text_shadow_size") or 0)) or 2
            shad_op = max(0, min(100, int(sc.get("text_shadow_opacity") or 0)))
            shad_alpha = max(0, min(255, 255 - int(round(shad_op / 100.0 * 255))))
            shadow_tag = f"\\shad{shad_depth}\\4c{_ass_color(sc.get('text_shadow_color') or '#000000')}\\4a&H{shad_alpha:02X}&"
        else:
            shadow_tag = "\\shad0"
        try:
            weight = int(sc.get("text_weight") or 400)
        except (TypeError, ValueError):
            weight = 400
        # Weight: \b with a hundreds value (100..900) is honoured only by *some* libass builds; others
        # render ANY non-zero \b as full bold — which made a normal 400 caption come out bold in the
        # render while the browser preview showed it normal. Use the portable on/off form so render ==
        # preview everywhere: normal (<600) vs bold (>=600).
        eff_w = 700 if (sc.get("text_bold") and weight < 700) else weight
        bold_tag = "\\b1" if eff_w >= 600 else "\\b0"
        italic = 1 if sc.get("text_italic") else 0
        under = 1 if sc.get("text_underline") else 0
        upper = bool(sc.get("text_upper"))
        letter = int(sc.get("text_letter") or 0)
        rot = int(sc.get("text_rotation") or 0)
        stroke_w = int(sc.get("text_stroke_w") or 0) if sc.get("text_stroke", True) else 0
        stroke_c = _ass_color(sc.get("text_stroke_color") or "#000000")
        place = sc.get("text_place") or "top"
        leading = float(sc.get("text_leading") or 1.15)
        x_off, y_off = int(sc.get("text_x") or 0), int(sc.get("text_y") or 0)
        cxp = cx + x_off
        lines = [ln.replace("{", "(").replace("}", ")") for ln in re.split(r"\s*\n\s*", txt) if ln.strip()]
        if upper:
            lines = [ln.upper() for ln in lines]
        if not lines:
            continue
        n, line_h = len(lines), size * leading
        if place == "center":
            first = SEQ_H * 0.5 - (n - 1) / 2.0 * line_h
        elif place == "bottom":
            # captions sit lower (matches the preview's .pv-caption at ~4.5% from the bottom);
            # on-screen-text overlays keep the higher 14%-from-bottom anchor.
            _bfrac = 0.925 if sc.get("_caption") else 0.86
            first = SEQ_H * _bfrac - (n - 1) * line_h
        else:                                            # top
            first = SEQ_H * 0.15
        border = (f"\\bord{stroke_w}\\3c{stroke_c}" if stroke_w > 0 else "\\bord0")
        frz = f"\\frz{(-rot) % 360}" if rot else ""     # ASS rotates CCW; negate to match CSS (CW)
        fsp = f"\\fsp{letter}" if letter else ""
        out_ms = 400 if (out_anim and out_anim != "none") else 0
        # background box (approx): filled rounded rect behind the whole block. Text width is estimated
        # from a per-char advance (~0.6*size); the exact box is preview-only, pad/radius are adjustable.
        if sc.get("text_bg") and int(sc.get("text_bg_opacity") or 0) > 0:
            pad, rad = int(sc.get("text_bg_pad") or 0), int(sc.get("text_bg_radius") or 0)
            max_chars = max((len(ln) for ln in lines), default=1)
            tw = max_chars * size * 0.60 + max(0, max_chars - 1) * letter
            th = (n - 1) * line_h + size * 1.15
            W, H = int(tw + 2 * pad), int(th + 2 * pad)
            r = max(0, min(rad, W // 2, H // 2))
            bcy = int(round(first + (n - 1) / 2.0 * line_h)) + y_off
            op = max(0, min(100, int(sc.get("text_bg_opacity") or 0)))
            alpha = max(0, min(255, 255 - int(round(op / 100.0 * 255))))
            bg_tag = (f"\\an5\\pos({cxp},{bcy})\\bord0\\shad0{frz}"
                      f"\\1c{_ass_color(sc.get('text_bg_color') or '#000000')}\\1a&H{alpha:02X}&"
                      f"\\fad(400,{out_ms})\\p1")
            out.append(f"Dialogue: 0,{st},{en},OST,,0,0,0,,{{{bg_tag}}}{_round_rect_path(W, H, r)}{{\\p0}}")
        for i, line in enumerate(lines):
            y = int(round(first + i * line_h)) + y_off   # each line is centre-anchored (\an5) at its y
            base = f"\\an5\\q2\\fn{font}\\fs{size}\\c{col}{fill_a}{bold_tag}\\i{italic}\\u{under}{fsp}{frz}{border}{shadow_tag}"
            if anim == "none":
                tag = f"{base}\\pos({cxp},{y})" + (f"\\fad(0,{out_ms})" if out_ms else "")
            elif anim == "popup":
                tag = f"{base}\\pos({cxp},{y})\\fad(250,{out_ms})\\fscx50\\fscy50\\t(0,400,\\fscx100\\fscy100)"
            elif anim == "slide-left":
                tag = f"{base}\\move({cxp - off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-right":
                tag = f"{base}\\move({cxp + off},{y},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-top":
                tag = f"{base}\\move({cxp},{y - off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            elif anim == "slide-bottom":
                tag = f"{base}\\move({cxp},{y + off},{cxp},{y},0,450)\\fad(400,{out_ms})"
            else:
                tag = f"{base}\\pos({cxp},{y})\\fad(500,{out_ms})"
            out.append(f"Dialogue: 1,{st},{en},OST,,0,0,0,,{{{tag}}}{line}")
    return out


def _snum(v, d):
    try: return float(v)
    except (TypeError, ValueError): return d


def _sub_wrap_lines(text, style):
    """Split a caption into balanced lines per the global subtitle style — width (% of frame) sets how
    many characters fit; 'lines' picks Auto / 1 / 2. Balanced splits avoid a lone word on the last line.
    Returns a list of line strings. Same logic is mirrored in app.js (wrapSub) so preview == render."""
    text = " ".join((text or "").split())
    if not text:
        return []
    width = max(20.0, min(100.0, _snum(style.get("sub_width"), 86)))
    size = max(1.0, _snum(style.get("ost_size"), 46))
    mode = str(style.get("sub_lines") or "auto")
    cpl = max(6, int(SEQ_W * width / 100.0 / (0.5 * size)))   # ~chars per line at this width+size
    words = text.split(" ")

    def greedy(cap):
        lines, cur = [], ""
        for w in words:
            if cur and len(cur) + 1 + len(w) > cap:
                lines.append(cur); cur = w
            else:
                cur = (cur + " " + w) if cur else w
        if cur:
            lines.append(cur)
        return lines or [text]

    def balance(n):
        if n <= 1 or len(words) < 2:
            return [text]
        total = len(text)
        target = total / n
        lines, cur = [], []
        for idx, w in enumerate(words):
            cur.append(w)
            cur_len = len(" ".join(cur))
            words_left = len(words) - idx - 1
            lines_left = n - len(lines) - 1
            if len(lines) < n - 1 and cur_len >= target and words_left >= lines_left:
                lines.append(" ".join(cur)); cur = []
        if cur:
            lines.append(" ".join(cur))
        return lines

    if mode == "1":
        return [text]                                 # force ONE line — never wrap (box hugs it)
    if mode == "2":
        return [text] if len(text) <= cpl else balance(2)
    # auto: fill each line up to the "Line" width (greedy → text reaches the edges); mirrors app.js wrapSubLines
    if len(text) <= cpl:
        return [text]
    return greedy(cpl)


def _style_to_text(style, text):
    """Map the global subtitle style (ost_* keys) onto the text_* shape _emit_text_items consumes."""
    g = (style or {}).get
    return {
        "text": text,
        "text_font": g("ost_font", "Arial"), "text_size": g("ost_size", 46),
        "text_color": g("ost_color", "#ffffff"), "text_fill": g("ost_fill", True),
        "text_weight": g("ost_weight", "400"), "text_bold": g("ost_bold", False),
        "text_italic": g("ost_italic", False), "text_underline": g("ost_underline", False),
        "text_upper": g("ost_upper", False), "text_letter": g("ost_letter", 0),
        "text_leading": g("ost_leading", 1.15), "text_place": g("ost_place", "bottom"),
        "text_x": g("ost_x", 0), "text_y": g("ost_y", 0), "text_rotation": g("ost_rotation", 0),
        "text_stroke": g("ost_stroke", False), "text_stroke_w": g("ost_stroke_w", 0),
        "text_stroke_color": g("ost_stroke_color", "#000000"),
        "text_bg": g("ost_bg", True), "text_bg_color": g("ost_bg_color", "#000000"),
        "text_bg_opacity": g("ost_bg_opacity", 62), "text_bg_pad": g("ost_bg_pad", 14),
        "text_bg_radius": g("ost_bg_radius", 10),
        "text_shadow": g("ost_shadow", False), "text_shadow_color": g("ost_shadow_color", "#000000"),
        "text_shadow_opacity": g("ost_shadow_opacity", 80), "text_shadow_size": g("ost_shadow_size", 6),
        "text_shadow_dir": g("ost_shadow_dir", 135),
        "text_anim": g("ost_anim", "fade"), "text_out_anim": g("ost_out_anim", "none"),
        "_caption": True,   # positions like the preview caption (lower) + not an on-screen overlay
    }


def _caption_events(captions, style):
    """Render captions through the on-screen-text engine using the one global subtitle style."""
    if not style:
        return []
    items = []
    for c in captions:
        lines = _sub_wrap_lines((c.get("text") or "").strip(), style)
        if not lines:
            continue
        ov = _style_to_text(style, "\n".join(lines))     # _emit_text_items splits on \n into centred lines
        items.append((ov, _t(_snap(float(c["start"]))), _t(_snap(float(c["end"])))))
    return _emit_text_items(items)


def _browser_items(captions, scenes, sub_style, opts):
    """Flatten captions + on-screen-text overlays into the item shape caption_layer.build_clips wants.
    Captions carry the one global subtitle style; each OST overlay carries its own text_* style (mapped
    back to the ost_* keys the browser CSS mirror reads). Times match the libass path exactly."""
    items = []
    rng = opts.get("range")
    rs, re_ = (float(rng[0]), float(rng[1])) if rng else (None, None)

    def _in_range(a, b):
        return rng is None or (b > rs and a < re_)   # overlaps the rendered slice

    # captions — one global subtitle style, balanced width-aware wrapping (same as the preview)
    if opts.get("burnsubs", True) and sub_style:
        for c in (captions or []):
            cs, ce = _snap(float(c["start"])), _snap(float(c["end"]))
            if not _in_range(cs, ce):
                continue                              # outside the rendered slice — the output-seek would cut it anyway
            lines = _sub_wrap_lines((c.get("text") or "").strip(), sub_style)
            if not lines:
                continue
            items.append({
                "text": "\n".join(lines), "style": dict(sub_style), "kind": "caption",
                "place": sub_style.get("ost_place", "bottom"),
                "x": sub_style.get("ost_x", 0), "y": sub_style.get("ost_y", 0),
                "rotation": sub_style.get("ost_rotation", 0),
                "sub_width": sub_style.get("sub_width", 86),
                "oneline": str(sub_style.get("sub_lines") or "auto") == "1",
                "anim": sub_style.get("ost_anim", "fade"), "out_anim": sub_style.get("ost_out_anim", "none"),
                "start": cs, "end": ce,
            })
    # on-screen text — each scene's overlays, each with its own window (mirrors _ost_events)
    if opts.get("onscreentext", True):
        def _cf(v, d):
            try: return min(1.0, max(0.0, float(v)))
            except (TypeError, ValueError): return d
        for sc in (scenes or []):
            s0, e0 = float(sc["start"]), float(sc["end"])
            dur = max(0.0, e0 - s0)
            for ov in (sc.get("texts") or []):
                txt = (ov.get("text") or "").strip()
                if not txt:
                    continue
                style = {("ost_" + k[5:]): v for k, v in ov.items()
                         if k.startswith("text_") and k not in
                         ("text_place", "text_x", "text_y", "text_rotation", "text_anim", "text_out_anim")}
                a = s0 + dur * _cf(ov.get("text_in"), 0.0)
                b = s0 + dur * _cf(ov.get("text_out"), 1.0)
                if b <= a:
                    b = min(e0, a + 0.1)
                if not _in_range(a, b):
                    continue                          # outside the rendered slice
                items.append({
                    "text": txt, "style": style, "kind": "ost",
                    "place": ov.get("text_place", "top"),
                    "x": ov.get("text_x", 0), "y": ov.get("text_y", 0), "rotation": ov.get("text_rotation", 0),
                    "anim": ov.get("text_anim", "fade"), "out_anim": ov.get("text_out_anim", "none"),
                    "start": a, "end": b,
                })
    return items


def build_ass(captions, scenes, path, sub_style=None):
    """Write the caption cues + on-screen-text overlays as an .ass subtitle file.

    We generate ASS rather than handing the .srt to ffmpeg because ffmpeg's SRT->ASS
    conversion picks its own PlayRes, which makes the resulting on-screen font size
    depend on the ffmpeg build. With an explicit PlayResX/Y the size is exact.
    """
    head = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {SEQ_W}\n"
        f"PlayResY: {SEQ_H}\n"
        "WrapStyle: 0\n"
        "ScaledBorderAndShadow: yes\n"
        "\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        # BorderStyle=3 -> the caption box. libass draws that box in OutlineColour (NOT
        # BackColour, which is the drop shadow), so the CSS background alpha goes there.
        # Outline=6 is the box padding; Alignment=2 -> bottom-centre.
        f"Style: Def,{FONT_NAME},{FONT_SIZE},&H00FFFFFF,&H00FFFFFF,&H{BOX_ALPHA:02X}000000,"
        f"&H{BOX_ALPHA:02X}000000,0,0,0,0,100,100,0,0,3,6,0,2,"
        f"{SIDE_MARGIN},{SIDE_MARGIN},{MARGIN_V},1\n"
        # OST = on-screen text overlay: outline (BorderStyle=1), no box, top-centre. Per-scene
        # font/size/colour + animation come from inline override tags (see _ost_events).
        f"Style: OST,Arial,56,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,1,0,0,0,100,100,0,0,1,3,2,8,12,12,60,1\n"
        "\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    lines = []
    if sub_style:
        # Global subtitle style set → render captions through the on-screen-text engine (full control
        # over font/colour/box/stroke/placement + balanced width-aware wrapping).
        lines += _caption_events(captions, sub_style)
    else:
        for c in captions:
            txt = (c.get("text") or "").strip()
            if not txt:
                continue
            # ASS reserves braces for override tags, and needs \N for a hard line break
            txt = txt.replace("{", "(").replace("}", ")")
            txt = re.sub(r"\s*\n\s*", r"\\N", txt)
            lines.append(f"Dialogue: 0,{_t(_snap(c['start']))},{_t(_snap(c['end']))},Def,,0,0,0,,{txt}")
    lines += _ost_events(scenes)                     # animated on-screen text on top of the captions
    Path(path).write_text(head + "\n".join(lines) + "\n", encoding="utf-8")


def _fit(label, upscaling):
    """Scale to the canvas preserving aspect, pad the rest black, square pixels.

    lanczos when shrinking (2K stills -> 1080p: keeps them crisp), bicubic when
    enlarging (720p clips -> 1080p: lanczos rings on upscale).
    """
    flags = "bicubic" if upscaling else "lanczos"
    return (f"[{label}]scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=decrease:flags={flags},"
            f"pad={SEQ_W}:{SEQ_H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps={FPS}")


# Ken-Burns works on an oversized canvas, this many times the output. zoompan places its
# crop window on WHOLE pixels of that canvas, so the canvas resolution — not any output
# super-sampling — sets the step size of the move. Our zoom is slow (1.4 %/sec), so on a
# small canvas the window advances well under a pixel per frame, freezes, then jumps: the
# shake. Measured (frame-to-frame diff; evenness = coefficient of variation, lower = smoother):
#     2x  6 % frames frozen, CV 42 %   <- the shake
#     3x  0 % frozen,        CV 26 %
#     4x  0 % frozen,        CV 10 %
#     5x  0 % frozen,        CV  8 %   <- and lowest fine-detail shimmer of the set
# The lever is this input canvas; super-sampling the zoom OUTPUT and downscaling was
# measured to NOT reduce the shake, only the render time. 5x is the practical floor.
KEN_CANVAS = 5


def _kenburns_fit(label, dur):
    """Scale a still onto the oversized Ken-Burns canvas, then zoom in at a constant
    1.4 %/sec — the same speed as the Premiere export's Ken Burns.

    COVER the canvas (scale up to fill, crop the small overflow), NOT fit-and-black-pad:
    with pad, zoompan at zoom=1 showed the whole padded frame, so a still that wasn't
    exactly 16:9 opened with black bars top/bottom that "filled in" as the zoom cropped
    inward. increase+crop makes frame 1 already fill the frame; the zoom then starts from
    there identically.

    bicubic, not lanczos, for the enlargement: we scale a ~2K still up past 4K, and lanczos
    rings on enlargement — that ringing crawls as shimmer during the slow zoom (measured
    lower shimmer with bicubic). This also scales once, straight from the source, so no
    2K -> 1080p -> canvas round-trip throws away the detail the image generator gave us.
    """
    kw, kh = SEQ_W * KEN_CANVAS, SEQ_H * KEN_CANVAS
    frames = max(1, int(round(dur * FPS)))
    z = ZOOM_PCT_PER_SEC / 100.0
    return (f"[{label}]scale={kw}:{kh}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={kw}:{kh},setsar=1,fps={FPS},"
            f"zoompan=z='1+{z:.5f}*on/{FPS}':d={frames}:s={SEQ_W}x{SEQ_H}:fps={FPS}"
            f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'")


def _slow_pre(slow):
    """setpts prefix that stretches a clip to `slow`x its length (slow>1 = slower). Applied FIRST so the
    fps resample fills the extra time and any Ken-Burns `t` ramps over the stretched (final) duration."""
    return f"setpts={slow:.6f}*PTS," if (slow and slow > 1.0001) else ""


def _video_cover(label, slow=1.0):
    """Scale a video clip to COVER the canvas (fill, crop the small overflow) instead of fit-and-pad.
    grok 1.5 delivers 1920x1088; padding would letterbox those 8px, cover crops them so the clip fills
    the 1080 frame edge-to-edge — matching the still + the preview (object-fit:cover). bicubic: clips are
    usually upscaled (720p/1088 -> 1080). `slow`>1 stretches a short clip to fill its scene."""
    return (f"[{label}]{_slow_pre(slow)}scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={SEQ_W}:{SEQ_H},setsar=1,fps={FPS}")


def _video_kenburns(label, slow=1.0):
    """COVER the canvas, then slow-zoom the MOVING clip at the same constant 1.4 %/sec as the stills'
    Ken Burns (locked-camera clips need the motion). Time-based centre crop + rescale; t is the clip's own
    time and starts at 0, so frame 1 is at zoom 1.0 and it grows from there — identical ramp to _kenburns_fit.
    `slow`>1 stretches a short clip to fill its scene (applied before the zoom so the ramp covers the fill)."""
    z = ZOOM_PCT_PER_SEC / 100.0
    # Use zoompan (NOT a time-varying crop): a filter's output size must stay constant, so crop=w='iw/(1+..t)'
    # is invalid — its w/h can't change per frame, which aborted the whole render. zoompan keeps a constant
    # output and slides a shrinking zoom window. THE SHIMMER FIX: zoompan rounds its crop window to WHOLE INPUT
    # pixels each frame, so at output resolution the ~1.4 %/sec creep jumps a full pixel every few frames ->
    # visible shimmer/jitter. Feeding it an OVER-SIZED canvas (2x) makes each jump a half output-pixel -> smooth.
    # (Stills use 5x; video can't afford 25x pixels per frame, but 2x kills most of the shake at 4x the cost.)
    kw, kh = SEQ_W * 2, SEQ_H * 2
    return (f"[{label}]{_slow_pre(slow)}scale={kw}:{kh}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={kw}:{kh},setsar=1,fps={FPS},"
            f"zoompan=z='1+{z:.5f}*on/{FPS}':d=1:s={SEQ_W}x{SEQ_H}:fps={FPS}"
            f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',setsar=1")


def _exact(dur):
    """Force a segment to be EXACTLY dur long: hold the last frame if the source ran
    out (a clip shorter than its spoken line), cut it if it ran over."""
    # 5 dp: the timeline hands us frame-quantized durations (frame/60), so keep that precision
    # here — each clip is then an exact whole-frame count and the clips don't drift when concatenated
    return (f",tpad=stop_mode=clone:stop_duration={dur:.5f},"
            f"trim=duration={dur:.5f},setpts=PTS-STARTPTS")

# per-scene transition key -> ffmpeg xfade transition name (slide render has no blur; the
# preview adds blur via CSS). "none" = a hard cut (a 1-frame xfade, imperceptible).
XFADE_NAMES = {
    "crossfade": "fade", "dip-black": "fadeblack", "dip-white": "fadewhite",
    "slide-left": "slideleft", "slide-right": "slideright",
    "slide-up": "slideup", "slide-down": "slidedown",
}
TX_SEC = 0.4          # scene-transition length (short; NOT XFADE_SEC, which is the 3s music cross-fade)


# ============================ ON-SCREEN ICON OVERLAYS (render) ============================
# Draw the same X / arrow / check / sparkle / pain-burst + animated video icons the Premiere XML export and the
# preview show. STATIC icons are PIL-composited to a full-frame transparent PNG (recoloured + sized + rotated +
# positioned with the SAME _icon_geom / _ICON_ONSCREEN math as the export, so placement is WYSIWYG) and overlaid
# as a still with a short fade-in over the icon's window. ANIMATED video icons (_VFX: arrows/hands/etc.) are
# overlaid LOOPING (mirrors the XML "loop, never freeze" behaviour). Heavy work is done in render() (where the
# work dir + PIL live) and the resolved specs are wired into the filtergraph by build_graph().
def _icon_still_png(kind, ix, iy, size, rot, flip, hue, workdir, tag, icon_dir):
    """Composite ONE static icon onto a full-frame transparent PNG at (ix,iy). Returns the path, or None."""
    try:
        from PIL import Image
    except Exception:
        return None
    canvas = Image.new("RGBA", (SEQ_W, SEQ_H), (0, 0, 0, 0))

    def _place(base, art, cx, cy):
        aw, ah = art.size
        layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
        layer.paste(art, (int(round(cx - aw / 2)), int(round(cy - ah / 2))), art)   # paste clips negatives/overflow
        return Image.alpha_composite(base, layer)

    try:
        if kind == "burst":
            rp = Path(icon_dir) / "icon_ring.png"
            if not rp.exists():
                return None
            rp = _icon_hue_file(rp, hue or 0)
            ring = Image.open(rp).convert("RGBA")
            af, _cx, _cy = _icon_geom(rp)
            base_w = SEQ_W * 0.17 * size                            # widest ring ~17% of the frame
            for scl, al in ((1.0, 235), (0.66, 150), (0.42, 95)):   # a few concentric rings = a static "pain burst"
                wpx = max(6.0, base_w * scl)
                k = wpx / ((af or 0.3) * ring.width)
                r2 = ring.resize((max(1, int(ring.width * k)), max(1, int(ring.height * k))), Image.LANCZOS)
                a = r2.split()[3].point(lambda p: int(p * al / 255))
                r2.putalpha(a)
                canvas = _place(canvas, r2, ix * SEQ_W, iy * SEQ_H)
        else:
            files = {"x": "icon_x.png", "arrow": "icon_arrow.png", "check": "icon_check.png", "sparkle": "icon_sparkle.png"}
            fn = files.get(kind)
            if kind == "arrow" and flip:
                fn = "icon_arrow_flip.png"
            if not fn:
                return None
            ip = Path(icon_dir) / fn
            if not ip.exists():
                return None
            ip = _icon_hue_file(ip, hue or 0)
            art = Image.open(ip).convert("RGBA")
            af, _cx, _cy = _icon_geom(ip)
            want = SEQ_W * _ICON_ONSCREEN.get(kind, 0.24) * size    # ART width on screen (art is pre-centred in the PNG)
            k = want / ((af or 0.2) * art.width)
            art = art.resize((max(1, int(art.width * k)), max(1, int(art.height * k))), Image.LANCZOS)
            if abs(rot) > 0.5:
                art = art.rotate(-rot, resample=Image.BICUBIC, expand=True)   # PIL rotates CCW+, preview/CSS CW+ -> negate
            canvas = _place(canvas, art, ix * SEQ_W, iy * SEQ_H)
        out = Path(workdir) / f"ico_{tag}.png"
        canvas.save(out)
        return out
    except Exception:
        return None


def _build_icon_specs(scenes, workdir):
    """Build overlay specs for every scene's on-screen icons (matches the XML export + preview placement).
    Static -> a composited PNG shown as a still; video (_VFX) -> the looping clip. Returns a list of dicts."""
    specs = []
    try:
        icon_dir = Path(premiere_export.__file__).resolve().parent / "Icons"
    except Exception:
        return specs
    n = 0
    for s in (scenes or []):
        if s.get("kind") not in ("image", "video"):       # icons only over real footage (never on blanks)
            continue
        icons = s.get("icons")
        if not isinstance(icons, list) or not icons:
            continue
        try:
            s0, s1 = float(s["start"]), float(s["end"])
        except Exception:
            continue
        span = s1 - s0
        if span <= 0:
            continue
        for it in icons:
            if not isinstance(it, dict):
                continue
            kind = (it.get("type") or it.get("icon") or "").strip().lower()
            if not kind:
                continue
            ix = float(it.get("x", 0.5) or 0.5); iy = float(it.get("y", 0.5) or 0.5)
            size = min(1.6, max(0.35, float(it.get("size", 1.0) or 1.0)))
            rot = float(it.get("rot", 0) or 0); flip = bool(it.get("flip"))
            hue = float(it.get("hue", 0) or 0)
            in_f = min(1.0, max(0.0, float(it.get("in", 0) or 0)))
            out_f = min(1.0, max(0.0, float(it.get("out") if it.get("out") is not None else 1.0)))
            st = s0 + span * in_f
            if kind == "x" and in_f <= 0.001:
                st += 0.4                                  # the X pops a beat after the scene starts (mirrors the export)
            en = (s0 + span * out_f) if out_f < 0.999 else s1
            if en - st < 0.4:
                continue
            n += 1
            if kind in _VFX:                               # animated video icon -> loop the clip
                blend, fnm = _VFX[kind]
                mv = icon_dir / fnm
                if not mv.exists():
                    continue
                try:
                    if blend == "key":                     # white-on-black mp4 -> tinted REAL-alpha .mov (same as the export)
                        mv = _movfx_alpha_file(mv, hue)
                    _vd, vw, vh = ffprobe_media(mv)
                except Exception:
                    continue
                vw = vw or SEQ_W; vh = vh or SEQ_H
                scw = max(2, int(round(vw * size))); sch = max(2, int(round(vh * size)))
                ox, oy = _MOV_OFF.get(kind, (0.0, 0.0))
                cx = (ix - ox) * SEQ_W; cy = (iy - oy) * SEQ_H
                specs.append({"video": True, "src": str(mv), "w": scw, "h": sch,
                              "x": int(round(cx - scw / 2)), "y": int(round(cy - sch / 2)),
                              "start": round(st, 4), "end": round(en, 4),
                              "loop": _vfx_mode(kind) != "once"})   # "once" -> play then FREEZE last frame (no repeat)
            else:                                          # static icon -> composited still PNG
                png = _icon_still_png(kind, ix, iy, size, rot, flip, hue, workdir, f"{s.get('id', 's')}_{n}", icon_dir)
                if not png:
                    continue
                specs.append({"video": False, "src": str(png), "start": round(st, 4), "end": round(en, 4)})
    return specs


def build_graph(timeline, opts):
    """Return (ffmpeg input args, filter-graph text, output map labels).

    Scene media become real -i inputs; gaps and blank scenes become in-graph color
    sources (no input slot needed).
    """
    ken = bool(opts.get("kenburns"))
    xfade = XFADE_SEC if opts.get("crossfade", True) else 0.0
    total = float(timeline["total"])

    inputs, graph = [], []
    idx = 0                       # next ffmpeg input index

    # 1) resolve every segment (scene clip, or black for a gap/blank) with its duration and
    #    the transition INTO the next segment (the outgoing scene owns the handoff).
    segs = []                     # each: {"kind","src","dur","trans"}
    cursor = 0.0
    for sc in timeline["scenes"]:
        start, end = _snap(sc["start"]), _snap(sc["end"])   # frame-align so the xfade boundary lands on the same frame as the (also snapped) caption cue
        if start - cursor > 0.02:                 # nothing scheduled here -> black filler (hard cut)
            segs.append({"kind": "black", "src": None, "dur": start - cursor, "trans": "none"})
        dur = end - start
        cursor = end
        if dur <= 0:
            continue
        kind, src = sc.get("kind"), sc.get("path")
        trans = sc.get("transition") or "none"
        if kind == "video" and src:
            segs.append({"kind": "video", "src": src, "dur": dur, "trans": trans, "no_zoom": bool(sc.get("no_zoom"))})
        elif kind == "image" and src:
            segs.append({"kind": "image", "src": src, "dur": dur, "trans": trans, "no_zoom": bool(sc.get("no_zoom"))})
        else:
            segs.append({"kind": "black", "src": None, "dur": dur, "trans": "none"})
    if total - cursor > 0.02:                      # voice-over runs past the last scene
        segs.append({"kind": "black", "src": None, "dur": total - cursor, "trans": "none"})

    if not segs:
        raise RuntimeError("Nothing to render — no scene has an approved image or video yet.")

    # transitions on only when the user asked AND some non-last segment actually has one
    use_tx = bool(opts.get("transitions", True)) and len(segs) > 1 and \
        any(s["trans"] != "none" for s in segs[:-1])
    HARD = 1.0 / FPS               # a "none" handoff = a 1-frame xfade (a clean cut)

    # overlap AFTER each segment (into the next). Clamp so a transition never exceeds half of
    # either adjacent clip — otherwise a short scene's xfade would run past the clip and break.
    def _dout(i):
        if not use_tx or i >= len(segs) - 1:
            return 0.0
        if segs[i]["trans"] == "none" or segs[i]["trans"] in _UTX:   # user clips play over a HARD cut
            return HARD
        return max(HARD, min(TX_SEC, 0.5 * segs[i]["dur"], 0.5 * segs[i + 1]["dur"]))
    douts = [_dout(i) for i in range(len(segs))]

    # user-transition events: (key, cut_time). The clip's hit frame (60 fps, normal speed) is later aligned to the
    # cut; `speed` re-times it so the effective hit lands at hit/speed. Only when transitions are enabled.
    utx_events = []
    if bool(opts.get("transitions", True)) and len(segs) > 1:
        _acc = 0.0
        for i in range(len(segs) - 1):
            _acc += segs[i]["dur"]
            if segs[i]["trans"] in _UTX:
                utx_events.append((segs[i]["trans"], _acc))

    # 2) build each segment; a transitioning clip is extended by its overlap so the total
    #    duration (and every scene start) stays exactly aligned with the audio/captions.
    for i, s in enumerate(segs):
        seglen = s["dur"] + douts[i]
        if s["kind"] == "video":
            inputs += ["-i", str(s["src"])]
            # if the clip is SHORTER than the scene it must fill, slow it to fill exactly (no last-frame
            # freeze). factor = target / clip-length; probed once per clip. clip >= scene -> no slow (1.0).
            vdur = s.get("dur_src")
            if vdur is None:
                d, _w, _h = ffprobe_media(s["src"])
                vdur = d or 0.0
            slow = (seglen / vdur) if (vdur and vdur > 0 and vdur < seglen - 1.0 / FPS) else 1.0
            chain = _video_kenburns(f"{idx}:v", slow) if (ken and not s.get("no_zoom")) else _video_cover(f"{idx}:v", slow)
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        elif s["kind"] == "image":
            inputs += ["-loop", "1", "-framerate", str(FPS), "-t", f"{seglen + 0.5:.3f}", "-i", str(s["src"])]
            chain = _kenburns_fit(f"{idx}:v", seglen) if (ken and not s.get("no_zoom")) else _fit(f"{idx}:v", upscaling=False)   # no Ken-Burns zoom on a testimonial card
            graph.append(chain + _exact(seglen) + f"[v{i}]")
            idx += 1
        else:
            graph.append(f"color=c=black:s={SEQ_W}x{SEQ_H}:r={FPS}:d={seglen:.5f},setsar=1[v{i}]")

    # 3) join: a plain concat when there are no transitions, else an xfade chain. Each xfade
    #    starts at the (original) scene boundary; the outgoing clip's extension covers the overlap.
    slide_windows = []                             # (start_t, dur, transition) → motion-blur the slide
    if not use_tx:
        graph.append(f"{''.join(f'[v{i}]' for i in range(len(segs)))}concat=n={len(segs)}:v=1:a=0[vcat]")
    else:
        acc, cum = "v0", segs[0]["dur"]            # cum = start time of the next segment
        for i in range(1, len(segs)):
            trans = segs[i - 1]["trans"]
            D = douts[i - 1]                        # same overlap the outgoing clip was extended by
            name = XFADE_NAMES.get(trans, "fade")
            out = "vcat" if i == len(segs) - 1 else f"xf{i}"
            graph.append(f"[{acc}][v{i}]xfade=transition={name}:duration={D:.5f}:offset={cum:.5f}[{out}]")
            if trans.startswith("slide-"):
                slide_windows.append((cum, D, trans))
            acc = out
            cum += segs[i]["dur"]
    # Motion blur on slides, matching the preview's blurred push. A single box blur looks blocky/"cheap",
    # so we run TWO smaller box passes (≈ a smooth gaussian) along the slide axis only, gated to each
    # slide's time window. One filter chain per direction keeps a video with many slides light.
    vsrc = "vcat"
    if slide_windows:
        rad = max(2, round(SEQ_W / 150))           # per-pass radius (~13 at 1080p, ~9 at 720p)
        groups = ((True,  [w for w in slide_windows if w[2] in ("slide-left", "slide-right")]),
                  (False, [w for w in slide_windows if w[2] in ("slide-up", "slide-down")]))
        k = 0
        for horiz, group in groups:
            if not group:
                continue
            conds = "+".join(f"between(t,{c0:.5f},{c0 + d:.5f})" for (c0, d, tr) in group)
            sx, sy = (rad, 1) if horiz else (1, rad)
            for _ in range(2):                     # two passes → smooth (gaussian-like), not boxy
                nxt = f"vb{k}"; k += 1
                graph.append(f"[{vsrc}]avgblur=sizeX={sx}:sizeY={sy}:enable='{conds}'[{nxt}]")
                vsrc = nxt
    # On-screen ICON overlays — wired UNDER the caption/OST layer so the text always sits on top (matches the
    # XML track order: icons below, text above). render() pre-built the specs (PIL stills + resolved video clips)
    # into opts["icon_specs"]. Static icons fade in; animated video icons loop to the icon's window end.
    for spec in (opts.get("icon_specs") or []):
        src = spec["src"]; st = float(spec["start"]); en = float(spec["end"]); dur = max(0.1, en - st)
        vloop = spec.get("loop", True)                         # "once" icons (chkg/xv*/cancel/warn/ques) don't repeat
        if spec.get("video"):
            if vloop:
                inputs += ["-stream_loop", "-1", "-t", f"{dur:.4f}", "-i", src]
            else:
                inputs += ["-i", src]                          # play ONCE; tpad below freezes the last frame for the rest
        else:
            inputs += ["-loop", "1", "-t", f"{dur:.4f}", "-i", src]
        ci = idx; idx += 1
        if spec.get("video"):
            _hold = "" if vloop else f"tpad=stop_mode=clone:stop_duration={dur:.4f},"   # freeze last frame to fill the window
            graph.append(f"[{ci}:v]scale={spec['w']}:{spec['h']},format=rgba,{_hold}"
                         f"setpts=PTS-STARTPTS+{st:.4f}/TB[ico{ci}]")
            oxy = f"x={spec['x']}:y={spec['y']}"
        else:
            graph.append(f"[{ci}:v]format=rgba,fade=t=in:st=0:d=0.18:alpha=1,"
                         f"setpts=PTS-STARTPTS+{st:.4f}/TB[ico{ci}]")
            oxy = "x=0:y=0"                                     # static PNG is full-frame, icon already at its place
        nxt = f"ivc{ci}"
        graph.append(f"[{vsrc}][ico{ci}]overlay={oxy}:eof_action=pass:enable='between(t,{st:.4f},{en:.4f})'[{nxt}]")
        vsrc = nxt

    # Caption / on-screen-text layer. Preferred: overlay the browser-rendered clips (pixel-identical to
    # the preview) each at its own [start,end] window — the clips are 1920x1080 transparent + positioned,
    # so they blend straight onto the picture (scaled to the output size for the 720p test render).
    caption_clips = opts.get("caption_clips") or []
    has_ost = bool(opts.get("onscreentext", True)) and any(
        (ov.get("text") or "").strip() for s in timeline["scenes"] for ov in (s.get("texts") or []))
    if caption_clips:
        cur = vsrc
        sx = SEQ_W / 1920.0                        # clips are authored at 1920x1080; scale crop + position for 720p test
        for (mov, cstart, cend, cx, cy) in caption_clips:
            inputs += ["-i", str(mov)]
            ci = idx; idx += 1
            if (SEQ_W, SEQ_H) == (1920, 1080):
                pre, ox, oy = "", int(cx), int(cy)
            else:
                pre = f"scale=iw*{sx:.6f}:ih*{sx:.6f},"
                ox, oy = int(round(cx * sx)), int(round(cy * sx))
            graph.append(f"[{ci}:v]{pre}setpts=PTS-STARTPTS+{cstart:.4f}/TB[cc{ci}]")
            nxt = f"cv{ci}"
            graph.append(f"[{cur}][cc{ci}]overlay=x={ox}:y={oy}:eof_action=pass:"
                         f"enable='between(t,{cstart:.4f},{cend:.4f})'[{nxt}]")
            cur = nxt
        graph.append(f"[{cur}]null[vcap]")
    elif opts.get("burnsubs", True) or has_ost:
        # libass fallback (no browser present). relative filename — ffmpeg runs with cwd = the work dir.
        graph.append(f"[{vsrc}]ass=subs.ass:fontsdir=fonts[vcap]")
    else:
        graph.append(f"[{vsrc}]null[vcap]")            # clean render, no captions, no overlay text

    # USER transition clips: place each over its cut with the HIT frame aligned. speed re-times it (setpts), blend
    # is NORMAL (alpha overlay — the clip carries alpha) or SCREEN (black-pad to full length + blend=screen).
    # ALL of this runs in RGB (gbrp): blend=screen in YUV screen-blends the CHROMA planes too, and the full-length
    # black padding then shifts every frame's colour -> a magenta cast over the whole video. In RGB, black is a
    # true screen no-op, so outside the short transition window the picture is untouched.
    if utx_events:
        graph.append("[vcap]format=gbrp[vrgb]")
        cur = "vrgb"
        for n, (key, cut_t) in enumerate(utx_events):
            spec = _UTX[key]
            fn = _UTX_DIR / spec["file"]
            if not fn.exists():
                continue
            vdur, _vw, _vh = ffprobe_media(fn)
            if not vdur:
                continue
            sp = spec["speed"]
            placed = vdur / sp                              # placed duration (s) after the speed change
            s0 = max(0.0, cut_t - spec["hit"] / 60.0)       # hit measured on the final (sped) clip, 60 fps timebase
            inputs += ["-i", str(fn)]
            ti = idx; idx += 1
            spd = f"setpts=PTS/{sp:.5f}," if abs(sp - 1.0) > 1e-3 else ""
            if spec["blend"] == "screen":
                pad_end = max(0.1, total - s0 - placed + 0.5)
                graph.append(f"[{ti}:v]{spd}fps={FPS},scale={SEQ_W}:{SEQ_H},setsar=1,format=gbrp,"
                             f"tpad=start_duration={s0:.4f}:start_mode=add:color=black:"
                             f"stop_duration={pad_end:.4f}:stop_mode=add:color=black[utf{n}]")
                nxt = f"uv{n}"
                # ,format=gbrp AFTER the blend keeps the chain in RGB: with several transitions, overlay (below)
                # outputs yuv420 by default, and the NEXT screen-blend in YUV would shift chroma -> magenta.
                graph.append(f"[{cur}][utf{n}]blend=all_mode=screen:shortest=1,format=gbrp[{nxt}]")
            else:                                           # NORMAL: alpha overlay (keep the clip's alpha channel)
                end = s0 + placed
                graph.append(f"[{ti}:v]{spd}fps={FPS},scale={SEQ_W}:{SEQ_H},setsar=1,format=gbrap,"
                             f"setpts=PTS-STARTPTS+{s0:.4f}/TB[utf{n}]")
                nxt = f"uv{n}"
                graph.append(f"[{cur}][utf{n}]overlay=eof_action=pass:enable='between(t,{s0:.4f},{end:.4f})',format=gbrp[{nxt}]")
            cur = nxt
        graph.append(f"[{cur}]format=yuv420p[vout]")
    else:
        graph.append("[vcap]null[vout]")

    # ---- audio: voice-over + one stream per music segment ----
    inputs += ["-i", str(timeline["vo"])]
    vo_idx = idx; idx += 1
    graph.append(f"[{vo_idx}:a]aresample=48000,asetpts=PTS-STARTPTS[avo]")
    alabels = ["[avo]"]

    # music off -> no music streams at all, so the mix below is voice-over only
    music_segs = (timeline.get("music") or []) if opts.get("music", True) else []
    last = len(music_segs) - 1
    for i, seg in enumerate(music_segs):
        if not seg.get("path"):
            continue
        s, e = float(seg["start"]), float(seg["end"])
        span = e - s
        if span <= 0.05:
            continue
        # Softer hand-off (render output only; the Premiere export keeps its own crossfade): the NEW
        # segment still pre-rolls by xfade and is at full exactly AT the boundary, but the OLD segment
        # now LINGERS past the boundary — it plays MUSIC_TAIL seconds into the new one and fades out
        # gently over that tail, so the two overlap longer instead of the old cutting off at the seam.
        MUSIC_TAIL = 1.5
        pre = xfade if (xfade and i > 0) else 0.0
        placed_start = max(0.0, s - pre)
        tail = MUSIC_TAIL if (i < last and xfade) else 0.0
        placed_dur = span + (s - placed_start) + tail                  # extend past the boundary by `tail`
        fin = (s - placed_start) if i > 0 else min(1.5, span)          # new reaches full at the boundary
        fout = (xfade + tail) if (i < last and xfade) else min(2.0, placed_dur)  # starts ~xfade before the seam, ends `tail` after it
        # -stream_loop so a segment longer than its track doesn't fall silent
        inputs += ["-stream_loop", "-1", "-i", str(seg["path"])]
        chain = (f"[{idx}:a]aresample=48000,atrim=duration={placed_dur:.3f},asetpts=PTS-STARTPTS,"
                 f"volume={float(seg.get('level') or 0.15):.4f},"
                 f"afade=t=in:st=0:d={max(0.05, fin):.3f},"
                 f"afade=t=out:st={max(0.0, placed_dur - fout):.3f}:d={max(0.05, fout):.3f}")
        delay = int(round(placed_start * 1000))
        chain += f",adelay={delay}|{delay}[am{i}]"
        graph.append(chain)
        alabels.append(f"[am{i}]")
        idx += 1

    # transition SFX: a whoosh/impact per user-transition, synced so its impact lands on the cut, under the VO.
    if bool(opts.get("transitions", True)):
        for sn, (key, cut_t) in enumerate(utx_events):
            spec = _UTX[key]
            sfxfn = _UTX_DIR / (spec.get("sfx") or "")
            if not spec.get("sfx") or not sfxfn.exists():
                continue
            s_start = max(0.0, cut_t - spec["sfx_hit"])
            inputs += ["-i", str(sfxfn)]
            si = idx; idx += 1
            d_ms = int(round(s_start * 1000))
            graph.append(f"[{si}:a]aresample=48000,volume={_UTX_SFX_LEVEL:.3f},adelay={d_ms}|{d_ms}[usfx{sn}]")
            alabels.append(f"[usfx{sn}]")

    if len(alabels) > 1:
        # normalize=0: the VO is already at -16 LUFS and each music segment already carries
        # its measured -33 LUFS gain, so amix must NOT re-level them. alimiter is a safety
        # net against the rare sum overshooting 0 dBFS.
        graph.append(f"{''.join(alabels)}amix=inputs={len(alabels)}:duration=longest:normalize=0,"
                     f"alimiter=limit=0.97[aout]")
    else:
        graph.append("[avo]alimiter=limit=0.97[aout]")

    return inputs, ";\n".join(graph), ("[vout]", "[aout]")


def render(timeline, out_path, workdir, opts=None, progress=None, on_proc=None, on_status=None, should_cancel=None):
    """Render the timeline to out_path. `progress(pct, seconds_done)` is called as it runs.
    `on_proc(popen)` is called once with the ffmpeg process so the caller can cancel it.
    `on_status(text)` (optional) reports the current phase label (e.g. "Preparing captions…").
    `should_cancel()` (optional) — checked during the caption-prep phase so Stop works before ffmpeg starts.

    Returns the output Path. Raises RuntimeError with ffmpeg's tail on failure.
    """
    opts = opts or {}
    # Fast "test render": drop to 720p30 + x264 ultrafast + higher CRF for a quick sync/timing check.
    # These are module-level constants the filter builders read by name, so override them only while we
    # build the graph/subs/command, then restore (the ffmpeg subprocess itself uses the already-built cmd).
    global FPS, SEQ_W, SEQ_H, PRESET, CRF
    _saved = (FPS, SEQ_W, SEQ_H, PRESET, CRF)
    if opts.get("fast"):
        FPS, SEQ_W, SEQ_H, PRESET, CRF = 30, 1280, 720, "ultrafast", "28"
    try:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Bundle the on-screen-text fonts into the work dir so libass can find them — most of the
        # chosen fonts (Montserrat, Poppins, Flatshoes, …) are NOT installed system-wide. A relative
        # fontsdir=fonts (cwd is the work dir) sidesteps Windows filter-path escaping.
        try:
            _fsrc = Path(__file__).parent / "static" / "fonts"
            if _fsrc.is_dir():
                _fdst = workdir / "fonts"; _fdst.mkdir(exist_ok=True)
                for _f in _fsrc.iterdir():
                    if _f.suffix.lower() in (".ttf", ".otf"):
                        shutil.copy2(_f, _fdst / _f.name)
        except Exception:
            pass

        # captions only when "Burn Subtitles" is on; on-screen text overlays only when "On-screen Text" is on
        caps = (timeline.get("captions") or []) if opts.get("burnsubs", True) else []
        scenes_for_ass = timeline.get("scenes") or []
        if not opts.get("onscreentext", True):
            scenes_for_ass = [{**s, "texts": []} for s in scenes_for_ass]   # drop overlays so they don't burn

        # Preferred path: render captions + on-screen text through the SAME engine as the preview
        # (headless browser) so the burned-in text is pixel-identical — font weight, line spacing and the
        # text-hugging box all match. Falls back to libass (build_ass) when no browser is present.
        caption_clips = []
        if caption_layer is not None:
            try:
                _items = _browser_items(timeline.get("captions") or [], scenes_for_ass,
                                        timeline.get("sub_style"), opts)
                if _items:
                    if on_status:
                        on_status("Preparing captions…")
                    def _cap_prog(done, tot):
                        if on_status:
                            on_status(f"Preparing captions… {done}/{tot}")
                    caption_clips = caption_layer.build_clips(
                        _items, workdir, FPS, 1920, 1080, _cap_prog, should_cancel) or []
            except Exception:
                caption_clips = []
        if should_cancel and should_cancel():          # Stop pressed during caption prep → bail before ffmpeg
            raise RuntimeError("cancelled")
        # ffmpeg runs with cwd=workdir → pass caption clips as RELATIVE paths so hundreds of "-i" args
        # don't blow past Windows' ~32K command-line limit (WinError 206 on a full VSL's ~220 captions).
        _wd = Path(workdir)
        caption_clips = [(Path(os.path.relpath(m, _wd)).as_posix(), s, e, x, y)
                         for (m, s, e, x, y) in caption_clips]
        opts = {**opts, "caption_clips": caption_clips}
        # On-screen icons -> transparent overlay clips (PIL stills + looping video icons), built here where the
        # work dir + PIL live; build_graph() wires them under the caption layer. Never fatal — icons are cosmetic.
        try:
            opts = {**opts, "icon_specs": _build_icon_specs(timeline.get("scenes") or [], workdir)}
        except Exception:
            opts = {**opts, "icon_specs": []}
        if not caption_clips:                       # libass fallback only when the browser path produced nothing
            build_ass(caps, scenes_for_ass, workdir / "subs.ass", timeline.get("sub_style"))
        inputs, graph, (vlab, alab) = build_graph(timeline, opts)
        (workdir / "filter.txt").write_text(graph, encoding="utf-8")

        total = float(timeline["total"])
        # Optional partial render: only encode a [start, end] slice of the finished timeline (output
        # seeking on the full graph — the picture/captions/music stay correct; "first N seconds" also
        # renders faster because ffmpeg stops once the output reaches its duration).
        r_start, r_dur = 0.0, total
        rng = opts.get("range")
        if rng:
            try:
                _rs = max(0.0, float(rng[0])); _re = min(total, float(rng[1]))
                if _re > _rs + 0.05:
                    r_start, r_dur = _rs, _re - _rs
            except (TypeError, ValueError):
                pass
        prog_total = r_dur
        seek = (["-ss", f"{r_start:.3f}"] if r_start > 0.001 else [])
        # GPU (NVENC) encode when asked AND available; otherwise fall back to x264 silently.
        if opts.get("gpu") and _has_nvenc():
            _cq = "28" if opts.get("fast") else "20"
            vcodec = ["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr",
                      "-cq", _cq, "-b:v", "0", "-pix_fmt", "yuv420p", "-profile:v", "high"]
        else:
            vcodec = ["-c:v", "libx264", "-preset", PRESET, "-crf", CRF,
                      "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.2"]
        # "Easy on the CPU": cap threads so the machine stays responsive during a render.
        threads = (["-threads", str(max(1, (os.cpu_count() or 4) // 2))] if opts.get("low_priority") else [])
        cmd = (["ffmpeg", "-y", "-hide_banner", "-nostats"] + inputs +
               ["-filter_complex_script", "filter.txt", "-map", vlab, "-map", alab] + seek + threads +
               ["-t", f"{r_dur:.3f}"] + vcodec +
               ["-r", str(FPS), "-g", str(FPS * 2),
                "-c:a", "aac", "-b:a", AUDIO_BITRATE, "-ar", "48000", "-ac", "2",
                "-movflags", "+faststart",
                "-progress", "pipe:1", str(out_path)])
    finally:
        FPS, SEQ_W, SEQ_H, PRESET, CRF = _saved   # restore before the (slow) ffmpeg run

    # stderr goes STRAIGHT to the log file, not a pipe: ffmpeg is chatty, and a pipe we
    # only drain after wait() fills its buffer and deadlocks the render. stdout stays a
    # pipe because that's the -progress stream we read live.
    log = workdir / "render.log"
    with open(log, "w", encoding="utf-8", errors="ignore") as errf:
        _prio = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x4000) if opts.get("low_priority") else 0
        proc = subprocess.Popen(cmd, cwd=str(workdir), stdout=subprocess.PIPE,
                                stderr=errf, text=True, encoding="utf-8",
                                errors="ignore", bufsize=1, creationflags=_NO_WINDOW | _prio)
        if on_proc:
            on_proc(proc)          # hand the process to the caller so a cancel can kill it
        try:
            for line in proc.stdout:
                m = re.match(r"out_time_us=(\d+)", line.strip())
                if m and progress and prog_total > 0:
                    done = int(m.group(1)) / 1_000_000.0
                    progress(min(99, int(done / prog_total * 100)), done)
        finally:
            proc.wait()

    tail = []
    try:
        err = log.read_text(encoding="utf-8", errors="ignore")
        tail = [ln for ln in err.strip().splitlines() if ln.strip()][-6:]
    except Exception:
        pass

    if proc.returncode != 0 or not out_path.exists():
        why = " | ".join(tail) if tail else f"exit {proc.returncode}; see {log}"
        raise RuntimeError(f"ffmpeg failed: {why}")
    if progress:
        progress(100, prog_total)
    return out_path
