"""Regroup existing measured captions after scene redistribution; never align audio."""
from pathlib import Path
import copy,hashlib,json,shutil
from subtitle import acoustic_phrasing as phrasing,phrase_store as store
from subtitle.text_boundaries import normalize_spacing

class Pending(ValueError):pass

def partition(doc):
    return [normalize_spacing(s.get('vo') or '') for s in doc.get('scenes',[]) if str(s.get('vo') or '').strip()]

def signature(doc):
    return hashlib.sha256(json.dumps(partition(doc),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def unfinished(doc):
    return any(isinstance(s.get('sentence_draft'),str) and normalize_spacing(s['sentence_draft'])!=normalize_spacing(s.get('vo') or '') for s in doc.get('scenes',[]))

def lexical(text):
    return [key for token in normalize_spacing(text).split() if (key:=store.lexical_key(token))]

def inspect(selected,doc):
    """Cheap preflight before a copy: exact full coverage, source and numeric cuts."""
    selected=Path(selected)
    if unfinished(doc):raise Pending('Finish moving the recorded words into the new scene before previewing or exporting.')
    record=selected/'_result.json';meta=json.loads(record.read_text('utf8')) if record.is_file() else {}
    filename=meta.get('srt') or 'subtitles.srt'
    if Path(filename).name!=filename:raise Pending('Invalid selected subtitle filename.')
    srt=selected/filename
    if not srt.is_file():return None
    planfile=selected/'phrase-plan.json';old=json.loads(planfile.read_text('utf8')) if planfile.is_file() else None
    try:
        wp=store._pick_wordfile(selected,old or {},None);raw=store.load_words(wp)
        if old and old.get('policy')==phrasing.POLICY:
            tokens=store.canonical_rows(old,raw)
        else:
            text=' '.join(store._cues_text(srt));tokens=store.timed_tokens(text.split(),raw)
            old=None
        text=' '.join(w[0] for w in tokens);parts=partition(doc)
        # A unique subrange is useful elsewhere, but must not turn unfinished
        # prefix/suffix cut-and-paste into a complete scene redistribution.
        if parts and lexical(' '.join(parts))!=lexical(text):
            raise Pending('Scene words do not yet cover the complete recording in order. Finish moving the words, or sync the changed script with the voice-over.')
        if not parts:return None
        cuts=store.scene_boundaries(text,parts)
        starts={g['a'] for g in old['groups']}|{len(tokens)} if old else set()
        missing=sorted(set(cuts)-starts)
        new_cuts=sorted(set(cuts)-set((old or {}).get('forced_boundaries',[]))-{0,len(tokens)})
        return dict(meta=meta,srt=filename,wordfile=wp.name,raw=raw,tokens=tokens,old=old,cuts=cuts,missing=missing,new_cuts=new_cuts,needed=old is None or bool(missing) or bool(new_cuts))
    except Pending:raise
    except (OSError,ValueError,KeyError,TypeError) as exc:
        raise Pending(str(exc)) from exc

def _regroup(state,lang):
    old=state['old'];tokens=state['tokens'];cuts=state['cuts'];fps=(old or {}).get('fps',60)
    if not old:
        new=phrasing.plan(tokens,lang=lang,forced_boundaries=cuts,fps=fps)
    else:
        new=copy.deepcopy(old);n=len(tokens)
        prior=sorted(set([0,n,*old.get('forced_boundaries',[])]))
        regions=set()
        for point in state['missing']:
            for a,b in zip(prior,prior[1:]):
                if a<point<b:regions.add((a,b));break
        groups=[]
        for a,b in sorted(regions):
            # Existing fixed source/scene edges partition the affected area.
            # Reuse all other phrases exactly, including their reviewed breaks.
            sub=phrasing.plan(tokens[a:b],lang=lang,forced_boundaries=[c-a for c in cuts if a<c<b],fps=fps)
            for g in sub['groups']:
                g['a']+=a;g['b']+=a;g['line_breaks']=[i+a for i in g['line_breaks']]
                groups.append(g)
        groups.extend(copy.deepcopy(g) for g in old['groups'] if not any(a<=g['a']<b for a,b in regions))
        groups.sort(key=lambda g:g['a']);new['groups']=groups
        new['forced_boundaries']=sorted(set(old.get('forced_boundaries',[]))|{c for c in cuts if 0<c<n})
        for left,right in zip(groups,groups[1:]):
            left['end']=right['start'];left['end_frame']=right['start_frame'];left['measured_end']=right['measured_start']
    store.bind_source(new,state['raw'],state['wordfile'],measurement_overrides=(old or {}).get('measurement_overrides',[]))
    return new

def prepare(selected,target,doc,state):
    """Write a complete private set only after inspect has validated all text."""
    selected,target=Path(selected),Path(target);target.mkdir(parents=True,exist_ok=True)
    plan=_regroup(state,(state['old'] or {}).get('language') or doc.get('subtitle_lang') or 'en')
    for path in copied_files(selected):
        dest=target/path.relative_to(selected);dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,dest)
    (target/state['srt']).write_text(store.serialize_srt(plan),'utf8')
    (target/'phrase-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
    (target/'caption-policy.json').write_text(json.dumps(dict(schema=1,clock=phrasing.POLICY,phrase_policy=phrasing.POLICY)),'utf8')
    meta=copy.deepcopy(state['meta']);meta.update(srt=state['srt'],caption_clock=phrasing.POLICY,display_edits_file='subtitle-display.json',scene_partition=signature(doc))
    meta['scene_caption_refresh']=dict(source=str(selected),source_words_unchanged=True,source_audio_unchanged=True)
    (target/'_result.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
    return target/state['srt']

def copied_files(selected):
    selected=Path(selected);files=[]
    for path in sorted(selected.iterdir()):
        if path.is_symlink():raise Pending('Subtitle source contains a link.')
        if path.is_file() and (path.suffix.lower() in ('.srt','.tsv','.json','.docx') or path.name.startswith('audio.') or path.name=='voiceover_trimmed.mp3'):
            files.append(path)
        elif path.name=='_inputs' and path.is_dir():
            files.extend(input_files(path))
    return files


def input_files(directory):
    if Path(directory).is_symlink():raise Pending('Subtitle source contains a link.')
    files=[]
    for path in sorted(Path(directory).rglob('*')):
        if path.is_symlink():raise Pending('Subtitle source contains a link.')
        if path.is_file():files.append(path)
    return files


def _signature(base,files):
    result=[]
    for path in files:
        digest=hashlib.sha256()
        with path.open('rb') as source:
            for chunk in iter(lambda:source.read(1024*1024),b''):digest.update(chunk)
        stat=path.stat();result.append((str(path.relative_to(base)),stat.st_size,stat.st_mtime_ns,digest.hexdigest()))
    return result


def source_signature(selected):
    """Detect any copied source changing, including audio and private inputs."""
    selected=Path(selected)
    return _signature(selected,copied_files(selected))


def inputs_signature(directory):
    directory=Path(directory)
    return _signature(directory,input_files(directory)) if directory.is_dir() else None
