"""Prepare project-owned showcase references with one persistent background task.

Prepare fills missing packs; Change creates a new set and keeps the previous versions.
Exact transparent packshots are composited locally.
No automatic retry ever submits a second paid job.
"""
import copy
import hashlib
import re
import shutil
import tempfile
import threading
import time
import uuid
from pathlib import Path
from flask import abort, jsonify, request

PLATE_PROMPT = (
    'One continuous photorealistic premium botanical product photograph of an EMPTY broad solid '
    'natural wood or pale stone display pedestal. The whole pedestal belongs to the same scene as '
    'its surroundings: continuous perspective, material grain, daylight and natural shadows. '
    'A low camera sees its broad flat horizontal TOP and a modest front face. The top extends from '
    'about 62 to 78 percent of frame height, and across the central 80 percent of the frame, with '
    'clearly visible rear and front edges. Keep this entire top empty and unobstructed for product packs. '
    'A real commercial product photography set, photographed with a 70mm lens at f/5.6: '
    'the pedestal top is sharply focused, rear foliage is softly out of focus, with realistic optical depth. '
    'Large soft window daylight from front-left plus gentle neutral bounce fill from front-right. '
    'Natural exposure, restrained saturation and believable soft shadows; no dramatic spotlight or coloured glow. '
    'Fine tactile material texture, slight natural imperfections, modest understated greenery at the sides. '
    'Avoid a plastic CGI look, synthetic blur, excessive tropical foliage, oversharpening or polished fantasy scenery. '
    'Leave generous clear space ABOVE the pedestal for the product, with an uncluttered background. '
    'No split image, collage, horizontal splice, mismatched upper/lower halves or cut-and-paste backdrop. '
    'No foreground objects covering the stand, no products, bottles, jars, packaging, people, text or logos. '
    'Photograph the pedestal and environment together as one coherent physical set. '
)

SET_VARIANTS = (
    'A low warm oak plinth on a pale natural tabletop near a daylight window; a few olive branches behind it.',
    'A low ivory travertine plinth in a quiet conservatory; muted sage foliage and soft warm-grey surroundings.',
    'A low light walnut display stand on warm limestone; sparse softly blurred leaves and a calm outdoor garden beyond.',
    'A low pale limestone block on a natural wood table, beside a softly lit window; restrained eucalyptus at the edges.',
    'A low weathered oak stand in a sheltered botanical courtyard; gentle morning daylight and distant natural greenery.',
    'A low matte sand-coloured stone pedestal in a bright minimalist botanical studio, with a few small natural branches.',
)


def version_urls(showcase, active):
    """Only versions connected to this exact showcase, never every image with the same pack label."""
    if active not in showcase.get('urls',[]): return []
    history=[h for h in showcase.get('history',[]) if isinstance(h,dict) and isinstance(h.get('url'),str) and isinstance(h.get('replaced_by'),str)]
    connected={active}
    for _ in range(len(history)+1):
        before=len(connected)
        for h in history:
            if h['url'] in connected or h['replaced_by'] in connected:connected.update((h['url'],h['replaced_by']))
        if len(connected)==before:break
    ordered=[]
    for h in history:
        for url in (h['url'],h['replaced_by']):
            if url in connected and url not in ordered:ordered.append(url)
    if active not in ordered:ordered.append(active)
    return ordered


def register(app, ns):
    running = ns['_user_job_registry']('showcase-reference-workers')
    guard = threading.RLock()
    active = ('queued','submitting','generating','composing')

    def basis(doc):
        p=doc.get('product') or {}
        return copy.deepcopy({k:p.get(k) for k in ('urls','names','name','form')})

    def read(project, token=None):
        doc=ns['load_doc'](project)
        job=(doc or {}).get('product',{}).get('showcase_job',{})
        return (doc,job) if doc and (not token or job.get('token')==token) else (None,{})

    def update(project, token, **fields):
        with ns['_project_lock'](project):
            doc,job=read(project,token)
            if not doc or job.get('status')=='cancelled': return False
            job.update(fields);ns['save_doc'](project,doc);return True

    def pack_files(doc,d,counts):
        from PIL import Image
        files=[]
        for n in counts:
            rel=ns['_pack_url'](doc,n)
            p=(d/rel).resolve() if rel else None
            if not p or not p.is_relative_to(d.resolve()) or not p.is_file():
                raise ValueError('Upload and label the exact %d-unit product image first.' % n)
            with Image.open(p) as im:
                if 'A' not in im.getbands() or im.getchannel('A').getextrema()[0]>20:
                    raise ValueError('The %d-unit product must be a transparent PNG so its exact packaging can be preserved.' % n)
            files.append(p)
        return files

    def work(project):
        token=None
        try:
            with ns['_project_lock'](project):
                doc,live=read(project)
                if not doc or live.get('status') not in active:return
                job=copy.deepcopy(live);token=job['token'];d,_=ns['proj_dir'](project)
                files=pack_files(doc,d,job['counts'])
                if basis(doc)!=job['basis']:raise ValueError('Product references changed; your current settings were kept.')
                plate=d/job['plate'];task=job.get('taskId')
                if job.get('repair') and (not plate.is_file() or hashlib.sha256(plate.read_bytes()).hexdigest()!=job.get('plate_hash')):
                    raise ValueError('The saved background changed or is missing. No AI generation was started.')
                if not plate.is_file() and not task:
                    if job['status']!='queued':raise ValueError('Submission status is unknown. Check the provider before starting again.')
                    live.update(status='submitting',progress=5,started=time.time());ns['save_doc'](project,doc)
            with tempfile.TemporaryDirectory(prefix='showcase-result-') as tmp:
                tmp=Path(tmp);background=plate
                if not plate.is_file():
                    if not task:
                        model,inputs=ns['build_kie_image_request'](job.get('model') or ns['IMAGE_MODEL'],job.get('prompt') or PLATE_PROMPT,[],aspect=job['aspect'],resolution='2K')
                        task,error=ns['kie_create'](model,inputs)
                        if not task:raise ValueError(error or 'The provider did not return a task ID. Check your account before resubmitting.')
                        # Retain an acknowledged task even if Stop was pressed during submission.
                        with ns['_project_lock'](project):
                            current,j=read(project,token)
                            if not current:return
                            j['taskId']=task
                            if j.get('status')!='cancelled':j.update(status='generating',started=time.time())
                            ns['save_doc'](project,current)
                            if j.get('status')=='cancelled':return
                    started=time.time()
                    while True:
                        with ns['_project_lock'](project):
                            current,j=read(project,token)
                            if not current or j.get('status')=='cancelled':return
                            if basis(current)!=job['basis']:raise ValueError('Product settings changed; result was not applied.')
                        try:rec=ns['kie_record'](task)
                        except Exception:rec={}
                        state=(rec.get('data') or {}).get('state')
                        if state=='fail':
                            update(project,token,provider_failed=True)
                            raise ValueError('The provider could not create the background. No automatic retry was sent.')
                        url=ns['result_url'](rec) if state=='success' else None
                        if url:
                            update(project,token,provider_complete=True)
                            background=tmp/'background.png';ns['download_as_png'](url,background);break
                        if time.time()-started>=ns.get('IMG_GEN_TIMEOUT',1800):
                            raise ValueError('The provider has not confirmed a result. Check Existing Result; no second generation was sent.')
                        update(project,token,progress=None)
                        time.sleep(2)
                if not update(project,token,status='composing',progress=85):return
                outputs=[]
                for count,pack in zip(job['counts'],files):
                    output=tmp/('%d.png'%count)
                    ns['compose_showcase'](background,[pack],output);outputs.append((count,output))
                with ns['_project_lock'](project):
                    current,j=read(project,token)
                    if not current or j.get('status')=='cancelled':return
                    if basis(current)!=job['basis'] or ns['project_image_aspect'](current)!=job['aspect'] or [hashlib.sha256(p.read_bytes()).hexdigest() for p in files]!=job['hashes']:
                        raise ValueError('Product references changed; your newer settings were kept.')
                    sc=current['product'].setdefault('showcase',{});sc.setdefault('urls',[]);sc.setdefault('names',{})
                    targets=job.get('change_targets') or job.get('repair_targets') or {}
                    if job.get('change') and any(ns['_showcase_by_count'](current,int(n))!=old or (old and sc['names'].get(old)!=job['target_names'].get(old)) for n,old in targets.items()):
                        raise ValueError('A showcase selection changed while generating. Your newer choices were kept.')
                    if job.get('repair') and (hashlib.sha256(plate.read_bytes()).hexdigest()!=job['plate_hash'] or any(old not in sc['urls'] or not (d/old).is_file() or hashlib.sha256((d/old).read_bytes()).hexdigest()!=job['source_hashes'][old] for old in targets.values())):
                        raise ValueError('A showcase changed while repairing; your newer choices were kept.')
                    owned=[];committed=False
                    try:
                        (d/'refs').mkdir(exist_ok=True)
                        if not plate.is_file():
                            # Exclusive claim; a concurrent job cannot overwrite an existing backdrop.
                            rel=ns['_claim_new_file'](d,lambda:'refs/showcase_botanical_'+uuid.uuid4().hex+'.png')
                            owned.append(d/rel);shutil.copyfile(background,d/rel);j['plate']=rel
                        for count,output in outputs:
                            old=targets.get(str(count))
                            if not old and ns['_showcase_by_count'](current,count):continue
                            rel=ns['_claim_new_file'](d,lambda:'refs/showcase_%d_%s.png'%(count,uuid.uuid4().hex))
                            owned.append(d/rel);shutil.copyfile(output,d/rel)
                            if old:
                                sc['urls'][sc['urls'].index(old)]=rel
                                sc['names'][rel]=sc['names'].pop(old,'%d bottles'%count)
                                sc.setdefault('history',[]).append(dict(url=old,name=sc['names'][rel],replaced_by=rel,created=time.time()))
                                j.setdefault('replacements',{})[old]=rel
                                for scene in current.get('scenes',[]):
                                    if scene.get('showcase')==old:scene['showcase']=rel
                            else:
                                sc['urls'].append(rel);sc['names'][rel]='%d bottles'%count
                            sc.setdefault('variants',{})[rel]=dict(plate=j['plate'],variant=job.get('variant'),created=time.time(),count=count,model=job.get('model'))
                        j.update(status='ready',progress=100,error=None,completed=time.time(),composition_version=2)
                        ns['save_doc'](project,current);committed=True
                    finally:
                        if not committed:
                            for p in owned:ns['_drop_own_file'](p)
        except Exception as error:
            if token:update(project,token,status='error',error=str(error)[:600])
        finally:
            with guard:running.pop(project,None)

    def start(project):
        with guard:
            if running.get(project):return
            doc,job=read(project)
            if not doc or job.get('status') not in active:return
            running[project]=True
            try:ns['_KeyThread'](target=work,args=(project,),daemon=True).start()
            except Exception:running.pop(project,None);raise

    def reply(doc,job):
        return jsonify(job={k:job.get(k) for k in ('token','status','progress','counts','error','taskId','provider_failed','repair','change','replacements')},product=doc.get('product',{}))

    @app.post('/api/product/<project>/showcase/prepare', endpoint='prepare_showcase_references')
    def prepare(project):
        body=request.get_json(silent=True) or {}
        selected_model=ns['image_model_choice'](body.get('model'))
        with ns['_project_lock'](project):
            doc,job=read(project)
            if not doc:abort(404)
            d,_=ns['proj_dir'](project)
            if body.get('recover'):
                if not job.get('taskId') or job.get('provider_failed') or basis(doc)!=job.get('basis'):
                    return jsonify(error='There is no unchanged provider task to recover.'),409
                job.update(status='generating',error=None)
            elif job.get('status') in active:
                pass  # idempotent double-click / another tab
            elif body.get('change'):
                if job.get('status')=='error' and not job.get('provider_failed') and not job.get('provider_complete'):
                    return jsonify(error='Check Existing Result first. The previous submission may still be processing.'),409
                counts=body.get('counts')
                if not isinstance(counts,list) or not counts or len(counts)>12 or any(type(n) is not int or not 1<=n<=24 for n in counts):
                    return jsonify(error='Choose the product packs to change.'),400
                counts=sorted(set(counts))
                try:files=pack_files(doc,d,counts)
                except ValueError as error:return jsonify(error=str(error)),400
                err=ns['_keys_ok'](('kie',))
                if err:return err
                sc=doc['product'].get('showcase') or {};targets={str(n):ns['_showcase_by_count'](doc,n) for n in counts}
                variant=(int(job.get('variant',-1))+1)%len(SET_VARIANTS)
                job=dict(token=uuid.uuid4().hex,status='queued',progress=0,counts=counts,basis=basis(doc),aspect=ns['project_image_aspect'](doc),
                    model=selected_model,plate='refs/showcase_botanical_'+uuid.uuid4().hex+'.png',change=True,change_targets=targets,
                    target_names={u:(sc.get('names') or {}).get(u) for u in targets.values() if u},variant=variant,
                    prompt=PLATE_PROMPT+' Set direction: '+SET_VARIANTS[variant],hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files])
                doc['product']['showcase_job']=job
            elif body.get('repair'):
                plate=job.get('plate') or ''
                source=(d/plate).resolve()
                if not plate.startswith('refs/') or not source.is_relative_to((d/'refs').resolve()) or not source.is_file():
                    return jsonify(error='The original showcase background is missing. No credits were used.'),400
                if basis(doc)!=job.get('basis'):
                    return jsonify(error='Product references changed since these showcases were prepared. Keep the current pictures or prepare new showcases.'),409
                sc=doc['product'].get('showcase') or {};targets={}
                for rel in sc.get('urls',[]):
                    match=re.fullmatch(r'refs/showcase_(\d+)_[0-9a-f]{32}\.png',rel)
                    if match and (d/rel).is_file():targets.setdefault(int(match.group(1)),rel)
                if not targets:return jsonify(error='No locally prepared showcases are available to repair.'),400
                from PIL import Image
                with Image.open(source) as im:plate_size=im.size
                for rel in targets.values():
                    with Image.open(d/rel) as im:
                        if im.size!=plate_size:return jsonify(error='These showcases use different background sizes. Keep them and prepare a matching set instead.'),409
                counts=sorted(targets)
                try:files=pack_files(doc,d,counts)
                except ValueError as error:return jsonify(error=str(error)),400
                job=dict(token=uuid.uuid4().hex,status='queued',progress=0,counts=counts,basis=basis(doc),aspect=job['aspect'],plate=plate,
                    repair=True,repair_targets={str(n):u for n,u in targets.items()},plate_hash=hashlib.sha256(source.read_bytes()).hexdigest(),
                    source_hashes={u:hashlib.sha256((d/u).read_bytes()).hexdigest() for u in targets.values()},hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files])
                doc['product']['showcase_job']=job
            else:
                if job.get('status')=='error' and not job.get('provider_failed') and not job.get('provider_complete'):
                    return jsonify(error='Check Existing Result first. The previous submission may still be processing.'),409
                counts=body.get('counts')
                if not isinstance(counts,list) or not counts or len(counts)>12 or any(type(n) is not int or not 1<=n<=24 for n in counts):
                    return jsonify(error='Choose the product packs to prepare.'),400
                counts=sorted(set(counts));counts=[n for n in counts if not ns['_showcase_by_count'](doc,n)]
                if not counts:return reply(doc,dict(status='ready',progress=100,counts=[]))
                try:files=pack_files(doc,d,counts)
                except ValueError as error:return jsonify(error=str(error)),400
                aspect=ns['project_image_aspect'](doc)
                plate=job.get('plate') if job.get('aspect')==aspect else None
                if not plate or not (d/plate).is_file():
                    err=ns['_keys_ok'](('kie',))
                    if err:return err
                    plate='refs/showcase_botanical_'+uuid.uuid4().hex+'.png'
                job=dict(token=uuid.uuid4().hex,status='queued',progress=0,counts=counts,basis=basis(doc),aspect=aspect,plate=plate,model=selected_model,
                    variant=job.get('variant',0),prompt=PLATE_PROMPT+' Set direction: '+SET_VARIANTS[int(job.get('variant',0))%len(SET_VARIANTS)],hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files])
                doc['product']['showcase_job']=job
            ns['save_doc'](project,doc)
        start(project);return reply(doc,job)

    @app.post('/api/product/<project>/showcase/use', endpoint='use_showcase_version')
    def use_version(project):
        body=request.get_json(silent=True) or {};old=body.get('current');url=body.get('url')
        with ns['_project_lock'](project):
            doc,job=read(project)
            if not doc:abort(404)
            if job.get('status') in active:return jsonify(error='Wait for showcase generation to finish before choosing a version.'),409
            sc=doc.get('product',{}).get('showcase') or {};d,_=ns['proj_dir'](project)
            if not isinstance(old,str) or not isinstance(url,str) or url not in version_urls(sc,old):
                return jsonify(error='This version is no longer part of the selected showcase.'),409
            source=(d/url).resolve()
            if not url.startswith('refs/') or not source.is_relative_to((d/'refs').resolve()) or not source.is_file():
                return jsonify(error='The original version file is missing.'),404
            if url!=old:
                sc['urls'][sc['urls'].index(old)]=url;sc.setdefault('names',{})[url]=sc['names'].pop(old,'Showcase')
                for scene in doc.get('scenes',[]):
                    if scene.get('showcase')==old:scene['showcase']=url
                ns['save_doc'](project,doc)
            return ns['_product_reply'](doc)

    @app.get('/api/product/<project>/showcase/status', endpoint='showcase_reference_status')
    def status(project):
        doc,job=read(project)
        if not doc:abort(404)
        start(project);return reply(doc,job)

    @app.post('/api/product/<project>/showcase/stop', endpoint='stop_showcase_references')
    def stop(project):
        with ns['_project_lock'](project):
            doc,job=read(project)
            if not doc:abort(404)
            if job.get('status') in active:job.update(status='cancelled')
            ns['save_doc'](project,doc)
        return reply(doc,job)
