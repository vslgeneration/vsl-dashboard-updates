"""Prepare project-owned showcase references with one persistent background task.

Only the empty set is generated. Exact transparent packshots are composited locally.
No automatic retry ever submits a second paid job.
"""
import copy
import hashlib
import shutil
import tempfile
import threading
import time
import uuid
from pathlib import Path
from flask import abort, jsonify, request

PLATE_PROMPT = (
    'Premium botanical product photography: an EMPTY broad natural wood or pale stone pedestal, '
    'a simple flat horizontal top with generous clear space in the centre. Pedestal top at 76 percent '
    'of frame height. Soft daylight, out-of-focus deep green leaves at the sides and in the background, '
    'gentle organic bokeh, refined warm natural materials. Front three-quarter view, almost straight on. '
    'Keep the central 80 percent of the pedestal empty and the central background softly blurred. '
    'No foreground leaves obscuring the centre, no products, bottles, jars, packaging, people, text or logos. '
    'This is an empty photography set on which the real client product will be placed later. '
)

def register(app, ns):
    running = ns['_user_job_registry']('showcase-reference-workers')
    guard = threading.RLock()
    active = ('queued','submitting','generating','composing')

    def basis(doc):
        p=doc.get('product') or {}
        return copy.deepcopy({k:p.get(k) for k in ('urls','names','name','form')})

    def read(project, token=None):
        doc=ns['load_doc'](project)
        job=(doc or {}).get('product',{}).get('showcase_job',{})
        return (doc,job) if doc and (not token or job.get('token')==token) else (None,{})

    def update(project, token, **fields):
        with ns['_project_lock'](project):
            doc,job=read(project,token)
            if not doc or job.get('status')=='cancelled': return False
            job.update(fields);ns['save_doc'](project,doc);return True

    def pack_files(doc,d,counts):
        from PIL import Image
        files=[]
        for n in counts:
            rel=ns['_pack_url'](doc,n)
            p=(d/rel).resolve() if rel else None
            if not p or not p.is_relative_to(d.resolve()) or not p.is_file():
                raise ValueError('Upload and label the exact %d-unit product image first.' % n)
            with Image.open(p) as im:
                if 'A' not in im.getbands() or im.getchannel('A').getextrema()[0]>20:
                    raise ValueError('The %d-unit product must be a transparent PNG so its exact packaging can be preserved.' % n)
            files.append(p)
        return files

    def work(project):
        token=None
        try:
            with ns['_project_lock'](project):
                doc,live=read(project)
                if not doc or live.get('status') not in active:return
                job=copy.deepcopy(live);token=job['token'];d,_=ns['proj_dir'](project)
                files=pack_files(doc,d,job['counts'])
                if basis(doc)!=job['basis']:raise ValueError('Product references changed; your current settings were kept.')
                plate=d/job['plate'];task=job.get('taskId')
                if not plate.is_file() and not task:
                    if job['status']!='queued':raise ValueError('Submission status is unknown. Check the provider before starting again.')
                    live.update(status='submitting',progress=5,started=time.time());ns['save_doc'](project,doc)
            with tempfile.TemporaryDirectory(prefix='showcase-result-') as tmp:
                tmp=Path(tmp);background=plate
                if not plate.is_file():
                    if not task:
                        model,inputs=ns['build_kie_image_request'](ns['IMAGE_MODEL'],PLATE_PROMPT,[],aspect=job['aspect'],resolution='2K')
                        task,error=ns['kie_create'](model,inputs)
                        if not task:raise ValueError(error or 'The provider did not return a task ID. Check your account before resubmitting.')
                        # Retain an acknowledged task even if Stop was pressed during submission.
                        with ns['_project_lock'](project):
                            current,j=read(project,token)
                            if not current:return
                            j['taskId']=task
                            if j.get('status')!='cancelled':j.update(status='generating',started=time.time())
                            ns['save_doc'](project,current)
                            if j.get('status')=='cancelled':return
                    started=time.time()
                    while True:
                        with ns['_project_lock'](project):
                            current,j=read(project,token)
                            if not current or j.get('status')=='cancelled':return
                            if basis(current)!=job['basis']:raise ValueError('Product settings changed; result was not applied.')
                        try:rec=ns['kie_record'](task)
                        except Exception:rec={}
                        state=(rec.get('data') or {}).get('state')
                        if state=='fail':
                            update(project,token,provider_failed=True)
                            raise ValueError('The provider could not create the background. No automatic retry was sent.')
                        url=ns['result_url'](rec) if state=='success' else None
                        if url:
                            background=tmp/'background.png';ns['download_as_png'](url,background);break
                        if time.time()-started>=ns.get('IMG_GEN_TIMEOUT',1800):
                            raise ValueError('The provider has not confirmed a result. Check Existing Result; no second generation was sent.')
                        update(project,token,progress=None)
                        time.sleep(2)
                if not update(project,token,status='composing',progress=85):return
                outputs=[]
                for count,pack in zip(job['counts'],files):
                    output=tmp/('%d.png'%count)
                    ns['compose_showcase'](background,[pack],output);outputs.append((count,output))
                with ns['_project_lock'](project):
                    current,j=read(project,token)
                    if not current or j.get('status')=='cancelled':return
                    if basis(current)!=job['basis'] or [hashlib.sha256(p.read_bytes()).hexdigest() for p in files]!=job['hashes']:
                        raise ValueError('Product references changed; your newer settings were kept.')
                    sc=current['product'].setdefault('showcase',{});sc.setdefault('urls',[]);sc.setdefault('names',{})
                    owned=[];committed=False
                    try:
                        (d/'refs').mkdir(exist_ok=True)
                        if not plate.is_file():
                            # Exclusive claim; a concurrent job cannot overwrite an existing backdrop.
                            rel=ns['_claim_new_file'](d,lambda:'refs/showcase_botanical_'+uuid.uuid4().hex+'.png')
                            owned.append(d/rel);shutil.copyfile(background,d/rel);j['plate']=rel
                        for count,output in outputs:
                            if ns['_showcase_by_count'](current,count):continue
                            rel=ns['_claim_new_file'](d,lambda:'refs/showcase_%d_%s.png'%(count,uuid.uuid4().hex))
                            owned.append(d/rel);shutil.copyfile(output,d/rel)
                            sc['urls'].append(rel);sc['names'][rel]='%d bottles'%count
                        j.update(status='ready',progress=100,error=None,completed=time.time())
                        ns['save_doc'](project,current);committed=True
                    finally:
                        if not committed:
                            for p in owned:ns['_drop_own_file'](p)
        except Exception as error:
            if token:update(project,token,status='error',error=str(error)[:600])
        finally:
            with guard:running.pop(project,None)

    def start(project):
        with guard:
            if running.get(project):return
            doc,job=read(project)
            if not doc or job.get('status') not in active:return
            running[project]=True
            try:ns['_KeyThread'](target=work,args=(project,),daemon=True).start()
            except Exception:running.pop(project,None);raise

    def reply(doc,job):
        return jsonify(job={k:job.get(k) for k in ('token','status','progress','counts','error','taskId','provider_failed')},product=doc.get('product',{}))

    @app.post('/api/product/<project>/showcase/prepare', endpoint='prepare_showcase_references')
    def prepare(project):
        body=request.get_json(silent=True) or {}
        with ns['_project_lock'](project):
            doc,job=read(project)
            if not doc:abort(404)
            d,_=ns['proj_dir'](project)
            if body.get('recover'):
                if not job.get('taskId') or job.get('provider_failed') or basis(doc)!=job.get('basis'):
                    return jsonify(error='There is no unchanged provider task to recover.'),409
                job.update(status='generating',error=None)
            elif job.get('status') in active:
                pass  # idempotent double-click / another tab
            else:
                if job.get('status')=='error' and not job.get('provider_failed'):
                    return jsonify(error='Check Existing Result first. The previous submission may still be processing.'),409
                counts=body.get('counts')
                if not isinstance(counts,list) or not counts or len(counts)>12 or any(type(n) is not int or not 1<=n<=24 for n in counts):
                    return jsonify(error='Choose the product packs to prepare.'),400
                counts=sorted(set(counts));counts=[n for n in counts if not ns['_showcase_by_count'](doc,n)]
                if not counts:return reply(doc,dict(status='ready',progress=100,counts=[]))
                try:files=pack_files(doc,d,counts)
                except ValueError as error:return jsonify(error=str(error)),400
                aspect=ns['project_image_aspect'](doc)
                plate=job.get('plate') if job.get('aspect')==aspect else None
                if not plate or not (d/plate).is_file():
                    err=ns['_keys_ok'](('kie',))
                    if err:return err
                    plate='refs/showcase_botanical_'+uuid.uuid4().hex+'.png'
                job=dict(token=uuid.uuid4().hex,status='queued',progress=0,counts=counts,basis=basis(doc),aspect=aspect,plate=plate,
                    hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files])
                doc['product']['showcase_job']=job
            ns['save_doc'](project,doc)
        start(project);return reply(doc,job)

    @app.get('/api/product/<project>/showcase/status', endpoint='showcase_reference_status')
    def status(project):
        doc,job=read(project)
        if not doc:abort(404)
        start(project);return reply(doc,job)

    @app.post('/api/product/<project>/showcase/stop', endpoint='stop_showcase_references')
    def stop(project):
        with ns['_project_lock'](project):
            doc,job=read(project)
            if not doc:abort(404)
            if job.get('status') in active:job.update(status='cancelled')
            ns['save_doc'](project,doc)
        return reply(doc,job)
