"""Hide only spoken words duplicated by visible on-screen text; keep canonical speech intact."""
import copy
import math
import re
import unicodedata


def tokens(text):
    normalized=unicodedata.normalize('NFKC',str(text)).casefold().replace('\u0307','').replace('ı','i')
    return re.findall(r'[^\W_]+', normalized, re.UNICODE)


def scene_windows(scenes, cues, total, words):
    import premiere_export as pe
    starts=pe.word_scene_starts(scenes,words) if words else None
    ranges,included=pe.scene_ranges_for_words(scenes,cues,total,words)
    windows=[]
    for scene,(start,end),include in zip(scenes,ranges,included):
        if not include: continue
        for text in scene.get('texts') or []:
            if not str(text.get('text','')).strip():continue
            a=max(0,min(1,float(text.get('text_in',0) or 0)))
            b=max(0,min(1,float(text.get('text_out',1) if text.get('text_out') is not None else 1)))
            if b>a:windows.append(dict(text=text['text'],start=start+(end-start)*a,end=start+(end-start)*b))
    return windows



def visibility_source(captions):
    # A replacement/regenerated track must never inherit another track's toggles.
    import hashlib,json
    return hashlib.sha256(json.dumps(captions,sort_keys=True,ensure_ascii=False).encode('utf8')).hexdigest()


def word_key(word):
    return [str(word.get('text','')),round(float(word.get('start',0))*60)]


def visibility_rules(edits,source):
    rules=[]
    for identity,record in edits.items():
        if not identity.startswith('visibility_'):continue
        if not isinstance(record,dict) or record.get('kind')!='caption-visibility-v1':raise ValueError('Invalid saved subtitle visibility.')
        if (type(record.get('enabled')) is not bool or not isinstance(record.get('owner'),str)
                or not isinstance(record.get('source'),str) or type(record.get('order')) is not int
                or not isinstance(record.get('words'),list)
                or any(not isinstance(w,list) or len(w)!=2 or not isinstance(w[0],str) or type(w[1]) is not int for w in record['words'])):
            raise ValueError('Invalid saved subtitle visibility.')
        if (not record['owner'] or not record['source'] or not record['words'] and not record['owner'].startswith('custom_')
                or type(record.get('start')) not in (int,float) or type(record.get('end')) not in (int,float)
                or not math.isfinite(record['start']) or not math.isfinite(record['end'])
                or record['start']<0 or record['end']-record['start']<1/60-1e-8):
            raise ValueError('Invalid saved subtitle visibility.')
        if record['source']==source:rules.append(dict(record,_id=identity))
    return sorted(rules,key=lambda rule:rule['order'])


def visibility_record(captions,cue,enabled,edits):
    if type(enabled) is not bool:raise ValueError('Choose whether to enable this subtitle.')
    if not cue.get('display_id') or not str(cue.get('text','')).strip():raise ValueError('Choose a subtitle with text.')
    order=max((r.get('order',0) for k,r in edits.items() if k.startswith('visibility_') and isinstance(r,dict) and type(r.get('order')) is int),default=0)+1
    return dict(kind='caption-visibility-v1',enabled=enabled,source=visibility_source(captions),
                owner=cue.get('_visibility_owner') or cue['display_id'],
                words=copy.deepcopy(cue.get('_visibility_word_keys') or [word_key(w) for w in cue.get('words',[])]),
                start=cue['start'],end=cue['end'],order=order)


def response(captions,edits,windows,pacing=None):
    return dict(captions=display(captions,edits,windows,pacing=pacing),
                caption_items=display(captions,edits,windows,pacing=pacing,include_hidden=True))

def parts(captions, windows, rules=()):
    """Keep all timed word groups; delivery filters hidden groups afterwards."""
    import subtitle_edits
    flat=[]
    for ci,cue in enumerate(captions):
        for wi,word in enumerate(cue.get('words') or []):
            for token in tokens(word.get('text','')):flat.append((token,ci,wi,word))
    hidden=set();hay=[row[0] for row in flat]
    for window in windows:
        needle=tokens(window.get('text',''))
        if not needle:continue
        for i in range(len(hay)-len(needle)+1):
            if hay[i:i+len(needle)]!=needle:continue
            for _,ci,wi,word in flat[i:i+len(needle)]:
                if min(float(word['end']),float(window['end']))-max(float(word['start']),float(window['start']))>.02:hidden.add((ci,wi))
    result=[]
    for ci,original in enumerate(captions):
        cue=copy.deepcopy(original);words=cue.get('words') or []
        owner=cue.get('_visibility_owner') or cue.get('display_id')
        cue['_visibility_owner']=owner;cue['_visibility_word_keys']=[word_key(w) for w in words]
        selected=[r for r in rules if r['owner']==owner]
        state=[]
        for i,w in enumerate(words):
            rule=next((r for r in reversed(selected) if word_key(w) in r['words']),None)
            auto=(ci,i) in hidden
            state.append((not rule['enabled'] if rule else auto,auto,rule))
        if not any(s[1] or s[2] for s in state):
            if not words and selected:cue['display_hidden']=not selected[-1]['enabled']
            result.append((cue,False));continue
        from render_video import cap_units
        breaks=set();count=0
        for line in str(cue.get('text','')).replace('\r\n','\n').replace('\r','\n').split('\n'):
            if count:breaks.add(count)
            count+=len(cap_units(line))
        groups=[]
        for i,w in enumerate(words):
            flag,auto,rule=state[i];signature=(flag,auto,rule.get('_id') if rule else None)
            if not groups or groups[-1][0]!=signature:groups.append((signature,[],rule))
            groups[-1][1].append((i,w))
        for gi,(signature,group,rule) in enumerate(groups):
            first,last=group[0][0],group[-1][0]
            start=cue['start'] if first==0 else max(cue['start'],group[0][1]['start'])
            end=cue['end'] if last==len(words)-1 else min(cue['end'],group[-1][1]['end'])
            if rule:
                # Toggling a paced caption keeps its exact authored frame edges.
                if word_key(group[0][1])==rule['words'][0]:start=max(cue['start'],float(rule['start']))
                if word_key(group[-1][1])==rule['words'][-1]:end=min(cue['end'],float(rule['end']))
            if end-start<1/60:continue
            text=''.join(('\n' if i in breaks else ' ')+w['text'] if n else w['text'] for n,(i,w) in enumerate(group))
            if subtitle_edits.canonical(cue):text=subtitle_edits.word_slice_text(cue,first,last+1)
            # Only remnants CREATED by duplicate OST suppression are candidates.
            # Keep them on the editable timeline; a manual Enable always wins later.
            scrap = not signature[0] and any(s[1] for s in state) and round(end*60)-round(start*60)<24
            piece=copy.deepcopy(cue);piece.update(text=text,start=start if subtitle_edits.canonical(cue) else round(start*60)/60,end=end if subtitle_edits.canonical(cue) else round(end*60)/60,
                words=[copy.deepcopy(w) for _,w in group],auto_ost=True,display_hidden=signature[0] or scrap,
                auto_ost_scrap=scrap,
                hidden_reason='ost-fragment' if scrap else 'manual' if rule and not rule['enabled'] else 'ost' if signature[0] else '',
                _visibility_word_keys=[word_key(w) for _,w in group])
            result.append((piece,True))
    return result



def visibility_parts(cue,rules):
    """Apply explicit choices after automatic pagination, preserving untouched pages."""
    import subtitle_edits
    owner=cue.get('_visibility_owner') or cue.get('display_id')
    selected=[r for r in rules if r['owner']==owner]
    if not selected:return [cue]
    whole=next((r for r in reversed(selected) if r.get('_id','').removeprefix('visibility_')==cue.get('display_id')),None)
    words=cue.get('words') or []
    keys=cue.get('_visibility_word_keys') or [word_key(w) for w in words]
    # Exact IDs preserve authored replacement words. A newer partial choice
    # still wins if a font/pacing change later merges this page into its owner.
    matched=[next((r for r in reversed(selected) if (not whole or r['order']>=whole['order']) and key in r['words']),whole) for key in keys]
    if not words:
        result=copy.deepcopy(cue);result['display_hidden']=not selected[-1]['enabled'];return [result]
    if not any(matched):return [cue]
    if all(r is matched[0] for r in matched):
        result=copy.deepcopy(cue);rule=matched[0]
        result['display_hidden']=not rule['enabled'];result['hidden_reason']='manual' if result['display_hidden'] else ''
        return [result]
    groups=[]
    for i,rule in enumerate(matched):
        if not groups or groups[-1][0] is not rule:groups.append((rule,[]))
        groups[-1][1].append(i)
    result=[]
    from render_video import cap_units
    breaks=set();count=0
    for line in str(cue.get('text','')).replace('\r\n','\n').replace('\r','\n').split('\n'):
        if count:breaks.add(count)
        count+=len(cap_units(line))
    for rule,indexes in groups:
        a,b=indexes[0],indexes[-1]+1
        start=cue['start'] if a==0 else max(cue['start'],words[a]['start'])
        end=cue['end'] if b==len(words) else min(cue['end'],words[b-1]['end'])
        if rule:
            if keys[a]==rule['words'][0]:start=max(cue['start'],rule['start'])
            if keys[b-1]==rule['words'][-1]:end=min(cue['end'],rule['end'])
        # Keep the neighboring piece outside the exact user-selected interval.
        elif a and matched[a-1]:start=max(start,matched[a-1]['end'])
        if not rule and b<len(words) and matched[b]:end=min(end,matched[b]['start'])
        if end-start<1/60-1e-8:continue
        piece=copy.deepcopy(cue)
        for field in ('display_id','display_base','display_edited'):piece.pop(field,None)
        piece.update(text=''.join(('\n' if i in breaks else ' ')+words[i]['text'] if i>a else words[i]['text'] for i in indexes),
            start=round(start*60)/60,end=round(end*60)/60,words=copy.deepcopy(words[a:b]),auto_ost=True,
            _visibility_word_keys=copy.deepcopy(keys[a:b]))
        if subtitle_edits.canonical(cue):piece.update(text=subtitle_edits.word_slice_text(cue,a,b),start=start,end=end)
        if rule:piece['display_hidden']=not rule['enabled'];piece['hidden_reason']='manual' if piece['display_hidden'] else ''
        result.append(piece)
    return result

def display(captions, edits, windows, bases=False, pacing=None, include_hidden=False):
    import subtitle_edits
    rules=visibility_rules(edits,visibility_source(captions))
    manual=subtitle_edits.speech_sync(subtitle_edits.apply(captions,edits))
    out=copy.deepcopy(captions) if bases else []
    for cue,affected in parts(manual,windows):
        if affected:
            for field in ('display_id','display_base','display_edited'):cue.pop(field,None)
            if bases:out.append(copy.deepcopy(cue))
            cue=subtitle_edits.apply([cue],edits)[0]
        pages=subtitle_edits.pages(cue,pacing,edits)
        if len(pages)>1:out.extend(pages if bases else subtitle_edits.apply(pages,edits))
        elif not bases:out.append(cue)
    if bases:
        if rules or any(c.get('_scene_sync') for c in captions):
            visible=display(captions,{k:v for k,v in edits.items() if not v.get('deleted')},windows,pacing=pacing,include_hidden=True)
            for c in visible:
                for field in ('_sync_base','_visibility_base'):
                    if c.get(field):out.append(c[field])
        return out
    out=[cue for cue in out if not cue.get('display_deleted')]
    custom=subtitle_edits.custom_captions(edits)
    if captions and all(subtitle_edits.canonical(c) for c in captions):
        for cue in custom:cue['_caption_policy']=subtitle_edits.CANONICAL_POLICY
        import caption_layer
        caption_layer.timed_caption_words(custom,[])
    for cue in custom:
        cue['_visibility_owner']=cue['display_id'];cue['_visibility_word_keys']=[word_key(w) for w in cue.get('words',[])]
    out.extend(custom);out.sort(key=lambda cue:(cue['start'],cue['end']))
    hidden=[cue for cue in out if cue.get('display_hidden')]
    out=[cue for cue in out if not cue.get('display_hidden')]
    cuts=next((c['_scene_sync'] for c in captions if c.get('_scene_sync')),[])
    if cuts:
        blocked=[(c['start'],c['end']) for c in manual if c.get('display_deleted') or not c.get('text','').strip()]
        blocked.extend((c['start'],c['end']) for c in hidden)
        out=subtitle_edits.sync_display(out,cuts,blocked,edits=edits)
    # Finish automatic scene alignment first: hiding one display item must not
    # extend, shorten or regroup any adjacent item. Delivery only filters here.
    result=[]
    for cue in sorted(out+hidden,key=lambda c:(c['start'],c['end'])):
        for fragment in visibility_parts(cue,rules):
            if not fragment.get('display_id'):
                raw=copy.deepcopy(fragment)
                fragment=subtitle_edits.apply([fragment],edits)[0]
                fragment['_visibility_base']=raw
            if not fragment.get('display_deleted') and (include_hidden or not fragment.get('display_hidden')):result.append(fragment)
    return result
