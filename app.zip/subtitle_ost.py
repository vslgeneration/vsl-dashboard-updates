"""Hide only spoken words duplicated by visible on-screen text; keep canonical speech intact."""
import copy
import re
import unicodedata


def tokens(text):
    normalized=unicodedata.normalize('NFKC',str(text)).casefold().replace('\u0307','').replace('ı','i')
    return re.findall(r'[^\W_]+', normalized, re.UNICODE)


def scene_windows(scenes, cues, total, words):
    import premiere_export as pe
    starts=pe.word_scene_starts(scenes,words) if words else None
    ranges,included=pe.scene_time_ranges(scenes,cues,total,starts)
    windows=[]
    for scene,(start,end),include in zip(scenes,ranges,included):
        if not include: continue
        for text in scene.get('texts') or []:
            if not str(text.get('text','')).strip():continue
            a=max(0,min(1,float(text.get('text_in',0) or 0)))
            b=max(0,min(1,float(text.get('text_out',1) if text.get('text_out') is not None else 1)))
            if b>a:windows.append(dict(text=text['text'],start=start+(end-start)*a,end=start+(end-start)*b))
    return windows


def parts(captions, windows):
    """Return (piece, affected) pairs. Text matches must occur in the same time window."""
    flat=[]
    for ci,cue in enumerate(captions):
        for wi,word in enumerate(cue.get('words') or []):
            for token in tokens(word.get('text','')):flat.append((token,ci,wi,word))
    hidden=set()
    hay=[row[0] for row in flat]
    for window in windows:
        needle=tokens(window.get('text',''))
        if not needle:continue
        for i in range(len(hay)-len(needle)+1):
            if hay[i:i+len(needle)]!=needle:continue
            match=flat[i:i+len(needle)]
            for _,ci,wi,word in match:
                if min(float(word['end']),float(window['end']))-max(float(word['start']),float(window['start']))>.02:
                    hidden.add((ci,wi))
    result=[]
    for ci,cue in enumerate(captions):
        words=cue.get('words') or []
        if not any((ci,i) in hidden for i in range(len(words))):
            result.append((cue,False));continue
        # Keep authored line boundaries when neighbouring words survive OST hiding.
        # cap_units is the same punctuation-aware tokenizer used by timed words.
        from render_video import cap_units
        breaks=set();count=0
        for line in str(cue.get('text','')).replace('\r\n','\n').replace('\r','\n').split('\n'):
            if count:breaks.add(count)
            count+=len(cap_units(line))
        groups=[];group=[]
        for i,w in enumerate(words):
            if (ci,i) in hidden:
                if group:groups.append(group);group=[]
            else:group.append((i,w))
        if group:groups.append(group)
        if not groups:
            piece=copy.deepcopy(cue);piece.update(text='',words=[],auto_ost=True)
            result.append((piece,True));continue
        for group in groups:
            first,last=group[0][0],group[-1][0]
            start=cue['start'] if first==0 else max(cue['start'],group[0][1]['start'])
            end=cue['end'] if last==len(words)-1 else min(cue['end'],group[-1][1]['end'])
            if end-start<1/60:continue
            text=''.join(('\n' if i in breaks else ' ') + w['text'] if n else w['text'] for n,(i,w) in enumerate(group))
            piece=copy.deepcopy(cue);piece.update(text=text,start=round(start*60)/60,end=round(end*60)/60,
                                                 words=[copy.deepcopy(w) for _,w in group],auto_ost=True)
            result.append((piece,True))
    return result


def display(captions, edits, windows, bases=False, pacing=None):
    import subtitle_edits
    manual=subtitle_edits.apply(captions,edits)
    out=copy.deepcopy(captions) if bases else []
    for cue,affected in parts(manual,windows):
        if affected:
            # Edits made before OST matching are kept, then each remaining piece
            # gets its own stable editor identity. No full-script mutation.
            for field in ('display_id','display_base','display_edited'):cue.pop(field,None)
            if bases:out.append(cue)
            cue=subtitle_edits.apply([cue],edits)[0]
        pages=subtitle_edits.pages(cue,pacing,edits)
        if len(pages)>1:
            out.extend(pages if bases else subtitle_edits.apply(pages,edits))
        elif not bases:out.append(cue)
    if not bases:
        out=[cue for cue in out if not cue.get('display_deleted')]
        # Authored captions have explicit text/time windows; keep those choices intact.
        out.extend(subtitle_edits.custom_captions(edits))
        out.sort(key=lambda cue:(cue['start'],cue['end']))
        cuts=next((c['_scene_sync'] for c in captions if c.get('_scene_sync')),[])
        if cuts:
            blocked=[(c['start'],c['end']) for c in manual if c.get('display_deleted') or not c.get('text','').strip()]
            out=subtitle_edits.sync_display(out,cuts,blocked,edits=edits)
    elif any(c.get('_scene_sync') for c in captions):
        # Frame-exact short-scene pieces also need to be valid editor targets.
        visible=display(captions,{k:v for k,v in edits.items() if not v.get('deleted')},windows,pacing=pacing)
        out.extend(c['_sync_base'] for c in visible if c.get('_sync_base'))
    return out
