"""Account-local quality evidence; no provider requests, no inferred historical button presses."""
import json, time, uuid
from pathlib import Path
from collections import defaultdict


def read_events(path):
    rows, invalid = [], 0
    if Path(path).exists():
        with Path(path).open(encoding='utf-8') as f:
            for line in f:
                try:
                    r=json.loads(line)
                    if not isinstance(r,dict) or not r.get('event'): raise ValueError()
                    rows.append(r)
                except (ValueError,TypeError): invalid += 1
    return rows, invalid


def append(path, event, project, uid=None, **facts):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    row=dict(facts,event=event,project=project,uid=uid,id=uuid.uuid4().hex,ts=time.time())
    with path.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    return row


def qa_guidance(rows, project):
    """Explicit, revocable feedback for this project; never an automatic issue filter."""
    use=[r for r in rows if r.get('project')==project]
    reviews={r.get('id'):r for r in use if r.get('event')=='qa_review' and r.get('issue')}
    latest={}
    for r in use:
        if r.get('event')=='qa_feedback':
            latest.pop(r.get('review_id'),None)
            latest[r.get('review_id')]=r
    notes=[]
    for review_id,r in reversed(list(latest.items())):
        review=reviews.get(review_id)
        reason=r.get('reason')
        if (review and r.get('verdict')=='false_alarm' and r.get('use_in_checks') is True
                and isinstance(reason,str) and reason.strip()):
            notes.append(dict(scene=review.get('scene'),original_issue=str(review['issue'])[:800],
                              user_reason=reason.strip()[:800]))
        if len(notes)==5:break
    if not notes:return ''
    return ('\n\nPROJECT QA FEEDBACK: the user explicitly asked to consider these reasons in future checks '
            'of THIS project. They describe earlier false alarms, not automatic passes or blanket exclusions. '
            'Apply a reason only where the same circumstances actually hold in the CURRENT image and scene. '
            'Still inspect the current image and compare all required product/cast references. Report genuine '
            'defects, including new instances of previously dismissed issue types. These notes do not override '
            'the required JSON verdict format. At most the five most recently saved active reasons follow:\n'
            +json.dumps(notes,ensure_ascii=False))


def summary(rows, project=None, scenes=None):
    media_key=lambda rel: str(rel or '').replace('\\','/')
    use=[r for r in rows if project is None or r.get('project')==project]
    submits=defaultdict(list);approvals=defaultdict(list);feedback={};details={};issues=[]
    for r in use:
        key=(r.get('project'),r.get('uid'))
        if r['event']=='submitted': submits[key].append(r)
        if r['event']=='approved': approvals[key].append(r)
        if r['event']=='qa_feedback':
            feedback[r.get('review_id')]=r.get('verdict');details[r.get('review_id')]=r
        if r['event']=='qa_review' and r.get('issue'):issues.append(review_display(r))
    # Read-only opening snapshot, not a claim that current prompt/settings match an old review.
    by_uid = {s.get('uid'): s for s in (scenes or []) if s.get('uid')}
    latest = {}
    for r in use:
        if r.get('event') == 'qa_review':
            latest[(r.get('project'), r.get('uid'), media_key(r.get('file')))] = r.get('id')
    for r in issues:
        scene = by_uid.get(r.get('uid'))
        status = 'unknown'
        if scenes is not None and r.get('uid') and r.get('file'):
            if scene is None:
                status = 'scene_missing'
            else:
                im = scene.get('image') or {}
                selected = im.get('approved_file') or im.get('file')
                if not selected:
                    status = 'no_current_image'
                elif media_key(r['file']) != media_key(selected):
                    status = 'older_image'
                elif latest.get((r.get('project'), r.get('uid'), media_key(r.get('file')))) != r.get('id'):
                    status = 'older_review'
                else:
                    status = 'current'
        r.update(history_status=status, current_scene=scene.get('id') if scene else None)
    first=eligible=0
    for k,rs in submits.items():
        # A scene already containing images at first observation has no trustworthy first attempt.
        rs=sorted(rs,key=lambda r:r['ts'])
        if rs[0].get('prior_versions')!=0:continue
        approved=[r for r in approvals[k] if r.get('generation_id')]
        if not approved:continue
        initial=min(approved,key=lambda r:r['ts'])
        before=[r for r in rs if r['ts']<=initial['ts']]
        if not before:continue
        eligible+=1
        if len(before)==1 and initial['generation_id']==before[0].get('generation_id'):first+=1
    reviewed=[r for r in issues if feedback.get(r['id']) in ('valid','false_alarm')]
    false=sum(feedback.get(r['id'])=='false_alarm' for r in reviewed)
    for r in issues:
        f=details.get(r['id'],{})
        r.update(feedback=feedback.get(r['id']),feedback_reason=f.get('reason',''),
                 feedback_use_in_checks=f.get('use_in_checks') is True)
    return dict(usage=usage_summary(rows,project),submitted=sum(map(len,submits.values())), scenes_generated=len(submits),
                repeat_submissions=sum(max(0,len(rs)-1) for rs in submits.values()),
                prompt_edits=sum(r['event']=='prompt_edit' for r in use),
                first_approved=first,first_eligible=eligible,
                first_rate=round(first/eligible*100,1) if eligible else None,
                qa_flags=len(issues),qa_reviewed=len(reviewed),qa_false=false,
                false_rate=round(false/len(reviewed)*100,1) if reviewed else None,
                issues=sorted(issues,key=lambda r:r['ts'],reverse=True)[:50],
                since=min((r['ts'] for r in use),default=None),
                limits='Metrics cover actions recorded since this version. Submissions are not billing counts; repeats include automatic retries. Prompt edits are UI records, not keystroke counts. QA rates cover only warnings you assessed; approval alone does not count as a false alarm.')


def qa_detail(verdict,available):
    clean=lambda name: verdict.get(name,'').strip()[:1000] if isinstance(verdict.get(name,''),str) else ''
    basis=verdict.get('basis') or []
    if not isinstance(basis,list):basis=[]
    return dict(observation=clean('observation'),correction=clean('correction'),
                basis=list(dict.fromkeys(available[k] for k in basis if isinstance(k,str) and k in available)))


QA_CATEGORIES = {'meaning':'Meaning defect', 'instruction':'Explicit instruction mismatch',
                 'aesthetic':'Optional aesthetic suggestion', 'uncertain':'Uncertain finding — review needed'}


# Translate only built-in labels from older records. Never rewrite user or model-authored content.
_LEGACY_REVIEW_LABELS = {'Anlamı bozan hata': 'Meaning defect', 'Açık isteğe aykırılık': 'Explicit instruction mismatch', 'İsteğe bağlı estetik öneri': 'Optional aesthetic suggestion', 'Kararını gerektiren belirsizlik': 'Uncertain finding — review needed', 'Aktarılan testimonial kartı — yalnız görünür kalite kontrolü': 'Imported testimonial card — visible quality check only', 'Üretilen yorum panosu': 'Generated review board', 'İstenen yorum panosu tasarımı': 'Requested review board design', 'Ürün/marka referansı — yalnız tasarımda istendiği yerde': 'Product/brand reference — only where requested in the design', 'Kontrol edilen görsel': 'Reviewed image', 'Sahnenin metni ve promptu': 'Scene text and prompt', 'Ödeme sayfası referansı': 'Checkout page reference', 'Ürün referansı': 'Product reference'}


def review_display(row):
    result=dict(row)
    category=result.get('category')
    label=result.get('category_label')
    if category in QA_CATEGORIES:
        result['category_label']=QA_CATEGORIES[category]
    elif isinstance(label,str):
        result['category_label']=_LEGACY_REVIEW_LABELS.get(label,label)
    if isinstance(result.get('basis'),list):
        result['basis']=[_LEGACY_REVIEW_LABELS.get(x,x) if isinstance(x,str) else x for x in result['basis']]
    return result


def qa_priority(verdict, detail, request_text=''):
    category=verdict.get('category')
    if category not in QA_CATEGORIES: category='uncertain'
    confidence=str(verdict.get('confidence') or '').lower()
    requirement=verdict.get('requirement') if isinstance(verdict.get('requirement'),str) else ''
    if category=='instruction':
        norm=lambda x:' '.join(x.split()).casefold()
        if not requirement.strip() or norm(requirement) not in norm(request_text): category='uncertain'
    actionable=(category in ('meaning','instruction') and confidence=='high'
                and bool(detail.get('observation')) and bool(detail.get('basis')))
    if category in ('meaning','instruction') and not actionable:category='uncertain'
    return dict(category=category,category_label=QA_CATEGORIES[category],advisory=not actionable,
                confidence=confidence if confidence in ('high','medium','low') else 'unknown',
                requirement=requirement[:400])


def usage_summary(rows,project):
    """Observed workload, not a causal quality score or inferred failure count."""
    rows=[r for r in rows if r.get('project')==project]
    versions={};scenes={}
    for r in rows:
        event=r.get('event')
        if event not in ('submitted','image_edit','prompt_edit','approved'):continue
        version=str(r.get('app_version') or 'Unknown')
        v=versions.setdefault(version,dict(version=version,submitted=0,image_edits=0,prompt_edits=0,approved_uids=set()))
        uid=r.get('uid')
        if event=='approved':
            if uid:v['approved_uids'].add(uid)
            continue
        key={'submitted':'submitted','image_edit':'image_edits','prompt_edit':'prompt_edits'}[event];v[key]+=1
        if uid:
            s=scenes.setdefault(uid,dict(uid=uid,scene=r.get('scene'),submitted=0,image_edits=0,prompt_edits=0))
            s['scene']=r.get('scene');s[key]+=1
    for v in versions.values():v['approved_scenes']=len(v.pop('approved_uids'))
    for s in scenes.values():s['repeat_submissions']=max(0,s['submitted']-1)
    priority=sorted(scenes.values(),key=lambda s:(s['repeat_submissions']+s['image_edits']+s['prompt_edits']),reverse=True)
    return dict(versions=list(versions.values()),attention=[s for s in priority if s['repeat_submissions']+s['image_edits']+s['prompt_edits']][:5],
                enough=bool(versions),note='These are recorded activity counts, not evidence of defects, charges or quality improvements. Different work may have been done in different versions. Missing older records are not treated as complete.')
