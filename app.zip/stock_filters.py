"""Validated catalog filters. Provider arguments are data, never model-chosen replacements."""
import copy
import math

def field(key,label,options=None,kind='select',default=None):
    return dict(key=key,label=label,options=options,kind=kind,default=default)

SB_CATEGORIES={'video': {'footage': ['Aerial', 'Animals', 'Business and Professions', 'Food and Beverage', 'Historical and Archival', 'Holidays and Celebrations', 'Nature', 'People', 'Slow Motion', 'Sports and Recreation', 'Technology', 'Time Lapse', 'Transportation', 'Effects and Lower Thirds', 'Places and Landmarks', '360° and VR', 'Green Screen', 'Medical', 'Lifestyle'], 'motion-backgrounds': ['Abstract', 'Business', 'Space', 'Fire', 'Flowers', 'Energy', 'Particles', 'Water', 'Love', 'Countdown', 'Medical', 'Science', 'Music', 'Technology', 'Religion', 'Shapes', 'Business and Professions', 'Colors', 'Effects and Overlays', 'Nature', 'News', 'Holidays and Celebrations']}, 'image': {'all': ['Design Elements', 'Objects', 'Business', 'People', 'Holidays and Celebrations', 'Nature and Wildlife', 'Buildings and Landmarks', 'Sports and Outdoors', 'Fictional', 'Travel and Transportation', 'Health and Science', 'Backgrounds', 'Cultural', 'Beauty and Fashion'], 'snapshots': ['Design Elements', 'Objects', 'Business', 'People', 'Holidays and Celebrations', 'Nature and Wildlife', 'Health and Science', 'Fictional', 'Buildings and Landmarks', 'Sports and Outdoors', 'Backgrounds', 'Cultural', 'Travel and Transportation', 'Beauty and Fashion']}}

SB_SORT=['most_relevant','most_downloaded','highest_rated','most_recent','trending_now','undiscovered']
SB_COMMON=[field('sort_by','Sort By',SB_SORT,default='most_relevant'),field('sort_order','Sort Direction',['DESC','ASC']),
    field('categories','Categories (Comma Separated)',kind='text'),field('required_keywords','Required Subject',kind='text'),
    field('filtered_keywords','Exclude Keywords',kind='text'),field('is_editorial','Editorial Content',kind='bool',default=False),
    field('has_talent_released','Model Release',kind='bool'),field('has_property_released','Property Release',kind='bool'),field('safe_search','Safe Search',kind='bool')]
SB_VIDEO=[field('content_type','Content Type',['footage','motion-backgrounds'],default='footage'),field('quality','Catalog Resolution',['HD','4K','8K','ALL'],default='HD'),
    field('frame_rates','Frame Rates',['24','25','30','50','60'],kind='multi'),field('min_duration','Minimum Duration (Seconds)',kind='number'),
    field('max_duration','Maximum Duration (Seconds)',kind='number'),field('has_alpha','Alpha Channel',kind='bool'),field('is_vr_360','360° / VR',kind='bool')]
SB_IMAGE=[field('content_type','Content Type',['photos','snapshots','illustrations','vectors']),field('color','Dominant Color (#RRGGBB)',kind='color'),field('has_transparency','Transparency',kind='bool')]
EV_FOOTAGE=['Buildings','Business, Corporate','Cartoons','City','Construction','Education','Food','Holidays','Industrial','Kids','Lifestyle','Medical','Military','Nature','Overhead','People','Religious','Science','Slow Motion','Special Events','Sports','Stop Motion','Technology','Time Lapse','Vehicles','Weather']
EV_MOTION=['Backgrounds','Bugs','Distortions','Elements','Infographics','Interface Effects','Lower Thirds','Miscellaneous','Overlays','Particles','Revealer','Transitions','Water & Fluid']
EV_COMMON=[field('sortBy','Sort By',['relevance','popular','latest'],default='relevance')]
EV_VIDEO=[field('resolution','Catalog Resolution',['720p (HD)','1080p (Full HD)','2K','4K (UHD)'],default='1080p (Full HD)'),
    field('categories','Category',['Stock Footage','Motion Graphics'],default='Stock Footage'),field('subcategories','Subcategory',EV_FOOTAGE+EV_MOTION),
    field('frame_rate','Frame Rate',['23.98 fps','24 fps','25 fps','29.97 fps','30 fps','50 fps','60 fps','More than 60 fps']),
    field('min_media_length','Minimum Duration (Seconds)',kind='number'),field('max_media_length','Maximum Duration (Seconds)',kind='number'),
    field('has_alpha_channel','Alpha Channel',kind='bool'),field('is_looped','Looped',kind='bool')]
EV_IMAGE=[field('number_of_people','People',['No people','1 person','2 people','3+ people']),field('colors','Dominant Color',['pink','red','orange','yellow','green','teal','blue','purple','brown','black','grey','white'])]

FIXED_FILTERS={
    'storyblocks':{'sort_order':None,'categories':None,'required_keywords':None,'filtered_keywords':None,
        'is_editorial':False,'has_talent_released':None,'has_property_released':None,'safe_search':None,
        'frame_rates':None,'min_duration':None,'max_duration':None,'is_vr_360':None},
    'envato':{'categories':None,'subcategories':None,'frame_rate':None,
        'min_media_length':None,'max_media_length':None,'is_looped':None},
}

def definitions(kind,include_hidden=False):
    fields=copy.deepcopy(SB_COMMON+(SB_VIDEO if kind=='video' else SB_IMAGE))
    categories=next(f for f in fields if f['key']=='categories')
    categories.update(label='Categories',kind='multi',groups=SB_CATEGORIES[kind],options=sorted({v for values in SB_CATEGORIES[kind].values() for v in values}))
    result={'storyblocks':fields,'envato':copy.deepcopy(EV_COMMON+(EV_VIDEO if kind=='video' else EV_IMAGE))}
    if not include_hidden:
        result={p:[f for f in fields if f['key'] not in FIXED_FILTERS[p]] for p,fields in result.items()}
    return result

def normalize(body):
    if not isinstance(body,dict):raise ValueError('Choose valid stock search settings.')
    kind=body.get('type','video');provider=body.get('provider','all')
    if kind not in ('video','image') or provider not in ('all','storyblocks','envato','library'):raise ValueError('Choose a valid source and media type.')
    page=body.get('page',1)
    if type(page) is not int or not 1<=page<=1000:raise ValueError('Choose a valid results page.')
    if provider!='library':page=1
    source=body.get('filters') or {}
    if not isinstance(source,dict):raise ValueError('Choose valid filters.')
    aspect=source.get('aspect','16:9' if kind=='video' else 'landscape')
    if aspect not in ('any','16:9','9:16','1:1','landscape','portrait'):raise ValueError('Choose a valid aspect ratio.')
    result={'aspect':aspect}
    for p,fields in definitions(kind,include_hidden=True).items():
        values=source.get(p) or {}
        if not isinstance(values,dict) or set(values)-{f['key'] for f in fields}:raise ValueError('Unknown '+p+' filter.')
        clean={}
        for f in fields:
            # Retired controls cannot retain invisible restrictions from saved searches.
            # FPS never filters clips; compare formats only after the user chooses a clip.
            value=copy.deepcopy(FIXED_FILTERS[p][f['key']]) if f['key'] in FIXED_FILTERS[p] else values.get(f['key'],f['default'])
            if value in (None,'',[]):continue
            typ=f['kind']
            if typ=='bool':
                if type(value) is not bool:raise ValueError(f['label']+' must be Yes, No or Any.')
            elif typ=='number':
                if type(value) is not int or not 0<=value<=3600:raise ValueError('Duration must be between 0 and 3600 seconds.')
            elif typ=='multi':
                if not isinstance(value,list) or any(v not in f['options'] for v in value):raise ValueError('Choose valid '+f['label']+'.')
                value=sorted(set(value))
            elif typ=='select':
                if value not in f['options']:raise ValueError('Choose valid '+f['label']+'.')
            elif typ in ('text','color'):
                if not isinstance(value,str) or len(value)>200:raise ValueError(f['label']+' is too long.')
                value=value.strip()
                if typ=='color':
                    import re
                    if not re.fullmatch(r'#[0-9a-fA-F]{6}',value):raise ValueError('Use a color such as #4A8B62.')
            clean[f['key']]=value
        # Explicit empty fields override defaults when reopening a saved search.
        result[p]={f['key']:clean.get(f['key']) for f in fields}
    for p,lo,hi in [('storyblocks','min_duration','max_duration'),('envato','min_media_length','max_media_length')]:
        v=result[p]
        if v.get(lo) is not None and v.get(hi) is not None and v[lo]>v[hi]:raise ValueError('Minimum duration cannot exceed maximum duration.')
    ev=result['envato'];category=ev.get('categories');sub=ev.get('subcategories')
    if sub and (not category or sub not in (EV_FOOTAGE if category=='Stock Footage' else EV_MOTION)):raise ValueError('Choose a subcategory that matches the Envato category.')
    return dict(type=kind,provider=provider,query=str(body.get('query') or '').strip()[:160],filters=result,page=page)

def arguments(filters,kind,provider):
    args={k:v for k,v in filters[provider].items() if v is not None}
    aspect=filters['aspect']
    orientation='horizontal' if aspect in ('landscape','16:9') else 'vertical' if aspect in ('portrait','9:16') else None
    if kind=='image':orientation={'horizontal':'landscape','vertical':'portrait'}.get(orientation,'square' if aspect=='1:1' else None)
    if orientation:args['orientation']=orientation
    if provider=='storyblocks':
        # The category API uses a hyphen; the search API explicitly rejects it.
        if args.get('content_type')=='motion-backgrounds':args['content_type']='motionbackgrounds'
        for key in ('frame_rates','categories'):
            if args.get(key):args[key]=','.join(args[key])
        args['extended']='aspectRatio'
    return args

def ratio(value):
    try:
        if isinstance(value,str) and ':' in value:
            w,h=value.split(':');value=float(w)/float(h)
        number=float(value)
        return number if math.isfinite(number) and number>0 else None
    except (ValueError,TypeError,ZeroDivisionError):return None

def accepts(item,aspect):
    if aspect=='any':return True
    r=ratio(item.get('aspect_ratio'))
    if aspect in ('16:9','9:16','1:1'):
        target={'16:9':16/9,'9:16':9/16,'1:1':1}[aspect]
        return r is not None and abs(r-target)<=.01
    if r is not None:return r>1 if aspect=='landscape' else r<1
    return item.get('orientation') in (('horizontal','landscape') if aspect=='landscape' else ('vertical','portrait'))
