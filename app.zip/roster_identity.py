"""Conservative roster matching. Never delete, rename, or reassign existing assets."""
import re
import unicodedata

def norm(value):
    value=unicodedata.normalize('NFKC',str(value or '')).casefold()
    value=value.translate(str.maketrans({'’':"'",'‘':"'",'‐':'-','‑':'-','–':'-','—':'-'}))
    return ' '.join(value.split()).strip()

_TITLE=re.compile(r'^(?:(?:dr|doctor|docteur|doctora|doktor|dottore|dott|prof|professor|professeur|captain|capt|capitaine|capitan|capitán|kapitän)\.?\s+)+')
_GROUPS=[
    ('adma','asymmetric dimethylarginine','asymmetrical dimethylarginine','adma (asymmetric dimethylarginine)'),
    ('coq10','co-q10','coenzyme q10','coenzyme q-10'),
    ('citrulline','l-citrulline','l citrulline'),
]
_ALIASES={norm(v):norm(group[0]) for group in _GROUPS for v in group}

def keys(label,kind,row=None):
    key=norm(label)
    if not key:return set()
    result={key}
    if kind=='cast':
        bare=_TITLE.sub('',key)
        # Full names only: never merge a role, surname, relative, or generic narrator.
        if len(bare.split())>=2 and not re.search(r"\b(wife|husband|daughter|son|mother|father|sister|brother)\b",bare):
            result.add(bare)
    else:
        result.add(_ALIASES.get(key,key))
        # A botanical name alone may refer to other plant parts. Only collapse berry
        # synonyms when this existing reference actually describes berries.
        if key=='hawthorn' and re.search(r'\b(berry|berries)\b',norm((row or {}).get('desc'))):
            result.add('hawthorn berry')
        if key in ('hawthorn berries','hawthorn berry'):result.add('hawthorn berry')
    return result

def find(rows,label,kind):
    wanted=norm(label)
    exact=[r for r in rows if norm(r.get('name',r.get('label')))==wanted]
    if exact:return exact[0]
    wanted_keys=keys(label,kind)
    matches=[]
    for row in rows:
        labels=[row.get('name',row.get('label'))]+[a for a in row.get('aliases',[]) if isinstance(a,str)]
        known=set().union(*(keys(a,kind,row) for a in labels))
        if wanted_keys & known:matches.append(row)
    return matches[0] if len(matches)==1 else None

def remember(row,label):
    if norm(label)==norm(row.get('name',row.get('label'))):return
    aliases=[a for a in row.get('aliases',[]) if isinstance(a,str)]
    if norm(label) not in {norm(a) for a in aliases}:aliases.append(label)
    row['aliases']=aliases[:30]

def context(rows,kind):
    if not rows:return ''
    import json
    compact=[{k:r[k] for k in ('name','role','desc','aliases','is_narrator') if k in r} for r in rows if r.get('name')]
    return ('\n\nEXISTING '+('CAST' if kind=='cast' else 'INGREDIENT / MECHANISM')+' ROSTER (read-only identities):\n'
            +json.dumps(compact,ensure_ascii=False)+'\nReuse the EXACT existing name when referring to the SAME person or substance. '
            'An added title, expanded acronym or spelling variant does not make a new identity. Do not merge different '
            'relatives, people sharing a surname, chemical salts, stereoisomers, extracts, plant parts or distinct formulations. '
            'Do not infer that an unnamed narrator is a named expert solely because both have medical roles. '
            'Return only entities supported by the script/context; existing unused entries need not be repeated.\n')
