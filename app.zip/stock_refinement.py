"""One optional extra catalog pass for weak automatic scene matches, never typed searches."""
import copy
import stock_quality

def weak(result,report=None,rejected=()):
 spec=result.get('spec') or {}
 if result.get('type')!='video' or spec.get('query') or spec.get('_live') or spec.get('provider') not in ('all','storyblocks','envato') or result.get('warnings') or result.get('refinement_round'):return False
 items=result.get('items',[])
 if not items:return True
 if not report or report.get('status')!='done':return False
 for item in items:
  if stock_quality.identity(item) in rejected:continue
  evidence=report.get('items',{}).get(item['id'])
  if (evidence or {}).get('fit',item.get('fit'))=='match':return False
 return True

def instructions(base,report):
 return dict(previous_queries=[q.get('query') for q in (base.get('plan') or {}).get('queries',[])],
  avoid_assets=[stock_quality.identity(i) for i in base.get('items',[])],
  weak_evidence=[dict(id=i,fit=r.get('fit'),reason=r.get('reason')) for i,r in (report or {}).get('items',{}).items()],
  instruction='Choose ONE meaningfully different English search phrase for the same scene. Keep explicit action and audience constraints. Use the weak-match evidence; do not merely repeat the previous query. Do not loosen age or meaning silently.')

def merge(base,result,report):
 items=copy.deepcopy(base.get('items',[]));seen={stock_quality.identity(i) for i in items};added=[]
 for item in result.get('items',[]):
  key=stock_quality.identity(item)
  if key and key not in seen:items.append(copy.deepcopy(item));seen.add(key);added.append(item['id'])
 return dict(result,items=items[:48],refinement_round=1,refinement_new_ids=added[:24],
             refinement_added=len(added[:24]),original_plan=base.get('plan'),
             refinement_note='Additional alternatives are ready.' if added else 'No better new alternatives found. Original matches were kept.')
