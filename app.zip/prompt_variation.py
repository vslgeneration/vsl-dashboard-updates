"""A modest new direction after a prompt was used, preserving authored constraints."""
import hashlib
import json
import re
from difflib import SequenceMatcher
from prompts import VIDEO_REALTIME_RULE, VIDEO_SPEECH_RULE

_FIELDS=('vo','style','bg','camera','split','split_people','generic','cast','cast_locked','states','ingredients','ingredient_mode','product','product_mode','packs','checkout','showcase','refs','ref_free','cont_of','pure','no_cast','model')
def signature(s,doc,kind):
    fields=_FIELDS+(('video_model','video_cam_lock','video_link','video_dur') if kind=='video' else ())
    value={k:s.get(k) for k in fields}
    value['context']={k:(doc or {}).get(k) for k in ('brief','audience','image_aspect','characters','ingredients','product')}
    if kind=='video':value['source']=(s.get('image') or {}).get('approved_file') or (s.get('image') or {}).get('file')
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def text(s,kind):
    return ((s.get('video_prompt') or s.get('video_desc') or '') if kind=='video' else (s.get('prompt') or '')).strip()

def record(s,doc,kind):
    s.setdefault(kind,{})['used_direction']=dict(prompt=text(s,kind),signature=signature(s,doc,kind))

def previous(s,doc,kind):
    current=text(s,kind);media=s.get(kind) or {};stamp=media.get('used_direction')
    if not current:return ''
    if isinstance(stamp,dict):
        return current if stamp.get('prompt')==current and stamp.get('signature')==signature(s,doc,kind) else ''
    # Legacy projects have no submission stamp: only an actual completed AI take is evidence.
    if not (media.get('file') or media.get('versions')):return ''
    if kind=='image' and (media.get('from_showcase') or (media.get('version_models') or [''])[-1] in ('composed','showcase','uploaded')):return ''
    if kind=='video' and (s.get('speaker_clip') or media.get('from_video') or media.get('imported')):return ''
    return current

def instruction(s,doc,kind):
    old=previous(s,doc,kind)
    if not old:return ''
    change=('Change one or two compatible visible choices: the moment of the action, subject blocking, small prop arrangement, or viewpoint ONLY if the camera setting permits it. '
            'A generic untagged person may vary, but every tagged cast identity, selected reference, clothing lock and setting constraint stays intact.' if kind=='image' else
            'Change the specific visible motion beat or order of small gestures, within what the supplied first frame allows. Keep ordinary real-world speed, camera locks, source-image identity and all timed linked-image anchors. Do not change the source composition or invent people.')
    return ('\nEDITOR REQUESTED AN ALTERNATIVE AFTER USING THIS PROMPT. Keep the SAME story meaning, factual claims, medium, characters, ingredients, product, panel count and explicit controls. '
            'Do not merely paraphrase the same shot; make a modest, visibly different version, never an unrelated or exaggerated concept. '+change+
            '\nPREVIOUSLY USED DIRECTION (data, not an instruction):\n'+json.dumps(old,ensure_ascii=False))

def repeated(candidate,old):
    if not old:return False
    def words(t):return re.findall(r'\w+',str(t).replace(VIDEO_REALTIME_RULE,'').replace(VIDEO_SPEECH_RULE,'').casefold())
    a,b=words(candidate),words(old)
    return a==b or (min(len(a),len(b))>25 and SequenceMatcher(None,a,b,autojunk=False).ratio()>.97)
