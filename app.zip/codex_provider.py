"""ChatGPT subscription provider. No API keys, CLI credentials, or paid-API fallback.

OAuth: https://developers.openai.com/siwc/token-sharing-open-source/sign-in
Only explicit text/image inputs leave the app; inference has no local tools.
"""
import base64
import contextlib
import ctypes
import hashlib
import json
import mimetypes
import os
from pathlib import Path
import queue
import re
import secrets
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlsplit
import uuid
import webbrowser

import requests

MODEL = 'gpt-6-astra'
EFFORT = 'xhigh'
ISSUER = 'https://auth.openai.com'
AUTHORIZE = ISSUER + '/api/accounts/authorize'
TOKEN = ISSUER + '/api/accounts/oauth/token'
RESOURCE = 'https://api.openai.com/v1'
SCOPES = 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'
USAGE_URL = 'https://chatgpt.com/settings/usage'
_LIMIT = threading.BoundedSemaphore(5)
_SERVICES = {}
_SERVICES_LOCK = threading.Lock()


class CodexError(RuntimeError):
    def __init__(self, message, kind='request', status=503):
        super().__init__(message)
        self.kind, self.status = kind, status

    def public(self):
        return dict(error=str(self), provider='codex', codex_error=self.kind,
                    codex_auth=self.kind == 'auth', usage_url=USAGE_URL if self.kind == 'limit' else None)


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.codex-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def _protect(data, decrypt=False):
    """Windows DPAPI, bound to this Windows user; no plaintext credential fallback."""
    if os.name != 'nt':
        raise CodexError('ChatGPT credential storage requires Windows on this build.', 'auth', 428)
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypto, kernel = ctypes.windll.crypt32, ctypes.windll.kernel32
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if decrypt:
        fn = crypto.CryptUnprotectData
        fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result))
    else:
        fn = crypto.CryptProtectData
        fn.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = fn(ctypes.byref(source), 'AI Dashboard ChatGPT', None, None, None, 1, ctypes.byref(result))
    if not ok:
        raise CodexError('ChatGPT credentials could not be unlocked. Reconnect on this Windows account.', 'auth', 428)
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        kernel.LocalFree(result.data)


class Vault:
    def __init__(self, path, codec=_protect):
        self.path, self.codec, self.lock = Path(path), codec, threading.RLock()

    @contextlib.contextmanager
    def transaction(self):
        """Also serialize rotating refresh tokens across Dashboard processes."""
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path.with_suffix('.lock'), 'a+b') as handle:
                handle.seek(0, 2)
                if not handle.tell():
                    handle.write(b'0'); handle.flush()
                deadline = time.monotonic() + 45
                while True:
                    try:
                        handle.seek(0)
                        if os.name == 'nt':
                            import msvcrt
                            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                        else:
                            import fcntl
                            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except OSError:
                        if time.monotonic() >= deadline:
                            raise CodexError('ChatGPT account is busy. Try again shortly.')
                        time.sleep(.05)
                try:
                    yield
                finally:
                    handle.seek(0)
                    if os.name == 'nt':
                        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def read(self):
        if not self.path.exists():
            return dict(accounts={}, active=None, welcomed=False)
        try:
            result = json.loads(self.codec(self.path.read_bytes(), decrypt=True))
            if not isinstance(result.get('accounts'), dict):
                raise ValueError()
            return result
        except CodexError:
            raise
        except Exception:
            raise CodexError('Saved ChatGPT connection could not be read. Its file has been preserved.', 'auth', 428) from None

    def write(self, state):
        atomic_write(self.path, self.codec(json.dumps(state).encode('utf-8')))


def _http_error(response):
    try:
        data = response.json()
        error = data.get('error') or data
        code = error.get('code', error.get('type', '')) if isinstance(error, dict) else str(error)
    except Exception:
        code = ''
    return _provider_error(code, response.status_code)


def _provider_error(code, status=503):
    # Do not surface raw bodies: they can include prompts or credential material.
    if status in (401, 403) or code in ('invalid_grant', 'invalid_token', 'access_denied'):
        return CodexError('Reconnect your ChatGPT account in Settings → AI Provider. Check that plan usage is allowed.', 'auth', 428)
    if status == 429 or code in ('subscription_sharing_usage_limit_exceeded', 'subscription_sharing_usage_unavailable'):
        return CodexError('ChatGPT plan usage is unavailable or its limit was reached. Open Manage usage in Settings → AI Provider.', 'limit', 429)
    if code in ('model_not_found', 'model_not_available', 'unsupported_model'):
        return CodexError('GPT-6 Astra is not available to this ChatGPT account. No other model was used.', 'model')
    return CodexError('Codex could not complete the request (HTTP %s). The partial response was not used. Try again.' % status)


def _token_request(data):
    try:
        with requests.post(TOKEN, data=data, timeout=(10, 25), allow_redirects=False) as response:
            if response.status_code != 200:
                raise _http_error(response)
            token = response.json()
        if not token.get('access_token') or str(token.get('token_type', '')).lower() != 'bearer':
            raise ValueError()
        return token
    except CodexError:
        raise
    except Exception:
        raise CodexError('The ChatGPT connection could not be completed. Retry sign-in.', 'auth', 428) from None


def _verify_identity(token, client_id, nonce=None, previous=None):
    vendor = str(Path(__file__).parent / '_codex_vendor')
    if vendor not in sys.path:
        sys.path.append(vendor)
    try:
        import jwt
        # PyJWKClient caches trusted issuer keys; refreshes on an unknown kid.
        global _JWKS
        if '_JWKS' not in globals():
            _JWKS = jwt.PyJWKClient(ISSUER + '/.well-known/jwks.json', timeout=15)
        signing = _JWKS.get_signing_key_from_jwt(token)
        claims = jwt.decode(token, signing.key, algorithms=['RS256'], audience=client_id,
                            issuer=ISSUER, leeway=5, options={'require': ['sub', 'exp', 'iat', 'aud', 'iss']})
        if not isinstance(claims['sub'], str) or not claims['sub']:
            raise ValueError()
        if nonce is not None and not secrets.compare_digest(str(claims.get('nonce', '')), nonce):
            raise ValueError()
        if previous and claims['sub'] != previous['sub']:
            raise ValueError()
        if claims.get('azp') and claims['azp'] != client_id:
            raise ValueError()
        return claims
    except Exception:
        raise CodexError('ChatGPT identity verification failed. The existing connection was kept.', 'auth', 428) from None


def _token_record(token, client_id, identity, old=None):
    old = old or {}
    scopes = token.get('scope', old.get('scope', '')).split()
    if not {'resource.invoke', 'chatgpt.tokens.use.direct'}.issubset(scopes):
        raise CodexError('Allow ChatGPT plan usage during sign-in to use Codex.', 'auth', 428)
    refresh = token.get('refresh_token') or old.get('refresh_token')
    if not refresh:
        raise CodexError('ChatGPT did not return a renewable session. Please reconnect.', 'auth', 428)
    return dict(old, client_id=client_id, sub=identity['sub'], email=identity.get('email', old.get('email', '')),
                issuer=ISSUER, access_token=token['access_token'], refresh_token=refresh,
                id_token=token.get('id_token', old.get('id_token', '')), scope=' '.join(scopes),
                expires_at=time.time() + float(token.get('expires_in', 3600)),
                earliest_refresh_at=token.get('earliest_refresh_at'), connected=True)


class Service:
    def __init__(self, vault):
        self.vault = vault
        self.lock = threading.RLock()
        self.pending = None
        self.login_error = None
        self.last = {}
        self.revoked = set()
        self._active_cache = None

    def account_id(self):
        # Requests for hundreds of scene thumbnails must not decrypt the vault each time.
        try: stamp = self.vault.path.stat().st_mtime_ns
        except OSError: return None
        with self.lock:
            if not self._active_cache or self._active_cache[0] != stamp:
                try:
                    with self.vault.transaction(): state = self.vault.read()
                    self._active_cache = (stamp, state.get('active'))
                except CodexError: return None
            return self._active_cache[1]

    def status(self):
        try:
            with self.vault.transaction():
                state = self.vault.read()
        except CodexError as error:
            return dict(accounts=[], active=None, connected=False, pending=False, error=str(error),
                        last_result=None, welcome=False, model=MODEL, effort=EFFORT, usage_url=USAGE_URL)
        active = state.get('active')
        accounts = [dict(id=k, label=(v.get('email') or 'ChatGPT account') + ' · ' + k[:6],
                         connected=bool(v.get('connected'))) for k, v in state['accounts'].items()]
        return dict(accounts=accounts, active=active, connected=bool(state['accounts'].get(active, {}).get('connected')),
                    pending=bool(self.pending), error=self.login_error, last_result=self.last.get(active),
                    welcome=bool(active and not state.get('welcomed')), model=MODEL, effort=EFFORT, usage_url=USAGE_URL)

    def select_account(self, account_id):
        with self.vault.transaction():
            state = self.vault.read()
            if not state['accounts'].get(account_id, {}).get('connected'):
                raise CodexError('Connect this ChatGPT account first.', 'auth', 428)
            state['active'] = account_id
            self.vault.write(state)

    def welcome_seen(self):
        with self.vault.transaction():
            state = self.vault.read(); state['welcomed'] = True; self.vault.write(state)

    def begin_login(self, account_id=None):
        with self.lock:
            if self.pending:
                raise CodexError('A ChatGPT sign-in is already open. Finish it or cancel it first.', 'login', 409)
            with self.vault.transaction():
                state = self.vault.read()
                if account_id and account_id not in state['accounts']:
                    raise CodexError('Unknown saved ChatGPT account.', 'auth', 428)
                old = state['accounts'].get(account_id)
                if not state.get('host_id'):
                    state['host_id'] = 'urn:uuid:' + str(uuid.uuid4()); self.vault.write(state)
            pending = dict(state=secrets.token_urlsafe(32), nonce=secrets.token_urlsafe(32),
                           verifier=secrets.token_urlsafe(48), old=old, account_id=account_id,
                           done=threading.Event(), expires=time.monotonic() + 300)
            owner = self
            class Callback(BaseHTTPRequestHandler):
                def log_message(self, *args): pass
                def do_GET(self):
                    parsed = urlsplit(self.path)
                    if (parsed.path != '/auth/callback' or len(self.path) > 16384 or
                        self.headers.get('Host') != '127.0.0.1:%d' % self.server.server_port):
                        self.send_error(404); return
                    query = parse_qs(parsed.query)
                    if any(len(v) != 1 for v in query.values()):
                        self.send_error(400); return
                    query = {k: v[0] for k, v in query.items()}
                    if not secrets.compare_digest(query.get('state', ''), pending['state']):
                        self.send_error(400); return
                    if pending['done'].is_set() or time.monotonic() > pending['expires']:
                        self.send_error(410); return
                    pending['done'].set()  # consume the callback before exchanging its code
                    try:
                        owner._finish_login(pending, query)
                        message = 'ChatGPT connected. You can close this tab and return to AI Dashboard.'
                        code = 200
                    except CodexError as error:
                        owner.login_error = str(error)
                        message = 'Sign-in could not be completed. Return to AI Dashboard for details.'
                        code = 400
                    except Exception:
                        owner.login_error = 'ChatGPT sign-in could not be saved. Retry sign-in.'
                        message = owner.login_error; code = 500
                    self.send_response(code)
                    self.send_header('Content-Type', 'text/plain; charset=utf-8')
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('Referrer-Policy', 'no-referrer')
                    self.end_headers(); self.wfile.write(message.encode())
            server = HTTPServer(('127.0.0.1', 0), Callback)
            server.timeout = .5
            pending['redirect_uri'] = 'http://127.0.0.1:%d/auth/callback' % server.server_port
            challenge = base64.urlsafe_b64encode(hashlib.sha256(pending['verifier'].encode()).digest()).rstrip(b'=').decode()
            params = dict(client_id=old['client_id'] if old else 'dynamic_agent_client',
                          redirect_uri=pending['redirect_uri'], response_type='code', scope=SCOPES,
                          resource=RESOURCE, state=pending['state'], nonce=pending['nonce'],
                          code_challenge=challenge, code_challenge_method='S256', ext_agent_host_id=state['host_id'])
            if old:
                if old.get('id_token'): params['id_token_hint'] = old['id_token']
                if old.get('email'): params['login_hint'] = old['email']
            else:
                params['agent_name_hint'] = 'AI Dashboard'
            self.pending, self.login_error = pending, None
            def listen():
                try:
                    while not pending['done'].is_set() and time.monotonic() < pending['expires']:
                        server.handle_request()
                    if not pending['done'].is_set():
                        self.login_error = 'ChatGPT sign-in expired. Click Continue with ChatGPT to retry.'
                finally:
                    server.server_close()
                    with self.lock:
                        if self.pending is pending: self.pending = None
            threading.Thread(target=listen, daemon=True, name='chatgpt-login').start()
            # Keep authorization URLs (possibly containing an ID-token hint) out of frontend state/logs.
            if not webbrowser.open(AUTHORIZE + '?' + urlencode(params), new=2):
                pending['done'].set()
                raise CodexError('The browser could not be opened. Set a default browser and retry.', 'login')
            return dict(ok=True)

    def _finish_login(self, pending, query):
        if query.get('error'):
            raise CodexError('ChatGPT sign-in was declined. Your previous connection was kept.', 'auth', 428)
        old = pending['old']
        client_id = query.get('client_id') or (old or {}).get('client_id')
        if (not client_id or client_id == 'dynamic_agent_client' or not query.get('code') or
            (old and client_id != old['client_id'])):
            raise CodexError('ChatGPT returned an invalid sign-in callback.', 'auth', 428)
        token = _token_request(dict(grant_type='authorization_code', client_id=client_id, code=query['code'],
                                    code_verifier=pending['verifier'], redirect_uri=pending['redirect_uri'], resource=RESOURCE))
        identity = _verify_identity(token.get('id_token', ''), client_id, pending['nonce'], old)
        record = _token_record(token, client_id, identity, old)
        with self.lock:
            if self.pending is not pending or pending.get('cancelled'):
                raise CodexError('ChatGPT sign-in was cancelled.', 'auth', 428)
            with self.vault.transaction():
                state = self.vault.read()
                aid = pending['account_id'] or uuid.uuid4().hex
                state['accounts'][aid] = record; state['active'] = aid
                self.vault.write(state)
                self.revoked.discard(aid)

    def cancel_login(self):
        with self.lock:
            if self.pending:
                self.pending['cancelled'] = True; self.pending['done'].set()

    def sign_out(self, aid):
        self.cancel_login()
        confirmed = False
        with self.vault.transaction():
            state = self.vault.read()
            record = state['accounts'].get(aid)
            if not record: raise CodexError('Unknown ChatGPT account.', 'auth', 428)
            self.revoked.add(aid)
            try:
                discovery = requests.get(ISSUER + '/.well-known/openid-configuration', timeout=(5, 10)).json()
                endpoint = discovery.get('revocation_endpoint', '')
                if urlsplit(endpoint).scheme == 'https' and urlsplit(endpoint).netloc == 'auth.openai.com':
                    for attempt in range(2):
                        with requests.post(endpoint, data=dict(token=record.get('refresh_token', ''),
                                token_type_hint='refresh_token', client_id=record['client_id']),
                                timeout=(5, 10), allow_redirects=False) as response:
                            confirmed = response.status_code == 200
                            if confirmed or response.status_code < 500: break
                        time.sleep(.5)
            except requests.RequestException:
                pass
            except ValueError:
                pass
            for key in ('access_token', 'refresh_token', 'id_token', 'expires_at'):
                record.pop(key, None)
            record['connected'] = False
            self.vault.write(state)
        return dict(ok=True, revocation_confirmed=confirmed,
                    warning=None if confirmed else 'Signed out locally. Remote revocation was not confirmed; disconnect AI Dashboard in ChatGPT Settings.', usage_url=USAGE_URL)

    def access_token(self, aid):
        with self.vault.transaction():
            state = self.vault.read()
            record = state['accounts'].get(aid)
            if not record or not record.get('connected') or aid in self.revoked:
                raise CodexError('Connect your ChatGPT account in Settings → AI Provider.', 'auth', 428)
            earliest = record.get('earliest_refresh_at')
            try: earliest = float(earliest or 0)
            except (TypeError, ValueError): earliest = 0
            if record.get('expires_at', 0) <= time.time() + 60 and time.time() >= earliest:
                try:
                    token = _token_request(dict(grant_type='refresh_token', client_id=record['client_id'],
                                               refresh_token=record['refresh_token'], resource=RESOURCE))
                except CodexError as error:
                    if error.kind == 'auth':
                        record['connected'] = False; self.vault.write(state)
                    raise
                identity = _verify_identity(token['id_token'], record['client_id'], previous=record) if token.get('id_token') else record
                record = _token_record(token, record['client_id'], identity, record)
                state['accounts'][aid] = record; self.vault.write(state)
            return record['access_token']

    def text(self, aid, system, user, images=None, web=False, timeout=300):
        return ''.join(self.stream(aid, system, user, images=images, web=web, timeout=timeout))

    def stream(self, aid, system, user, images=None, web=False, timeout=300):
        import stock_cancel
        stock_cancel.check()
        token = self.access_token(aid)
        content = [{'type': 'input_text', 'text': str(user or '')}]
        for path in images or []:
            path = Path(path)
            if not path.is_file() or path.stat().st_size > 20 * 1024 * 1024:
                raise CodexError('A reference image is missing or larger than 20 MB.', 'input', 400)
            mime = mimetypes.guess_type(str(path))[0]
            if mime not in ('image/png', 'image/jpeg', 'image/webp', 'image/gif'):
                raise CodexError('Codex references must be PNG, JPEG, WebP or GIF images.', 'input', 400)
            content.extend([{'type': 'input_text', 'text': 'Reference image: ' + path.name},
                            {'type': 'input_image', 'image_url': 'data:%s;base64,%s' % (mime, base64.b64encode(path.read_bytes()).decode()), 'detail': 'high'}])
        payload = dict(model=MODEL, reasoning={'effort': EFFORT}, instructions=str(system or ''),
                       input=[{'role': 'user', 'content': content}], store=False, stream=True)
        if web: payload['tools'] = [{'type': 'web_search'}]
        messages = queue.Queue(maxsize=128)
        stop = threading.Event()
        deadline = time.monotonic() + max(15, float(timeout))
        def send(value):
            while not stop.is_set():
                try: messages.put(value, timeout=.2); return
                except queue.Full: pass
        def receive():
            acquired = False
            try:
                while not stop.is_set() and time.monotonic() < deadline:
                    if _LIMIT.acquire(timeout=.2): acquired = True; break
                if not acquired or stop.is_set(): return
                with requests.post(RESOURCE + '/responses', json=payload,
                        headers={'Authorization': 'Bearer ' + token, 'Accept': 'text/event-stream'},
                        stream=True, timeout=(10, 90), allow_redirects=False) as response:
                    if response.status_code != 200: raise _http_error(response)
                    data = []
                    for raw in response.iter_lines(chunk_size=1024):
                        if stop.is_set() or time.monotonic() >= deadline: break
                        line = raw.decode('utf-8') if isinstance(raw, bytes) else raw
                        if line.startswith('data:'): data.append(line[5:].lstrip())
                        elif not line and data:
                            text = '\n'.join(data); data = []
                            if text != '[DONE]': send(('event', json.loads(text)))
                    if data and '\n'.join(data) != '[DONE]': send(('event', json.loads('\n'.join(data))))
            except CodexError as error: send(('error', error))
            except Exception: send(('error', CodexError('The Codex connection ended before a complete response. No partial result was used.')))
            finally:
                if acquired: _LIMIT.release()
                send(('end', None))
        threading.Thread(target=receive, daemon=True, name='codex-response').start()
        got = False
        try:
            while True:
                stock_cancel.check()
                if aid in self.revoked: raise CodexError('ChatGPT account was disconnected.', 'auth', 428)
                if time.monotonic() >= deadline:
                    raise CodexError('Codex exceeded the request time limit. No partial result was used. Retry this operation.', 'timeout', 504)
                try: kind, event = messages.get(timeout=.15)
                except queue.Empty: continue
                if kind == 'error': raise event
                if kind == 'end': raise CodexError('Codex returned an incomplete response. No partial result was used.')
                event_type = event.get('type')
                if event_type in ('error', 'response.failed', 'response.incomplete'):
                    err = event.get('error') or (event.get('response') or {}).get('error') or event
                    raise _provider_error(err.get('code', ''), 503)
                if event_type == 'response.output_text.delta':
                    got = True; yield event.get('delta', '')
                if event_type == 'response.completed':
                    result = event.get('response') or {}
                    actual = str(result.get('model') or '')
                    if result.get('status') != 'completed': raise CodexError('Codex did not complete the response.')
                    if not re.fullmatch(re.escape(MODEL) + r'(?:-\d{4}-\d{2}-\d{2})?', actual):
                        raise CodexError('Codex returned a different or unidentified model. Its response was not used.', 'model')
                    if not got:
                        answer = ''.join(c.get('text', '') for item in result.get('output', [])
                                         for c in item.get('content', []) if c.get('type') == 'output_text')
                        if not answer: raise CodexError('Codex completed without a text answer.')
                        yield answer
                    self.last[aid] = dict(model=actual, effort=EFFORT, accepted=True, time=int(time.time()))
                    return
        finally:
            stop.set()


def service(user_root):
    key = str(Path(user_root).resolve()).casefold()
    with _SERVICES_LOCK:
        if key not in _SERVICES:
            account_hash = hashlib.sha256(key.encode()).hexdigest()[:32]
            location = Path(os.environ.get('LOCALAPPDATA') or Path.home() / '.local/share') / 'VSLDashboard' / 'codex' / account_hash
            _SERVICES[key] = Service(Vault(location / 'credentials.dpapi'))
        return _SERVICES[key]


def preference(user_root, default='claude'):
    try:
        value = json.loads((Path(user_root) / '.ai-provider.json').read_text('utf-8')).get('provider')
        if value in ('claude', 'codex', 'kie'): return value
    except (OSError, ValueError): pass
    return default if default in ('claude', 'kie') else 'claude'


def set_preference(user_root, provider):
    if provider not in ('claude', 'codex'):
        raise CodexError('Select Claude or Codex.', 'input', 400)
    atomic_write(Path(user_root) / '.ai-provider.json', json.dumps({'provider': provider}).encode())


def snapshot(user_root, default='claude'):
    provider = preference(user_root, default)
    aid = service(user_root).account_id() if provider == 'codex' else None
    return {'provider': provider, 'account_id': aid}
