"""Account-local Subtitle Studio: finished video in, styled captions out.

The hidden workspace is separate from projects and the Voiceover & Subtitles tab.
Source recordings/videos are retained. Export workers read immutable snapshots.
"""
import copy
import hashlib
import json
import math
import os
import shutil
from pathlib import Path
import subprocess
import time
import uuid

PROJECT = '_subtitle_video'
PREFIX = '/api/studio/subtitle'


def _export_signature(state, captions, kind):
    """Identify the displayed content used by an immutable export snapshot."""
    value = dict(kind=kind, revision=state.get('revision'), video=state.get('video'),
                 audio=state.get('audio'), audio_mode=state.get('audio_mode'),
                 style=state.get('style') if kind != 'srt' else None,
                 captions=[{k:c.get(k) for k in ('text','start','end','words')} for c in captions])
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode('utf8')).hexdigest()


def probe(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
                            capture_output=True, timeout=40, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise ValueError('This media file could not be read.')
    data = json.loads(result.stdout)
    streams = data.get('streams', [])
    video = next((s for s in streams if s.get('codec_type') == 'video' and not s.get('disposition', {}).get('attached_pic')), None)
    duration = float(data.get('format', {}).get('duration') or (video or {}).get('duration') or 0)
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('The media duration could not be read.')
    info = dict(duration=duration, has_audio=any(s.get('codec_type') == 'audio' for s in streams))
    if video:
        width, height = int(video['width']), int(video['height'])
        rotation = int(float(video.get('tags', {}).get('rotate', 0)))
        for side in video.get('side_data_list', []):
            rotation = int(side.get('rotation', rotation))
        if abs(rotation) % 180 == 90:
            width, height = height, width
        sar = video.get('sample_aspect_ratio', '1:1')
        if sar not in ('1:1', 'N/A', '0:1'):
            raise ValueError('Export the video with square pixels before uploading it.')
        rate = video.get('avg_frame_rate', '30/1').split('/')
        fps = float(rate[0]) / max(1, float(rate[-1]))
        info.update(width=width, height=height, fps=max(1, min(60, round(fps) or 30)), codec=video.get('codec_name'))
    return info


def encode(command, duration, progress, cancelled, logfile):
    """FFmpeg's encoded clock, not an arbitrary timer, drives export progress."""
    command = ['ffmpeg', '-hide_banner', '-nostdin', '-y', '-progress', 'pipe:1', '-nostats', *command]
    with open(logfile, 'wb') as log:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log, text=True,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        # Cancellation also works while the encoder has not produced a line yet.
        import threading
        finished = threading.Event()
        def watch():
            while not finished.wait(.15):
                if cancelled():
                    process.kill()
                    return
        threading.Thread(target=watch, daemon=True).start()
        try:
            for line in process.stdout:
                if line.startswith('out_time_us='):
                    try: progress(min(duration, int(line.split('=')[1]) / 1e6), duration)
                    except ValueError: pass
            code = process.wait()
            if cancelled():
                raise ValueError('Cancelled')
            if code:
                raise RuntimeError('Video export failed. ' + Path(logfile).read_text('utf8', errors='replace')[-800:])
        finally:
            finished.set()
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdout.close()


def register(app, env):
    from flask import request, jsonify, send_file
    import caption_layer
    import subtitle_edits
    import premiere_export as pe
    import project_canvas
    import render_video
    import download_progress
    import audio_prepare
    from werkzeug.datastructures import FileStorage
    e = lambda name: env[name]
    jobs = e('_user_job_registry')('subtitle-studio')

    def root():
        return e('proj_dir')(PROJECT)[0]

    def ensure():
        with e('_project_lock')(PROJECT):
            if e('load_doc')(PROJECT) is None:
                e('save_doc')(PROJECT, dict(title='Subtitle Studio', script='', script_draft='', scenes=[], characters=[], ptype='vsl'))

    def state():
        ensure()
        path = root() / 'subtitle-studio.json'
        s = json.loads(path.read_text('utf8')) if path.exists() else dict(revision=0, script='', language='en', style={}, audio_mode='video')
        # Connect the existing v855 recording to the shared, optional Trim controls.
        prep = audio_prepare.state(prep_root())
        if not prep.get('ref') and s.get('audio'):
            with (root() / s['audio']['file']).open('rb') as handle:
                prep = audio_prepare.upload(prep_root(), FileStorage(handle, filename=s['audio']['name']))
            s['prep_ref'] = prep['ref']
            write(s)
        if prep.get('ref') and prep.get('status') != 'running' and prep['ref'] != s.get('prep_ref'):
            source, name = audio_prepare.selected(prep_root(), prep['ref'])
            own_audio(s, source, name, prep['ref'])
            write(s)
        return s

    def prep_root():
        return e('_audio_prep_root')('subtitle', PROJECT)

    def own_audio(s, source, name, ref):
        info = probe(source)
        if not info['has_audio']: raise ValueError('Choose a recording containing audio.')
        dest = root() / 'uploads' / (uuid.uuid4().hex + source.suffix)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        s.update(audio=dict(info, file=dest.relative_to(root()).as_posix(), name=name), prep_ref=ref)
        s['revision'] += 1
        s.pop('aligned_job', None)

    def write(value):
        e('_write_atomic')(root() / 'subtitle-studio.json', json.dumps(value, ensure_ascii=False, indent=2), backup=True)

    def busy():
        return e('get_sub_status')(PROJECT).get('status') == 'running'

    def captions(s):
        status = e('get_sub_status')(PROJECT)
        if status.get('status') != 'done' or s.get('aligned_job') != status.get('job_id'):
            return []
        import subtitle_ost
        doc=e('load_doc')(PROJECT)
        return subtitle_ost.display(e('_display_caption_base')(PROJECT,doc), subtitle_edits.read(root()), s.get('ost_windows',[]) if s.get('auto_ost',True) else [],pacing=e('_subtitle_pacing')(PROJECT,doc))

    def adopt(s):
        status = e('get_sub_status')(PROJECT)
        if s.get('pending_job') and status.get('job_id') == s['pending_job'] and status.get('status') == 'done':
            if s.get('pending_revision') == s['revision']:
                s['aligned_job'] = s['pending_job']
                if status.get('reconciled_script'):
                    s['script'] = status['reconciled_script']
            s.pop('pending_job', None)
            write(s)
        return s

    def public(s):
        out = copy.deepcopy(s)
        status = e('get_sub_status')(PROJECT)
        status['pct'] = e('_srt_pct')(status) if status.get('status') == 'running' else (100 if status.get('status') == 'done' else None)
        preparing = audio_prepare.state(prep_root()).get('status') == 'running'
        out.update(project=PROJECT, captions=[] if preparing else captions(s), status=status, audio_preparing=preparing)
        generated = root() / 'voiceover/voiceover.mp3'
        out['generated_voice'] = dict(url=f'/media/{PROJECT}/voiceover/voiceover.mp3?v={generated.stat().st_mtime_ns}') if generated.is_file() else None
        legacy = e('proj_dir')('_studio')[0]
        old_srt = e('_find_srt')(legacy) if (legacy/'scenes.json').is_file() else None
        out['legacy'] = dict(srt_url='/media/_studio/'+old_srt.relative_to(legacy).as_posix() if old_srt else None,
                             available=bool(old_srt or (legacy/'voiceover/voiceover.mp3').is_file()))
        for kind in ('video', 'audio'):
            if out.get(kind):
                out[kind]['url'] = f'/media/{PROJECT}/' + out[kind]['file']
        return out

    @app.route(PREFIX + '/state', methods=['GET', 'POST'])
    def subtitle_studio_state():
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if request.method == 'POST':
                b = request.get_json(force=True) or {}
                if 'script' in b or 'language' in b:
                    if busy(): return jsonify(error='Stop subtitle generation before changing its inputs.'), 409
                    changed = False
                    for field in ('script', 'language'):
                        if field in b:
                            if not isinstance(b[field], str) or len(b[field]) > (300000 if field == 'script' else 10):
                                return jsonify(error='Invalid subtitle input.'), 400
                            changed |= s.get(field) != b[field]
                            s[field] = b[field]
                    if changed:
                        s['revision'] += 1
                        s.pop('aligned_job', None)
                if 'style' in b:
                    if not isinstance(b['style'], dict): return jsonify(error='Invalid style.'), 400
                    s['style'] = {k:v for k,v in b['style'].items() if k.startswith(('ost_', 'sub_')) and isinstance(v,(str,int,float,bool))}
                if isinstance(b.get('voice_id'), str): s['voice_id'] = b['voice_id'][:200]
                if 'ost_windows' in b:
                    if b.get('ost_video') != (s.get('video') or {}).get('file'):return jsonify(error='The video changed. Scan its on-screen text again.'),409
                    values=b['ost_windows']
                    if not isinstance(values,list) or len(values)>2000:return jsonify(error='Invalid on-screen text matches.'),400
                    clean=[]
                    for v in values:
                        try:
                            a,z=float(v['start']),float(v['end']);text=v['text']
                            assert math.isfinite(a) and math.isfinite(z) and 0<=a<z<=s['video']['duration'] and isinstance(text,str) and len(text)<=2000
                        except (KeyError,TypeError,ValueError,AssertionError):return jsonify(error='Invalid on-screen text time range.'),400
                        clean.append(dict(start=a,end=z,text=text))
                    s['ost_windows']=clean
                if 'auto_ost' in b:s['auto_ost']=bool(b['auto_ost'])
                if b.get('remove_video'):
                    s.pop('video', None)
                    s.pop('ost_windows',None)
                if b.get('audio_mode') in ('video', 'voiceover'):
                    s['audio_mode'] = b['audio_mode']
                write(s)
            return jsonify(public(s))

    @app.post(PREFIX + '/upload/<kind>')
    def subtitle_studio_upload(kind):
        if kind not in ('video', 'audio', 'script'): return jsonify(error='Unknown upload.'), 400
        f = request.files.get('file')
        if not f or not f.filename: return jsonify(error='Choose a file.'), 400
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if busy() or audio_prepare.state(prep_root()).get('status') == 'running': return jsonify(error='Stop subtitle generation or Trim before replacing its inputs.'), 409
            ext = Path(f.filename).suffix.lower()
            allowed = {'video':('.mp4','.mov','.m4v','.webm'), 'audio':('.mp3','.wav','.m4a','.aac','.ogg','.flac','.opus','.wma'), 'script':('.txt','.docx')}
            if ext not in allowed[kind]: return jsonify(error='Unsupported file format.'), 400
            dest = root() / 'uploads' / (uuid.uuid4().hex + ext)
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                f.save(dest)
                if kind == 'script':
                    text = e('_docx_to_text')(dest.read_bytes(), f.filename)
                    if not text.strip(): raise ValueError('The script file is empty.')
                    s['script'] = text
                    s['script_name'] = Path(f.filename).name
                else:
                    info = probe(dest)
                    if kind == 'video' and 'width' not in info: raise ValueError('Choose a file containing video.')
                    if kind == 'audio' and not info['has_audio']: raise ValueError('Choose a recording containing audio.')
                    if kind == 'video' and max(info['width'], info['height']) > 4096: raise ValueError('Use a video up to 4K.')
                    s[kind] = dict(info, file=dest.relative_to(root()).as_posix(), name=Path(f.filename).name)
                    if kind == 'audio':
                        with dest.open('rb') as handle:
                            prep = audio_prepare.upload(prep_root(), FileStorage(handle, filename=s[kind]['name']))
                        s['prep_ref'] = prep['ref']
                    elif kind == 'video':s.pop('ost_windows',None)
                if kind != 'video':
                    s['revision'] += 1
                    s.pop('aligned_job', None)
                write(s)
                return jsonify(public(s))
            except ValueError as exc:
                dest.unlink(missing_ok=True)
                return jsonify(error=str(exc)), 400

    @app.post(PREFIX + '/use-generated')
    def subtitle_studio_use_generated():
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if busy() or audio_prepare.state(prep_root()).get('status') == 'running':
                return jsonify(error='Finish subtitle generation or Trim first.'), 409
            source = root() / 'voiceover/voiceover.mp3'
            if not source.is_file(): return jsonify(error='Generate a voice-over first.'), 400
            with source.open('rb') as handle:
                prep = audio_prepare.upload(prep_root(), FileStorage(handle, filename='Generated_Voiceover.mp3'))
            own_audio(s, source, 'Generated_Voiceover.mp3', prep['ref']); write(s)
            return jsonify(public(s))

    @app.post(PREFIX + '/legacy')
    def subtitle_studio_legacy():
        # Explicit import only: preserve both former workspaces and every source file.
        with e('_project_lock')(PROJECT), e('_project_lock')('_studio'):
            s = adopt(state())
            if busy() or e('get_sub_status')('_studio').get('status') == 'running' or audio_prepare.state(prep_root()).get('status') == 'running':
                return jsonify(error='Finish the current subtitle or Trim job first.'), 409
            old = e('proj_dir')('_studio')[0]
            old_doc = json.loads((old/'scenes.json').read_text('utf8')) if (old/'scenes.json').is_file() else {}
            source_dir = e('subtitle_store').source_dir(old)
            source = e('_find_vo_audio')(old)
            source = source or next(iter(source_dir.glob('audio.*')), None) or (old/'voiceover/voiceover.mp3')
            if not source.is_file(): return jsonify(error='No previous recording is available.'), 404
            old_srt = e('_find_srt')(old)
            scripts = [e('subtitle_store').active_dir(old)/'script.docx', *source_dir.glob('script.*')]
            text = old_doc.get('script_draft') or old_doc.get('script') or ''
            for script in scripts:
                if script.is_file():
                    text = e('_docx_to_text')(script.read_bytes(), script.name); break
            if not text and old_srt:
                text = ' '.join(c['text'] for c in pe.parse_srt(old_srt.read_text('utf8')))
            with source.open('rb') as handle:
                prep = audio_prepare.upload(prep_root(), FileStorage(handle, filename='Previous_Voiceover'+source.suffix))
            own_audio(s, source, 'Previous_Voiceover'+source.suffix, prep['ref'])
            s.update(script=text, language=old_doc.get('subtitle_lang') or 'en')
            s.pop('video', None)
            doc=e('load_doc')(PROJECT);doc.update(script=text,script_draft=text);e('save_doc')(PROJECT,doc)
            if old_srt:
                import tempfile
                with tempfile.TemporaryDirectory(prefix='subtitle-import-') as tmp:
                    wd=Path(tmp); (wd/'_inputs').mkdir()
                    shutil.copyfile(old_srt,wd/'subtitles.srt')
                    for words in e('subtitle_store').active_dir(old).glob('words*.tsv'): shutil.copyfile(words,wd/words.name)
                    shutil.copyfile(source,wd/'_inputs'/('audio'+source.suffix))
                    shutil.copyfile(source,wd/('audio'+source.suffix))
                    jid=uuid.uuid4().hex
                    (wd/'_result.json').write_text(json.dumps(dict(job_id=jid,srt='subtitles.srt',status='done')))
                    published=e('subtitle_store').publish(root(),wd)
                request.environ.get('vsl.subtitle.sets',{}).pop(str(root().resolve()).casefold(),None)
                e('set_sub_status')(PROJECT,status='done',job_id=jid,srt=published.relative_to(root()).as_posix()+'/subtitles.srt')
                s['aligned_job']=jid
            write(s)
            return jsonify(public(s))

    @app.post(PREFIX + '/generate')
    def subtitle_studio_generate():
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if busy(): return jsonify(error='Subtitle generation is already running.'), 409
            if audio_prepare.state(prep_root()).get('status') == 'running':
                return jsonify(error='Finish Trim before generating subtitles.'), 409
            if not s.get('audio') or not s.get('script','').strip():
                return jsonify(error='Upload a voice-over and script first. Video is optional.'), 400
            doc = e('load_doc')(PROJECT)
            doc.update(script=s['script'], script_draft=s['script'], subtitle_lang=s['language'])
            e('save_doc')(PROJECT, doc)
            from werkzeug.datastructures import FileStorage
            form = dict(use_script='true', script_text=s['script'], lang=s['language'], trim='false')
            if (request.get_json(silent=True) or {}).get('force'): form['force'] = 'true'
            with (root() / s['audio']['file']).open('rb') as handle:
                result, code = e('_start_subtitle')(PROJECT, doc, form, FileStorage(handle, filename=s['audio']['name']))
            if result.get('status') == 'running':
                s.update(pending_job=e('get_sub_status')(PROJECT).get('job_id'), pending_revision=s['revision'])
                s.pop('aligned_job', None)
                write(s)
            return jsonify(result), code

    def worker(jid, snapshot, caps, kind, directory):
        job = jobs[jid]
        cancelled = lambda: bool(job.get('cancel'))
        progress = job['_progress']
        wd = directory / 'exports' / jid
        wd.mkdir(parents=True, exist_ok=True)
        try:
            media = snapshot.get('video'); total = media['duration'] if media else snapshot['audio']['duration']
            w,h = (media['width'],media['height']) if media else (1920,1080); fps = media['fps'] if media else 60
            caps = [dict(c, end=min(c['end'], total)) for c in caps if c['text'].strip() and c['start'] < total]
            if not caps and kind=='overlay': raise ValueError('All captions are hidden. There is no subtitle overlay to export.')
            if kind == 'srt':
                result = wd / 'Subtitles.srt'
                result.write_text(pe.caps_to_srt(caps), 'utf8')
            else:
                layer=None
                if caps:
                    with project_canvas.scope(dims=(w,h)):
                        items = render_video._browser_items(caps, [], snapshot['style'], dict(burnsubs=True,onscreentext=False))
                        layer = caption_layer.build_subtitle_overlay(items, directory / 'exports' / 'captions', total, fps, w, h,
                            should_cancel=cancelled, stage_progress=progress.update, pixel_ratio=2 if kind=='overlay' else 1)
                result = layer
                if kind == 'video':
                    progress.update('Rendering Video', 0, total, 'seconds')
                    result = wd / 'Subtitled_Video.mp4'
                    command = ['-i', str(directory / media['file'])]
                    if layer:command += ['-i', str(layer)]
                    audio = '0:a?'
                    if snapshot.get('audio_mode') == 'voiceover':
                        command += ['-i', str(directory / snapshot['audio']['file'])]
                        audio = '2:a:0' if layer else '1:a:0'
                    graph='[0:v]setpts=PTS-STARTPTS,setsar=1[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[out]' if layer else '[0:v]setpts=PTS-STARTPTS,setsar=1,format=yuv420p[out]'
                    command += ['-filter_complex', graph,
                                '-map','[out]','-map',audio,'-t',str(total),'-r',str(fps),'-c:v','libx264','-crf','16','-preset','fast',
                                '-c:a','aac','-b:a','256k','-movflags','+faststart',str(result)]
                    encode(command,total,lambda a,b:progress.update('Rendering Video',a,b,'seconds'),cancelled,wd/'render.log')
            if cancelled(): raise ValueError('Cancelled')
            job.update(status='done', file=str(result), name=('Subtitles_Alpha_2x.mov' if kind=='overlay' else result.name))
            progress.update('Ready', 1, 1, 'files')
        except Exception as exc:
            job.update(status='cancelled' if cancelled() else 'error', error=str(exc))

    def export_changed(job):
        if not job.get('export_signature'): return False  # OCR jobs have no download snapshot.
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            try:
                return job['export_signature'] != _export_signature(s, captions(s), job['export_kind'])
            except ValueError:
                return True

    outdated = 'Subtitles changed after this export started. Download again to include your latest edits.'

    @app.post(PREFIX + '/export/<kind>')
    def subtitle_studio_export(kind):
        if kind not in ('srt','overlay','video'): return jsonify(error='Unknown download.'), 400
        with e('_project_lock')(PROJECT):
            s = adopt(state()); caps = captions(s)
            if audio_prepare.state(prep_root()).get('status') == 'running': return jsonify(error='Finish Trim first.'), 409
            if not caps: return jsonify(error='Generate subtitles for the current inputs first.'), 409
            if kind != 'srt' and not s.get('video'): return jsonify(error='Upload a video for a styled export.'), 400
            if not s.get('style'): return jsonify(error='Select a subtitle style first.'), 400
            if any(j.get('status') == 'running' for j in jobs.values()): return jsonify(error='Wait for the current subtitle export or stop it.'), 409
            jid = uuid.uuid4().hex
            jobs[jid] = dict(status='running', _progress=download_progress.Progress(),
                             export_kind=kind, export_signature=_export_signature(s,caps,kind))
            e('_KeyThread')(target=worker, args=(jid,copy.deepcopy(s),copy.deepcopy(caps),kind,root()),daemon=True).start()
            return jsonify(job=jid)

    @app.post(PREFIX + '/scan-ost')
    def subtitle_studio_scan_ost():
        with e('_project_lock')(PROJECT):
            s=adopt(state());caps=captions(s)
            if not s.get('video') or not caps:return jsonify(error='Add a video and generate subtitles first.'),400
            if any(j.get('status')=='running' for j in jobs.values()):return jsonify(error='Finish the current scan or export first.'),409
            jid=uuid.uuid4().hex;directory=root()/'exports'/jid
            job=jobs[jid]=dict(status='running',_progress=download_progress.Progress(),video=s['video']['file'])
            video=dict(s['video'],path=str(root()/s['video']['file']))
            # Rescanning uses all manually edited captions, not the prior OCR exclusions.
            caps=subtitle_edits.apply(e('_display_caption_base')(PROJECT,e('load_doc')(PROJECT)),subtitle_edits.read(root()))
            def work():
                try:
                    import subtitle_ocr
                    windows,language=subtitle_ocr.scan(video,directory,caps,s['language'],encode,job['_progress'],lambda:bool(job.get('cancel')))
                    job.update(status='done',windows=windows,ocr_language=language)
                    job['_progress'].update('Text Matches Ready',1,1,'scans')
                except Exception as exc:job.update(status='cancelled' if job.get('cancel') else 'error',error=str(exc))
            e('_KeyThread')(target=work,daemon=True).start()
            return jsonify(job=jid)

    @app.route(PREFIX + '/job/<jid>', methods=['GET','POST'])
    def subtitle_studio_job(jid):
        job = jobs.get(jid)
        if not job: return jsonify(error='Job not found.'), 404
        if request.method == 'POST': job['cancel'] = True
        result = {k:v for k,v in job.items() if k in ('status','error','name','windows','video','ocr_language')}
        if job.get('status') == 'done' and export_changed(job):
            result.update(status='outdated', message=outdated)
        return jsonify(dict(result, **job['_progress'].snapshot()))

    @app.get(PREFIX + '/download/<jid>')
    def subtitle_studio_download(jid):
        job = jobs.get(jid)
        if not job or job.get('status') != 'done' or not job.get('file'): return jsonify(error='Download is not ready.'), 404
        if export_changed(job): return jsonify(error=outdated), 409
        return send_file(job['file'], as_attachment=True, download_name=job['name'], conditional=True)
