"""Account-local Subtitle Studio: finished video in, styled captions out.

The hidden workspace is separate from projects and the Voiceover & Subtitles tab.
Source recordings/videos are retained. Export workers read immutable snapshots.
"""
import copy
import json
import math
import os
from pathlib import Path
import subprocess
import time
import uuid

PROJECT = '_subtitle_video'
PREFIX = '/api/studio/subtitle'


def probe(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
                            capture_output=True, timeout=40, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise ValueError('This media file could not be read.')
    data = json.loads(result.stdout)
    streams = data.get('streams', [])
    video = next((s for s in streams if s.get('codec_type') == 'video' and not s.get('disposition', {}).get('attached_pic')), None)
    duration = float(data.get('format', {}).get('duration') or (video or {}).get('duration') or 0)
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('The media duration could not be read.')
    info = dict(duration=duration, has_audio=any(s.get('codec_type') == 'audio' for s in streams))
    if video:
        width, height = int(video['width']), int(video['height'])
        rotation = int(float(video.get('tags', {}).get('rotate', 0)))
        for side in video.get('side_data_list', []):
            rotation = int(side.get('rotation', rotation))
        if abs(rotation) % 180 == 90:
            width, height = height, width
        sar = video.get('sample_aspect_ratio', '1:1')
        if sar not in ('1:1', 'N/A', '0:1'):
            raise ValueError('Export the video with square pixels before uploading it.')
        rate = video.get('avg_frame_rate', '30/1').split('/')
        fps = float(rate[0]) / max(1, float(rate[-1]))
        info.update(width=width, height=height, fps=max(1, min(60, round(fps) or 30)), codec=video.get('codec_name'))
    return info


def encode(command, duration, progress, cancelled, logfile):
    """FFmpeg's encoded clock, not an arbitrary timer, drives export progress."""
    command = ['ffmpeg', '-hide_banner', '-nostdin', '-y', '-progress', 'pipe:1', '-nostats', *command]
    with open(logfile, 'wb') as log:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log, text=True,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        # Cancellation also works while the encoder has not produced a line yet.
        import threading
        finished = threading.Event()
        def watch():
            while not finished.wait(.15):
                if cancelled():
                    process.kill()
                    return
        threading.Thread(target=watch, daemon=True).start()
        try:
            for line in process.stdout:
                if line.startswith('out_time_us='):
                    try: progress(min(duration, int(line.split('=')[1]) / 1e6), duration)
                    except ValueError: pass
            code = process.wait()
            if cancelled():
                raise ValueError('Cancelled')
            if code:
                raise RuntimeError('Video export failed. ' + Path(logfile).read_text('utf8', errors='replace')[-800:])
        finally:
            finished.set()
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdout.close()


def register(app, env):
    from flask import request, jsonify, send_file
    import caption_layer
    import subtitle_edits
    import premiere_export as pe
    import project_canvas
    import render_video
    import download_progress
    e = lambda name: env[name]
    jobs = e('_user_job_registry')('subtitle-studio')

    def root():
        return e('proj_dir')(PROJECT)[0]

    def ensure():
        with e('_project_lock')(PROJECT):
            if e('load_doc')(PROJECT) is None:
                e('save_doc')(PROJECT, dict(title='Subtitle Studio', script='', script_draft='', scenes=[], characters=[], ptype='vsl'))

    def state():
        ensure()
        path = root() / 'subtitle-studio.json'
        return json.loads(path.read_text('utf8')) if path.exists() else dict(revision=0, script='', language='en', style={}, audio_mode='video')

    def write(value):
        e('_write_atomic')(root() / 'subtitle-studio.json', json.dumps(value, ensure_ascii=False, indent=2), backup=True)

    def busy():
        return e('get_sub_status')(PROJECT).get('status') == 'running'

    def captions(s):
        status = e('get_sub_status')(PROJECT)
        if status.get('status') != 'done' or s.get('aligned_job') != status.get('job_id'):
            return []
        return subtitle_edits.apply(e('_display_caption_base')(PROJECT, e('load_doc')(PROJECT)), subtitle_edits.read(root()))

    def adopt(s):
        status = e('get_sub_status')(PROJECT)
        if s.get('pending_job') and status.get('job_id') == s['pending_job'] and status.get('status') == 'done':
            if s.get('pending_revision') == s['revision']:
                s['aligned_job'] = s['pending_job']
                if status.get('reconciled_script'):
                    s['script'] = status['reconciled_script']
            s.pop('pending_job', None)
            write(s)
        return s

    def public(s):
        out = copy.deepcopy(s)
        status = e('get_sub_status')(PROJECT)
        status['pct'] = e('_srt_pct')(status) if status.get('status') == 'running' else (100 if status.get('status') == 'done' else None)
        out.update(project=PROJECT, captions=captions(s), status=status)
        for kind in ('video', 'audio'):
            if out.get(kind):
                out[kind]['url'] = f'/media/{PROJECT}/' + out[kind]['file']
        return out

    @app.route(PREFIX + '/state', methods=['GET', 'POST'])
    def subtitle_studio_state():
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if request.method == 'POST':
                b = request.get_json(force=True) or {}
                if 'script' in b or 'language' in b:
                    if busy(): return jsonify(error='Stop subtitle generation before changing its inputs.'), 409
                    changed = False
                    for field in ('script', 'language'):
                        if field in b:
                            if not isinstance(b[field], str) or len(b[field]) > (300000 if field == 'script' else 10):
                                return jsonify(error='Invalid subtitle input.'), 400
                            changed |= s.get(field) != b[field]
                            s[field] = b[field]
                    if changed:
                        s['revision'] += 1
                        s.pop('aligned_job', None)
                if 'style' in b:
                    if not isinstance(b['style'], dict): return jsonify(error='Invalid style.'), 400
                    s['style'] = {k:v for k,v in b['style'].items() if k.startswith(('ost_', 'sub_')) and isinstance(v,(str,int,float,bool))}
                if b.get('audio_mode') in ('video', 'voiceover'):
                    s['audio_mode'] = b['audio_mode']
                write(s)
            return jsonify(public(s))

    @app.post(PREFIX + '/upload/<kind>')
    def subtitle_studio_upload(kind):
        if kind not in ('video', 'audio', 'script'): return jsonify(error='Unknown upload.'), 400
        f = request.files.get('file')
        if not f or not f.filename: return jsonify(error='Choose a file.'), 400
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if busy(): return jsonify(error='Stop subtitle generation before replacing its inputs.'), 409
            ext = Path(f.filename).suffix.lower()
            allowed = {'video':('.mp4','.mov','.m4v','.webm'), 'audio':('.mp3','.wav','.m4a','.aac','.ogg','.flac'), 'script':('.txt','.docx')}
            if ext not in allowed[kind]: return jsonify(error='Unsupported file format.'), 400
            dest = root() / 'uploads' / (uuid.uuid4().hex + ext)
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                f.save(dest)
                if kind == 'script':
                    text = e('_docx_to_text')(dest.read_bytes(), f.filename)
                    if not text.strip(): raise ValueError('The script file is empty.')
                    s['script'] = text
                    s['script_name'] = Path(f.filename).name
                else:
                    info = probe(dest)
                    if kind == 'video' and 'width' not in info: raise ValueError('Choose a file containing video.')
                    if kind == 'audio' and not info['has_audio']: raise ValueError('Choose a recording containing audio.')
                    if kind == 'video' and max(info['width'], info['height']) > 4096: raise ValueError('Use a video up to 4K.')
                    s[kind] = dict(info, file=dest.relative_to(root()).as_posix(), name=Path(f.filename).name)
                s['revision'] += 1
                s.pop('aligned_job', None)
                write(s)
                return jsonify(public(s))
            except ValueError as exc:
                dest.unlink(missing_ok=True)
                return jsonify(error=str(exc)), 400

    @app.post(PREFIX + '/generate')
    def subtitle_studio_generate():
        with e('_project_lock')(PROJECT):
            s = adopt(state())
            if busy(): return jsonify(error='Subtitle generation is already running.'), 409
            if not s.get('video') or not s.get('audio') or not s.get('script','').strip():
                return jsonify(error='Upload a video, voice-over and script first.'), 400
            doc = e('load_doc')(PROJECT)
            doc.update(script=s['script'], script_draft=s['script'], subtitle_lang=s['language'])
            e('save_doc')(PROJECT, doc)
            from werkzeug.datastructures import FileStorage
            form = dict(use_script='true', script_text=s['script'], lang=s['language'], trim='false')
            if (request.get_json(silent=True) or {}).get('force'): form['force'] = 'true'
            with (root() / s['audio']['file']).open('rb') as handle:
                result, code = e('_start_subtitle')(PROJECT, doc, form, FileStorage(handle, filename=s['audio']['name']))
            if result.get('status') == 'running':
                s.update(pending_job=e('get_sub_status')(PROJECT).get('job_id'), pending_revision=s['revision'])
                s.pop('aligned_job', None)
                write(s)
            return jsonify(result), code

    def worker(jid, snapshot, caps, kind, directory):
        job = jobs[jid]
        cancelled = lambda: bool(job.get('cancel'))
        progress = job['_progress']
        wd = directory / 'exports' / jid
        wd.mkdir(parents=True, exist_ok=True)
        try:
            media = snapshot['video']; w,h = media['width'],media['height']; total = media['duration']; fps = media['fps']
            caps = [dict(c, end=min(c['end'], total)) for c in caps if c['text'].strip() and c['start'] < total]
            if not caps: raise ValueError('No visible subtitles to export.')
            if kind == 'srt':
                result = wd / 'Subtitles.srt'
                result.write_text(pe.caps_to_srt(caps), 'utf8')
            else:
                with project_canvas.scope(dims=(w,h)):
                    items = render_video._browser_items(caps, [], snapshot['style'], dict(burnsubs=True,onscreentext=False))
                    layer = caption_layer.build_subtitle_overlay(items, directory / 'exports' / 'captions', total, fps, w, h,
                        should_cancel=cancelled, stage_progress=progress.update, pixel_ratio=2 if kind=='overlay' else 1)
                result = layer
                if kind == 'video':
                    progress.update('Rendering Video', 0, total, 'seconds')
                    result = wd / 'Subtitled_Video.mp4'
                    command = ['-i', str(directory / media['file']), '-i', str(layer)]
                    audio = '0:a?'
                    if snapshot.get('audio_mode') == 'voiceover':
                        command += ['-i', str(directory / snapshot['audio']['file'])]
                        audio = '2:a:0'
                    command += ['-filter_complex', '[0:v]setpts=PTS-STARTPTS,setsar=1[base];[base][1:v]overlay=0:0:format=auto,format=yuv420p[out]',
                                '-map','[out]','-map',audio,'-t',str(total),'-r',str(fps),'-c:v','libx264','-crf','16','-preset','fast',
                                '-c:a','aac','-b:a','256k','-movflags','+faststart',str(result)]
                    encode(command,total,lambda a,b:progress.update('Rendering Video',a,b,'seconds'),cancelled,wd/'render.log')
            if cancelled(): raise ValueError('Cancelled')
            job.update(status='done', file=str(result), name=('Subtitles_Alpha_2x.mov' if kind=='overlay' else result.name))
            progress.update('Ready', 1, 1, 'files')
        except Exception as exc:
            job.update(status='cancelled' if cancelled() else 'error', error=str(exc))

    @app.post(PREFIX + '/export/<kind>')
    def subtitle_studio_export(kind):
        if kind not in ('srt','overlay','video'): return jsonify(error='Unknown download.'), 400
        with e('_project_lock')(PROJECT):
            s = adopt(state()); caps = captions(s)
            if not s.get('video') or not caps: return jsonify(error='Generate subtitles for the current inputs first.'), 409
            if not s.get('style'): return jsonify(error='Select a subtitle style first.'), 400
            if any(j.get('status') == 'running' for j in jobs.values()): return jsonify(error='Wait for the current subtitle export or stop it.'), 409
            jid = uuid.uuid4().hex
            jobs[jid] = dict(status='running', _progress=download_progress.Progress())
            e('_KeyThread')(target=worker, args=(jid,copy.deepcopy(s),copy.deepcopy(caps),kind,root()),daemon=True).start()
            return jsonify(job=jid)

    @app.route(PREFIX + '/job/<jid>', methods=['GET','POST'])
    def subtitle_studio_job(jid):
        job = jobs.get(jid)
        if not job: return jsonify(error='Job not found.'), 404
        if request.method == 'POST': job['cancel'] = True
        result = {k:v for k,v in job.items() if k in ('status','error','name')}
        return jsonify(dict(result, **job['_progress'].snapshot()))

    @app.get(PREFIX + '/download/<jid>')
    def subtitle_studio_download(jid):
        job = jobs.get(jid)
        if not job or job.get('status') != 'done': return jsonify(error='Download is not ready.'), 404
        return send_file(job['file'], as_attachment=True, download_name=job['name'], conditional=True)
