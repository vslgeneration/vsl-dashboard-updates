"""Local, user-configured stock catalog. Source archives are never opened for writing."""
from pathlib import Path
import contextlib
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import threading
import time
import unicodedata
import uuid

ID = re.compile(r'[a-f0-9]{32}')
LOCK = threading.RLock()
FILE_LOCK = threading.Lock()
STOP_WORDS = set('a an the and or of in on at to with from for is are by as this that scene video stock footage clip close up shot show showing view woman man person people adult'.split())


def read_json(path, fallback=None):
    try: return json.loads(Path(path).read_text(encoding='utf8'))
    except (OSError, ValueError): return fallback


def write_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    part = path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with part.open('x', encoding='utf8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2); f.flush(); os.fsync(f.fileno())
        os.replace(part, path)
    finally: part.unlink(missing_ok=True)


def configured(stock_root):
    value = read_json(Path(stock_root)/'library.json', {}) or {}
    path = value.get('directory')
    if not isinstance(path, str) or not path: return None
    root = Path(path)
    if not root.is_absolute() or not root.is_dir(): return None
    marker = read_json(root/'.vsl-library-owned.json', {}) or {}
    return root.resolve() if marker.get('originals_read_only') is True else None


def safe_file(root, relative):
    if not isinstance(relative, str) or not relative: raise ValueError('Library file is unavailable.')
    p = (Path(root)/relative).resolve()
    if not p.is_relative_to(Path(root).resolve()) or not p.is_file():
        raise ValueError('Library file is unavailable. The scene was not changed.')
    return p


@contextlib.contextmanager
def database(root):
    db = sqlite3.connect(str(Path(root)/'catalog.sqlite3'), timeout=20)
    db.row_factory = sqlite3.Row
    try:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('''CREATE TABLE IF NOT EXISTS assets (
            id TEXT PRIMARY KEY, sha256 TEXT UNIQUE NOT NULL, file TEXT NOT NULL,
            original_name TEXT NOT NULL, source_folder TEXT NOT NULL, bytes INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '[]',
            duration REAL, width INTEGER, height INTEGER, fps REAL, codec TEXT,
            poster TEXT, sheet TEXT, fingerprints TEXT, metadata TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'pending', error TEXT NOT NULL DEFAULT '',
            duplicate_of TEXT, reviewed INTEGER NOT NULL DEFAULT 0, updated REAL NOT NULL
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS asset_status ON assets(status,duplicate_of)')
        db.execute('CREATE VIRTUAL TABLE IF NOT EXISTS asset_search USING fts5(id UNINDEXED,title,tags,description,original, tokenize="unicode61 remove_diacritics 2")')
        db.commit()
        yield db
        db.commit()
    except BaseException:
        db.rollback(); raise
    finally: db.close()


def normalize_words(value):
    value = unicodedata.normalize('NFKD', str(value).casefold().replace('ı','i'))
    value = ''.join(c for c in value if not unicodedata.combining(c))
    return re.findall(r'[^\W_]+', value, re.UNICODE)


def revision(root):
    if not root:return 'none'
    path=Path(root)/'catalog.sqlite3'
    if not path.exists():return 'empty'
    try:
        with contextlib.closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=5)) as db:
            summary=db.execute('SELECT COUNT(*),COALESCE(MAX(updated),0),COALESCE(SUM(reviewed),0) FROM assets').fetchone()
        return hashlib.sha256((str(root)+repr(summary)).encode()).hexdigest()[:20]
    except sqlite3.Error:return 'preparing'


def refresh_search(db, row):
    db.execute('DELETE FROM asset_search WHERE id=?', (row['id'],))
    if row['duplicate_of'] or row['status'] not in ('ready','reviewed'): return
    clean=lambda text:' '.join(normalize_words(text))
    tags=' '.join(json.loads(row['tags']))
    db.execute('INSERT INTO asset_search(id,title,tags,description,original) VALUES(?,?,?,?,?)',
               (row['id'],clean(row['title']),clean(tags),clean(row['description']),clean(row['original_name']+' '+row['source_folder'])))


def asset(root, asset_id):
    if not ID.fullmatch(str(asset_id)): raise ValueError('Choose a valid Library video.')
    with database(root) as db:
        seen=set()
        while asset_id not in seen:
            seen.add(asset_id); r=db.execute('SELECT * FROM assets WHERE id=?',(asset_id,)).fetchone()
            if not r: break
            if not r['duplicate_of']: return dict(r)
            asset_id=r['duplicate_of']
    raise ValueError('This Library video is no longer available. Search again.')


def public(row):
    ident=row['id']; metadata=json.loads(row['metadata'] or '{}')
    return dict(id='library-'+ident,asset_id=ident,provider='library',type='video',title=row['title'] or row['original_name'],
        description=row['description'],tags=json.loads(row['tags']),duration=row['duration'],fps=row['fps'],
        aspect_ratio=row['width']/row['height'] if row['width'] and row['height'] else None,
        thumbnail='/api/stock/library/'+ident+'/poster',preview='/api/stock/library/'+ident+'/preview',
        url='',reviewed=bool(row['reviewed']),observations=metadata)


def search(root, queries, aspect='16:9', *, page=1, limit=24, reviewed_only=False, prefix=False):
    if not root: return [],False
    import stock_filters
    words=list(dict.fromkeys(w for q in queries for w in normalize_words(q)))[:60]
    useful=[w for w in words if w not in STOP_WORDS and len(w)>1]
    if not prefix:words=useful or words
    start=(max(1,min(1000,int(page)))-1)*limit
    priority = ("CASE WHEN a.height>0 AND ABS(1.0*a.width/a.height-0.5625)<=0.01 THEN 0 "
                "WHEN a.width>0 AND a.height>a.width THEN 1 ELSE 2 END," if aspect=='portrait-first' else '')
    with database(root) as db:
        clause="a.status IN ('ready','reviewed') AND a.duplicate_of IS NULL"+(' AND a.reviewed=1' if reviewed_only else '')
        if prefix:
            # Rank/filter IDs first: sorting every clip's full metadata made one-letter
            # queries and empty browsing disproportionately expensive.
            args=[]
            if reviewed_only:clause+=" AND COALESCE(json_extract(a.metadata,'$.watermark'),'')!='yes'"
            if aspect not in ('any','portrait-first'):
                clause+=' AND a.width>0 AND a.height>0'
                if aspect in ('16:9','9:16','1:1'):
                    clause+=' AND ABS(1.0*a.width/a.height-?)<=0.01';args.append({'16:9':16/9,'9:16':9/16,'1:1':1}[aspect])
                else:clause+=' AND a.width'+('>' if aspect=='landscape' else '<')+'a.height'
            if words:
                match=' AND '.join('"'+w+'"'+('*' if i==len(words)-1 else '') for i,w in enumerate(words))
                sql='SELECT a.id,bm25(asset_search,0,8,5,2,0.5) AS score FROM asset_search JOIN assets a ON a.id=asset_search.id WHERE asset_search MATCH ? AND '+clause+' ORDER BY '+priority+'score,a.id'
                args.insert(0,match)
            else:sql='SELECT a.id FROM assets a WHERE '+clause+' ORDER BY '+priority+'a.reviewed DESC,a.title,a.id'
            ids=[r['id'] for r in db.execute(sql+' LIMIT ? OFFSET ?',args+[limit+1,start])]
            more=len(ids)>limit;ids=ids[:limit]
            rows={r['id']:r for r in db.execute('SELECT * FROM assets WHERE id IN ('+','.join('?' for _ in ids)+')',ids)} if ids else {}
            return [public(rows[i]) for i in ids],more
        if words:
            match=(' AND ' if prefix else ' OR ').join('"'+w+'"'+('*' if prefix and i==len(words)-1 else '') for i,w in enumerate(words))
            rows=db.execute('SELECT a.*,bm25(asset_search,0,8,5,2,0.5) AS score FROM asset_search JOIN assets a ON a.id=asset_search.id WHERE asset_search MATCH ? AND '+clause+' ORDER BY '+priority+'score,a.id LIMIT 20000',(match,))
        else:
            rows=db.execute('SELECT a.* FROM assets a WHERE '+clause+' ORDER BY '+priority+'a.reviewed DESC,a.title,a.id LIMIT 20000')
        selected=[]
        for row in rows:
            item=public(row)
            if reviewed_only and item['observations'].get('watermark')=='yes':continue
            if stock_filters.accepts(item,aspect): selected.append(item)
            if len(selected)>start+limit:break
    return selected[start:start+limit],len(selected)>start+limit


def state(root):
    if not root: return dict(configured=False,total=0,ready=0,reviewed=0)
    with database(root) as db:
        count=lambda clause:db.execute('SELECT COUNT(*) FROM assets WHERE '+clause).fetchone()[0]
        value=dict(configured=True,total=count('duplicate_of IS NULL'),ready=count("status IN ('ready','reviewed') AND duplicate_of IS NULL"),
                   reviewed=count('reviewed=1 AND duplicate_of IS NULL'),errors=count("status='error'"),duplicates=count('duplicate_of IS NOT NULL'))
    # Only progress and counts are public. Do not expose source paths or raw model output.
    for name in ('copy','index'):
        status=read_json(Path(root)/(name+'-status.json'),{}) or {}
        value[name]={k:status[k] for k in ('state','total_files','completed_files','unique_files','duplicate_files','reviewed','prepared','message') if k in status}
    return value


def run_media(args, timeout=180):
    result=subprocess.run(args,capture_output=True,timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode: raise ValueError('Could not read this Library video.')
    return result.stdout


def probe(path):
    data=json.loads(run_media(['ffprobe','-v','error','-select_streams','v:0','-show_entries',
        'stream=codec_name,width,height,avg_frame_rate,pix_fmt:format=duration','-of','json',str(path)],60))
    stream=next(iter(data.get('streams') or []),{})
    duration=float((data.get('format') or {}).get('duration') or 0)
    if not math.isfinite(duration) or duration<=0 or not stream.get('width') or not stream.get('height'):raise ValueError('Unreadable video duration or dimensions.')
    try:
        a,b=stream.get('avg_frame_rate','0/1').split('/');fps=float(a)/float(b)
        if not math.isfinite(fps) or fps<=0:fps=None
    except (ValueError,ZeroDivisionError):fps=None
    return dict(duration=duration,width=stream['width'],height=stream['height'],fps=fps,codec=stream.get('codec_name'),pix_fmt=stream.get('pix_fmt'))


def playback(root, row, directory=None, hd=False):
    """Preserve full length and native timing. Remux compatible MOV; encode only when needed for playback."""
    src=safe_file(root,row['file'])
    meta=json.loads(row['metadata'] or '{}');compatible=row['codec']=='h264' and meta.get('pix_fmt') in ('yuv420p','yuvj420p')
    if src.suffix.lower()=='.mp4' and compatible and (not hd or (row['width']<=1920 and row['height']<=1080)):
        return src
    cache=Path(directory) if directory else Path(root)/'previews';cache.mkdir(parents=True,exist_ok=True)
    target=cache/(row['id']+('-hd' if hd else '-preview')+'.mp4')
    with FILE_LOCK:
        if target.is_file() and target.stat().st_size:return target
        part=target.with_name(target.stem+'.'+uuid.uuid4().hex+'.part.mp4')
        try:
            args=['ffmpeg','-nostdin','-v','error','-i',str(src),'-map','0:v:0','-map','0:a?']
            if compatible and (not hd or (row['width']<=1920 and row['height']<=1080)):
                args+=['-c:v','copy']
            else:
                maxw,maxh=(1920,1080) if hd else (960,540)
                args+=['-vf',f'scale=w=min({maxw}\\,iw):h=min({maxh}\\,ih):force_original_aspect_ratio=decrease:force_divisible_by=2',
                       '-c:v','libx264','-preset','veryfast','-crf','18' if hd else '25','-pix_fmt','yuv420p','-threads','2']
            args+=['-c:a','aac','-b:a','192k','-movflags','+faststart','-n',str(part)]
            run_media(args,timeout=900)
            measured=probe(part)
            if abs(measured['duration']-row['duration'])>max(.25,1/(row['fps'] or 24)*3):
                raise ValueError('Library conversion did not preserve the complete video duration.')
            os.replace(part,target);return target
        finally:part.unlink(missing_ok=True)


def register(app, ns, stock_root):
    from flask import abort,jsonify,request,send_file
    jobs=ns['_user_job_registry']('library-preview')
    def root():
        found=configured(stock_root())
        if not found:abort(404)
        return found
    @app.get('/api/stock/library/status')
    def library_status():return jsonify(state(configured(stock_root())))
    @app.get('/api/stock/library/<ident>/poster')
    def library_poster(ident):
        try:
            r=root();a=asset(r,ident);return send_file(safe_file(r,a['poster']),conditional=True)
        except ValueError:abort(404)
    @app.route('/api/stock/library/<ident>/preview',methods=['GET','POST'])
    def library_preview(ident):
        r=root()
        try:a=asset(r,ident)
        except ValueError:abort(404)
        if request.method=='GET':
            job=jobs.get(ident)
            if not job or job['status']!='ready':abort(404)
            return send_file(safe_file(r,job['file']),conditional=True,mimetype='video/mp4')
        with LOCK:
            job=jobs.get(ident)
            if job and job['status']=='error' and (request.get_json(silent=True) or {}).get('retry') is True:
                jobs.pop(ident,None);job=None
            if job:return jsonify({k:v for k,v in job.items() if k!='file'})
            if sum(j['status']=='running' for j in jobs.values())>=2:return jsonify(error='Another preview is preparing. Please wait.'),409
            jobs[ident]=dict(status='running')
        def worker():
            try:
                p=playback(r,a)
                jobs[ident]=dict(status='ready',file=p.relative_to(r).as_posix())
            except Exception:
                jobs[ident]=dict(status='error',error='Could not prepare this Library preview.')
        ns['_KeyThread'](target=worker,daemon=True).start()
        return jsonify(status='running')
