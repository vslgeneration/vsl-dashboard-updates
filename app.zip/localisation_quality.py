"""Localisation evidence, bounded edits and explicitly approved translation memory helpers."""
import math,re,unicodedata
from collections import Counter
from decimal import Decimal,InvalidOperation
from PIL import Image,ImageDraw

def text(value):return unicodedata.normalize('NFKC',str(value or '')).strip()
def folded(value):return re.sub(r'\s+',' ',text(value)).casefold()
def box(value):
 if not isinstance(value,(list,tuple)) or len(value)!=4:return None
 if any(isinstance(x,bool) or not isinstance(x,(float,int)) or not math.isfinite(x) for x in value):return None
 x,y,w,h=[round(float(v),2) for v in value]
 if min(x,y)<0 or min(w,h)<1 or x+w>1000.01 or y+h>1000.01:return None
 return [x,y,w,h]
def normalise_analysis(answer):
 lines=[]
 for n,row in enumerate(answer['lines']):
  lines.append(dict(row,id='text-'+str(n+1),box=box(row.get('box')),protected=row.get('protected') is True))
 refs=[]
 for row in answer.get('reference_regions',[]):
  if isinstance(row,dict) and box(row.get('box')):refs.append(dict(id=str(row.get('id')),box=box(row['box'])))
 unreadable=[]
 for row in answer.get('unreadable_regions',[]):
  if isinstance(row,dict):unreadable.append(dict(box=box(row.get('box')),reason=str(row.get('reason') or 'Unreadable source text')[:500]))
 return dict(lines=lines,reference_regions=refs,unreadable_regions=unreadable[:80],regions_version=1)
def regions(analysis):
 # Unchanged names/numbers are deliberately outside the edit mask.
 rows=[dict(id=r.get('id'),box=box(r.get('box')),kind='text') for r in analysis.get('lines',[]) if text(r.get('source'))!=text(r.get('target'))]
 for ref in analysis.get('reference_ids',[]):
  matches=[r for r in analysis.get('reference_regions',[]) if r.get('id')==ref and box(r.get('box'))]
  if not matches:raise ValueError('Outline the matching product or page region for every selected reference.')
  rows.extend(dict(id=ref,box=box(r['box']),kind='reference') for r in matches)
 if any(not r['box'] for r in rows):raise ValueError('Mark the missing text regions before localising. Detect Text again or use Edit Regions.')
 if not rows:raise ValueError('No text or reference region needs changing.')
 return rows
def compose(source,generated,destination,analysis):
 edits=regions(analysis)
 with Image.open(source) as src,Image.open(generated) as gen:
  src=src.convert('RGBA');gen=gen.convert('RGBA')
  if abs((gen.width/gen.height)/(src.width/src.height)-1)>.03:raise ValueError('Generated image framing changed. The result was kept for review; no original was replaced.')
  if gen.size!=src.size:gen=gen.resize(src.size,Image.Resampling.LANCZOS)
  mask=Image.new('L',src.size);draw=ImageDraw.Draw(mask)
  for r in edits:
   x,y,w,h=r['box'];left=int(x*src.width/1000);top=int(y*src.height/1000);right=math.ceil((x+w)*src.width/1000);bottom=math.ceil((y+h)*src.height/1000)
   draw.rectangle((left,top,min(src.width,right)-1,min(src.height,bottom)-1),fill=255)
  # Hard boundary: even feathering must never alter pixels outside the approved rectangles.
  Image.composite(gen,src,mask).save(destination,'PNG')
 return dict(mode='regions',regions=edits,outside_pixels_preserved=True)

def numbers(value,language):
 """Compare numeric values with language-aware decimal/thousands punctuation, including repetitions."""
 decimal_comma=folded(language).split()[0] in {'french','german','spanish','italian','portuguese','turkish','dutch','polish','romanian','russian'}
 values=[]
 for token in re.findall(r'(?<!\w)[+−-]?\d+(?:[.,\u00a0\u202f ]\d+)*(?:\s*[%‰€$£])?',text(value)):
  symbol=''.join(c for c in token if c in '%‰€$£');n=re.sub(r'[%‰€$£\s\u00a0\u202f]','',token).replace('−','-')
  n=n.replace('.','').replace(',','.') if decimal_comma else n.replace(',','')
  try:values.append((str(Decimal(n).normalize()),symbol))
  except InvalidOperation:values.append((n,symbol))
 return Counter(values)
def check(analysis,answer,source_language,target_language):
 issues=[];findings=[]
 def add(reason,bounds=None,kind='text'):
  issues.append(reason);findings.append(dict(kind=kind,message=reason,box=box(bounds)))
 if not isinstance(answer,dict):answer={}
 observed={r.get('id'):r for r in answer.get('lines',[]) if isinstance(r,dict)} if isinstance(answer.get('lines'),list) else {}
 for line in analysis.get('lines',[]):
  bounds=line.get('box');source=line.get('source','');target=line.get('target','');row=observed.get(line.get('id'))
  if numbers(source,source_language)!=numbers(target,target_language):add('The requested translation changes a number, price or percentage. Confirm the intended value.',bounds,'number')
  if not row or row.get('readable') is not True or not isinstance(row.get('observed'),str):add('This text could not be independently verified.',bounds,'unverified');continue
  actual=row['observed']
  if folded(actual)!=folded(target):add('Text differs from the requested translation: '+str(target)[:160],bounds)
  if numbers(target,target_language)!=numbers(actual,target_language):add('A number, price or percentage differs in the result.',bounds,'number')
  if line.get('protected') and folded(actual)!=folded(source):add('A protected name or label changed.',bounds,'protected')
 for row in analysis.get('unreadable_regions',[]):add(str(row.get('reason') or 'Unreadable source text'),row.get('box'),'unverified')
 for row in answer.get('unverified_regions',[]) if isinstance(answer.get('unverified_regions'),list) else []:
  add(str(row.get('reason') or 'Unverified area') if isinstance(row,dict) else str(row),row.get('box') if isinstance(row,dict) else None,'unverified')
 for row in answer.get('issues',[]) if isinstance(answer.get('issues'),list) else []:
  add(str(row.get('message') or 'Visual difference') if isinstance(row,dict) else str(row),row.get('box') if isinstance(row,dict) else None,'layout')
 if answer.get('complete') is not True:add('The independent check did not verify every requested text and reference region.',None,'unverified')
 if answer.get('ok') is not True and not issues:add('The independent image check needs review.')
 return dict(ok=not issues,issues=list(dict.fromkeys(issues)),findings=findings[:160],summary=str(answer.get('summary') or 'Review Required')[:1000],strict=True)

def memory_key(source_language,target_language,source):return '|'.join(map(folded,[source_language,target_language,source]))
def memory_apply(analysis,entries,source_language,target_language):
 used=0
 for row in analysis.get('lines',[]):
  entry=entries.get(memory_key(source_language,target_language,row['source']))
  if entry:
   row.update(target=entry['target'],protected=entry.get('protected') is True,memory_applied=True);used+=1
 return used
