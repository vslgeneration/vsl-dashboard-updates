"""Sequential Grok jobs on one narration clock, with durable paid-task checkpoints."""
import copy
import json
import math
import os
import re
import time
import uuid
from prompts import VIDEO_REALTIME_RULE

RATES = {'480p': 2.4, '720p': 4.5, '1080p': 8.0}


def schedule(p):
    fps, total = p['fps'], p['frames']
    limit = round(15 * fps)
    if total > 75 * fps:
        raise ValueError('Link up to 75 seconds of narration at a time. Select a shorter range.')
    if total <= limit:
        cuts = [0, total]
    else:
        # Continue inside a held situation, away from an image/word-slot change.
        # A continuation generates one extra bridge frame, removed from output.
        count = math.ceil(total / limit)
        while total + count - 1 > count * limit:
            count += 1
        cuts = [0]
        for i in range(count - 1):
            left = cuts[-1]
            remaining = count - i - 1
            low = max(left + math.ceil(fps / 3), total - remaining * (limit - 1))
            high = min(left + limit - (1 if i else 0), total - remaining * math.ceil(fps / 3))
            target = left + (total - left) / (remaining + 1)
            choices = []
            for s in p['slots']:
                a, b = s['offset_frame'], s['offset_frame'] + s['frames']
                margin = min(round(fps / 2), max(1, s['frames'] // 3))
                lo, hi = max(low, a + margin), min(high, b - margin)
                if lo <= hi:
                    cut = max(lo, min(hi, round(target)))
                    choices.append((abs(cut - target), -min(cut - a, b - cut), cut))
            if not choices:
                raise ValueError('A safe continuation point could not be placed within these sentence timings. Select fewer scenes.')
            cuts.append(min(choices)[2])
        cuts.append(total)
    chunks = []
    for i, (a, b) in enumerate(zip(cuts, cuts[1:])):
        lead = int(i > 0)
        duration = math.ceil((b - a + lead) / fps - 1e-8)
        if duration > 15:
            raise ValueError('The continuation exceeds the model duration limit.')
        chunks.append(dict(index=i, start_frame=a, end_frame=b, frames=b-a,
                           lead_frames=lead, duration=duration))
    seconds = sum(c['duration'] for c in chunks)
    return dict(chunks=chunks, generation_count=len(chunks), billed_seconds=seconds,
                estimated_credits=round(seconds * RATES[p['resolution']], 2),
                credit_rate=RATES[p['resolution']], pricing_checked='2026-11-12')


def multiple(p):
    return len(p.get('chunks') or []) > 1


def _path(d, rel):
    path = (d / rel).resolve()
    if not path.is_relative_to((d / 'videos').resolve()):
        raise ValueError('Invalid linked-video checkpoint path.')
    return path


def journal_path(d, token):
    if not re.fullmatch('[a-f0-9]{32}', token):
        raise ValueError('Invalid linked-video run identity.')
    return _path(d, 'videos/linked_run_' + token + '.json')


def checkpoint(d, pending, state, task=None, error=None):
    path = journal_path(d, pending['token']); path.parent.mkdir(parents=True, exist_ok=True)
    data = dict(pending=copy.deepcopy(pending), state=state, task=task, error=error, updated=time.time())
    tmp = path.with_suffix('.' + uuid.uuid4().hex + '.tmp')
    try:
        with tmp.open('w', encoding='utf8') as f:
            json.dump(data, f, ensure_ascii=False); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read(d, pending):
    path = journal_path(d, pending['token'])
    if not path.is_file():
        return None
    data = json.loads(path.read_text('utf8'))
    saved = data['pending']
    if saved['token'] != pending['token'] or saved['plan']['signature'] != pending['plan']['signature'] or saved['motion'] != pending['motion']:
        raise ValueError('Linked-video checkpoint no longer matches this request.')
    return data


def progress(doc, pending):
    index, total = pending.get('next_chunk', 0), len(pending['plan']['chunks'])
    for s in doc.get('scenes', []):
        v = s.get('video') or {}
        if v.get('link_wait_token') == pending['token']:
            v['link_progress'] = dict(part=index+1, total=total, completed=index)


def recover(doc, d):
    """Restore only active run tokens. Cancelled or replaced jobs never resurrect."""
    changed = False
    for s in doc.get('scenes', []):
        v = s.get('video') or {}; pending = v.get('pending_link')
        if not pending or not multiple(pending['plan']) or v.get('status') not in ('queued', 'generating'):
            continue
        data = read(d, pending)
        if not data:
            continue
        state = data['state']; desired = copy.deepcopy(data['pending'])
        if state == 'complete':
            # A saved task still pending after a crash can re-land its final download.
            state = 'generating'
        if state in ('submitting', 'unknown', 'error', 'failed', 'cancelled'):
            message = data.get('error') or 'The submission status is unknown. Check Kie before starting another generation.'
            for member in doc['scenes']:
                mv = member.get('video') or {}
                if mv.get('link_wait_token') == pending['token']:
                    mv.update(status='error', error=message, taskId=None)
            v['pending_link'] = desired
            changed = True
            continue
        status, task = ('generating', data.get('task')) if state == 'generating' else ('queued', None)
        if v.get('pending_link') != desired or v.get('status') != status or v.get('taskId') != task:
            v.update(pending_link=desired, status=status, taskId=task, api='jobs', error=None)
            if status == 'generating': v['gen_started'] = data.get('started', data['updated'])
            progress(doc, desired); changed = True
    return changed


def payload(p, chunk, urls, bridge, motion):
    from linked_video import validate_provider_payload, identity_rule
    fps, start, end = p['fps'], chunk['start_frame'], chunk['end_frame']
    lead = chunk['lead_frames']
    active = lambda frame: next(i for i,s in enumerate(p['slots']) if s['offset_frame'] <= frame < s['offset_frame']+s['frames'])
    first, last = active(start), active(end-1)
    anchors = [dict(url=urls[i], timestamp_s=(s['offset_frame']-start+lead)/fps)
               for i,s in enumerate(p['slots']) if start < s['offset_frame'] < end]
    rows = []
    for i,s in enumerate(p['slots']):
        a, b = max(start,s['offset_frame']), min(end,s['offset_frame']+s['frames'])
        if b > a:
            rows.append(f"{(a-start+lead)/fps:.6f}–{(b-start+lead)/fps:.6f}s: image {i+1}, narration: {s['vo']}")
    text = ('Create this part of ONE continuous moving sequence. Follow the local time windows below. '
            'Start from the supplied first frame; continue the same action and camera direction without resetting. '
            'The first frame may be the actual final frame of the preceding generated part. '
            'Do not re-enact earlier actions. Establish each timed reference state at its assigned time; a requested transformation may lead into that arrival. '
            'Use smooth natural connections, no hard cuts, flashes or black frames. '+identity_rule(p)+
            'No speech, text, narration or music. '+VIDEO_REALTIME_RULE+' '
            'Hold the final situation during any fractional-second padding. '
            'MOTION DIRECTION below describes the whole sequence; use only the actions for this part.\n'
            f"Part {chunk['index']+1}/{len(p['chunks'])}; whole-video interval {start/fps:.6f}–{end/fps:.6f}s.\n"
            + '\n'.join(rows) + '\nMOTION DIRECTION:\n' + motion.strip())
    if len(text) > 4096:
        raise ValueError('The continuation prompt exceeds 4096 characters. Shorten the shared motion prompt.')
    return validate_provider_payload(dict(prompt=text, first_frame_url=bridge or urls[first], last_frame_url=urls[last],
                keyframes=anchors, duration=chunk['duration'], resolution=p['resolution'], enable_audio=False))


def submit(g, doc, d, safe, sc, pending):
    from linked_video import plan, group
    v = sc['video']; p = plan(g, doc, d, group(sc))
    if p['signature'] != pending['plan']['signature']:
        raise ValueError('Linked images or timing changed. Generate the shared prompt again.')
    old = read(d, pending)
    if old and old['state'] == 'generating':
        v.update(pending_link=old['pending'], status='generating', taskId=old['task'], api='jobs', gen_started=old['updated'])
        progress(doc, old['pending']); return
    if old and old['state'] in ('submitting','unknown'):
        raise ValueError('The preceding submission has no confirmed task ID. Check Kie before generating again; no duplicate was sent.')
    index = pending.get('next_chunk', 0)
    if pending.get('not_before', 0) > time.time(): return
    urls = pending.get('image_urls')
    if not urls:
        urls = [g['cloudinary_upload'](d / slot['image'], f"{safe}/linked/{pending['token']}/{i}") for i,slot in enumerate(p['slots'])]
        if not all(urls): raise ValueError('A linked image could not be uploaded. No video task was sent.')
        pending['image_urls'] = urls
    bridge = None
    if index:
        previous = pending['completed'][-1]
        path = _path(d, previous['bridge'])
        if not path.is_file(): raise ValueError('The preceding video’s continuation frame is missing.')
        bridge = g['cloudinary_upload'](path, f"{safe}/linked/{pending['token']}/bridge-{index}")
        if not bridge: raise ValueError('The continuation frame could not be uploaded. Completed parts were kept.')
    body = payload(p, p['chunks'][index], urls, bridge, pending['motion'])
    checkpoint(d, pending, 'submitting')  # durable before the one paid POST
    try:
        tid, error = g['kie_create']('grok-imagine-video-1-5-preview', body)
    except Exception:
        checkpoint(d, pending, 'unknown', error='Video submission status is unknown. Check Kie before generating again.')
        raise
    if not tid:
        checkpoint(d, pending, 'failed', error=error or 'The service did not return a task ID.')
        raise ValueError(error or 'Grok did not return a task ID.')
    checkpoint(d, pending, 'generating', task=tid)
    v.update(status='generating', taskId=tid, api='jobs', gen_started=time.time(), error=None)
    progress(doc, pending)


def prepare(g, d, v, raw):
    from linked_video import _run, prepare_result
    pending = v['pending_link']; p = pending['plan']; index = pending.get('next_chunk', 0); c = p['chunks'][index]
    made = []
    try:
        length = g['_shared_video_duration'](d / raw)
        needed = (c['frames'] + c['lead_frames']) / p['fps']
        if length is None or length + .5/p['fps'] < needed:
            raise ValueError('The generated part is shorter than its narration interval. Completed parts were kept.')
        clip = 'videos/_linked_chunk_' + uuid.uuid4().hex + '.mp4'; made.append(clip)
        _run(['ffmpeg','-nostdin','-v','error','-threads','2','-filter_threads','1','-i',str(d/raw),'-an',
              '-vf',f"fps={p['fps']},trim=start_frame={c['lead_frames']}:end_frame={c['lead_frames']+c['frames']},setpts=PTS-STARTPTS",
              '-c:v','libx264','-crf','18','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart','-y',str(d/clip)])
        actual = g['_shared_video_duration'](d/clip)
        if actual is None or abs(actual*p['fps']-c['frames']) > .1: raise ValueError('A continuation part has an incorrect frame count.')
        bridge = 'videos/_linked_bridge_' + uuid.uuid4().hex + '.png'; made.append(bridge)
        _run(['ffmpeg','-nostdin','-v','error','-threads','2','-i',str(d/clip),'-vf',f"select=eq(n\\,{c['frames']-1})",'-frames:v','1','-threads','1','-y',str(d/bridge)])
        chunk = dict(index=index, raw_tmp=raw, clip_tmp=clip, bridge_tmp=bridge, frames=c['frames'], task=v['taskId'])
        if index < len(p['chunks'])-1:
            return dict(ok=True, tmp=raw, linked_chunk=chunk)
        previous = pending.get('completed') or []
        if len(previous) != index: raise ValueError('A preceding video part is missing. Completed parts were kept.')
        files = [_path(d,x['clip']) for x in previous] + [d/clip]
        if not all(x.is_file() for x in files): raise ValueError('A preceding video file is missing.')
        # A concat filter decodes each part, avoiding timestamp/keyframe gaps.
        combined = 'videos/_linked_combined_' + uuid.uuid4().hex + '.mp4'; made.append(combined)
        args = ['ffmpeg','-nostdin','-v','error','-threads','2','-filter_complex_threads','1']
        for f in files: args += ['-i',str(f)]
        filters = ';'.join(f'[{i}:v]setpts=PTS-STARTPTS,setsar=1[v{i}]' for i in range(len(files)))
        filters += ';'+''.join(f'[v{i}]' for i in range(len(files)))+f'concat=n={len(files)}:v=1:a=0[out]'
        args += ['-filter_complex',filters,'-map','[out]','-an','-c:v','libx264','-crf','18','-preset','fast',
                 '-pix_fmt','yuv420p','-threads','2','-movflags','+faststart','-y',str(d/combined)]
        _run(args)
        length = g['_shared_video_duration'](d/combined)
        if length is None or abs(length*p['fps']-p['frames']) > .1: raise ValueError('The complete video does not match the narration frame count.')
        parts = prepare_result(g,d,v,combined)
        return dict(ok=True,tmp=combined,linked_parts=parts,linked_chunk=chunk)
    except Exception:
        for rel in made: (d/rel).unlink(missing_ok=True)
        raise


def cleanup(d, update):
    for key in ('raw_tmp','clip_tmp','bridge_tmp'):
        rel = (update.get('linked_chunk') or {}).get(key)
        if rel: _path(d,rel).unlink(missing_ok=True)


def land_chunk(d, pending, update, landed):
    chunk = update['linked_chunk']; index = pending.get('next_chunk',0)
    if chunk['index'] != index: raise ValueError('This video part belongs to an earlier continuation step.')
    entry = dict(index=index,frames=chunk['frames'],task=chunk['task'])
    moved = []
    try:
        for name,ext in (('raw','mp4'),('clip','mp4'),('bridge','png')):
            src = chunk[name+'_tmp']; dest = f"videos/linked_part_{pending['token']}_{index}_{name}.{ext}"
            os.replace(_path(d,src),_path(d,dest)); moved.append(dest); entry[name]=dest
        pending.setdefault('completed',[]).append(entry)
    except Exception:
        for rel in moved: _path(d,rel).unlink(missing_ok=True)
        raise
    landed.extend(moved)
    if update.get('tmp') == chunk['raw_tmp']: update.pop('tmp')
    update.pop('linked_chunk')
    return entry
