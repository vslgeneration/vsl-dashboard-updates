"""Safe authored OST runs, indexed in UTF-16 like the browser. No stored HTML."""
import html
import math
import re

BOOLS = {'fill','bold','italic','upper','underline','stroke','shadow'}
NUMS = dict(size=(12,1000),letter=(-20,60),leading=(-3,3),stroke_w=(0,40),shadow_opacity=(0,100),shadow_size=(0,40),shadow_dir=(0,360),shadow_distance=(0,200))

def alignment(value):
    return value if value in ('left','center','right') else 'center'

def clean(style):
    out = {}
    for key,v in (style.items() if isinstance(style,dict) else []):
        k = key.removeprefix('ost_')
        if k in BOOLS and isinstance(v,bool): out['ost_'+k]=v
        elif k in NUMS and v is not None:
            try:
                n=float(v)
                if math.isfinite(n): out['ost_'+k]=min(NUMS[k][1],max(NUMS[k][0],n))
            except (ValueError,TypeError): pass
        elif k in ('color','stroke_color','shadow_color') and re.fullmatch(r'#[0-9a-fA-F]{6}',str(v)): out['ost_'+k]=v.lower()
        elif k=='font' and isinstance(v,str) and 1<=len(v)<=80 and all(c.isalnum() or c in ' _-' for c in v): out['ost_font']=v
        elif k=='weight' and str(v) in [str(x) for x in range(100,1000,100)]: out['ost_weight']=str(v)
    return dict(sorted(out.items()))

def normalize(text,runs):
    raw=str(text or '').encode('utf-16-le');length=len(raw)//2
    def bound(v):
        try: n=min(length,max(0,int(float(v))))
        except (ValueError,TypeError,OverflowError): n=0
        if 0<n<length and 0xdc00<=int.from_bytes(raw[n*2:n*2+2],'little')<=0xdfff:n-=1
        return n
    rows=[]
    for r in (runs[:2048] if isinstance(runs,list) else []):
        if not isinstance(r,dict):continue
        a,b,st=bound(r.get('start')),bound(r.get('end')),clean(r.get('style'))
        if b>a and st: rows.append(dict(start=a,end=b,style=st))
    points=sorted({0,length,*[p for r in rows for p in (r['start'],r['end'])]});out=[]
    for a,b in zip(points,points[1:]):
        st={}
        for r in rows:
            if r['start']<=a and r['end']>=b:st.update(r['style'])
        if not st:continue
        if out and out[-1]['end']==a and out[-1]['style']==st:out[-1]['end']=b
        else:out.append(dict(start=a,end=b,style=st))
    return out

def pieces(text,runs):
    raw=text.encode('utf-16-le');out=[];at=0
    for r in normalize(text,runs):
        if r['start']>at:out.append((raw[at*2:r['start']*2].decode('utf-16-le'),{}))
        out.append((raw[r['start']*2:r['end']*2].decode('utf-16-le'),r['style']));at=r['end']
    if at*2<len(raw):out.append((raw[at*2:].decode('utf-16-le'),{}))
    return out

def css(st,base_size):
    def n(k,d):
        try:
            v=float(st.get('ost_'+k));return v if math.isfinite(v) else d
        except (ValueError,TypeError):return d
    size=n('size',56);col=st.get('ost_color') or '#ffffff'
    d=n('shadow_distance',n('shadow_size',6));rad=n('shadow_dir',135)*math.pi/180
    sh=st.get('ost_shadow_color') or '#000000'
    try:rgb=','.join(str(int(sh[i:i+2],16)) for i in (1,3,5))
    except ValueError:rgb='0,0,0'
    shadow=f'{d*math.cos(rad)/size:.6f}em {d*math.sin(rad)/size:.6f}em {n("shadow_size",6)/size:.6f}em rgba({rgb},{n("shadow_opacity",80)/100:g})' if st.get('ost_shadow') is not False else 'none'
    return ';'.join((f'color:{col}',f'-webkit-text-fill-color:{"transparent" if st.get("ost_fill") is False else col}',
        f'font-family:"{st.get("ost_font") or "Arial"}",sans-serif',f'font-size:{size/base_size:.6f}em',
        f'font-weight:{800 if st.get("ost_bold") else n("weight",400):g}',f'font-style:{"italic" if st.get("ost_italic") else "normal"}',
        f'text-decoration:{"underline" if st.get("ost_underline") else "none"}',f'text-transform:{"uppercase" if st.get("ost_upper") else "none"}',
        f'letter-spacing:{n("letter",0)/size:.6f}em',f'line-height:{n("leading",1.15) if n("leading",1.15)>0 else 1:g}',
        f'-webkit-text-stroke:{n("stroke_w",0)/size if st.get("ost_stroke") is not False else 0:.6f}em {st.get("ost_stroke_color") or "#000000"}',
        'paint-order:stroke fill',f'text-shadow:{shadow}'))


def _leading(style):
    try:
        n=float(style.get('ost_leading'));return n if math.isfinite(n) else 1.15
    except (ValueError,TypeError):return 1.15

def _signed_rows(text,style,runs):
    base=float(style.get('ost_size') or 56)
    if _leading(style)>0 and not any(('ost_leading' in r['style'] and _leading(r['style'])!=_leading(style)) or ('ost_size' in r['style'] and r['style']['ost_size']!=base) for r in runs):return None
    rows=[[]]
    for txt,st in pieces(text,runs):
        for i,part in enumerate(txt.split('\n')):
            if i:rows.append([])
            if part:rows[-1].append((part,st))
    sizes=[max(float(st.get('ost_size',base)) for _,st in row) if row else base for row in rows]
    pos=[0.]
    for i in range(1,len(rows)):
        overrides=[part for part in rows[i] if 'ost_leading' in part[1]]
        source=overrides or rows[i-1]
        gap=min(_leading(dict(style,**st)) for _,st in source) if source else _leading(style)
        previous,current=sizes[i-1]/base,sizes[i]/base
        pos.append(pos[-1]+(previous+current)*gap/2+(previous-current)/2)
    lo,hi=min(pos),max(pos)
    return rows,[v-lo for v in pos],hi-lo,sizes

def _render_signed(style,layout):
    rows,pos,extent,sizes=layout;size=float(style.get('ost_size') or 56);out=[]
    for i,row in enumerate(rows):
        contents=''.join(f'<span style="{html.escape(css(dict(style,**st),sizes[i]),quote=True)};line-height:1">{html.escape(txt)}</span>' for txt,st in row)
        out.append(f'<span data-ost-line="{i}" style="grid-area:1/1;white-space:pre-wrap;overflow-wrap:anywhere;text-align:{alignment(style.get("ost_align"))};font-size:{sizes[i]/size:g}em;line-height:1;min-height:1em;align-self:start;justify-self:stretch;transform:translateY({pos[i]*size/sizes[i]:g}em)">{contents}</span>')
    content='\n'.join(out)
    return f'<span data-ost-signed="" style="display:inline-grid;grid-template-columns:minmax(0,1fr);white-space:normal;line-height:1;vertical-align:middle;max-width:100%;box-sizing:content-box;padding-bottom:{extent:g}em;text-decoration:none;text-transform:none">{content}</span>'

def render(text,style):
    runs=normalize(text,style.get('ost_runs'))
    signed=_signed_rows(text,style,runs)
    if signed is not None:return _render_signed(style,signed)
    if not runs:return html.escape(text)
    size=float(style.get('ost_size') or 56)
    return ''.join(f'<span style="{html.escape(css(dict(style,**st),size),quote=True)}">{html.escape(txt)}</span>' for txt,st in pieces(text,runs))

def families(items):
    out=set()
    for it in items:
        st=it.get('style') or {};out.add(str(st.get('ost_font') or 'Arial'))
        out.update(r['style']['ost_font'] for r in normalize(it.get('text') or '',st.get('ost_runs')) if r['style'].get('ost_font'))
    return out or {'Arial'}
