"""Browser-rendered caption / on-screen-text layer — pixel-identical preview↔render parity.

The preview draws captions with the browser (HTML/CSS); libass is a different text engine and
can never match it (font weight, line spacing, the text-hugging box all diverge). So for the
render we drive the SAME engine: headless Edge/Chrome renders each caption to a transparent PNG
using the EXACT preview CSS + the bundled fonts. We then animate those plates (fade / pop-up /
slide) with the SAME keyframes + cubic-bezier easing as the CSS and composite everything into one
transparent overlay video (qtrle, alpha) that ffmpeg lays over the picture.

Public entry point: build_overlay(items, workdir, total, fps, seq_w, seq_h) -> Path | None
  items: list of dicts (see _ITEM shape in render_video._browser_caption_items)
Returns the path to a full-length transparent captions.mov, or None if no browser is available
(the caller then falls back to the libass path).
"""
import hashlib
import html as _html
import json
import math
import os
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from PIL import Image

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ---------------------------------------------------------------- browser locate
_EDGE = "unset"


def edge_exe():
    """Path to a headless-capable Chromium (Edge, then Chrome). Cached. None if none found."""
    global _EDGE
    if _EDGE == "unset":
        cands = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        _EDGE = next((c for c in cands if Path(c).exists()), None)
    return _EDGE


# ---------------------------------------------------------------- fonts
# family -> variable-font file (weight axis), or list of (file, weight) static faces.
_VF = {"Montserrat": "Montserrat-VF.ttf", "Inter": "Inter-VF.ttf", "Open Sans": "OpenSans-VF.ttf",
       "Roboto": "Roboto-VF.ttf", "Noto Serif": "NotoSerif-VF.ttf"}
_STATIC = {
    "Poppins": [("Poppins-Regular.ttf", 400), ("Poppins-Medium.ttf", 500), ("Poppins-SemiBold.ttf", 600),
                ("Poppins-Bold.ttf", 700), ("Poppins-ExtraBold.ttf", 800)],
    "Geomini": [("Geomini-Regular.ttf", 400), ("Geomini-Medium.ttf", 500), ("Geomini-SemiBold.ttf", 600),
                ("Geomini-Bold.ttf", 700), ("Geomini-ExtraBold.ttf", 800)],
    "Google Sans": [("GoogleSans-Regular.ttf", 400), ("GoogleSans-Medium.ttf", 500),
                    ("GoogleSans-SemiBold.ttf", 600), ("GoogleSans-Bold.ttf", 700)],
}
_SINGLE = {"Flatshoes": "Flatshoes.ttf"}


def _font_face_css(fonts_dir):
    """@font-face rules pointing at the bundled TTFs (file:// URLs) — same files the preview uses,
    so the render is font-identical AND works offline (the preview's Google-Fonts CDN is not needed)."""
    def url(fn):
        p = fonts_dir / fn
        return p.resolve().as_uri() if p.exists() else None
    rules = []
    for fam, fn in _VF.items():
        u = url(fn)
        if u:
            rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-weight:100 900;font-display:block;}}')
    for fam, faces in _STATIC.items():
        for fn, w in faces:
            u = url(fn)
            if u:
                rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-weight:{w};font-display:block;}}')
    for fam, fn in _SINGLE.items():
        u = url(fn)
        if u:
            rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-display:block;}}')
    return "\n".join(rules)


# ---------------------------------------------------------------- CSS mirror
def _hex_rgba(hex_color, a):
    h = (hex_color or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        r, g, b = 0, 0, 0
    return f"rgba({r},{g},{b},{a:.3f})"


def _num(v, d):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _inner_css(st, kind):
    """Inline style for the text element — mirrors ostTextStyle() in app.js at scale=1 (1920 stage)."""
    color = st.get("ost_color") or "#ffffff"
    fill = st.get("ost_fill", True)
    size = _num(st.get("ost_size"), 46)
    leading = _num(st.get("ost_leading"), 1.15)
    try:
        weight = int(st.get("ost_weight") or 400)
    except (TypeError, ValueError):
        weight = 400
    if st.get("ost_bold"):
        weight = 800
    letter = _num(st.get("ost_letter"), 0)
    parts = [
        f'color:{color}',
        f'-webkit-text-fill-color:{"transparent" if fill is False else color}',
        f"font-family:'{st.get('ost_font') or 'Arial'}',sans-serif",
        f'font-size:{size:g}px',
        f'line-height:{leading:g}',
        f'font-weight:{weight}',
        f'font-style:{"italic" if st.get("ost_italic") else "normal"}',
        f'text-decoration:{"underline" if st.get("ost_underline") else "none"}',
        f'text-transform:{"uppercase" if st.get("ost_upper") else "none"}',
        f'letter-spacing:{letter:g}px',
        'display:inline-block', 'box-sizing:border-box', 'text-align:center',
        'margin:0', 'padding:0',
        f'white-space:{"pre-line" if kind == "caption" else "pre"}',
        'paint-order:stroke fill',
    ]
    # drop shadow (colour / opacity / size / direction) — matches the CSS textShadow formula
    if st.get("ost_shadow"):
        sz = _num(st.get("ost_shadow_size"), 6)
        rad = math.radians(_num(st.get("ost_shadow_dir"), 135))
        ox, oy = sz * math.cos(rad), sz * math.sin(rad)
        col = _hex_rgba(st.get("ost_shadow_color") or "#000000", _num(st.get("ost_shadow_opacity"), 80) / 100.0)
        parts.append(f'text-shadow:{ox:.1f}px {oy:.1f}px {sz:.1f}px {col}')
    else:
        parts.append('text-shadow:none')
    sw = _num(st.get("ost_stroke_w"), 0) if st.get("ost_stroke") else 0
    if sw > 0:
        parts.append(f'-webkit-text-stroke:{sw:g}px {st.get("ost_stroke_color") or "#000000"}')
    else:
        parts.append('-webkit-text-stroke:0px')
    if st.get("ost_bg"):
        parts.append(f'background:{_hex_rgba(st.get("ost_bg_color") or "#000000", _num(st.get("ost_bg_opacity"), 62) / 100.0)}')
        parts.append(f'padding:{_num(st.get("ost_bg_pad"), 14):g}px')
        parts.append(f'border-radius:{_num(st.get("ost_bg_radius"), 10):g}px')
    else:
        parts.append('background:none')
    return ";".join(parts)


def _outer_css(item):
    """Positioning style for the wrapper — mirrors styleCaption() (captions) / ostWrapPos() (OST)."""
    place = item.get("place") or "bottom"
    x, y, rot = _num(item.get("x"), 0), _num(item.get("y"), 0), _num(item.get("rotation"), 0)
    rotc = f" rotate({rot:g}deg)" if rot else ""
    p = ["position:absolute", "left:50%", "text-align:center", "margin:0"]
    if item.get("kind") == "caption":
        p.append("width:auto")
        p.append(f'max-width:{_num(item.get("sub_width"), 86):g}%')
        if place == "top":
            p.append("top:14%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
        elif place == "center":
            p.append("top:50%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), calc(-50% + {y:g}px)){rotc}')
        else:
            p.append("bottom:4.5%"); p.append("top:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
    else:  # on-screen text: .pv-ost-wrap
        p.append("max-width:98%")
        if place == "top":
            p.append("top:12%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
        elif place == "center":
            p.append("top:50%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), calc(-50% + {y:g}px)){rotc}')
        else:
            p.append("bottom:14%"); p.append("top:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
    return ";".join(p)


# ---------------------------------------------------------------- browser plates
def _render_plates(items, work, fonts_dir, seq_w, seq_h, edge):
    """Screenshot every item to a full-frame RGBA plate (the static, final-position look).
    Returns a list parallel to `items`: {"img": PIL.Image RGBA (seq_w x seq_h), "bbox": (l,t,r,b)} or None."""
    faces = _font_face_css(fonts_dir)
    plates = [None] * len(items)
    PER_PAGE = 10                                    # cap page height (10*1080 = 10800px)
    pages = [(i, items[i:i + PER_PAGE]) for i in range(0, len(items), PER_PAGE)]
    for pi, (base_idx, chunk) in enumerate(pages):
        stages = []
        for it in chunk:
            txt = _html.escape(it.get("text") or "")
            stages.append(
                f'<div class="stage"><div class="outer" style="{_outer_css(it)}">'
                f'<span class="inner" style="{_inner_css(it.get("style") or {}, it.get("kind"))}">{txt}</span>'
                f'</div></div>')
        page_h = seq_h * len(chunk)
        htmlp = (f'<!doctype html><html><head><meta charset="utf-8"><style>{faces}\n'
                 f'html,body{{margin:0;padding:0;background:transparent;}}'
                 f'.stage{{position:relative;width:{seq_w}px;height:{seq_h}px;overflow:hidden;background:transparent;}}'
                 f'</style></head><body>{"".join(stages)}</body></html>')
        hp = work / f"_cap_page{pi}.html"
        hp.write_text(htmlp, encoding="utf-8")
        op = work / f"_cap_page{pi}.png"
        cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
               "--force-device-scale-factor=1", "--allow-file-access-from-files",
               "--default-background-color=00000000", f"--window-size={seq_w},{page_h}",
               f"--screenshot={op.resolve()}", hp.resolve().as_uri()]   # absolute — Edge can't write a relative screenshot path
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=120,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if not op.exists():
            continue
        page = Image.open(op).convert("RGBA")
        for row, it in enumerate(chunk):
            crop = page.crop((0, row * seq_h, seq_w, (row + 1) * seq_h))
            bbox = crop.getbbox()
            if bbox:
                plates[base_idx + row] = {"img": crop, "bbox": bbox}
    return plates


# ---------------------------------------------------------------- easing / animation
def _bezier(x1, y1, x2, y2):
    def bx(t):
        return 3 * (1 - t) ** 2 * t * x1 + 3 * (1 - t) * t * t * x2 + t ** 3

    def by(t):
        return 3 * (1 - t) ** 2 * t * y1 + 3 * (1 - t) * t * t * y2 + t ** 3

    def ease(u):
        if u <= 0:
            return 0.0
        if u >= 1:
            return 1.0
        lo, hi = 0.0, 1.0
        for _ in range(40):
            mid = (lo + hi) / 2
            if bx(mid) < u:
                lo = mid
            else:
                hi = mid
        return by((lo + hi) / 2)
    return ease


_EASE_STD = _bezier(0.25, 0.1, 0.25, 1)            # CSS "ease"
# entrance: name -> (duration, easing, describe)
_IN = {
    "fade":         (0.50, _EASE_STD,               ("fade",)),
    "popup":        (0.55, _bezier(.2, .85, .3, 1.1), ("popup",)),
    "slide-left":   (0.50, _bezier(.2, .7, .2, 1),  ("slide", -70, 0)),
    "slide-right":  (0.50, _bezier(.2, .7, .2, 1),  ("slide", 70, 0)),
    "slide-top":    (0.50, _bezier(.2, .7, .2, 1),  ("slide", 0, -48)),
    "slide-bottom": (0.50, _bezier(.2, .7, .2, 1),  ("slide", 0, 48)),
}
# exit: name -> (duration, easing, describe)
_OUT = {
    "fade":         (0.40, _EASE_STD,                ("fade",)),
    "popup":        (0.40, _bezier(.5, -.3, .7, .3), ("pop",)),
    "slide-left":   (0.40, _bezier(.6, .1, .8, .4),  ("slide", -70, 0)),
    "slide-right":  (0.40, _bezier(.6, .1, .8, .4),  ("slide", 70, 0)),
    "slide-top":    (0.40, _bezier(.6, .1, .8, .4),  ("slide", 0, -48)),
    "slide-bottom": (0.40, _bezier(.6, .1, .8, .4),  ("slide", 0, 48)),
}


def _in_state(spec, u):
    """(opacity, tx, ty, scale) for entrance progress u in [0,1]."""
    dur, ease, d = spec
    kind = d[0]
    if kind == "fade":
        e = ease(u)
        return e, 0.0, 0.0, 1.0
    if kind == "slide":
        e = ease(u)
        return e, d[1] * (1 - e), d[2] * (1 - e), 1.0
    if kind == "popup":
        # two keyframe intervals (0→70%: .5→1.08 scale, opacity 0→1; 70→100%: 1.08→1), each eased
        if u <= 0.7:
            e = ease(u / 0.7)
            return e, 0.0, 0.0, 0.5 + (1.08 - 0.5) * e
        e = ease((u - 0.7) / 0.3)
        return 1.0, 0.0, 0.0, 1.08 + (1.0 - 1.08) * e
    return 1.0, 0.0, 0.0, 1.0


def _out_state(spec, u):
    """(opacity, tx, ty, scale) for exit progress u in [0,1]."""
    dur, ease, d = spec
    kind = d[0]
    e = ease(u)
    if kind == "fade":
        return 1 - e, 0.0, 0.0, 1.0
    if kind == "pop":
        return 1 - e, 0.0, 0.0, 1.0 + (0.6 - 1.0) * e
    if kind == "slide":
        return 1 - e, d[1] * e, d[2] * e, 1.0
    return 1 - e, 0.0, 0.0, 1.0


# ---------------------------------------------------------------- frame compositing
def _compose(local_img, bbox, cw, ch, opacity, tx, ty, scale):
    """Return one RGBA (cw x ch) animation frame — the caption's small crop region, not the whole 1920x1080
    frame (huge speedup). `local_img` is the plate cropped to that region; `bbox` is the element box in
    local coords. Slide = shift; pop-up = scale about the element centre; fade/opacity = alpha multiply."""
    canvas = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    if abs(scale - 1.0) > 1e-3:
        l, t, r, b = bbox
        cx, cy = (l + r) / 2.0, (t + b) / 2.0
        nw, nh = max(1, int(round((r - l) * scale))), max(1, int(round((b - t) * scale)))
        chip = local_img.crop(bbox).resize((nw, nh), Image.LANCZOS)
        px, py = int(round(cx - nw / 2.0 + tx)), int(round(cy - nh / 2.0 + ty))
        canvas.paste(chip, (px, py))          # NO mask — copy RGBA verbatim; a mask would square the box alpha
    else:
        dx, dy = int(round(tx)), int(round(ty))
        if dx == 0 and dy == 0:
            canvas = local_img.copy()
        else:
            canvas.paste(local_img, (dx, dy))  # NO mask — see above (this bug dimmed pop-up/slide mid-animation)
    if opacity < 0.999:
        r_, g_, b_, a_ = canvas.split()
        a_ = a_.point(lambda v: int(v * opacity))
        canvas = Image.merge("RGBA", (r_, g_, b_, a_))
    return canvas


def _run_ffmpeg(args, timeout=180):
    # stdout/stderr -> DEVNULL: in the packaged windowless app (pythonw, no console) an inherited
    # std handle is invalid, and a caption whose ffmpeg emits any stderr would block on it forever
    # (this hung the caption build at "225/227"). DEVNULL + a real timeout make every clip safe.
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args],
                   creationflags=_NO_WINDOW, timeout=timeout, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _item_key(item, fps, seq_w, seq_h):
    """Stable hash of everything that affects a caption clip's PIXELS (not its absolute placement in the
    timeline) — so identical captions reuse one cached .mov and re-renders don't rebuild them."""
    payload = {
        "text": item.get("text"), "style": item.get("style"), "kind": item.get("kind"),
        "place": item.get("place"), "x": item.get("x"), "y": item.get("y"),
        "rotation": item.get("rotation"), "sub_width": item.get("sub_width"),
        "anim": item.get("anim"), "out_anim": item.get("out_anim"),
        "dur": round(float(item.get("end", 0)) - float(item.get("start", 0)), 3),
        "fps": fps, "w": seq_w, "h": seq_h, "v": 2,   # bump to invalidate clips cached before the alpha-mask fix
    }
    return hashlib.md5(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]


def _caption_clip(key, item, plate, cache, fps, seq_w, seq_h):
    """Build one caption's transparent clip (in-anim + static hold + out-anim) as a qtrle .mov, cached by
    `key`. Works on the caption's small CROP region (not the full 1920x1080 frame) for speed. Returns
    (mov_path, x, y) where (x, y) is where to overlay the crop on the picture, or None."""
    start, end = float(item["start"]), float(item["end"])
    dur = end - start
    if dur <= 0 or plate is None:
        return None
    anim = item.get("anim") or "fade"
    out_anim = item.get("out_anim") or "none"
    in_spec = _IN.get(anim)
    out_spec = _OUT.get(out_anim)
    in_dur = in_spec[0] if in_spec else 0.0
    out_dur = out_spec[0] if out_spec else 0.0
    # never let in+out exceed the clip; shrink proportionally, keep a sliver of hold
    if in_dur + out_dur > dur:
        k = dur / (in_dur + out_dur) if (in_dur + out_dur) else 0
        in_dur, out_dur = in_dur * k, out_dur * k
    hold_dur = max(0.0, dur - in_dur - out_dur)

    # crop to the region the caption + its animation can occupy: element box + margin for slide (±70/48)
    # and the pop-up's 1.08 overshoot (~4% of the box each side). ~13x fewer pixels than a full frame.
    el, et, er, eb = plate["bbox"]
    ew, eh = er - el, eb - et
    mx = int(math.ceil(max(72, 0.06 * ew))) + 6
    my = int(math.ceil(max(52, 0.06 * eh))) + 6
    X0, Y0 = max(0, el - mx), max(0, et - my)
    X1, Y1 = min(seq_w, er + mx), min(seq_h, eb + my)
    cw, ch = X1 - X0, Y1 - Y0
    local_img = plate["img"].crop((X0, Y0, X1, Y1))
    lbbox = (el - X0, et - Y0, er - X0, eb - Y0)       # element box in local (crop) coords

    cdir = cache / key
    cdir.mkdir(exist_ok=True)
    parts = []                                        # list of (kind, path/paths, duration)

    n_in = int(round(in_dur * fps))
    if in_spec and n_in > 0:
        for f in range(n_in):
            u = (f + 0.5) / n_in
            _compose(local_img, lbbox, cw, ch, *_in_state(in_spec, u)).save(cdir / f"in{f:05d}.png")
        parts.append(("seq", str(cdir / "in%05d.png"), n_in))
    # static hold — the untransformed final look (the cropped plate itself)
    plate_png = cdir / "hold.png"
    local_img.save(plate_png)
    if hold_dur > 1e-4 or not parts:
        parts.append(("hold", str(plate_png), max(hold_dur, 1.0 / fps)))
    n_out = int(round(out_dur * fps))
    if out_spec and n_out > 0:
        for f in range(n_out):
            u = (f + 0.5) / n_out
            _compose(local_img, lbbox, cw, ch, *_out_state(out_spec, u)).save(cdir / f"out{f:05d}.png")
        parts.append(("seq", str(cdir / "out%05d.png"), n_out))

    # assemble the parts into one clip via concat
    inputs, filters, labels = [], [], []
    for pi, (kind, path, meta) in enumerate(parts):
        if kind == "seq":
            inputs += ["-framerate", str(fps), "-i", path]
        else:
            inputs += ["-loop", "1", "-t", f"{meta:.4f}", "-i", path]
        filters.append(f"[{pi}:v]fps={fps},format=rgba,setpts=PTS-STARTPTS[p{pi}]")
        labels.append(f"[p{pi}]")
    mov = cdir / "clip.mov"
    fc = ";".join(filters) + ";" + "".join(labels) + f"concat=n={len(parts)}:v=1:a=0[v]"
    _run_ffmpeg([*inputs, "-filter_complex", fc, "-map", "[v]", "-c:v", "qtrle",
                 "-pix_fmt", "argb", str(mov)])
    (cdir / "pos.txt").write_text(f"{X0} {Y0}", encoding="utf-8")   # where to overlay this crop
    # the per-frame PNGs are baked into clip.mov now — drop them so a long VSL doesn't bloat the temp dir
    for p in list(cdir.glob("in*.png")) + list(cdir.glob("out*.png")) + [plate_png]:
        try: p.unlink()
        except OSError: pass
    return (mov, X0, Y0)


def _read_pos(cdir):
    try:
        x, y = (cdir / "pos.txt").read_text(encoding="utf-8").split()
        return int(x), int(y)
    except Exception:
        return 0, 0


def build_clips(items, workdir, fps, seq_w=1920, seq_h=1080, progress=None, should_cancel=None):
    """Render all caption/OST items through the browser + animate them. Returns a list of
    (transparent_clip.mov, start, end, x, y) to overlay onto the picture in the main render pass (each
    clip is a small transparent crop, overlaid at x,y). Returns [] if no browser is available or nothing
    rendered — the caller then falls back to libass. `progress(done, total)` is called as clips finish.
    `should_cancel()` (optional) — if it ever returns True the build aborts promptly."""
    def _cancelled():
        try: return bool(should_cancel and should_cancel())
        except Exception: return False

    edge = edge_exe()
    if not edge or not items:
        return []
    work = Path(workdir)
    fonts_dir = work / "fonts"
    if not (fonts_dir.exists() and any(fonts_dir.iterdir())):
        fonts_dir = Path(__file__).parent / "static" / "fonts"
    cache = work / "_capcache"
    cache.mkdir(exist_ok=True)

    n = len(items)
    keys = [_item_key(it, fps, seq_w, seq_h) for it in items]
    result = [None] * n
    todo = []                                     # indices whose clip isn't cached yet
    for i, it in enumerate(items):
        cdir = cache / keys[i]
        mov = cdir / "clip.mov"
        if mov.exists():
            x, y = _read_pos(cdir)
            result[i] = (mov, float(it["start"]), float(it["end"]), x, y)   # reuse — built in a past render
            try: cdir.touch()                                               # mark fresh so it survives pruning
            except OSError: pass
        else:
            todo.append(i)
    done = [n - len(todo)]                          # list so the worker threads can bump it
    if progress and done[0]:
        try: progress(done[0], n)
        except Exception: pass

    if todo and not _cancelled():
        # only render plates (headless browser) for the captions we actually need to build
        todo_items = [items[i] for i in todo]
        plates = _render_plates(todo_items, work, fonts_dir, seq_w, seq_h, edge)

        def _one(j, i):
            r = _caption_clip(keys[i], items[i], plates[j], cache, fps, seq_w, seq_h)
            return (i, r)

        # build the clips in parallel — PIL frame gen + a tiny ffmpeg per clip are independent
        workers = max(2, min(6, (os.cpu_count() or 4) - 1))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_one, j, i) for j, i in enumerate(todo)]
            for fut in as_completed(futs):
                try:
                    i, r = fut.result()
                except Exception:
                    r = None; i = None
                if i is not None and r:
                    mov, x, y = r
                    result[i] = (mov, float(items[i]["start"]), float(items[i]["end"]), x, y)
                done[0] += 1
                if progress:
                    try: progress(done[0], n)
                    except Exception: pass
                if _cancelled():                       # Stop pressed → drop the queued clips, don't wait
                    ex.shutdown(wait=False, cancel_futures=True)
                    break

    # keep the cache from growing forever as styles/text change over many renders: drop the oldest dirs
    try:
        dirs = [d for d in cache.iterdir() if d.is_dir()]
        if len(dirs) > 400:
            for d in sorted(dirs, key=lambda p: p.stat().st_mtime, reverse=True)[400:]:
                shutil.rmtree(d, ignore_errors=True)
    except OSError:
        pass
    return [r for r in result if r]
