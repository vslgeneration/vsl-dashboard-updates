"""Browser-rendered caption / on-screen-text layer — pixel-identical preview↔render parity.

The preview draws captions with the browser (HTML/CSS); libass is a different text engine and
can never match it (font weight, line spacing, the text-hugging box all diverge). So for the
render we drive the SAME engine: headless Edge/Chrome renders each caption to a transparent PNG
using the EXACT preview CSS + the bundled fonts. We then animate those plates (fade / pop-up /
slide) with the SAME keyframes + cubic-bezier easing as the CSS and composite everything into one
transparent overlay video (qtrle, alpha) that ffmpeg lays over the picture.

Public entry point: build_overlay(items, workdir, total, fps, seq_w, seq_h) -> Path | None
  items: list of dicts (see _ITEM shape in render_video._browser_caption_items)
Returns the path to a full-length transparent captions.mov, or None if no browser is available
(the caller then falls back to the libass path).
"""
import hashlib
import html as _html
import json
import math
import os
import shutil
import base64
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from PIL import Image
from quietlog import quiet

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ---------------------------------------------------------------- browser locate
_EDGE = "unset"


def edge_exe():
    """Path to a headless-capable Chromium (Edge, then Chrome). Cached. None if none found."""
    global _EDGE
    if _EDGE == "unset":
        cands = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        _EDGE = next((c for c in cands if Path(c).exists()), None)
    return _EDGE


# ---------------------------------------------------------------- fonts
# family -> variable-font file (weight axis), or list of (file, weight) static faces.
_VF = {"Montserrat": "Montserrat-VF.ttf", "Inter": "Inter-VF.ttf", "Open Sans": "OpenSans-VF.ttf",
       "Roboto": "Roboto-VF.ttf", "Noto Serif": "NotoSerif-VF.ttf"}
_STATIC = {
    "Poppins": [("Poppins-Regular.ttf", 400), ("Poppins-Medium.ttf", 500), ("Poppins-SemiBold.ttf", 600),
                ("Poppins-Bold.ttf", 700), ("Poppins-ExtraBold.ttf", 800)],
    "Geomini": [("Geomini-Regular.ttf", 400), ("Geomini-Medium.ttf", 500), ("Geomini-SemiBold.ttf", 600),
                ("Geomini-Bold.ttf", 700), ("Geomini-ExtraBold.ttf", 800)],
    "Google Sans": [("GoogleSans-Regular.ttf", 400), ("GoogleSans-Medium.ttf", 500),
                    ("GoogleSans-SemiBold.ttf", 600), ("GoogleSans-Bold.ttf", 700)],
}
_SINGLE = {"Flatshoes": "Flatshoes.ttf"}


_FONT_B64 = {}


def _font_face_css(fonts_dir, families=None):
    """@font-face rules for the bundled TTFs, with the font EMBEDDED as a data: URI.

    A file:// URL does not work here: the headless browser refuses the cross-origin font fetch and the
    face sits at "loading" forever, so the plate quietly comes out in the fallback face - narrower text,
    and a background box that hugs it at the wrong size. That was the whole reason a burnt-in caption
    did not match the one in the preview. Embedding removes the fetch.

    `families` limits it to the faces actually in play - GoogleSans alone is 8 MB across its four
    weights, and there is no reason to inline a font nobody asked for."""
    want = None if not families else {str(f) for f in families}

    def url(fn):
        p = fonts_dir / fn
        if not p.exists():
            return None
        key = str(p.resolve())
        if key not in _FONT_B64:
            _FONT_B64[key] = base64.b64encode(p.read_bytes()).decode("ascii")
        return "data:font/ttf;base64," + _FONT_B64[key]
    rules = []
    for fam, fn in _VF.items():
        if want is not None and fam not in want:
            continue
        u = url(fn)
        if u:
            rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-weight:100 900;font-display:block;}}')
    for fam, faces in _STATIC.items():
        if want is not None and fam not in want:
            continue
        for fn, w in faces:
            u = url(fn)
            if u:
                rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-weight:{w};font-display:block;}}')
    for fam, fn in _SINGLE.items():
        if want is not None and fam not in want:
            continue
        u = url(fn)
        if u:
            rules.append(f'@font-face{{font-family:"{fam}";src:url("{u}");font-display:block;}}')
    return "\n".join(rules)


# ---------------------------------------------------------------- CSS mirror
def _hex_rgba(hex_color, a):
    h = (hex_color or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        r, g, b = 0, 0, 0
    return f"rgba({r},{g},{b},{a:.3f})"


def _num(v, d):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _inner_css(st, kind, oneline=False, narrow=False):
    """Inline style for the text element — mirrors ostTextStyle() in app.js at scale=1 (1920 stage).
    The box hugs the text with even padding on all sides. oneline (captions) → never wrap (nowrap)."""
    color = st.get("ost_color") or "#ffffff"
    fill = st.get("ost_fill", True)
    size = _num(st.get("ost_size"), 46)
    leading = _num(st.get("ost_leading"), 1.15)
    try:
        weight = int(st.get("ost_weight") or 400)
    except (TypeError, ValueError):
        weight = 400
    if st.get("ost_bold"):
        weight = 800
    letter = _num(st.get("ost_letter"), 0)
    parts = [
        f'color:{color}',
        f'-webkit-text-fill-color:{"transparent" if fill is False else color}',
        f"font-family:'{st.get('ost_font') or 'Arial'}',sans-serif",
        f'font-size:{size:g}px',
        f'line-height:{leading:g}',
        f'font-weight:{weight}',
        f'font-style:{"italic" if st.get("ost_italic") else "normal"}',
        f'text-decoration:{"underline" if st.get("ost_underline") else "none"}',
        f'text-transform:{"uppercase" if st.get("ost_upper") else "none"}',
        f'letter-spacing:{letter:g}px',
        'display:inline-block', 'box-sizing:border-box', 'text-align:center',
        'margin:0', 'padding:0',
        # the bg HUGS each caption's own text: shrink-wrap to content and centre in the sub_width%% wrapper,
        # so a short line gets a short plate (was width:100%, a fixed-width bar). mirrors styleCaption().
        'width:auto', 'max-width:100%',
        f'white-space:{"nowrap" if oneline else ("pre-line" if kind == "caption" else "pre")}',
        'paint-order:stroke fill',
    ]
    # drop shadow (colour / opacity / size / direction) — matches the CSS textShadow formula
    if st.get("ost_shadow"):
        sz = _num(st.get("ost_shadow_size"), 6)
        rad = math.radians(_num(st.get("ost_shadow_dir"), 135))
        ox, oy = sz * math.cos(rad), sz * math.sin(rad)
        col = _hex_rgba(st.get("ost_shadow_color") or "#000000", _num(st.get("ost_shadow_opacity"), 80) / 100.0)
        parts.append(f'text-shadow:{ox:.1f}px {oy:.1f}px {sz:.1f}px {col}')
    else:
        parts.append('text-shadow:none')
    sw = _num(st.get("ost_stroke_w"), 0) if st.get("ost_stroke") else 0
    if sw > 0:
        parts.append(f'-webkit-text-stroke:{sw:g}px {st.get("ost_stroke_color") or "#000000"}')
    else:
        parts.append('-webkit-text-stroke:0px')
    if st.get("ost_bg"):
        parts.append(f'background:{_hex_rgba(st.get("ost_bg_color") or "#000000", _num(st.get("ost_bg_opacity"), 62) / 100.0)}')
        parts.append(f'padding:{_num(st.get("ost_bg_pad"), 14):g}px')
        parts.append(f'border-radius:{_num(st.get("ost_bg_radius"), 10):g}px')
    else:
        parts.append('background:none')
    if narrow and not oneline:
        parts += ['white-space:pre-wrap', 'overflow-wrap:anywhere']
    return ";".join(parts)


def _outer_css(item):
    """Positioning style for the wrapper — mirrors styleCaption() (captions) / ostWrapPos() (OST)."""
    place = item.get("place") or "bottom"
    x, y, rot = _num(item.get("x"), 0), _num(item.get("y"), 0), _num(item.get("rotation"), 0)
    rotc = f" rotate({rot:g}deg)" if rot else ""
    p = ["position:absolute", "left:50%", "text-align:center", "margin:0"]
    if item.get("kind") == "caption":
        # explicit width (= the "Line" %) so text fills edge-to-edge; width:auto + left:50% was capped at ~50%
        if item.get("oneline"):
            p.append("width:auto")
        else:
            p.append(f'width:{_num(item.get("sub_width"), 86):g}%')
        if place == "top":
            p.append("top:14%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
        elif place == "center":
            p.append("top:50%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), calc(-50% + {y:g}px)){rotc}')
        else:
            p.append("bottom:4.5%"); p.append("top:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
    else:  # on-screen text: the SAME anchors as the scene card (.scene-ost) where the text was placed
        p.append("max-width:98%")
        if place == "top":
            p.append("top:6%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
        elif place == "center":
            p.append("top:50%"); p.append("bottom:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), calc(-50% + {y:g}px)){rotc}')
        else:
            p.append("bottom:6%"); p.append("top:auto")
            p.append(f'transform:translate(calc(-50% + {x:g}px), {y:g}px){rotc}')
    return ";".join(p)


# ---------------------------------------------------------------- browser plates
def _render_plates(items, work, fonts_dir, seq_w, seq_h, edge, hl_color="#e5322d", should_cancel=None, pixel_ratio=1):
    """Screenshot every item to a full-frame RGBA plate (the static, final-position look).
    Returns a list parallel to `items`: {"img": PIL.Image RGBA (seq_w x seq_h), "bbox": (l,t,r,b)} or None."""
    # only the families these captions actually name - inlining all of them is 18 MB of base64
    fams = {str((it.get("style") or {}).get("ost_font") or "Arial") for it in items} or {"Arial"}
    faces = _font_face_css(fonts_dir, families=fams)
    plates = [None] * len(items)
    # Edge can hand work to a child and return before the screenshot is written.
    # A private directory also prevents a previous page from masquerading as the new one.
    page_work = Path(tempfile.mkdtemp(prefix="_cap_", dir=work))
    SS = 2                                           # supersample: render at 2x device pixels then LANCZOS-downscale
    #                                                  -> crisp anti-aliased letter edges (kills the "jagged" look on alpha)
    PER_PAGE = max(1, 15000 // (seq_h * SS))         # keep the 2x page bitmap under the browser screenshot height limit
    pages = [(i, items[i:i + PER_PAGE]) for i in range(0, len(items), PER_PAGE)]
    for pi, (base_idx, chunk) in enumerate(pages):
        stages = []
        for it in chunk:
            # FAQ captions pass pre-built inner HTML (with red <span class="faq-kw"> keywords); others escape plain text
            txt = it.get("html") if it.get("html") else _html.escape(it.get("text") or "")
            outer = _outer_css(it)
            if seq_w / seq_h < 1.7 and (it.get("kind") != "caption" or it.get("oneline")):
                outer += ";width:max-content;max-width:" + ("none" if it.get("oneline") else "96%")
            stages.append(
                f'<div class="stage"><div class="outer" style="{outer}">'
                f'<span class="inner" style="{_inner_css(it.get("style") or {}, it.get("kind"), it.get("oneline"), seq_w / seq_h < 1.7)}">{txt}</span>'
                f'</div></div>')
        page_h = seq_h * len(chunk)
        fit_script = ""
        if seq_w / seq_h < 1.7:
            fit_script = '<script>function fit(){document.querySelectorAll(".outer").forEach(o=>{const t=o.querySelector(".inner");if(getComputedStyle(t).whiteSpace!=="nowrap")return;const max=o.parentElement.clientWidth*.96;const width=t.scrollWidth;if(width>max)t.style.fontSize=(parseFloat(getComputedStyle(t).fontSize)*max/width)+"px";});}document.fonts.ready.then(fit);fit();</script>'
        htmlp = (f'<!doctype html><html><head><meta charset="utf-8"><style>{faces}\n'
                 f'html,body{{margin:0;padding:0;background:transparent;}}'
                 f'.stage{{position:relative;width:{seq_w}px;height:{seq_h}px;overflow:hidden;background:transparent;}}'
                 f'.faq-kw{{color:{hl_color};-webkit-text-fill-color:{hl_color};font-weight:800;}}'
                 f'</style></head><body>{"".join(stages)}{fit_script}</body></html>')
        hp = page_work / f"page{pi}.html"
        hp.write_text(htmlp, encoding="utf-8")
        op = page_work / f"page{pi}.png"
        cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
               f"--user-data-dir={page_work / 'profile'}", "--no-first-run", "--disable-background-networking",
               "--host-resolver-rules=MAP * ~NOTFOUND",
               f"--force-device-scale-factor={SS}", "--allow-file-access-from-files",
               "--default-background-color=00000000", f"--window-size={seq_w},{page_h}",
               f"--screenshot={op.resolve()}", hp.resolve().as_uri()]   # absolute — Edge can't write a relative screenshot path
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=120,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + 10
        page = None
        while page is None:
            if should_cancel and should_cancel():
                raise RuntimeError("cancelled")
            try:
                with Image.open(op) as check:
                    check.verify()  # reject a file still being written
                with Image.open(op) as ready:
                    page = ready.convert("RGBA")
            except (OSError, SyntaxError):
                if time.monotonic() >= deadline:
                    break
                time.sleep(0.05)
        if page is None:
            continue
        sx = page.width / seq_w                       # actual device-pixel ratio Edge produced (2 if honoured, else 1)
        for row, it in enumerate(chunk):
            box = (0, int(round(row * seq_h * sx)), int(round(seq_w * sx)), int(round((row + 1) * seq_h * sx)))
            hi = page.crop(box)
            delivery_size = (seq_w * pixel_ratio, seq_h * pixel_ratio)
            crop = hi.resize(delivery_size, Image.LANCZOS) if hi.size != delivery_size else hi
            bbox = crop.getbbox()
            if bbox:
                plates[base_idx + row] = {"img": crop, "bbox": bbox}
    return plates


def render_overlay_stills(items, workdir, seq_w=1920, seq_h=1080):
    """Render each item to a FULL-FRAME (seq_w x seq_h) transparent PNG showing the text at its final
    placement — for compositing as a Premiere overlay clip (V2). Same browser plate pipeline as
    build_clips, so it's pixel-identical to the preview/render. Returns a list parallel to `items`
    (Path or None), or None if no headless browser is available."""
    edge = edge_exe()
    if not edge or not items:
        return None
    work = Path(workdir)
    work.mkdir(parents=True, exist_ok=True)
    fonts_dir = work / "fonts"
    if not (fonts_dir.exists() and any(fonts_dir.iterdir())):
        fonts_dir = Path(__file__).parent / "static" / "fonts"
    plates = _render_plates(items, work, fonts_dir, seq_w, seq_h, edge)
    out = []
    for i, pl in enumerate(plates):
        if not pl:
            out.append(None)
            continue
        p = work / f"ost_still_{i:03d}.png"
        pl["img"].save(p)                     # already a full-frame RGBA plate at the right position
        out.append((p, pl["bbox"]))           # bbox (l,t,r,b) -> the text centre, for the pop/scale anchor
    return out


# ---------------------------------------------------------------- easing / animation
def _bezier(x1, y1, x2, y2):
    def bx(t):
        return 3 * (1 - t) ** 2 * t * x1 + 3 * (1 - t) * t * t * x2 + t ** 3

    def by(t):
        return 3 * (1 - t) ** 2 * t * y1 + 3 * (1 - t) * t * t * y2 + t ** 3

    def ease(u):
        if u <= 0:
            return 0.0
        if u >= 1:
            return 1.0
        lo, hi = 0.0, 1.0
        for _ in range(40):
            mid = (lo + hi) / 2
            if bx(mid) < u:
                lo = mid
            else:
                hi = mid
        return by((lo + hi) / 2)
    return ease


# Hard ceiling on a single caption/overlay clip's duration. A real caption or on-screen-text runs a
# few seconds; anything longer means a corrupt timeline (a bad SRT `end`). Without this cap one such
# cue once made ffmpeg encode a ~16h qtrle clip that ballooned clip.mov to 223 GB and filled the disk.
_MAX_CLIP_SEC = 120.0

_EASE_STD = _bezier(0.25, 0.1, 0.25, 1)            # CSS "ease"
# entrance: name -> (duration, easing, describe)
_IN = {
    "fade":         (0.50, _EASE_STD,               ("fade",)),
    "popup":        (0.55, _bezier(.2, .85, .3, 1.1), ("popup",)),
    "slide-left":   (0.50, _bezier(.2, .7, .2, 1),  ("slide", -70, 0)),
    "slide-right":  (0.50, _bezier(.2, .7, .2, 1),  ("slide", 70, 0)),
    "slide-top":    (0.50, _bezier(.2, .7, .2, 1),  ("slide", 0, -48)),
    "slide-bottom": (0.50, _bezier(.2, .7, .2, 1),  ("slide", 0, 48)),
}
# exit: name -> (duration, easing, describe)
_OUT = {
    "fade":         (0.40, _EASE_STD,                ("fade",)),
    "popup":        (0.40, _bezier(.5, -.3, .7, .3), ("pop",)),
    "slide-left":   (0.40, _bezier(.6, .1, .8, .4),  ("slide", -70, 0)),
    "slide-right":  (0.40, _bezier(.6, .1, .8, .4),  ("slide", 70, 0)),
    "slide-top":    (0.40, _bezier(.6, .1, .8, .4),  ("slide", 0, -48)),
    "slide-bottom": (0.40, _bezier(.6, .1, .8, .4),  ("slide", 0, 48)),
}
# The UI saves "pop"; retain "popup" for older saved styles too.
_OUT["pop"] = _OUT["popup"]


def _in_state(spec, u):
    """(opacity, tx, ty, scale) for entrance progress u in [0,1]."""
    dur, ease, d = spec
    kind = d[0]
    if kind == "fade":
        e = ease(u)
        return e, 0.0, 0.0, 1.0
    if kind == "slide":
        e = ease(u)
        return e, d[1] * (1 - e), d[2] * (1 - e), 1.0
    if kind == "popup":
        # two keyframe intervals (0→70%: .5→1.08 scale, opacity 0→1; 70→100%: 1.08→1), each eased
        if u <= 0.7:
            e = ease(u / 0.7)
            return e, 0.0, 0.0, 0.5 + (1.08 - 0.5) * e
        e = ease((u - 0.7) / 0.3)
        return 1.0, 0.0, 0.0, 1.08 + (1.0 - 1.08) * e
    return 1.0, 0.0, 0.0, 1.0


def _out_state(spec, u):
    """(opacity, tx, ty, scale) for exit progress u in [0,1]."""
    dur, ease, d = spec
    kind = d[0]
    e = ease(u)
    if kind == "fade":
        return 1 - e, 0.0, 0.0, 1.0
    if kind == "pop":
        return 1 - e, 0.0, 0.0, 1.0 + (0.6 - 1.0) * e
    if kind == "slide":
        return 1 - e, d[1] * e, d[2] * e, 1.0
    return 1 - e, 0.0, 0.0, 1.0


# ---------------------------------------------------------------- frame compositing
def _compose(local_img, bbox, cw, ch, opacity, tx, ty, scale):
    """Return one RGBA (cw x ch) animation frame — the caption's small crop region, not the whole 1920x1080
    frame (huge speedup). `local_img` is the plate cropped to that region; `bbox` is the element box in
    local coords. Slide = shift; pop-up = scale about the element centre; fade/opacity = alpha multiply."""
    canvas = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    if abs(scale - 1.0) > 1e-3:
        l, t, r, b = bbox
        cx, cy = (l + r) / 2.0, (t + b) / 2.0
        nw, nh = max(1, int(round((r - l) * scale))), max(1, int(round((b - t) * scale)))
        chip = local_img.crop(bbox).resize((nw, nh), Image.LANCZOS)
        px, py = int(round(cx - nw / 2.0 + tx)), int(round(cy - nh / 2.0 + ty))
        canvas.paste(chip, (px, py))          # NO mask — copy RGBA verbatim; a mask would square the box alpha
    else:
        dx, dy = int(round(tx)), int(round(ty))
        if dx == 0 and dy == 0:
            canvas = local_img.copy()
        else:
            canvas.paste(local_img, (dx, dy))  # NO mask — see above (this bug dimmed pop-up/slide mid-animation)
    if opacity < 0.999:
        r_, g_, b_, a_ = canvas.split()
        a_ = a_.point(lambda v: int(v * opacity))
        canvas = Image.merge("RGBA", (r_, g_, b_, a_))
    return canvas


def _run_ffmpeg(args, timeout=180):
    # stdout/stderr -> DEVNULL: in the packaged windowless app (pythonw, no console) an inherited
    # std handle is invalid, and a caption whose ffmpeg emits any stderr would block on it forever
    # (this hung the caption build at "225/227"). DEVNULL + a real timeout make every clip safe.
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args],
                   creationflags=_NO_WINDOW, timeout=timeout, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _item_key(item, fps, seq_w, seq_h, pixel_ratio=1):
    """Stable hash of everything that affects a caption clip's PIXELS (not its absolute placement in the
    timeline) — so identical captions reuse one cached .mov and re-renders don't rebuild them."""
    payload = {
        "text": item.get("text"), "html": item.get("html"), "style": item.get("style"), "kind": item.get("kind"),
        "place": item.get("place"), "x": item.get("x"), "y": item.get("y"),
        "rotation": item.get("rotation"), "sub_width": item.get("sub_width"),
        "oneline": bool(item.get("oneline")),
        "words": [{**w, "start": round(w["start"]-item["start"],6), "end": round(w["end"]-item["start"],6)} for w in item.get("words",[])],
        # Whole-sentence alpha is now applied once after compositing word layers.
        "motion_version": 8 if item.get("kind") == "caption" and motion_enabled(item.get("style")) else (4 if item.get("out_anim") == "pop" else 3),
        "anim": item.get("anim"), "out_anim": item.get("out_anim"),
        "dur": round(float(item.get("end", 0)) - float(item.get("start", 0)), 3),
        # v3: the fonts are embedded now. Before that the bundled faces silently failed to load in the
        # headless page and every plate was drawn in a fallback - cached plates from then are wrong.
        "fps": fps, "w": seq_w, "h": seq_h, "v": 4 if seq_w / seq_h < 1.7 else 3,
    }
    if pixel_ratio != 1: payload["delivery_pixel_ratio"] = pixel_ratio
    return hashlib.md5(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]


def _caption_clip(key, item, plate, cache, fps, seq_w, seq_h, pixel_ratio=1):
    """Build one caption's transparent clip (in-anim + static hold + out-anim) as a qtrle .mov, cached by
    `key`. Works on the caption's small CROP region (not the full 1920x1080 frame) for speed. Returns
    (mov_path, x, y) where (x, y) is where to overlay the crop on the picture, or None."""
    seq_w, seq_h = seq_w * pixel_ratio, seq_h * pixel_ratio
    def transform(state):
        opacity, tx, ty, scale = state
        return opacity, tx * pixel_ratio, ty * pixel_ratio, scale
    start, end = float(item["start"]), float(item["end"])
    dur = end - start
    if dur <= 0 or plate is None:
        return None
    if dur > _MAX_CLIP_SEC:                 # corrupt timeline safety-net — never let one cue run ffmpeg away
        dur = _MAX_CLIP_SEC
    anim = item.get("anim") or "fade"
    out_anim = item.get("out_anim") or "none"
    in_spec = _IN.get(anim)
    out_spec = _OUT.get(out_anim)
    in_dur = in_spec[0] if in_spec else 0.0
    out_dur = out_spec[0] if out_spec else 0.0
    # never let in+out exceed the clip; shrink proportionally, keep a sliver of hold
    if in_dur + out_dur > dur:
        k = dur / (in_dur + out_dur) if (in_dur + out_dur) else 0
        in_dur, out_dur = in_dur * k, out_dur * k
    hold_dur = max(0.0, dur - in_dur - out_dur)

    # crop to the region the caption + its animation can occupy: element box + margin for slide (±70/48)
    # and the pop-up's 1.08 overshoot (~4% of the box each side). ~13x fewer pixels than a full frame.
    el, et, er, eb = plate["bbox"]
    ew, eh = er - el, eb - et
    mx = int(math.ceil(max(72 * pixel_ratio, 0.06 * ew))) + 6 * pixel_ratio
    my = int(math.ceil(max(52 * pixel_ratio, 0.06 * eh))) + 6 * pixel_ratio
    X0, Y0 = max(0, el - mx), max(0, et - my)
    X1, Y1 = min(seq_w, er + mx), min(seq_h, eb + my)
    cw, ch = X1 - X0, Y1 - Y0
    local_img = plate["img"].crop((X0, Y0, X1, Y1))
    lbbox = (el - X0, et - Y0, er - X0, eb - Y0)       # element box in local (crop) coords

    cdir = cache / key
    cdir.mkdir(exist_ok=True)
    parts = []                                        # list of (kind, path/paths, duration)

    n_in = int(round(in_dur * fps))
    if in_spec and n_in > 0:
        for f in range(n_in):
            u = (f + 0.5) / n_in
            _compose(local_img, lbbox, cw, ch, *transform(_in_state(in_spec, u))).save(cdir / f"in{f:05d}.png")
        parts.append(("seq", str(cdir / "in%05d.png"), n_in))
    # static hold — the untransformed final look (the cropped plate itself)
    plate_png = cdir / "hold.png"
    local_img.save(plate_png)
    if hold_dur > 1e-4 or not parts:
        parts.append(("hold", str(plate_png), max(hold_dur, 1.0 / fps)))
    n_out = int(round(out_dur * fps))
    if out_spec and n_out > 0:
        for f in range(n_out):
            u = (f + 0.5) / n_out
            _compose(local_img, lbbox, cw, ch, *transform(_out_state(out_spec, u))).save(cdir / f"out{f:05d}.png")
        parts.append(("seq", str(cdir / "out%05d.png"), n_out))

    # assemble the parts into one clip via concat
    inputs, filters, labels = [], [], []
    for pi, (kind, path, meta) in enumerate(parts):
        if kind == "seq":
            inputs += ["-framerate", str(fps), "-i", path]
        else:
            inputs += ["-loop", "1", "-t", f"{meta:.4f}", "-i", path]
        filters.append(f"[{pi}:v]fps={fps},format=rgba,setpts=PTS-STARTPTS[p{pi}]")
        labels.append(f"[p{pi}]")
    mov = cdir / "clip.mov"
    fc = ";".join(filters) + ";" + "".join(labels) + f"concat=n={len(parts)}:v=1:a=0[v]"
    _run_ffmpeg([*inputs, "-filter_complex", fc, "-map", "[v]", "-c:v", "qtrle",
                 "-pix_fmt", "argb", str(mov)])
    (cdir / "pos.txt").write_text(f"{X0} {Y0}", encoding="utf-8")   # where to overlay this crop
    # the per-frame PNGs are baked into clip.mov now — drop them so a long VSL doesn't bloat the temp dir
    for p in list(cdir.glob("in*.png")) + list(cdir.glob("out*.png")) + [plate_png]:
        try: p.unlink()
        except OSError as _qe: quiet(_qe, "_caption_clip")
    return (mov, X0, Y0)


def _read_pos(cdir):
    try:
        x, y = (cdir / "pos.txt").read_text(encoding="utf-8").split()
        return int(x), int(y)
    except Exception:
        return 0, 0


def build_clips(items, workdir, fps, seq_w=1920, seq_h=1080, progress=None, should_cancel=None, hl_color="#e5322d", pixel_ratio=1):
    """Render all caption/OST items through the browser + animate them. Returns a list of
    (transparent_clip.mov, start, end, x, y) to overlay onto the picture in the main render pass (each
    clip is a small transparent crop, overlaid at x,y). Returns [] if no browser is available or nothing
    rendered — the caller then falls back to libass. `progress(done, total)` is called as clips finish.
    `should_cancel()` (optional) — if it ever returns True the build aborts promptly."""
    def _cancelled():
        try: return bool(should_cancel and should_cancel())
        except Exception: return False

    motion_items = [it for it in items if it.get("kind") == "caption" and motion_enabled(it.get("style"))]
    if motion_items:
        ordinary = [it for it in items if it not in motion_items]
        base = build_clips(ordinary, workdir, fps, seq_w, seq_h, progress, should_cancel, hl_color, pixel_ratio) if ordinary else []
        return base + build_motion_clips(motion_items, workdir, fps, seq_w, seq_h, progress, should_cancel, pixel_ratio)
    edge = edge_exe()
    if not edge or not items:
        return []
    work = Path(workdir)
    fonts_dir = work / "fonts"
    if not (fonts_dir.exists() and any(fonts_dir.iterdir())):
        fonts_dir = Path(__file__).parent / "static" / "fonts"
    cache = work / "_capcache"
    cache.mkdir(exist_ok=True)

    n = len(items)
    keys = [_item_key(it, fps, seq_w, seq_h, pixel_ratio) for it in items]
    result = [None] * n
    todo = []                                     # indices whose clip isn't cached yet
    for i, it in enumerate(items):
        cdir = cache / keys[i]
        mov = cdir / "clip.mov"
        if mov.exists():
            x, y = _read_pos(cdir)
            result[i] = (mov, float(it["start"]), float(it["end"]), x, y)   # reuse — built in a past render
            try: cdir.touch()                                               # mark fresh so it survives pruning
            except OSError as _qe: quiet(_qe, "build_clips")
        else:
            todo.append(i)
    done = [n - len(todo)]                          # list so the worker threads can bump it
    if progress and done[0]:
        try: progress(done[0], n)
        except Exception as _qe: quiet(_qe, "build_clips")

    if todo and not _cancelled():
        # only render plates (headless browser) for the captions we actually need to build
        todo_items = [items[i] for i in todo]
        plates = _render_plates(todo_items, work, fonts_dir, seq_w, seq_h, edge, hl_color, should_cancel, pixel_ratio)

        def _one(j, i):
            r = _caption_clip(keys[i], items[i], plates[j], cache, fps, seq_w, seq_h, pixel_ratio)
            return (i, r)

        # build the clips in parallel — PIL frame gen + a tiny ffmpeg per clip are independent
        workers = max(2, min(6, (os.cpu_count() or 4) - 1))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_one, j, i) for j, i in enumerate(todo)]
            for fut in as_completed(futs):
                try:
                    i, r = fut.result()
                except Exception:
                    r = None; i = None
                if i is not None and r:
                    mov, x, y = r
                    result[i] = (mov, float(items[i]["start"]), float(items[i]["end"]), x, y)
                done[0] += 1
                if progress:
                    try: progress(done[0], n)
                    except Exception as _qe: quiet(_qe, "build_clips")
                if _cancelled():                       # Stop pressed → drop the queued clips, don't wait
                    ex.shutdown(wait=False, cancel_futures=True)
                    break

    # These files are still INPUTS to the caller's encoder after we return. A
    # 400-entry LRU here deleted the beginning of long FAQs before ffmpeg opened
    # it. Even excluding this call's keys can erase another render's inputs.
    # Cache removal therefore belongs to idle storage maintenance, not a build.
    return [r for r in result if r]


# Word motion uses the very same canvas painter in the preview and in an isolated
# local headless browser. Only transparent caption crops enter ffmpeg, not source media.
_MOTION_LOCK = __import__('threading').RLock()


def motion_enabled(style):
    return (style or {}).get('sub_effect') in ('word-box', 'word-pop', 'word-fill')


def timed_caption_words(captions, aligned):
    """Attach aligned speech times to display words, binding punctuation to its word.
    Missing alignment is explicit (estimated); no provider call is made on export.
    Match the whole stream so repeated words do not restart at the first occurrence.
    """
    import difflib
    import re
    def norm(t):
        return re.findall(r'[^\W_]+', str(t).casefold(), re.UNICODE)
    stream, timing = [], []
    for a, b, text in aligned or []:
        for token in norm(text):
            stream.append(token); timing.append((float(a), float(b)))
    targets, records = [], []
    for c in captions:
        units, prefix = [], ''
        for t in str(c.get('text') or '').split():
            if all(x in '«“‘([{$£€' for x in t):
                prefix += t + ' '; continue
            if not any(x.isalnum() for x in t) and units:
                units[-1] += ' ' + t
            else:
                units.append(prefix + t); prefix = ''
        if prefix:
            if units: units[-1] += prefix
            else: units.append(prefix)
        for t in units:
            words = norm(t); records.append((c, t, len(targets), len(words))); targets.extend(words)
        c['words'] = []
    mapping = {}
    for a, b, n in difflib.SequenceMatcher(None, targets, stream, autojunk=False).get_matching_blocks():
        for j in range(n): mapping[a+j] = b+j
    for c, text, first, count in records:
        indices = [mapping[j] for j in range(first, first+count) if j in mapping]
        lo, hi = float(c['start']), float(c['end'])
        if indices and timing[indices[0]][0] < hi and timing[indices[-1]][1] > lo:
            start, end = max(lo, timing[indices[0]][0]), min(hi, timing[indices[-1]][1])
            c['words'].append({'text':text, 'start':start, 'end':max(start+.001, end), 'aligned':True})
        else:
            c['words'].append({'text':text, 'start':None, 'end':None, 'aligned':False})
    for c in captions:
        ws = c['words']; n = len(ws); lo, hi = float(c['start']), float(c['end'])
        # Interpolate only unmatched runs between their neighbouring aligned words.
        i = 0
        while i < n:
            if ws[i]['aligned']: i += 1; continue
            j = i
            while j < n and not ws[j]['aligned']: j += 1
            a = ws[i-1]['end'] if i else lo; b = ws[j]['start'] if j < n else hi
            b = max(a, b)
            for k in range(i,j):
                ws[k]['start'] = a + (b-a)*(k-i)/(j-i)
                ws[k]['end'] = a + (b-a)*(k-i+1)/(j-i)
            i = j
        for i,w in enumerate(ws):
            w['start'] = round(min(hi, max(lo, ws[i-1]['start'] if i else lo, w['start'])), 6)
            w['end'] = round(min(hi, max(w['start']+.001, w['end'])), 6)
        c['word_timing'] = 'aligned' if ws and all(w['aligned'] for w in ws) else 'estimated'
    return captions


def build_motion_clips(items, workdir, fps, seq_w, seq_h, progress=None, should_cancel=None, pixel_ratio=1):
    # One fresh local renderer can recover an interrupted encoder/browser. Completed
    # caption clips stay cached; never restart the whole export or retry bad inputs.
    for attempt in range(2):
        try:
            return _build_motion_clips_once(items, workdir, fps, seq_w, seq_h, progress, should_cancel, pixel_ratio)
        except RuntimeError as exc:
            quiet(exc, 'build_motion_clips')
            recoverable = any(s in str(exc).lower() for s in ('encoder failed', 'timed out', 'not completed', 'broken pipe', 'pipe has been ended'))
            if attempt or not recoverable or (should_cancel and should_cancel()):
                raise


def _build_motion_clips_once(items, workdir, fps, seq_w, seq_h, progress=None, should_cancel=None, pixel_ratio=1):
    """Render clock-driven RGBA crops with no external network and no new dependencies.
    A random local endpoint accepts only ordered PNG frames for the current owned encoder.
    A failed/cancelled encode is never published as a cache hit.
    """
    import threading
    import secrets
    from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
    with _MOTION_LOCK:
        if should_cancel and should_cancel(): raise RuntimeError('cancelled')
        if not items: return []
        edge = edge_exe()
        if not edge: raise RuntimeError('Animated subtitles need Microsoft Edge or Chrome installed.')
        work = Path(workdir); work.mkdir(parents=True, exist_ok=True)
        cache = work / '_motioncache'; cache.mkdir(exist_ok=True)
        result, todo = [], []
        for it in items:
            if float(it['end']) <= float(it['start']): continue
            key = _item_key(it, fps, seq_w, seq_h, pixel_ratio)
            dest = cache / key
            if (dest/'clip.mov').is_file() and (dest/'pos.txt').is_file():
                x,y = _read_pos(dest); result.append((dest/'clip.mov',it['start'],it['end'],x,y))
            else: todo.append((it,key))
        if not todo: return result
        private = Path(tempfile.mkdtemp(prefix='_motion_', dir=work))
        token = secrets.token_urlsafe(24)
        state = {'index':0,'frames':0,'encoder':None,'error':None,'done':False,'log':None}
        done = threading.Event()
        script = (Path(__file__).parent/'static/subtitle_motion.js').read_text('utf8')
        config = {'items':[it for it,k in todo], 'width':seq_w,'height':seq_h,'fps':fps,'pixelRatio':pixel_ratio}
        faces = _font_face_css(Path(__file__).parent/'static/fonts', {(it.get('style') or {}).get('ost_font','Poppins') for it,k in todo})
        page = ('<!doctype html><meta charset="utf-8"><style>'+faces+'</style><canvas id="c"></canvas><script>'+script+'</script><script>'
                +'const config='+json.dumps(config,ensure_ascii=False).replace('<','\\u003c')+';'
                + r"""
                async function post(name,body,extra={}) { const r=await fetch(location.pathname+'/'+name,{method:'POST',body,headers:extra}); if(!r.ok)throw Error(await r.text()); return r; }
                (async()=>{try {
                  for(const it of config.items) { await document.fonts.load(`${it.style.ost_weight||700} ${it.style.ost_size||54}px "${it.style.ost_font||'Poppins'}"`); }
                  await document.fonts.ready;
                  const canvas=document.querySelector('canvas');
                  for(let i=0;i<config.items.length;i++) {
                    const it=config.items[i],l=SubtitleMotion.layout(it,it.style,config.width,config.height),n=Math.max(1,Math.round((it.end-it.start)*config.fps));
                    const bounds=Object.fromEntries(Object.entries(l.bounds).map(([k,v])=>[k,v*config.pixelRatio]));
                    await post('begin',JSON.stringify({i,n,bounds}));
                    for(let f=0;f<n;f++) {
                      SubtitleMotion.paint(canvas,l,it.start+f/config.fps,true,config.pixelRatio);
                      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
                      await post('frame',blob,{'X-Frame':String(f)});
                    }
                    await post('end','');
                  }
                  await post('finish','');
                } catch(e) { await post('error',String(e)).catch(()=>{}); }})();
                """+'</script>')
        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(20)
            def log_message(self,*args): pass
            def reply(self,code=200,data=b'OK',kind='text/plain'):
                self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
            def do_GET(self):
                if self.path=='/'+token: self.reply(200,page.encode('utf8'),'text/html; charset=utf-8')
                else: self.reply(404)
            def do_POST(self):
                try:
                    if not self.path.startswith('/'+token+'/'): self.reply(403);return
                    if should_cancel and should_cancel(): raise RuntimeError('cancelled')
                    size=int(self.headers.get('Content-Length','0'))
                    if not 0<=size<=16_000_000: raise ValueError('Invalid subtitle frame size')
                    body=self.rfile.read(size); action=self.path.rsplit('/',1)[-1]
                    if action=='begin':
                        data=json.loads(body);idx=state['index']
                        if state['encoder'] or data['i']!=idx or idx>=len(todo): raise ValueError('Unexpected subtitle clip')
                        it,key=todo[idx]; expected=max(1,round((float(it['end'])-float(it['start']))*fps))
                        if data['n']!=expected or expected>_MAX_CLIP_SEC*fps: raise ValueError('Invalid subtitle duration')
                        b=data['bounds']
                        if not (0<=b['x']<seq_w*pixel_ratio and 0<=b['y']<seq_h*pixel_ratio and 0<b['width']<=seq_w*pixel_ratio and 0<b['height']<=seq_h*pixel_ratio): raise ValueError('Invalid subtitle bounds')
                        state['bounds']=b;state['expected']=expected;state['frames']=0
                        state['log']=open(private/'ffmpeg.log','wb')
                        state['encoder']=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','image2pipe','-framerate',str(fps),'-vcodec','png','-i','pipe:0','-an','-c:v','qtrle','-pix_fmt','argb',str(private/'clip.mov')],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=state['log'],creationflags=_NO_WINDOW)
                    elif action=='frame':
                        enc=state['encoder']
                        if not enc or int(self.headers.get('X-Frame','-1'))!=state['frames'] or state['frames']>=state['expected'] or body[:8]!=b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid subtitle frame order')
                        enc.stdin.write(body);enc.stdin.flush();state['frames']+=1
                    elif action=='end':
                        enc=state['encoder']
                        if not enc or state['frames']!=state['expected']: raise ValueError('Incomplete subtitle clip')
                        enc.stdin.close()
                        if enc.wait(timeout=60)!=0:
                            state['log'].flush()
                            detail=(private/'ffmpeg.log').read_text('utf8',errors='replace')[-600:].strip()
                            raise RuntimeError('Subtitle encoder failed'+(': '+detail if detail else ''))
                        state['encoder']=None;state['log'].close();state['log']=None
                        it,key=todo[state['index']];dest=cache/key;dest.mkdir(exist_ok=True);b=state['bounds']
                        (dest/'pos.txt').write_text(f"{b['x']} {b['y']}",'utf8')
                        os.replace(private/'clip.mov',dest/'clip.mov')
                        result.append((dest/'clip.mov',it['start'],it['end'],b['x'],b['y']))
                        state['index']+=1
                        if progress: progress(len(result),len(items))
                    elif action=='finish':
                        if state['index']!=len(todo): raise ValueError('Incomplete subtitles')
                        state['done']=True;done.set()
                    elif action=='error': raise RuntimeError(body.decode('utf8',errors='replace')[:300])
                    else: self.reply(404);return
                    self.reply()
                except Exception as e:
                    # Keep the originating failure: the browser's follow-up /error
                    # request must not replace it with "Subtitle rendering failed".
                    if not state['error']:
                        item=todo[min(state['index'],len(todo)-1)][0]
                        state['error']=f"Subtitle at {float(item['start']):.2f}s: {e}"
                    done.set();self.reply(500,b'Subtitle rendering failed')
        # Chromium pre-connects idle sockets; a single-threaded server would wait
        # on one of those and never receive the frame POST on another connection.
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True;server.timeout=1
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();browser=None
        try:
            url=f'http://127.0.0.1:{server.server_port}/{token}'
            browser=subprocess.Popen([edge,'--edge-skip-compat-layer-relaunch','--headless=new','--no-sandbox','--disable-gpu','--no-first-run','--disable-background-networking','--disable-background-timer-throttling','--disable-renderer-backgrounding','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1',f'--user-data-dir={private/"profile"}',url],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=_NO_WINDOW)
            deadline=time.monotonic()+max(120, sum(max(0,it['end']-it['start']) for it,k in todo)*6)
            while not done.wait(.1):
                if should_cancel and should_cancel(): raise RuntimeError('cancelled')
                if time.monotonic()>deadline: raise RuntimeError('Animated subtitle rendering timed out')
            if state['error']: raise RuntimeError(state['error'])
            if not state['done']: raise RuntimeError('Animated subtitles were not completed')
            return sorted(result,key=lambda x:x[1])
        finally:
            enc=state['encoder']
            if enc:
                enc.kill();enc.wait(timeout=10)
                if enc.stdin: enc.stdin.close()
            if state['log']: state['log'].close()
            server.shutdown();server.server_close();thread.join(timeout=3)
            if browser:
                subprocess.run(['taskkill','/PID',str(browser.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=_NO_WINDOW,timeout=15)
                try:browser.wait(timeout=5)
                except subprocess.TimeoutExpired:browser.kill()
            shutil.rmtree(private,ignore_errors=True)


def _video_frame_count(path):
    """MOV stores an exact sample count; do not infer completeness from file size."""
    result = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries', 'stream=nb_frames', '-of', 'json', str(path)],
                            capture_output=True, check=True, timeout=30, creationflags=_NO_WINDOW)
    try:
        return int(json.loads(result.stdout)['streams'][0]['nb_frames'])
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise RuntimeError('The subtitle layer frame count could not be verified.') from exc


def build_subtitle_overlay(items, workdir, total, fps, seq_w, seq_h, should_cancel=None, outro=0,
                           prepared_clips=None, progress=None, cache_tag=None, stage_progress=None, pixel_ratio=1):
    """Full-canvas alpha MOV using the same caption crop pixels as the MP4.
    Transparent gaps and durations are integer frames. Publish only a complete file.
    """
    if pixel_ratio not in (1, 2): raise ValueError("Unsupported subtitle pixel ratio")
    if pixel_ratio != 1 and prepared_clips is not None: raise ValueError("High-resolution subtitles need original captions")
    output_w, output_h = seq_w * pixel_ratio, seq_h * pixel_ratio
    stage = stage_progress or (lambda *args: None)
    stage("Waiting for Subtitle Renderer")
    with _MOTION_LOCK:
        if not items: raise ValueError('There are no subtitles to export.')
        work = Path(workdir); work.mkdir(parents=True, exist_ok=True)
        keys = [_item_key(it, fps, seq_w, seq_h, pixel_ratio) for it in items]
        outro = max(0,min(float(outro or 0),total))
        signature = json.dumps([keys, [(it['start'],it['end']) for it in items],total,fps,seq_w,seq_h,outro,'overlay-v2-exact-frames'])
        if cache_tag is not None: signature += json.dumps(cache_tag, sort_keys=True)
        digest = hashlib.sha256(signature.encode()).hexdigest()[:20]
        output = work / ('subtitles_'+digest+'.mov')
        if output.is_file() and output.stat().st_size:
            stage("Using Cached Subtitles")
            if progress: progress(max(1,round(total*fps)),max(1,round(total*fps)))
            return output
        stage("Rendering Subtitles", 0, len(items), "captions")
        clips = sorted(prepared_clips if prepared_clips is not None else build_clips(items, work, fps, seq_w, seq_h, should_cancel=should_cancel, progress=lambda done, count: stage("Rendering Subtitles", done, count, "captions"), pixel_ratio=pixel_ratio), key=lambda c:c[1])
        if len(clips)!=len(items): raise RuntimeError('Some subtitle clips could not be rendered. Nothing was exported.')
        total_f=max(1,round(total*fps));private=Path(tempfile.mkdtemp(prefix='_subtitle_export_',dir=work));segments=[]
        try:
            stage("Building Transparent Video", 0, total_f, "frames")
            cursor=0; completed_frames=0
            def cancelled():
                if should_cancel and should_cancel(): raise RuntimeError('cancelled')
            def segment(nframes,source=None,x=0,y=0,skip=0):
                nonlocal completed_frames
                if nframes<=0:return
                cancelled();dest=private/f's{len(segments):05d}.mov'
                if source:
                    # Local clip rounding can be a frame shorter than its absolute
                    # timeline interval. Extend only that rounding margin, then cut
                    # to the exact requested count; never let it advance later cues.
                    args=['-ss',f'{skip/fps:.8f}','-i',str(source),'-vf',f'fps={fps},format=rgba,pad={output_w}:{output_h}:{x}:{y}:color=black@0,setsar=1,tpad=stop_mode=clone:stop=2,trim=end_frame={nframes},setpts=PTS-STARTPTS']
                else: args=['-f','lavfi','-i',f'color=black@0:s={output_w}x{output_h}:r={fps},format=rgba']
                _run_ffmpeg([*args,'-an','-r',str(fps),'-frames:v',str(nframes),'-c:v','qtrle','-pix_fmt','argb',str(dest)],timeout=max(180,nframes/fps*4))
                segments.append(dest)
                completed_frames += nframes
                stage("Building Transparent Video", completed_frames, total_f, "frames")
                if progress: progress(completed_frames,total_f)
            for mov,start,end,x,y in clips:
                a,b=max(0,round(start*fps)),min(total_f,round(end*fps))
                if a>cursor:segment(a-cursor)
                skip=max(0,cursor-a);a=max(cursor,a)
                if b>a:segment(b-a,mov,x,y,skip)
                cursor=max(cursor,b)
            if cursor<total_f:segment(total_f-cursor)
            cancelled();listing=private/'concat.txt'
            listing.write_text(''.join(f"file '{p.name}'\n" for p in segments),'utf8')
            final=private/'final.mov'
            stage("Finalizing Transparent Video")
            encode = ['-vf',f'fade=t=out:st={total-outro:.6f}:d={outro:.6f}:alpha=1','-c:v','qtrle','-pix_fmt','argb'] if outro else ['-c','copy']
            _run_ffmpeg(['-f','concat','-safe','0','-i',str(listing),*encode,str(final)],timeout=max(180,total*2))
            if _video_frame_count(final) != total_f:
                raise RuntimeError('Subtitle timing verification failed. No incomplete video was exported. Please try again.')
            os.replace(final,output)
            return output
        finally: shutil.rmtree(private,ignore_errors=True)
