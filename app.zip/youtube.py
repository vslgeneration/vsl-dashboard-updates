"""Signing in to YouTube and putting an episode on it.

Google's own client library is not used - it drags in a large dependency tree for what is, in the end,
three HTTPS calls. This does the installed-app OAuth flow by hand:

  * a loopback redirect (http://127.0.0.1:<free port>), which is what Google wants for a Desktop client
    and which means the user never has to register a redirect URL,
  * PKCE, so the authorisation code is useless to anything that intercepts it,
  * a refresh token kept in the app config, so signing in happens once.

The upload is RESUMABLE, because an episode is tens of megabytes and a plain POST that dies at 90% has
to start over. A scheduled episode goes up PRIVATE with publishAt set - that is the only way YouTube
accepts a future publish time.
"""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import os
import http.client
import secrets
import socket
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from quietlog import quiet

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
UPLOAD_URL = "https://www.googleapis.com/upload/youtube/v3/videos"
THUMB_URL = "https://www.googleapis.com/upload/youtube/v3/thumbnails/set"
API_URL = "https://www.googleapis.com/youtube/v3"
# youtube.upload puts the video up; youtube covers the thumbnail and reading the channel's own name.
SCOPES = "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube"
CHUNK = 4 << 20
# keep the console window from flashing up on every yt-dlp call
_NOWIN = {"creationflags": 0x08000000} if os.name == "nt" else {}


class YouTubeError(RuntimeError):
    pass


class QuotaSpent(YouTubeError):
    """YouTube's daily allowance is gone. Nothing to fix - it comes back at midnight Pacific."""


# ---------------------------------------------------------------- IPv4 (see _v4_connect)
def _v4_connect(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None):
    """Connect over IPv4, falling back to whatever DNS offers if there is no working v4 route.

    Measured on this machine: 24/24 TLS handshakes to googleapis.com succeed over IPv4 and 13/24 fail
    over IPv6 with INVALID_SESSION_ID or a 19s hang. Windows tries IPv6 first, so an upload that would
    take a minute was failing before it sent a byte. curl fails the same way, so it is the route, not us.
    """
    host, port = address
    last = None
    try:
        infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
    except OSError as e:
        infos, last = [], e
    for fam, typ, proto, _canon, sa in infos:
        sock = socket.socket(fam, typ, proto)
        try:
            if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
                sock.settimeout(timeout)
            if source_address:
                sock.bind(source_address)
            sock.connect(sa)
            return sock
        except OSError as e:
            last = e
            sock.close()
    # no IPv4 route at all (an IPv6-only network) - let the stack decide, as it did before
    return socket.create_connection(address, timeout, source_address)


class _V4HTTPSConnection(http.client.HTTPSConnection):
    # HTTPConnection.__init__ assigns _create_connection onto the INSTANCE, so a class attribute here
    # would be shadowed and silently ignored. Set it after super().__init__ has run.
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._create_connection = _v4_connect


class _V4HTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_V4HTTPSConnection, req, context=self._context)


def _opener(context):
    return urllib.request.build_opener(_V4HTTPSHandler(context=context))


def _ctx():
    """A FRESH TLS context per request.

    Reusing one lets OpenSSL try to resume a cached TLS session, and on machines behind antivirus /
    corporate TLS inspection that comes back as "INVALID_SESSION_ID" - seen here on roughly one call in
    two. A new context has nothing to resume, so the handshake is done from scratch every time.
    """
    return ssl.create_default_context()


def _open(req, timeout=60, tries=5):
    """urlopen that survives a flaky line. HTTP replies (including 308) are passed straight through -
    only a dead connection is retried."""
    last = None
    for n in range(tries):
        try:
            return _opener(_ctx()).open(req, timeout=timeout)
        except urllib.error.HTTPError:
            raise                                       # the server answered; that is the caller's business
        except Exception as e:                          # TLS hiccup, reset, DNS blip, timeout
            last = e
            if n + 1 < tries:
                time.sleep(min(8, 1.5 ** n))
    raise YouTubeError("Could not reach Google (%s: %s). Check the connection and try again."
                       % (type(last).__name__, str(last)[:160]))


def _post_form(url, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with _open(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise YouTubeError("Google refused the request (%s): %s"
                           % (e.code, e.read().decode("utf-8", "replace")[:400]))


# ---------------------------------------------------------------- sign in
class _Catcher(BaseHTTPRequestHandler):
    result = {}

    def do_GET(self):                       # noqa: N802
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        _Catcher.result = {k: v[0] for k, v in q.items()}
        ok = "code" in _Catcher.result
        msg = ("Signed in. You can close this tab and go back to the app."
               if ok else "Sign-in was refused or cancelled. Close this tab and try again.")
        page = ("<html><head><meta charset=utf-8><title>AI Dashboard</title></head>"
                "<body style=\"font:16px system-ui;background:#0b0e0c;color:#e6ede8;display:flex;"
                "align-items:center;justify-content:center;height:100vh\"><div>"
                + msg + "</div></body></html>").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def log_message(self, *a):              # keep the console quiet
        pass


def build_auth(client_id, redirect, challenge, state):
    return AUTH_URL + "?" + urllib.parse.urlencode({
        "client_id": client_id, "redirect_uri": redirect, "response_type": "code",
        "scope": SCOPES, "access_type": "offline", "prompt": "consent",
        "code_challenge": challenge, "code_challenge_method": "S256", "state": state,
    })


def start_sign_in(client_id, client_secret, on_done, timeout=300, open_browser=True):
    """Open Google's consent page and wait for the redirect. Calls on_done(tokens, error)."""
    if not (client_id and client_secret):
        on_done(None, "Add the Google client ID and secret in Settings first.")
        return None
    # Bind the listener HERE, not in the thread. Picking a free port and rebinding it a moment later
    # can lose the race to anything else on the machine, and by then the caller has already returned.
    try:
        srv = HTTPServer(("127.0.0.1", 0), _Catcher)
    except OSError as e:
        on_done(None, "Could not listen for Google's reply: %s" % e)
        return None
    port = srv.server_address[1]
    redirect = "http://127.0.0.1:%d/" % port
    verifier = base64.urlsafe_b64encode(os.urandom(48)).decode().rstrip("=")
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    state = secrets.token_urlsafe(16)
    url = build_auth(client_id, redirect, challenge, state)

    def run():
        srv.timeout = timeout
        _Catcher.result = {}
        srv.handle_request()                       # exactly one request: the redirect
        srv.server_close()
        got = dict(_Catcher.result)
        if not got:
            on_done(None, "Sign-in timed out - the browser never came back.")
            return
        if got.get("state") != state:
            on_done(None, "The sign-in came back with the wrong state, so nothing was saved.")
            return
        if not got.get("code"):
            on_done(None, got.get("error") or "Sign-in was cancelled.")
            return
        try:
            tok = _post_form(TOKEN_URL, {
                "code": got["code"], "client_id": client_id, "client_secret": client_secret,
                "redirect_uri": redirect, "grant_type": "authorization_code",
                "code_verifier": verifier})
        except YouTubeError as e:
            on_done(None, str(e))
            return
        if not tok.get("refresh_token"):
            on_done(None, "Google did not send a refresh token. Remove this app under your Google "
                          "account's third-party access, then sign in again.")
            return
        tok["expires_at"] = time.time() + float(tok.get("expires_in") or 3500)
        on_done(tok, None)

    threading.Thread(target=run, daemon=True).start()
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception as _qe:
            quiet(_qe, "start_sign_in")
    return url


class SignInExpired(YouTubeError):
    """The refresh token is dead - the only cure is signing in again."""


def access_token(cfg):
    """A live access token, refreshed if the stored one has expired. Raises if not signed in."""
    tok = cfg.get("youtube_token") or {}
    if not tok.get("refresh_token"):
        raise YouTubeError("Not signed in to YouTube yet.")
    if tok.get("access_token") and float(tok.get("expires_at") or 0) > time.time() + 60:
        return tok["access_token"]
    try:
        fresh = _post_form(TOKEN_URL, {
            "client_id": cfg.get("youtube_client_id") or "",
            "client_secret": cfg.get("youtube_client_secret") or "",
            "refresh_token": tok["refresh_token"], "grant_type": "refresh_token"})
    except YouTubeError as e:
        # Google revokes the refresh token of an app still in Testing every 7 days, and revokes it for
        # good if access is removed. Either way the raw JSON tells the user nothing they can act on.
        if "invalid_grant" in str(e):
            cfg.pop("youtube_token", None)
            cfg.pop("youtube_channel", None)
            raise SignInExpired(
                "The YouTube sign-in expired. Open Settings -> Keys and press Connect YouTube again. "
                "(Google drops it every 7 days while the app is still in Testing - set the app to "
                "In production on the Google Auth Platform Audience page to stop that.)")
        raise
    tok["access_token"] = fresh.get("access_token")
    tok["expires_at"] = time.time() + float(fresh.get("expires_in") or 3500)
    cfg["youtube_token"] = tok
    return tok["access_token"]


def channel_name(cfg):
    at = access_token(cfg)
    req = urllib.request.Request(API_URL + "/channels?part=snippet&mine=true",
                                 headers={"Authorization": "Bearer " + at})
    with _open(req, timeout=45) as r:
        d = json.loads(r.read().decode("utf-8"))
    items = d.get("items") or []
    return (items[0]["snippet"]["title"] if items else "") or ""


# ---------------------------------------------------------------- upload
def _session_url(cfg, video_path, snippet, status, size):
    at = access_token(cfg)
    body = json.dumps({"snippet": snippet, "status": status}).encode("utf-8")
    req = urllib.request.Request(
        UPLOAD_URL + "?uploadType=resumable&part=snippet,status", data=body, method="POST",
        headers={"Authorization": "Bearer " + at,
                 "Content-Type": "application/json; charset=UTF-8",
                 "X-Upload-Content-Length": str(size), "X-Upload-Content-Type": "video/*"})
    try:
        with _open(req, timeout=60) as r:
            return r.headers.get("Location")
    except urllib.error.HTTPError as e:
        raise YouTubeError("YouTube would not start the upload (%s): %s"
                           % (e.code, e.read().decode("utf-8", "replace")[:400]))


def _resume_point(session, size):
    """Ask YouTube how much of the file it already has. Returns the next byte to send, or -1 if it is
    finished with the upload (in which case the video already exists)."""
    req = urllib.request.Request(session, data=b"", method="PUT",
                                 headers={"Content-Length": "0",
                                          "Content-Range": "bytes */%d" % size})
    try:
        with _open(req, timeout=60):
            return -1                                   # 200/201: it is already complete
    except urllib.error.HTTPError as e:
        if e.code != 308:
            raise
        rng = e.headers.get("Range")                    # "bytes=0-1048575", or absent if it has nothing
        if not rng or "-" not in rng:
            return 0
        return int(rng.rsplit("-", 1)[1]) + 1


def upload(cfg, video_path, snippet, status, on_progress=None, retries=6):
    """Resumable upload. Returns the new video id.

    Every network hiccup is survivable: on a dropped connection or a 5xx the upload asks YouTube how far
    it actually got and carries on from there, instead of throwing away an episode that was 90% sent.
    """
    size = Path(video_path).stat().st_size
    session = _session_url(cfg, video_path, snippet, status, size)
    if not session:
        raise YouTubeError("YouTube did not give us an upload session.")
    sent, tries, last_err = 0, 0, None
    with open(video_path, "rb") as f:
        while sent < size:
            f.seek(sent)
            chunk = f.read(CHUNK)
            if not chunk:
                break
            end = sent + len(chunk) - 1
            put = urllib.request.Request(
                session, data=chunk, method="PUT",
                headers={"Content-Length": str(len(chunk)),
                         "Content-Range": "bytes %d-%d/%d" % (sent, end, size)})
            try:
                with _opener(_ctx()).open(put, timeout=900) as r:
                    return (json.loads(r.read().decode("utf-8")) or {}).get("id") or ""
            except urllib.error.HTTPError as e:
                if e.code == 308:                       # "keep going" - the normal per-chunk reply
                    sent, tries = end + 1, 0
                    if on_progress:
                        on_progress(int(sent * 100 / max(1, size)))
                    continue
                if e.code not in (500, 502, 503, 504):  # a real refusal: bad file, quota, wrong scope
                    raise YouTubeError("The upload failed at %d%% (%s): %s"
                                       % (int(sent * 100 / max(1, size)), e.code,
                                          e.read().decode("utf-8", "replace")[:300]))
                last_err = "YouTube returned %s" % e.code
            except Exception as e:                      # dropped connection, TLS hiccup, timeout
                last_err = "%s: %s" % (type(e).__name__, str(e)[:120])
            # something transient - back off, ask where we really are, and carry on from there
            tries += 1
            if tries > retries:
                raise YouTubeError("The upload kept failing at %d%% (%s). Try again - it resumes."
                                   % (int(sent * 100 / max(1, size)), last_err))
            time.sleep(min(30, 2 ** tries))
            try:
                where = _resume_point(session, size)
            except Exception:
                continue                                # even the probe failed; just retry the chunk
            if where < 0:
                break                                   # YouTube says it has the lot
            sent = where
            if on_progress:
                on_progress(int(sent * 100 / max(1, size)))
    raise YouTubeError("The upload ended without YouTube confirming the video.")


# ---------------------------------------------------------------- where searches come from
# A YouTube search costs 100 of a project's 10,000 units a day, and a sweep of twenty topics spends
# the lot. So a search is tried against several sources in turn:
#   1. any plain API keys in the config - each belongs to its OWN Cloud project, so a second key is a
#      second daily allowance. Reading public search results needs no sign-in, only a key.
#   2. the signed-in channel's own OAuth, as a last resort - that allowance is better kept for uploads.
#   3. yt-dlp, which has no allowance at all. Slower, unofficial, and the caller is TOLD when it is
#      used, because the numbers come from a different road and the user should know which.
CACHE_DIR = None                   # app.py points this at the data folder
CACHE_DAYS = 7                     # view counts move slowly; a week-old reading is still a reading
_SPENT = set()                     # sources known to be out of allowance, for this process
YTDLP_MAX = 20                     # full look-ups to run for a fallback search
YTDLP_WORKERS = 6


def _cache_path():
    if not CACHE_DIR:
        return None
    try:
        d = Path(CACHE_DIR)
        d.mkdir(parents=True, exist_ok=True)
        return d / "yt_search_cache.json"
    except Exception:
        return None


def _cache_load():
    p = _cache_path()
    if not p or not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _cache_get(key):
    e = _cache_load().get(key)
    if not e:
        return None
    if time.time() - float(e.get("at") or 0) > CACHE_DAYS * 86400:
        return None
    return e.get("rows")


def _cache_put(key, rows, source):
    p = _cache_path()
    if not p:
        return
    try:
        d = _cache_load()
        d[key] = {"at": time.time(), "rows": rows, "source": source}
        if len(d) > 400:                       # keep the file small - drop the oldest half
            for k in sorted(d, key=lambda k: d[k].get("at", 0))[:len(d) // 2]:
                d.pop(k, None)
        p.write_text(json.dumps(d), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "_cache_put")


def ytdlp_exe():
    """App-local verified helper, PATH, or WinGet; no system installation needed."""
    bundled=Path(__file__).resolve().parent/'tools/yt-dlp.exe'
    if bundled.is_file() and bundled.stat().st_size>1_000_000:
        return str(bundled)
    p = shutil.which("yt-dlp") or shutil.which("yt-dlp.exe")
    if p:
        return p
    for g in (Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Packages").glob(
            "yt-dlp*/yt-dlp.exe"):
        return str(g)
    return None


def _ytdlp_one(exe, vid):
    try:
        r = subprocess.run([exe, "https://www.youtube.com/watch?v=" + vid, "--dump-json",
                            "--skip-download", "--no-warnings", "--no-playlist"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=90, **_NOWIN)
        if r.returncode or not r.stdout.strip():
            return None
        return json.loads(r.stdout)
    except Exception:
        return None


def _ytdlp_search(query, n=25):
    """The same rows the API would give, without an allowance to spend.

    The flat search is one cheap call but carries no subscriber count and no upload date - and this
    whole reading is built on those two. So each result is looked up properly afterwards, in parallel.
    """
    exe = ytdlp_exe()
    if not exe:
        raise YouTubeError("yt-dlp is not installed on this PC.")
    try:
        r = subprocess.run([exe, "ytsearch%d:%s" % (int(n), query), "--flat-playlist", "--print", "id",
                            "--no-warnings"], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180, **_NOWIN)
    except Exception as e:
        raise YouTubeError("yt-dlp could not search (%s)." % str(e)[:120])
    ids = [x.strip() for x in (r.stdout or "").splitlines() if len(x.strip()) == 11][:YTDLP_MAX]
    if not ids:
        raise YouTubeError("yt-dlp found nothing for that search.")
    rows = []
    with ThreadPoolExecutor(max_workers=YTDLP_WORKERS) as pool:
        for d in pool.map(lambda v: _ytdlp_one(exe, v), ids):
            if not d:
                continue
            dur = int(d.get("duration") or 0)
            if dur < 90:
                continue
            views = int(d.get("view_count") or 0)
            subs = int(d.get("channel_follower_count") or 0)
            up = str(d.get("upload_date") or "")
            rows.append({"title": d.get("title") or "", "channel": d.get("channel") or "",
                         "views": views, "subs": subs, "ratio": (views / subs) if subs else 0.0,
                         "minutes": round(dur / 60.0, 1),
                         "published": ("%s-%s" % (up[:4], up[4:6])) if len(up) == 8 else "",
                         "url": "https://youtu.be/" + str(d.get("id") or "")})
    return rows


def search_sources(cfg):
    """In order: each API key (its own project, its own allowance), then OAuth, then yt-dlp."""
    out = []
    for k in ("youtube_api_key", "youtube_api_key2", "youtube_api_key3"):
        v = (cfg.get(k) or "").strip()
        if v:
            out.append(("key:" + k, v))
    if (cfg.get("youtube_token") or {}).get("refresh_token"):
        out.append(("oauth", None))
    if ytdlp_exe():
        out.append(("ytdlp", None))
    return out


# ---------------------------------------------------------------- is anyone watching this?
# Views alone say nothing about a topic: a channel with five million subscribers gets big numbers
# whatever it uploads. The number that transfers to a channel with no audience is views DIVIDED BY
# SUBSCRIBERS - when a thousand-subscriber channel takes a hundred thousand views, the TOPIC did that,
# not the channel, and a new channel can borrow it. The other half of the picture is the graveyard:
# how many small channels tried the same thing and sank. Measured on real searches, a saturated topic
# shows seven to seventeen small channels under a thousand views each.
OUTLIER_RATIO = 3.0            # views >= 3x subscribers: the topic carried it
OUTLIER_VIEWS = 100_000        # ...and enough views that it was not a fluke
SANK_VIEWS = 1_000             # a small channel's video nobody found
SMALL_CHANNEL = 5_000
FRESH_MONTHS = 30              # older than this proves nothing about what works NOW

# Recency is not a refinement, it is the whole thing. Checked by hand on one topic: the "winners" were
# classroom films from 2008-2016 that happen to share a subject, while SEVEN recent attempts at the
# actual angle - same claim, same length - drew 810, 165, 21, 13, 12, 5 and 1 views. Counting the old
# ones produced a confident GOOD on a topic that has killed everyone who tried it lately.


def _iso_secs(iso):
    m = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", iso or "")
    if not m:
        return 0
    h, mi, se = (int(x) if x else 0 for x in m.groups())
    return h * 3600 + mi * 60 + se


def _search_api(cfg, query, n=25, api_key=None):
    """One search plus the two cheap look-ups that turn it into numbers worth reading.

    Quota: search costs 100 units of the 10,000-a-day allowance, videos and channels 1 each.
    """
    d = _api_json(cfg, "/search?part=snippet&type=video&maxResults=%d&q=%s"
                       % (int(n), urllib.parse.quote(query)), api_key=api_key)
    ids = [it["id"]["videoId"] for it in d.get("items") or [] if (it.get("id") or {}).get("videoId")]
    if not ids:
        return []
    v = _api_json(cfg, "/videos?part=snippet,statistics,contentDetails&id=" + ",".join(ids),
                  api_key=api_key)
    items = v.get("items") or []
    chans = list({it["snippet"]["channelId"] for it in items})
    subs = {}
    for i in range(0, len(chans), 50):
        c = _api_json(cfg, "/channels?part=statistics&id=" + ",".join(chans[i:i + 50]),
                      api_key=api_key)
        for it in c.get("items") or []:
            subs[it["id"]] = int((it.get("statistics") or {}).get("subscriberCount") or 0)
    rows = []
    for it in items:
        sn, st = it["snippet"], it.get("statistics") or {}
        dur = _iso_secs((it.get("contentDetails") or {}).get("duration", ""))
        if dur < 90:
            continue                       # a Short is a different format, not this episode's rival
        views, nsub = int(st.get("viewCount") or 0), subs.get(sn["channelId"], 0)
        rows.append({"title": sn["title"], "channel": sn["channelTitle"], "views": views,
                     "subs": nsub, "ratio": (views / nsub) if nsub else 0.0,
                     "minutes": round(dur / 60.0, 1), "published": sn.get("publishedAt", "")[:7],
                     "url": "https://youtu.be/" + it["id"]})
    return rows


def _search_stats(cfg, query, n=25, note=None):
    """Try each source in turn until one answers. Returns (rows, which source answered).

    A source that reports its allowance is spent is remembered and skipped for the rest of the run,
    so twenty topics do not each waste a call discovering the same thing.
    """
    key = "%s|%d" % (query.strip().lower(), n)
    hit = _cache_get(key)
    if hit is not None:
        return hit, "cache"
    srcs = search_sources(cfg)
    if not srcs:
        raise YouTubeError("No way to search YouTube. Add a Google API key in Settings, or connect "
                           "your channel.")
    last = None
    for name, api_key in srcs:
        if name in _SPENT:
            continue
        try:
            rows = _ytdlp_search(query, n) if name == "ytdlp" else _search_api(cfg, query, n, api_key)
            if name == "ytdlp" and note:
                note("Searched with yt-dlp instead of the YouTube API - every API allowance is spent "
                     "for today. The numbers are the same, they just took a different road.")
            _cache_put(key, rows, name)
            return rows, name
        except QuotaSpent as e:
            _SPENT.add(name)
            last = e
        except Exception as e:
            last = e
    raise last or QuotaSpent("Every way of searching YouTube is unavailable right now.")


_DEMAND_CACHE = {}                 # query -> rows, for this process. A sweep asks the same thing twice.


def demand(cfg, queries, our_minutes=4.0, per_query=25, keep=None, note=None):
    """Read the room for a topic. Returns the evidence AND a verdict, with the reason spelled out.

    `keep` filters the search results down to the ones actually ABOUT this subject. Without it a query
    that drifts even slightly ("noise cancelling microphone") drags in a film soundtrack and two
    Windows tutorials, and the verdict gets built on videos that are not competing with anything.
    """
    if isinstance(queries, str):
        queries = [queries]
    rows, seen = [], set()
    sources = set()
    for q in queries[:3]:
        got, src = _search_stats(cfg, q, per_query, note=note)
        sources.add(src)
        for r in got:
            k = (r["title"], r["channel"])
            if k not in seen:
                seen.add(k)
                rows.append(r)
    found = len(rows)
    if keep and rows:
        try:
            rows = keep(rows)
        except Exception as _qe:
            quiet(_qe, "demand")                                # a filter that fails must not lose the whole check
    if not rows:
        return {"verdict": "unknown", "why": "No comparable videos came back for that search.",
                "rows": [], "outliers": [], "checked": 0, "source": ",".join(sorted(sources))}
    cutoff = (datetime.now(timezone.utc) - timedelta(days=30 * FRESH_MONTHS)).strftime("%Y-%m")
    for r in rows:
        r["fresh"] = bool(r.get("published")) and r["published"] >= cutoff
    outliers = [r for r in rows
                if r["ratio"] >= OUTLIER_RATIO and r["views"] >= OUTLIER_VIEWS and r["minutes"] >= 2
                and r["fresh"]]
    small = [r for r in rows if 0 < r["subs"] < SMALL_CHANNEL]
    sank = [r for r in small if r["views"] < SANK_VIEWS]
    small_new = [r for r in small if r["fresh"]]
    sank_new = [r for r in small_new if r["views"] < SANK_VIEWS]
    stale_wins = [r for r in rows if r["ratio"] >= OUTLIER_RATIO and r["views"] >= OUTLIER_VIEWS
                  and not r["fresh"]]
    worked = [r for r in rows if r["views"] >= 200_000]
    med = 0.0
    if worked:
        w = sorted(r["minutes"] for r in worked)
        med = w[len(w) // 2] if len(w) % 2 else (w[len(w) // 2 - 1] + w[len(w) // 2]) / 2.0
    death = (len(sank) / len(small)) if small else 0.0
    # a topic a small channel recently won with is the strongest signal there is
    reachable = [r for r in outliers if r["subs"] < 200_000]
    why = []
    if reachable:
        b = max(reachable, key=lambda r: r["ratio"])
        why.append("A channel with %s subscribers took %s views with this (%.0fx)."
                   % (f"{b['subs']:,}", f"{b['views']:,}", b["ratio"]))
    else:
        why.append("No small channel has won with this - every big number belongs to a channel that "
                   "was already big.")
    if stale_wins and not reachable:
        why.append("%d video(s) did well with this, but years ago - nothing recent has."
                   % len(stale_wins))
    if len(small_new) >= 3:
        why.append("Of the small channels that tried it in the last %d months, %d of %d were never "
                   "found (%.0f%%)." % (FRESH_MONTHS, len(sank_new), len(small_new),
                                        100.0 * len(sank_new) / len(small_new)))
    elif len(small) >= 4:
        why.append("%d of %d small channels that tried it were never found (%.0f%%)."
                   % (len(sank), len(small), death * 100))
    if med:
        why.append("The videos that worked run about %g minutes; this episode is %g."
                   % (med, our_minutes))
    length_off = bool(med) and med > max(8.0, our_minutes * 2.5)
    # the recent death rate outranks the all-time one: what happened last year is what will happen
    death = (len(sank_new) / len(small_new)) if len(small_new) >= 3 else death
    # Measured across 442 videos in one afternoon: of recent uploads by channels under 200k subs, only
    # 2% ever take 100k views at 3x their subscriber count. So a proven breakout is a LOTTERY WIN, not
    # a bar a topic can be expected to clear - demanding one would reject everything, which is what it
    # did for three sweeps running. The reliable signal is the other way round: where small channels
    # are DYING, stay away. So a clean graveyard reading with the right length is its own verdict.
    graveyard = len(small_new) >= 3 and death >= 0.7
    clean = len(small_new) >= 3 and death <= 0.4
    if reachable and not graveyard and not length_off:
        verdict = "good"                      # someone reachable actually won with it, recently
    elif graveyard:
        verdict = "avoid"
    elif length_off:
        verdict = "wrong-length"
    elif clean:
        verdict = "clear"                     # nothing here says this kills small channels
    elif reachable:
        verdict = "risky"
    else:
        verdict = "weak"
    return {"verdict": verdict, "why": " ".join(why), "checked": len(rows), "found": found,
            "source": ",".join(sorted(sources)),
            "outliers": sorted(reachable, key=lambda r: -r["ratio"])[:5],
            "small_tried": len(small_new) if len(small_new) >= 3 else len(small),
            "small_sank": len(sank_new) if len(small_new) >= 3 else len(sank),
            "stale_wins": len(stale_wins),
            "winner_minutes": med, "our_minutes": our_minutes,
            "rows": sorted(rows, key=lambda r: -r["views"])[:12]}


# ---------------------------------------------------------------- playlists
def _api_json(cfg, path, body=None, method="GET", api_key=None):
    """A key reads PUBLIC data with no sign-in; the signed-in account is only needed for the channel."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    if api_key:
        path += ("&" if "?" in path else "?") + "key=" + urllib.parse.quote(api_key)
        headers = {}
    else:
        headers = {"Authorization": "Bearer " + access_token(cfg)}
    if data:
        headers["Content-Type"] = "application/json; charset=UTF-8"
    req = urllib.request.Request(API_URL + path, data=data, method=method, headers=headers)
    try:
        with _open(req, timeout=60) as r:
            raw = r.read().decode("utf-8")
        return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        # A search costs 100 of the 10,000 units a day, so a long run of topic checks can spend the
        # lot. Saying that plainly beats printing Google's JSON at someone.
        if e.code in (403, 429) and ("quota" in detail.lower() or e.code == 429):
            raise QuotaSpent("YouTube's daily search allowance is used up. It resets at midnight "
                             "Pacific time (about 10:00 in Turkey). Topic checks will work again then; "
                             "everything else - uploading, thumbnails, playlists - is unaffected.")
        raise YouTubeError("YouTube refused that (%s): %s" % (e.code, detail[:300]))


def playlists(cfg):
    """Every playlist on the signed-in channel, newest first. Paged - a channel can have hundreds."""
    out, page = [], ""
    for _ in range(20):                                  # 20 x 50 = 1000, far past any real channel
        q = "/playlists?part=snippet,status,contentDetails&mine=true&maxResults=50"
        if page:
            q += "&pageToken=" + urllib.parse.quote(page)
        d = _api_json(cfg, q)
        for it in d.get("items") or []:
            sn = it.get("snippet") or {}
            out.append({"id": it.get("id"), "title": sn.get("title") or "(untitled)",
                        "count": (it.get("contentDetails") or {}).get("itemCount", 0),
                        "privacy": (it.get("status") or {}).get("privacyStatus") or ""})
        page = d.get("nextPageToken") or ""
        if not page:
            break
    return out


def create_playlist(cfg, title, description="", privacy="public"):
    d = _api_json(cfg, "/playlists?part=snippet,status", method="POST", body={
        "snippet": {"title": title[:150], "description": description[:5000]},
        "status": {"privacyStatus": privacy}})
    return d.get("id") or ""


def add_to_playlist(cfg, playlist_id, video_id):
    """Put a video in a playlist. Adding one that is already there just makes a second entry, so the
    caller checks first."""
    _api_json(cfg, "/playlistItems?part=snippet", method="POST", body={
        "snippet": {"playlistId": playlist_id,
                    "resourceId": {"kind": "youtube#video", "videoId": video_id}}})
    return True


def playlist_has(cfg, playlist_id, video_id):
    page = ""
    for _ in range(20):
        q = ("/playlistItems?part=contentDetails&maxResults=50&playlistId="
             + urllib.parse.quote(playlist_id))
        if page:
            q += "&pageToken=" + urllib.parse.quote(page)
        try:
            d = _api_json(cfg, q)
        except YouTubeError:
            return False
        for it in d.get("items") or []:
            if ((it.get("contentDetails") or {}).get("videoId")) == video_id:
                return True
        page = d.get("nextPageToken") or ""
        if not page:
            break
    return False


def set_thumbnail(cfg, video_id, image_path):
    at = access_token(cfg)
    data = Path(image_path).read_bytes()
    ext = Path(image_path).suffix.lower()
    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else "image/png"
    req = urllib.request.Request(
        THUMB_URL + "?videoId=" + urllib.parse.quote(video_id), data=data, method="POST",
        headers={"Authorization": "Bearer " + at, "Content-Type": mime,
                 "Content-Length": str(len(data))})
    try:
        with _open(req, timeout=300) as r:
            r.read()
        return True
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        # YouTube refuses custom thumbnails on a channel that has not been phone-verified. Nothing in
        # the app can fix that, so say what to do instead of printing Google's JSON at the user.
        if e.code == 403 and "custom video thumbnail" in detail:
            raise YouTubeError("The video is up, but YouTube will not take a custom thumbnail until the "
                               "channel is verified. Open youtube.com/verify, verify with your phone, "
                               "then set the thumbnail (it takes a moment to become available).")
        raise YouTubeError("The video went up but the thumbnail did not (%s): %s"
                           % (e.code, detail[:300]))
