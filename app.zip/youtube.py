"""Signing in to YouTube and putting an episode on it.

Google's own client library is not used - it drags in a large dependency tree for what is, in the end,
three HTTPS calls. This does the installed-app OAuth flow by hand:

  * a loopback redirect (http://127.0.0.1:<free port>), which is what Google wants for a Desktop client
    and which means the user never has to register a redirect URL,
  * PKCE, so the authorisation code is useless to anything that intercepts it,
  * a refresh token kept in the app config, so signing in happens once.

The upload is RESUMABLE, because an episode is tens of megabytes and a plain POST that dies at 90% has
to start over. A scheduled episode goes up PRIVATE with publishAt set - that is the only way YouTube
accepts a future publish time.
"""
import base64
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
UPLOAD_URL = "https://www.googleapis.com/upload/youtube/v3/videos"
THUMB_URL = "https://www.googleapis.com/upload/youtube/v3/thumbnails/set"
API_URL = "https://www.googleapis.com/youtube/v3"
# youtube.upload puts the video up; youtube covers the thumbnail and reading the channel's own name.
SCOPES = "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube"
CHUNK = 4 << 20


class YouTubeError(RuntimeError):
    pass


def _post_form(url, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise YouTubeError("Google refused the request (%s): %s"
                           % (e.code, e.read().decode("utf-8", "replace")[:400]))


# ---------------------------------------------------------------- sign in
class _Catcher(BaseHTTPRequestHandler):
    result = {}

    def do_GET(self):                       # noqa: N802
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        _Catcher.result = {k: v[0] for k, v in q.items()}
        ok = "code" in _Catcher.result
        msg = ("Signed in. You can close this tab and go back to the app."
               if ok else "Sign-in was refused or cancelled. Close this tab and try again.")
        page = ("<html><head><meta charset=utf-8><title>AI Dashboard</title></head>"
                "<body style=\"font:16px system-ui;background:#0b0e0c;color:#e6ede8;display:flex;"
                "align-items:center;justify-content:center;height:100vh\"><div>"
                + msg + "</div></body></html>").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def log_message(self, *a):              # keep the console quiet
        pass


def build_auth(client_id, redirect, challenge, state):
    return AUTH_URL + "?" + urllib.parse.urlencode({
        "client_id": client_id, "redirect_uri": redirect, "response_type": "code",
        "scope": SCOPES, "access_type": "offline", "prompt": "consent",
        "code_challenge": challenge, "code_challenge_method": "S256", "state": state,
    })


def start_sign_in(client_id, client_secret, on_done, timeout=300, open_browser=True):
    """Open Google's consent page and wait for the redirect. Calls on_done(tokens, error)."""
    if not (client_id and client_secret):
        on_done(None, "Add the Google client ID and secret in Settings first.")
        return None
    # Bind the listener HERE, not in the thread. Picking a free port and rebinding it a moment later
    # can lose the race to anything else on the machine, and by then the caller has already returned.
    try:
        srv = HTTPServer(("127.0.0.1", 0), _Catcher)
    except OSError as e:
        on_done(None, "Could not listen for Google's reply: %s" % e)
        return None
    port = srv.server_address[1]
    redirect = "http://127.0.0.1:%d/" % port
    verifier = base64.urlsafe_b64encode(os.urandom(48)).decode().rstrip("=")
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    state = secrets.token_urlsafe(16)
    url = build_auth(client_id, redirect, challenge, state)

    def run():
        srv.timeout = timeout
        _Catcher.result = {}
        srv.handle_request()                       # exactly one request: the redirect
        srv.server_close()
        got = dict(_Catcher.result)
        if not got:
            on_done(None, "Sign-in timed out - the browser never came back.")
            return
        if got.get("state") != state:
            on_done(None, "The sign-in came back with the wrong state, so nothing was saved.")
            return
        if not got.get("code"):
            on_done(None, got.get("error") or "Sign-in was cancelled.")
            return
        try:
            tok = _post_form(TOKEN_URL, {
                "code": got["code"], "client_id": client_id, "client_secret": client_secret,
                "redirect_uri": redirect, "grant_type": "authorization_code",
                "code_verifier": verifier})
        except YouTubeError as e:
            on_done(None, str(e))
            return
        if not tok.get("refresh_token"):
            on_done(None, "Google did not send a refresh token. Remove this app under your Google "
                          "account's third-party access, then sign in again.")
            return
        tok["expires_at"] = time.time() + float(tok.get("expires_in") or 3500)
        on_done(tok, None)

    threading.Thread(target=run, daemon=True).start()
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    return url


def access_token(cfg):
    """A live access token, refreshed if the stored one has expired. Raises if not signed in."""
    tok = cfg.get("youtube_token") or {}
    if not tok.get("refresh_token"):
        raise YouTubeError("Not signed in to YouTube yet.")
    if tok.get("access_token") and float(tok.get("expires_at") or 0) > time.time() + 60:
        return tok["access_token"]
    fresh = _post_form(TOKEN_URL, {
        "client_id": cfg.get("youtube_client_id") or "",
        "client_secret": cfg.get("youtube_client_secret") or "",
        "refresh_token": tok["refresh_token"], "grant_type": "refresh_token"})
    tok["access_token"] = fresh.get("access_token")
    tok["expires_at"] = time.time() + float(fresh.get("expires_in") or 3500)
    cfg["youtube_token"] = tok
    return tok["access_token"]


def channel_name(cfg):
    at = access_token(cfg)
    req = urllib.request.Request(API_URL + "/channels?part=snippet&mine=true",
                                 headers={"Authorization": "Bearer " + at})
    with urllib.request.urlopen(req, timeout=45) as r:
        d = json.loads(r.read().decode("utf-8"))
    items = d.get("items") or []
    return (items[0]["snippet"]["title"] if items else "") or ""


# ---------------------------------------------------------------- upload
def upload(cfg, video_path, snippet, status, on_progress=None):
    """Resumable upload. Returns the new video id."""
    at = access_token(cfg)
    body = json.dumps({"snippet": snippet, "status": status}).encode("utf-8")
    size = Path(video_path).stat().st_size
    req = urllib.request.Request(
        UPLOAD_URL + "?uploadType=resumable&part=snippet,status", data=body, method="POST",
        headers={"Authorization": "Bearer " + at,
                 "Content-Type": "application/json; charset=UTF-8",
                 "X-Upload-Content-Length": str(size), "X-Upload-Content-Type": "video/*"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            session = r.headers.get("Location")
    except urllib.error.HTTPError as e:
        raise YouTubeError("YouTube would not start the upload (%s): %s"
                           % (e.code, e.read().decode("utf-8", "replace")[:400]))
    if not session:
        raise YouTubeError("YouTube did not give us an upload session.")
    sent = 0
    with open(video_path, "rb") as f:
        while sent < size:
            chunk = f.read(CHUNK)
            if not chunk:
                break
            end = sent + len(chunk) - 1
            put = urllib.request.Request(
                session, data=chunk, method="PUT",
                headers={"Content-Length": str(len(chunk)),
                         "Content-Range": "bytes %d-%d/%d" % (sent, end, size)})
            try:
                with urllib.request.urlopen(put, timeout=900) as r:
                    return (json.loads(r.read().decode("utf-8")) or {}).get("id") or ""
            except urllib.error.HTTPError as e:
                if e.code == 308:                       # "keep going" - the normal per-chunk reply
                    sent = end + 1
                    if on_progress:
                        on_progress(int(sent * 100 / max(1, size)))
                    continue
                raise YouTubeError("The upload failed at %d%% (%s): %s"
                                   % (int(sent * 100 / max(1, size)), e.code,
                                      e.read().decode("utf-8", "replace")[:300]))
    raise YouTubeError("The upload ended without YouTube confirming the video.")


def set_thumbnail(cfg, video_id, image_path):
    at = access_token(cfg)
    data = Path(image_path).read_bytes()
    ext = Path(image_path).suffix.lower()
    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else "image/png"
    req = urllib.request.Request(
        THUMB_URL + "?videoId=" + urllib.parse.quote(video_id), data=data, method="POST",
        headers={"Authorization": "Bearer " + at, "Content-Type": mime,
                 "Content-Length": str(len(data))})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            r.read()
        return True
    except urllib.error.HTTPError as e:
        raise YouTubeError("The video went up but the thumbnail did not (%s): %s"
                           % (e.code, e.read().decode("utf-8", "replace")[:300]))
