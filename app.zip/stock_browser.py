"""A separate stock-only browser process. No Dashboard API, cookies or account passwords exposed."""
import os
import re
from pathlib import Path
import sys
import threading
import time
from urllib.parse import urlparse

from stock_media import IMAGE_EXT, VIDEO_EXT, MAX_FILE, identifier, item_url, same_envato_item, read_json, write_json


def clean_page(url):
    try:
        p=urlparse(str(url))
        if p.scheme=='https' and not p.username and not p.password and p.port in (None,443):
            return 'https://'+(p.hostname or '').lower()+p.path.rstrip('/')
    except ValueError:pass
    return ''


def envato_app_identity(url):
    # Envato opens the same item either directly or inside its search overlay.
    # The UUID and media kind identify it; the optional search prefix does not.
    match=re.fullmatch(r'https://app\.envato\.com/(?:search/)?(stock-video|photos)/'
                       r'([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})',
                       clean_page(url),re.IGNORECASE)
    return (match[1].lower(),match[2].lower()) if match else None


def envato_app_item(url):
    return envato_app_identity(url) is not None


def envato_download_host(url):
    page=clean_page(url)
    return bool(page and (urlparse(page).hostname or '').endswith('.elements.envatousercontent.com'))


class DownloadOrigin:
    """Bind only the selected catalog item and its observed download navigation.

    Signed file URLs live only in memory. A download host alone is not identity
    evidence, and changing the selected command creates an entirely new binding.
    """
    def __init__(self, command):
        self.command=dict(command);self.alias='';self.navigation_id=None
        self.download_urls=set();self.download_navigation_id=None;self.navigation_trace=[]

    def matches(self,url):
        if self.command.get('provider')!='envato':return bool(item_url(self.command.get('provider'),url))
        return same_envato_item(url,self.command['url']) or bool(self.alias and
            envato_app_identity(url) is not None and envato_app_identity(url)==envato_app_identity(self.alias))

    def allows_download(self,url,source,navigation_id=None,redirected=False):
        if self.command.get('provider')!='envato' or not envato_download_host(url):return False
        return self.matches(source) or bool(redirected and navigation_id is not None
            and navigation_id==self.download_navigation_id and self.download_urls)

    def navigate(self,url,source,navigation_id,redirected=False,user_initiated=True):
        if self.command.get('provider')!='envato':return
        page=clean_page(url)
        # A small failure-only trace: no signed URLs, queries, login paths or cookies.
        self.navigation_trace.append(dict(page=page if item_url('envato',url) or envato_app_item(url)
            else (urlparse(page).hostname or ''),source_matches=self.matches(source),
            navigation_id=str(navigation_id),redirected=bool(redirected),user_initiated=bool(user_initiated)))
        self.navigation_trace=self.navigation_trace[-8:]
        if envato_download_host(url):
            if self.allows_download(url,source,navigation_id,redirected):
                self.download_urls.add(str(url));self.download_navigation_id=navigation_id
            return
        self.download_urls.clear();self.download_navigation_id=None
        if self.matches(url):
            self.navigation_id=navigation_id
        elif not self.alias and envato_app_item(url) and (
                (redirected and self.navigation_id is not None and navigation_id==self.navigation_id)
                or (not user_initiated and same_envato_item(source,self.command['url']))):
            self.alias=clean_page(url)
        elif not redirected or item_url('envato',url):
            self.navigation_id=None

    def receipt_source(self,url,download_url=''):
        if self.matches(url):return self.command['url']
        if (self.command.get('provider')=='envato' and str(download_url) in self.download_urls
                and str(url) in self.download_urls):return self.command['url']
        return None

    def diagnostic(self,page,download):
        # Never persist signed queries, cookies, account pages or credentials.
        return dict(selected=clean_page(self.command.get('url')),observed=clean_page(page),
                    alias=self.alias,download_host=urlparse(clean_page(download)).hostname or '',
                    observed_download_navigation=bool(self.download_urls),navigation=list(self.navigation_trace))


def navigation_allowed(url):
    if url == "about:blank":
        return True
    try:
        value = urlparse(str(url)); host = (value.hostname or "").lower()
        allowed = ("storyblocks.com", "envato.com", "envato.market", "google.com", "microsoftonline.com", "apple.com")
        return value.scheme == "https" and not value.username and not value.password and value.port in (None, 443) and any(host == h or host.endswith("." + h) for h in allowed)
    except ValueError:
        return False


class DownloadLifetime:
    """Closing the provider window hides it until its accepted downloads finish."""
    def __init__(self):
        self.active = set()
        self.hidden = False
        self.lock = threading.RLock()

    def started(self, token):
        with self.lock:
            self.active.add(token)

    def finished(self, token):
        with self.lock:
            self.active.discard(token)

    def closing(self, window):
        with self.lock:
            if not self.active:
                return True
            self.hidden = True
        window.hide()
        return False

    def shown(self):
        with self.lock:
            self.hidden = False

    def may_exit(self):
        with self.lock:
            return self.hidden and not self.active


def main(profile):
    import webview

    profile = Path(profile).resolve()
    command = read_json(profile / "command.json")
    if not command or not item_url(command.get("provider"), command.get("url")):
        return 2
    provider = command["provider"]
    write_json(profile / "status.json", {**read_json(profile / "status.json", {}), "state": "starting", "pid": os.getpid()})
    current = {"selection": (command, DownloadOrigin(command)), "ready": False}
    stop = threading.Event()
    operations = []  # keep .NET event delegates alive for the duration of each operation
    lifetime = DownloadLifetime()
    webview.settings["ALLOW_FILE_URLS"] = False
    webview.settings["ALLOW_DOWNLOADS"] = False  # our handler below admits media only
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
    window = webview.create_window(f'{provider.title()} · Stock Browser', html="<html><body style='background:#0a130d;color:#e6ede8;font:16px Segoe UI;padding:28px'>Opening stock browser…</body></html>",
                                   width=1120, height=800, min_size=(720, 520), js_api=None)

    def progress(target, **values):
        write_json(target / "progress.json", values)

    def on_download(sender, args):
        selected, origin = current["selection"]
        cmd = dict(selected)
        target = Path(cmd["target"])
        expected = profile.parent.parent / "inbox" / cmd["id"]
        if target.resolve() != expected.resolve():
            args.Cancel = True
            return
        name = Path(str(args.ResultFilePath)).name
        suffix = Path(name).suffix.lower()
        if suffix not in VIDEO_EXT | IMAGE_EXT | {".zip"}:
            args.Cancel = True
            progress(target, state="error", message="Choose a video, image or ZIP download.")
            return
        op = args.DownloadOperation
        download_url = str(getattr(op, 'Uri', '') or '')
        source_url = origin.receipt_source(str(sender.Source), download_url)
        if not source_url:
            args.Cancel = True
            progress(target, state="error", message="This download could not be matched to the selected clip. Use the clip again.",
                     origin=origin.diagnostic(str(sender.Source),download_url))
            return
        filename = identifier() + suffix
        dest = target / filename
        args.ResultFilePath = str(dest)
        args.Handled = True
        if int(op.TotalBytesToReceive or 0) > MAX_FILE:
            args.Cancel = True
            progress(target, state="error", message="Choose a media download smaller than 2 GB.")
            return
        progress(target, state="downloading", message=f"Downloading {name}…", received=0, total=max(0,int(op.TotalBytesToReceive or 0)))
        lifetime.started(filename)

        last_progress={"percent":-1,"time":0}
        def received(_sender, _args):
            if int(op.BytesReceived) > MAX_FILE:
                op.Cancel()
                progress(target, state="error", message="Choose a media download smaller than 2 GB.")
                return
            total=int(op.TotalBytesToReceive or 0)
            percent=min(100,int(100*int(op.BytesReceived)/total)) if total>0 else None
            if percent!=last_progress['percent'] or time.monotonic()-last_progress['time']>=.5:
                last_progress.update(percent=percent,time=time.monotonic())
                progress(target,state='downloading',message='Downloading Stock…',percent=percent,received=int(op.BytesReceived),total=max(0,total))
                window.set_title(f'{provider.title()} · Downloading '+(str(percent)+'%' if percent is not None else f'{int(op.BytesReceived)/1048576:.1f} MB'))

        def state_changed(_sender, _args):
            state = str(op.State)
            if state == "Completed":
                write_json(target / (filename + ".receipt.json"), {"file": filename, "name": name, "source_url": source_url, "completed": time.time()})
                progress(target, state="done", message="Download Complete. Preparing Your Clip…",percent=100)
                window.set_title(f'{provider.title()} · Download Complete')
                status = read_json(profile / "status.json", {})
                status.update(last_download=time.time()); write_json(profile / "status.json", status)
                lifetime.finished(filename)
            elif state == "Interrupted":
                # WebView may retain resumable partial data. Never publish a receipt for it.
                progress(target, state="error", message="Download interrupted. Retry on the stock website.")
                lifetime.finished(filename)
        op.StateChanged += state_changed
        op.BytesReceivedChanged += received
        operations.append((op, state_changed, received))
        received(None,None)
        state_changed(None,None)

    def navigate(sender, args):
        url=str(args.Uri); origin=current["selection"][1];source=str(sender.Source)
        nav_id=getattr(args,'NavigationId',None);redirected=bool(getattr(args,'IsRedirected',False))
        if not navigation_allowed(url) and not origin.allows_download(url,source,nav_id,redirected):
            args.Cancel = True
            return
        origin.navigate(url,source,nav_id,redirected,bool(getattr(args,'IsUserInitiated',True)))

    def popup(sender, args):
        args.Handled = True
        url = str(args.Uri);origin=current["selection"][1];source=str(sender.Source)
        if navigation_allowed(url) or origin.allows_download(url,source):
            origin.navigate(url,source,None,user_initiated=True)
            sender.Navigate(url)

    def setup():
        if current["ready"]:
            return
        try:
            from System import Action
            browser = window.native.browser
            control = browser.webview
            def attach():
                if current["ready"]:
                    return
                core = control.CoreWebView2
                if core is None:
                    return
                core.DownloadStarting -= browser.on_download_starting
                core.NewWindowRequested -= browser.on_new_window_request
                core.DownloadStarting += on_download
                core.NewWindowRequested += popup
                core.NavigationStarting += navigate
                core.Settings.AreHostObjectsAllowed = False
                core.Settings.IsWebMessageEnabled = False
                core.Settings.AreDevToolsEnabled = False
                core.Settings.IsPasswordAutosaveEnabled = False
                core.Settings.IsGeneralAutofillEnabled = False
                current["ready"] = True
                status = read_json(profile / "status.json", {})
                status.update(opened_at=time.time(), state="open", pid=os.getpid())
                write_json(profile / "status.json", status)
                core.Navigate(current["selection"][0]["url"])
            control.Invoke(Action(attach))
        except Exception as exc:
            write_json(profile / "status.json", {"state": "error", "message": "Stock browser could not start. Open the stock website in your browser and import the downloaded file.", "detail": type(exc).__name__})

    def watch():
        last = command["id"]
        while not stop.wait(0.5):
            if not current["ready"]:
                setup()
            cmd = read_json(profile / "command.json", {})
            if cmd.get("action") == "close" and cmd.get("provider") == provider:
                window.destroy()
                # Closing is deferred while WebView2 is receiving a file.
                if stop.is_set(): return
                continue
            if current["ready"] and cmd.get("id") != last and cmd.get("provider") == provider and item_url(provider, cmd.get("url")):
                last = cmd["id"]; current["selection"] = (cmd, DownloadOrigin(cmd))
                lifetime.shown()
                window.load_url(cmd["url"]); window.show(); window.restore()
            elif lifetime.may_exit():
                window.destroy()
                return
    window.events.loaded += setup
    window.events.closing += lambda: lifetime.closing(window)
    window.events.closed += lambda: stop.set()
    def boot():
        threading.Thread(target=watch, daemon=True).start()
    try:
        webview.start(boot, gui="edgechromium", private_mode=False, storage_path=str(profile / "session"))
    finally:
        stop.set()
        status = read_json(profile / "status.json", {}); status["state"] = "closed"; write_json(profile / "status.json", status)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
