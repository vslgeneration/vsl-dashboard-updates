"""A separate stock-only browser process. No Dashboard API, cookies or account passwords exposed."""
import os
import re
from pathlib import Path
import sys
import threading
import time
from urllib.parse import urlparse

from stock_media import IMAGE_EXT, VIDEO_EXT, MAX_FILE, identifier, item_url, same_envato_item, read_json, write_json


def clean_page(url):
    try:
        p=urlparse(str(url))
        if p.scheme=='https' and not p.username and not p.password and p.port in (None,443):
            return 'https://'+(p.hostname or '').lower()+p.path.rstrip('/')
    except ValueError:pass
    return ''


def envato_app_item(url):
    return bool(re.fullmatch(r'https://app\.envato\.com/(?:stock-video|photos)/[a-f0-9-]{36}',clean_page(url)))


def envato_download_host(url):
    page=clean_page(url)
    return bool(page and (urlparse(page).hostname or '').endswith('.elements.envatousercontent.com'))


class DownloadOrigin:
    """Bind a new Envato item URL to the selected legacy item via its observed redirect.

    A different clicked item, a login page, or a stale alias must never be stamped
    with the selected item's identity simply because it belongs to Envato.
    """
    def __init__(self, command):
        self.command=dict(command);self.alias='';self.navigation_id=None

    def matches(self,url):
        if self.command.get('provider')!='envato':return bool(item_url(self.command.get('provider'),url))
        return same_envato_item(url,self.command['url']) or bool(self.alias and clean_page(url)==self.alias)

    def navigate(self,url,source,navigation_id,redirected=False,user_initiated=True):
        if self.command.get('provider')!='envato':return
        if same_envato_item(url,self.command['url']):
            self.navigation_id=navigation_id
        elif not self.alias and envato_app_item(url) and (
                (redirected and self.navigation_id is not None and navigation_id==self.navigation_id)
                or (not user_initiated and same_envato_item(source,self.command['url']))):
            self.alias=clean_page(url)
        elif not redirected:
            self.navigation_id=None

    def receipt_source(self,url):
        return self.command['url'] if self.matches(url) else None


def navigation_allowed(url):
    if url == "about:blank":
        return True
    try:
        value = urlparse(str(url)); host = (value.hostname or "").lower()
        allowed = ("storyblocks.com", "envato.com", "envato.market", "google.com", "microsoftonline.com", "apple.com")
        return value.scheme == "https" and not value.username and not value.password and value.port in (None, 443) and any(host == h or host.endswith("." + h) for h in allowed)
    except ValueError:
        return False


def main(profile):
    import webview

    profile = Path(profile).resolve()
    command = read_json(profile / "command.json")
    if not command or not item_url(command.get("provider"), command.get("url")):
        return 2
    provider = command["provider"]
    write_json(profile / "status.json", {**read_json(profile / "status.json", {}), "state": "starting", "pid": os.getpid()})
    current = {"command": command, "ready": False, "origin": DownloadOrigin(command)}
    stop = threading.Event()
    operations = []  # keep .NET event delegates alive for the duration of each operation
    webview.settings["ALLOW_FILE_URLS"] = False
    webview.settings["ALLOW_DOWNLOADS"] = False  # our handler below admits media only
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
    window = webview.create_window(f'{provider.title()} · Stock Browser', html="<html><body style='background:#0a130d;color:#e6ede8;font:16px Segoe UI;padding:28px'>Opening stock browser…</body></html>",
                                   width=1120, height=800, min_size=(720, 520), js_api=None)

    def progress(target, **values):
        write_json(target / "progress.json", values)

    def on_download(sender, args):
        cmd = dict(current["command"])
        target = Path(cmd["target"])
        expected = profile.parent.parent / "inbox" / cmd["id"]
        if target.resolve() != expected.resolve():
            args.Cancel = True
            return
        name = Path(str(args.ResultFilePath)).name
        suffix = Path(name).suffix.lower()
        if suffix not in VIDEO_EXT | IMAGE_EXT | {".zip"}:
            args.Cancel = True
            progress(target, state="error", message="Choose a video, image or ZIP download.")
            return
        source_url = current['origin'].receipt_source(str(sender.Source))
        if not source_url:
            args.Cancel = True
            progress(target, state="error", message="The download could not be linked to the selected clip. Close this browser and use the clip again.")
            return
        filename = identifier() + suffix
        dest = target / filename
        args.ResultFilePath = str(dest)
        args.Handled = True
        op = args.DownloadOperation
        if int(op.TotalBytesToReceive or 0) > MAX_FILE:
            args.Cancel = True
            progress(target, state="error", message="Choose a media download smaller than 2 GB.")
            return
        progress(target, state="downloading", message=f"Downloading {name}…", received=0, total=max(0,int(op.TotalBytesToReceive or 0)))

        last_progress={"percent":-1,"time":0}
        def received(_sender, _args):
            if int(op.BytesReceived) > MAX_FILE:
                op.Cancel()
                progress(target, state="error", message="Choose a media download smaller than 2 GB.")
                return
            total=int(op.TotalBytesToReceive or 0)
            percent=min(100,int(100*int(op.BytesReceived)/total)) if total>0 else None
            if percent!=last_progress['percent'] or time.monotonic()-last_progress['time']>=.5:
                last_progress.update(percent=percent,time=time.monotonic())
                progress(target,state='downloading',message='Downloading Stock…',percent=percent,received=int(op.BytesReceived),total=max(0,total))
                window.set_title(f'{provider.title()} · Downloading '+(str(percent)+'%' if percent is not None else f'{int(op.BytesReceived)/1048576:.1f} MB'))

        def state_changed(_sender, _args):
            state = str(op.State)
            if state == "Completed":
                write_json(target / (filename + ".receipt.json"), {"file": filename, "name": name, "source_url": source_url, "completed": time.time()})
                progress(target, state="done", message="Download Complete. Preparing Your Clip…",percent=100)
                window.set_title(f'{provider.title()} · Download Complete')
                status = read_json(profile / "status.json", {})
                status.update(last_download=time.time()); write_json(profile / "status.json", status)
            elif state == "Interrupted":
                # WebView may retain resumable partial data. Never publish a receipt for it.
                progress(target, state="error", message="Download interrupted. Retry on the stock website.")
        op.StateChanged += state_changed
        op.BytesReceivedChanged += received
        operations.append((op, state_changed, received))
        received(None,None)
        state_changed(None,None)

    def navigate(sender, args):
        url=str(args.Uri)
        if not navigation_allowed(url) and not (provider=='envato' and current['origin'].matches(str(sender.Source)) and envato_download_host(url)):
            args.Cancel = True
            return
        current['origin'].navigate(url,str(sender.Source),getattr(args,'NavigationId',None),
            bool(getattr(args,'IsRedirected',False)),bool(getattr(args,'IsUserInitiated',True)))

    def popup(sender, args):
        args.Handled = True
        url = str(args.Uri)
        if navigation_allowed(url) or (provider=='envato' and current['origin'].matches(str(sender.Source)) and envato_download_host(url)):
            sender.Navigate(url)

    def setup():
        if current["ready"]:
            return
        try:
            from System import Action
            browser = window.native.browser
            control = browser.webview
            def attach():
                if current["ready"]:
                    return
                core = control.CoreWebView2
                if core is None:
                    return
                core.DownloadStarting -= browser.on_download_starting
                core.NewWindowRequested -= browser.on_new_window_request
                core.DownloadStarting += on_download
                core.NewWindowRequested += popup
                core.NavigationStarting += navigate
                core.Settings.AreHostObjectsAllowed = False
                core.Settings.IsWebMessageEnabled = False
                core.Settings.AreDevToolsEnabled = False
                core.Settings.IsPasswordAutosaveEnabled = False
                core.Settings.IsGeneralAutofillEnabled = False
                current["ready"] = True
                status = read_json(profile / "status.json", {})
                status.update(opened_at=time.time(), state="open", pid=os.getpid())
                write_json(profile / "status.json", status)
                core.Navigate(current["command"]["url"])
            control.Invoke(Action(attach))
        except Exception as exc:
            write_json(profile / "status.json", {"state": "error", "message": "Stock browser could not start. Open the stock website in your browser and import the downloaded file.", "detail": type(exc).__name__})

    def watch():
        last = command["id"]
        while not stop.wait(0.5):
            if not current["ready"]:
                setup()
            cmd = read_json(profile / "command.json", {})
            if cmd.get("action") == "close" and cmd.get("provider") == provider:
                window.destroy()
                return
            if current["ready"] and cmd.get("id") != last and cmd.get("provider") == provider and item_url(provider, cmd.get("url")):
                last = cmd["id"]; current["command"] = cmd; current['origin']=DownloadOrigin(cmd)
                window.load_url(cmd["url"]); window.show(); window.restore()
    window.events.loaded += setup
    window.events.closed += lambda: stop.set()
    def boot():
        threading.Thread(target=watch, daemon=True).start()
    try:
        webview.start(boot, gui="edgechromium", private_mode=False, storage_path=str(profile / "session"))
    finally:
        stop.set()
        status = read_json(profile / "status.json", {}); status["state"] = "closed"; write_json(profile / "status.json", status)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
