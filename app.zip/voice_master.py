"""Immutable, cached narration master: fixed gain followed by one hard limiter.

No loudness target, gain envelope or timeline edits. Resample once to the delivery
clock, compensate limiter lookahead, and verify every decoded sample survived.
"""
from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
import math
import os
import re
import subprocess
import tempfile
import threading
import time

VERSION = 'voice-master-1005-2'
GAIN_DB = 18.0
CEILING_DB = -6.0
INTERNAL_CEILING_DB = -6.05
SAMPLE_RATE = 48000
CONFIG = dict(version=VERSION, sample_rate=SAMPLE_RATE, codec='pcm_s24le',
              gain_db=GAIN_DB, ceiling_db=CEILING_DB, attack_ms=7, release_ms=100,
              internal_rate=192000, internal_ceiling_db=INTERNAL_CEILING_DB,
              auto_level=False, latency_compensation=True)
_FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
_LOCK = threading.RLock()
_PREFIX = 'voice-master-'
_VERIFIED = {}


class VoiceMasterError(RuntimeError):
    """Delivery must stop rather than substitute raw or partly processed narration."""


def _hash(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def _stat(path):
    stat = Path(path).stat()
    return dict(size=stat.st_size, mtime_ns=stat.st_mtime_ns)


def _verification_stat(path):
    stat = Path(path).stat()
    return stat.st_size, stat.st_mtime_ns, getattr(stat, 'st_ctime_ns', 0)


def _identity(path):
    path = Path(path).resolve()
    return dict(path=str(path), **_stat(path))


def _key(identity):
    return hashlib.sha256(json.dumps([identity, CONFIG], sort_keys=True).encode('utf8')).hexdigest()[:32]


def _sidecar(path):
    return Path(path).with_suffix('.voice-master.json')


def _declared(path):
    path = Path(path)
    return bool(re.fullmatch(r'voice-master-[0-9a-f]{32}\.wav', path.name)) or _sidecar(path).exists()


def _record(path):
    """Verify both asset hashes, rather than trusting a filename or a marker alone."""
    path = Path(path).resolve()
    record = json.loads(_sidecar(path).read_text('utf8'))
    if not isinstance(record, dict) or record.get('schema') != 1 or record.get('config') != CONFIG:
        raise ValueError('Narration master settings are stale or invalid.')
    source = record['source']; original = Path(source['path']).resolve()
    identity = _identity(original)
    if original == path or identity != {k: source[k] for k in ('path', 'size', 'mtime_ns')}:
        raise ValueError('The original narration changed after mastering.')
    if path.name != _PREFIX + _key(identity) + '.wav':
        raise ValueError('Narration master identity is invalid.')
    memo = (str(path), _verification_stat(path), str(original), _verification_stat(original),
            _verification_stat(_sidecar(path)), json.dumps(CONFIG, sort_keys=True), json.dumps(record, sort_keys=True))
    # Full hashes are checked once per process and again after any source,
    # output or sidecar stat change. Preview requests must not reread a 500MB
    # PCM master several times merely to recognize the same verified asset.
    if memo in _VERIFIED:
        return record
    if _stat(path) != record['output']['stat'] or _hash(path) != record['output']['sha256']:
        raise ValueError('Narration master data changed or is incomplete.')
    if _hash(original) != source['sha256']:
        raise ValueError('The original narration changed after mastering.')
    output = record['output']
    if (output['sample_rate'] != SAMPLE_RATE or output['codec'] != 'pcm_s24le'
            or output['samples'] != record['decoded_samples'] or output['samples'] <= 0
            or output['channels'] < 1 or output['first_pts'] != 0
            or output['peak_db'] is not None and output['peak_db'] > CEILING_DB + .00001):
        raise ValueError('Narration master verification metadata is invalid.')
    if len(_VERIFIED) >= 128:
        _VERIFIED.clear()
    _VERIFIED[memo] = True
    return record


def is_prepared(path):
    """True only for a complete verified current master, never for raw narration."""
    try:
        if not _declared(path):
            return False
        _record(path)
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def original(path):
    """Recover unprocessed source for a splice, so the completed mix is limited once."""
    path = Path(path).resolve()
    if not _declared(path):
        return path
    try:
        return Path(_record(path)['source']['path'])
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise VoiceMasterError('The prepared narration is incomplete or stale. Rebuild it from the original recording.') from error


def _probe(path):
    result = subprocess.run([
        'ffprobe', '-v', 'error', '-select_streams', 'a:0', '-read_intervals', '%+#1',
        '-show_entries', 'stream=codec_name,sample_rate,channels,duration,duration_ts,time_base:packet=pts_time',
        '-of', 'json', str(path)], capture_output=True, text=True, timeout=60, creationflags=_FLAGS)
    if result.returncode:
        raise ValueError('Narration audio metadata could not be read.')
    obj = json.loads(result.stdout)
    streams = obj.get('streams') or []
    if not streams or not streams[0].get('channels'):
        raise ValueError('The recording has no readable audio stream.')
    info = dict(streams[0])
    info['first_pts'] = float((obj.get('packets') or [{}])[0].get('pts_time') or 0)
    return info


@contextmanager
def _cache_guard(folder, key):
    """Serialize threads and processes; a crashed process releases its OS file lock."""
    with _LOCK:
        with (folder / ('.' + key + '.lock')).open('a+b') as stream:
            if stream.tell() == 0:
                stream.write(b'0'); stream.flush()
            deadline = time.monotonic() + 120
            while True:
                try:
                    stream.seek(0)
                    if os.name == 'nt':
                        import msvcrt
                        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic() > deadline:
                        raise RuntimeError('Another narration preparation is still running; try again when it finishes.')
                    time.sleep(.1)
            try:
                yield
            finally:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def _write_json(path, value):
    fd, name = tempfile.mkstemp(prefix='.voice-master-', suffix='.json.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as stream:
            json.dump(value, stream, sort_keys=True, allow_nan=False)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def _prepare(source, cache_root):
    """Return a verified PCM24/48k WAV; failures never silently return raw audio."""
    supplied = Path(source).resolve()
    source = original(supplied)
    if not source.is_file():
        raise FileNotFoundError('The original narration recording is missing.')
    # A valid master already meets the contract regardless of which cache the
    # caller would otherwise choose. Never reprocess its limited samples.
    if source != supplied:
        return supplied
    identity = _identity(source)
    folder = Path(cache_root).resolve(); folder.mkdir(parents=True, exist_ok=True)
    key = _key(identity); target = folder / (_PREFIX + key + '.wav')
    if target == source:
        raise ValueError('Narration output cannot overwrite its source.')
    with _cache_guard(folder, key):
        if is_prepared(target):
            return target
        before = _identity(source); source_hash = _hash(source)
        if before != identity:
            raise ValueError('The narration changed during preparation; retry with the current recording.')
        info = _probe(source); channels = int(info['channels'])
        ceiling = 10 ** (INTERNAL_CEILING_DB / 20)
        # astats only observes samples: input count and post-limiter peak are
        # checked in the same decode/filter pass without another gain stage.
        filters = (f'aresample={SAMPLE_RATE},asetpts=PTS-STARTPTS,'
                   'astats=measure_perchannel=none:measure_overall=Number_of_samples,'
                   'aresample=192000,'
                   f'volume={GAIN_DB:g}dB,alimiter=limit={ceiling:.16g}:attack=7:release=100:level=false:latency=true,'
                   f'aresample={SAMPLE_RATE},'
                   'astats=measure_perchannel=none:measure_overall=Peak_level')
        fd, name = tempfile.mkstemp(prefix='.voice-master-', suffix='.wav', dir=folder)
        os.close(fd); temp = Path(name)
        try:
            result = subprocess.run([
                'ffmpeg', '-hide_banner', '-nostdin', '-nostats', '-loglevel', 'info', '-y', '-threads', '2',
                '-i', str(source), '-map', '0:a:0', '-vn', '-sn', '-dn', '-map_metadata', '-1', '-map_chapters', '-1',
                '-af', filters, '-c:a', 'pcm_s24le', '-ar', str(SAMPLE_RATE), '-rf64', 'auto', str(temp)],
                capture_output=True, text=True, timeout=max(120, min(7200, float(info.get('duration') or 0) * 4 + 30)), creationflags=_FLAGS)
            if result.returncode:
                raise RuntimeError('Narration preparation failed: ' + result.stderr[-700:])
            counts = re.findall(r'Number of samples:\s*(\d+)', result.stderr)
            peaks = re.findall(r'Peak level dB:\s*(-?inf|[-+\d.eE]+)', result.stderr)
            if len(counts) != 1 or len(peaks) != 1:
                raise RuntimeError('Narration sample count or limiter peak could not be verified.')
            count = int(counts[0]); peak = float(peaks[0]); output = _probe(temp)
            if (count <= 0 or output.get('codec_name') != 'pcm_s24le'
                    or int(output.get('sample_rate') or 0) != SAMPLE_RATE
                    or int(output.get('channels') or 0) != channels
                    or output.get('time_base') != '1/48000'
                    or int(output.get('duration_ts') or 0) != count or output['first_pts'] != 0
                    or math.isnan(peak) or peak > CEILING_DB + .00001):
                raise RuntimeError('Prepared narration did not preserve its sample clock or limiter ceiling.')
            if _identity(source) != before or _hash(source) != source_hash:
                raise ValueError('The narration changed during preparation; the result was not published.')
            record = dict(schema=1, config=CONFIG, source=dict(before, sha256=source_hash), decoded_samples=count,
                          output=dict(codec='pcm_s24le', sample_rate=SAMPLE_RATE, channels=channels,
                                      samples=count, first_pts=0, peak_db=peak if math.isfinite(peak) else None,
                                      stat=_stat(temp), sha256=_hash(temp)))
            os.replace(temp, target)
            # Rename preserves the verified file bytes and stat; publish marker
            # last, so an interrupted/partial output can never count as prepared.
            record['output']['stat'] = _stat(target)
            _write_json(_sidecar(target), record)
            if not is_prepared(target):
                raise RuntimeError('Prepared narration integrity verification failed.')
            return target
        finally:
            temp.unlink(missing_ok=True)


def prepare(source, cache_root):
    """Prepare a narration master or raise VoiceMasterError; never return raw fallback."""
    try:
        return _prepare(source, cache_root)
    except VoiceMasterError:
        raise
    except Exception as error:
        raise VoiceMasterError(str(error) or 'Narration preparation failed.') from error
