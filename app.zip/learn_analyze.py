# -*- coding: utf-8 -*-
"""
Offline, READ-ONLY analysis of the passive learning log (learn_log.jsonl).

It changes NOTHING in the live system. Per approved scene it pairs the director's FIRST prompt (the baseline)
with the scene's prompt at the moment its picture was approved, says whether the two differ, and writes:
  - learn_dataset.jsonl : one record per approved scene {status, baseline_prompt, final_prompt, prompt_changed, ...}
  - learn_report.md     : a human-readable summary to review together

What the log can and cannot say is kept apart:
  - status "comparable"       : a known baseline and no note on the scene
  - status "baseline_unknown" : no baseline found - which is NOT evidence the prompt was written from scratch
  - status "review_needed"    : the scene carried a note (the user's, or the QA reviewer's) - kept for a person
                                to look at, never fed to automatic learning
  - a changed prompt is "prompt changed": the user, the QA fix, a translation or another step may have changed
    it, and the log does not say which. It is not an image rejection rate or a first-try failure rate.

Run:  python learn_analyze.py                 # build dataset + report from the default data dir
      python learn_analyze.py <path-to-log>   # explicit log file
      python learn_analyze.py --distill       # ALSO ask the LLM to PROPOSE generalised technique rules
                                              # (writes learn_proposal.md; NEVER edits DIRECTOR_SYSTEM)

Nothing here is wired into the app or any route — it is a manual tool we run when we decide to review the data.
Older log lines (no "schema") are read as they are: they never carry a note (the old app dropped noted scenes)
and never name the approved version.
"""
import os, sys, json, pathlib
from collections import defaultdict

ARGS = sys.argv[1:]
DISTILL = "--distill" in ARGS
paths = [a for a in ARGS if not a.startswith("--")]

DATA_DIR = pathlib.Path(os.environ.get("VSL_DATA_DIR") or ".").resolve()
LOG = pathlib.Path(paths[0]) if paths else (DATA_DIR / "learn" / "learn_log.jsonl")
OUT = LOG.parent

SETTINGS = ("style", "camera", "split", "product", "testimonial", "no_cast", "pure", "generic", "cast", "ingredients")


def load(log):
    if not log.exists():
        print(f"No log yet at {log} — nothing collected. (Use the app; data accumulates as you Re-run Director / approve.)")
        sys.exit(0)
    recs = []
    for line in log.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            recs.append(json.loads(line))
        except Exception:
            pass
    return recs


def key(r):
    return (r.get("project"), r.get("uid") or r.get("scene_id"))


def _ts(r):
    try:
        return float(r.get("ts") or 0)
    except (TypeError, ValueError):
        return 0.0


def _prompt(p):
    return p if isinstance(p, str) and p.strip() else None


def build(recs):
    """One entry per approved scene - its LAST approval - paired with the baseline it started from.

    The baseline is, in this order: the director_prompt carried INSIDE the approval record (the scene's own stored
    first prompt); else the nearest director record for the same project + scene at or BEFORE the approval - a
    director record written after it is never used; else unknown. Unknown is not "from scratch"."""
    director = defaultdict(list)                   # key -> [(ts, prompt)] of the director's (non-empty) prompts
    approved = {}
    for r in recs:
        k, ev = key(r), r.get("event")
        if ev == "director" and _prompt(r.get("prompt")):
            director[k].append((_ts(r), r["prompt"]))
        elif ev == "approved" and (k not in approved or _ts(r) >= _ts(approved[k])):
            approved[k] = r
    pairs = []
    for k, ap in approved.items():
        t = _ts(ap)
        base, basis = _prompt(ap.get("director_prompt")), None
        if base:
            basis = "approval_record"
        else:
            earlier = [x for x in director.get(k, []) if x[0] <= t]
            if earlier:
                base, basis = max(earlier, key=lambda x: x[0])[1], "earlier_director_record"
        final = ap.get("prompt") or ""
        note = bool(ap.get("note_present"))       # older records have no note fields: they never had a note
        status = "review_needed" if note else ("comparable" if base else "baseline_unknown")
        pairs.append({
            "project": ap.get("project"), "scene_id": ap.get("scene_id"), "uid": ap.get("uid"),
            "vo": ap.get("vo", ""), "status": status,
            "baseline_prompt": base, "baseline_basis": basis,            # None / None = unknown
            "director_prompt": base or "",                                # older name, kept for older readers
            "final_prompt": final,
            "final_prompt_basis": ap.get("prompt_basis") or "scene_prompt_at_approval",   # what the app has always logged
            "prompt_changed": (base.strip() != final.strip()) if base else None,
            "change_source": "unknown",                                   # the log never says who or what changed it
            "note_present": note, "note_qa": bool(ap.get("note_qa")), "note_other": bool(ap.get("note_other")),
            "note_excerpt": ap.get("note_excerpt") or "",
            "approved_version": ap.get("approved_version"), "version_count": ap.get("version_count"),
            "approved_is_latest": ap.get("approved_is_latest"), "approved_file": ap.get("approved_file"),
            "approval_source": ap.get("source"),                          # None on older records
            "schema": ap.get("schema") or 1,
            "settings": {k2: ap.get(k2) for k2 in SETTINGS},
            "audience": ap.get("audience"),
        })
    return pairs


def _version_line(p):
    if p.get("approved_version") is None:
        return "approved version: not recorded (older record)"
    n, v = p.get("version_count"), p["approved_version"] + 1
    return "approved version: %d of %s%s" % (v, n if n else "?", "" if p.get("approved_is_latest") else " (not the newest)")


def report(recs, pairs):
    n = len(pairs)
    by = defaultdict(list)
    for p in pairs:
        by[p["status"]].append(p)
    comp, unk, rev = by["comparable"], by["baseline_unknown"], by["review_needed"]
    changed = [p for p in comp if p["prompt_changed"]]
    new_schema = sum(1 for r in recs if r.get("schema"))
    by_proj = defaultdict(int)
    for p in pairs:
        by_proj[p["project"]] += 1
    L = ["# Learning log — review report", ""]
    L.append(f"- Log records: {len(recs)} ({new_schema} in the current format, {len(recs) - new_schema} older)")
    L.append(f"- Approved scenes (the latest approval of each): {n}")
    L.append(f"  - Comparable - a known starting prompt, no note on the scene: {len(comp)}")
    L.append(f"  - Starting prompt unknown - no director prompt at or before the approval: {len(unk)}"
             "  (this does NOT mean the prompt was written from scratch)")
    L.append(f"  - Needs review - the scene carried a note: {len(rev)}"
             f"  (QA lines: {sum(1 for p in rev if p['note_qa'])}, other text: {sum(1 for p in rev if p['note_other'])};"
             f" starting prompt unknown among them: {sum(1 for p in rev if not p['baseline_prompt'])})"
             "  - not used for learning")
    L.append(f"- Of the comparable: the prompt at approval differs from the starting prompt in {len(changed)}, "
             f"is the same in {len(comp) - len(changed)}.")
    L.append("  A difference can come from the user, the QA fix, a translation or any other step - the log does not "
             "say which. It is not an image rejection rate and not a first-try failure rate.")
    L.append(f"- Starting prompt taken from the approval record itself: {sum(1 for p in pairs if p['baseline_basis'] == 'approval_record')}; "
             f"from the nearest earlier director record: {sum(1 for p in pairs if p['baseline_basis'] == 'earlier_director_record')}")
    known_v = [p for p in pairs if p.get("approved_version") is not None]
    L.append(f"- Approved version recorded: {len(known_v)} (not the newest version: "
             f"{sum(1 for p in known_v if p.get('approved_is_latest') is False)}); older records do not say")
    L.append("- Projects: " + ", ".join(f"{k}={v}" for k, v in by_proj.items()))
    L.append("")
    L.append("## Prompt changed (comparable; who or what changed it is unknown)")
    for p in changed[:40]:
        L.append(f"\n### scene {p['scene_id']} — “{p['vo'][:90]}”")
        L.append(f"- {_version_line(p)}")
        L.append(f"- settings at approval: {json.dumps(p['settings'], ensure_ascii=False)}")
        L.append(f"- STARTING PROMPT ({p['baseline_basis'].replace('_', ' ')}): {p['baseline_prompt'][:300]}")
        L.append(f"- PROMPT AT APPROVAL: {p['final_prompt'][:300]}")
    L.append("\n## Needs review (kept apart - not used for learning)")
    for p in rev[:40]:
        kind = " + ".join(x for x, on in (("QA line", p["note_qa"]), ("other text", p["note_other"])) if on) or "note"
        L.append(f"- scene {p['scene_id']} ({p['project']}) — {kind}: {p['note_excerpt'][:160]!r}")
    L.append("\n## Starting prompt unknown")
    for p in unk[:40]:
        L.append(f"- scene {p['scene_id']} ({p['project']}) — “{p['vo'][:80]}”")
    return "\n".join(L)


def main():
    recs = load(LOG)
    pairs = build(recs)
    (OUT / "learn_dataset.jsonl").write_text(
        "\n".join(json.dumps(p, ensure_ascii=False) for p in pairs), encoding="utf-8")
    (OUT / "learn_report.md").write_text(report(recs, pairs), encoding="utf-8")
    print(f"Wrote {OUT/'learn_dataset.jsonl'} ({len(pairs)} pairs) and {OUT/'learn_report.md'}")
    if DISTILL:
        distill(pairs)


def learning_input(pairs):
    """What automatic distillation may read: comparable records whose prompt changed - never a record that needs
    review, and never one whose starting prompt is unknown."""
    return [p for p in pairs if p["status"] == "comparable" and p["prompt_changed"]]


def distill(pairs):
    """Ask the LLM to PROPOSE generalised, product-agnostic sentence->technique rules from the pairs.
    Writes learn_proposal.md. It NEVER edits DIRECTOR_SYSTEM — we review the proposal by hand first."""
    use = learning_input(pairs)
    if not use:
        print("No comparable changed prompts to distill."); return
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
    import app  # reuse the app's LLM call + keys
    examples = [{"vo": p["vo"], "director": p["baseline_prompt"], "at_approval": p["final_prompt"],
                 "settings": p["settings"]} for p in use]
    sysmsg = (
        "You improve an ad DIRECTOR's sentence->image technique. You are given pairs: the voice-over line, what "
        "the director first wrote, and the prompt the scene had when its picture was approved. The second may have "
        "been changed by the user, by an automatic QA fix, by a translation or by another step - the data does not "
        "say which, so do not assume a person chose it. Extract GENERALISED, PRODUCT-AGNOSTIC TECHNIQUE rules of the "
        "form 'WHEN the line is <type> -> DO <visual approach>'. Strip all product/brand/audience specifics (no "
        "CitruSlim, no blood oranges). Only propose a rule if the SAME technique appears across MULTIPLE scenes (say "
        "how many). Output a concise markdown list; do not restate one-off content.")
    payload = json.dumps(examples[:200], ensure_ascii=False)
    try:
        out = app._claude_text(sysmsg, payload, max_tokens=4000)
    except Exception as e:
        out = f"(distill failed: {e})"
    (OUT / "learn_proposal.md").write_text(out, encoding="utf-8")
    print(f"Wrote {OUT/'learn_proposal.md'} — REVIEW by hand; nothing was applied to the director.")


if __name__ == "__main__":
    main()
