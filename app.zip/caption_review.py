"""Reviewable, offset-based text changes. Audio and timings are never edited here."""
import difflib
import re
import unicodedata

WORD = re.compile(r"\w+(?:['’\-]\w+)*", re.UNICODE)


def words(text):
    return list(WORD.finditer(text or ''))


def norm(value):
    return unicodedata.normalize('NFC', value).casefold().replace('’', "'")


def differences(script, transcript):
    a, b = words(script), words(transcript)
    matcher = difflib.SequenceMatcher(None, [norm(x.group()) for x in a],
                                     [norm(x.group()) for x in b], autojunk=False)
    out = []
    for tag, i, j, k, l in matcher.get_opcodes():
        if tag == 'equal':
            continue
        start = a[i].start() if i < len(a) else len(script)
        end = a[j-1].end() if j > i else start
        replacement = transcript[b[k].start():b[l-1].end()] if l > k else ''
        if tag == 'insert':
            if start and not script[start-1].isspace():
                replacement = ' ' + replacement
            if start < len(script) and not script[start].isspace():
                replacement += ' '
        if tag == 'delete':
            while end < len(script) and script[end].isspace():
                end += 1
        out.append(dict(start=start, end=end, before=script[start:end], after=replacement,
                        kind='voice', reason='Different From The Recognized Voice-over',
                        context=script[max(0,start-55):min(len(script),end+55)]))
    return out


def spelling_changes(script, corrections, occupied=()):
    """Only exact, unambiguous excerpts supplied by the proofreader may be offered."""
    out = []
    for c in corrections if isinstance(corrections, list) else []:
        if not isinstance(c, dict):
            continue
        before, after = c.get('before'), c.get('after')
        if not isinstance(before, str) or not isinstance(after, str) or not before or before == after:
            continue
        if len(before) > 700 or len(after) > 900:
            continue
        positions = [m.start() for m in re.finditer(re.escape(before),script)]
        if len(positions) != 1:
            continue
        start, end = positions[0], positions[0]+len(before)
        if any(start <= p['end'] and end >= p['start'] for p in [*occupied,*out]):
            continue
        out.append(dict(start=start,end=end,before=before,after=after,kind='spelling',
                        reason='Spelling Or Punctuation',context=script[max(0,start-55):min(len(script),end+55)]))
    return out


def apply_selected(script, changes, selected):
    if not isinstance(selected, list) or any(not isinstance(v,str) for v in selected):
        raise ValueError('Select the changes to apply.')
    by_id = {str(i): change for i,change in enumerate(changes)}
    if len(set(selected)) != len(selected) or any(k not in by_id for k in selected):
        raise ValueError('Unknown or repeated review selection.')
    chosen = sorted((by_id[k] for k in selected),key=lambda p:(p['start'],p['end']))
    last = -1
    for c in chosen:
        if c['start'] < last or script[c['start']:c['end']] != c['before']:
            raise ValueError('Overlapping or stale text changes.')
        last=c['end']
    for c in reversed(chosen):
        script=script[:c['start']]+c['after']+script[c['end']:]
    return script


def block_spans(script, texts):
    """Locate ordered scene/caption wording in the canonical script, including repeats."""
    source=words(script)
    pieces=[words(t) for t in texts]
    flat=[norm(w.group()) for piece in pieces for w in piece]
    matcher=difflib.SequenceMatcher(None,flat,[norm(w.group()) for w in source],autojunk=False)
    mapping={i+k:j+k for i,j,n in matcher.get_matching_blocks() for k in range(n)}
    spans=[];cursor=0
    for piece in pieces:
        hits=[mapping[i] for i in range(cursor,cursor+len(piece)) if i in mapping]
        if piece and len(hits)<max(1,len(piece)*.7):
            raise ValueError('Some scene/caption text has diverged from the script. It was kept unchanged; sync its wording first.')
        spans.append((min(hits),max(hits)+1) if hits else None)
        cursor+=len(piece)
    return source,spans


def rewrite_blocks(old, new, texts):
    before,spans=block_spans(old,texts);after=words(new)
    matcher=difflib.SequenceMatcher(None,[norm(w.group()) for w in before],
                                   [norm(w.group()) for w in after],autojunk=False)
    operations=matcher.get_opcodes()
    def boundary(pos):
        for tag,i,j,k,l in operations:
            if i<=pos<=j:
                if tag=='equal':return k+pos-i
                if pos==i:return k
                if pos==j:return l
                return k+round((pos-i)/(j-i)*(l-k))
        return len(after)
    out=[]
    for text,span in zip(texts,spans):
        if span is None:out.append(text);continue
        a,b=map(boundary,span)
        start=0 if a==0 else after[a].start() if a<len(after) else len(new)
        end=after[b].start() if b<len(after) else len(new)
        out.append(new[start:end].strip() if b>a else '')
    # A final insertion belongs to the final block (there is no next scene/cue).
    if spans and spans[-1] and spans[-1][1]==len(before) and after:
        a=boundary(spans[-1][0]);start=0 if a==0 else after[a].start() if a<len(after) else len(new)
        out[-1]=new[start:].strip()
    return out


def replace_caption(script, texts, index, replacement):
    tokens,spans=block_spans(script,texts)
    if not isinstance(index,int) or index<0 or index>=len(spans) or spans[index] is None:
        raise ValueError('This caption can no longer be located in the script. Refresh Preview.')
    a,b=spans[index]
    start=0 if a==0 else tokens[a].start()
    end=tokens[b].start() if b<len(tokens) else len(script)
    tail=script[end:]
    insert=replacement.strip()
    if tail and insert:insert+=' '
    return script[:start]+insert+tail
