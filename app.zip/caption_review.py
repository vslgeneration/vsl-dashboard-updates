"""Reviewable, offset-based text changes. Audio and timings are never edited here."""
import difflib
import re
import unicodedata

WORD = re.compile(r"\w+(?:['’\-]\w+)*", re.UNICODE)


def words(text):
    return list(WORD.finditer(text or ''))


def norm(value):
    return unicodedata.normalize('NFC', value).casefold().replace('’', "'")


def differences(script, transcript):
    a, b = words(script), words(transcript)
    matcher = difflib.SequenceMatcher(None, [norm(x.group()) for x in a],
                                     [norm(x.group()) for x in b], autojunk=False)
    out = []
    for tag, i, j, k, l in matcher.get_opcodes():
        if tag == 'equal':
            continue
        start = a[i].start() if i < len(a) else len(script)
        end = a[j-1].end() if j > i else start
        replacement = transcript[b[k].start():b[l-1].end()] if l > k else ''
        if tag == 'insert':
            if start and not script[start-1].isspace():
                replacement = ' ' + replacement
            if start < len(script) and not script[start].isspace():
                replacement += ' '
        if tag == 'delete':
            while end < len(script) and script[end].isspace():
                end += 1
        out.append(dict(start=start, end=end, before=script[start:end], after=replacement,
                        kind='voice', reason='Different From The Recognized Voice-over',
                        context=script[max(0,start-55):min(len(script),end+55)]))
    return out


def spelling_changes(script, corrections, occupied=()):
    """Only exact, unambiguous excerpts supplied by the proofreader may be offered."""
    out = []
    for c in corrections if isinstance(corrections, list) else []:
        if not isinstance(c, dict):
            continue
        before, after = c.get('before'), c.get('after')
        if not isinstance(before, str) or not isinstance(after, str) or not before or before == after:
            continue
        if len(before) > 700 or len(after) > 900:
            continue
        positions = [m.start() for m in re.finditer(re.escape(before),script)]
        if len(positions) != 1:
            continue
        start, end = positions[0], positions[0]+len(before)
        if any(start <= p['end'] and end >= p['start'] for p in [*occupied,*out]):
            continue
        out.append(dict(start=start,end=end,before=before,after=after,kind='spelling',
                        reason='Spelling Or Punctuation',context=script[max(0,start-55):min(len(script),end+55)]))
    return out


def apply_selected(script, changes, selected):
    if not isinstance(selected, list) or any(not isinstance(v,str) for v in selected):
        raise ValueError('Select the changes to apply.')
    by_id = {str(i): change for i,change in enumerate(changes)}
    if len(set(selected)) != len(selected) or any(k not in by_id for k in selected):
        raise ValueError('Unknown or repeated review selection.')
    chosen = sorted((by_id[k] for k in selected),key=lambda p:(p['start'],p['end']))
    last = -1
    for c in chosen:
        if c['start'] < last or script[c['start']:c['end']] != c['before']:
            raise ValueError('Overlapping or stale text changes.')
        last=c['end']
    for c in reversed(chosen):
        script=script[:c['start']]+c['after']+script[c['end']:]
    return script


def block_spans(script, texts):
    """Locate ordered scene/caption wording in the canonical script, including repeats."""
    source=words(script)
    pieces=[words(t) for t in texts]
    flat=[norm(w.group()) for piece in pieces for w in piece]
    target=[norm(w.group()) for w in source]
    mapping={i+k:j+k for tag,i,end,j,_ in word_operations(flat,target) if tag=='equal' for k in range(end-i)}
    spans=[];cursor=0
    for piece in pieces:
        hits=[mapping[i] for i in range(cursor,cursor+len(piece)) if i in mapping]
        if piece and len(hits)<max(1,len(piece)*.7):
            raise ValueError('Some scene/caption text has diverged from the script. It was kept unchanged; sync its wording first.')
        spans.append((min(hits),max(hits)+1) if hits else None)
        cursor+=len(piece)
    return source,spans


def rewrite_blocks(old, new, texts):
    before,spans=block_spans(old,texts);after=words(new)
    operations=word_operations([norm(w.group()) for w in before],[norm(w.group()) for w in after])
    def boundary(pos):
        for tag,i,j,k,l in operations:
            if i<=pos<=j:
                if tag=='equal':return k+pos-i
                if pos==i:return k
                if pos==j:return l
                return k+round((pos-i)/(j-i)*(l-k))
        return len(after)
    out=[]
    for text,span in zip(texts,spans):
        if span is None:out.append(text);continue
        a,b=map(boundary,span)
        start=0 if a==0 else after[a].start() if a<len(after) else len(new)
        end=after[b].start() if b<len(after) else len(new)
        out.append(new[start:end].strip() if b>a else '')
    # A final insertion belongs to the final block (there is no next scene/cue).
    if spans and spans[-1] and spans[-1][1]==len(before) and after:
        a=boundary(spans[-1][0]);start=0 if a==0 else after[a].start() if a<len(after) else len(new)
        out[-1]=new[start:].strip()
    return out


def word_operations(a,b):
    """Linear common edges keep one-word edits in long repeated scripts cheap."""
    first=0
    while first<min(len(a),len(b)) and a[first]==b[first]:first+=1
    end_a,end_b=len(a),len(b)
    while end_a>first and end_b>first and a[end_a-1]==b[end_b-1]:end_a-=1;end_b-=1
    result=[('equal',0,first,0,first)] if first else []
    result.extend((tag,i+first,j+first,k+first,l+first) for tag,i,j,k,l in
                  difflib.SequenceMatcher(None,a[first:end_a],b[first:end_b],autojunk=False).get_opcodes())
    if end_a<len(a):result.append(('equal',end_a,len(a),end_b,len(b)))
    return result


def replace_caption(script, texts, index, replacement):
    tokens,spans=block_spans(script,texts)
    if not isinstance(index,int) or index<0 or index>=len(spans) or spans[index] is None:
        raise ValueError('This caption can no longer be located in the script. Refresh Preview.')
    a,b=spans[index]
    start=0 if a==0 else tokens[a].start()
    end=tokens[b].start() if b<len(tokens) else len(script)
    tail=script[end:]
    insert=replacement.strip()
    if tail and insert:insert+=' '
    return script[:start]+insert+tail


def local_alignment_plan(old, new, cues, timed_words):
    """Use measured neighbouring cues as audio anchors; never guess absent timing."""
    import math
    tokens=lambda text:[norm(w.group()) for w in words(text)]
    if not cues or not timed_words or tokens(old)!=tokens(' '.join(c['text'] for c in cues)):
        return None
    cache_tokens=[];edges={0:0}
    for i,(start,end,text) in enumerate(timed_words):
        if not all(math.isfinite(t) for t in (start,end)) or start<0 or end<start:
            return None
        if i and start<timed_words[i-1][0]:return None
        cache_tokens.extend(tokens(text));edges[len(cache_tokens)]=i+1
    if cache_tokens!=tokens(old):return None
    rewritten=rewrite_blocks(old,new,[c['text'] for c in cues])
    if tokens(' '.join(rewritten))!=tokens(new):return None
    changed=[i for i,c in enumerate(cues) if tokens(c['text'])!=tokens(rewritten[i])]
    if not changed:return None
    a=max(0,min(changed)-1);b=min(len(cues),max(changed)+2)
    wi=sum(len(tokens(c['text'])) for c in cues[:a]);wj=sum(len(tokens(c['text'])) for c in cues[:b])
    if wi not in edges or wj not in edges or wi==wj:return None
    i,j=edges[wi],edges[wj]
    start=min(float(cues[a]['start']),timed_words[i][0])
    end=max(float(cues[b-1]['end']),timed_words[j-1][1])
    if not 0<end-start<=90 or (a==0 and b==len(cues)):return None
    # Overlapping legacy timing cannot establish an independent safe crop.
    if (a and start<cues[a-1]['end']-.002) or (b<len(cues) and end>cues[b]['start']+.002):return None
    text=' '.join(rewritten[a:b]).strip()
    if not text:return None
    return dict(a=a,b=b,i=i,j=j,start=start,end=end,text=text,rewritten=rewritten)


def timed_caption_edit(old, new, cues, timed_words):
    """Editorial removals/one-for-one corrections reuse exact measured word slots.

    New spoken words require alignment. This never stretches another word or
    redistributes timing, even when a whole caption is removed.
    """
    import math
    before, after = words(old), words(new)
    tokens = lambda text: [norm(w.group()) for w in words(text)]
    a, b = tokens(old), tokens(new)
    if not cues or not timed_words or tokens(' '.join(c['text'] for c in cues)) != a:
        return None
    if any(len(words(t)) != 1 for _, _, t in timed_words):
        return None
    if [norm(words(t)[0].group()) for _, _, t in timed_words] != a:
        return None
    last = -1
    for start, end, _ in timed_words:
        if not all(math.isfinite(t) for t in (start, end)) or start < 0 or end < start or start < last:
            return None
        last = start
    operations = word_operations(a, b)
    changes = [r for r in operations if r[0] != 'equal']
    if not changes or sum(j-i for _, i, j, _, _ in changes) > 24:
        return None
    if any(tag == 'insert' or (tag == 'replace' and j-i != l-k) for tag, i, j, k, l in changes):
        return None
    result = []
    for tag, i, j, k, l in operations:
        if tag == 'equal':
            result.extend(timed_words[i:j])
        elif tag == 'replace':
            for old_index, new_index in zip(range(i, j), range(k, l)):
                start, end, _ = timed_words[old_index]
                stop = after[new_index+1].start() if new_index+1 < len(after) else len(new)
                text = new[after[new_index].start():stop].strip()
                result.append((start, end, text))
    rewritten = rewrite_blocks(old, new, [c['text'] for c in cues])
    output = [dict(c, text=t) for c, t in zip(cues, rewritten) if t.strip()]
    if tokens(' '.join(c['text'] for c in output)) != b:
        return None
    if tokens(' '.join(w[2] for w in result)) != b:
        return None
    return output, result
