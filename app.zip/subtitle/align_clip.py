#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Word-level forced alignment of ONE short audio clip against a text — used for a single testimonial's
CUSTOM voice-over (generated or uploaded), so the karaoke highlight can sync to the user's own voice
without re-running the whole VSL SRT.

Aligner: torchaudio MMS-FA (Meta multilingual CTC forced aligner), NOT Whisper.
Whisper does not produce timestamps — it infers them from cross-attention, which is usually fine
(median ~20 ms) but lands a word up to ~700 ms out at some sentence starts. On a subtitle that is
invisible; on karaoke, where each word lights up on its own, it is the "highlight stalls then catches
up" bug. MMS-FA is a real forced aligner: measured worst case ~100 ms, no catastrophic misses.

On top of the model, every word start is SNAPPED to the real speech onset measured from the waveform
(the model says WHICH word, the waveform says exactly WHEN) — that is what takes the median error to
~10 ms. Words the aligner cannot take (pure digits, symbols) keep their place and are interpolated
between their neighbours, so the caller still gets one entry per word.

Reads env:
  VSL_CLIP_AUDIO  path to the audio clip
  VSL_CLIP_TEXT   path to a UTF-8 text file (the testimonial text)
  VSL_CLIP_OUT    path to write JSON [{"w":..,"s":..,"e":..}] (0-based clip seconds)
  VSL_CLIP_LANG   language code of the voice-over (default en) — used only for diacritic folding
  VSL_CLIP_MODEL  ignored (kept so existing callers do not break)
"""
import os, sys, json, re, wave, subprocess, tempfile, shutil

BIAS = 0.033          # MMS-FA marks word starts ~33 ms late (measured over 1267 onsets)
_WORD = re.compile(r"[^\W_]", re.U)


def step(pct, label):
    """Progress line the dashboard parses to drive its toast. Loading the model is most of the wall
    time on a short clip, so the stages are weighted by how long they actually take, not evenly."""
    print("[clip] PROGRESS %d %s" % (pct, label), flush=True)


def _fold(s):
    """Latin-script fold to the aligner's token set (a-z and apostrophe)."""
    s = s.lower()
    for a, b in (("ä", "a"), ("ö", "o"), ("ü", "u"), ("ß", "ss"), ("é", "e"), ("è", "e"), ("ê", "e"),
                 ("à", "a"), ("â", "a"), ("á", "a"), ("ç", "c"), ("î", "i"), ("ï", "i"), ("í", "i"),
                 ("ô", "o"), ("ó", "o"), ("û", "u"), ("ù", "u"), ("ú", "u"), ("ñ", "n"), ("œ", "oe"),
                 ("å", "a"), ("ø", "o"), ("æ", "ae"), ("ı", "i"), ("ş", "s"), ("ğ", "g"), ("ç", "c")):
        s = s.replace(a, b)
    return re.sub(r"[^a-z']", "", s)


def _to_wav16(src):
    """Decode any input to 16 kHz mono WAV (MMS-FA's sample rate). Returns (path, tmpdir)."""
    td = tempfile.mkdtemp(prefix="clipalign_")
    dst = os.path.join(td, "clip16.wav")
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", src,
                    "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", dst], check=True)
    return dst, td


def main():
    audio = os.environ.get("VSL_CLIP_AUDIO")
    text_path = os.environ.get("VSL_CLIP_TEXT")
    out = os.environ.get("VSL_CLIP_OUT")
    if not (audio and text_path and out):
        print("missing VSL_CLIP_* env", file=sys.stderr); sys.exit(2)
    with open(text_path, encoding="utf-8") as f:
        text = f.read().strip()
    if not text:
        print("empty text", file=sys.stderr); sys.exit(2)

    step(6, "Starting the aligner")
    import numpy as np
    import torch, torchaudio

    step(14, "Loading the alignment model")
    try:
        bundle = torchaudio.pipelines.MMS_FA
        # with_star=True enables the "*" token, appended below to absorb audio no word matches —
        # a recorded clip usually has a breath, a room tone or a music tail after the last word, and
        # without the star the aligner must cover that too, so the final word gets stretched over it.
        model = bundle.get_model(with_star=True)
        model.eval()
        tokenizer = bundle.get_tokenizer()
        aligner = bundle.get_aligner()
    except Exception as e:
        print("aligner model not available: %s" % e, file=sys.stderr)
        print("The speech alignment model is still downloading — wait for it to finish, then retry.",
              file=sys.stderr)
        sys.exit(3)

    step(52, "Reading the voice-over")
    wav16, td = _to_wav16(audio)
    try:
        with wave.open(wav16, "rb") as w:
            sr = w.getframerate()
            x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        if x.size == 0:
            print("empty audio", file=sys.stderr); sys.exit(2)

        toks = [m.group(0) for m in re.finditer(r"\S+", text)]
        toks = [t for t in toks if _WORD.search(t)]          # drop punctuation-only tokens ("—")
        idx_ok, words = [], []
        for i, t in enumerate(toks):
            f = _fold(t)
            if f:
                idx_ok.append(i); words.append(f)
        if not words:
            print("no alignable words", file=sys.stderr); sys.exit(2)

        step(62, "Matching %d words to the audio" % len(toks))
        lst = ["*"] + words + ["*"]          # stars front and back: lead-in silence and tail room tone
        with torch.inference_mode():
            emission, _ = model(torch.from_numpy(x).unsqueeze(0))
            spans = aligner(emission[0], tokenizer(lst))
        if len(spans) != len(lst):
            print("aligner returned %d spans for %d tokens" % (len(spans), len(lst)), file=sys.stderr)
            sys.exit(3)
        spans = spans[1:-1]                  # drop the stars' own spans
        ratio = x.shape[0] / emission.shape[1]

        step(88, "Placing each word on the waveform")
        # speech-energy envelope, for snapping each start to the real onset
        hop, win = int(0.0025 * sr), int(0.010 * sr)
        nfr = max(1, (len(x) - win) // hop)
        env = np.sqrt(np.array([np.mean(x[k * hop:k * hop + win] ** 2) for k in range(nfr)], dtype=np.float32))
        th = max(float(np.percentile(env, 10)) * 4.0, 0.004)

        def E(t):
            k = int(t * sr / hop)
            return float(env[k]) if 0 <= k < len(env) else 0.0

        def snap(t, back=0.35):
            """Walk BACK from t (through the word) to the silence in front of it, then forward to the
            first speech frame. Probing at one fixed offset misses every word the model placed later
            than that offset — which is exactly the case worth fixing."""
            u, limit = t, t - back
            while u > limit and E(u) > th:
                u -= 0.0025
            if u <= limit:                       # genuinely mid-flow: no measurable onset
                return max(0.0, t - BIAS)
            v = u
            while v < t + 0.10 and E(v) <= th:
                v += 0.0025
            return max(0.0, v) if abs(v - t) < back else max(0.0, t - BIAS)

        res = [None] * len(toks)
        if len(spans) != len(idx_ok):         # zip() would SILENTLY truncate and drop words
            print('aligner returned %d spans for %d words' % (len(spans), len(idx_ok)), file=sys.stderr)
            sys.exit(4)
        for sp, i in zip(spans, idx_ok):
            s = sp[0].start * ratio / sr
            e = sp[-1].end * ratio / sr
            res[i] = [snap(s), max(e, s + 0.02)]
        # words the aligner could not take (pure digits / symbols): interpolate across the gap
        for i, r in enumerate(res):
            if r is not None:
                continue
            p = next((res[j] for j in range(i - 1, -1, -1) if res[j]), None)
            n = next((res[j] for j in range(i + 1, len(res)) if res[j]), None)
            if p and n:
                res[i] = [p[1], max(p[1] + 0.05, n[0])]
            elif p:
                res[i] = [p[1], p[1] + 0.30]
            elif n:
                res[i] = [max(0.0, n[0] - 0.30), n[0]]
            else:
                res[i] = [0.0, 0.30]
        # keep it monotonic
        for i in range(1, len(res)):
            if res[i][0] < res[i - 1][0] + 0.02:
                res[i][0] = res[i - 1][0] + 0.02
            if res[i][1] < res[i][0] + 0.02:
                res[i][1] = res[i][0] + 0.02

        words_out = [{"w": toks[i], "s": round(res[i][0], 3), "e": round(res[i][1], 3)}
                     for i in range(len(toks))]
        with open(out, "w", encoding="utf-8") as f:
            json.dump(words_out, f)
        print("[clip] %d words -> %s" % (len(words_out), out), flush=True)
    finally:
        shutil.rmtree(td, ignore_errors=True)


if __name__ == "__main__":
    main()
