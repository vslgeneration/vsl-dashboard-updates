#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Word-level forced alignment of ONE short audio clip against a text — used for a single testimonial's
CUSTOM voice-over (generated or uploaded), so the karaoke highlight can sync to the user's own voice
without re-running the whole VSL SRT.

Uses the same multilingual MMS forced alignment, numeric speech forms and independent quality
checks as project subtitles. Printed words and punctuation remain unchanged. An unresolved
timing or wording check leaves the previous completed highlight file in place and exposes
the quality report to the caller; unmeasured numeric times are never interpolated.

Reads env:
  VSL_CLIP_AUDIO  path to the audio clip
  VSL_CLIP_TEXT   path to a UTF-8 text file (the testimonial text)
  VSL_CLIP_OUT    path to write JSON [{"w":..,"s":..,"e":..}] (0-based clip seconds)
  VSL_CLIP_LANG   language code for alignment, speech forms and quality checks (default en)
  VSL_CLIP_MODEL  ignored (kept so existing callers do not break)
"""
import os, sys, json, re, wave, subprocess, tempfile, shutil
from text_boundaries import normalize_spacing
from testimonial_numbers import spoken_token

BIAS = 0.033          # MMS-FA marks word starts ~33 ms late (measured over 1267 onsets)
_WORD = re.compile(r"[^\W_]", re.U)


def step(pct, label):
    """Progress line the dashboard parses to drive its toast. Loading the model is most of the wall
    time on a short clip, so the stages are weighted by how long they actually take, not evenly."""
    print("[clip] PROGRESS %d %s" % (pct, label), flush=True)


def _fold(s):
    """Latin-script fold to the aligner's token set (a-z and apostrophe)."""
    s = s.lower()
    for a, b in (("ä", "a"), ("ö", "o"), ("ü", "u"), ("ß", "ss"), ("é", "e"), ("è", "e"), ("ê", "e"),
                 ("à", "a"), ("â", "a"), ("á", "a"), ("ç", "c"), ("î", "i"), ("ï", "i"), ("í", "i"),
                 ("ô", "o"), ("ó", "o"), ("û", "u"), ("ù", "u"), ("ú", "u"), ("ñ", "n"), ("œ", "oe"),
                 ("å", "a"), ("ø", "o"), ("æ", "ae"), ("ı", "i"), ("ş", "s"), ("ğ", "g"), ("ç", "c")):
        s = s.replace(a, b)
    return re.sub(r"[^a-z']", "", s)


def _to_wav16(src):
    """Decode any input to 16 kHz mono WAV (MMS-FA's sample rate). Returns (path, tmpdir)."""
    td = tempfile.mkdtemp(prefix="clipalign_")
    dst = os.path.join(td, "clip16.wav")
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", src,
                    "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", dst], check=True)
    return dst, td


def main():
    """Custom testimonial timings use the same measured clock and quality gate.

    Phrase layout is checked here, but the card still displays its own full text
    and highlights individual words; it does not become a normal SRT overlay.
    """
    from pathlib import Path
    import _mms_align,acoustic_phrasing,phrase_store,caption_quality
    audio=os.environ.get('VSL_CLIP_AUDIO');text_path=os.environ.get('VSL_CLIP_TEXT');out=os.environ.get('VSL_CLIP_OUT')
    if not (audio and text_path and out):raise ValueError('Missing clip alignment inputs')
    text=normalize_spacing(Path(text_path).read_text('utf8').strip());lang=os.environ.get('VSL_CLIP_LANG') or 'en'
    if not text:raise ValueError('Empty testimonial text')
    os.environ['VSL_LANG']=lang;folder=Path(out).parent;diagnostics={}
    step(6,'Measuring Testimonial Speech…')
    try:
        rows=_mms_align.align(audio,text,diagnostics=diagnostics)
    except Exception as error:
        caption_quality.persist_report(folder,caption_quality.alignment_failure_report(error,diagnostics=diagnostics,lang=lang))
        raise
    printed=phrase_store.timed_tokens(text.split(),rows)
    plan=acoustic_phrasing.plan(printed,acoustic_phrasing.detect_pauses(audio),lang)
    phrase_store.bind_source(plan,rows)
    step(88,'Checking Subtitles Against Script And Recording…')
    import hashlib
    evidence=dict(method='mms-fa',rows_sha256=phrase_store.rows_sha256(rows),
        audio_sha256=hashlib.sha256(Path(audio).read_bytes()).hexdigest(),
        clock=dict(language=lang,text_sha256=hashlib.sha256(text.encode()).hexdigest()),diagnostics=diagnostics)
    report=caption_quality.audit_candidate(audio,text,rows,plan,lang,folder,
        acoustic=evidence,cache_dir=os.environ.get('VSL_CAPTION_QA_CACHE'))
    caption_quality.persist_report(folder,report)
    if report.get('passed') is not True or report.get('status')!='pass':
        raise ValueError('Testimonial timing needs review. Previous highlight timings were kept.')
    final=report.get('candidate_plan') or plan
    verified=phrase_store.canonical_rows(final,rows)
    if [t for t,a,b in verified]!=text.split():raise ValueError('Testimonial text changed during alignment')
    words=[dict(w=t,s=round(a,3),e=round(b,3)) for t,a,b in verified if _WORD.search(t)]
    Path(out).write_text(json.dumps(words,ensure_ascii=False),'utf8')
    step(100,'Done')


if __name__ == "__main__":
    main()
