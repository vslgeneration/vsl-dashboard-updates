"""Independent audio-only recognition cache; never conditioned on the script."""
from pathlib import Path
import hashlib,json,math,numbers,os,tempfile,threading

POLICY='audio-recognition-v1000'
_LOCK=threading.Lock()

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as source:
  for chunk in iter(lambda:source.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def normalized_lang(lang):return str(lang or '').lower().replace('_','-').split('-')[0]

def _independent(options):
 return isinstance(options,dict) and 'initial_prompt' in options and not options.get('initial_prompt') and not options.get('prefix') and not options.get('hotwords') and not options.get('script_prompt')

def _result(value):
 if hasattr(value,'to_dict'):value=value.to_dict()
 if not isinstance(value,dict) or not isinstance(value.get('segments'),list):raise ValueError('Independent recognition has no segment list.')
 def plain(item):
  if isinstance(item,bool):return item
  if isinstance(item,numbers.Real):return float(item)
  if isinstance(item,dict):return {k:plain(v) for k,v in item.items()}
  if isinstance(item,(list,tuple)):return [plain(v) for v in item]
  return item
 value=plain(value)
 segments=[]
 for s in value['segments']:
  if not isinstance(s,dict):raise ValueError('Invalid recognition segment.')
  def valid_interval(row):return all(type(row.get(k)) in (int,float) and math.isfinite(row[k]) for k in ('start','end')) and 0<=row['start']<=row['end']
  if not valid_interval(s) or not isinstance(s.get('text'),str):raise ValueError('Invalid recognition segment timing.')
  for row in s.get('words') or []:
   if not isinstance(row,dict) or not valid_interval(row) or not isinstance(row.get('word',row.get('text')),str):raise ValueError('Invalid recognition word evidence.')
  segments.append({k:s[k] for k in ('start','end','text','words','avg_logprob','no_speech_prob') if k in s})
 return dict(language=value.get('language'),segments=segments)

def persist_recognition(audio,lang,model,backend,options,result,cache_dir):
 if not _independent(options):raise ValueError('Subtitle QA requires audio-only recognition without a script prompt.')
 record=dict(schema=1,policy=POLICY,audio_sha256=digest(audio),lang=normalized_lang(lang),model=str(model),backend=str(backend),options=dict(options),result=_result(result))
 if cache_dir:
  directory=Path(cache_dir);directory.mkdir(parents=True,exist_ok=True)
  identity={k:v for k,v in record.items() if k!='result'}
  key=hashlib.sha256(json.dumps(identity,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
  target=directory/(record['audio_sha256'][:16]+'-'+record['lang']+'-'+key[:20]+'.json')
  fd,temporary=tempfile.mkstemp(prefix='.recognition-',suffix='.tmp',dir=directory)
  try:
   with os.fdopen(fd,'w',encoding='utf8') as output:json.dump(record,output,ensure_ascii=False)
   os.replace(temporary,target)
  finally:Path(temporary).unlink(missing_ok=True)
 record['cached']=False
 return record

def cached_recognition(audio,lang,cache_dir):
 if not cache_dir or not Path(cache_dir).is_dir():return None
 sha=digest(audio);language=normalized_lang(lang);matches=[]
 for path in Path(cache_dir).glob(sha[:16]+'-'+language+'-*.json'):
  try:
   value=json.loads(path.read_text('utf8'))
   if value.get('policy')!=POLICY or value.get('audio_sha256')!=sha or value.get('lang')!=language or not _independent(value.get('options')):continue
   if value.get('model') not in ('small','medium','large-v3','large-v2','large'):continue
   if value.get('backend') not in ('whisper','stable_whisper','faster_whisper'):continue
   _result(value.get('result'));matches.append((value.get('model')=='medium',path.stat().st_mtime_ns,value))
  except (OSError,ValueError,TypeError):continue
 if not matches:return None
 value=max(matches,key=lambda x:x[:2])[2];value['cached']=True;return value

def recognize_audio(audio,lang,cache_dir=None):
 cached=cached_recognition(audio,lang,cache_dir)
 if cached:return cached
 print('[quality] Listening independently with the cached multilingual model',flush=True)
 import torch,whisper
 torch.set_num_threads(2)
 try:torch.set_num_interop_threads(1)
 except RuntimeError:pass
 model_path=Path(os.environ.get('VSL_WHISPER_CACHE') or Path.home()/'.cache/whisper')/'small.pt'
 if not model_path.is_file():raise ValueError('The local multilingual subtitle quality model is not installed. Existing subtitles were kept.')
 options=dict(initial_prompt=None,condition_on_previous_text=False,word_timestamps=True,temperature=0,fp16=False)
 with _LOCK:
  model=whisper.load_model(str(model_path),device='cpu')
  result=model.transcribe(str(audio),language=normalized_lang(lang) or None,verbose=None,**options)
  del model
 return persist_recognition(audio,lang,'small','whisper',options,result,cache_dir)
