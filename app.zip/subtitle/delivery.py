"""A bound recording/word/SRT snapshot shared by editing and all delivery paths."""
import difflib
import json
import math
import re
import unicodedata
from pathlib import Path
from . import review_words


class MeasuredWords(list):
    def __init__(self, rows=(), scene_clock=None, issues=()):
        super().__init__(rows)
        self.scene_clock=scene_clock
        self.issues=list(issues)


def partition(scenes):
    return [[s.get('uid'),s.get('vo',''),s.get('editorial_timing'),s.get('speaker_cut_frame')] for s in scenes]


def locked_ranges(scenes, words):
    clock=getattr(words,'scene_clock',None)
    if not clock or clock.get('partition')!=partition(scenes): return None
    ranges=clock.get('ranges');included=clock.get('included')
    if not isinstance(ranges,list) or len(ranges)!=len(scenes) or len(included or [])!=len(scenes):
        raise ValueError('The preserved scene clock is incomplete.')
    if any(not isinstance(r,(list,tuple)) or len(r)!=2 or not all(type(x) in (int,float) and math.isfinite(x) for x in r) or not 0<=r[0]<=r[1] for r in ranges):
        raise ValueError('The preserved scene clock is invalid.')
    return [tuple(x) for x in ranges],list(included)


def duration(total, scenes, words):
    return float(words.scene_clock['duration']) if locked_ranges(scenes,words) is not None else total


def scene_words(scene, words):
    """Find words by their ordered script position, even across a protected cut."""
    clock=getattr(words,'scene_clock',None)
    if not clock:return None
    parts=clock.get('partition') or []
    norm=lambda text: [''.join(c for c in unicodedata.normalize('NFKC',w).casefold() if c.isalnum()) for w in str(text).split()]
    source=[];owners=[]
    for i,(_,_,word) in enumerate(words):
        for key in norm(word):
            if key:source.append(key);owners.append(i)
    target=[];spans={}
    for uid,text,*_ in parts:
        a=len(target);target.extend(k for k in norm(text) if k);spans[uid]=(a,len(target),text)
    span=spans.get(scene.get('uid'))
    if not span or span[2]!=scene.get('vo',''):return None
    positions={}
    for a,b,size in difflib.SequenceMatcher(None,target,source,autojunk=False).get_matching_blocks():
        for j in range(size):positions[a+j]=b+j
    selected=[positions.get(i) for i in range(span[0],span[1])]
    if not selected or any(i is None for i in selected):return None
    if selected!=list(range(selected[0],selected[-1]+1)):return None
    return list(words[owners[selected[0]]:owners[selected[-1]]+1])


def resolve_review(project, script, srt):
    """Never combine a recording from one take with words from another."""
    import audio_prepare
    folder=Path(project)/'subtitle'
    try:record=json.loads((folder/'caption-review.json').read_text('utf8'))
    except (OSError,ValueError):return None
    if not record.get('file') or Path(srt).resolve()!=(folder/record['file']).resolve():return None
    audio=None
    name=record.get('review_audio_file') or ''
    if not name:
        try:
            recovery=json.loads((folder/'recovered-review-words.json').read_text('utf8'))
            if recovery.get('review_sha256')==review_words.sha(folder/'caption-review.json'):
                name=recovery.get('review_audio_file') or ''
        except (OSError,ValueError):pass
    if re.fullmatch(r'review-[0-9a-f]{32}\.(?:wav|mp3|m4a|flac|ogg|aac)',name):
        audio=folder/name
        if not audio.is_file():raise ValueError('The retained subtitle recording is missing. Restore it or generate subtitles again.')
    else:
        state=audio_prepare.state(folder/'_audio-prep')
        if state.get('ref'):audio,_=audio_prepare.selected(folder/'_audio-prep',state['ref'])
    if audio is None:return None
    take=review_words.load(folder,record,script,srt,audio)
    if not take:raise ValueError('The review subtitles, recording and measured words do not match. Select their original recording or generate subtitles again.')
    return dict(take,audio=Path(audio),srt=Path(srt),review=True)
