#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Yol 1: word-level forced alignment of the exact (cleaned) script to the audio,
then re-segment subtitles ourselves by SCRIPT punctuation (independent of Premiere).

Pipeline:
  1. Build spoken-only script text (strip SOURCES / version markers / VO note / VERSION B).
  2. stable-ts forced alignment: audio + exact text -> per-word (start,end).
  3. Transfer word timings onto our EXACT script tokens (difflib) so display text stays 100% script.
  4. Segment: split into sentences, then into cues preferring strong punctuation (— ; :) then commas,
     capped at 42 chars/line x 2 lines. Each cue's time = first/last word timing.
  5. Write SRT.
"""
import re, sys, zipfile, difflib, os, subprocess, bisect, unicodedata

# Paths can be overridden via env vars (used by the dashboard integration);
# fall back to the original hardcoded defaults for standalone CLI use.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # so _mms_align imports when CWD is the project dir
AUDIO = os.environ.get("VSL_AUDIO") or r"C:\Users\Desktop\Desktop\CitruSlim_EN_VSL.mp3"
DOCX  = os.environ.get("VSL_DOCX")  or r"C:\Users\Desktop\Desktop\CitruSlim VSL EN2.docx"
OUT   = os.environ.get("VSL_OUT")   or r"C:\Users\Desktop\Desktop\CitruSlim_EN_VSL_ALIGNED.srt"
_args = sys.argv[1:]
MODEL = next((a for a in _args if not a.startswith('--')), "base.en")
VAD   = '--vad' in _args                  # voice-activity detection -> better silence/pause boundaries
LANG  = (os.environ.get("VSL_LANG") or "en").strip() or "en"   # Whisper language (fr/de/es/…); default English
WORDS_CACHE = f"words_{MODEL.replace('.', '_')}{'_vad' if VAD else ''}.tsv"

MAX_LINE  = 42
MAX_LINES = 2
MAX_CHARS = MAX_LINE * MAX_LINES          # ~84 per cue
CUE_MAX   = 76                            # cap per cue; keeps 2-line cues wrappable within 42 chars
MIN_DUR   = 0.9                           # seconds; extend very short cues if room
NO_GAP    = True                          # each cue ends exactly when the next begins (no blank gaps)
# FAQ / social "punchy" mode (--faq): short, snappy captions — a FEW words per cue on ONE line, broken at natural
# pauses, each tightly timed to its own words. Leaves the main VSL subtitle behaviour untouched.
FAQ_MODE = '--faq' in _args
if FAQ_MODE:
    MAX_LINE = 42; MAX_LINES = 2; CUE_MAX = 74; MIN_DUR = 0.8
    MAX_CHARS = MAX_LINE * MAX_LINES
# FAQ = ONE SENTENCE AT A TIME. Segmentation already breaks at sentence ends; a whole sentence that fits <=2
# lines becomes a single caption, a LONG sentence is split within itself (at pauses/punctuation) into readable
# pieces, and the merge below (which NEVER crosses a sentence boundary) keeps any piece from flashing too fast.
MERGE_MIN_DISP = 1.2 if FAQ_MODE else 1.1
SILENCE_MIN = 0.20                        # ffmpeg-detected silence >= this (sec) forces a cue cut
SOFT_PAUSE  = 0.12                        # smaller silence >= this guides LINE breaks within a cue
ELISION_KEEP_MAX = 0.45                   # a pause SHORTER than this right after a French elision (c'est/j'ai/…) is
                                          # a breath/micro-gap -> keep the elision with the next word (no split); a
                                          # LONGER (deliberate/dramatic) pause is still allowed to split.
SIL_LOG   = 'silence_all.log'             # cached ffmpeg silencedetect log
NOISE_DB  = '-30dB'                       # silence energy threshold

# ---------------- script (spoken only) ----------------
def spoken_script():
    z = zipfile.ZipFile(DOCX); xml = z.read('word/document.xml').decode('utf-8', 'ignore')
    out = []
    for para in re.split(r'</w:p>', xml):
        t = ''.join(re.findall(r'<w:t[^>]*>(.*?)</w:t>', para, re.S))
        t = (t.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
              .replace('&quot;', '"').replace('&apos;', "'"))
        if t.strip():
            out.append(t.strip())
    for i, p in enumerate(out):
        if p.strip().upper() == 'SOURCES':
            out = out[:i]; break
    kept, skip_b = [], False
    for p in out:
        s = p.strip()
        if s == '[START OF VERSION B]': skip_b = True;  continue
        if s == '[END OF VERSION B]':   skip_b = False; continue
        if skip_b: continue
        if re.match(r'^\[.*\]$', s): continue
        if s.startswith('(Note for the Voice Actor'): continue
        kept.append(p)
    return ' '.join(kept)

def norm(w): return re.sub(r'[^a-z0-9]', '', w.lower())

# ---------------- alignment ----------------
def _audio_dur_probe(path):
    import subprocess
    try:
        r = subprocess.run(["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", path], capture_output=True, text=True)
        return float((r.stdout or "0").strip() or 0)
    except Exception:
        return 0.0

def _align_slice(model, audio, text, offset=0.0):
    try:
        result = model.align(audio, text, language=LANG, vad=VAD)
    except TypeError:
        result = model.align(audio, text, language=LANG)
    return [(w.word.strip(), float(w.start) + offset, float(w.end) + offset)
            for w in result.all_words() if w.word.strip()]

def _tail_collapse_index(words, dur):
    """Index from which the tail is badly aligned, or None. Forced alignment DEGRADES on very long audio:
    it stops advancing and snaps runs of words onto a few 'stuck' timestamps while lots of audio remains.
    Detect the first run of >=6 words sharing ~one timestamp that still leaves >25s of audio ahead."""
    n = len(words)
    if n < 30 or dur <= 0:
        return None
    i = 0
    while i < n:
        j = i
        while j + 1 < n and abs(words[j + 1][1] - words[i][1]) < 0.05:
            j += 1
        if (j - i + 1) >= 6 and (dur - words[i][1]) > 25:
            return max(0, i - 2)          # back up a couple words for context
        i = max(j + 1, i + 1)
    return None

def align_words(text):
    """Word-level forced alignment with torchaudio MMS-FA. Returns [(token, start, end)].

    Replaces the old stable-ts (Whisper) forced alignment. Whisper INFERS timestamps from
    cross-attention: median ~20 ms but up to ~700 ms out at some sentence starts, and on
    multi-minute audio it collapses runs of words onto one timestamp — which is what the
    tail-repair loop and the two-model ensemble below existed to paper over. MMS-FA is a real
    CTC forced aligner: no collapse, worst case ~100 ms, and every start is then snapped to the
    speech onset measured from the waveform."""
    import _mms_align
    print(f"[align] MMS-FA forced alignment (lang={LANG}) ...", flush=True)
    words = _mms_align.align(AUDIO, text, lang=LANG)
    with open(WORDS_CACHE, 'w', encoding='utf-8') as f:
        for t, s_, e_ in words:
            f.write("%.3f\t%.3f\t%s\n" % (s_, e_, t))
    print(f"[align] {len(words)} words -> {WORDS_CACHE}", flush=True)
    return words

def transcribe_audio():
    """Plain transcription of the audio (what is ACTUALLY spoken), written to VSL_OUT as text. Used to
    reconcile the user's script against the real voice-over BEFORE aligning, so extra/mismatched script
    text can't derail the alignment."""
    import stable_whisper
    print(f"[transcribe] loading model {MODEL} ...", flush=True)
    model = stable_whisper.load_model(MODEL)
    try:
        result = model.transcribe(AUDIO, language=LANG, vad=VAD)
    except TypeError:
        result = model.transcribe(AUDIO, language=LANG)
    txt = (getattr(result, "text", "") or "").strip()
    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(txt)
    print(f"[transcribe] {len(txt.split())} words -> {OUT}", flush=True)

def load_words(path):
    words = []
    for ln in open(path, encoding='utf-8'):
        s, e, t = ln.rstrip('\n').split('\t', 2)
        words.append((t, float(s), float(e)))
    return words

def load_cached_words():
    return load_words(WORDS_CACHE)

def alignment_health(words):
    """0..1 score: fraction of words that are neither COLLAPSED (zero-width) nor OUT-OF-ORDER.
    A whole-audio alignment that failed a long tail (words crammed onto the audio-end timestamp, or
    jumping non-monotonically) scores low. Used to pick the healthier of the two models as the base."""
    n = len(words)
    if not n:
        return 0.0
    good, prev = 0, -1.0
    for (_t, s, e) in words:
        if (e > s + 1e-6) and (s >= prev - 0.25):     # has real duration AND roughly in order
            good += 1
        prev = max(prev, s)
    return good / n

def merge_timings(primary, secondary, pad=3):
    """Both lists are per-SCRIPT-token (start,end) from two models, so index k is the same
    word in each. Whole-audio alignment occasionally COLLAPSES a run of words onto one
    timestamp; different models collapse in different places. Where the primary model
    collapsed (a run of >=3 zero-width tokens), splice in the secondary model's timing for
    that padded window, then repair monotonicity."""
    n = len(primary)
    out = [list(x) for x in primary]                  # [word, start, end]
    i, patched = 0, 0
    while i < n:
        if primary[i][1] >= primary[i][2] - 1e-6:     # zero-width token
            j = i
            while j < n and primary[j][1] >= primary[j][2] - 1e-6:
                j += 1
            if j - i >= 3:                            # a real collapse run
                a, b = max(0, i - pad), min(n, j + pad)
                for k in range(a, b):
                    out[k][1], out[k][2] = secondary[k][1], secondary[k][2]
                patched += 1
                i = b; continue
            i = j
        else:
            i += 1
    for k in range(1, n):                             # repair monotonicity across splices
        if out[k][1] < out[k-1][2]:
            out[k][1] = out[k-1][2]
        if out[k][2] < out[k][1]:
            out[k][2] = out[k][1]
    if patched:
        print(f"[merge] patched {patched} alignment-collapse region(s) from secondary model", flush=True)
    return [(primary[k][0], out[k][1], out[k][2]) for k in range(n)]

# ---------------- transfer timings onto exact script tokens ----------------
def timed_script_tokens(script_tokens, aligned):
    aw_norm = [norm(t) for (t, _, _) in aligned]
    st_norm = [norm(t) for t in script_tokens]
    sm = difflib.SequenceMatcher(a=st_norm, b=aw_norm, autojunk=False)
    starts = [None] * len(script_tokens)
    ends   = [None] * len(script_tokens)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for k in range(i2 - i1):
                starts[i1 + k] = aligned[j1 + k][1]
                ends[i1 + k]   = aligned[j1 + k][2]
        elif tag == 'replace':
            js = aligned[j1:j2]
            if js:
                s0, e0 = js[0][1], js[-1][2]
                span = max(1, i2 - i1)
                for k in range(i2 - i1):
                    frac = k / span
                    starts[i1 + k] = s0 + (e0 - s0) * frac
                    ends[i1 + k]   = s0 + (e0 - s0) * (k + 1) / span
        elif tag == 'delete':  # script tokens with no aligned word -> fill later
            pass
        # insert: extra aligned words, ignore
    # forward/backward fill Nones
    last = 0.0
    for k in range(len(script_tokens)):
        if starts[k] is None:
            starts[k] = last
            ends[k]   = last
        last = ends[k]
    # enforce monotonic
    for k in range(1, len(script_tokens)):
        if starts[k] < ends[k-1]:
            starts[k] = ends[k-1]
        if ends[k] < starts[k]:
            ends[k] = starts[k]
    return [(script_tokens[k], starts[k], ends[k]) for k in range(len(script_tokens))]

# ---------------- segmentation ----------------
SENT_END = ('.', '?', '!', '…')
# R8 — A FULL STOP IS NOT ALWAYS A FULL STOP. "Dr." ends in a period, so segmentation cut the caption
# there and R2 then refused to merge the stub back ("Genau dann hielt aber Dr." on its own, "Carbonell
# inne – und…" on the next). Abbreviations are per language, and the ones that normally END a sentence
# (etc. usw. ecc. enz.) are deliberately NOT here. Neither are bare initials ("A.") or lone numbers
# ("14."), because "vitamin A." and "Plan B." really do end sentences — guessing there would just swap
# one wrong break for another. Company suffixes (Inc. Ltd. Co. GmbH.) are out for the same reason: they
# sit at the end of a name, and the name is usually the end of the sentence.
_ABBR = set("""
dr dres prof pr hr fr mr mrs ms mme mlle sr sra srta sig sig.ra dott dhr mevr drs ir ing
st ste jr
bzw ca evtl ggf inkl exkl zzgl bspw sog vgl abs art nr num vol fig approx env cf ung
""".split())
# Closing marks to look PAST when deciding what a token really ends on. German closes with “ (which is
# also the English OPENER, but only ever leading, and rstrip touches the tail only) — leaving it out meant
# a sentence that ends inside German quotes, ausgeht.“ , was not seen as a sentence end at all, and the
# caption ran straight on into the next speaker.
_TRAIL_Q = '"”“\'’‘)»›]'
def is_sent_end(tok):
    t = tok.rstrip(_TRAIL_Q)
    if not t.endswith(SENT_END):
        return False
    if t.endswith('.'):
        stem = t[:-1]
        if '.' in stem:                       # z.B. / u.a. / i.e. / U.S. — an abbreviation, not an ending
            return False
        if stem.lower() in _ABBR:
            return False
    return True
def break_score(tok):
    t = tok.rstrip(_TRAIL_Q)
    if tok in ('—', '–') or t.endswith(('—', '–', ';', ':')): return 2   # strong
    if t.endswith(','): return 1                                          # weak
    return 0

# R7 — LINE BREAKS FOLLOW GRAMMAR. A word that "glues" forward to the next one must not END a line or
# a cue: the eye trips on "der" / "and" / "para" left hanging. These lists are PER LANGUAGE. Until now
# only English existed, so a German or Spanish caption had no protection at all and happily broke
# after an article. English stays in the set for every language: VSL scripts carry English offer and
# brand terms mid-sentence.
_GLUE_EN = """
a an the this that these those my your his her its our their no some any each every another
of to in on at by for with from into onto upon as than about over under between through during
without within per off out up down
and or but nor so yet if while whereas because although though since unless until whether
next last first more most less least very such other own same few many much several
one two three four five six seven eight nine ten
is are was were be been being have has had do does did will would shall should can could may might must
"""
_GLUE_DE = """
der die das dem den des ein eine einem einen einer eines dieser diese dieses diesem diesen
mein meine meinem meinen meiner dein deine ihr ihre ihrem ihren ihrer sein seine seinem seinen seiner
unser unsere unserem unseren euer eure kein keine keinem keinen keiner jeder jede jedes
in an auf zu mit von fur uber unter bei nach aus seit ohne um durch gegen vor hinter neben zwischen
und oder aber denn sondern dass ob wenn weil damit als wie sowie bevor nachdem obwohl falls
weder entweder sowohl zwar teils je desto umso
ist sind war waren hat haben hatte hatten wird werden wurde wurden bin bist seid
kann konnen muss mussen soll sollen will wollen darf durfen mochte mochten
nicht nur auch noch sehr mehr immer wieder ganz
zwei drei vier funf sechs sieben acht neun zehn
"""
_GLUE_ES = """
el la los las un una unos unas lo al del
de a en con por para sin sobre entre hasta desde hacia segun tras
y o pero sino que si porque aunque cuando mientras donde como tambien
mi mis tu tus su sus nuestro nuestra nuestros nuestras este esta estos estas ese esa
es son era eran ha han habia habian esta estan sera seran puede pueden debe deben tiene tienen
muy mas menos cada todo toda todos todas otro otra
dos tres cuatro cinco seis siete ocho nueve diez
"""
_GLUE_IT = """
il lo la i gli le un uno una del della dei delle al alla ai alle dal dalla nel nella sul sulla
di a da in con su per tra fra senza sotto sopra verso durante
e o ma se che perche quando mentre dove come anche
mio mia miei mie tuo tua suo sua nostro nostra questo questa questi queste quel quella
sono era erano ha hanno aveva avevano sara saranno puo possono deve devono
molto piu meno ogni tutto tutta tutti tutte altro altra
due tre quattro cinque sei sette otto nove dieci
"""
_GLUE_PT = """
o a os as um uma uns umas do da dos das no na nos nas ao aos pelo pela
de em com por para sem sobre entre ate desde apos
e ou mas se que porque quando enquanto onde como tambem
meu minha seu sua nosso nossa este esta esse essa aquele aquela
sao era eram tem ha havia sera serao pode podem deve devem
muito mais menos cada todo toda todos todas outro outra
dois tres quatro cinco seis sete oito nove dez
"""
_GLUE_FR = """
le la les un une des du de au aux
a dans sur sous par pour avec sans vers chez entre depuis pendant contre
et ou mais donc car si que qui quand comme parce
mon ma mes ton ta son sa ses notre nos votre vos leur leurs ce cet cette ces
est sont etait etaient ont avait avaient sera seront peut peuvent doit doivent
tres plus moins chaque tout toute tous toutes autre
deux trois quatre cinq six sept huit neuf dix
"""
_GLUE_NL = """
de het een deze dit die dat
in op aan bij van voor met naar door over onder tussen zonder tegen
en of maar want als dan omdat terwijl toen ook
mijn jouw zijn haar onze hun
is was waren heeft hebben had hadden wordt worden kan kunnen moet moeten wil willen
zeer meer minder elke alle andere
twee drie vier vijf zes zeven acht negen tien
"""
_GLUE = {'de': _GLUE_DE, 'es': _GLUE_ES, 'it': _GLUE_IT,
         'pt': _GLUE_PT, 'fr': _GLUE_FR, 'nl': _GLUE_NL}
NO_END = set((_GLUE_EN + _GLUE.get(LANG, '')).split())

# A cue must not START with any of these: they finish the clause the previous cue began, so breaking
# in front of one leaves the subject on one card and its verb on the next - "Behind that plate" then
# "is a hole in the tub wall". Only 'of' was listed, which caught the noun-phrase case and missed every
# linking verb. Punctuation still wins: if the previous cue ended on a comma or a full stop the clause
# was already finished, and split_into_cues checks that first.
BIND_BACK = {
    'of',
    # linking and auxiliary verbs - always the tail of a clause that started earlier
    'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'has', 'have', 'had', 'does', 'do', 'did',
    'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might', 'must',
}

def _fold(s):
    """Strip accents: 'für' -> 'fur', 'más' -> 'mas'. Without this bare() DELETED every accented
    letter ('für' -> 'fr'), so no non-English glue word could ever match its list."""
    s = s.replace(chr(223), 'ss')                                  # ß -> ss
    return ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c))

def bare(tok):
    return re.sub(r"[^a-z']", '', _fold(tok.lower()))

# French ELISION (c'est, j'ai, l'eau, d'un, n'est, qu'il, s'il, m'/t', jusqu'/lorsqu'/puisqu'/quoiqu') — an
# elided word ALWAYS binds forward to the next word, so a cue/line must never END on it (that's what put a bare
# "C'est" on its own subtitle: a micro low-energy dip after it was read as a pause, and — unlike the English glue
# words in NO_END — nothing protected the French elision). Matches both the straight ' and the curly ' apostrophe.
_ELISION = re.compile(r"^(?:c|j|l|d|m|t|n|s|qu|jusqu|lorsqu|puisqu|quoiqu)['’]", re.I)
# Pure conjunctions. These keep the ban even with a comma — a line ending on "and," or "und," reads badly
# whatever the punctuation says.
_CONJ = set("""
and or but nor yet so
und oder aber denn sondern
et ou mais donc ni car
y e o u pero sino
ma oppure pero
mas porem
en of maar want
""".split())


def ends_ok(tok):
    """Can this token END a line or a cue? A glue word normally cannot — but PUNCTUATION OUTRANKS THE
    WORD. Once it carries a comma the clause is finished, and that is the most natural break there is.
    German is where the flat ban really hurt: it puts the verb at the end of a subordinate clause, right
    before the comma, so "…dass Sie absolut keine Zweifel haben, wenn…" had its best break rejected
    (haben is an auxiliary, so it was in the glue list) and got cut between the object and its verb
    instead — "…keine Zweifel" / "haben, wenn…". Same for "Ich möchte,". Every language benefits; only
    the pure conjunctions above stay banned."""
    b = bare(tok)
    if b not in NO_END:
        return True
    if b in _CONJ:
        return False
    return bool(re.search(r"[,;:—–]$", tok.rstrip(_TRAIL_Q)))


def binds_forward(tok):
    """True if `tok` must NOT end a cue/line: a glue word with nothing to close it, or a French elision."""
    return (not ends_ok(tok)) or bool(_ELISION.match(tok.strip()))

def split_by_cap(toks, cap, soft=None):
    """split a token list into chunks each <= cap chars, preferring audio pauses then
    punctuation; on a forced break, back off so the chunk doesn't end on a glue word or
    start the next chunk with a binder. `soft[j]` marks an audio pause after token j."""
    chunks, i, n = [], 0, len(toks)
    while i < n:
        j, length = i, 0
        best_end, best_score, best_len = -1, 0, 0
        while j < n:
            w = toks[j][0]
            add = len(w) + (1 if j > i else 0)
            if length + add > cap and j > i:
                break
            length += add
            sc = break_score(w)
            if soft is not None and soft[j]:
                sc = 3                                # audio pause after this word = best line break
            if sc >= 1 and sc >= best_score:
                best_score, best_end, best_len = sc, j + 1, length
            j += 1
        if j >= n:
            chunks.append(toks[i:n]); break
        # (A) honour a break only if the line is reasonably full, so we don't leave a stub
        # line like "What's more," (12 chars). Audio pauses (score 3) may break a bit shorter.
        min_fill = cap * (0.30 if best_score >= 3 else 0.40 if best_score >= 2 else 0.45)
        if best_end > i and best_len >= min_fill:
            end = best_end
        else:
            end = j                                   # forced hard break at max fill
            # (B) don't END on a glue word, and don't START the next line with a binder
            # like "of" — keeps units such as "University of California" together.
            while end - 1 > i and ((not ends_ok(toks[end - 1][0])) or
                                   (end < n and bare(toks[end][0]) in BIND_BACK)):
                end -= 1
        chunks.append(toks[i:end]); i = end
    return chunks

def get_silences():
    """ground-truth silence intervals from the audio waveform via ffmpeg silencedetect.

    The log is cached, and the cache used to be keyed on nothing but "does the file exist". Drop a new
    voice-over into a folder that already has one — a re-recorded VSL, a second FAQ in the same Studio
    scope — and the run silently reused the FIRST audio's pauses. With almost no pauses to break on,
    cue boundaries fall back to the character limit, which reads as captions splitting mid-phrase
    ("…absolut keine Zweifel" / "haben, wenn…"). Seen for real: an 18-day-old log with 6 pauses used
    for a 287s German voice-over that actually has 121. Key it to the audio itself."""
    try:
        _st = os.stat(AUDIO)
        sig = "# audio %d %d %s" % (_st.st_size, int(_st.st_mtime), NOISE_DB)
    except OSError:
        sig = "# audio ?"
    fresh = False
    if os.path.exists(SIL_LOG):
        try:
            with open(SIL_LOG, encoding='utf-8', errors='ignore') as f:
                fresh = any(ln.rstrip('\n') == sig for ln in f)
        except OSError:
            fresh = False
    if not fresh:
        with open(SIL_LOG, 'w', encoding='utf-8') as log:
            subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', AUDIO,
                            '-af', f'silencedetect=noise={NOISE_DB}:d=0.10', '-f', 'null', '-'],
                           stderr=log, stdout=subprocess.DEVNULL)
        with open(SIL_LOG, 'a', encoding='utf-8') as log:     # stamp it LAST — the parser ignores the line
            log.write('\n' + sig + '\n')
    ints, s = [], None
    for ln in open(SIL_LOG, encoding='utf-8', errors='ignore'):
        m = re.search(r'silence_start: ([\d.]+)', ln)
        if m: s = float(m.group(1))
        m = re.search(r'silence_end: ([\d.]+) \| silence_duration: ([\d.]+)', ln)
        if m: ints.append((s, float(m.group(1)), float(m.group(2))))
    return ints

def map_silences(timed, silences, min_dur):
    """indices i such that a silence (>= min_dur) maps to the word boundary after word i.
    ROBUST RULE (fixes word-bleed): a real pause [ss,se] cuts AFTER the last word that BEGINS
    before the pause starts. Any word whose ONSET falls after the pause belongs to the NEXT cue,
    so a post-pause word can never leak into the previous cue (nor make it end early). Uses word
    ONSETS (steadier than ASR word-ends) with a small tolerance, instead of the old
    nearest-gap-midpoint mapping that drifted by ~1 word."""
    n = len(timed)
    onsets = [timed[i][1] for i in range(n)]          # word start times (monotonic)
    def is_punct(w): return not re.search(r'[A-Za-z0-9]', w)
    cuts = {}                                         # {cut-after index i: silence_end (speech onset)}
    for ss, se, dur in silences:
        if dur < min_dur:
            continue
        i = bisect.bisect_left(onsets, ss) - 1        # last word whose ONSET is before the pause starts
        if i < 0 or i >= n - 1:
            continue
        # don't cut right after a glue word (and/for/the/to/is/next…): a real phrasing
        # pause lands after a content word; a micro breath after a glue word is noise.
        gi = i
        while gi > 0 and is_punct(timed[gi][0]):
            gi -= 1
        w0 = timed[gi][0]
        if not ends_ok(w0):                          # glue word with nothing closing it -> never cut after it
            continue
        if _ELISION.match(w0.strip()) and dur < ELISION_KEEP_MAX:
            continue                                 # French elision + only a SHORT breath/micro pause -> keep it with the
                                                     # next word; a LONGER deliberate pause still splits (respects delivery)
        while i + 1 < n - 1 and is_punct(timed[i + 1][0]):
            i += 1                                    # keep trailing punctuation with preceding
        cuts[i] = se                                  # next cue starts when speech resumes (silence_end)
    return cuts

def toklen(toks, a, b):
    return sum(len(toks[k][0]) for k in range(a, b)) + max(0, b - a - 1)

def wrappable(toks, a, b):
    """can toks[a:b] fit in <=2 lines of <=MAX_LINE chars?"""
    if toklen(toks, a, b) <= MAX_LINE:
        return True
    for k in range(a + 1, b):
        if toklen(toks, a, k) <= MAX_LINE and toklen(toks, k, b) <= MAX_LINE:
            return True
    return False

def split_into_cues(toks, soft):
    """Split a segment into cues (each <= CUE_MAX chars = at most 2 lines). When a segment is too long and must
    break into several cues, aim for BALANCED cues (near-equal length) and snap each break to a meaningful
    boundary NEAR that balance point (soft pause > strong punct > comma > word) — never dumping the bulk into the
    first cue and leaving a tiny short tail. Breaks land on WORD boundaries, so cues stay voice-over-synced."""
    cues, starts, i, n = [], [], 0, len(toks)
    while i < n:
        rem = sum(len(toks[k][0]) + (1 if k > i else 0) for k in range(i, n))
        if rem <= CUE_MAX and wrappable(toks, i, n):     # the rest fits in one cue, in 2 lines of <=42
            cues.append(toks[i:n]); starts.append(i); break
        cues_left = max(2, -(-rem // CUE_MAX))          # ceil: how many cues the remainder still needs
        target = rem / cues_left                        # balanced target length for THIS cue
        length, best, hard = 0, None, i + 1
        for j in range(i, n):
            add = len(toks[j][0]) + (1 if j > i else 0)
            if length + add > CUE_MAX and j > i:
                break
            length += add
            # R3: 76 chars is not the only limit — the cue must also SPLIT into 2 lines of <=42.
            # "of course" (76 chars, but one 50-char word + a 25-char word) has no legal 2-line
            # split, and letting it grow is what pushed lines past 42 on screen.
            fit2 = wrappable(toks, i, j + 1)
            if fit2:
                hard = j + 1                            # furthest word that still fits (fallback)
            if j + 1 >= n:
                continue                                # don't end this cue on the segment's very last token
            if not fit2:
                continue
            if (not ends_ok(toks[j][0])) or bare(toks[j + 1][0]) in BIND_BACK:
                continue                                # never end on a glue word / right before a binder
            sc = 3 if soft[j] else break_score(toks[j][0])   # pause > strong punct > comma > plain word (0)
            cost = abs(length - target) - sc * 6        # closest to the balance point, pulled toward real breaks
            if best is None or cost < best[0]:
                best = (cost, j + 1)
        if best is not None:
            end = best[1]
        else:                                           # no clean boundary in range → hard cut, backed off glue words
            end = hard
            while end - 1 > i and ((not ends_ok(toks[end - 1][0])) or
                                   (end < n and bare(toks[end][0]) in BIND_BACK)):
                end -= 1
        cues.append(toks[i:end]); starts.append(i); i = end
    return cues, starts

def wrap2(toks, soft):
    """wrap a cue into 1 or 2 balanced lines. Option B: minimise imbalance, but prefer a
    punctuation/pause boundary when it is near-balanced; avoid ending a line on a glue word
    or starting the next line with a binder ('of')."""
    n = len(toks)
    if n == 1 or toklen(toks, 0, n) <= MAX_LINE:
        return [toks]
    best = None
    for k in range(1, n):
        l1, l2 = toklen(toks, 0, k), toklen(toks, k, n)
        over = max(0, l1 - MAX_LINE) + max(0, l2 - MAX_LINE)   # chars past the 42 limit
        sc = 3 if soft[k - 1] else break_score(toks[k - 1][0])
        penalty = (60 if bare(toks[k][0]) in BIND_BACK else 0) + \
                  (25 if not ends_ok(toks[k - 1][0]) else 0)
        # <=42 dominates everything else; then balance; a punctuation/pause break is worth ~5 chars
        cost = over * 1000 + abs(l1 - l2) - sc * 5 + penalty
        if best is None or cost < best[0]:
            best = (cost, k)
    k = best[1]
    return [toks[:k], toks[k:]]

def segment(timed, cuts, soft):
    # 1) split into segments at sentence-ends AND at real audio silences (>= SILENCE_MIN).
    segments, cur, cur_idx = [], [], []
    for idx, tk in enumerate(timed):
        cur.append(tk); cur_idx.append(idx)
        w = tk[0]
        sent = is_sent_end(w)
        # A full stop followed by a LOWERCASE word is not the end of a sentence — "Und Helene F. fügt
        # hinzu", an initial inside a name. Every language we caption opens a sentence with a capital,
        # so the next word's case is a better witness than the period, and it catches the abbreviations
        # no list will ever have. A real audio pause still cuts, whatever the spelling says.
        if sent and w.rstrip(_TRAIL_Q).endswith('.') and idx + 1 < len(timed):
            if timed[idx + 1][0].lstrip('„«‹“‘"\'¿¡([{')[:1].islower():
                sent = False
        end_here = (idx in cuts) or sent
        if end_here and re.match(r'^\d{1,2}\.$', w):
            if len(cur) == 1:
                end_here = False                      # keep a leading ordinal with its sentence
            elif cur[-2][0].rstrip('"”\'’)').endswith(':'):
                # A numbered list opened by a colon — "…zusammengefasst: 1. Ist CitruSlim…". The colon is
                # not a sentence end, so the marker was not run-initial and the guard above missed it,
                # leaving "…zusammengefasst: 1." stranded on one caption while the question started on
                # the next. Close the run BEFORE the marker and let it open the question, like the other
                # items in the list (which DO follow a full stop and were already handled).
                segments.append((cur[:-1], cur_idx[:-1]))
                cur, cur_idx = [cur[-1]], [cur_idx[-1]]
                end_here = False
        if end_here:
            segments.append((cur, cur_idx)); cur, cur_idx = [], []
    if cur: segments.append((cur, cur_idx))
    # 1b) A SILENCE IS NOT ALWAYS A CLAUSE END. The speaker breathing after "Behind that plate" cut a
    # segment there, so "is a hole in the tub wall" became a segment of its own and the subject ended up
    # on one card with its verb on the next. split_into_cues can never repair that - it only ever sees
    # one segment at a time - so the join has to happen here. Only when the previous segment did NOT
    # finish a sentence: a full stop really is an end, whatever word follows it.
    joined = []
    for seg in segments:
        toks, idxs = seg
        if joined and toks and bare(toks[0][0]) in BIND_BACK:
            prev_toks = joined[-1][0]
            if prev_toks and not is_sent_end(prev_toks[-1][0]):
                joined[-1] = (prev_toks + toks, joined[-1][1] + idxs)
                continue
        joined.append(seg)
    segments = joined
    # 2) each segment -> cues (pause/length aware) -> each cue wrapped into 2 balanced lines.
    #    Track each cue's first-token global index so its start can snap to a pause onset.
    cues, cue_start_idx = [], []
    for toks, idxs in segments:
        soft_bools = [idxs[m] in soft for m in range(len(toks))]
        cue_toks, starts = split_into_cues(toks, soft_bools)
        for ct, sr in zip(cue_toks, starts):
            cues.append(wrap2(ct, soft_bools[sr:sr + len(ct)]))
            cue_start_idx.append(idxs[sr])
    return cues, cue_start_idx

# ---------------- merge too-short cues (readability) ----------------
def merge_short_cues(cues, starts, timed, last_end, min_disp=1.1):
    """A lone short word (e.g. 'Then,', 'fat.') can land on its own cue and flash for <0.7s — too fast to
    read. Merge any cue that would DISPLAY shorter than min_disp into an adjacent cue, as long as the
    combined text still fits 2 lines. Only concatenates tokens (never changes wording), so text stays
    100% script. Display time = next cue's start − this cue's start (NO_GAP), so it matches what's on screen."""
    def flat(cue): return [t for line in cue for t in line]
    def disp(i):
        s_i = timed[starts[i]][1]
        s_n = timed[starts[i + 1]][1] if i + 1 < len(starts) else last_end
        return s_n - s_i
    ORPHAN_KEEP_PAUSE = 0.6   # a real spoken pause (s) around a short cue justifies leaving it on its own
    ORPHAN_MIN = 18           # R1: a cue shorter than this many chars is an orphan tail, not a caption
    def orphan(i):
        # R1 — NO ORPHANS. A stub cue ("sont", "C'est", "davon aus.") reads as broken — merge it into a
        # neighbour… UNLESS the voice-over actually PAUSED noticeably right before or after it (a
        # deliberate beat). Measured in CHARACTERS, not "is it exactly one token": a two-word tail
        # ("davon aus.", "Jahre alt.") looks just as stranded but used to slip through.
        # A genuine one-word sentence ("Oui.") needs no special case here — it can only merge across a
        # sentence end, and the merge loop below refuses that (R2), so it stays on its own cue.
        fl = flat(cues[i])
        if toklen(fl, 0, len(fl)) >= ORPHAN_MIN:
            return False
        gi = starts[i]                                            # global index of the cue's FIRST word
        gl = gi + len(fl) - 1                                     # …and its LAST
        before = (timed[gi][1] - timed[gi - 1][2]) if gi > 0 else 0.0
        nxt = starts[i + 1] if i + 1 < len(starts) else None
        after = (timed[nxt][1] - timed[gl][2]) if nxt is not None else 0.0
        return max(before, after) < ORPHAN_KEEP_PAUSE            # small gaps → force-merge; big pause → keep
    skip, guard = set(), 0
    while len(cues) > 1 and guard < 100000:
        guard += 1
        idx = next((i for i in range(len(cues)) if i not in skip and (disp(i) < min_disp or orphan(i))), None)
        if idx is None:
            break
        merged = False
        for j in (idx - 1, idx + 1):                      # prefer merging back into the previous cue
            if not (0 <= j < len(cues)):
                continue
            a, b = (j, idx) if j < idx else (idx, j)
            if is_sent_end(flat(cues[a])[-1][0]):         # NEVER merge across a sentence end — no caption may hold
                continue                                  # the tail of one sentence AND the head of the next
            combo = flat(cues[a]) + flat(cues[b])
            if wrappable(combo, 0, len(combo)):           # still fits <=2 lines of <=MAX_LINE
                cues[a] = wrap2(combo, [False] * len(combo))
                del cues[b]; del starts[b]                # keep cue a's (earlier) start index
                skip = set(); merged = True               # indices shifted → reset the skip set
                break
        if not merged:
            skip.add(idx)                                 # both neighbours too long to merge — leave it
    return cues, starts

# opening quotes / brackets LEAD the phrase they open — they must never be stranded at the END of a cue.
_OPEN_PUNCT = set('«"“‘‹¿¡([{„‟')
def lead_open_punct(cues, starts):
    """Move an opening mark («, ", ¿, (, …) stuck at the END of a cue to the FRONT of the next cue, so it sits
    with the phrase it opens (fixes « / a quote-open landing on the previous caption)."""
    for i in range(len(cues) - 1):
        flat_i = [t for line in cues[i] for t in line]
        moved = False
        while len(flat_i) > 1 and (flat_i[-1][0].strip() in _OPEN_PUNCT):
            tok = flat_i.pop()
            flat_next = [t for line in cues[i + 1] for t in line]
            flat_next.insert(0, tok)
            cues[i + 1] = wrap2(flat_next, [False] * len(flat_next))
            moved = True
        if moved:
            cues[i] = wrap2(flat_i, [False] * len(flat_i))
    return cues, starts

# a token with no letter or digit in it is never SPOKEN: – — … » " ) etc.
NOSPEAK = re.compile(r'^[^\w]+$', re.U)
def trail_nonspoken(cues, starts):
    """R6 — a non-spoken mark must not OPEN a cue. It has no alignment of its own, so it inherits the
    PREVIOUS word's end time: a moment that sits inside the pause. Opening a cue on it pops the caption
    up before the voice comes back (that is the dash that appeared ~180 ms early). Hand it to the end of
    the previous cue instead, where it reads as "…continues". Two limits: never across a sentence end
    (R2 — the mark belongs to its own sentence), and never if it would push that cue past 2x42 (R3).
    When the mark is the sentence's FIRST token there is nowhere to move it; R5 then makes sure it does
    not get to set the time."""
    _fl = lambda c: [t for line in c for t in line]
    _re = lambda ts: wrap2(ts, [False] * len(ts))
    i = 0
    while i < len(cues):
        flat_i = _fl(cues[i])
        # (B) A cue made of NOTHING BUT marks — a caption that reads "…" and holds a slot on screen
        # with no speech under it at all. It happens when the script has a bare ellipsis between two
        # sentences: is_sent_end() treats it as a sentence of its own, segment() gives it a cue, and
        # the merge step then refuses to touch it (R2) precisely because it looks like a sentence.
        # It is not one. Hand it to a neighbour — previous first (it reads as a trailing "…").
        if flat_i and all(NOSPEAK.match(t[0].strip()) for t in flat_i):
            def _back(_i=i, _f=flat_i):
                if _i <= 0:
                    return False
                p = _fl(cues[_i - 1])
                if not wrappable(p + _f, 0, len(p) + len(_f)):
                    return False
                cues[_i - 1] = _re(p + _f); del cues[_i]; del starts[_i]
                return True
            def _fwd(_i=i, _f=flat_i):
                if _i + 1 >= len(cues):
                    return False
                n = _fl(cues[_i + 1])
                if not wrappable(_f + n, 0, len(_f) + len(n)):
                    return False
                cues[_i + 1] = _re(_f + n); starts[_i + 1] = starts[_i]   # the cue now begins at the mark
                del cues[_i]; del starts[_i]
                return True
            # Previous cue first — a trailing "…" reads as "…continues". EXCEPT when that cue already
            # ends in a mark: a script written "Oberschenkeln … … und verwandelt" then stacked both on
            # one caption ("Oberschenkeln … …") instead of one closing it and the other opening the next.
            prev_ends_mark = i > 0 and bool(NOSPEAK.match(_fl(cues[i - 1])[-1][0].strip()))
            order = (_fwd, _back) if prev_ends_mark else (_back, _fwd)
            if order[0]() or order[1]():
                continue                                 # list shrank: re-test this index
        # (A) A cue that OPENS on a mark but does carry speech: give the mark to the previous cue.
        if i > 0:
            prev = _fl(cues[i - 1])
            if not is_sent_end(prev[-1][0]):             # R2: never across a sentence boundary
                moved = 0
                while (len(flat_i) > 1
                       and NOSPEAK.match(flat_i[0][0].strip())
                       and flat_i[0][0].strip() not in _OPEN_PUNCT   # those LEAD their phrase (above)
                       and wrappable(prev + flat_i[:1], 0, len(prev) + 1)):
                    prev.append(flat_i.pop(0)); moved += 1
                if moved:
                    cues[i - 1] = _re(prev)
                    cues[i] = _re(flat_i)
                    starts[i] += moved                   # the cue now begins at a later token
        i += 1
    return cues, starts

# ---------------- srt ----------------
def wrap(text):
    words = text.split()
    if len(text) <= MAX_LINE or len(words) == 1:
        return text
    # 2-line split minimising the longer line (tiebreak: prefer break after punctuation)
    best = None
    for k in range(1, len(words)):
        l1 = ' '.join(words[:k]); l2 = ' '.join(words[k:])
        cost = (max(len(l1), len(l2)), 0 if break_score(words[k-1]) else 1, abs(len(l1)-len(l2)))
        if best is None or cost < best[0]:
            best = (cost, l1 + '\n' + l2)
    return best[1]

def ts(sec):
    if sec < 0: sec = 0
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def write_srt(cues, overrides):
    n = len(cues)
    MAX_SNAP = 0.6                                     # only trust a silence onset within this of the ASR word start
    def toks(i):    return [t for line in cues[i] for t in line]
    # start = ffmpeg silence onset (speech resume) if it is close to the ASR first-word start;
    # if the silence mapping drifted too far, it's unreliable -> fall back to the ASR word start.
    st = []
    for i in range(n):
        # R5 — TIMING COMES FROM SPEECH. A cue can still open on a mark that is never spoken (a
        # sentence-initial – or « that R6 was not allowed to move back). That token has no alignment,
        # so timed_script_tokens handed it the PREVIOUS word's end — a timestamp that lands inside the
        # pause. Take the start from the first token that is actually voiced. The mark still shows on
        # screen; it just doesn't decide when the caption appears.
        tk = toks(i)
        f = next((k for k in range(len(tk)) if not NOSPEAK.match(tk[k][0].strip())), 0)
        ws = tk[f][1]
        ov = overrides[i]
        st.append(ov if (ov is not None and abs(ov - ws) <= MAX_SNAP) else ws)
    last_end = toks(n - 1)[-1][2]
    # DE-CRAM: whole-audio alignment sometimes fails on a hard multi-minute stretch (music bed
    # under the VO, a fast passage) and piles the ENTIRE tail of the script onto the stretch's
    # end timestamp — dozens of cues sharing ~1s, preceded by a huge empty gap. That reads as a
    # frozen caption then a blank then a burst. Detect a large forward gap whose following cues
    # are crammed into a tiny window, and redistribute those starts evenly across the gap so the
    # captions track the ongoing speech instead. Safety-gated so normal FAQs never trigger.
    DECRAM_GAP, DECRAM_WIN, DECRAM_MIN = 15.0, 5.0, 0.40
    for i in range(n - 1):
        if st[i+1] - st[i] < DECRAM_GAP:
            continue
        j = i + 1                                     # extend over the crammed cluster
        while j + 1 < n and st[j+1] - st[i+1] < DECRAM_WIN:
            j += 1
        if j - i < 3:                                 # not a cluster, just an isolated jump
            continue
        lo = st[i] + DECRAM_MIN
        hi = last_end if j >= n - 1 else st[j+1]
        count = j - i
        if hi - lo <= count * DECRAM_MIN:             # no room to actually spread them out
            continue
        gap = st[i+1] - st[i]
        step = (hi - lo) / count
        for m in range(i + 1, j + 1):
            st[m] = lo + step * (m - i)
        print(f"[decram] spread {count} crammed cues across a {gap:.0f}s gap", flush=True)
    # keep starts non-decreasing
    for i in range(1, n):
        if st[i] < st[i-1]:
            st[i] = st[i-1]
    # only fix TRUE zero-width cues from alignment gaps (dur < COLLAPSE); pull that one start
    # earlier without cascading into well-separated cues (this is what caused the old drift).
    # only fix true collapses; pull the short cue's start earlier (borrow from the previous
    # cue, cascading left only through equally-collapsed cues). min(nxt,…) keeps it monotonic.
    COLLAPSE, MIN_DISPLAY = 0.15, 0.6
    for i in range(n - 1, -1, -1):
        nxt = st[i+1] if i + 1 < n else last_end
        if nxt - st[i] < COLLAPSE:
            floor = st[i-1] + COLLAPSE if i > 0 else 0.0
            st[i] = min(nxt, max(nxt - MIN_DISPLAY, floor))
    # guarantee visibility: no cue shorter than MIN_SHOW. Only fires at the few hard ASR
    # alignment collapses (where ~dozens of words share one timestamp); elsewhere cues are
    # already well separated, so this is a tiny bounded forward nudge, not a global shift.
    MIN_SHOW = 0.40
    for i in range(n - 1):
        if st[i+1] - st[i] < MIN_SHOW:
            st[i+1] = st[i] + MIN_SHOW
    if last_end - st[-1] < MIN_DISPLAY:
        last_end = st[-1] + MIN_DISPLAY
    raw_ends = ([st[i+1] for i in range(n - 1)] + [last_end]) if NO_GAP \
               else [toks(i)[-1][2] for i in range(n - 1)] + [last_end]
    # SAFETY CAP: no caption may stay longer than MAX_SHOW. A huge gap to the next cue means an alignment
    # collapse (e.g. an English model on French audio piling the tail onto one timestamp) — cap it so a single
    # caption never freezes on screen for tens of seconds; the frame just holds no caption until the next.
    MAX_SHOW = 7.0
    ends = [min(raw_ends[i], st[i] + MAX_SHOW) for i in range(n)]
    with open(OUT, 'w', encoding='utf-8') as f:
        for i in range(n):
            text = '\n'.join(' '.join(t for t, _, _ in line) for line in cues[i])
            f.write(f"{i+1}\n{ts(st[i])} --> {ts(ends[i])}\n{text}\n\n")
    print(f"[srt] {n} cues -> {OUT}", flush=True)

# ---------------- main ----------------
if __name__ == '__main__':
    if '--transcribe' in sys.argv:              # transcription-only pass (reconcile the script to the VO first)
        transcribe_audio()
        sys.exit(0)
    text = spoken_script()
    script_tokens = text.split()
    if '--resegment' in sys.argv and os.path.exists(WORDS_CACHE):
        aligned = load_cached_words()
        print(f"[cache] loaded {len(aligned)} aligned words")
    else:
        aligned = align_words(text)
    timed = timed_script_tokens(script_tokens, aligned)
    # ensemble: patch this model's alignment-collapse regions with the small model's timing.
    # English uses the tuned small.en cache; other languages use the multilingual small cache.
    _small = "small.en" if LANG == "en" else "small"
    SECONDARY_CACHE = f"words_{_small.replace('.', '_')}_vad.tsv"
    # The two-model ensemble below only ever existed to repair Whisper alignment collapses.
    # MMS-FA does not collapse, and a stale words_small_vad.tsv from an OLD Whisper run would
    # now corrupt good timings — so it is off unless explicitly asked for.
    if os.environ.get("VSL_ENSEMBLE") == "1" and os.path.exists(SECONDARY_CACHE) and SECONDARY_CACHE != WORDS_CACHE:
        timed_sec = timed_script_tokens(script_tokens, load_words(SECONDARY_CACHE))
        # Normally the final (medium) model is the base and the small model patches its collapses.
        # BUT if the final model's alignment is substantially MORE broken than the small model's
        # (it failed a long tail -> words crammed at the audio end / jumping around), that base is
        # unusable. Fall back to the small model as the base and patch IT with the final model.
        h_pri, h_sec = alignment_health(timed), alignment_health(timed_sec)
        if h_sec > h_pri + 0.08:
            print(f"[ensemble] final model unhealthy ({h_pri:.2f}) vs small ({h_sec:.2f}) -> using small as the base", flush=True)
            timed = merge_timings(timed_sec, timed)
        else:
            timed = merge_timings(timed, timed_sec)
        # Write the MERGED (healthy) per-word timings back to this model's cache, so downstream consumers
        # that read words_<model>_vad.tsv (the dashboard's mid-cue word_starts refinement) also get the
        # repaired timeline instead of the raw, possibly-collapsed model output.
        try:
            with open(WORDS_CACHE, "w", encoding="utf-8") as _wf:
                for (_t, _s, _e) in timed:
                    _wf.write(f"{_s:.3f}\t{_e:.3f}\t{_t}\n")
        except Exception:
            pass
    silences = get_silences()
    cuts = map_silences(timed, silences, SILENCE_MIN)          # cue/segment cuts (bigger pauses)
    onset_map = map_silences(timed, silences, SOFT_PAUSE)      # {i: speech-onset} for ALL pauses >= SOFT_PAUSE
    soft = set(onset_map)                                       # also used as line-break hints
    print(f"[silence] {len(cuts)} cue cuts (>= {SILENCE_MIN}s), {len(soft)} pauses (>= {SOFT_PAUSE}s)")
    cues, cue_start_idx = segment(timed, cuts, soft)
    # merge cues that would flash too briefly (a lone short word) into a neighbour → readable on screen
    cues, cue_start_idx = merge_short_cues(cues, cue_start_idx, timed, timed[-1][2] if timed else 0.0, min_disp=MERGE_MIN_DISP)
    cues, cue_start_idx = lead_open_punct(cues, cue_start_idx)   # « / opening quotes lead the NEXT cue, never trail
    cues, cue_start_idx = trail_nonspoken(cues, cue_start_idx)   # R6: – … » never OPEN a cue
    # R4 — THE CAPTION TEXT IS THE SCRIPT, WORD FOR WORD. Every step above only ever concatenates or
    # moves whole tokens, so a mismatch is a real bug (a dropped tail, two lists paired by index that
    # drifted apart). This used to only PRINT False, after the file was already written — and a
    # silently incomplete SRT is far worse than none, because a whole timeline gets synced to it.
    # Check first, and refuse to write.
    joined = [t for c in cues for line in c for (t, _, _) in line]
    if joined != script_tokens:
        _d = list(difflib.unified_diff(script_tokens, joined, 'script', 'cues', n=0, lineterm=''))[:14]
        raise SystemExit("[srt] ABORT: caption text != script (script %d words, cues %d)\n%s"
                         % (len(script_tokens), len(joined), '\n'.join(_d)))
    # snap each cue's start to the pause onset just before it (if any); write_srt sanity-guards it
    overrides = [onset_map.get(cue_start_idx[c] - 1) for c in range(len(cues))]
    write_srt(cues, overrides)
    print("TEXT == SCRIPT word-for-word: True",
          "| cues:", len(cues), "| script words:", len(script_tokens))
