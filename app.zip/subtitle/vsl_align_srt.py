#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Yol 1: word-level forced alignment of the exact (cleaned) script to the audio,
then re-segment subtitles ourselves by SCRIPT punctuation (independent of Premiere).

Pipeline:
  1. Build spoken-only script text (strip SOURCES / version markers / VO note / VERSION B).
  2. MMS forced alignment: audio + exact text -> measured per-word (start,end).
  3. Transfer word timings onto our EXACT script tokens (difflib) so display text stays 100% script.
  4. Build one speech-v998 phrase plan from measured pauses and protected language units.
     Reading width is a soft preference; line wrapping does not create new cues.
  5. Write SRT plus the canonical phrase plan; each cue holds until the next voiced onset.
"""
import re, sys, zipfile, difflib, os, subprocess, bisect, unicodedata, json, hashlib
from pathlib import Path
from text_boundaries import normalize_spacing, joined_words

# Paths can be overridden via env vars (used by the dashboard integration);
# fall back to the original hardcoded defaults for standalone CLI use.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # so _mms_align imports when CWD is the project dir
AUDIO = os.environ.get("VSL_AUDIO") or r"C:\Users\Desktop\Desktop\CitruSlim_EN_VSL.mp3"
DOCX  = os.environ.get("VSL_DOCX")  or r"C:\Users\Desktop\Desktop\CitruSlim VSL EN2.docx"
OUT   = os.environ.get("VSL_OUT")   or r"C:\Users\Desktop\Desktop\CitruSlim_EN_VSL_ALIGNED.srt"
_args = sys.argv[1:]
MODEL = next((a for a in _args if not a.startswith('--')), "base.en")
VAD   = '--vad' in _args                  # voice-activity detection -> better silence/pause boundaries
LANG  = (os.environ.get("VSL_LANG") or "en").strip() or "en"   # Whisper language (fr/de/es/…); default English
WORDS_CACHE = f"words_{MODEL.replace('.', '_')}{'_vad' if VAD else ''}.tsv"
_QUALITY_REPORTED = False
_QUALITY_PASSED = False


def quality_failure(error, diagnostics=None):
    """A rejected measurement is a review result, never a replacement clock."""
    global _QUALITY_REPORTED, _QUALITY_PASSED
    from caption_quality import alignment_failure_report, persist_report
    report = alignment_failure_report(error, diagnostics=diagnostics, lang=LANG)
    persist_report(Path(OUT).parent, report)
    _QUALITY_REPORTED = True
    _QUALITY_PASSED = False
    Path(OUT).with_name('alignment-error.json').write_text(
        json.dumps({'error':str(error),'quality_report':'caption-quality.json'},ensure_ascii=False),'utf8')
    return report


def audit_subtitles(text, aligned, canonical, bounds):
    global _QUALITY_REPORTED, _QUALITY_PASSED
    from caption_quality import audit_candidate, persist_report
    print('[quality] Checking Subtitles', flush=True)
    tokens=canonical['tokens']
    scenes=[dict(token_index=i,frame=round(tokens[i]['start']*60),fps=60)
            for i in sorted(set(bounds)) if 0<i<len(tokens)]
    report=audit_candidate(AUDIO,text,aligned,canonical,LANG,Path(OUT).parent,
        cache_dir=os.environ.get('VSL_CAPTION_QA_CACHE'),scene_bounds=scenes)
    persist_report(Path(OUT).parent,report)
    _QUALITY_REPORTED=True
    if report.get('status')!='pass' or report.get('passed') is not True:
        from caption_quality import audit_structure
        from phrase_store import serialize_srt
        canonical=report.get('candidate_plan') or canonical
        structure=audit_structure(text,aligned,canonical,LANG,scene_bounds=scenes)
        if structure.get('passed') is True:
            Path(OUT).with_name('subtitles-review.srt').write_text(serialize_srt(canonical),'utf8')
        issues=report.get('issues') or []
        message=next((str(i.get('message')) for i in issues if i.get('severity') in ('error','review') and i.get('message')),None)
        raise ValueError(message or 'Subtitle checks require review. Previous subtitles were preserved.')
    print('[quality] Subtitle checks passed', flush=True)
    _QUALITY_PASSED=True
    return report


def save_word_cache(text, words):
    target=Path(WORDS_CACHE)
    temporary=target.with_name(target.name+'.tmp')
    temporary.write_text(''.join('%.3f\t%.3f\t%s\n' % (a,b,t) for t,a,b in words),'utf8')
    os.replace(temporary,target)
    policy=Path(WORDS_CACHE+'.policy.json')
    temporary=policy.with_name(policy.name+'.tmp')
    temporary.write_text(json.dumps(word_clock_policy(text),ensure_ascii=False),'utf8')
    os.replace(temporary,policy)


def word_clock_policy(text):
    from speech_forms import VERSION
    audio = Path(AUDIO).resolve()
    try:
        stat = audio.stat()
        identity = [str(audio), stat.st_size, stat.st_mtime_ns]
    except OSError:
        identity = [str(audio)]
    return dict(version=VERSION, measurement='numeric-local-1009', language=LANG,
                text_sha256=hashlib.sha256(text.encode('utf8')).hexdigest(), audio=identity)


def word_cache_is_current(text):
    try:
        return json.loads(Path(WORDS_CACHE + '.policy.json').read_text('utf8')) == word_clock_policy(text)
    except (OSError, ValueError, TypeError):
        return False

MAX_LINE  = 42
MAX_LINES = 2
MAX_CHARS = MAX_LINE * MAX_LINES          # ~84 per cue
CUE_MAX   = 76                            # cap per cue; keeps 2-line cues wrappable within 42 chars
MIN_DUR   = 0.9                           # seconds; extend very short cues if room
NO_GAP    = True                          # each cue ends exactly when the next begins (no blank gaps)
# FAQ / social "punchy" mode (--faq): short, snappy captions — a FEW words per cue on ONE line, broken at natural
# pauses, each tightly timed to its own words. Leaves the main VSL subtitle behaviour untouched.
FAQ_MODE = '--faq' in _args
if FAQ_MODE:
    MAX_LINE = 42; MAX_LINES = 2; CUE_MAX = 74; MIN_DUR = 0.8
    MAX_CHARS = MAX_LINE * MAX_LINES
# FAQ = ONE SENTENCE AT A TIME. Segmentation already breaks at sentence ends; a whole sentence that fits <=2
# lines becomes a single caption, a LONG sentence is split within itself (at pauses/punctuation) into readable
# pieces, and the merge below (which NEVER crosses a sentence boundary) keeps any piece from flashing too fast.
MERGE_MIN_DISP = 1.2 if FAQ_MODE else 1.1
SILENCE_MIN = 0.20                        # ffmpeg-detected silence >= this (sec) forces a cue cut
SOFT_PAUSE  = 0.12                        # smaller silence >= this guides LINE breaks within a cue
ELISION_KEEP_MAX = 0.45                   # a pause SHORTER than this right after a French elision (c'est/j'ai/…) is
                                          # a breath/micro-gap -> keep the elision with the next word (no split); a
                                          # LONGER (deliberate/dramatic) pause is still allowed to split.
SIL_LOG   = 'silence_all.log'             # cached ffmpeg silencedetect log
NOISE_DB  = '-30dB'                       # silence energy threshold

# ---------------- script (spoken only) ----------------
def spoken_script():
    z = zipfile.ZipFile(DOCX); xml = z.read('word/document.xml').decode('utf-8', 'ignore')
    out = []
    for para in re.split(r'</w:p>', xml):
        t = ''.join(re.findall(r'<w:t[^>]*>(.*?)</w:t>', para, re.S))
        t = (t.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
              .replace('&quot;', '"').replace('&apos;', "'"))
        if t.strip():
            out.append(t.strip())
    from text_boundaries import spoken_text
    return spoken_text('\n'.join(out))

# letters of any alphabet: [^a-z0-9] turned "à" / "é" / "è" into "", the same key as a bare "?" or "»", so the
# difflib pairing below could hand a spoken word's timing to a punctuation mark and the other way round.
def norm(w): return re.sub(r'[\W_]', '', unicodedata.normalize('NFC', w.lower()))

# ---------------- alignment ----------------
def align_words(text):
    """Word-level forced alignment with torchaudio MMS-FA. Returns [(token, start, end)].

    Replaces the old stable-ts (Whisper) forced alignment. Whisper INFERS timestamps from
    cross-attention: median ~20 ms but up to ~700 ms out at some sentence starts, and on
    multi-minute audio it collapses runs of words onto one timestamp — which is what the
    tail-repair loop and the two-model ensemble below existed to paper over. MMS-FA is a real
    CTC forced aligner with measured onsets. Imported recordings use bounded source
    windows and an acoustic quality gate; mismatches are not redistributed into invented timings."""
    import _mms_align
    print(f"[align] MMS-FA forced alignment (lang={LANG}) ...", flush=True)
    diagnostics={}
    try:
        plan_path = os.environ.get('VSL_ALIGNMENT_PLAN')
        if plan_path:
            from bounded_alignment import align
            words = align(AUDIO, text, json.loads(Path(plan_path).read_text('utf8')), Path(OUT).parent, diagnostics=diagnostics)
        else:
            words = _mms_align.align(AUDIO, text, diagnostics=diagnostics)
    except (ValueError, RuntimeError) as exc:
        quality_failure(exc,diagnostics)
        raise
    words=[(t,round(a,3),round(b,3)) for t,a,b in words]
    from phrase_store import rows_sha256
    with open(AUDIO,'rb') as stream:audio_sha256=hashlib.file_digest(stream,'sha256').hexdigest()
    Path(OUT).with_name('alignment-evidence.json').write_text(json.dumps(
        dict(schema=1,method='mms-fa',language=LANG,audio_sha256=audio_sha256,clock=word_clock_policy(text),rows_sha256=rows_sha256(words),diagnostics=diagnostics),ensure_ascii=False,indent=2),'utf8')
    print(f"[align] {len(words)} measured words ready for subtitle checks", flush=True)
    # Match the final TSV precision without replacing a last-good cache before QA.
    return words

def transcribe_audio():
    """Plain transcription of the audio (what is ACTUALLY spoken), written to VSL_OUT as text. Used to
    reconcile the user's script against the real voice-over BEFORE aligning, so extra/mismatched script
    text can't derail the alignment."""
    import stable_whisper, json, time, torch
    clock = time.monotonic()
    def progress(done, total):
        data = {"seconds": float(done), "total": float(total), "elapsed": round(time.monotonic()-clock, 2), "updated": time.time()}
        tmp = "transcribe-progress.json.tmp"
        try:
            with open(tmp, "w", encoding="utf8") as f: json.dump(data, f)
            for attempt in range(20):
                try: os.replace(tmp, "transcribe-progress.json"); break
                except PermissionError:
                    if attempt == 19: raise
                    time.sleep(.02)
        except OSError: pass  # UI progress never invalidates transcription.
        print("[transcribe-progress] " + json.dumps(data), flush=True)
    torch.set_num_threads(2)
    print(f"[transcribe] loading model {MODEL}; CPU threads=2", flush=True)
    model = stable_whisper.load_model(MODEL,device='cpu')
    options=dict(language=LANG,initial_prompt=None,condition_on_previous_text=False,
                 temperature=0,word_timestamps=True,fp16=False,vad=VAD)
    try:
        result = model.transcribe(AUDIO,progress_callback=progress,**options)
    except TypeError:
        options.pop('vad',None)
        result = model.transcribe(AUDIO,progress_callback=progress,**options)
    from recognition_cache import persist_recognition
    recognition=result.to_dict()
    recognition['language']=LANG
    record=persist_recognition(AUDIO,LANG,MODEL,'stable_whisper',options,recognition,
        os.environ.get('VSL_CAPTION_QA_CACHE') or Path(OUT).parent/'recognition-cache')
    (Path(OUT).parent/'review-recognition.json').write_text(json.dumps(record,ensure_ascii=False),'utf8')
    txt = (getattr(result, "text", "") or "").strip()
    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(txt)
    print(f"[transcribe] {len(txt.split())} words -> {OUT}", flush=True)

def load_words(path):
    words = []
    for ln in open(path, encoding='utf-8'):
        s, e, t = ln.rstrip('\n').split('\t', 2)
        words.append((t, float(s), float(e)))
    return words

def load_cached_words():
    return load_words(WORDS_CACHE)

def alignment_health(words):
    """0..1 score: fraction of words that are neither COLLAPSED (zero-width) nor OUT-OF-ORDER.
    A whole-audio alignment that failed a long tail (words crammed onto the audio-end timestamp, or
    jumping non-monotonically) scores low. Used to pick the healthier of the two models as the base."""
    n = len(words)
    if not n:
        return 0.0
    good, prev = 0, -1.0
    for (_t, s, e) in words:
        if (e > s + 1e-6) and (s >= prev - 0.25):     # has real duration AND roughly in order
            good += 1
        prev = max(prev, s)
    return good / n

def merge_timings(primary, secondary, pad=3):
    """Both lists are per-SCRIPT-token (start,end) from two models, so index k is the same
    word in each. Whole-audio alignment occasionally COLLAPSES a run of words onto one
    timestamp; different models collapse in different places. Where the primary model
    collapsed (a run of >=3 zero-width tokens), splice in the secondary model's timing for
    that padded window, then repair monotonicity."""
    n = len(primary)
    out = [list(x) for x in primary]                  # [word, start, end]
    i, patched = 0, 0
    while i < n:
        if primary[i][1] >= primary[i][2] - 1e-6:     # zero-width token
            j = i
            while j < n and primary[j][1] >= primary[j][2] - 1e-6:
                j += 1
            if j - i >= 3:                            # a real collapse run
                a, b = max(0, i - pad), min(n, j + pad)
                for k in range(a, b):
                    out[k][1], out[k][2] = secondary[k][1], secondary[k][2]
                patched += 1
                i = b; continue
            i = j
        else:
            i += 1
    for k in range(1, n):                             # repair monotonicity across splices
        if out[k][1] < out[k-1][2]:
            out[k][1] = out[k-1][2]
        if out[k][2] < out[k][1]:
            out[k][2] = out[k][1]
    if patched:
        print(f"[merge] patched {patched} alignment-collapse region(s) from secondary model", flush=True)
    return [(primary[k][0], out[k][1], out[k][2]) for k in range(n)]

# ---------------- transfer timings onto exact script tokens ----------------
def timed_script_tokens(script_tokens, aligned):
    from phrase_store import timed_tokens
    return timed_tokens(script_tokens, aligned)

# ---------------- segmentation ----------------
SENT_END = ('.', '?', '!', '…')
# R8 — A FULL STOP IS NOT ALWAYS A FULL STOP. "Dr." ends in a period, so segmentation cut the caption
# there and R2 then refused to merge the stub back ("Genau dann hielt aber Dr." on its own, "Carbonell
# inne – und…" on the next). Abbreviations are per language, and the ones that normally END a sentence
# (etc. usw. ecc. enz.) are deliberately NOT here. Neither are bare initials ("A.") or lone numbers
# ("14."), because "vitamin A." and "Plan B." really do end sentences — guessing there would just swap
# one wrong break for another. Company suffixes (Inc. Ltd. Co. GmbH.) are out for the same reason: they
# sit at the end of a name, and the name is usually the end of the sentence.
_ABBR = set("""
dr dres prof pr hr fr mr mrs ms mme mlle sr sra srta sig sig.ra dott dhr mevr drs ir ing
st ste jr
bzw ca evtl ggf inkl exkl zzgl bspw sog vgl abs art nr num vol fig approx env cf ung
""".split())
# Closing marks to look PAST when deciding what a token really ends on. German closes with “ (which is
# also the English OPENER, but only ever leading, and rstrip touches the tail only) — leaving it out meant
# a sentence that ends inside German quotes, ausgeht.“ , was not seen as a sentence end at all, and the
# caption ran straight on into the next speaker.
_TRAIL_Q = '"”“\'’‘)»›]'
def is_sent_end(tok):
    t = tok.rstrip(_TRAIL_Q)
    if not t.endswith(SENT_END):
        return False
    if t.endswith('.'):
        stem = t[:-1]
        if '.' in stem:                       # z.B. / u.a. / i.e. / U.S. — an abbreviation, not an ending
            return False
        if stem.lower() in _ABBR:
            return False
    return True
def break_score(tok):
    t = tok.rstrip(_TRAIL_Q)
    if tok in ('—', '–') or t.endswith(('—', '–', ';', ':')): return 2   # strong
    if t.endswith(','): return 1                                          # weak
    return 0

# R7 — LINE BREAKS FOLLOW GRAMMAR. A word that "glues" forward to the next one must not END a line or
# a cue: the eye trips on "der" / "and" / "para" left hanging. These lists are PER LANGUAGE. Until now
# only English existed, so a German or Spanish caption had no protection at all and happily broke
# after an article. English stays in the set for every language: VSL scripts carry English offer and
# brand terms mid-sentence.
_GLUE_EN = """
a an the this that these those my your his her its our their no some any each every another
of to in on at by for with from into onto upon as than about over under between through during
without within per off out up down
and or but nor so yet if while whereas because although though since unless until whether
next last first more most less least very such other own same few many much several
one two three four five six seven eight nine ten
is are was were be been being have has had do does did will would shall should can could may might must
"""
# R9 — AN ACCENT MAKES IT A DIFFERENT WORD. These lists used to be matched after every accent was stripped,
# so "sûr" (sure) was read as the French preposition "sur": the full stop after "…juste pour être sûr." was
# ignored and "sûr." was handed to the NEXT caption ("sûr. 5. Et si…"). The same fold turned "là" into the
# article "la", "dû" into "du", Spanish "él/mí/sí/tú" into "el/mi/si/tu", and Italian "è" / Portuguese "é"
# (is) into "e" (and) - a conjunction that may not end a line even before a comma. Words are now compared
# WITH their accents, so every accented glue word is written below the way it is spelled; the unaccented
# spellings stay for scripts typed without accents.
_GLUE_DE = """
der die das dem den des ein eine einem einen einer eines dieser diese dieses diesem diesen
mein meine meinem meinen meiner dein deine ihr ihre ihrem ihren ihrer sein seine seinem seinen seiner
unser unsere unserem unseren euer eure kein keine keinem keinen keiner jeder jede jedes
in an auf zu mit von fur für uber über unter bei nach aus seit ohne um durch gegen vor hinter neben zwischen
und oder aber denn sondern dass ob wenn weil damit als wie sowie bevor nachdem obwohl falls
weder entweder sowohl zwar teils je desto umso
ist sind war waren wäre wären hat haben hatte hatten hätte hätten wird werden wurde wurden würde würden bin bist seid
kann konnen können muss mussen müssen soll sollen will wollen darf durfen dürfen mochte mochten möchte möchten
nicht nur auch noch sehr mehr immer wieder ganz
zwei drei vier funf fünf sechs sieben acht neun zehn
"""
_GLUE_ES = """
el la los las un una unos unas lo al del
de a en con por para sin sobre entre hasta desde hacia segun según tras
y o pero sino que qué si porque aunque cuando cuándo mientras donde dónde como cómo tambien también
mi mis tu tus su sus nuestro nuestra nuestros nuestras este esta estos estas ese esa
es son era eran ha han habia había habian habían esta está estan están sera será seran serán
puede pueden debe deben tiene tienen
muy mas más menos cada todo toda todos todas otro otra
dos tres cuatro cinco seis siete ocho nueve diez
se me te le les nos os
"""
_GLUE_IT = """
il lo la i gli le un uno una del della dei delle al alla ai alle dal dalla nel nella sul sulla
di a da in con su per tra fra senza sotto sopra verso durante
e o ma se che perche perché quando mentre dove come anche
mio mia miei mie tuo tua suo sua nostro nostra questo questa questi queste quel quella
è sono era erano ha hanno aveva avevano sara sarà saranno puo può possono deve devono
molto piu più meno ogni tutto tutta tutti tutte altro altra
due tre quattro cinque sei sette otto nove dieci
non si mi ti ci vi ne
"""
_GLUE_PT = """
o a à às os as um uma uns umas do da dos das no na nos nas ao aos pelo pela
de em com por para sem sobre entre ate até desde apos após
e ou mas se que porque quando enquanto onde como tambem também
meu minha seu sua nosso nossa este esta esse essa aquele aquela
é está sao são era eram tem têm ha há havia sera será serao serão pode pôde podem deve devem
muito mais menos cada todo toda todos todas outro outra
dois tres três quatro cinco seis sete oito nove dez
não me te lhe lhes
"""
# French also gains the words that can only ever lead into the verb after them - the negation "ne", the object
# pronouns "se/me/te", "en", "y", the subject pronouns "je/il/ils", "dont", "lorsque/puisque". None of them
# can close a phrase, and "ne" was ending lines and captions ("…qu'aucun produit ne" / "fonctionne…").
_GLUE_FR = """
le la les un une des du de au aux
a à dans sur sous par pour avec sans vers chez entre depuis pendant contre dès
et ou mais donc car si que qui quand comme parce où dont lorsque puisque
mon ma mes ton ta son sa ses notre nos votre vos leur leurs ce cet cette ces
est sont etait était etaient étaient ont avait avaient sera seront peut peuvent doit doivent
tres très plus moins chaque tout toute tous toutes autre
deux trois quatre cinq six sept huit neuf dix
ne se me te en y je il ils
"""
_GLUE_NL = """
de het een één deze dit die dat
in op aan bij van voor vóór met naar door over onder tussen zonder tegen
en of maar want als dan omdat terwijl toen ook
mijn jouw zijn haar onze hun
is was waren heeft hebben had hadden wordt worden kan kunnen moet moeten wil willen
zeer meer minder elke alle andere
twee drie vier vijf zes zeven acht negen tien
"""
_GLUE = {'de': _GLUE_DE, 'es': _GLUE_ES, 'it': _GLUE_IT,
         'pt': _GLUE_PT, 'fr': _GLUE_FR, 'nl': _GLUE_NL}
# English glue applies to every language (English offer and brand terms turn up mid-sentence), except where
# the same spelling is an everyday content word of the caption's own language: French "but" (the goal) and
# "an" (the year - "59 € par an") close phrases all the time.
_EN_NOT_GLUE = {'fr': {'but', 'an'}}
NO_END = (set(_GLUE_EN.split()) - _EN_NOT_GLUE.get(LANG, set())) | set(_GLUE.get(LANG, '').split())

# A cue must not START with any of these: they finish the clause the previous cue began, so breaking
# in front of one leaves the subject on one card and its verb on the next - "Behind that plate" then
# "is a hole in the tub wall". Only 'of' was listed, which caught the noun-phrase case and missed every
# linking verb. Punctuation still wins: if the previous cue ended on a comma or a full stop the clause
# was already finished, and split_into_cues checks that first.
BIND_BACK = {
    'of',
    # linking and auxiliary verbs - always the tail of a clause that started earlier
    'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'has', 'have', 'had', 'does', 'do', 'did',
    'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might', 'must',
}

def bare(tok):
    """The word itself, lowercased, for the glue lists: punctuation and digits dropped, ACCENTS KEPT (R9).
    Letters are matched as Unicode letters - an ASCII-only class deleted every accented letter ('für' -> 'fr')
    - and composed (NFC), so a script saved with decomposed accents still spells 'sûr' the same way.
    'ß' -> 'ss' is a spelling variant of the same word (daß / dass), not a different word, so it stays."""
    s = unicodedata.normalize('NFC', tok.lower()).replace(chr(223), 'ss')
    return ''.join(c for c in s if c.isalpha() or c == "'")

# French ELISION (c'est, j'ai, l'eau, d'un, n'est, qu'il, s'il, m'/t', jusqu'/lorsqu'/puisqu'/quoiqu') — an
# elided word ALWAYS binds forward to the next word, so a cue/line must never END on it (that's what put a bare
# "C'est" on its own subtitle: a micro low-energy dip after it was read as a pause, and — unlike the English glue
# words in NO_END — nothing protected the French elision). Matches both the straight ' and the curly ' apostrophe.
_ELISION = re.compile(r"^(?:c|j|l|d|m|t|n|s|qu|jusqu|lorsqu|puisqu|quoiqu)['’]", re.I)
# Pure conjunctions. These keep the ban even with a comma — a line ending on "and," or "und," reads badly
# whatever the punctuation says. PER LANGUAGE (English plus the caption's own): one flat set for every
# language banned German "so," - an ordinary clause end there ("Es ist nicht so, dass…") - because English
# "so" is a conjunction.
_CONJ_BY_LANG = {
    'en': 'and or but nor yet so',
    'de': 'und oder aber denn sondern',
    'fr': 'et ou mais donc ni car',
    'es': 'y e o u pero sino',
    'it': 'e o ma oppure però pero',
    'pt': 'e ou mas porém porem',
    'nl': 'en of maar want',
}
_CONJ_NOT = {'de': {'so'}}
_CONJ = (set(_CONJ_BY_LANG['en'].split()) | set(_CONJ_BY_LANG.get(LANG, '').split())) - _CONJ_NOT.get(LANG, set())

# R10 — A MARK STAYS WITH ITS WORD. French sets ? ! : ; » and the currency / percent signs apart with a space
# ("chez moi ? »", "120 €", "12 %"), so each is a token of its own - and a line or caption could break right
# in front of one: "» me disait-elle." opened a caption, "…plus de 120" / "€ sur le prix de détail." split a
# price over two lines. A CLOSING mark belongs to the word before it, an OPENING mark to the word after it,
# and no line or caption may ever come between them. Dashes are real break points and bind to neither side;
# the straight " and “ ‘ can open or close, so they are left out rather than guessed. So is a free-standing
# ellipsis: "Oberschenkeln … … und verwandelt" is the subtitle convention of one closing the caption and one
# opening the next (R6 already places those).
_CLOSE_MARKS = set('?!:;,.»›”’)]}%‰°')
_OPEN_MARKS = set('«‹„‚¿¡([{')
_CURRENCY = set('€$£¥₺₽')
_NUM_HEAD = re.compile(r'^[(\[]?\d{1,3}$')                 # "96" of "96 400", "1" of "1 000 €"
_NUM_GROUP = re.compile(r'^\d{3}(?:[.,;:!?%)\]]*)$')        # "400" / "000," - a thousands group after a space

def _txt(t):
    return t[0] if isinstance(t, tuple) else t

def _bind(toks, k):
    """'back' if toks[k] belongs to the word before it, 'fwd' if it belongs to the word after it, else None."""
    s = _txt(toks[k]).strip()
    if not s:
        return None
    prev = _txt(toks[k - 1]).strip() if k > 0 else ''
    if _NUM_GROUP.match(s) and _NUM_HEAD.match(prev):       # "96 400", "1 000" - one number, one unit
        return 'back'
    if re.search(r'\w', s):
        return None                                         # a word, not a mark
    if all(c in _CURRENCY for c in s):                      # € $ £ follow the amount in French, lead it in English
        nxt = _txt(toks[k + 1]).strip() if k + 1 < len(toks) else ''
        if re.search(r'\d[\d.,]*$', prev):
            return 'back'
        return 'fwd' if re.match(r'\d', nxt) else 'back'
    if '…' in s or '..' in s:                                # continuation dots (see _CLOSE_MARKS)
        return None
    if all(c in _CLOSE_MARKS or c in _CURRENCY for c in s):
        return 'back'
    if all(c in _OPEN_MARKS for c in s):
        return 'fwd'
    return None

def _no_break_before(toks, k):
    """True when a line or caption may NOT start at toks[k] (R10): it closes the word before it, or the token
    before it opens this one."""
    if k <= 0 or k >= len(toks):
        return False
    return _bind(toks, k) == 'back' or _bind(toks, k - 1) == 'fwd'

def _ends_sentence(toks):
    """Does this run of tokens end its sentence? Looks PAST closing marks that stand on their own - French
    "…chez moi ? »" ends on ».  A bare is_sent_end() on the last token read that as "not a sentence end", so
    R2 (never across a sentence end) no longer protected it."""
    for k in range(len(toks) - 1, -1, -1):
        w = _txt(toks[k])
        if is_sent_end(w):
            return True
        s = w.strip()
        if s and not re.search(r'\w', s) and _bind(toks, k) == 'back':
            continue
        return False
    return False


def ends_ok(tok):
    """Can this token END a line or a cue? A glue word normally cannot — but PUNCTUATION OUTRANKS THE
    WORD. Once it carries a comma the clause is finished, and that is the most natural break there is.
    German is where the flat ban really hurt: it puts the verb at the end of a subordinate clause, right
    before the comma, so "…dass Sie absolut keine Zweifel haben, wenn…" had its best break rejected
    (haben is an auxiliary, so it was in the glue list) and got cut between the object and its verb
    instead — "…keine Zweifel" / "haben, wenn…". Same for "Ich möchte,". Every language benefits; only
    the pure conjunctions above stay banned.

    A SENTENCE END outranks everything, conjunctions included. "…we've ever offered LymphActiv at." ends
    its sentence on a glue word, and without this the full stop was not read at all: "at." was handed to the
    next caption ("at. To take advantage…"), splitting one sentence across two cards against R2. Any glue word
    in any language ended the same way ("I think so.", "…que je vous parle de."), so the fix is here, once."""
    if is_sent_end(tok):
        return True
    b = bare(tok)
    if b not in NO_END:
        return True
    if b in _CONJ:
        return False
    return bool(re.search(r"[,;:—–]$", tok.rstrip(_TRAIL_Q)))


def get_silences():
    """ground-truth silence intervals from the audio waveform via ffmpeg silencedetect.

    The log is cached, and the cache used to be keyed on nothing but "does the file exist". Drop a new
    voice-over into a folder that already has one — a re-recorded VSL, a second FAQ in the same Studio
    scope — and the run silently reused the FIRST audio's pauses. With almost no pauses to break on,
    cue boundaries fall back to the character limit, which reads as captions splitting mid-phrase
    ("…absolut keine Zweifel" / "haben, wenn…"). Seen for real: an 18-day-old log with 6 pauses used
    for a 287s German voice-over that actually has 121. Key it to the audio itself."""
    try:
        _st = os.stat(AUDIO)
        sig = "# audio %d %d %s" % (_st.st_size, int(_st.st_mtime), NOISE_DB)
    except OSError:
        sig = "# audio ?"
    fresh = False
    if os.path.exists(SIL_LOG):
        try:
            with open(SIL_LOG, encoding='utf-8', errors='ignore') as f:
                fresh = any(ln.rstrip('\n') == sig for ln in f)
        except OSError:
            fresh = False
    if not fresh:
        with open(SIL_LOG, 'w', encoding='utf-8') as log:
            subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', AUDIO,
                            '-af', f'silencedetect=noise={NOISE_DB}:d=0.10', '-f', 'null', '-'],
                           stderr=log, stdout=subprocess.DEVNULL)
        with open(SIL_LOG, 'a', encoding='utf-8') as log:     # stamp it LAST — the parser ignores the line
            log.write('\n' + sig + '\n')
    ints, s = [], None
    for ln in open(SIL_LOG, encoding='utf-8', errors='ignore'):
        m = re.search(r'silence_start: ([\d.]+)', ln)
        if m: s = float(m.group(1))
        m = re.search(r'silence_end: ([\d.]+) \| silence_duration: ([\d.]+)', ln)
        if m: ints.append((s, float(m.group(1)), float(m.group(2))))
    return ints

def map_silences(timed, silences, min_dur):
    """indices i such that a silence (>= min_dur) maps to the word boundary after word i.
    ROBUST RULE (fixes word-bleed): a real pause [ss,se] cuts AFTER the last word that BEGINS
    before the pause starts. Any word whose ONSET falls after the pause belongs to the NEXT cue,
    so a post-pause word can never leak into the previous cue (nor make it end early). Uses word
    ONSETS (steadier than ASR word-ends) with a small tolerance, instead of the old
    nearest-gap-midpoint mapping that drifted by ~1 word."""
    n = len(timed)
    onsets = [timed[i][1] for i in range(n)]          # word start times (monotonic)
    # a token with no letter or digit in ANY alphabet. This was [A-Za-z0-9], so the French "à", Italian "è"
    # and Portuguese "é" counted as punctuation: the cut was pushed PAST them and they ended the caption.
    def is_punct(w): return not re.search(r'\w', w)
    cuts = {}                                         # {cut-after index i: silence_end (speech onset)}
    for ss, se, dur in silences:
        if dur < min_dur:
            continue
        i = bisect.bisect_left(onsets, ss) - 1        # last word whose ONSET is before the pause starts
        if i < 0 or i >= n - 1:
            continue
        # don't cut right after a glue word (and/for/the/to/is/next…): a real phrasing
        # pause lands after a content word; a micro breath after a glue word is noise.
        gi = i
        while gi > 0 and is_punct(timed[gi][0]):
            gi -= 1
        w0 = timed[gi][0]
        # the marks standing on their own after it are part of it: French "…pour qui ?" ends on "?", not on "qui"
        w0_full = w0 + ''.join(timed[k][0].strip() for k in range(gi + 1, i + 1) if _bind(timed, k) == 'back')
        if not ends_ok(w0_full):                     # glue word with nothing closing it -> never cut after it
            continue
        if _ELISION.match(w0.strip()) and dur < ELISION_KEEP_MAX:
            continue                                 # French elision + only a SHORT breath/micro pause -> keep it with the
                                                     # next word; a LONGER deliberate pause still splits (respects delivery)
        while i + 1 < n - 1 and is_punct(timed[i + 1][0]) and _bind(timed, i + 1) != 'fwd':
            i += 1                                    # keep trailing punctuation with preceding (never an OPENING mark:
                                                      # « ( ¿ lead the words after the pause)
        while i > 0 and _bind(timed, i) == 'fwd':
            i -= 1                                    # the pause fell right after an opening mark: cut before it
        if _no_break_before(timed, i + 1):
            continue                                  # R10: a pause may not separate a mark or a number group from its word
        cuts[i] = se                                  # next cue starts when speech resumes (silence_end)
    return cuts

def toklen(toks, a, b):
    return sum(len(toks[k][0]) for k in range(a, b)) + max(0, b - a - 1)

def wrappable(toks, a, b):
    """can toks[a:b] fit in <=2 lines of <=MAX_LINE chars? Only at a break R10 allows - a split that
    would leave "€" or "»" at the head of line 2 is not a way to fit."""
    if toklen(toks, a, b) <= MAX_LINE:
        return True
    for k in range(a + 1, b):
        if toklen(toks, a, k) <= MAX_LINE and toklen(toks, k, b) <= MAX_LINE and not _no_break_before(toks, k):
            return True
    return False

def split_into_cues(toks, soft):
    """Split a segment into cues (each <= CUE_MAX chars = at most 2 lines). When a segment is too long and must
    break into several cues, aim for BALANCED cues (near-equal length) and snap each break to a meaningful
    boundary NEAR that balance point (soft pause > strong punct > comma > word) — never dumping the bulk into the
    first cue and leaving a tiny short tail. Breaks land on WORD boundaries, so cues stay voice-over-synced."""
    cues, starts, i, n = [], [], 0, len(toks)
    while i < n:
        rem = sum(len(toks[k][0]) + (1 if k > i else 0) for k in range(i, n))
        if rem <= CUE_MAX and wrappable(toks, i, n):     # the rest fits in one cue, in 2 lines of <=42
            cues.append(toks[i:n]); starts.append(i); break
        cues_left = max(2, -(-rem // CUE_MAX))          # ceil: how many cues the remainder still needs
        target = rem / cues_left                        # balanced target length for THIS cue
        length, best, hard = 0, None, i + 1
        for j in range(i, n):
            add = len(toks[j][0]) + (1 if j > i else 0)
            if length + add > CUE_MAX and j > i:
                break
            length += add
            # R3: 76 chars is not the only limit — the cue must also SPLIT into 2 lines of <=42.
            # "of course" (76 chars, but one 50-char word + a 25-char word) has no legal 2-line
            # split, and letting it grow is what pushed lines past 42 on screen.
            fit2 = wrappable(toks, i, j + 1)
            if fit2:
                hard = j + 1                            # furthest word that still fits (fallback)
            if j + 1 >= n:
                continue                                # don't end this cue on the segment's very last token
            if not fit2:
                continue
            if (not ends_ok(toks[j][0])) or bare(toks[j + 1][0]) in BIND_BACK or _no_break_before(toks, j + 1):
                continue                                # never end on a glue word / right before a binder / a mark
            sc = 3 if soft[j] else break_score(toks[j][0])   # pause > strong punct > comma > plain word (0)
            cost = abs(length - target) - sc * 6        # closest to the balance point, pulled toward real breaks
            if best is None or cost < best[0]:
                best = (cost, j + 1)
        if best is not None:
            end = best[1]
        else:                                           # no clean boundary in range → hard cut, backed off glue words
            end = hard
            while end - 1 > i and ((not ends_ok(toks[end - 1][0])) or
                                   (end < n and (bare(toks[end][0]) in BIND_BACK or _no_break_before(toks, end)))):
                end -= 1
            while end < n and _no_break_before(toks, end):
                end += 1                                # backed off to the segment start: a mark still never leads
        cues.append(toks[i:end]); starts.append(i); i = end
    return cues, starts

def wrap2(toks, soft):
    """wrap a cue into 1 or 2 balanced lines. Option B: minimise imbalance, but prefer a
    punctuation/pause boundary when it is near-balanced; avoid ending a line on a glue word
    or starting the next line with a binder ('of')."""
    n = len(toks)
    if n == 1 or toklen(toks, 0, n) <= MAX_LINE:
        return [toks]
    best = None
    for k in range(1, n):
        l1, l2 = toklen(toks, 0, k), toklen(toks, k, n)
        over = max(0, l1 - MAX_LINE) + max(0, l2 - MAX_LINE)   # chars past the 42 limit
        sc = 3 if soft[k - 1] else break_score(toks[k - 1][0])
        penalty = (60 if bare(toks[k][0]) in BIND_BACK else 0) + \
                  (25 if not ends_ok(toks[k - 1][0]) else 0) + \
                  (100000 if _no_break_before(toks, k) else 0)   # R10 outranks even the 42 limit
        # <=42 dominates everything else; then balance; a punctuation/pause break is worth ~5 chars
        cost = over * 1000 + abs(l1 - l2) - sc * 5 + penalty
        if best is None or cost < best[0]:
            best = (cost, k)
    k = best[1]
    return [toks[:k], toks[k:]]

def segment(timed, cuts, soft):
    # 1) split into segments at sentence-ends AND at real audio silences (>= SILENCE_MIN).
    segments, cur, cur_idx = [], [], []
    carry = False                                     # R10: an end waits for the closing marks that follow it
    for idx, tk in enumerate(timed):
        cur.append(tk); cur_idx.append(idx)
        w = tk[0]
        sent = is_sent_end(w) or carry
        carry = False
        # A full stop followed by a LOWERCASE word is not the end of a sentence — "Und Helene F. fügt
        # hinzu", an initial inside a name. Every language we caption opens a sentence with a capital,
        # so the next word's case is a better witness than the period, and it catches the abbreviations
        # no list will ever have. A real audio pause still cuts, whatever the spelling says.
        if sent and w.rstrip(_TRAIL_Q).endswith('.') and idx + 1 < len(timed):
            if timed[idx + 1][0].lstrip('„«‹“‘"\'¿¡([{')[:1].islower():
                sent = False
        end_here = (idx in cuts) or sent
        if end_here and re.match(r'^\d{1,2}\.$', w):
            if len(cur) == 1:
                end_here = False                      # keep a leading ordinal with its sentence
            elif cur[-2][0].rstrip('"”\'’)').endswith(':'):
                # A numbered list opened by a colon — "…zusammengefasst: 1. Ist CitruSlim…". The colon is
                # not a sentence end, so the marker was not run-initial and the guard above missed it,
                # leaving "…zusammengefasst: 1." stranded on one caption while the question started on
                # the next. Close the run BEFORE the marker and let it open the question, like the other
                # items in the list (which DO follow a full stop and were already handled).
                segments.append((cur[:-1], cur_idx[:-1]))
                cur, cur_idx = [cur[-1]], [cur_idx[-1]]
                end_here = False
        if end_here and idx + 1 < len(timed) and _no_break_before(timed, idx + 1):
            # R10: "…chez moi ?" is followed by its closing "»" - end AFTER it, so the mark closes this
            # sentence instead of opening the next caption ("» me disait-elle.").
            if _bind(timed, idx) == 'fwd':
                if len(cur) > 1:                                # an opening mark goes with the words after it
                    segments.append((cur[:-1], cur_idx[:-1]))
                    cur, cur_idx = [cur[-1]], [cur_idx[-1]]
            else:
                carry = True
            end_here = False
        if end_here:
            segments.append((cur, cur_idx)); cur, cur_idx = [], []
    if cur: segments.append((cur, cur_idx))
    # 1b) A SILENCE IS NOT ALWAYS A CLAUSE END. The speaker breathing after "Behind that plate" cut a
    # segment there, so "is a hole in the tub wall" became a segment of its own and the subject ended up
    # on one card with its verb on the next. split_into_cues can never repair that - it only ever sees
    # one segment at a time - so the join has to happen here. Only when the previous segment did NOT
    # finish a sentence: a full stop really is an end, whatever word follows it.
    joined = []
    for seg in segments:
        toks, idxs = seg
        if joined and toks and bare(toks[0][0]) in BIND_BACK:
            prev_toks = joined[-1][0]
            if prev_toks and not _ends_sentence(prev_toks):
                joined[-1] = (prev_toks + toks, joined[-1][1] + idxs)
                continue
        joined.append(seg)
    segments = joined
    # 2) each segment -> cues (pause/length aware) -> each cue wrapped into 2 balanced lines.
    #    Track each cue's first-token global index so its start can snap to a pause onset.
    cues, cue_start_idx = [], []
    for toks, idxs in segments:
        soft_bools = [idxs[m] in soft for m in range(len(toks))]
        cue_toks, starts = split_into_cues(toks, soft_bools)
        for ct, sr in zip(cue_toks, starts):
            cues.append(wrap2(ct, soft_bools[sr:sr + len(ct)]))
            cue_start_idx.append(idxs[sr])
    return cues, cue_start_idx

# ---------------- merge too-short cues (readability) ----------------
def merge_short_cues(cues, starts, timed, last_end, min_disp=1.1):
    """A lone short word (e.g. 'Then,', 'fat.') can land on its own cue and flash for <0.7s — too fast to
    read. Merge any cue that would DISPLAY shorter than min_disp into an adjacent cue, as long as the
    combined text still fits 2 lines. Only concatenates tokens (never changes wording), so text stays
    100% script. Display time = next cue's start − this cue's start (NO_GAP), so it matches what's on screen."""
    def flat(cue): return [t for line in cue for t in line]
    def disp(i):
        s_i = timed[starts[i]][1]
        s_n = timed[starts[i + 1]][1] if i + 1 < len(starts) else last_end
        return s_n - s_i
    ORPHAN_KEEP_PAUSE = 0.6   # a real spoken pause (s) around a short cue justifies leaving it on its own
    ORPHAN_MIN = 18           # R1: a cue shorter than this many chars is an orphan tail, not a caption
    def orphan(i):
        # R1 — NO ORPHANS. A stub cue ("sont", "C'est", "davon aus.") reads as broken — merge it into a
        # neighbour… UNLESS the voice-over actually PAUSED noticeably right before or after it (a
        # deliberate beat). Measured in CHARACTERS, not "is it exactly one token": a two-word tail
        # ("davon aus.", "Jahre alt.") looks just as stranded but used to slip through.
        # A genuine one-word sentence ("Oui.") needs no special case here — it can only merge across a
        # sentence end, and the merge loop below refuses that (R2), so it stays on its own cue.
        fl = flat(cues[i])
        if toklen(fl, 0, len(fl)) >= ORPHAN_MIN:
            return False
        gi = starts[i]                                            # global index of the cue's FIRST word
        gl = gi + len(fl) - 1                                     # …and its LAST
        before = (timed[gi][1] - timed[gi - 1][2]) if gi > 0 else 0.0
        nxt = starts[i + 1] if i + 1 < len(starts) else None
        after = (timed[nxt][1] - timed[gl][2]) if nxt is not None else 0.0
        return max(before, after) < ORPHAN_KEEP_PAUSE            # small gaps → force-merge; big pause → keep
    def voiced(fl, last=False):
        seq = reversed(fl) if last else fl
        return next((t for t in seq if not NOSPEAK.match(t[0].strip())), fl[-1] if last else fl[0])
    def seam(a):
        # R11 — how strongly the voice-over separates cue a from cue a+1: the silence between the two words,
        # plus what the script's punctuation says (a comma after "(thé vert décaféiné)," is a phrase end).
        fa, fb = flat(cues[a]), flat(cues[a + 1])
        gap = max(0.0, voiced(fb)[1] - voiced(fa, last=True)[2])
        return gap + 0.3 * break_score(fa[-1][0])
    skip, guard = set(), 0
    while len(cues) > 1 and guard < 100000:
        guard += 1
        idx = next((i for i in range(len(cues)) if i not in skip and (disp(i) < min_disp or orphan(i))), None)
        if idx is None:
            break
        merged = False
        # R11 — merge across the WEAKER seam. This always tried the previous cue first, so "du Capsicum" -
        # too short to stand alone - was glued BACK onto "(thé vert décaféiné)," across the clear pause and
        # the comma, instead of forward onto "(piment rouge)", which it runs into. Ties still go back.
        order = (idx - 1, idx + 1)
        if 0 < idx < len(cues) - 1 and seam(idx) < seam(idx - 1):
            order = (idx + 1, idx - 1)
        for j in order:
            if not (0 <= j < len(cues)):
                continue
            a, b = (j, idx) if j < idx else (idx, j)
            if _ends_sentence(flat(cues[a])):             # NEVER merge across a sentence end — no caption may hold
                continue                                  # the tail of one sentence AND the head of the next
            combo = flat(cues[a]) + flat(cues[b])
            if wrappable(combo, 0, len(combo)):           # still fits <=2 lines of <=MAX_LINE
                cues[a] = wrap2(combo, [False] * len(combo))
                del cues[b]; del starts[b]                # keep cue a's (earlier) start index
                skip = set(); merged = True               # indices shifted → reset the skip set
                break
        if not merged:
            skip.add(idx)                                 # both neighbours too long to merge — leave it
    return cues, starts

# opening quotes / brackets LEAD the phrase they open — they must never be stranded at the END of a cue.
_OPEN_PUNCT = set('«"“‘‹¿¡([{„‟')
def lead_open_punct(cues, starts):
    """Move an opening mark («, ", ¿, (, …) stuck at the END of a cue to the FRONT of the next cue, so it sits
    with the phrase it opens (fixes « / a quote-open landing on the previous caption)."""
    for i in range(len(cues) - 1):
        flat_i = [t for line in cues[i] for t in line]
        moved = False
        while len(flat_i) > 1 and (flat_i[-1][0].strip() in _OPEN_PUNCT):
            tok = flat_i.pop()
            flat_next = [t for line in cues[i + 1] for t in line]
            flat_next.insert(0, tok)
            cues[i + 1] = wrap2(flat_next, [False] * len(flat_next))
            starts[i + 1] -= 1                          # the next cue now opens one token earlier (its pause snap
            moved = True                                # is looked up from the token before its first one)
        if moved:
            cues[i] = wrap2(flat_i, [False] * len(flat_i))
    return cues, starts

def lead_glue_tail(cues, starts):
    """R7 over the FINISHED cue list: a glue word left at the end of a cue is handed to the next one, where
    the phrase it opens lives. split_into_cues already refuses such a break, but a cue that came out of a
    silence cut or out of merge_short_cues never went through that check - this is the net under both."""
    for i in range(len(cues) - 1):
        for _ in range(2):                                  # at most two words hop forward
            flat_i = [t for line in cues[i] for t in line]
            if len(flat_i) < 2 or ends_ok(flat_i[-1][0]):
                break
            flat_next = [t for line in cues[i + 1] for t in line]
            flat_next.insert(0, flat_i.pop())
            starts[i + 1] -= 1                              # the next cue now opens one word earlier
            while len(flat_i) > 1 and _bind(flat_i, len(flat_i) - 1) == 'fwd':
                flat_next.insert(0, flat_i.pop())           # R10: "« le" - the opening mark goes with its word
                starts[i + 1] -= 1
            cues[i] = wrap2(flat_i, [False] * len(flat_i))
            cues[i + 1] = wrap2(flat_next, [False] * len(flat_next))
    return cues, starts


# a token with no letter or digit in it is never SPOKEN: – — … » " ) etc.
NOSPEAK = re.compile(r'^[^\w]+$', re.U)
def trail_nonspoken(cues, starts):
    """R6 — a non-spoken mark must not OPEN a cue. It has no alignment of its own, so it inherits the
    PREVIOUS word's end time: a moment that sits inside the pause. Opening a cue on it pops the caption
    up before the voice comes back (that is the dash that appeared ~180 ms early). Hand it to the end of
    the previous cue instead, where it reads as "…continues". Two limits: never across a sentence end
    (R2 — the mark belongs to its own sentence), and never if it would push that cue past 2x42 (R3).
    When the mark is the sentence's FIRST token there is nowhere to move it; R5 then makes sure it does
    not get to set the time."""
    _fl = lambda c: [t for line in c for t in line]
    _re = lambda ts: wrap2(ts, [False] * len(ts))
    i = 0
    while i < len(cues):
        flat_i = _fl(cues[i])
        # (B) A cue made of NOTHING BUT marks — a caption that reads "…" and holds a slot on screen
        # with no speech under it at all. It happens when the script has a bare ellipsis between two
        # sentences: is_sent_end() treats it as a sentence of its own, segment() gives it a cue, and
        # the merge step then refuses to touch it (R2) precisely because it looks like a sentence.
        # It is not one. Hand it to a neighbour — previous first (it reads as a trailing "…").
        if flat_i and all(NOSPEAK.match(t[0].strip()) for t in flat_i):
            def _back(_i=i, _f=flat_i):
                if _i <= 0:
                    return False
                p = _fl(cues[_i - 1])
                if not wrappable(p + _f, 0, len(p) + len(_f)):
                    return False
                cues[_i - 1] = _re(p + _f); del cues[_i]; del starts[_i]
                return True
            def _fwd(_i=i, _f=flat_i):
                if _i + 1 >= len(cues):
                    return False
                n = _fl(cues[_i + 1])
                if not wrappable(_f + n, 0, len(_f) + len(n)):
                    return False
                cues[_i + 1] = _re(_f + n); starts[_i + 1] = starts[_i]   # the cue now begins at the mark
                del cues[_i]; del starts[_i]
                return True
            # Previous cue first — a trailing "…" reads as "…continues". EXCEPT when that cue already
            # ends in a mark: a script written "Oberschenkeln … … und verwandelt" then stacked both on
            # one caption ("Oberschenkeln … …") instead of one closing it and the other opening the next.
            prev_ends_mark = i > 0 and bool(NOSPEAK.match(_fl(cues[i - 1])[-1][0].strip()))
            order = (_fwd, _back) if prev_ends_mark else (_back, _fwd)
            if order[0]() or order[1]():
                continue                                 # list shrank: re-test this index
        # (A) A cue that OPENS on a mark but does carry speech: give the mark to the previous cue.
        if i > 0:
            prev = _fl(cues[i - 1])
            moved = 0
            # R2: never across a sentence boundary - except a CLOSING mark (R10): "»" after "…chez moi ?" closes
            # that very sentence, so it goes back even though the previous cue ends one.
            while (len(flat_i) > 1
                   and NOSPEAK.match(flat_i[0][0].strip())
                   and flat_i[0][0].strip() not in _OPEN_PUNCT   # those LEAD their phrase (above)
                   and (_bind(prev + flat_i[:2], len(prev)) == 'back' or not _ends_sentence(prev))
                   and wrappable(prev + flat_i[:1], 0, len(prev) + 1)):
                prev.append(flat_i.pop(0)); moved += 1
            if moved:
                cues[i - 1] = _re(prev)
                cues[i] = _re(flat_i)
                starts[i] += moved                       # the cue now begins at a later token
        i += 1
    return cues, starts

# ---------------- srt ----------------
def wrap(text):
    words = text.split()
    if len(text) <= MAX_LINE or len(words) == 1:
        return text
    # 2-line split minimising the longer line (tiebreak: prefer break after punctuation)
    best = None
    for k in range(1, len(words)):
        l1 = ' '.join(words[:k]); l2 = ' '.join(words[k:])
        cost = (max(len(l1), len(l2)), 0 if break_score(words[k-1]) else 1, abs(len(l1)-len(l2)))
        if best is None or cost < best[0]:
            best = (cost, l1 + '\n' + l2)
    return best[1]

def ts(sec):
    if sec < 0: sec = 0
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def write_srt(cues, overrides, canonical=None):
    n = len(cues)
    MAX_SNAP = 0.0  # Measured phonemes own caption starts in every mode and language.
    def toks(i):    return [t for line in cues[i] for t in line]
    # start = ffmpeg silence onset (speech resume) if it is close to the ASR first-word start;
    # if the silence mapping drifted too far, it's unreliable -> fall back to the ASR word start.
    st = []
    for i in range(n):
        # R5 — TIMING COMES FROM SPEECH. A cue can still open on a mark that is never spoken (a
        # sentence-initial – or « that R6 was not allowed to move back). That token has no alignment,
        # so timed_script_tokens handed it the PREVIOUS word's end — a timestamp that lands inside the
        # pause. Take the start from the first token that is actually voiced. The mark still shows on
        # screen; it just doesn't decide when the caption appears.
        tk = toks(i)
        f = next((k for k in range(len(tk)) if not NOSPEAK.match(tk[k][0].strip())), 0)
        ws = tk[f][1]
        ov = overrides[i]
        st.append(ov if (ov is not None and abs(ov - ws) <= MAX_SNAP) else ws)
    last_end = next((t[2] for t in reversed(toks(n - 1)) if not NOSPEAK.match(t[0].strip())), toks(n - 1)[-1][2])
    # Do not redistribute or push measured starts for minimum reading time.
    # That hid alignment failures and shifted following captions away from speech.
    if any(st[i+1] <= st[i] for i in range(n-1)) or last_end <= st[-1]:
        message='Subtitle timing collapsed. Check the recording/script; previous subtitles were kept.'
        Path(OUT).with_name('alignment-error.json').write_text(json.dumps({'error':message}),'utf8')
        raise ValueError(message)
    raw_ends = ([st[i+1] for i in range(n - 1)] + [last_end]) if NO_GAP \
               else [toks(i)[-1][2] for i in range(n - 1)] + [last_end]
    # A pause is not an empty-caption request. Retain this cue until the next
    # measured onset, including FAQ and source-window boundaries. User/OST
    # hiding is applied later by the display layer, never by the speech clock.
    ends = raw_ends
    if canonical is not None:
        groups = canonical['groups']
        if len(groups) != n or any(g['text'] != '\n'.join(' '.join(t for t,_,_ in line) for line in cues[i]) for i,g in enumerate(groups)):
            raise ValueError('Canonical phrase plan does not match the exact subtitle text.')
        from phrase_store import serialize_srt
        with open(OUT, 'w', encoding='utf-8') as f:
            f.write(serialize_srt(canonical))
        print(f"[srt] {n} cues -> {OUT}", flush=True)
        return
    with open(OUT, 'w', encoding='utf-8') as f:
        for i in range(n):
            text = '\n'.join(' '.join(t for t, _, _ in line) for line in cues[i])
            f.write(f"{i+1}\n{ts(st[i])} --> {ts(ends[i])}\n{text}\n\n")
    print(f"[srt] {n} cues -> {OUT}", flush=True)

# ---------------- main ----------------
def main():
    if '--transcribe' in sys.argv:              # transcription-only pass (reconcile the script to the VO first)
        transcribe_audio()
        sys.exit(0)
    text = spoken_script()
    script_tokens = text.split()
    scene_cuts=[]
    scene_path=os.environ.get('VSL_SCENE_TEXTS')
    if scene_path:
        from phrase_store import scene_boundaries
        try:
            scene_cuts=scene_boundaries(text,json.loads(Path(scene_path).read_text('utf8')))
        except (OSError,ValueError,TypeError) as exc:
            Path(OUT).with_name('alignment-error.json').write_text(json.dumps({'error':str(exc)}),'utf8')
            raise
    if '--resegment' in sys.argv and os.path.exists(WORDS_CACHE) and word_cache_is_current(text):
        aligned = load_cached_words()
        if joined_words(aligned):
            import _mms_align
            aligned = _mms_align.repair_joined_words(AUDIO, aligned)
        # Different lexical content must never borrow a stale alignment cache.
        if [norm(t) for t in script_tokens if norm(t)] != [norm(t) for t, _, _ in aligned if norm(t)]:
            aligned = align_words(text)
        print(f"[cache] loaded {len(aligned)} aligned words")
    else:
        aligned = align_words(text)
    timed = timed_script_tokens(script_tokens, aligned)
    # ensemble: patch this model's alignment-collapse regions with the small model's timing.
    # English uses the tuned small.en cache; other languages use the multilingual small cache.
    _small = "small.en" if LANG == "en" else "small"
    SECONDARY_CACHE = f"words_{_small.replace('.', '_')}_vad.tsv"
    # The two-model ensemble below only ever existed to repair Whisper alignment collapses.
    # MMS-FA does not collapse, and a stale words_small_vad.tsv from an OLD Whisper run would
    # now corrupt good timings — so it is off unless explicitly asked for.
    if os.environ.get("VSL_ENSEMBLE") == "1" and os.path.exists(SECONDARY_CACHE) and SECONDARY_CACHE != WORDS_CACHE:
        timed_sec = timed_script_tokens(script_tokens, load_words(SECONDARY_CACHE))
        # Normally the final (medium) model is the base and the small model patches its collapses.
        # BUT if the final model's alignment is substantially MORE broken than the small model's
        # (it failed a long tail -> words crammed at the audio end / jumping around), that base is
        # unusable. Fall back to the small model as the base and patch IT with the final model.
        h_pri, h_sec = alignment_health(timed), alignment_health(timed_sec)
        if h_sec > h_pri + 0.08:
            print(f"[ensemble] final model unhealthy ({h_pri:.2f}) vs small ({h_sec:.2f}) -> using small as the base", flush=True)
            timed = merge_timings(timed_sec, timed)
        else:
            timed = merge_timings(timed, timed_sec)
        aligned=timed
    # Use the exact persisted precision for the source fingerprint and plan.
    # This also covers an explicit legacy ensemble or joined-word repair pass.
    aligned = [(t,round(a,3),round(b,3)) for t,a,b in aligned]
    timed = timed_script_tokens(script_tokens, aligned)
    bounds=[0,len(timed)]
    plan_path=os.environ.get('VSL_ALIGNMENT_PLAN')
    if plan_path:
        from bounded_alignment import validate_plan
        windows=validate_plan(json.loads(Path(plan_path).read_text('utf8')),text)
        bounds=[0]
        for window in windows: bounds.append(bounds[-1]+len(normalize_spacing(window['text']).split()))
    bounds.extend(scene_cuts)
    # Optional existing scene boundaries are token indices, never new times.
    # The caller must derive them from the same immutable alignment rows.
    boundary_path = os.environ.get('VSL_PHRASE_BOUNDARIES')
    if boundary_path:
        extra = json.loads(Path(boundary_path).read_text('utf8'))
        bounds.extend(extra.get('forced_boundaries', []) if isinstance(extra, dict) else extra)
    from acoustic_phrasing import plan as speech_plan, detect_pauses, POLICY
    acoustic_pauses = detect_pauses(AUDIO)
    canonical = speech_plan(timed, acoustic_pauses, LANG, forced_boundaries=bounds)
    from phrase_store import bind_source
    bind_source(canonical, aligned, WORDS_CACHE)
    cues, cue_start_idx=[],[]
    for group in canonical['groups']:
        edges = [group['a']] + group['line_breaks'] + [group['b']]
        cues.append([timed[a:b] for a,b in zip(edges, edges[1:])])
        cue_start_idx.append(group['a'])
    # R4 — THE CAPTION TEXT IS THE SCRIPT, WORD FOR WORD. Every step above only ever concatenates or
    # moves whole tokens, so a mismatch is a real bug (a dropped tail, two lists paired by index that
    # drifted apart). This used to only PRINT False, after the file was already written — and a
    # silently incomplete SRT is far worse than none, because a whole timeline gets synced to it.
    # Check first, and refuse to write.
    joined = [t for c in cues for line in c for (t, _, _) in line]
    if joined != script_tokens:
        _d = list(difflib.unified_diff(script_tokens, joined, 'script', 'cues', n=0, lineterm=''))[:14]
        raise ValueError("[srt] ABORT: caption text != script (script %d words, cues %d)\n%s"
                         % (len(script_tokens), len(joined), '\n'.join(_d)))
    quality=audit_subtitles(text,aligned,canonical,bounds)
    if quality.get('candidate_plan') is not None:
        from phrase_store import canonical_rows
        from caption_quality import audit_structure
        repaired=quality['candidate_plan']
        scenes=[dict(token_index=i,frame=round(timed[i][1]*60),fps=60)
                for i in sorted(set(bounds)) if 0<i<len(timed)]
        validation=audit_structure(text,aligned,repaired,LANG,scene_bounds=scenes)
        if not validation.get('passed'):
            raise ValueError('A subtitle repair conflicts with the original source or scene frames. Previous subtitles were preserved.')
        timed=canonical_rows(repaired,aligned);canonical=repaired;cues=[]
        for group in canonical['groups']:
            edges=[group['a']]+group['line_breaks']+[group['b']]
            cues.append([timed[a:b] for a,b in zip(edges,edges[1:])])
    save_word_cache(text,aligned)
    write_srt(cues, [None] * len(cues), canonical)
    Path(OUT).with_name('phrase-plan.json').write_text(json.dumps(canonical, ensure_ascii=False, indent=2),'utf8')
    Path(OUT).with_name('caption-policy.json').write_text(json.dumps({'clock':POLICY, 'phrase_policy':POLICY, 'schema':1}),'utf8')
    print("TEXT == SCRIPT word-for-word: True",
          "| cues:", len(cues), "| script words:", len(script_tokens))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        if not _QUALITY_REPORTED or _QUALITY_PASSED:quality_failure(error)
        raise
