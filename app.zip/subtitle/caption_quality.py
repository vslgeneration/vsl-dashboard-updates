"""Post-generation QA. Exact script and measured clocks always remain authoritative."""
from pathlib import Path
import difflib,hashlib,json,math,os,re,tempfile,unicodedata
try:
 from . import phrase_store as store,acoustic_phrasing as phrasing,speech_forms as forms,recognition_cache as recognition
 from .text_boundaries import protected_boundaries,normalize_spacing,spoken_text
except ImportError:
 import phrase_store as store,acoustic_phrasing as phrasing,speech_forms as forms,recognition_cache as recognition
 from text_boundaries import protected_boundaries,normalize_spacing,spoken_text

POLICY='caption-quality-v1009'

def _sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def _frame(value,fps=60):return max(0,int(float(value)*fps+.5+1e-9))
def _finite(value):return type(value) in (int,float) and math.isfinite(value)
def _report():return dict(schema=1,policy=POLICY,status='pass',passed=True,issues=[],checks=[],repairs=[],recognition=None)
def fingerprints(audio,script_text,rows,canonical,lang):
 return dict(audio_sha256=recognition.digest(audio),script_sha256=_sha(str(script_text)),plan_sha256=_sha(canonical),rows_sha256=store.rows_sha256(rows),lang=recognition.normalized_lang(lang))
def report_matches(report,audio,script_text,rows,canonical,lang):
 try:return report.get('policy')==POLICY and report.get('mode')=='full' and report.get('fingerprints')==fingerprints(audio,script_text,rows,canonical,lang)
 except (OSError,TypeError,ValueError):return False
def _issue(report,code,message,start=0,end=None,text='',heard='',severity='review',evidence=None):
 report['issues'].append(dict(code=code,severity=severity,start=max(0,float(start or 0)),end=max(0,float(end if end is not None else start or 0)),text=text,heard=heard,message=message,evidence=evidence or {}))
 if severity=='review':report.update(status='review',passed=False)
def save_user_review(folder,audio,script,transcript,lang):
 receipt=dict(schema=1,source='explicit-script-review',audio_sha256=recognition.digest(audio),
     script_sha256=_sha(spoken_text(script)),transcript_sha256=_sha(_norm(transcript)),lang=recognition.normalized_lang(lang))
 target=Path(folder)/'script-review-choice.json'
 target.write_text(json.dumps(receipt,ensure_ascii=False),'utf8')


def reviewed_recognition(audio,script,lang,folder):
 """Reuse the independent recording evidence the user actually reviewed."""
 try:
  root=Path(folder);record=json.loads((root/'review-recognition.json').read_text('utf8'))
  receipt=json.loads((root/'script-review-choice.json').read_text('utf8'))
  language=recognition.normalized_lang(lang);digest=recognition.digest(audio)
  if record.get('policy')!=recognition.POLICY or record.get('audio_sha256')!=digest or record.get('lang')!=language:return None
  if not recognition._independent(record.get('options')):return None
  allowed=('small','medium','large-v3','large-v2','large')+(('small.en','medium.en') if language=='en' else ())
  if record.get('model') not in allowed or record.get('backend') not in ('whisper','stable_whisper','faster_whisper'):return None
  result=recognition._result(record.get('result'))
  transcript=' '.join(s['text'] for s in result['segments'])
  expected=dict(schema=1,source='explicit-script-review',audio_sha256=digest,
      script_sha256=_sha(spoken_text(script)),transcript_sha256=_sha(_norm(transcript)),lang=language)
  return record if receipt==expected else None
 except (OSError,ValueError,TypeError,KeyError):return None


def apply_user_review(report,audio,script,record,lang,folder):
 """Honour a choice for this exact script/audio/transcript, never timing errors."""
 try:
  receipt=json.loads((Path(folder)/'script-review-choice.json').read_text('utf8'))
  result=record.get('result',record);transcript=' '.join(str(s.get('text') or '') for s in result.get('segments',[]))
  expected=dict(schema=1,source='explicit-script-review',audio_sha256=recognition.digest(audio),
      script_sha256=_sha(spoken_text(script)),transcript_sha256=_sha(_norm(transcript)),lang=recognition.normalized_lang(lang))
  if receipt!=expected:return
 except (OSError,ValueError,TypeError):return
 count=0
 for issue in report.get('issues',[]):
  if issue.get('code')=='transcript_disagreement' and issue.get('severity')=='review':
   issue.update(severity='warning',code='user_reviewed_script_retained',message='You chose to keep this script wording. The measured subtitle timing was preserved.');count+=1
 if count:
  report['user_review']=dict(source='explicit-script-review',retained_spans=count)
  passed=not any(i.get('severity') in ('review','error') for i in report['issues'])
  report.update(passed=passed,status='pass' if passed else 'review')


def _check(report,name,passed):report['checks'].append(dict(name=name,passed=bool(passed)))

def persist_report(workdir,report):
 target=Path(workdir)/'caption-quality.json';target.parent.mkdir(parents=True,exist_ok=True)
 fd,temporary=tempfile.mkstemp(prefix='.caption-quality-',suffix='.tmp',dir=target.parent)
 try:
  with os.fdopen(fd,'w',encoding='utf8') as out:json.dump(report,out,ensure_ascii=False,indent=2)
  os.replace(temporary,target)
 finally:Path(temporary).unlink(missing_ok=True)
 return target

def alignment_failure_report(error,diagnostics=None,lang=None):
 report=_report();report['language']=lang;data=diagnostics or {}
 weak=data.get('weak_numeric',[]) if isinstance(data,dict) else []
 if not weak and isinstance(data,dict):
  for window in data.get('windows',[]):weak.extend(window.get('weak_numeric',[]) or window.get('diagnostics',{}).get('weak_numeric',[]))
 for row in weak:
  start=row.get('source_start',row.get('start',0));end=row.get('source_end',row.get('end',start))
  _issue(report,'weak_numeric_evidence','The spoken number needs review; its precise onset was not verified.',start,end,row.get('text') or row.get('token') or '',evidence=row)
 if not weak:_issue(report,'alignment_unverified',str(error),evidence={'diagnostics':data})
 report['error']=str(error);return report

def audit_structure(script_text,rows,canonical,lang,scene_bounds=None,acoustic=None):
 report=_report();report['mode']='structure';report['language']=recognition.normalized_lang(lang)
 report['fingerprints']=dict(script_sha256=_sha(str(script_text)),plan_sha256=_sha(canonical),rows_sha256=store.rows_sha256(rows),lang=recognition.normalized_lang(lang))
 try:tokens=store.canonical_rows(canonical,rows)
 except (ValueError,TypeError,KeyError) as error:
  _issue(report,'source_clock_mismatch',str(error));return report
 printed=str(script_text).split();actual=[t[0] for t in tokens]
 exact=printed==actual;_check(report,'exact_printed_script',exact)
 if not exact:_issue(report,'printed_script_changed','Subtitle tokens differ from the exact supplied script.',text=str(script_text),heard=' '.join(actual))
 numeric_groups=[set(u['indices']) for u in forms.contextual_units(actual) if len(u['indices'])>1]
 previous=None
 for i,(text,start,end) in enumerate(tokens):
  if not any(c.isalnum() for c in text):continue
  if not all(_finite(t) for t in (start,end)) or start<0 or end<=start:
   _issue(report,'invalid_word_interval','A spoken word has no positive measured interval.',start,end,text)
  if previous is not None:
   pi,pa,pb=previous;shared=any(pi in group and i in group for group in numeric_groups)
   if start<pa-1e-7 or (not shared and start<pb-1/60-.001):
    _issue(report,'overlapping_word_clock','Measured word intervals overlap outside one atomic numeric expression.',start,end,text,evidence={'previous_token':pi,'token_index':i})
  previous=(i,start,end)
 fps=canonical.get('fps',60);groups=canonical.get('groups',[]);protected=protected_boundaries(actual)
 forced=set(canonical.get('forced_boundaries',[]));cursor=0;valid=True
 for index,group in enumerate(groups):
  a,b=group.get('a'),group.get('b');start,end=group.get('start'),group.get('end')
  if type(a) is not int or type(b) is not int or a!=cursor or not a<b<=len(tokens) or not _finite(start) or not _finite(end) or end<=start:
   _issue(report,'invalid_phrase_partition','The phrase plan has missing, repeated or invalid intervals.',text=str(group));valid=False;break
  cursor=b;text=group.get('text','');expected=' '.join(actual[a:b])
  if text.split()!=actual[a:b]:_issue(report,'phrase_text_changed','A phrase changed printed words or punctuation.',start,end,expected,text)
  voiced=next((i for i in range(a,b) if any(ch.isalnum() for ch in tokens[i][0])),a)
  expected_frame=_frame(tokens[voiced][1],fps)
  if _frame(start,fps)!=expected_frame or group.get('start_frame')!=expected_frame:
   _issue(report,'cue_onset_mismatch','The cue does not start at its measured first-word frame.',start,end,text,evidence={'measured_frame':expected_frame,'cue_frame':_frame(start,fps)})
  if abs(start-_frame(start,fps)/fps)>1e-7 or abs(end-_frame(end,fps)/fps)>1e-7:
   _issue(report,'unquantized_cue','Cue boundaries are not on the canonical frame clock.',start,end,text)
  if index+1<len(groups):
   next_start=groups[index+1].get('start')
   if not _finite(next_start) or _frame(end,fps)!=_frame(next_start,fps):_issue(report,'caption_hold_gap','The preceding caption must hold until the next measured cue onset.',start,end,text)
  if b<len(tokens) and b in protected and b not in forced:
   _issue(report,'broken_semantic_unit','A phrase boundary splits a protected expression.',start,end,text,evidence={'token_index':b})
  for linecut in group.get('line_breaks',[]):
   if linecut in protected:_issue(report,'broken_line_unit','A line break splits a protected expression.',start,end,text,evidence={'token_index':linecut})
  if len(text.splitlines())>2:_issue(report,'too_many_lines','The phrase needs at most two balanced lines.',start,end,text)
  duration=end-start
  if duration<.25:_issue(report,'brief_caption','This caption is shorter than a quarter second; review its forced scene cut or phrase grouping.',start,end,text,severity='warning' if a in forced or b in forced else 'review')
  if duration>8 and len(actual[a:b])>3:_issue(report,'long_caption','The phrase stays on screen for more than eight seconds.',start,end,text)
 if cursor!=len(tokens):_issue(report,'incomplete_phrase_coverage','Not every printed token belongs to one phrase.')
 _check(report,'contiguous_phrase_coverage',valid and cursor==len(tokens))
 by_start={g.get('a'):g for g in groups}
 for bound in scene_bounds or []:
  try:
   token=bound['token_index'];frame=bound['frame'];clock=bound.get('fps',60)
   if type(token) is not int or type(frame) is not int or not 0<=token<len(tokens) or not _finite(clock) or clock<=0:raise ValueError()
   group=by_start.get(token);when=frame/clock
   if group is None or _frame(group['start'],clock)!=frame:
    _issue(report,'scene_caption_frame_mismatch','The scene and its first caption do not start on the same frame; no source timing was moved.',when,when,tokens[token][0],evidence={'token_index':token,'scene_frame':frame,'caption_frame':_frame(group['start'],clock) if group else None,'fps':clock})
  except (KeyError,TypeError,ValueError):_issue(report,'invalid_scene_boundary','The scene-boundary audit input is incomplete.',evidence={'boundary':bound})
 if acoustic:
  weak=acoustic.get('weak_numeric',[]) if isinstance(acoustic,dict) else []
  for row in weak:_issue(report,'weak_numeric_evidence','Precise number timing still requires acoustic review.',row.get('source_start',row.get('start',0)),row.get('source_end',row.get('end',0)),row.get('text') or row.get('token',''),evidence=row)
 return report

def _norm(text):return ''.join(c for c in unicodedata.normalize('NFKC',str(text)).casefold() if c.isalnum())

def _stream(tokens,lang):
 """Normalize speech-equivalent notation while retaining original token ownership."""
 units=forms.contextual_units(tokens);characters=[];owners=[]
 for unit in units:
  raw=unit['alignment_text']
  try:value=forms.spoken(raw,lang)
  except ValueError:value=raw # uncertain normalization remains a visible mismatch
  key=_norm(value);characters.append(key);owners.extend([unit['indices']]*len(key))
 return ''.join(characters),owners

def _numeric_equivalence(observed,owners,source,lang):
 """Accept alternate complete pronunciations of the same printed amount.

 Never remove a currency/percent unit, change a value, or match inside a word.
 This only canonicalizes notation for comparison; it cannot change output text.
 """
 for unit in forms.contextual_units(source):
  if not unit.get('numeric'):continue
  raw=forms.numeric_notation(unit['alignment_text'])
  try:canonical=_norm(forms.spoken(raw,lang))
  except ValueError:continue
  variants=[]
  if recognition.normalized_lang(lang)=='en':variants.append(_norm(forms.spoken(raw,lang).replace(' and ',' ')))
  match=re.fullmatch(r'([$€£₺¥₹₽])([+\-−]?\d+(?:[.,]\d+)*)',raw)
  if match:
   try:
    value=forms.numeric_value(match[2],forms.language(lang));whole=int(value);minor=round(abs(value-whole)*100)
    major=forms.money_words(forms.Decimal(whole),forms.language(lang),forms._CURRENCY[match[1]])
    number=forms.number_words(whole,forms.language(lang));label=_norm(major)
    if label.startswith(_norm(number)):
     label=label[len(_norm(number)):]
     variants.append(_norm(forms.number_words(value,forms.language(lang)))+label)
    if minor:variants.append(_norm(major+' '+forms.number_words(minor,forms.language(lang))))
   except (ValueError,TypeError):pass
  for alias in sorted(set(variants)-{canonical},key=len,reverse=True):
   if not alias:continue
   at=0
   while (at:=observed.find(alias,at))>=0:
    end=at+len(alias)
    left=at==0 or owners[at-1]!=owners[at];right=end==len(owners) or owners[end-1]!=owners[end]
    if not(left and right):at=end;continue
    mapped=sorted({i for own in owners[at:end] for i in own})
    observed=observed[:at]+canonical+observed[end:];owners=owners[:at]+[mapped]*len(canonical)+owners[end:];at+=len(canonical)
 return observed,owners

def _recognized_words(record):
 result=record.get('result',record);words=[]
 for segment in result.get('segments',[]):
  if segment.get('words'):
   for row in segment['words']:
    raw=str(row.get('word',row.get('text','')));text=raw.strip()
    # Whisper can attach several word records to one printed number:
    # "$1" + ",865". Retain the complete value and aggregate only ASR
    # review bounds; never split or invent canonical word timestamps.
    if words and text and (raw==raw.lstrip() or re.search(r'[$€£₺¥₹₽٪%]',text)) and re.fullmatch(r'[,\.]\d+[$€£₺¥₹₽٪%]?[.,]?',text) and re.fullmatch(r'[$€£₺¥₹₽]?[+\-−]?\d+(?:[.,]\d+)*',words[-1]['text']):
     previous=words[-1];previous['text']+=text;previous['end']=row.get('end',segment.get('end',0))
     if _finite(previous.get('score')) and _finite(row.get('probability')):previous['score']=min(previous['score'],row['probability'])
     continue
    if text:
     for token in text.split():words.append(dict(text=token,start=row.get('start',segment.get('start',0)),end=row.get('end',segment.get('end',0)),score=row.get('probability')))
  elif str(segment.get('text','')).strip():
   # Segment timing locates a review span only, never supplies word onsets.
   for token in str(segment['text']).split():words.append(dict(text=token,start=segment.get('start',0),end=segment.get('end',0),score=None))
 return words

def _scores(acoustic,tokens):
 """Return only explicitly paired MMS token scores; never pad missing evidence."""
 if not isinstance(acoustic,dict):return {}
 raw=acoustic.get('raw_words',[]);scores=acoustic.get('scores',[])
 if len(raw)!=len(scores):return {}
 out={};cursor=0
 for index,token in enumerate(tokens):
  if cursor>=len(raw):break
  item=raw[cursor];text=item[0] if isinstance(item,(list,tuple)) else item.get('text',item.get('word',''))
  if _norm(text)==_norm(token[0]):
   score=scores[cursor]
   if isinstance(score,dict):
    if _norm(score.get('token',text))!=_norm(text):return {}
    score=score.get('score')
   if _finite(score):out[index]=score
   cursor+=1
  elif not _norm(token[0]):continue
  else:return {}
 return out

def _validated_acoustic(acoustic,audio,text,rows,lang):
 if not isinstance(acoustic,dict) or acoustic.get('method')!='mms-fa' or acoustic.get('rows_sha256')!=store.rows_sha256(rows):return None
 clock=acoustic.get('clock',{})
 if recognition.normalized_lang(clock.get('language'))!=recognition.normalized_lang(lang) or clock.get('text_sha256')!=hashlib.sha256(str(text).encode('utf8')).hexdigest():return None
 if acoustic.get('audio_sha256'):
  if acoustic['audio_sha256']!=recognition.digest(audio):return None
 else:
  stat=Path(audio).stat()
  if clock.get('audio')!=[str(Path(audio).resolve()),stat.st_size,stat.st_mtime_ns]:return None
 return acoustic.get('diagnostics')

def audit_candidate(audio,script_text,rows,canonical,lang,workdir,cache_dir=None,scene_bounds=None,recognize=None,acoustic=None,repair=True):
 if acoustic is None:
  try:acoustic=json.loads((Path(workdir)/'alignment-evidence.json').read_text('utf8'))
  except (OSError,ValueError):pass
 report=audit_structure(script_text,rows,canonical,lang,scene_bounds,acoustic)
 report['mode']='full'
 if not report['passed']:
  if repair:
   try:
    from .quality_repair import refine_candidate
   except ImportError:from quality_repair import refine_candidate
   candidate,fixed=refine_candidate(audio,script_text,rows,canonical,lang,report,workdir,scene_bounds,acoustic)
   if fixed['passed'] and candidate!=canonical:
    result=audit_candidate(audio,script_text,rows,candidate,lang,workdir,cache_dir,scene_bounds,recognize,acoustic,repair)
    result['repairs']=fixed.get('repairs',[])+result.get('repairs',[])
    if result['passed']:result['candidate_plan']=result.get('candidate_plan',candidate)
    return result
   return fixed
  return report
 try:report['fingerprints']['audio_sha256']=recognition.digest(audio)
 except OSError as error:_issue(report,'audio_unavailable',str(error));return report
 print('[quality] Checking transcript evidence',flush=True)
 try:
  record=reviewed_recognition(audio,script_text,lang,workdir)
  if record is None:record=recognize(audio,lang,cache_dir) if recognize else recognition.recognize_audio(audio,lang,cache_dir)
  heard=_recognized_words(record)
  report['recognition']={k:v for k,v in record.items() if k!='result'}
  if not heard:raise ValueError('The independent recognizer returned no speech.')
 except Exception as error:
  _issue(report,'recognition_unavailable','Independent audio validation could not finish: '+str(error));return report
 tokens=store.canonical_rows(canonical,rows);source=[t[0] for t in tokens]
 try:
  expected,emap=_stream(source,lang);observed,omap=_stream([w['text'] for w in heard],lang)
  observed,omap=_numeric_equivalence(observed,omap,source,lang)
 except (ValueError,TypeError) as error:
  _issue(report,'recognition_notation_uncertain','A numeric expression in the independent transcript needs review: '+str(error));return report
 trusted=_validated_acoustic(acoustic,audio,script_text,rows,lang)
 scores=_scores(trusted,tokens);matcher=difflib.SequenceMatcher(None,expected,observed,autojunk=False)
 operations=matcher.get_opcodes();matched={};matched_count={};expected_count={}
 for owner in emap:
  for i in owner:expected_count[i]=expected_count.get(i,0)+1
 for operation,a,b,c,d in operations:
  if operation=='equal':
   for offset in range(b-a):
    for i in emap[a+offset]:
     matched.setdefault(i,set()).update(omap[c+offset]);matched_count[i]=matched_count.get(i,0)+1
 reverse={}
 for source_index,heard_indices in matched.items():
  for heard_index in heard_indices:reverse.setdefault(heard_index,set()).add(source_index)
 seen_differences=set()
 for operation,a,b,c,d in operations:
  if operation=='equal':continue
  left={i for own in emap[a:b] for i in own};right={i for own in omap[c:d] for i in own}
  # Character alignment can allocate an inserted plural 's' to the next word
  # ("toxin stable" / "toxins stable"). Expand the affected bipartite word
  # component instead of reporting a fictitious added "stable". A genuinely
  # inserted full word has no equal-character owner and stays an insertion.
  while True:
   prior=(len(left),len(right))
   left.update(i for j in tuple(right) for i in reverse.get(j,()))
   right.update(j for i in tuple(left) for j in matched.get(i,()))
   if prior==(len(left),len(right)):break
  left,right=sorted(left),sorted(right)
  signature=(tuple(left),tuple(right))
  if signature in seen_differences:continue
  seen_differences.add(signature)
  if not left:
   anchor=min(len(tokens)-1,(emap[min(a,len(emap)-1)] or [0])[0]) if emap else 0
   start,end=tokens[anchor][1:];text=''
  else:start=tokens[left[0]][1];end=tokens[left[-1]][2];text=' '.join(source[i] for i in left)
  other=' '.join(heard[i]['text'] for i in right)
  evidence=dict(script_token_indices=left,recognized_word_indices=right,mms_scores=[scores.get(i) for i in left],recognizer_scores=[heard[i]['score'] for i in right],operation=operation)
  severity='review';code='transcript_disagreement'
  # An independent ASR omission is not proof a clearly measured short word was
  # absent. Retain the exact script, expose both pieces of model evidence.
  if operation=='delete' and not right and 0<len(left)<=2 and end-start<=.55 and all(scores.get(i,0)>=.85 for i in left) and not any(any(ch.isdigit() for ch in source[i]) for i in left):
   severity='warning';code='asr_omission_measured_word_retained'
  if operation=='insert' and not left and right and all((heard[i]['end']<tokens[0][1]-.15 or heard[i]['start']>tokens[-1][2]+.15) for i in right):
   severity='warning';code='asr_outside_script_span'
  _issue(report,code,'Independent audio recognition differs here. The printed script and measured timing were preserved.',start,end,text,other,severity,evidence)
 for group in canonical['groups']:
  token=next((i for i in range(group['a'],group['b']) if _norm(tokens[i][0])),group['a'])
  if matched_count.get(token)!=expected_count.get(token) or not matched.get(token):continue
  indexes=sorted(matched[token]);begin=min(heard[i]['start'] for i in indexes);finish=max(heard[i]['end'] for i in indexes)
  if not all(_finite(t) for t in (begin,finish)):continue
  onset=tokens[token][1]
  # ASR word bounds are coarse. Only a clearly disjoint interval requests a
  # new local acoustic check; they NEVER become replacement frame times.
  if onset<begin-.35 or onset>finish+.35:
   _issue(report,'recognition_timing_disagreement','Independent speech timing is clearly separated from this cue onset; verify the local audio before changing any frames.',onset,tokens[token][2],tokens[token][0],evidence=dict(script_token_indices=[token],recognized_interval=[begin,finish],mms_score=scores.get(token)))
 apply_user_review(report,audio,script_text,record,lang,workdir)
 _check(report,'independent_transcript_checked',True)
 report['summary']=dict(review_spans=sum(i['severity']=='review' for i in report['issues']),warnings=sum(i['severity']=='warning' for i in report['issues']),script_tokens=len(tokens),recognized_words=len(heard))
 if repair and not report['passed']:
  try:
   from .quality_repair import refine_candidate
  except ImportError:from quality_repair import refine_candidate
  candidate,report=refine_candidate(audio,script_text,rows,canonical,lang,report,workdir,scene_bounds,acoustic)
  if report['passed'] and candidate!=canonical:
   report['candidate_plan']=candidate
   report['fingerprints']=fingerprints(audio,script_text,rows,candidate,lang)
 return report
