"""Maintain a canonical subtitle set after a measured clock or script change.

Call in the private subtitle work directory before publishing it. This module
never aligns audio, edits word TSVs, or gives an unmeasured lexical token time.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import math
import tempfile
import unicodedata
try:
    from .acoustic_phrasing import plan, detect_pauses, POLICY
    from .text_boundaries import is_spoken_token, normalize_spacing, protected_boundaries
except ImportError:
    from acoustic_phrasing import plan, detect_pauses, POLICY
    from text_boundaries import is_spoken_token, normalize_spacing, protected_boundaries


def lexical_key(text):
    text = unicodedata.normalize('NFC', str(text)).casefold().replace('’', "'")
    if any(c.isdigit() for c in text) or text.strip() in '$€£¥￥₺₹₽₩₪₫฿₱₦₴﷼¢%‰':
        # Changing a decimal/group separator, % or currency changes meaning.
        # Quotes/case can change without rewriting the measured number.
        return text.strip('"“”‘’«»‹›()[]{}!?;:،؛。').rstrip('.,')
    return ''.join(c for c in text if c.isalnum())


def scene_boundaries(script_text, scene_vos):
    """Locate scene cuts by exact spoken-token sequence, never fuzzy alignment.

    Accept complete coverage or one unambiguous contiguous speech subrange.
    Returned indices address the original normalized printed-token list.
    """
    if not isinstance(scene_vos,(list,tuple)) or not all(isinstance(v,str) for v in scene_vos):
        raise ValueError('Scene subtitle boundaries require a list of scene sentences.')
    tokens=normalize_spacing(str(script_text)).split()
    lexical=[(i,lexical_key(t)) for i,t in enumerate(tokens) if lexical_key(t)]
    scenes=[[lexical_key(t) for t in normalize_spacing(v).split() if lexical_key(t)] for v in scene_vos]
    scenes=[s for s in scenes if s]
    if not scenes:return []
    pattern=[key for scene in scenes for key in scene]
    haystack=[key for _,key in lexical]
    # KMP keeps long repeated scripts linear and explicitly finds ambiguity.
    prefix=[0]*len(pattern)
    for i in range(1,len(pattern)):
        j=prefix[i-1]
        while j and pattern[i]!=pattern[j]:j=prefix[j-1]
        if pattern[i]==pattern[j]:j+=1
        prefix[i]=j
    matches=[];j=0
    for i,key in enumerate(haystack):
        while j and key!=pattern[j]:j=prefix[j-1]
        if key==pattern[j]:j+=1
        if j==len(pattern):
            matches.append(i-j+1);j=prefix[j-1]
    if len(matches)!=1:
        reason='ambiguous repeated wording' if matches else 'different or out-of-order words'
        raise ValueError('Scene sentences do not match one clear range of the current script ('+reason+'). Sync the scenes and script before generating subtitles; existing subtitles were kept.')
    protected=protected_boundaries(tokens)
    def cut(ordinal):
        if ordinal==0:return 0
        if ordinal==len(lexical):return len(tokens)
        index=lexical[ordinal][0]
        # Move an opening quote/bracket with its following spoken word; keep
        # closing punctuation on the preceding side. Never move a lexical word.
        while index and not lexical_key(tokens[index-1]) and index in protected:index-=1
        return index
    cursor=matches[0];out=[cut(cursor)]
    for scene in scenes:
        cursor+=len(scene);out.append(cut(cursor))
    return sorted(set(out))


def timed_tokens(display_tokens, source_rows):
    """Map unchanged spoken tokens exactly; only unspoken punctuation may move.

    Source and result rows use (text,start,end). Repeated words are positional,
    never fuzzy matched. A missing/changed word requires real alignment.
    """
    display_tokens, source_rows = list(display_tokens), list(source_rows)
    source_spoken = [(i, lexical_key(w[0])) for i,w in enumerate(source_rows) if lexical_key(w[0])]
    printed_spoken = [(i, lexical_key(w)) for i,w in enumerate(display_tokens) if lexical_key(w)]
    if [k for _,k in source_spoken] != [k for _,k in printed_spoken]:
        raise ValueError('Script words or numeric expressions differ from the measured word cache. Re-align the changed speech; no replacement times were invented.')
    result = [None] * len(display_tokens)
    for (di,_),(si,_) in zip(printed_spoken,source_spoken):
        row=source_rows[si]
        result[di]=(display_tokens[di],row[1],row[2])
    # Punctuation has no phoneme. Use the next measured onset before the first
    # word, otherwise the preceding word end (bounded by the next onset).
    previous_end = None
    for i, token in enumerate(display_tokens):
        if result[i] is not None:
            previous_end=result[i][2]
            continue
        next_start=next((r[1] for r in result[i+1:] if r is not None),None)
        if previous_end is None and next_start is None:
            raise ValueError('The script contains no measured speech.')
        clock = next_start if previous_end is None else previous_end
        if next_start is not None: clock=min(clock,next_start)
        result[i]=(token,clock,clock)
    return result


def rows_sha256(rows):
    # Numeric representation is stable across int/float JSON and TSV readers.
    payload=[[str(t),float(s),float(e)] for t,s,e in rows]
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()


def source_signature(rows, filename=None):
    return dict(filename=Path(filename).name if filename else None,row_count=len(rows),
                rows_sha256=rows_sha256(rows),
                text_sha256=hashlib.sha256(json.dumps([str(w[0]) for w in rows],ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest())


def apply_measurement_overrides(rows, overrides):
    """Apply explicitly evidenced caption-only measurements to a copy."""
    out=list(rows);seen=set()
    for override in overrides or ():
        if not isinstance(override,dict):
            raise ValueError('Caption measurement override must include its source mapping and acoustic evidence.')
        i=override.get('source_index')
        if isinstance(i,bool) or not isinstance(i,int) or not 0 <= i < len(rows) or i in seen:
            raise ValueError('Caption measurement override has an invalid or repeated source index.')
        seen.add(i);text,start,end=rows[i]
        if (override.get('text')!=text or override.get('source_start')!=start or override.get('source_end')!=end):
            raise ValueError('Caption measurement override no longer matches the original word clock.')
        a,b=override.get('start'),override.get('end');proof=override.get('provenance',{})
        if not all(isinstance(v,(int,float)) and math.isfinite(v) for v in (a,b)) or a < 0 or b <= a:
            raise ValueError('Caption measurement override needs a positive measured interval.')
        if (not isinstance(proof,dict) or not proof.get('method') or
                not re.fullmatch(r'[0-9a-fA-F]{64}',str(proof.get('clip_sha256',''))) or
                not isinstance(proof.get('source_offset'),(int,float)) or
                not math.isfinite(proof['source_offset']) or proof['source_offset'] < 0 or
                not isinstance(proof.get('diagnostics'),dict)):
            raise ValueError('Caption measurement override lacks its audio clip hash, source offset or measurement diagnostics.')
        out[i]=(text,a,b)
    return out


def bind_source(canonical, rows, filename=None, measurement_overrides=None):
    corrected=apply_measurement_overrides(rows,measurement_overrides)
    tokens=canonical.get('tokens',[])
    expected=timed_tokens([t['text'] for t in tokens],corrected)
    source_spoken=[i for i,w in enumerate(rows) if lexical_key(w[0])]
    lexical_index=0
    for token,row in zip(tokens,expected):
        if lexical_key(token['text']):
            if token.get('start')!=row[1] or token.get('end')!=row[2]:
                raise ValueError('Canonical token time differs from its source without a validated measurement override.')
            token['source_index']=source_spoken[lexical_index];lexical_index+=1
    canonical['source']=source_signature(rows,filename)
    canonical['measurement_overrides']=list(measurement_overrides or [])
    return canonical


def canonical_rows(canonical, source_rows):
    """Validate a sidecar against the unchanged TSV and return printed rows.

    Callers pass (text,start,end), not the exporter's (start,end,text) ordering.
    Punctuation can increase row count; source signature replaces the old
    invalid assumption that canonical token count must equal TSV row count.
    """
    if canonical.get('policy')!=POLICY:
        raise ValueError('Unsupported canonical subtitle phrase policy.')
    source=canonical.get('source',{})
    if source.get('rows_sha256')!=rows_sha256(source_rows) or source.get('row_count')!=len(source_rows):
        raise ValueError('The canonical subtitle plan belongs to a different measured word clock.')
    tokens=canonical.get('tokens',[])
    if (not isinstance(tokens,list) or not tokens or canonical.get('token_count')!=len(tokens) or
            not all(isinstance(t,dict) and isinstance(t.get('text'),str) and
                    all(isinstance(t.get(k),(int,float)) and math.isfinite(t[k]) for k in ('start','end')) for t in tokens)):
        raise ValueError('The canonical subtitle plan has an incomplete printed-token list.')
    corrected=apply_measurement_overrides(source_rows,canonical.get('measurement_overrides',[]))
    expected=timed_tokens([t['text'] for t in tokens],corrected)
    source_spoken=[i for i,w in enumerate(source_rows) if lexical_key(w[0])]
    lexical_index=0
    for token,row in zip(tokens,expected):
        if token.get('start')!=row[1] or token.get('end')!=row[2]:
            raise ValueError('Canonical printed-token times lack matching measured source evidence.')
        if lexical_key(token['text']):
            if token.get('source_index')!=source_spoken[lexical_index]:
                raise ValueError('Canonical printed-token source mapping is stale.')
            lexical_index+=1
    return expected


def load_words(path):
    rows=[]
    for line in Path(path).read_text('utf-8-sig').splitlines():
        if not line.strip(): continue
        start,end,text=line.split('\t',2)
        rows.append((text,float(start),float(end)))
    if not rows: raise ValueError('No measured word timestamps are available.')
    return rows


def _cues_text(path):
    blocks=re.split(r'\r?\n\s*\r?\n',Path(path).read_text('utf-8-sig').strip())
    cues=[]
    for block in blocks:
        lines=block.splitlines()
        arrow=next((i for i,s in enumerate(lines) if '-->' in s),None)
        if arrow is not None:
            text='\n'.join(lines[arrow+1:]).strip()
            if text: cues.append(text)
    return cues


def _pick_wordfile(wd,old,wordfile):
    if wordfile:
        p=Path(wordfile)
        return p if p.is_absolute() else wd/p
    hinted=old.get('source',{}).get('filename')
    if hinted and (wd/Path(hinted).name).is_file(): return wd/Path(hinted).name
    files=sorted(wd.glob('words_*.tsv'))
    for name in ('words_medium_en_vad.tsv','words_medium_en.tsv','words_medium_vad.tsv','words_medium.tsv'):
        preferred=wd/name
        if preferred in files: return preferred
    if len(files)==1: return files[0]
    raise ValueError('Choose the measured word TSV for this subtitle take; none or several unrecognized caches were found.')


def _timestamp(t):
    # SRT has milliseconds, while our clock is frames. Rounding downward would
    # make importers that floor frame positions show a cue one frame early.
    ms=int(math.ceil(max(0,t)*1000-1e-7));seconds,ms=divmod(ms,1000)
    minutes,seconds=divmod(seconds,60);hours,minutes=divmod(minutes,60)
    return f'{hours:02d}:{minutes:02d}:{seconds:02d},{ms:03d}'


def serialize_srt(canonical):
    return ''.join(f'{i}\n{_timestamp(g["start"])} --> {_timestamp(g["end"])}\n{g["text"]}\n\n'
                   for i,g in enumerate(canonical['groups'],1))


def replan(wd,srt,audio,lang,script=None,forced_boundaries=None,wordfile=None,pauses=None,fps=60,
           measurement_overrides=None):
    """Refresh SRT/plan/policy from the current clock, only after full validation.

    `forced_boundaries` refers to the canonical printed-token list. Supplying an
    empty list deliberately clears old fixed boundaries. None preserves only
    indices whose complete token sequence is still valid; otherwise updated
    SRT cue boundaries are mapped by exact token counts. Callers knowing the
    new scene text should supply fresh scene boundaries instead.
    """
    wd=Path(wd);srt=Path(srt)
    if not srt.is_absolute(): srt=wd/srt
    old_path=wd/'phrase-plan.json'
    try: old=json.loads(old_path.read_text('utf8'))
    except (OSError,ValueError): old={}
    path=_pick_wordfile(wd,old,wordfile);rows=load_words(path)
    cue_texts=_cues_text(srt) if srt.is_file() else []
    warnings=[]
    if measurement_overrides is None:
        same_source=old.get('source',{}).get('rows_sha256')==rows_sha256(rows)
        measurement_overrides=old.get('measurement_overrides',[]) if same_source else []
        if old.get('measurement_overrides') and not same_source:
            warnings.append(dict(code='stale_measurement_overrides_discarded',
                message='The source clock changed; prior caption-only measurements need fresh validation.'))
    corrected=apply_measurement_overrides(rows,measurement_overrides)
    text=script if script is not None else ' '.join(cue_texts) if cue_texts else ' '.join(w[0] for w in rows)
    tokens=timed_tokens(str(text).split(),corrected)
    keys=[lexical_key(w[0]) for w in tokens]
    if forced_boundaries is None:
        old_tokens=old.get('tokens',[])
        old_keys=[lexical_key(t.get('text','')) for t in old_tokens if isinstance(t,dict)]
        if old_keys==keys and 'forced_boundaries' in old:
            forced_boundaries=old['forced_boundaries']
        else:
            forced_boundaries=[]
            printed=[t for cue in cue_texts for t in cue.split()]
            if [lexical_key(t) for t in printed]==keys:
                count=0
                for cue in cue_texts[:-1]:
                    count+=len(cue.split());forced_boundaries.append(count)
                if old:
                    warnings.append(dict(code='fixed_boundaries_remapped_from_updated_srt',
                        message='The token sequence changed; old plan indices were discarded.'))
            elif old:
                warnings.append(dict(code='stale_fixed_boundaries_discarded',
                    message='The token sequence changed; supply current scene boundaries to retain scene-specific grouping.'))
    if pauses is None:
        if not audio or not Path(audio).is_file():
            raise ValueError('The current voice-over is needed to refresh the phrase plan after a clock or script change.')
        pauses=detect_pauses(audio)
    canonical=plan(tokens,pauses,lang,forced_boundaries=forced_boundaries,fps=fps)
    canonical['warnings'].extend(warnings)
    bind_source(canonical,rows,path,measurement_overrides)
    payloads={srt:serialize_srt(canonical),old_path:json.dumps(canonical,ensure_ascii=False,indent=2),
              wd/'caption-policy.json':json.dumps(dict(clock=POLICY,phrase_policy=POLICY,schema=1))}
    # The caller publishes this private directory transactionally. Prepare all
    # complete files before replacing any member; never expose a half-written SRT.
    staged=[]
    try:
        for target,content in payloads.items():
            target.parent.mkdir(parents=True,exist_ok=True)
            fd,name=tempfile.mkstemp(prefix='.'+target.name+'.',suffix='.tmp',dir=target.parent)
            with os.fdopen(fd,'w',encoding='utf8',newline='\n') as f:f.write(content)
            staged.append((Path(name),target))
        for temp,target in staged: os.replace(temp,target)
    finally:
        for temp,_ in staged:temp.unlink(missing_ok=True)
    return canonical
