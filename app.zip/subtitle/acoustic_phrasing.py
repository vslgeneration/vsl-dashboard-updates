"""One speech/phrase plan for every subtitle consumer; no invented word times.

Timing, cue grouping and line wrapping are deliberately separate. Character
counts are soft readability preferences, never permission to break a number,
name or quoted word. Unknown languages use neutral punctuation/pause evidence.
"""
import bisect
import math
import re
import subprocess
import os
import statistics
import unicodedata
try:
    from .text_boundaries import protected_boundaries, word_key, is_spoken_token, is_abbreviation, numeric_units
except ImportError:
    from text_boundaries import protected_boundaries, word_key, is_spoken_token, is_abbreviation, numeric_units

POLICY = 'speech-v998'

GLUE = {
    'en': "a an the and or but of to for with from into your my our their its her his i she he we you it this that these those is are was were has have had will would shall should can could may might must do does did be been being not no so too very quite then what how why which who whose against on in at by because although unless if while when it's that's there's here's i'm you're we're they're he's she's don't doesn't didn't won't wouldn't shouldn't can't couldn't isn't aren't wasn't weren't i've you've we've they've i'll you'll we'll they'll",
    'fr': "le la les un une des du de au aux et ou mais à pour avec sans mon ma mes votre vos est sont ne c'est s'est j'ai j'étais il l'a qu'il qu'elle n'est n'a",
    'de': 'der die das den dem des ein eine einen einem und oder aber von zu für mit ohne mein meine dein deine ist sind nicht',
    'es': 'el la los las un una unos unas de del al y o pero para con sin mi mis tu tus su sus es son no',
    'it': 'il lo la i gli le un uno una di del della al alla e o ma per con senza mio mia tuo tua è sono non',
    'tr': 've veya ama ile için bir bu şu o çok daha en her',
    'pt': 'o a os as um uma uns umas de do da dos das ao aos e ou mas para com sem meu minha seu sua é são não',
    'nl': 'de het een en of maar van naar voor met zonder mijn jouw zijn haar is zijn niet',
    'ru': 'и или но а в во на к ко с со из от до для без при у не ни это',
    'uk': 'і й або але в у на до з із для без не це',
    'pl': 'i lub ale w na do z ze od dla bez nie ten ta to',
    'ar': 'و أو لكن في من إلى على مع عن دون هذا هذه الذي التي',
    'fa': 'و یا اما در از به با برای این آن که',
    'hi': 'और या लेकिन कि यह वह एक के की का को से में पर लिए',
    'id': 'dan atau tetapi di ke dari dengan untuk yang ini itu tidak',
    'vi': 'và hoặc nhưng của với cho trong từ này đó một',
}
CLAUSE_START = {
    'en': 'and but because although while whereas when if unless so yet then',
    'fr': 'et mais car parce lorsque quand si pourtant donc puis',
    'de': 'und aber weil obwohl während wenn damit dann deshalb',
    'es': 'y pero porque aunque mientras cuando si entonces',
    'it': 'e ma perché se quando mentre quindi',
    'tr': 've ama fakat çünkü eğer ancak sonra',
    'pt': 'e mas porque embora quando enquanto se então',
    'nl': 'en maar omdat hoewel wanneer als dus',
    'ru': 'и но потому хотя когда если поэтому',
    'uk': 'і але тому хоча коли якщо',
    'pl': 'i ale ponieważ chociaż kiedy jeśli',
    'ar': 'ولكن لكن لأن عندما إذا ثم',
    'fa': 'اما زیرا وقتی اگر سپس',
    'hi': 'लेकिन क्योंकि जब अगर फिर',
    'id': 'tetapi karena ketika jika lalu',
    'vi': 'nhưng vì khi nếu rồi',
}
PREPOSITIONS = {
    'en': 'of to for with from into on in at by against under underneath',
    'fr': 'de du des à au aux pour avec sans dans sur',
    'de': 'von zu für mit ohne in auf an bei',
    'es': 'de del al para con sin en por',
    'it': 'di del della al alla per con senza in',
    'tr': 'ile için',
}
PAIRS = set(('blood pressure', 'blood sugar', 'blood work', 'nitric oxide', 'amino acid',
             'heart attack', 'black garlic', 'clinical trial', 'clinical trials',
             'coenzyme q10', 'arterial stiffness', 'paid for', 'next to', 'kind of',
             'stress response', 'energy needs', 'pressed flat', 'trying to'))
_AGE_DETERMINERS = frozenset('a an one another this that the two three four five some several'.split())
_PERSON_NOUNS = frozenset(('woman women man men girl girls boy boys grandmother grandfather mother father '
                          'patient patients adult adults child children daughter son teacher doctor '
                          'dermatologist researcher nurse retiree resident person people').split())


def _age_adjective(text):
    text = text.replace('‐', '-').replace('‑', '-').casefold()
    return bool(re.fullmatch(r'(?:\d+|[a-z]+(?:-[a-z]+)*)-years?-old', text))


def bare(text):
    return word_key(text)


def boundary(words, index, lang='en', _protected=None):
    """Semantic preference only. None means a structurally protected join."""
    left, right = words[index-1][0], words[index][0]
    mark = left.rstrip('"”’»›)]}')
    if not mark and index > 1:
        # A detached closing quote must not hide the sentence punctuation.
        mark = words[index-2][0].rstrip('"”’»›)]}')
    if index in (protected_boundaries([w[0] for w in words]) if _protected is None else _protected):
        return None
    language = (lang or '').lower().replace('_', '-').split('-')[0]
    if language == 'en':
        # A numeral acting as a determiner belongs to its age noun phrase.
        # Standalone "one" ("I chose one. Then...") is not globally glued.
        if bare(left) in _AGE_DETERMINERS and _age_adjective(right): return None
        if _age_adjective(left) and bare(right) in _PERSON_NOUNS: return None
    if language == 'en' and bare(left)+' '+bare(right) in PAIRS:
        return None
    if mark.endswith(('.', '!', '?', '…', '。', '！', '？', '؟', '।', '॥')):
        if not is_abbreviation(left):
            return 5.0
    if mark.endswith((';', ':', '؛')): return 3.5
    if mark.endswith((',', '،', '、', '—', '–')): return 3.0
    if bare(left) in GLUE.get(language, '').split():
        return -8.0
    if bare(right) in CLAUSE_START.get(language, '').split(): return 1.5
    if bare(right) in PREPOSITIONS.get(language, '').split(): return -2.0
    return 0.0


def detect_pauses(audio):
    result = subprocess.run(['ffmpeg', '-v', 'info', '-nostdin', '-i', str(audio),
        '-af', 'silencedetect=noise=-35dB:d=0.06', '-f', 'null', '-'],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, timeout=180,
        creationflags=0x08000000 if os.name == 'nt' else 0)
    out, start = [], None
    for line in result.stderr.decode('utf8', errors='replace').splitlines():
        match = re.search(r'silence_start: ([\d.]+)', line)
        if match: start = float(match[1])
        match = re.search(r'silence_end: ([\d.]+)', line)
        if match and start is not None:
            out.append((start, float(match[1]))); start = None
    return out


def pause_strengths(words, pauses):
    """Map pauses only to adjacent phonetic boundaries, never inside another word."""
    strength = [0.0]*len(words)
    onsets = [w[1] for w in words]
    for a, b in pauses:
        i = bisect.bisect_right(onsets, b+.025)
        for k in (i-1, i):
            if not 0 < k < len(words): continue
            previous, following = words[k-1], words[k]
            if (a >= previous[2]-.055 and b <= following[1]+.055 and
                    abs(b-following[1]) <= .12):
                strength[k] = max(strength[k], b-a)
    return strength


def _width(text):
    # Wide scripts take more display space; combining marks take none.
    return sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in ('W', 'F') else 1
               for c in text)


def _voiced(words, a, b):
    indices = [i for i in range(a, b) if is_spoken_token(words[i][0])]
    if not indices:
        raise ValueError('A subtitle phrase contains only punctuation; keep it with the spoken words.')
    return indices[0], indices[-1]


def _validate(words):
    previous = -math.inf
    for i, row in enumerate(words):
        if len(row) < 3 or not isinstance(row[0], str) or not row[0].strip():
            raise ValueError('Subtitle planning requires original text and measured start/end for every token.')
        if not all(isinstance(t, (int, float)) and math.isfinite(t) for t in row[1:3]):
            raise ValueError('Subtitle planning received a missing or non-finite word time.')
        start, end = row[1:3]
        if start < 0 or end < start or start < previous - 1e-7:
            raise ValueError('Measured word times are out of order; phrase planning cannot repair the speech clock.')
        if is_spoken_token(row[0]) and end <= start:
            raise ValueError('Token %d (%s) has no measured speech duration; align it before planning subtitles.' % (i, row[0]))
        previous = start


def _line_break(words, a, b, scores, target):
    """Wrap a chosen cue, never create another cue or move its clock."""
    full = ' '.join(w[0] for w in words[a:b])
    if _width(full) <= target: return [full], []
    best = None
    for k in range(a + 1, b):
        if scores[k] is None: continue
        left, right = (' '.join(w[0] for w in rows) for rows in (words[a:k], words[k:b]))
        wl, wr = _width(left), _width(right)
        if not any(is_spoken_token(w[0]) for w in words[a:k]) or not any(is_spoken_token(w[0]) for w in words[k:b]):
            continue
        cost = max(0, max(wl, wr) - target) * 3 + abs(wl - wr) * .10
        cost += max(0, 10 - min(wl, wr)) * .8 - scores[k] * .8
        if best is None or cost < best[0]: best = (cost, k, left, right)
    return ([best[2], best[3]], [best[1]]) if best else ([full], [])


def plan(words, pauses=(), lang='en', max_words=8, max_chars=42, max_seconds=3.5,
         forced_boundaries=(), fps=60):
    """Return canonical phrases over immutable half-open original token indices.

    Limits are soft targets. A safety ceiling stops unreadable blocks, while an
    inseparable expression may exceed the target without losing any token.
    Explicit scene/source boundaries take priority and are reported if they
    intersect a protected expression, so callers can show that conflict.
    """
    words = list(words)
    language = (lang or '').lower().replace('_', '-').split('-')[0]
    if not isinstance(fps, (int, float)) or not math.isfinite(fps) or fps <= 0:
        raise ValueError('Subtitle frame rate must be positive.')
    result = dict(schema=1, policy=POLICY, fps=fps, language=language, token_count=len(words),
                  tokens=[dict(text=w[0],start=w[1],end=w[2]) for w in words], groups=[], warnings=[])
    if not words: return result
    _validate(words)
    if not all(isinstance(v, (int, float)) and math.isfinite(v) and v > 0 for v in (max_words, max_chars, max_seconds)):
        raise ValueError('Phrase readability targets must be positive finite numbers.')
    if language not in GLUE:
        result['warnings'].append(dict(code='neutral_language_rules', language=language,
            message='Using measured pauses and Unicode punctuation; no language-specific syntax rules are available.'))
    n = len(words)
    forced = set()
    for index in forced_boundaries or ():
        if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index <= n:
            raise ValueError('A fixed phrase boundary must be an original token index between 0 and token_count.')
        if 0 < index < n: forced.add(index)
    result['forced_boundaries'] = sorted(forced)
    units=numeric_units([w[0] for w in words])
    for unit in units:
        if forced & set(unit['indices'][1:]):
            raise ValueError('A fixed subtitle boundary splits the numeric expression '+unit['display']+'. Keep its shared acoustic interval together.')
    result['numeric_units']=[dict(a=u['indices'][0],b=u['indices'][-1]+1,text=u['display'],
        start=words[u['indices'][0]][1],end=words[u['indices'][-1]][2],
        shared_interval=len({(words[i][1],words[i][2]) for i in u['indices']})==1) for u in units]
    protected = protected_boundaries([w[0] for w in words])
    scores = [None] + [boundary(words, i, language, protected) for i in range(1, n)]
    for index in sorted(forced):
        if scores[index] is None:
            result['warnings'].append(dict(code='fixed_boundary_inside_expression', token_index=index,
                left=words[index-1][0], right=words[index][0]))
    # Line wrapping must still respect a protected expression even where a
    # caller explicitly requires a scene boundary. Only cue grouping overrides.
    line_scores = list(scores)
    for index in forced: scores[index] = 5.0
    acoustic = pause_strengths(words, pauses)
    gaps = [0.0] + [max(0.0, words[i][1] - words[i-1][2]) for i in range(1, n)]
    small_gaps = [g for g in gaps if .015 <= g <= .25]
    threshold = max(.14, min(.30, (statistics.median(small_gaps) * 2.8) if small_gaps else .18))
    strength = [max(a, g) for a, g in zip(acoustic, gaps)]
    required = forced | {i for i in range(1, n) if scores[i] is not None and scores[i] >= 5}
    # Sentence punctuation is hard evidence; a breath is not. Pause crossings
    # carry a substantial cost, allowing short grammatical units to stay intact.
    crossing = [0.0] * (n + 1)
    for i in range(1, n):
        penalty = 0.0
        if scores[i] is not None and strength[i] >= threshold:
            penalty = min(13.0, 5.0 + (strength[i] - threshold) * 18)
            if scores[i] < 0: penalty *= .2
        crossing[i+1] = crossing[i] + penalty
    limits = [0] + sorted(required) + [n]
    pairs = []
    for lo, hi in zip(limits, limits[1:]):
        dp, choice = {hi: 0.0}, {}
        for a in range(hi - 1, lo - 1, -1):
            if a > lo and scores[a] is None: continue
            text = ''
            for b in range(a + 1, hi + 1):
                text += (' ' if text else '') + words[b-1][0]
                chars, count = _width(text), b - a
                seconds = words[b-1][2] - words[a][1]
                if b < hi and scores[b] is None: continue
                # The first feasible end may be a long protected expression.
                # It is retained intact; arbitrary unaligned giant tokens fail.
                oversize = chars > max(96, max_chars * 2.4) or count > max(24, max_words * 3) or seconds > max(8, max_seconds * 2.3)
                if oversize and b > a + 1 and any(scores[k] is not None for k in range(a+1, b)):
                    break
                if b not in dp: continue
                try: first, last = _voiced(words, a, b)
                except ValueError: continue
                spoken_count = sum(is_spoken_token(w[0]) for w in words[a:b])
                display_end = words[b][1] if b < n else words[last][2]
                display = display_end - words[first][1]
                cost = 7.0
                cost += (max(0, chars - max_chars) / 10) ** 2 * 1.4
                cost += max(0, count - max_words) ** 2 * .22
                cost += max(0, seconds - max_seconds) ** 2 * .6
                if spoken_count == 1 and hi-lo > 1: cost += 7
                elif spoken_count == 2 and hi-lo > 2: cost += 1.5
                if display < .7 and b < hi: cost += (.7 - display) * 12
                if b < hi and scores[b] < 3:
                    # An unpunctuated sub-second noun/verb fragment is rarely
                    # a complete idea. Merge it without stretching its times.
                    cost += max(0, 1.1 - display) * 20
                cost += crossing[b] - crossing[a+1]
                if b < hi:
                    # After a glue word is expensive even if a character limit
                    # prefers it. Real pauses can promote a complete short unit.
                    cost -= scores[b] * .9
                    if strength[b] >= threshold:
                        cost -= min(7, 3 + (strength[b] - threshold) * 16)
                    elif strength[b] >= threshold * .6:
                        cost -= 1.0
                total = cost + dp[b]
                if total < dp.get(a, math.inf): dp[a], choice[a] = total, b
        if lo not in choice:
            raise ValueError('Cannot make readable phrases from these measured tokens. Check word-level alignment for this language; no times were invented.')
        a = lo
        while a < hi:
            b = choice[a]; pairs.append((a, b)); a = b
    for a, b in pairs:
        first, last = _voiced(words, a, b)
        lines, breaks = _line_break(words, a, b, line_scores, max_chars)
        if len(lines) == 1 and _width(lines[0]) > max(96, max_chars * 2.4):
            raise ValueError('A long token/expression has no measured internal word boundaries; align it before splitting subtitles.')
        result['groups'].append(dict(a=a, b=b, start=words[first][1], end=words[last][2],
            text='\n'.join(lines), lines=lines, line_breaks=breaks))
    for previous, following in zip(result['groups'], result['groups'][1:]):
        previous['end'] = following['start']
    if any(g['end'] <= g['start'] for g in result['groups']):
        raise ValueError('Measured phrase starts are not increasing; keep the existing subtitles and check the alignment.')
    for group in result['groups']:
        group['measured_start'], group['measured_end'] = group['start'], group['end']
        group['start_frame'] = int(group['start'] * fps + .5 + 1e-9)
        group['end_frame'] = int(group['end'] * fps + .5 + 1e-9)
        group['start'], group['end'] = group['start_frame'] / fps, group['end_frame'] / fps
        if group['end_frame'] <= group['start_frame']:
            raise ValueError('Measured phrase is shorter than one frame; keep the existing subtitles.')
    return result


def slices(words, pauses=(), lang='en', max_words=8, max_chars=42, max_seconds=3.5, forced_boundaries=()):
    return [(g['a'], g['b']) for g in plan(words, pauses, lang, max_words, max_chars,
                                         max_seconds, forced_boundaries)['groups']]


def captions(words, pauses=(), lang='en', fps=60, **limits):
    if not isinstance(fps, (int, float)) or not math.isfinite(fps) or fps <= 0:
        raise ValueError('Subtitle frame rate must be positive.')
    groups = plan(words, pauses, lang, fps=fps, **limits)['groups']
    result = [dict(start=g['start'], end=g['end'], text=g['text']) for g in groups]
    for previous, following in zip(result, result[1:]):
        previous['end'] = following['start']
    if any(c['end'] <= c['start'] for c in result):
        raise ValueError('Measured phrase is shorter than one frame; keep the previous subtitles.')
    return result
