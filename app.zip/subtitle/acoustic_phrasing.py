"""Short caption phrases from measured speech, without redistributing word times."""
import bisect
import math
import re
import subprocess
import os

GLUE = {
    'en': 'a an the and or but of to for with from into your my our their its her his i she he we you this that is are was were has have will can not against on in at by',
    'fr': 'le la les un une des du de au aux et ou mais à pour avec sans mon ma mes votre vos est sont ne',
    'de': 'der die das den dem des ein eine einen einem und oder aber von zu für mit ohne mein meine dein deine ist sind nicht',
    'es': 'el la los las un una unos unas de del al y o pero para con sin mi mis tu tus su sus es son no',
    'it': 'il lo la i gli le un uno una di del della al alla e o ma per con senza mio mia tuo tua è sono non',
    'tr': 've veya ama ile için bir bu şu o çok daha en her',
}
PAIRS = set(('blood pressure', 'blood sugar', 'blood work', 'nitric oxide', 'amino acid',
             'heart attack', 'black garlic', 'clinical trial', 'clinical trials',
             'coenzyme q10', 'arterial stiffness', 'paid for', 'next to', 'kind of',
             'stress response', 'energy needs', 'pressed flat', 'trying to'))


def bare(text):
    return text.casefold().strip('.,;:!?…“”‘’«»‹›()[]{}"')


def boundary(words, index, lang='en'):
    left, right = words[index-1][0], words[index][0]
    mark = left.rstrip('"”’»›)]}')
    if (re.fullmatch(r'[«‹„“¿¡(\[{]+', left) or
            re.fullmatch(r'[»›”!?.,;:%‰°)\]}]+', right) or left.endswith(("'", '’')) or
            (re.search(r'\d$', left) and re.match(r'^(?:[%‰€$£]|kg\b|mg\b|ml\b|cm\b)', right, re.I)) or
            (re.fullmatch(r'\d{1,3}', left) and re.match(r'^\d{3}(?:\D|$)', right))):
        return None
    if bare(left)+' '+bare(right) in PAIRS:
        return None
    if mark.endswith(('.', '!', '?', '…', ';', ':')):
        # Initials/abbreviations before a lower-case continuation are not a sentence.
        if not (mark.endswith('.') and right.lstrip('«“"')[:1].islower()):
            return 5.0
    if bare(left) in GLUE.get(lang.split('-')[0], GLUE['en']).split():
        return -8.0
    return 2.0 if mark.endswith((',', '—', '–')) else 0.0


def detect_pauses(audio):
    result = subprocess.run(['ffmpeg', '-v', 'info', '-nostdin', '-i', str(audio),
        '-af', 'silencedetect=noise=-35dB:d=0.06', '-f', 'null', '-'],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, timeout=180,
        creationflags=0x08000000 if os.name == 'nt' else 0)
    out, start = [], None
    for line in result.stderr.decode('utf8', errors='replace').splitlines():
        match = re.search(r'silence_start: ([\d.]+)', line)
        if match: start = float(match[1])
        match = re.search(r'silence_end: ([\d.]+)', line)
        if match and start is not None:
            out.append((start, float(match[1]))); start = None
    return out


def pause_strengths(words, pauses):
    """Map pauses only to adjacent phonetic boundaries, never inside another word."""
    strength = [0.0]*len(words)
    onsets = [w[1] for w in words]
    for a, b in pauses:
        i = bisect.bisect_right(onsets, b+.025)
        for k in (i-1, i):
            if not 0 < k < len(words): continue
            previous, following = words[k-1], words[k]
            if (a >= previous[2]-.055 and b <= following[1]+.055 and
                    abs(b-following[1]) <= .12):
                strength[k] = max(strength[k], b-a)
    return strength


def slices(words, pauses=(), lang='en', max_words=10, max_chars=48, max_seconds=3.8):
    """Globally choose readable phrases; actual pauses outrank balanced character counts."""
    n = len(words)
    if not n: return []
    acoustic = pause_strengths(words, pauses)
    scores = [None]+[boundary(words, i, lang) for i in range(1, n)]
    # Strong pauses and sentence ends separate utterances. Never turn a minor
    # breath inside a small grammatical unit into a two-word flash.
    sentence_ends = {i for i in range(1, n) if scores[i] is not None and scores[i] >= 5}
    required = set(sentence_ends)
    for i in range(1,n):
        lo=max([0]+[k for k in sentence_ends if k<i])
        hi=min([n]+[k for k in sentence_ends if k>i])
        if scores[i] is not None and scores[i]>=0 and acoustic[i]>=.32 and i-lo>=3 and hi-i>=3:
            required.add(i)
    dp, choice = [math.inf]*(n+1), {}
    dp[n] = 0
    for a in range(n-1, -1, -1):
        for b in range(a+1, min(n, a+max_words)+1):
            count = b-a
            chars = len(' '.join(w[0] for w in words[a:b]))
            seconds = words[b-1][2]-words[a][1]
            if count > 1 and (chars > max_chars or seconds > max_seconds): break
            if any(a < k < b for k in required): break
            if b < n and scores[b] is None: continue
            cost = 8.0 + max(0, chars-36)*.12 + max(0, 16-chars)*.12
            if count == 1 and n > 1: cost += 5
            if seconds < .65 and b < n and a not in required: cost += 4
            if b < n:
                gap = max(0, words[b][1]-words[b-1][2])
                sound = min(4.5, max(acoustic[b], gap)*30)
                cost -= min(6.5, scores[b]+sound)
                if bare(words[b][0]) in ('on', 'in', 'at', 'against', 'under', 'underneath', 'of'):
                    cost += 2
            if cost+dp[b] < dp[a]: dp[a], choice[a] = cost+dp[b], b
    if 0 not in choice:
        # Never lose a number/unit or opening/closing quote just to meet a width
        # preference. Expand only the exceptional unbreakable phrase.
        if max_words < 16:
            return slices(words, pauses, lang, 16, max(80,max_chars), max(6,max_seconds))
        raise ValueError('Cannot split measured words without separating punctuation or a phrase.')
    result, a = [], 0
    while a < n:
        b = choice[a]; result.append((a,b)); a = b
    return result


def captions(words, pauses=(), lang='en', fps=60, **limits):
    groups = slices(words, pauses, lang, **limits)
    snap = lambda t: round(int(max(0,t)*fps+.5+1e-9)/fps, 5)
    result = [dict(start=snap(words[a][1]), end=snap(words[b-1][2]),
                   text=' '.join(w[0] for w in words[a:b])) for a,b in groups]
    for previous, following in zip(result, result[1:]):
        previous['end'] = following['start']
    if any(c['end'] <= c['start'] for c in result):
        raise ValueError('Measured phrase is shorter than one frame; keep the previous subtitles.')
    return result
