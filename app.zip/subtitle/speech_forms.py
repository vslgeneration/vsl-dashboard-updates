"""Alignment-only Unicode/number spellings. Displayed script tokens never change."""
from functools import lru_cache
from pathlib import Path
from decimal import Decimal,InvalidOperation
import os,re,sys,unicodedata

VERSION='spoken-forms-998'
VENDOR=Path(__file__).resolve().parent/'_vendor'
if str(VENDOR) not in sys.path:sys.path.insert(0,str(VENDOR))
_ISO3={'en':'eng','fr':'fra','de':'deu','es':'spa','it':'ita','tr':'tur','pt':'por','ru':'rus','uk':'ukr','ar':'ara','fa':'fas','he':'heb','hi':'hin','ja':'jpn','zh':'zho','ko':'kor','th':'tha','el':'ell','pl':'pol','nl':'nld'}
_PERCENT={'en':'percent','fr':'pour cent','de':'Prozent','es':'por ciento','it':'per cento','tr':'yüzde','pt':'por cento','ru':'процентов','uk':'відсотків','ar':'بالمئة','fa':'درصد','he':'אחוז','hi':'प्रतिशत','ja':'パーセント','ko':'퍼센트','nl':'procent','pl':'procent','el':'τοις εκατό'}
_CURRENCY={'$':'USD','€':'EUR','£':'GBP','₺':'TRY','¥':'JPY','₹':'INR','₽':'RUB'}
_DECIMAL_COMMA={'fr','de','es','it','tr','pt','ru','uk','pl','nl','el','sv','da','fi','nb','no','cs','sk','ro','hu','bg'}

def validate_expressions(text):
 # These are single spoken numeric units, not independent whitespace words.
 # Until their source-token mapping is contextual, reject rather than measure
 # "1 000" as "one zero" or silently omit a detached currency/percent symbol.
 if re.search(r'(?<!\w)\d{1,3}[ \u00a0\u202f]+\d{3}(?!\d)',str(text)):
  raise ValueError('A number uses spaces as thousands separators. Use the selected language\'s unspaced number notation (for example 1000), then sync again. Previous subtitles were preserved.')
 if re.search(r'[$€£₺¥₹₽][ \t\u00a0\u202f]+\d|\d[ \t\u00a0\u202f]+[%٪$€£₺¥₹₽]',str(text)):
  raise ValueError('A currency or percent symbol is separated from its number. Join the symbol to the number before syncing; previous subtitles were preserved.')

def language(lang=None):
 return str(lang or os.environ.get('VSL_LANG') or 'en').strip().replace('-','_').lower()

@lru_cache(maxsize=1)
def romanizer():
 from uroman import Uroman
 return Uroman(data_dir=VENDOR/'uroman'/'linguistic')

def numeric_value(raw,lang):
 """Locale-specific decimals; reject ambiguous grouping instead of guessing."""
 raw=''.join(str(unicodedata.digit(c)) if c.isdigit() else c for c in raw)
 raw=raw.replace('\u00a0','').replace('\u202f','').replace(' ','').replace('−','-')
 decimal=',' if lang.split('_')[0] in _DECIMAL_COMMA else '.';group='.' if decimal==',' else ','
 if group in raw:
  whole=raw.split(decimal)[0].lstrip('+-')
  if not re.fullmatch(r'\d{1,3}(?:'+re.escape(group)+r'\d{3})+',whole):
   raise ValueError('Ambiguous number formatting: '+raw+'. Check the selected subtitle language.')
  raw=raw.replace(group,'')
 if raw.count(decimal)>1:raise ValueError('Ambiguous number formatting: '+raw)
 raw=raw.replace(decimal,'.')
 try:return Decimal(raw)
 except InvalidOperation:raise ValueError('Number could not be read: '+raw)

def number_words(value,lang,kind='cardinal',**kw):
 from num2words import num2words
 lang={'pt_br':'pt_BR','en_in':'en_IN','en_ng':'en_NG'}.get(lang,lang)
 try:return num2words(value,lang=lang,to=kind,**kw)
 except NotImplementedError:
  raise ValueError('Spoken number alignment is unavailable for language '+lang+'. Use its spoken spelling for alignment; the previous subtitles are preserved.')

def money_words(value,lang,currency):
 # Libraries spell zero cents even when a whole price was spoken. Separate
 # the subunit explicitly instead of inferring silence for nonexistent words.
 marker=' ||SUBUNIT|| '
 try:text=number_words(value,lang,'currency',currency=currency,cents=True,separator=marker)
 except TypeError:return number_words(value,lang,'currency',currency=currency,cents=True)
 if value==value.to_integral_value() and marker in text:return text.split(marker)[0]
 return text.replace(marker,', ')

def numeric_notation(raw):
 value=str(raw).strip(' \t\n"“”«»‘’()[]{}!?;:').rstrip('.,')
 # Currency placement is typography, not a different pronunciation.
 if len(value)>1 and value[-1] in _CURRENCY and any(c.isdigit() for c in value[:-1]):
  value=value[-1]+value[:-1]
 return value

def spoken(raw,lang=None):
 """Select a pronunciation spelling, retaining the original separately at the caller."""
 lang=language(lang);base=lang.split('_')[0];value=numeric_notation(raw)
 # A final sentence stop/comma is not the decimal separator.
 value=value.rstrip('.,')
 if not any(c.isdigit() for c in value):return value
 if value.startswith(('%','٪')):
  if base!='tr':raise ValueError('Prefix percent pronunciation needs review: '+value)
  value=value[1:]+'%'
 match=re.fullmatch(r'(?P<currency>[$€£₺¥₹₽])?(?P<number>[+\-−]?\d+(?:[.,\u00a0\u202f]\d+)*)(?P<percent>[%٪])?',value)
 if match:
  n=numeric_value(match['number'],lang)
  if match['currency']:
   if match['percent']:raise ValueError('A numeric token combines currency and percent: '+value)
   return money_words(n,lang,_CURRENCY[match['currency']])
  text=number_words(n,lang)
  if match['percent']:
   if base not in _PERCENT:raise ValueError('Percent pronunciation needs review for language '+lang)
   text=(_PERCENT[base]+' '+text) if base=='tr' else (text+' '+_PERCENT[base])
  return text
 # Preserve lexical compounds, but measure their numeric component rather than
 # deleting it: B12, 50-year-old, 2–3 etc. Ambiguous dates/ratios are reviewed.
 if re.search(r'\d[:/]\d|\d+-\d+-\d+',value):raise ValueError('Date, clock or ratio pronunciation needs review: '+value)
 return re.sub(r'\d+(?:[.,]\d+)*',lambda m:' '+number_words(numeric_value(m[0],lang),lang)+' ',value)

@lru_cache(maxsize=4096)
def spelling(raw,lang=None):
 lang=language(lang);value=spoken(raw,lang).replace('’',"'")
 # Use the same Latin representation the multilingual acoustic model was trained
 # on; stripping a non-Latin alphabet would invent an empty timing interval.
 normalized=romanizer().romanize_string(value,lcode=_ISO3.get(lang.split('_')[0]))
 result=re.sub(r"[^a-z']",'',normalized.lower()).strip("'")
 if not result and any(c.isalnum() for c in str(raw)):
  raise ValueError('No acoustic spelling for token '+str(raw)+'. Previous subtitles were preserved.')
 return result

def alternatives(raw,lang=None):
 """Common numeric pronunciations; the acoustic scorer chooses, not display text."""
 lang=language(lang);out=[spelling(raw,lang)];variants=[spoken(raw,lang)];value=numeric_notation(raw)
 m=re.fullmatch(r'([$€£₺¥₹₽])([+\-−]?\d+(?:[.,]\d+)*)',value)
 if m:
  n=numeric_value(m[2],lang);a=int(n);cents=round(abs(n-Decimal(a))*100)
  variants.append(number_words(n,lang))
  if not cents:variants.append(number_words(a,lang))
  if cents:variants.append(number_words(a,lang)+' '+number_words(cents,lang))
 # Both British and American number conjunctions are common. The acoustic
 # scorer chooses the observed pronunciation; displayed spelling never changes.
 if lang.split('_')[0]=='en':variants += [v.replace(' and ',' ') for v in variants]
 for v in variants:
  p=spelling(v,lang)
  if p not in out:out.append(p)
 return out
