"""Alignment-only Unicode/number spellings. Displayed script tokens never change."""
from functools import lru_cache
from pathlib import Path
from decimal import Decimal,InvalidOperation
import os,re,sys,unicodedata

VERSION='spoken-forms-999'
VENDOR=Path(__file__).resolve().parent/'_vendor'
if str(VENDOR) not in sys.path:sys.path.insert(0,str(VENDOR))
_ISO3={'en':'eng','fr':'fra','de':'deu','es':'spa','it':'ita','tr':'tur','pt':'por','ru':'rus','uk':'ukr','ar':'ara','fa':'fas','he':'heb','hi':'hin','ja':'jpn','zh':'zho','ko':'kor','th':'tha','el':'ell','pl':'pol','nl':'nld'}
_PERCENT={'en':'percent','fr':'pour cent','de':'Prozent','es':'por ciento','it':'per cento','tr':'yüzde','pt':'por cento','ru':'процентов','uk':'відсотків','ar':'بالمئة','fa':'درصد','he':'אחוז','hi':'प्रतिशत','ja':'パーセント','ko':'퍼센트','nl':'procent','pl':'procent','el':'τοις εκατό'}
_CURRENCY={'$':'USD','€':'EUR','£':'GBP','₺':'TRY','¥':'JPY','₹':'INR','₽':'RUB'}
_DECIMAL_COMMA={'fr','de','es','it','tr','pt','ru','uk','pl','nl','el','sv','da','fi','nb','no','cs','sk','ro','hu','bg'}

_SYMBOLS=frozenset((*_CURRENCY,'%','٪'))
_NUMERIC=re.compile(r'(?P<currency>[$€£₺¥₹₽])?(?P<number>[+\-−]?\d+(?:[.,]\d+)*)(?P<suffix>[%٪$€£₺¥₹₽])?')

def _numeric_text(text):
 return str(text).strip(' \t\n"“”«»‘’()[]{}!?;:').rstrip('.,')

def _numeric_boundary(text):
 return str(text).rstrip().endswith(tuple('.,;:!?…،؛。！？؟"”’»)]}'))

def alignment_tokens(text):
 """Keep spoken symbols for contextual numeric units; omit only punctuation."""
 return [t for t in str(text).split() if any(c.isalnum() for c in t) or _numeric_text(t) in _SYMBOLS]

def contextual_units(tokens):
 """Atomic spoken expressions retaining all original printed token indices.

 A spaced amount/percentage/thousands group gets ONE acoustic measurement.
 Its printed members later share that interval; no per-symbol onset is guessed.
 """
 tokens=list(tokens);units=[];i=0
 while i<len(tokens):
  start=i;first=_numeric_text(tokens[i]);prefix=''
  if first in _SYMBOLS:
   if i+1>=len(tokens) or not _NUMERIC.fullmatch(_numeric_text(tokens[i+1])):
    raise ValueError('A detached numeric symbol has no adjacent measured number: '+tokens[i])
   prefix=first;i+=1;first=_numeric_text(tokens[i])
  match=_NUMERIC.fullmatch(first)
  if not match:
   units.append(dict(indices=[i],display=tokens[i],alignment_text=tokens[i],numeric=any(c.isdigit() for c in tokens[i])));i+=1;continue
  currency=match['currency'] or '';suffix=match['suffix'] or '';number=match['number'];i+=1
  if prefix:
   if currency or suffix:raise ValueError('Ambiguous repeated currency/percent symbols: '+' '.join(tokens[start:i]))
   if prefix in ('%','٪'):suffix=prefix
   else:currency=prefix
  # The first 1–3 digits may be followed by whole groups of three. Decimal
  # separators remain language-specific and are checked by numeric_value.
  if re.fullmatch(r'[+\-−]?\d{1,3}',number) and not suffix and not _numeric_boundary(tokens[i-1]):
   while i<len(tokens):
    group=_NUMERIC.fullmatch(_numeric_text(tokens[i]))
    if not group or group['currency'] or not re.fullmatch(r'\d{3}(?:[.,]\d+)?',group['number']):break
    number+=group['number'];suffix=group['suffix'] or '';i+=1
    if suffix or re.search(r'[.,]',group['number']) or _numeric_boundary(tokens[i-1]):break
  if i<len(tokens) and not _numeric_boundary(tokens[i-1]) and _numeric_text(tokens[i]) in _SYMBOLS:
   if suffix:raise ValueError('Ambiguous repeated numeric symbols: '+' '.join(tokens[start:i+1]))
   suffix=_numeric_text(tokens[i]);i+=1
  if suffix in _CURRENCY:
   if currency:raise ValueError('A number has currency symbols on both sides: '+' '.join(tokens[start:i]))
   currency=suffix;suffix=''
  if currency and suffix:raise ValueError('A number combines currency and percent: '+' '.join(tokens[start:i]))
  canonical=(prefix+number) if prefix in ('%','٪') else currency+number+suffix
  units.append(dict(indices=list(range(start,i)),display=' '.join(tokens[start:i]),alignment_text=canonical,numeric=True))
 return units

def validate_expressions(text):
 if re.search(r'\d\s+[:/.,]\s*\d|(?<!\w)[+−-]\s+\d',str(text)):
  raise ValueError('A numeric sign, decimal separator, date or ratio is separated into ambiguous tokens. Check its written form before alignment; previous subtitles were preserved.')
 contextual_units(alignment_tokens(text))

def language(lang=None):
 return str(lang or os.environ.get('VSL_LANG') or 'en').strip().replace('-','_').lower()

@lru_cache(maxsize=1)
def romanizer():
 from uroman import Uroman
 return Uroman(data_dir=VENDOR/'uroman'/'linguistic')

def numeric_value(raw,lang):
 """Locale-specific decimals; reject ambiguous grouping instead of guessing."""
 raw=''.join(str(unicodedata.digit(c)) if c.isdigit() else c for c in raw)
 raw=raw.replace('\u00a0','').replace('\u202f','').replace(' ','').replace('−','-')
 decimal=',' if lang.split('_')[0] in _DECIMAL_COMMA else '.';group='.' if decimal==',' else ','
 if group in raw:
  whole=raw.split(decimal)[0].lstrip('+-')
  if not re.fullmatch(r'\d{1,3}(?:'+re.escape(group)+r'\d{3})+',whole):
   raise ValueError('Ambiguous number formatting: '+raw+'. Check the selected subtitle language.')
  raw=raw.replace(group,'')
 if raw.count(decimal)>1:raise ValueError('Ambiguous number formatting: '+raw)
 raw=raw.replace(decimal,'.')
 try:return Decimal(raw)
 except InvalidOperation:raise ValueError('Number could not be read: '+raw)

def number_words(value,lang,kind='cardinal',**kw):
 from num2words import num2words
 lang={'pt_br':'pt_BR','en_in':'en_IN','en_ng':'en_NG'}.get(lang,lang)
 try:return num2words(value,lang=lang,to=kind,**kw)
 except NotImplementedError:
  raise ValueError('Spoken number alignment is unavailable for language '+lang+'. Use its spoken spelling for alignment; the previous subtitles are preserved.')

def money_words(value,lang,currency):
 # Libraries spell zero cents even when a whole price was spoken. Separate
 # the subunit explicitly instead of inferring silence for nonexistent words.
 marker=' ||SUBUNIT|| '
 try:text=number_words(value,lang,'currency',currency=currency,cents=True,separator=marker)
 except TypeError:return number_words(value,lang,'currency',currency=currency,cents=True)
 if value==value.to_integral_value() and marker in text:return text.split(marker)[0]
 return text.replace(marker,', ')

def numeric_notation(raw):
 value=str(raw).strip(' \t\n"“”«»‘’()[]{}!?;:').rstrip('.,')
 # Currency placement is typography, not a different pronunciation.
 if len(value)>1 and value[-1] in _CURRENCY and any(c.isdigit() for c in value[:-1]):
  value=value[-1]+value[:-1]
 return value

def spoken(raw,lang=None):
 """Select a pronunciation spelling, retaining the original separately at the caller."""
 lang=language(lang);base=lang.split('_')[0];value=numeric_notation(raw)
 # A final sentence stop/comma is not the decimal separator.
 value=value.rstrip('.,')
 if not any(c.isdigit() for c in value):return value
 if value.startswith(('%','٪')):
  if base!='tr':raise ValueError('Prefix percent pronunciation needs review: '+value)
  value=value[1:]+'%'
 match=re.fullmatch(r'(?P<currency>[$€£₺¥₹₽])?(?P<number>[+\-−]?\d+(?:[.,\u00a0\u202f]\d+)*)(?P<percent>[%٪])?',value)
 if match:
  n=numeric_value(match['number'],lang)
  if match['currency']:
   if match['percent']:raise ValueError('A numeric token combines currency and percent: '+value)
   return money_words(n,lang,_CURRENCY[match['currency']])
  text=number_words(n,lang)
  if match['percent']:
   if base not in _PERCENT:raise ValueError('Percent pronunciation needs review for language '+lang)
   text=(_PERCENT[base]+' '+text) if base=='tr' else (text+' '+_PERCENT[base])
  return text
 # Preserve lexical compounds, but measure their numeric component rather than
 # deleting it: B12, 50-year-old, 2–3 etc. Ambiguous dates/ratios are reviewed.
 if re.search(r'\d[:/]\d|\d+-\d+-\d+',value):raise ValueError('Date, clock or ratio pronunciation needs review: '+value)
 return re.sub(r'\d+(?:[.,]\d+)*',lambda m:' '+number_words(numeric_value(m[0],lang),lang)+' ',value)

@lru_cache(maxsize=4096)
def spelling(raw,lang=None):
 lang=language(lang);value=spoken(raw,lang).replace('’',"'")
 # Use the same Latin representation the multilingual acoustic model was trained
 # on; stripping a non-Latin alphabet would invent an empty timing interval.
 normalized=romanizer().romanize_string(value,lcode=_ISO3.get(lang.split('_')[0]))
 result=re.sub(r"[^a-z']",'',normalized.lower()).strip("'")
 if not result and any(c.isalnum() for c in str(raw)):
  raise ValueError('No acoustic spelling for token '+str(raw)+'. Previous subtitles were preserved.')
 return result

def alternatives(raw,lang=None):
 """Common numeric pronunciations; the acoustic scorer chooses, not display text."""
 lang=language(lang);out=[spelling(raw,lang)];variants=[spoken(raw,lang)];value=numeric_notation(raw)
 m=re.fullmatch(r'([$€£₺¥₹₽])([+\-−]?\d+(?:[.,]\d+)*)',value)
 if m:
  n=numeric_value(m[2],lang);a=int(n);cents=round(abs(n-Decimal(a))*100)
  variants.append(number_words(n,lang))
  if not cents:variants.append(number_words(a,lang))
  if cents:
   variants.append(number_words(a,lang)+' '+number_words(cents,lang))
   # Common spoken prices omit the word "cents/centimes" but retain euros.
   variants.append(money_words(Decimal(a),lang,_CURRENCY[m[1]])+' '+number_words(cents,lang))
 # Both British and American number conjunctions are common. The acoustic
 # scorer chooses the observed pronunciation; displayed spelling never changes.
 if lang.split('_')[0]=='en':variants += [v.replace(' and ',' ') for v in variants]
 for v in variants:
  p=spelling(v,lang)
  if p not in out:out.append(p)
 return out
