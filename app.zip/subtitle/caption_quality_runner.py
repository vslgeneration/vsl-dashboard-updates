"""Cancelable application entry point for final candidate subtitle checks."""
import hashlib,json,sys,os
from pathlib import Path
import caption_quality
import phrase_store


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def binding(folder,audio,script,lang,bounds):
    folder=Path(folder)
    return dict(audio_sha256=digest(audio) if audio else None,script_sha256=hashlib.sha256(script.encode()).hexdigest(),
                plan_sha256=digest(folder/'phrase-plan.json'),
                words=[[p.name,digest(p)] for p in sorted(folder.glob('words_*.tsv'))],
                srt=[[p.name,digest(p)] for p in sorted(folder.glob('*.srt'))],
                lang=lang,scene_bounds=bounds)


def srt_matches(folder,plan,filename='subtitles.srt'):
    if not isinstance(filename,str) or Path(filename).name!=filename:return False
    try:
        actual=(Path(folder)/filename).read_text('utf-8-sig').replace('\r\n','\n').strip()
        return actual==phrase_store.serialize_srt(plan).strip()
    except OSError:return False


def run(request):
    folder=Path(request['folder']);audio=request.get('audio');script=request['script_text'];lang=request.get('lang','en')
    bounds=request.get('scene_bounds') or []
    before=binding(folder,audio,script,lang,bounds)
    plan=json.loads((folder/'phrase-plan.json').read_text('utf8'))
    wordfile=phrase_store._pick_wordfile(folder,plan,None)
    raw=phrase_store.load_words(wordfile);phrase_store.canonical_rows(plan,raw)
    print('[quality] Checking Subtitles',flush=True)
    if not srt_matches(folder,plan,request.get('srt') or 'subtitles.srt'):
        caption_quality.persist_report(folder,dict(schema=1,policy=caption_quality.POLICY,status='review',passed=False,mode='full',
            issues=[dict(code='srt_plan_mismatch',severity='review',start=0,end=0,message='The SRT does not match the verified phrase plan. Generate again from the current script.')],checks=[],repairs=[]))
        return 3
    prior=None
    try:prior=json.loads((folder/'caption-quality.json').read_text('utf8'))
    except (OSError,ValueError):pass
    semantic_prior=(prior or {}).get('semantic_review') or {}
    semantic_current=(semantic_prior.get('status')=='pass' and semantic_prior.get('provider')==os.environ.get('VSL_SEMANTIC_PROVIDER')) if os.environ.get('VSL_SEMANTIC_MAILBOX') else True
    if prior and prior.get('status')=='pass' and prior.get('passed') is True and semantic_current and caption_quality.report_matches(prior,audio,script,raw,plan,lang):
        structure=caption_quality.audit_structure(script,raw,plan,lang,scene_bounds=bounds)
        report=prior if structure.get('passed') is True else structure
    else:
        report=caption_quality.audit_candidate(audio,script,raw,plan,lang,folder,
            cache_dir=request.get('cache_dir'),scene_bounds=bounds)
    if before!=binding(folder,audio,script,lang,bounds):
        report=dict(report,status='review',passed=False,issues=[*report.get('issues',[]),
            dict(code='candidate_changed',severity='error',start=0,end=0,text='',heard='',message='The recording or subtitle candidate changed during checking. Retry from the current inputs.',evidence={})])
    candidate=report.pop('candidate_plan',None)
    if report.get('status')=='review' and before==binding(folder,audio,script,lang,bounds):
        caption_quality.write_review_draft(folder,script,raw,candidate or plan,lang,bounds)
    if candidate is not None and report.get('status')=='pass' and report.get('passed') is True:
        phrase_store.canonical_rows(candidate,raw)
        checked=caption_quality.audit_structure(script,raw,candidate,lang,scene_bounds=bounds)
        if checked.get('passed') is not True:
            report=checked
        else:
            filename=request.get('srt') or 'subtitles.srt'
            if Path(filename).name!=filename:raise ValueError('Invalid candidate subtitle filename')
            (folder/'phrase-plan.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2),'utf8')
            (folder/filename).write_text(phrase_store.serialize_srt(candidate),'utf8')
            report['fingerprints']=caption_quality.fingerprints(audio,script,raw,candidate,lang)
            before=binding(folder,audio,script,lang,bounds)
    report['mode']='full';report['app_binding']=before
    caption_quality.persist_report(folder,report)
    return 0 if report.get('status')=='pass' and report.get('passed') is True else 3


if __name__=='__main__':
    request=json.loads(Path(sys.argv[1]).read_text('utf8'))
    try:code=run(request)
    except Exception as error:
        report=dict(schema=1,policy='caption-quality-v1000',status='review',passed=False,mode='full',
            issues=[dict(code='quality_unavailable',severity='error',start=0,end=0,text='',heard='',
                message='The subtitle check could not finish. Retry checking the recording.',evidence=dict(error_type=type(error).__name__))],checks=[],recognition={},repairs=[])
        caption_quality.persist_report(request['folder'],report)
        code=3
    raise SystemExit(code)
