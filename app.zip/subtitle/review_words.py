"""Keep measured words bound to a reviewed take and its unchanged script.

The immutable sidecar is selected by caption-review.json through shared delivery.
It cannot move scene cuts or silently replace a previously completed subtitle set.
"""
import hashlib
import json
import math
import re
from pathlib import Path
from . import phrase_store


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def script_sha(script):
    return hashlib.sha256(script.strip().encode('utf8')).hexdigest()


def capture(work, script, audio, report):
    work = Path(work)
    candidate = work/'review-phrase-plan.json'
    plan = json.loads((candidate if candidate.is_file() else work/'phrase-plan.json').read_text('utf8'))
    source = phrase_store._pick_wordfile(work, plan, None)
    if source.parent.resolve() != work.resolve():
        raise ValueError('Measured words must belong to this generation.')
    raw = phrase_store.load_words(source)
    rows = phrase_store.canonical_rows(plan, raw)
    if [t for t, a, b in rows] != script.split():
        raise ValueError('Measured words do not match the unchanged script.')
    if any(not all(math.isfinite(v) for v in (a,b)) or a < 0 or b < a for _,a,b in rows):
        raise ValueError('Invalid measured word timestamps.')
    if any(a[1] > b[1] for a,b in zip(rows,rows[1:])):
        raise ValueError('Measured words are not ordered.')
    audio_hash = sha(audio)
    binding = report.get('app_binding') or {}
    if binding.get('audio_sha256') and binding['audio_sha256'] != audio_hash:
        raise ValueError('The recording changed after checking.')
    # Preserve the underlying measurements as well as the exact printed tokens.
    return dict(schema=1,script_sha256=script_sha(script),audio_sha256=audio_hash,
                source_words=raw,plan=plan,issues=report.get('issues') or [])


def load(folder, record, script, srt, audio=None):
    """Return a matching review take only; stale/foreign/tampered takes are ignored."""
    try:
        folder = Path(folder)
        name = record.get('word_timing_file') or ''
        if not name:
            # Older versions discarded the words. A separately recovered snapshot
            # may attach to that exact review without rewriting a live project.
            recovered=json.loads((folder/'recovered-review-words.json').read_text('utf8'))
            if recovered.get('review_sha256') != sha(folder/'caption-review.json'): return None
            record=dict(record,word_timing_file=recovered.get('word_timing_file'),
                        word_timing_sha256=recovered.get('word_timing_sha256'))
            name=record.get('word_timing_file') or ''
        if not re.fullmatch(r'review-[0-9a-f]{32}\.words\.json',name): return None
        if record.get('script_sha256') != script_sha(script): return None
        # Review timings are valid only on the SRT currently used by the project.
        # A completed active set therefore cannot inherit another take's timings.
        if Path(srt).resolve() != (folder/str(record.get('file') or '')).resolve(): return None
        if sha(srt) != record.get('file_sha256'): return None
        path = folder/name
        if sha(path) != record.get('word_timing_sha256'): return None
        data = json.loads(path.read_text('utf8'))
        if data.get('schema') != 1 or data.get('script_sha256') != record['script_sha256']: return None
        if audio and sha(audio) != data.get('audio_sha256'): return None
        rows = phrase_store.canonical_rows(data['plan'],data['source_words'])
        if [t for t,a,b in rows] != script.split(): return None
        return dict(words=[(a,b,t) for t,a,b in rows],issues=data.get('issues') or [],
                    scene_clock=data.get('scene_clock'),legacy_clock='scene_clock' not in data,plan=data['plan'])
    except (OSError,ValueError,TypeError,KeyError):
        return None


def issues_for_span(issues, start, end):
    out=[]
    for item in issues:
        if item.get('severity') not in ('warning','review','error'): continue
        a,b=item.get('start'),item.get('end')
        if not isinstance(a,(int,float)) or not isinstance(b,(int,float)) or b <= a:
            # A check that failed globally cannot attest to any local onset.
            if item.get('severity') == 'error': out.append(item)
        elif a < end+.001 and b > start-.001:
            out.append(item)
    return out
