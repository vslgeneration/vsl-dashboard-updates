"""Measure imported source turns independently; never invent a replacement clock."""
import json
import math
import wave
from pathlib import Path


def validate_plan(plan, text):
    from text_boundaries import normalize_spacing
    rows = plan.get('windows', [])
    if not rows or normalize_spacing(' '.join(r['text'] for r in rows)) != normalize_spacing(text):
        raise ValueError('The subtitle timing map does not match the script.')
    previous = 0.
    for r in rows:
        a, b = r['start'], r['end']
        if not all(math.isfinite(v) for v in (a,b)) or a < previous-.001 or not 0 <= a < b:
            raise ValueError('Invalid subtitle source window.')
        previous = b
    return rows


def check_rows(rows, duration):
    """Reject missing/collapsed measurements instead of spreading them evenly."""
    previous = -1.
    cramped = 0
    for token, a, b in rows:
        if not all(math.isfinite(v) for v in (a,b)) or not 0 <= a < b <= duration+.04 or a < previous:
            raise ValueError('Word timing could not be measured reliably; previous subtitles were kept.')
        cramped = cramped+1 if b-a <= .025 else 0
        if cramped >= 4:
            raise ValueError('Several words have collapsed timing; previous subtitles were kept.')
        previous = a


def acoustic_issue(samples, sr, rows, diagnostics):
    """Flag sustained unaccounted sound or runs of weak acoustic matches for review.

    This is an alignment-quality gate, not a claim to recognize every wrong word.
    Breaths and short pauses are permitted. Digit-only tokens retain their spans.
    """
    import numpy as np
    step = max(1, round(sr*.02))
    blocks = len(samples)//step
    if not blocks: return 'Empty recording'
    env = np.sqrt(np.mean(samples[:blocks*step].reshape(blocks,step)**2,axis=1))
    threshold = max(.008, float(np.percentile(env,10))*4)
    gaps = []
    end = 0.
    for _, a, b in rows:
        if a-end >= 1.8: gaps.append((end,a))
        end = max(end,b)
    if len(samples)/sr-end >= 1.8: gaps.append((end,len(samples)/sr))
    for a,b in gaps:
        energy = env[round((a+.15)/.02):round((b-.15)/.02)]
        if len(energy) and np.count_nonzero(energy > threshold)*.02 > 1.1:
            return 'Speech or sound has no matching script words at %.2f–%.2fs' % (a,b)
    weak = 0
    for row in diagnostics.get('scores', []):
        weak = weak+1 if row['score'] < .10 and len(row['token']) > 2 else 0
        if weak >= 5: return 'Several consecutive words do not match the recorded sound'
    return None


def align(audio, text, plan, work, log=print, diagnostics=None, allow_numeric_review=False):
    import numpy as np
    import _mms_align
    from text_boundaries import normalize_spacing
    windows = validate_plan(plan,text)
    wav, temporary = _mms_align._wav16(str(audio))
    all_rows, reports = [], []
    evidence=diagnostics if diagnostics is not None else {}
    evidence.update(method='mms-fa-bounded',scores=[],raw_words=[],numeric_groups=[],windows=[])
    import shutil
    try:
        with wave.open(wav,'rb') as f:
            sr=f.getframerate(); raw=f.readframes(f.getnframes())
        duration=len(raw)/(2*sr)
        for index, window in enumerate(windows):
            a,b=window['start'],window['end']
            if b>duration+.10: raise ValueError('Subtitle source window exceeds the recording.')
            chunk=raw[round(a*sr)*2:min(len(raw),round(b*sr)*2)]
            clip=Path(temporary)/'window.wav'
            with wave.open(str(clip),'wb') as f:
                f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes(chunk)
            measured={}
            try:
                rows=_mms_align.align(str(clip),window['text'],log=lambda *_:None,diagnostics=measured,allow_numeric_review=allow_numeric_review and diagnostics is not None)
            except (ValueError,RuntimeError) as exc:
                weak=measured.get('weak_numeric',[])
                evidence['windows'].append(dict(window=index+1,start=a,end=b,segment=window.get('segment',''),diagnostics=measured))
                if not weak:raise
                located=[dict(issue,source_start=round(a+float(issue.get('start') or 0),3),
                              source_end=round(a+float(issue.get('end') or 0),3),
                              source_offset=a) for issue in weak]
                evidence['weak_numeric']=located
                reports.append(dict(window=index+1,start=a,end=b,segment=window.get('segment',''),
                                    issue=str(exc),weak_numeric=located))
                (Path(work)/'alignment-quality.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),'utf8')
                first=located[0];at=first['source_start'];label='%02d:%06.3f' % (int(at)//60,at%60)
                raise ValueError('The numeric expression '+str(first['token'])+' could not be measured reliably near '+label+
                    ' in source window '+str(index+1)+' ('+str(window.get('segment') or 'source')+
                    '). Review that recording segment; previous subtitles were preserved.') from exc
            if measured.get('weak_numeric'):
                evidence.setdefault('weak_numeric',[]).extend(dict(row,
                    source_start=round(a+float(row['start']),3),source_end=round(a+float(row['end']),3),
                    source_indices=[i+len(all_rows) for i in row.get('source_indices',[])],
                    source_offset=a,window=index+1) for row in measured['weak_numeric'])
            check_rows(rows,len(chunk)/(2*sr))
            samples=np.frombuffer(chunk,dtype='<i2').astype(np.float32)/32768
            issue=acoustic_issue(samples,sr,rows,measured)
            evidence['windows'].append(dict(window=index+1,start=a,end=b,segment=window.get('segment',''),diagnostics=measured))
            evidence['scores'].extend(dict(row,source_offset=a,window=index+1) for row in measured.get('scores',[]))
            evidence['raw_words'].extend([t,round(float(s)+a,3),round(float(e)+a,3)] for t,s,e in measured.get('raw_words',[]))
            evidence['numeric_groups'].extend(dict(row,start=round(float(row['start'])+a,3),end=round(float(row['end'])+a,3),source_indices=[i+len(all_rows) for i in row.get('source_indices',[])],source_offset=a,window=index+1) for row in measured.get('numeric_groups',[]))
            report=dict(window=index+1,start=a,end=b,segment=window.get('segment',''),issue=issue)
            reports.append(report)
            (Path(work)/'alignment-quality.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),'utf8')
            if issue:
                label='%02d:%02d' % (int(a)//60,int(a)%60)
                raise ValueError('Check recording/script near '+label+' ('+str(window.get('segment','source'))+'): '+issue+'. Previous subtitles were kept.')
            from speech_forms import alignment_tokens
            expected=alignment_tokens(normalize_spacing(window['text']))
            if [r[0] for r in rows]!=expected: raise ValueError('Alignment changed the source text.')
            all_rows.extend((t,round(s+a,3),round(min(e+a,b),3)) for t,s,e in rows)
            log('[bounded] %d/%d source windows measured' % (index+1,len(windows)))
        check_rows(all_rows,duration)
        return all_rows
    finally:
        shutil.rmtree(temporary,ignore_errors=True)
