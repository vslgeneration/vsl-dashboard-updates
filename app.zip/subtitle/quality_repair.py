"""Bounded acoustic verification; recognition timestamps never become word times."""
from pathlib import Path
import copy,difflib,hashlib,json,math,os,subprocess,tempfile,threading,unicodedata
try:
 from . import phrase_store as store,acoustic_phrasing as phrasing
 from .text_boundaries import protected_boundaries
except ImportError:
 import phrase_store as store,acoustic_phrasing as phrasing
 from text_boundaries import protected_boundaries

_LOCK=threading.Lock()
_REGROUP={'cue_onset_mismatch','unquantized_cue','caption_hold_gap','broken_semantic_unit','broken_line_unit','too_many_lines','brief_caption','long_caption'}
_STRONG=.85

def _frame(t):return int(float(t)*60+.5+1e-9)

def _fresh_plan(audio,rows,canonical,lang,overrides):
 corrected=store.apply_measurement_overrides(rows,overrides)
 printed=store.timed_tokens([t['text'] for t in canonical['tokens']],corrected)
 rebuilt=phrasing.plan(printed,phrasing.detect_pauses(audio),lang,forced_boundaries=canonical.get('forced_boundaries',[]),fps=canonical.get('fps',60))
 store.bind_source(rebuilt,rows,canonical.get('source',{}).get('filename'),overrides)
 return rebuilt

def _measure(audio,tokens,a,b,workdir,lang,align):
 start=max(0.,tokens[a][1]-.2);end=max(t[2] for t in tokens[a:b])+.2
 if not 0<end-start<=15:raise ValueError('Local verification window is too long or empty.')
 with tempfile.TemporaryDirectory(prefix='caption-local-',dir=workdir) as temporary:
  clip=Path(temporary)/'audio.wav'
  subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-ss',str(start),'-i',str(audio),'-t',str(end-start),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(clip)],check=True,capture_output=True,timeout=60,creationflags=0x08000000 if os.name=='nt' else 0)
  proof=dict(method='local-mms-verification-v1000',clip_sha256=hashlib.sha256(clip.read_bytes()).hexdigest(),source_offset=start,diagnostics={})
  text=' '.join(t[0] for t in tokens[a:b]);measured=[]
  with _LOCK:
   prior=os.environ.get('VSL_LANG');os.environ['VSL_LANG']=lang
   try:
    if align is None:
     try:from ._mms_align import align as measure
     except ImportError:from _mms_align import align as measure
    else:measure=align
    local=measure(str(clip),text,log=lambda *_:None,diagnostics=proof['diagnostics'])
   finally:
    if prior is None:os.environ.pop('VSL_LANG',None)
    else:os.environ['VSL_LANG']=prior
  timed=store.timed_tokens([t[0] for t in tokens[a:b]],local)
  scores=proof['diagnostics'].get('scores',[])
  if len(scores)!=len(local):raise ValueError('Local acoustic scores are incomplete.')
  cursor=0
  for index,(text,lo,hi) in enumerate(timed,a):
   score=None
   if cursor<len(local) and local[cursor][0]==text:
    entry=scores[cursor];score=entry.get('score') if isinstance(entry,dict) else entry;cursor+=1
   measured.append(dict(index=index,text=text,start=round(start+lo,3),end=round(start+hi,3),score=score))
  if cursor!=len(local):raise ValueError('Local verification changed printed tokens.')
  proof['diagnostics']['absolute_words']=copy.deepcopy(measured)
  return {w['index']:w for w in measured},proof

def _local_recognition(audio,tokens,targets,issue,workdir,lang):
 """Independent bounded recheck, cached by exact extracted audio; no script prompt."""
 try:from . import recognition_cache as recognition
 except ImportError:import recognition_cache as recognition
 anchor=min(range(len(tokens)),key=lambda i:abs(tokens[i][1]-float(issue.get('start',0))))
 selected=sorted(targets or [anchor]);a=max(0,min(selected)-5);b=min(len(tokens),max(selected)+6)
 start=max(0.,tokens[a][1]-.4);end=max(t[2] for t in tokens[a:b])+.4
 if not 0<end-start<=15:raise ValueError('Independent local review window exceeds its bounded limit.')
 directory=Path(workdir)/'quality-local';directory.mkdir(parents=True,exist_ok=True);cache=directory/'recognition-cache'
 with tempfile.TemporaryDirectory(prefix='listen-',dir=directory) as temporary:
  clip=Path(temporary)/'audio.wav'
  subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-ss',str(start),'-i',str(audio),'-t',str(end-start),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(clip)],check=True,capture_output=True,timeout=60,creationflags=0x08000000 if os.name=='nt' else 0)
  cached=recognition.cached_recognition(clip,lang,cache)
  if cached:record=cached
  else:
   model_dir=Path(os.environ.get('VSL_WHISPER_CACHE') or Path.home()/'.cache/whisper')
   name='medium' if (model_dir/'medium.pt').is_file() else 'small';model_path=model_dir/(name+'.pt')
   if not model_path.is_file():raise ValueError('Local subtitle verification model is unavailable.')
   import torch,whisper
   torch.set_num_threads(2)
   try:torch.set_num_interop_threads(1)
   except RuntimeError:pass
   options=dict(initial_prompt=None,condition_on_previous_text=False,word_timestamps=True,temperature=0,fp16=False)
   with _LOCK:
    model=whisper.load_model(str(model_path),device='cpu')
    try:observed=model.transcribe(str(clip),language=recognition.normalized_lang(lang) or None,verbose=None,**options)
    finally:del model
   record=recognition.persist_recognition(clip,lang,name,'whisper',options,observed,cache)
  return record,dict(method='independent-local-recognition-v1000',clip_sha256=recognition.digest(clip),source_offset=start,source_end=end,context_indices=[a,b],anchor=anchor)

def _local_match(tokens,targets,issue,record,proof):
 """Exact contextual agreement, never fuzzy spelling or a replacement clock."""
 try:
  from .caption_quality import _recognized_words,_norm
  from . import recognition_cache as recognition
 except ImportError:
  from caption_quality import _recognized_words,_norm
  import recognition_cache as recognition
 if record.get('policy')!=recognition.POLICY or record.get('audio_sha256')!=proof['clip_sha256'] or not recognition._independent(record.get('options')):return None
 heard=_recognized_words(record);anchor=proof['anchor'];selected=sorted(targets or [anchor])
 a=max(0,min(selected)-2);b=min(len(tokens),max(selected)+3)
 if b-a<3:return None
 expected=''.join(_norm(t[0]) for t in tokens[a:b]);observed=''.join(_norm(w['text']) for w in heard)
 if not expected or observed.count(expected)!=1:return None
 origin=observed.index(expected);owners=[]
 for i,w in enumerate(heard):owners.extend([i]*len(_norm(w['text'])))
 matched={};cursor=origin
 for i in range(a,b):
  size=len(_norm(tokens[i][0]));matched[i]=sorted(set(owners[cursor:cursor+size]));cursor+=size
 # A missing/extra word must be corroborated by the surrounding spoken phrase,
 # not by an isolated name or a recognizer's low-confidence spelling choice.
 required=selected if targets else list(range(a,b))
 for i in required:
  indexes=matched.get(i,[])
  if not indexes:return None
  if any(type(heard[j]['score']) not in (int,float) or not math.isfinite(heard[j]['score']) or heard[j]['score']<.60 for j in indexes):return None
  lo=min(heard[j]['start'] for j in indexes)+proof['source_offset'];hi=max(heard[j]['end'] for j in indexes)+proof['source_offset']
  if lo>tokens[i][2]+.15 or hi<tokens[i][1]-.15:return None
 context_scores=[heard[j]['score'] for i in range(a,b) for j in matched[i] if type(heard[j]['score']) in (int,float)]
 if not context_scores or sum(context_scores)/len(context_scores)<.85:return None
 return dict(**proof,model=record.get('model'),backend=record.get('backend'),options=record.get('options'),
             exact_context=' '.join(t[0] for t in tokens[a:b]),recognized_text=' '.join(w['text'] for w in heard),
             recognized_words=[dict(w,start=w['start']+proof['source_offset'],end=w['end']+proof['source_offset']) for w in heard],timing_changed=False)

def _corroborate_local(audio,tokens,lang,result,workdir,align=None):
 """Resolve uncertain full-recording ASR only with independent local evidence."""
 try:from . import recognition_cache as recognition
 except ImportError:import recognition_cache as recognition
 full=result.get('recognition') or {}
 if full.get('policy')!=recognition.POLICY or not recognition._independent(full.get('options')) or full.get('audio_sha256')!=recognition.digest(audio):return
 pending=[i for i in result.get('issues',[]) if i.get('severity')=='review' and i.get('code') in ('transcript_disagreement','recognition_timing_disagreement')]
 for issue in pending[:12]:
  if issue.get('evidence',{}).get('local_verification_not_attempted'):continue
  targets=set(issue.get('evidence',{}).get('script_token_indices') or [])
  if any(type(i) is not int or not 0<=i<len(tokens) for i in targets):continue
  # Numerical uncertainties have their dedicated atomic acoustic verification;
  # an ASR transcript cannot make weak number timing authoritative.
  if any(any(c.isdigit() for c in tokens[i][0]) for i in targets):continue
  try:
   print('[quality] Listening to a bounded review span independently',flush=True)
   record,proof=_local_recognition(audio,tokens,targets,issue,workdir,lang)
   match=_local_match(tokens,targets,issue,record,proof)
   if not match:
    issue.setdefault('evidence',{})['independent_local_review']=dict(**proof,model=record.get('model'),recognized_text=record.get('result',{}).get('text') or ' '.join(s.get('text','') for s in record.get('result',{}).get('segments',[])),resolved=False)
    continue
   selected=targets or {proof['anchor']}
   attempts=issue.get('evidence',{}).get('local_verification_attempts',[])
   measurements=[a.get('proof') for a in attempts if a.get('proof')]
   if not targets:
    measurements=[]
    for context in (1,2):
     a=max(0,min(selected)-context);b=min(len(tokens),max(selected)+context+1)
     _,measured=_measure(audio,tokens,a,b,workdir,lang,align);measurements.append(measured)
   if len(measurements)!=2 or (measurements[0]['clip_sha256'],measurements[0]['source_offset'])==(measurements[1]['clip_sha256'],measurements[1]['source_offset']):continue
   stable=True
   for measured in measurements:
    words={w['index']:w for w in measured['diagnostics'].get('absolute_words',[])}
    for i in selected:
     w=words.get(i)
     if not w or type(w.get('score')) not in (int,float) or not math.isfinite(w['score']) or w['score']<=0 or abs(w['start']-tokens[i][1])>1/60+.001 or w['end']<=w['start'] or w['end']<tokens[i][1] or w['start']>tokens[i][2]:stable=False
   if not stable:continue
   match['local_clock_contexts']=measurements
   issue.update(severity='warning',resolution='verified_by_independent_local_recognition')
   issue.setdefault('evidence',{})['independent_local_verification']=match
   result.setdefault('repairs',[]).append(dict(kind='independent_local_verification',script_token_indices=sorted(targets),timing_changed=False,evidence=match))
  except (ValueError,RuntimeError,OSError,subprocess.SubprocessError) as error:
   issue.setdefault('evidence',{})['independent_local_error']=str(error)

def refine_candidate(audio,script_text,rows,canonical,lang,report,workdir,scene_bounds=None,acoustic=None,align=None):
 """Return a verified plan/report pair, leaving inputs and raw TSV untouched.

 A correction needs two separately contextualized MMS measurements. Existing
 scene frames are checked before accepting it; app publication separately guards
 authored caption edits. Uncertain spans remain actionable review items.
 """
 try:from .caption_quality import audit_structure,_validated_acoustic,_scores
 except ImportError:from caption_quality import audit_structure,_validated_acoustic,_scores
 result=copy.deepcopy(report);candidate=copy.deepcopy(canonical);repairs=result.setdefault('repairs',[])
 tokens=store.canonical_rows(canonical,rows);workdir=Path(workdir);workdir.mkdir(parents=True,exist_ok=True)
 if [t[0] for t in tokens]!=str(script_text).split():return candidate,result
 try:full_scores=_scores(_validated_acoustic(acoustic,audio,script_text,rows,lang),tokens)
 except (ValueError,TypeError,OSError):full_scores={}
 reviews=[i for i in result.get('issues',[]) if i.get('severity')=='review']
 structural=[i for i in reviews if i.get('code') in _REGROUP]
 if structural:
  try:
   rebuilt=_fresh_plan(audio,rows,candidate,lang,candidate.get('measurement_overrides',[]))
   validation=audit_structure(script_text,rows,rebuilt,lang,scene_bounds)
   if validation['passed']:
    for issue in structural:issue.update(severity='warning',resolution='regrouped_from_unchanged_measured_words')
    repairs.append(dict(kind='semantic_regroup',source_rows_changed=False,before_groups=len(candidate['groups']),after_groups=len(rebuilt['groups'])))
    candidate=rebuilt
  except (ValueError,RuntimeError,OSError,subprocess.SubprocessError):pass
 windows=[];entries=[]
 for issue in reviews:
  if issue.get('code') not in ('transcript_disagreement','recognition_timing_disagreement') or issue.get('severity')!='review':continue
  targets=issue.get('evidence',{}).get('script_token_indices',[])
  if not targets or any(type(i) is not int or not 0<=i<len(tokens) for i in targets):continue
  targets=set(targets)
  for unit in canonical.get('numeric_units',[]):
   members=set(range(unit['a'],unit['b']))
   if targets & members:targets.update(members)
  entries.append((min(targets),max(targets)+1,targets,issue))
 for a,b,targets,issue in sorted(entries,key=lambda entry:entry[:2]):
  if windows and a<=windows[-1]['b']+2:
   windows[-1]['b']=max(windows[-1]['b'],b);windows[-1]['issues'].append(issue);windows[-1]['targets'].update(targets)
  else:windows.append(dict(a=a,b=b,issues=[issue],targets=set(targets)))
 protected=protected_boundaries([t[0] for t in tokens])
 for ordinal,window in enumerate(windows):
  if ordinal>=12:
   for issue in window['issues']:
    issue.setdefault('evidence',{})['local_verification_not_attempted']='The bounded limit of twelve local review windows was reached.'
    issue['message']=str(issue.get('message',''))+' Local automatic checks reached their bounded limit; review this span.'
   continue
  print('[quality] Verifying local speech window %d/%d' % (ordinal+1,min(len(windows),12)),flush=True)
  attempts=[]
  for context in (1,2):
   a=max(0,window['a']-context);b=min(len(tokens),window['b']+context)
   while a>0 and a in protected:a-=1
   while b<len(tokens) and b in protected:b+=1
   try:measurement,proof=_measure(audio,tokens,a,b,workdir,lang,align)
   except (ValueError,RuntimeError,OSError,subprocess.SubprocessError) as error:
    attempts.append(dict(error=str(error)));continue
   context_ok=all(type(w['score']) in (int,float) and math.isfinite(w['score']) and w['score']>=.35 for i,w in measurement.items() if i not in window['targets'] and any(c.isalnum() for c in w['text']))
   strong=context_ok and all(i in measurement and type(measurement[i]['score']) in (int,float) and math.isfinite(measurement[i]['score']) and measurement[i]['score']>=_STRONG for i in window['targets'])
   stable=strong and all(abs(measurement[i]['start']-tokens[i][1])<=1/60+.001 for i in window['targets'])
   attempts.append(dict(measurement=measurement,proof=proof,strong=strong,stable=stable,context_ok=context_ok))
   if stable:
    for issue in window['issues']:
     issue.update(severity='warning',resolution='verified_by_local_mms')
     issue.setdefault('evidence',{})['local_verification']=proof
    repairs.append(dict(kind='local_acoustic_verification',script_token_indices=sorted(window['targets']),timing_changed=False,attempts=len(attempts),evidence=proof))
    break
  if any(a.get('stable') for a in attempts):continue
  # A near-spelling replacement can be acoustically indistinguishable. Keep
  # the supplied spelling only with source-bound full evidence AND two stable
  # local contexts. This never moves a clock or excuses a missing/extra word.
  normalize=lambda text:''.join(c for c in unicodedata.normalize('NFKC',str(text)).casefold() if c.isalnum())
  short_replacement=0<len(window['targets'])<=2 and all(
   issue.get('evidence',{}).get('operation')=='replace'
   and difflib.SequenceMatcher(None,normalize(issue.get('text','')),normalize(issue.get('heard','')),autojunk=False).ratio()>=.75
   for issue in window['issues']) and not any(any(c.isdigit() for c in tokens[i][0]) for i in window['targets'])
  local_pairs=[attempt for attempt in attempts if attempt.get('context_ok')]
  distinct=len(local_pairs)==2 and (local_pairs[0]['proof']['clip_sha256'],local_pairs[0]['proof']['source_offset'])!=(local_pairs[1]['proof']['clip_sha256'],local_pairs[1]['proof']['source_offset'])
  corroborated=short_replacement and distinct and all(full_scores.get(i,0)>=.80 for i in window['targets']) and all(
   i in attempt['measurement'] and type(attempt['measurement'][i]['score']) in (int,float) and attempt['measurement'][i]['score']>=.70
   and all(abs(attempt['measurement'][i][k]-tokens[i][j])<=1/60+.001 for k,j in (('start',1),('end',2)))
   for attempt in local_pairs for i in window['targets']) and all(
   abs(local_pairs[0]['measurement'][i][k]-local_pairs[1]['measurement'][i][k])<=1/60+.001
   for i in window['targets'] for k in ('start','end'))
  if corroborated:
   proof=dict(full_mms_scores={str(i):full_scores[i] for i in sorted(window['targets'])},local_contexts=[a['proof'] for a in local_pairs],timing_changed=False)
   for issue in window['issues']:
    issue.update(severity='warning',resolution='spelling_ambiguity_acoustically_corroborated')
    issue.setdefault('evidence',{})['spelling_corroboration']=proof
   repairs.append(dict(kind='spelling_ambiguity_corroboration',script_token_indices=sorted(window['targets']),timing_changed=False,attempts=2,evidence=proof))
   continue
  valid=[a for a in attempts if a.get('strong')]
  accepted=False
  different_windows=len(valid)==2 and (valid[0]['proof']['clip_sha256'],valid[0]['proof']['source_offset'])!=(valid[1]['proof']['clip_sha256'],valid[1]['proof']['source_offset'])
  if different_windows and all(abs(valid[0]['measurement'][i][k]-valid[1]['measurement'][i][k])<=1/60+.001 for i in window['targets'] for k in ('start','end')):
   overrides={o['source_index']:copy.deepcopy(o) for o in candidate.get('measurement_overrides',[])}
   proposals=[]
   for i in sorted(window['targets']):
    source_index=canonical['tokens'][i].get('source_index');found=valid[-1]['measurement'][i]
    if type(source_index) is not int or not 0<=source_index<len(rows) or any(abs(found[k]-tokens[i][j])>.3 for k,j in (('start',1),('end',2))):break
    text,old_start,old_end=rows[source_index]
    if found['end']<=found['start']:break
    value=dict(source_index=source_index,text=text,source_start=old_start,source_end=old_end,start=found['start'],end=found['end'],provenance=valid[-1]['proof'])
    overrides[source_index]=value;proposals.append(value)
   else:
    try:
     rebuilt=_fresh_plan(audio,rows,candidate,lang,list(overrides.values()))
     validation=audit_structure(script_text,rows,rebuilt,lang,scene_bounds)
     if validation['passed']:
      candidate=rebuilt;accepted=True
      for issue in window['issues']:issue.update(severity='warning',resolution='verified_caption_clock_override')
      repairs.append(dict(kind='verified_caption_clock_override',script_token_indices=sorted(window['targets']),source_rows_changed=False,attempts=2,overrides=proposals))
    except (ValueError,RuntimeError,OSError,subprocess.SubprocessError):pass
  if not accepted:
   for issue in window['issues']:
    issue.setdefault('evidence',{})['local_verification_attempts']=[dict(error=a['error']) if 'error' in a else dict(strong=a['strong'],stable=a['stable'],proof=a['proof']) for a in attempts]
 _corroborate_local(audio,tokens,lang,result,workdir,align)
 unresolved=[i for i in result.get('issues',[]) if i.get('severity')=='review']
 result.update(passed=not unresolved,status='review' if unresolved else 'pass')
 result['summary']={**result.get('summary',{}),'review_spans':len(unresolved),'warnings':sum(i.get('severity')=='warning' for i in result.get('issues',[]))}
 if candidate!=canonical and unresolved:
  # A partially repaired candidate is never exposed as a publishable plan.
  result['repairs']=[dict(r,applied=False) for r in repairs];candidate=copy.deepcopy(canonical)
 return candidate,result
