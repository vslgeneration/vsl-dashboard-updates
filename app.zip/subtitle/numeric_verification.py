"""Bounded second acoustic measurement for integer onsets rejected by MMS.

No recognizer timestamps are installed. Independent local recognition must
confirm the exact integer in context, then two DTW forced alignments must
agree. Printed script tokens are never replaced by the recognition transcript.
"""
from pathlib import Path
import hashlib, math, numbers, os, re
import speech_forms as forms


def _key(text, lang):
    return forms.spelling(text, lang)


def _mapped(expected, words, lang):
    """Bind complete contextual words, allowing only equivalent typography."""
    source=[_key(t,lang) for t in expected]
    heard=[_key(w['word'],lang) for w in words]
    needle=''.join(source);haystack=''.join(heard)
    if not needle or haystack.count(needle)!=1:return None
    start=haystack.index(needle);ends=[0]
    for h in heard:ends.append(ends[-1]+len(h))
    if start not in ends or start+len(needle) not in ends:return None
    result=[];cursor=start
    for key in source:
        stop=cursor+len(key)
        if cursor not in ends or stop not in ends:return None
        selected=words[ends.index(cursor):ends.index(stop)]
        if not selected:return None
        scores=[w.get('probability') for w in selected]
        if any(not isinstance(s,numbers.Real) or not math.isfinite(s) for s in scores):return None
        result.append(dict(start=float(selected[0]['start']),end=float(selected[-1]['end']),score=float(min(scores))))
        cursor=stop
    return result


def _consistent(res, target, attempts):
    if len(attempts)!=2 or attempts[0]['samples']==attempts[1]['samples']:return None
    a,b=max(0,target-1),min(len(res),target+2)
    for attempt in attempts:
        heard=attempt.get('recognized');measured=attempt.get('measured')
        if not heard or not measured:return None
        for k in range(a,b):
            h,w=heard.get(k),measured.get(k)
            if not h or not w:return None
            if any(not all(math.isfinite(v[t]) for t in ('start','end','score')) or v['end']<=v['start'] for v in (h,w)):return None
            if h['score']<(.60 if k==target else .35) or w['score']<(.60 if k==target else .35):return None
            # DTW can include a following pause in the next word. Only install
            # the numeral's verified clock; surrounding word onsets stay CTC.
            if k==target and (abs(h['start']-w['start'])>.15 or abs(h['end']-w['end'])>.25):return None
            if any(abs(w[t]-res[k][j])>.35 for j,t in enumerate(('start','end'))):return None
    measured=attempts[-1]['measured']
    chosen={target:measured[target]}
    for k in chosen:
        if any(abs(attempts[0]['measured'][k][t]-chosen[k][t])>.060001 for t in ('start','end')):return None
    if target and chosen[target]['start']<res[target-1][1]:
        previous=measured[target-1]
        if abs(attempts[0]['measured'][target-1]['end']-previous['end'])>.060001:return None
        if not res[target-1][0]<previous['end']<=chosen[target]['start']:return None
        chosen[target-1]=dict(previous,start=res[target-1][0])
    if target+1<len(res) and chosen[target]['end']>res[target+1][0]:return None
    if target and chosen[target]['start']<=res[target-1][0]:return None
    return chosen


def verify(x, sr, tokens, res, targets, log=print):
    """Only short, isolated integer failures; bounded to twelve targets."""
    lang=forms.language();eligible=[k for k in targets[:12] if re.fullmatch(r'\d+[.,:;!?]?',tokens[k])]
    if not eligible:return {},[]
    model_dir=Path(os.environ.get('VSL_WHISPER_CACHE') or Path.home()/'.cache/whisper')
    model_name='medium' if (model_dir/'medium.pt').is_file() else 'small'
    model_path=model_dir/(model_name+'.pt')
    if not model_path.is_file():return {},[dict(error='Local numeric verification model is unavailable.')]
    import torch,whisper,stable_whisper
    torch.set_num_threads(2)
    model=stable_whisper.load_model(str(model_path),device='cpu')
    accepted={};proofs=[]
    try:
        for k in eligible:
            log('[mms] Second acoustic check of number near %.2fs' % res[k][0]);attempts=[]
            for radius in (3,5):
                a,b=max(0,k-radius),min(len(tokens),k+radius+1)
                start=max(0.,res[a][0]-.25);end=min(len(x)/sr,res[b-1][1]+.25)
                if not 0<end-start<=15:continue
                lo,hi=int(start*sr),int(end*sr);clip=x[lo:hi].copy();offset=lo/sr
                proof=dict(samples=[lo,hi],clip_sha256=hashlib.sha256(clip.tobytes()).hexdigest(),context=[a,b])
                try:
                    # Separate, audio-only recognition has no script prompt.
                    observed=whisper.transcribe(model,clip,language=lang.split('_')[0],initial_prompt=None,
                        condition_on_previous_text=False,word_timestamps=True,temperature=0,fp16=False,verbose=None)
                    words=[w for s in observed['segments'] for w in s.get('words',[])]
                    selected=tokens[max(0,k-1):min(len(tokens),k+2)]
                    heard=_mapped(selected,words,lang)
                    proof['recognized_text']=' '.join(w['word'].strip() for w in words)
                    if heard is None:attempts.append(proof);continue
                    # Neutral alignment spelling prevents punctuation likelihood
                    # (e.g. a colon) from becoming a false acoustic rejection.
                    text=' '.join(('Nummer' if lang.split('_')[0]=='de' and re.fullmatch(r'Nr\.',t,re.I)
                                   else t.strip('“”"«»()[]').rstrip('.,:;!?')) for t in tokens[a:b])
                    aligned=model.align(clip,text,language=lang.split('_')[0],verbose=None,regroup=False,
                                        suppress_silence=False,presplit=False)
                    measured_words=[w for s in aligned.to_dict()['segments'] for w in s.get('words',[])]
                    measured=_mapped(selected,measured_words,lang)
                    for name,values in (('recognized',heard),('measured',measured)):
                        if values is not None:
                            proof[name]={j:dict(v,start=v['start']+offset,end=v['end']+offset)
                                         for j,v in enumerate(values,max(0,k-1))}
                    attempts.append(proof)
                except (ValueError,RuntimeError,OSError) as error:
                    proof['error']=str(error);attempts.append(proof)
            selected=_consistent(res,k,attempts)
            proofs.append(dict(method='independent-recognition-and-two-local-dtw-v1009',unit_index=k,
                               printed_text=tokens[k],model=model_name,attempts=attempts,accepted=bool(selected)))
            if selected:
                accepted[k]=selected
                for index,word in selected.items():res[index]=[word['start'],word['end']]
    finally:del model
    return accepted,proofs
