"""Conservative sentence spacing shared by display and audio tokenization.

Only whitespace is inserted. Numbers, abbreviations, web addresses, initials,
apostrophes and hyphenated words retain their original spelling.
"""
import re
import unicodedata

_ABBREVIATIONS = frozenset(('mr mrs ms dr prof sr jr st no nr vs etc e.g i.e '
                          'ph ll msc bsc mme mlle m mx bzw ca z.b u.a sra srta dra ing').split())
_TITLES = frozenset(('mr mrs ms dr dra drs prof professor sr jr st mme mlle m '
                     'sra srta don dona ing dipl lic herr frau hr fr sir').split())
_UNITS = frozenset(('percent percentage porcent pourcent prozent yüzde percento '
                    'kg g mg mcg µg μg lb lbs oz ml cl dl l mm cm m km ft in '
                    'mmhg bpm hz khz mhz kcal cal iu ui usd eur gbp tl try '
                    'euro euros dollar dollars cent cents centime centimes pound pounds pfund '
                    'year years month months week weeks day days hour hours minute minutes second seconds '
                    'an ans année années mois semaine semaines jour jours heure heures seconde secondes '
                    'jahr jahre jahren monat monate monaten woche wochen tag tage tagen stunde stunden '
                    'año años mes meses semana semanas día días hora horas segundo segundos '
                    'anno anni mese mesi settimana settimane giorno giorni ora ore '
                    'yıl yıldır yaş ay hafta gün saat dakika saniye '
                    'ano anos ano mês meses semana semanas dia dias hora horas '
                    'jaar jaren maand maanden week weken dag dagen uur uren '
                    'год года лет месяц месяцев день дня дней час часов минут секунд '
                    'سنة سنوات عام أعوام شهر أشهر يوم أيام ساعة ساعات '
                    'سال ماه روز ساعت دقیقه ثانیه वर्ष साल महीने दिन घंटे मिनट').split())
_CURRENCY = frozenset('$ € £ ¥ ￥ ₺ ₹ ₽ ₩ ₪ ₫ ฿ ₱ ₦ ₴ ﷼ ¢'.split())
_OPEN = frozenset(('(', '[', '{', '«', '‹', '“', '„', '‘', '「', '『', '（', '【', '¿', '¡'))
_CLOSE = frozenset((')', ']', '}', '»', '›', '”', '’', '」', '』', '）', '】'))
_JOINERS = frozenset(('-', '‐', '‑', '/', "'", '’'))
_NUMBER_LABELS = frozenset(('nr', 'no', 'nº', 'n°', '№', '#'))
_VALUE_LABELS = frozenset(('value worth price cost costs save savings discount total amount '
                           'wert preis kosten ersparnis ersparnisse rabatt gesamtbetrag '
                           'valeur prix coût coûts économie économies remise montant').split())


class ProtectedExpressionError(ValueError):
    def __init__(self, words, index):
        self.start=float(words[index][1]);self.end=float(words[index][2])
        self.expression=words[index-1][0]+' '+words[index][0]
        at='%02d:%06.3f' % (int(self.start)//60,self.start%60)
        super().__init__('A fixed subtitle boundary splits '+self.expression+' near '+at+
                         '. Keep this expression together; existing scene times were not changed.')


def word_key(text):
    """Comparison only; never use this normalized form as subtitle text."""
    return text.casefold().strip('.,;:!?…。！？،؛“”‘’«»‹›()[]{}「」『』【】"').replace('’', "'")


def is_spoken_token(text):
    symbol=text.strip(' \t\n"“”‘’«»‹›()[]{}!?;:،؛。.,')
    return any(ch.isalnum() for ch in text) or symbol in _CURRENCY or symbol in ('%', '‰', '٪')


def numeric_units(tokens):
    """Contextual numeric expressions with original printed-token indices."""
    try:
        from .speech_forms import contextual_units
    except ImportError:
        from speech_forms import contextual_units
    return [u for u in contextual_units(tokens) if u['numeric'] and len(u['indices'])>1]


def is_abbreviation(text):
    value = text.lstrip('"“„‘«‹([{¿¡').rstrip('"”’»›)]}').casefold()
    return (value.endswith('.') and (value.rstrip('.') in _ABBREVIATIONS or
            value.rstrip('.') in _TITLES or bool(re.fullmatch(r'(?:[^\W\d_]\.)+', value, re.U))))


def number_label_boundaries(tokens):
    """A number label and its value form one printed expression, e.g. Nr. 1:."""
    protected=set()
    for i,token in enumerate(tokens[:-1]):
        if word_key(token) not in _NUMBER_LABELS:continue
        j=i+1
        if tokens[j]=='.' and j+1<len(tokens):j+=1
        if re.match(r'^[+−-]?\d',word_key(tokens[j])):
            protected.update(range(i+1,j+1))
    return protected


def value_label_boundaries(tokens):
    protected=set()
    for i,token in enumerate(tokens[:-1]):
        if word_key(token) not in _VALUE_LABELS:continue
        j=i+1
        if tokens[j]==':' and j+1<len(tokens):j+=1
        if tokens[j] in _CURRENCY and j+1<len(tokens):j+=1
        value=word_key(tokens[j]).lstrip(''.join(_CURRENCY))
        if re.match(r'^[+−-]?\d',value):protected.update(range(i+1,j+1))
    return protected


def short_parenthetical_boundaries(tokens):
    """Keep short balanced asides in one cue; long passages may still wrap/split."""
    opens={'(':')','[':']','（':'）'};closes=set(opens.values());stack=[];protected=set()
    for i,token in enumerate(tokens):
        for char in token:
            if char in opens:stack.append((char,i))
            elif char in closes and stack:
                opener,a=stack.pop()
                if opens[opener]!=char:stack.clear();continue
                width=sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in ('W','F') else 1 for c in ' '.join(tokens[a:i+1]))
                if i-a+1<=8 and width<=64:
                    protected.update(range(a+1,i+1))
    return protected


def inseparable_boundaries(tokens):
    return number_label_boundaries(tokens)|value_label_boundaries(tokens)|short_parenthetical_boundaries(tokens)


def protected_boundaries(tokens, *, line=False):
    """Indices at which token expressions must stay together, in any language.

    Punctuation and numeric syntax are structural, not an English word list.
    Named units/titles supplement this without changing spelling or punctuation.
    """
    protected={i for unit in numeric_units(tokens) for i in unit['indices'][1:]}
    protected.update(number_label_boundaries(tokens))
    protected.update(value_label_boundaries(tokens))
    if not line:protected.update(short_parenthetical_boundaries(tokens))
    quote_open = {'"': False, "'": False}
    for i, token in enumerate(tokens):
        if token in _OPEN:
            if i + 1 < len(tokens): protected.add(i + 1)
        elif token in _CLOSE:
            if i: protected.add(i)
        elif token in quote_open:
            if quote_open[token]:
                if i: protected.add(i)
            elif i + 1 < len(tokens): protected.add(i + 1)
            quote_open[token] = not quote_open[token]
        elif token in _JOINERS:
            if i: protected.add(i)
            if i + 1 < len(tokens): protected.add(i + 1)
        elif not is_spoken_token(token) and token not in _CURRENCY:
            # Comma/period/percent and every script's trailing punctuation.
            if i: protected.add(i)
        if i + 1 >= len(tokens): continue
        right, key = tokens[i + 1], word_key(token)
        right_key = word_key(right)
        if token in _CURRENCY or token.endswith(("'", '’', '‐', '‑')):
            protected.add(i + 1)
        if is_abbreviation(token): protected.add(i + 1)
        if any(ch.isdigit() for ch in token):
            if right_key in _UNITS or right_key in _CURRENCY or right[:1] in ('%', '‰', '٪', '°'):
                protected.add(i + 1)
            # Unicode digits and whitespace thousands groups: 1 000 / ١ ٠٠٠.
            if re.fullmatch(r'[+−-]?\d{1,3}', token) and re.match(r'^\d{3}(?:\D|$)', right):
                protected.add(i + 1)
            # A separate decimal separator keeps both halves of a price intact.
            if right in ('.', ',', '٫', '٬') and i + 2 < len(tokens) and tokens[i + 2].isdigit():
                protected.update((i + 1, i + 2))
    return protected
_LINK = re.compile(r'(?:\w+://|www\.|[^\s@]+@)\S+|\b[\w.-]+\.(?:com|org|net|edu|gov|io|co|uk|de|fr|tr)(?:/\S*)?\b', re.I)
_BOUNDARY = re.compile(r"(?P<word>[^\W\d_]+)(?P<mark>[.!?…。！？]+)(?P<quotes>[\"'”’»\)\]]*)(?P<next>[^\W\d_])", re.U)


def spacing_positions(text):
    links = [m.span() for m in _LINK.finditer(text)]
    out = []
    for m in _BOUNDARY.finditer(text):
        pos = m.start('next')
        if any(a <= pos < b for a, b in links):
            continue
        mark, word = m['mark'], m['word']
        if mark == '.':
            # Lower-case domain suffixes are ambiguous without a language model.
            # Never split initials/abbreviations just because the next name is capitalized.
            if not m['next'].isupper() or len(word) == 1 or word.casefold() in _ABBREVIATIONS:
                continue
            if m.start() and text[m.start()-1] == '.':
                continue
        out.append(pos)
    return out


def normalize_spacing(text):
    for pos in reversed(spacing_positions(text)):
        text = text[:pos] + ' ' + text[pos:]
    return text


def spacing_changes(text, occupied=()):
    """Deterministic suggestions, even when the AI proofreading service fails."""
    changes = []
    for match in re.finditer(r'\S+', text):
        before = match.group();after = normalize_spacing(before)
        if before == after or any(c['start'] <= match.end() and c['end'] >= match.start() for c in occupied):
            continue
        changes.append(dict(start=match.start(), end=match.end(), before=before, after=after, kind='spelling',
                            reason='Missing Space Between Sentences',
                            context=text[max(0, match.start()-45):match.end()+45]))
    return changes


def joined_words(words):
    """Rows have (text,start,end), as used by the aligner; timing is never guessed."""
    return [i for i, row in enumerate(words) if normalize_spacing(row[0]) != row[0]]


def spoken_text(text):
    """Existing non-VO cleanup shared by generation and explicit review receipts."""
    kept=[];skip_b=False
    for paragraph in str(text).splitlines():
        value=paragraph.strip()
        if value.upper()=='SOURCES':break
        if value=='[START OF VERSION B]':skip_b=True;continue
        if value=='[END OF VERSION B]':skip_b=False;continue
        if skip_b or re.match(r'^\[.*\]$',value) or value.startswith('(Note for the Voice Actor'):continue
        if value:kept.append(value)
    return normalize_spacing(' '.join(kept))
