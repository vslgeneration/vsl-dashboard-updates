"""Conservative sentence spacing shared by display and audio tokenization.

Only whitespace is inserted. Numbers, abbreviations, web addresses, initials,
apostrophes and hyphenated words retain their original spelling.
"""
import re

_ABBREVIATIONS = frozenset(('mr mrs ms dr prof sr jr st no vs etc e.g i.e '
                          'ph ll msc bsc mme mlle m mx bzw ca z.b u.a sra srta dra ing').split())
_LINK = re.compile(r'(?:\w+://|www\.|[^\s@]+@)\S+|\b[\w.-]+\.(?:com|org|net|edu|gov|io|co|uk|de|fr|tr)(?:/\S*)?\b', re.I)
_BOUNDARY = re.compile(r"(?P<word>[^\W\d_]+)(?P<mark>[.!?…。！？]+)(?P<quotes>[\"'”’»\)\]]*)(?P<next>[^\W\d_])", re.U)


def spacing_positions(text):
    links = [m.span() for m in _LINK.finditer(text)]
    out = []
    for m in _BOUNDARY.finditer(text):
        pos = m.start('next')
        if any(a <= pos < b for a, b in links):
            continue
        mark, word = m['mark'], m['word']
        if mark == '.':
            # Lower-case domain suffixes are ambiguous without a language model.
            # Never split initials/abbreviations just because the next name is capitalized.
            if not m['next'].isupper() or len(word) == 1 or word.casefold() in _ABBREVIATIONS:
                continue
            if m.start() and text[m.start()-1] == '.':
                continue
        out.append(pos)
    return out


def normalize_spacing(text):
    for pos in reversed(spacing_positions(text)):
        text = text[:pos] + ' ' + text[pos:]
    return text


def spacing_changes(text, occupied=()):
    """Deterministic suggestions, even when the AI proofreading service fails."""
    changes = []
    for match in re.finditer(r'\S+', text):
        before = match.group();after = normalize_spacing(before)
        if before == after or any(c['start'] <= match.end() and c['end'] >= match.start() for c in occupied):
            continue
        changes.append(dict(start=match.start(), end=match.end(), before=before, after=after, kind='spelling',
                            reason='Missing Space Between Sentences',
                            context=text[max(0, match.start()-45):match.end()+45]))
    return changes


def joined_words(words):
    """Rows have (text,start,end), as used by the aligner; timing is never guessed."""
    return [i for i, row in enumerate(words) if normalize_spacing(row[0]) != row[0]]
