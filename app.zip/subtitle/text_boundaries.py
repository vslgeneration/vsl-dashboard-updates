"""Conservative sentence spacing shared by display and audio tokenization.

Only whitespace is inserted. Numbers, abbreviations, web addresses, initials,
apostrophes and hyphenated words retain their original spelling.
"""
import re

_ABBREVIATIONS = frozenset(('mr mrs ms dr prof sr jr st no vs etc e.g i.e '
                          'ph ll msc bsc mme mlle m mx bzw ca z.b u.a sra srta dra ing').split())
_TITLES = frozenset(('mr mrs ms dr dra drs prof professor sr jr st mme mlle m '
                     'sra srta don dona ing dipl lic herr frau hr fr sir').split())
_UNITS = frozenset(('percent percentage porcent pourcent prozent yüzde percento '
                    'kg g mg mcg µg μg lb lbs oz ml cl dl l mm cm m km ft in '
                    'mmhg bpm hz khz mhz kcal cal iu ui usd eur gbp tl try '
                    'year years month months week weeks day days hour hours minute minutes second seconds '
                    'an ans année années mois semaine semaines jour jours heure heures seconde secondes '
                    'jahr jahre jahren monat monate monaten woche wochen tag tage tagen stunde stunden '
                    'año años mes meses semana semanas día días hora horas segundo segundos '
                    'anno anni mese mesi settimana settimane giorno giorni ora ore '
                    'yıl yıldır yaş ay hafta gün saat dakika saniye '
                    'ano anos ano mês meses semana semanas dia dias hora horas '
                    'jaar jaren maand maanden week weken dag dagen uur uren '
                    'год года лет месяц месяцев день дня дней час часов минут секунд '
                    'سنة سنوات عام أعوام شهر أشهر يوم أيام ساعة ساعات '
                    'سال ماه روز ساعت دقیقه ثانیه वर्ष साल महीने दिन घंटे मिनट').split())
_CURRENCY = frozenset('$ € £ ¥ ￥ ₺ ₹ ₽ ₩ ₪ ₫ ฿ ₱ ₦ ₴ ﷼ ¢'.split())
_OPEN = frozenset(('(', '[', '{', '«', '‹', '“', '„', '‘', '「', '『', '（', '【', '¿', '¡'))
_CLOSE = frozenset((')', ']', '}', '»', '›', '”', '’', '」', '』', '）', '】'))
_JOINERS = frozenset(('-', '‐', '‑', '/', "'", '’'))


def word_key(text):
    """Comparison only; never use this normalized form as subtitle text."""
    return text.casefold().strip('.,;:!?…。！？،؛“”‘’«»‹›()[]{}「」『』【】"').replace('’', "'")


def is_spoken_token(text):
    symbol=text.strip(' \t\n"“”‘’«»‹›()[]{}!?;:،؛。.,')
    return any(ch.isalnum() for ch in text) or symbol in _CURRENCY or symbol in ('%', '‰', '٪')


def numeric_units(tokens):
    """Contextual numeric expressions with original printed-token indices."""
    try:
        from .speech_forms import contextual_units
    except ImportError:
        from speech_forms import contextual_units
    return [u for u in contextual_units(tokens) if u['numeric'] and len(u['indices'])>1]


def is_abbreviation(text):
    value = text.lstrip('"“„‘«‹([{¿¡').rstrip('"”’»›)]}').casefold()
    return (value.endswith('.') and (value.rstrip('.') in _ABBREVIATIONS or
            value.rstrip('.') in _TITLES or bool(re.fullmatch(r'(?:[^\W\d_]\.)+', value, re.U))))


def protected_boundaries(tokens):
    """Indices at which token expressions must stay together, in any language.

    Punctuation and numeric syntax are structural, not an English word list.
    Named units/titles supplement this without changing spelling or punctuation.
    """
    protected={i for unit in numeric_units(tokens) for i in unit['indices'][1:]}
    quote_open = {'"': False, "'": False}
    for i, token in enumerate(tokens):
        if token in _OPEN:
            if i + 1 < len(tokens): protected.add(i + 1)
        elif token in _CLOSE:
            if i: protected.add(i)
        elif token in quote_open:
            if quote_open[token]:
                if i: protected.add(i)
            elif i + 1 < len(tokens): protected.add(i + 1)
            quote_open[token] = not quote_open[token]
        elif token in _JOINERS:
            if i: protected.add(i)
            if i + 1 < len(tokens): protected.add(i + 1)
        elif not is_spoken_token(token) and token not in _CURRENCY:
            # Comma/period/percent and every script's trailing punctuation.
            if i: protected.add(i)
        if i + 1 >= len(tokens): continue
        right, key = tokens[i + 1], word_key(token)
        right_key = word_key(right)
        if token in _CURRENCY or token.endswith(("'", '’', '‐', '‑')):
            protected.add(i + 1)
        if is_abbreviation(token): protected.add(i + 1)
        if any(ch.isdigit() for ch in token):
            if right_key in _UNITS or right_key in _CURRENCY or right[:1] in ('%', '‰', '٪', '°'):
                protected.add(i + 1)
            # Unicode digits and whitespace thousands groups: 1 000 / ١ ٠٠٠.
            if re.fullmatch(r'[+−-]?\d{1,3}', token) and re.match(r'^\d{3}(?:\D|$)', right):
                protected.add(i + 1)
            # A separate decimal separator keeps both halves of a price intact.
            if right in ('.', ',', '٫', '٬') and i + 2 < len(tokens) and tokens[i + 2].isdigit():
                protected.update((i + 1, i + 2))
    return protected
_LINK = re.compile(r'(?:\w+://|www\.|[^\s@]+@)\S+|\b[\w.-]+\.(?:com|org|net|edu|gov|io|co|uk|de|fr|tr)(?:/\S*)?\b', re.I)
_BOUNDARY = re.compile(r"(?P<word>[^\W\d_]+)(?P<mark>[.!?…。！？]+)(?P<quotes>[\"'”’»\)\]]*)(?P<next>[^\W\d_])", re.U)


def spacing_positions(text):
    links = [m.span() for m in _LINK.finditer(text)]
    out = []
    for m in _BOUNDARY.finditer(text):
        pos = m.start('next')
        if any(a <= pos < b for a, b in links):
            continue
        mark, word = m['mark'], m['word']
        if mark == '.':
            # Lower-case domain suffixes are ambiguous without a language model.
            # Never split initials/abbreviations just because the next name is capitalized.
            if not m['next'].isupper() or len(word) == 1 or word.casefold() in _ABBREVIATIONS:
                continue
            if m.start() and text[m.start()-1] == '.':
                continue
        out.append(pos)
    return out


def normalize_spacing(text):
    for pos in reversed(spacing_positions(text)):
        text = text[:pos] + ' ' + text[pos:]
    return text


def spacing_changes(text, occupied=()):
    """Deterministic suggestions, even when the AI proofreading service fails."""
    changes = []
    for match in re.finditer(r'\S+', text):
        before = match.group();after = normalize_spacing(before)
        if before == after or any(c['start'] <= match.end() and c['end'] >= match.start() for c in occupied):
            continue
        changes.append(dict(start=match.start(), end=match.end(), before=before, after=after, kind='spelling',
                            reason='Missing Space Between Sentences',
                            context=text[max(0, match.start()-45):match.end()+45]))
    return changes


def joined_words(words):
    """Rows have (text,start,end), as used by the aligner; timing is never guessed."""
    return [i for i, row in enumerate(words) if normalize_spacing(row[0]) != row[0]]
