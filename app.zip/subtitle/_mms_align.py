# -*- coding: utf-8 -*-
"""Long-form word-level forced alignment with torchaudio MMS-FA (multilingual CTC).

Why not Whisper: Whisper does not produce timestamps, it infers them from cross-attention. The median
is fine (~20 ms) but it lands a word up to ~700 ms out at some sentence starts, and on multi-minute
audio its forced-align COLLAPSES — runs of words snap onto one timestamp while audio remains. That is
what the tail-repair / two-model ensemble in vsl_align_srt.py existed to paper over. MMS-FA is a real
forced aligner and has neither failure mode.

Long audio (too long for one forward pass) is aligned with a sliding window. Each pass is deliberately
given LESS script than the window holds, with a trailing "*" token to absorb the audio left over, and
the next pass restarts from the end of the last accepted word so the words-per-second estimate
corrects itself. Both halves of that matter: without the star the last word is dragged to the end of
the window, and over-feeding compresses the window instead of spilling out of it — see the loop.

align(audio_path, text, lang) -> [(token, start, end), ...]  one entry per whitespace token of `text`
"""
import os, re, wave, math, tempfile, shutil, subprocess
from text_boundaries import normalize_spacing, joined_words

WINDOW = 90.0          # seconds of audio per pass
FEED = 0.85            # fraction of the window's worth of words to hand over — see the loop; NEVER > 1
TRIM = 1               # words dropped from the tail of each non-final pass (re-done in the next one)
BIAS = 0.033           # MMS-FA marks word starts ~33 ms late (measured over 1267 onsets)

_FOLD = {"ä": "a", "ö": "o", "ü": "u", "ß": "ss", "é": "e", "è": "e", "ê": "e", "ë": "e",
         "à": "a", "â": "a", "á": "a", "ç": "c", "î": "i", "ï": "i", "í": "i", "ì": "i",
         "ô": "o", "ó": "o", "ò": "o", "õ": "o", "û": "u", "ù": "u", "ú": "u", "ñ": "n",
         "œ": "oe", "å": "a", "ø": "o", "æ": "ae", "ı": "i", "ş": "s", "ğ": "g", "ý": "y"}
_WORDCH = re.compile(r"[^\W_]", re.U)


def repair_joined_words(audio_path, rows, log=print):
    """Measure broken sentence boundaries locally, preserving unrelated timings.

    Keep a small acoustic context on each side: old neighbouring onsets may
    overlap the merged word and cannot safely be reused as separate words.
    """
    broken = joined_words(rows)
    if not broken:
        return rows
    windows = []
    for index in broken:
        a, b = max(0, index-5), min(len(rows), index+6)
        if windows and a <= windows[-1][1]:
            windows[-1] = (windows[-1][0], max(b, windows[-1][1]))
        else:
            windows.append((a,b))
    output, cursor = [], 0
    for a,b in windows:
        start = max(0., min(r[1] for r in rows[a:b])-.25)
        end = max(r[2] for r in rows[a:b])+.25
        if not 0 < end-start <= 30:
            raise ValueError('Merged-word audio window is invalid. Regenerate subtitles to remeasure it.')
        expected = normalize_spacing(' '.join(r[0] for r in rows[a:b])).split()
        log('[repair] Measuring joined words in %.2f–%.2fs audio' % (start, end))
        with tempfile.TemporaryDirectory(prefix='joined_words_') as td:
            clip = os.path.join(td, 'audio.wav')
            subprocess.run(['ffmpeg', '-v', 'error', '-nostdin', '-ss', str(start), '-i', str(audio_path),
                            '-t', str(end-start), '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', clip],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=120,
                           creationflags=0x08000000 if os.name == 'nt' else 0)
            measured = align(clip, ' '.join(expected), log=log)
        if [r[0] for r in measured] != expected:
            raise ValueError('Merged-word repair did not preserve the text; previous timing was kept.')
        result = [(t, round(s+start, 3), round(e+start, 3)) for t,s,e in measured]
        lower = rows[a-1][1] if a else 0.
        upper = rows[b][1] if b < len(rows) else end
        if (any(not all(math.isfinite(v) for v in (s,e)) or e <= s or s < lower-.05 or s > upper+.05 for _,s,e in result)
                or any(result[k][1] > result[k+1][1] for k in range(len(result)-1))):
            raise ValueError('Merged-word repair could not establish separate onsets; previous timing was kept.')
        for index in (i for i in broken if a <= i < b):
            offset = len(normalize_spacing(' '.join(r[0] for r in rows[a:index])).split())
            count = len(normalize_spacing(rows[index][0]).split())
            if any(result[k][1] >= result[k+1][1] for k in range(offset,offset+count-1)):
                raise ValueError('Joined words still share an onset; previous timing was kept.')
        output.extend(rows[cursor:a]);output.extend(result);cursor=b
    output.extend(rows[cursor:])
    return output


def fold(s):
    s = s.lower()
    for a, b in _FOLD.items():
        s = s.replace(a, b)
    return re.sub(r"[^a-z']", "", s)


def _wav16(src):
    td = tempfile.mkdtemp(prefix="mmsalign_")
    dst = os.path.join(td, "a16.wav")
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", src,
                    "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", dst], check=True)
    return dst, td


_MODEL = None

def align(audio_path, text, log=print, diagnostics=None):
    import numpy as np, torch, torchaudio

    bundle = torchaudio.pipelines.MMS_FA
    # with_star=True adds the "*" token, which absorbs audio that none of the given words match. That
    # is what makes a WINDOW alignable at all: without it a CTC aligner has to cover every frame with
    # the words it was handed, so the last word of a window gets dragged out to the window's end no
    # matter how many words were supplied. Measured on a 90s window: without the star the final word
    # landed at 89.6 / 88.0 / 88.2s for 143 / 180 / 240 words handed over (i.e. it just filled the
    # window); with it, 50.9 / 65.6 / 84.5s — a steady 2.8 words/sec, the real speaking rate.
    global _MODEL
    if _MODEL is None:
        torch.set_num_threads(min(4, os.cpu_count() or 1))
        _MODEL = bundle.get_model(with_star=True)
        _MODEL.eval()
    model = _MODEL
    scores = {}
    tokenizer = bundle.get_tokenizer()
    aligner = bundle.get_aligner()

    wav, td = _wav16(audio_path)
    try:
        with wave.open(wav, "rb") as w:
            sr = w.getframerate()
            x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        dur = len(x) / sr

        toks = [t for t in normalize_spacing(text).split() if _WORDCH.search(t)]
        folded = [fold(t) for t in toks]
        n = len(toks)
        log("[mms] %d words / %.0fs audio" % (n, dur))

        # energy envelope, for snapping each accepted start to the real speech onset
        hop, win = int(0.0025 * sr), int(0.010 * sr)
        nfr = max(1, (len(x) - win) // hop)
        env = np.sqrt(np.array([np.mean(x[k * hop:k * hop + win] ** 2) for k in range(nfr)], dtype=np.float32))
        th = max(float(np.percentile(env, 10)) * 4.0, 0.004)

        def E(t):
            k = int(t * sr / hop)
            return float(env[k]) if 0 <= k < len(env) else 0.0

        def snap(t, back=0.35):
            """Move t onto the real speech onset. Walk BACK from t (through the word itself) to the
            silence in front of it, then forward to the first speech frame. A fixed look-back of one
            window fails whenever the model is later than that window — which is exactly the case
            that matters — so the walk is what finds the onset, not a probe at a fixed offset."""
            u, limit = t, t - back
            while u > limit and E(u) > th:
                u -= 0.0025
            if u <= limit:                      # no silence within `back`: genuinely mid-flow
                return max(0.0, t - BIAS)
            v = u
            while v < t + 0.10 and E(v) <= th:
                v += 0.0025
            return max(0.0, v) if abs(v - t) < back else max(0.0, t - BIAS)

        res = [None] * n
        a_t, w_i, rate, guard = 0.0, 0, 2.7, 0
        while w_i < n and a_t < dur - 0.05 and guard < 400:
            guard += 1
            span = min(WINDOW, dur - a_t)
            last = (a_t + span) >= dur - 0.05
            # Hand the window FEWER words than it can hold — never more. Every token given must be
            # emitted somewhere, and a surplus cannot spill past the end of the window, so it gets
            # crammed inside it; the compressed result then RAISES the measured rate, the next window
            # is fed even harder, and the run ends with the script squeezed into the first half of the
            # audio and the rest bare. Coming up short costs nothing: the star soaks up the leftover
            # audio and the next pass picks the words up.
            take = n - w_i if last else max(8, min(n - w_i, int(span * rate * FEED)))
            idx = [k for k in range(w_i, min(n, w_i + take)) if folded[k]]
            if not idx:
                break
            seg = x[int(a_t * sr):int((a_t + span) * sr)]
            lst = ["*"] + [folded[k] for k in idx] + ["*"]   # the star eats the rest of the window (see get_model above)
            with torch.inference_mode():
                em, _ = model(torch.from_numpy(seg).unsqueeze(0))
                spans = aligner(em[0], tokenizer(lst))
            ratio = len(seg) / em.shape[1]
            if len(spans) != len(lst):        # zip() would SILENTLY truncate and drop words
                raise RuntimeError('MMS-FA returned %d spans for %d tokens' % (len(spans), len(lst)))
            spans = spans[1:1+len(idx)]          # drop the star's own span
            got = [(k, a_t + sp[0].start * ratio / sr, a_t + sp[-1].end * ratio / sr)
                   for sp, k in zip(spans, idx)]
            if not last and len(got) > TRIM:
                got = got[:-TRIM]                # the word right against the star boundary is the least certain one
            for sp,k in zip(spans,idx):
                scores[k] = sum(float(v.score)*(v.end-v.start) for v in sp)/max(1,sum(v.end-v.start for v in sp))
            for k, s, e in got:
                res[k] = [s, e]
            acc, nxt = got[-1][0] + 1, got[-1][2]
            if acc <= w_i or nxt <= a_t + 0.5:   # no progress in words or in time: shove the window on
                a_t += max(5.0, span * 0.5)
                w_i = max(w_i, acc)
                continue
            rate = max(1.2, min(6.0, (acc - w_i) / (nxt - a_t)))
            a_t, w_i = nxt, acc
            log("[mms] %d/%d words, %.0f/%.0fs" % (w_i, n, min(a_t, dur), dur))

        if any(folded[k] and res[k] is None for k in range(n)):
            raise ValueError('Some script words could not be measured. Check the recording and script; previous subtitles were kept.')
        if diagnostics is not None:
            diagnostics['scores'] = [dict(token=toks[k],score=scores[k]) for k in sorted(scores)]
        if diagnostics is not None:
            diagnostics['raw_words'] = [[toks[k], *res[k]] if res[k] else [toks[k], None, None] for k in range(n)]
        # Tokens without a CTC spelling keep their place between measured neighbours.
        for k in range(n):
            if res[k]:
                continue
            p = next((res[j] for j in range(k - 1, -1, -1) if res[j]), None)
            q = next((res[j] for j in range(k + 1, n) if res[j]), None)
            if p and q:
                res[k] = [p[1], max(p[1] + 0.05, q[0])]
            elif p:
                res[k] = [p[1], min(dur, p[1] + 0.30)]
            elif q:
                res[k] = [max(0.0, q[0] - 0.30), q[0]]
            else:
                res[k] = [0.0, min(dur, 0.30)]

        # CTC already measures phonetic word boundaries. A 350 ms energy walk
        # can jump to silence inside the PREVIOUS word ("floor and"), then
        # collapse several following words. Only refine isolated phrase onsets;
        # never move a continuous-speech word outside its measured neighbours.
        raw = [list(row) for row in res]
        for k, (start, end) in enumerate(raw):
            lower = raw[k-1][1] if k else 0.0
            corrected = max(lower, start-BIAS)
            if start-lower >= .10 or k == 0:
                candidate = snap(start, back=.06)
                if max(lower, start-.06) <= candidate <= start+.025:
                    corrected = candidate
            res[k][0] = max(0., min(end-.001, corrected))
            res[k][1] = max(res[k][0]+.001, end)
        result = [(toks[k], round(res[k][0], 3), round(res[k][1], 3)) for k in range(n)]
        from bounded_alignment import check_rows
        check_rows(result, dur)
        return result
    finally:
        shutil.rmtree(td, ignore_errors=True)
