"""Spoken number spellings for testimonial alignment; never rewrite displayed copy."""
import re

VERSION = 1
UNITS = {
    "en": "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split(),
    "fr": "zéro un deux trois quatre cinq six sept huit neuf dix onze douze treize quatorze quinze seize".split(),
    "de": "null eins zwei drei vier fünf sechs sieben acht neun zehn elf zwölf dreizehn vierzehn fünfzehn sechzehn siebzehn achtzehn neunzehn".split(),
    "es": "cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciséis diecisiete dieciocho diecinueve veinte veintiuno veintidós veintitrés veinticuatro veinticinco veintiséis veintisiete veintiocho veintinueve".split(),
    "it": "zero uno due tre quattro cinque sei sette otto nove dieci undici dodici tredici quattordici quindici sedici diciassette diciotto diciannove".split(),
    "tr": "sıfır bir iki üç dört beş altı yedi sekiz dokuz".split(),
}
TENS = {
    "en": "zero ten twenty thirty forty fifty sixty seventy eighty ninety".split(),
    "fr": "zéro dix vingt trente quarante cinquante soixante".split(),
    "de": "null zehn zwanzig dreißig vierzig fünfzig sechzig siebzig achtzig neunzig".split(),
    "es": "cero diez veinte treinta cuarenta cincuenta sesenta setenta ochenta noventa".split(),
    "it": "zero dieci venti trenta quaranta cinquanta sessanta settanta ottanta novanta".split(),
    "tr": "sıfır on yirmi otuz kırk elli altmış yetmiş seksen doksan".split(),
}


def cardinal(n, lang="en"):
    lang = str(lang or "en").lower()[:2]
    if lang not in UNITS or not 0 <= n < 1000000:
        return None
    u, tens = UNITS[lang], TENS[lang]
    if n < len(u):
        return u[n]
    if n < 100:
        a, b = divmod(n, 10)
        if lang == "fr":
            if n >= 80:
                return "quatre-vingts" if n == 80 else "quatre-vingt-" + cardinal(n-80, lang)
            if n >= 70:
                return "soixante" + (" et " if n == 71 else "-") + cardinal(n-60, lang)
            if n < 20:
                return "dix-" + u[b]
            return tens[a] + ((" et " if b == 1 else "-") + u[b] if b else "")
        if lang == "de":
            return (("ein" if b == 1 else u[b]) + "und" if b else "") + tens[a]
        if lang == "it":
            return (tens[a][:-1] if b in (1, 8) else tens[a]) + (("tré" if b == 3 else u[b]) if b else "")
        return tens[a] + ((" y " if lang == "es" else " ") + u[b] if b else "")
    if n < 1000:
        a, b = divmod(n, 100)
        if lang == "en":
            lead = u[a] + " hundred"
        elif lang == "fr":
            lead = ("cent" if a == 1 else u[a] + " cent") + ("s" if a > 1 and not b else "")
        elif lang == "de":
            lead = ("ein" if a == 1 else u[a]) + "hundert"
        elif lang == "es":
            lead = ["", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"][a]
            if n == 100:
                return "cien"
        elif lang == "it":
            lead = ("" if a == 1 else u[a]) + ("cent" if b == 8 or 80 <= b < 90 else "cento")
        else:
            lead = ("" if a == 1 else u[a] + " ") + "yüz"
        return lead + (("" if lang in ("de", "it") else " ") + cardinal(b, lang) if b else "")
    a, b = divmod(n, 1000)
    if lang == "en":
        lead = cardinal(a, lang) + " thousand"
    elif lang == "fr":
        prefix = cardinal(a, lang)
        if a % 100 == 80 or a % 100 == 0:
            prefix = prefix.removesuffix("s")
        lead = "mille" if a == 1 else prefix + " mille"
    elif lang == "de":
        lead = ("ein" if a == 1 else cardinal(a, lang)) + "tausend"
    elif lang == "es":
        prefix = cardinal(a, lang)
        prefix = prefix[:-3] + ("ún" if a % 100 == 21 else "un") if prefix.endswith("uno") else prefix
        lead = "mil" if a == 1 else prefix + " mil"
    elif lang == "it":
        lead = "mille" if a == 1 else cardinal(a, lang) + "mila"
    else:
        lead = "bin" if a == 1 else cardinal(a, lang) + " bin"
    return lead + (("" if lang in ("de", "it") else " ") + cardinal(b, lang) if b else "")


def spoken_token(raw, lang="en"):
    """Expand only a standalone number (optional decimal, grouping or percent).

    Brand names such as CoQ10 and B12 are intentionally untouched. Currency and
    dates are not guessed: their pronunciation depends on context.
    """
    lang = str(lang or "en").lower()[:2]
    value = str(raw).strip('.,!?;:()[]{}"“”«»')
    if lang not in UNITS or not re.fullmatch(r"\d+(?:[.,]\d+)*%?", value):
        return str(raw)
    percent = value.endswith("%")
    value = value.rstrip("%")
    decimal = "." if lang == "en" else ","
    grouping = "," if lang == "en" else "."
    if grouping in value:
        whole = value.split(decimal)[0]
        if not re.fullmatch(r"\d{1,3}(?:" + re.escape(grouping) + r"\d{3})+", whole):
            return str(raw)
        value = value.replace(grouping, "")
    parts = value.split(decimal)
    if len(parts) > 2 or len(parts[0]) > 6:
        return str(raw)
    result = cardinal(int(parts[0]), lang)
    if result is None:
        return str(raw)
    if len(parts) == 2:
        point = dict(en="point", fr="virgule", de="Komma", es="coma", it="virgola", tr="virgül")[lang]
        result += " " + point + " " + " ".join(UNITS[lang][int(c)] for c in parts[1])
    if percent:
        if lang == "tr":
            result = "yüzde " + result
        else:
            result += " " + dict(en="percent", fr="pour cent", de="Prozent", es="por ciento", it="per cento")[lang]
    return result


def detail_indices(words):
    """Extra local anchors only around numbers/compounds; keep other sweeps intact."""
    numeric_words = {x for values in list(UNITS.values()) + list(TENS.values()) for x in values}
    found = set()
    for i, word in enumerate(words):
        raw = str(word.get("w") or "").strip('.,!?;:()[]{}"“”«»').lower()
        if re.search(r"\d|[^\W\d_][-‐‑][^\W\d_]", raw) or raw in numeric_words:
            found.update(range(max(0, i-1), min(len(words), i+2)))
    return found
