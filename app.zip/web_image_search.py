"""Public Google/Yandex image result parsing and explicitly selected image downloads.

No API keys, account cookies, browser automation, CAPTCHA solving, substitute
engines, or model-created URLs. Provider HTML is data and is never executed.
"""
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urljoin, urlsplit, urlunsplit
import hashlib
import http.client
import io
import ipaddress
import json
import os
import queue
import re
import socket
import ssl
import threading
import time
import uuid
import warnings
import zlib

from PIL import Image, ImageOps
import stock_cancel

PROVIDERS = ('google', 'yandex')
LABELS = {'google': 'Google Images', 'yandex': 'Yandex Images'}
PAGE_SIZE = 24
MAX_RESULTS = 100
MIN_LONG = 800
MIN_SHORT = 400
MAX_BYTES = 40 * 1024 * 1024
MAX_PIXELS = 80_000_000
SEARCH_SECONDS = 25
DOWNLOAD_SECONDS = 90
MAX_HTML = 8 * 1024 * 1024
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
_FORMATS = {'JPEG': '.jpg', 'PNG': '.png', 'WEBP': '.webp'}
_MIMES = {'image/jpeg', 'image/png', 'image/webp'}
_REDIRECTS = (301, 302, 303, 307, 308)


class SearchError(ValueError):
    """Safe source-specific errors for the UI; never includes response bodies."""
    def __init__(self, provider, code='unavailable'):
        self.code = code
        name = LABELS.get(provider, 'Image search')
        suffix = {'blocked': ' requires verification. Automatic image search is unavailable right now.',
                  'timeout': ' search timed out. Try again.',
                  'changed': ' results could not be read. Try again later.',
                  'unavailable': ' could not complete this search. Try again.'}[code]
        super().__init__(name + suffix)


def _check(cancelled=None, deadline=None):
    stock_cancel.check()
    if cancelled and cancelled():
        raise stock_cancel.Cancelled()
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError('Image request timed out.')


def _url(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 8192 or re.search(r'[\x00-\x20\x7f\\]', value):
        raise ValueError('Choose a public image URL.')
    if value.startswith('//'):
        value = 'https:' + value
    try:
        p = urlsplit(value)
        host = (p.hostname or '').encode('idna').decode('ascii').lower().rstrip('.')
        port = p.port
        if p.scheme not in ('http', 'https') or p.username or p.password or port not in (None, 80 if p.scheme == 'http' else 443):
            raise ValueError()
        if not host or host.endswith(('.localhost', '.local', '.internal', '.test', '.invalid', '.home', '.lan')) or host == 'localhost':
            raise ValueError()
        try:
            ip = ipaddress.ip_address(host)
            if not ip.is_global or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
                raise ValueError('Private address')
        except ValueError as exc:
            if str(exc) == 'Private address' or '.' not in host or ':' in host:
                raise ValueError()
        # Reject integer/octal/hex IPv4 aliases accepted by some resolvers.
        if re.fullmatch(r'(?:0x[0-9a-f]+|[0-9.]+)', host, re.I):
            raise ValueError()
        netloc = '[' + host + ']' if ':' in host else host
        return urlunsplit((p.scheme, netloc, p.path or '/', p.query, ''))
    except (ValueError, UnicodeError):
        raise ValueError('Choose a public image URL.') from None


def _resolve(host, port, deadline, cancelled=None):
    # DNS may stall outside socket timeouts; a daemon resolver remains bounded for
    # the calling job. Connections below are pinned to the verified numeric IP.
    result = queue.Queue(maxsize=1)
    def resolve():
        try: result.put(socket.getaddrinfo(host, port, type=socket.SOCK_STREAM))
        except Exception as exc: result.put(exc)
    threading.Thread(target=resolve, daemon=True, name='public-image-dns').start()
    until = min(deadline, time.monotonic() + 5)
    while True:
        _check(cancelled, until)
        try: addresses = result.get(timeout=min(.1, max(.001, until-time.monotonic()))); break
        except queue.Empty: pass
    if isinstance(addresses, Exception):
        raise OSError('Image host is unavailable.')
    ips = list(dict.fromkeys(entry[4][0] for entry in addresses))
    if not ips or any(not ipaddress.ip_address(ip).is_global or ipaddress.ip_address(ip).is_multicast or ipaddress.ip_address(ip).is_reserved for ip in ips):
        raise ValueError('Private image addresses are not allowed.')
    return ips


def validate_url(value, resolve=True):
    """Validate public URL syntax and, by default, all resolved addresses."""
    value = _url(value)
    if resolve:
        p = urlsplit(value)
        _resolve(p.hostname, 443 if p.scheme == 'https' else 80, time.monotonic()+5)
    return value


def _fetch(url, *, limit, deadline, cancelled=None, allowed_host=None, progress=None, image=False):
    """No proxies/cookies; verify DNS and pin each redirect connection to that IP."""
    for redirect in range(6):
        _check(cancelled, deadline)
        url = _url(url); p = urlsplit(url); port = 443 if p.scheme == 'https' else 80
        if allowed_host and not allowed_host(p.hostname):
            raise ValueError('Unexpected image search redirect.')
        ips = _resolve(p.hostname, port, deadline, cancelled)
        conn = None; last = None
        for ip in ips[:2]:
            _check(cancelled, deadline)
            try:
                timeout = min(6, max(.1, deadline-time.monotonic()))
                sock = socket.create_connection((ip, port), timeout=timeout)
                try:
                    if p.scheme == 'https':
                        sock = ssl.create_default_context().wrap_socket(sock, server_hostname=p.hostname)
                    conn = (http.client.HTTPSConnection if p.scheme == 'https' else http.client.HTTPConnection)(p.hostname, port=port, timeout=timeout)
                    conn.sock = sock
                    conn.request('GET', urlunsplit(('', '', p.path or '/', p.query, '')),
                                 headers={'User-Agent': _UA, 'Accept': 'image/webp,image/png,image/jpeg;q=0.9,*/*;q=0.1' if image else 'text/html,application/xhtml+xml', 'Accept-Encoding': 'identity', 'Connection': 'close'})
                    response = conn.getresponse()
                    break
                except BaseException:
                    sock.close(); raise
            except (OSError, ssl.SSLError, http.client.HTTPException) as exc:
                if conn: conn.close()
                conn = None; last = exc
        if conn is None:
            raise OSError('Image host is unavailable.') from last
        try:
            if response.status in _REDIRECTS:
                if redirect == 5 or not response.getheader('Location'):
                    raise ValueError('Too many image redirects.')
                url = urljoin(url, response.getheader('Location')); continue
            if response.status in (401, 403, 429):
                raise PermissionError('Image request needs verification.')
            if response.status != 200:
                raise OSError('Image server did not return a usable response.')
            mime = (response.getheader('Content-Type') or '').split(';', 1)[0].strip().lower()
            if image and mime not in _MIMES:
                raise ValueError('This result is not a supported JPEG, PNG or WebP image.')
            if not image and mime not in ('text/html', 'application/xhtml+xml'):
                raise ValueError('Image search did not return a page.')
            size = response.getheader('Content-Length')
            if size and (not size.isdigit() or int(size) > limit):
                raise ValueError('The image response is too large.')
            encoding = (response.getheader('Content-Encoding') or '').lower()
            if encoding not in ('', 'identity', 'gzip', 'deflate'):
                raise ValueError('Unsupported image transfer encoding.')
            decoder = zlib.decompressobj(16+zlib.MAX_WBITS if encoding == 'gzip' else zlib.MAX_WBITS) if encoding in ('gzip', 'deflate') else None
            body = bytearray(); transferred = 0
            while True:
                _check(cancelled, deadline)
                if conn.sock: conn.sock.settimeout(min(5, max(.1, deadline-time.monotonic())))
                chunk = response.read(65536)
                if not chunk: break
                transferred += len(chunk)
                if transferred > limit: raise ValueError('The image response is too large.')
                chunk = decoder.decompress(chunk, limit-len(body)+1) if decoder else chunk
                body.extend(chunk)
                if len(body) > limit or (decoder and decoder.unconsumed_tail):
                    raise ValueError('The image response is too large.')
                if progress: progress(transferred, int(size) if size and size.isdigit() else None)
            if decoder:
                body.extend(decoder.flush(limit-len(body)+1))
                if len(body) > limit or not decoder.eof: raise ValueError('The image response is incomplete.')
            _check(cancelled, deadline)
            return bytes(body), mime, url
        finally:
            conn.close()
    raise ValueError('Too many image redirects.')


def _walk(value):
    pending = [(value, 0)]; count = 0
    while pending:
        node, depth = pending.pop(); count += 1
        if count > 200000 or depth > 60: continue
        yield node
        if isinstance(node, dict): pending.extend((v, depth+1) for v in reversed(list(node.values())))
        elif isinstance(node, list): pending.extend((v, depth+1) for v in reversed(node))


class _Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.blobs=[]; self.links=[]; self.script=None; self.anchor=None; self.meta=None
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        for key in ('data-state', 'data-bem'):
            if a.get(key):
                try: self.blobs.append(json.loads(a[key]))
                except (ValueError, RecursionError): pass
        if tag == 'script': self.script=[]
        if tag == 'a': self.anchor=dict(a, text='', thumbnail='')
        if tag == 'img' and self.anchor:
            self.anchor['thumbnail']=a.get('data-src') or a.get('src') or ''; self.anchor['alt']=a.get('alt','')
        if 'rg_meta' in a.get('class', '').split(): self.meta=[]
    def handle_data(self, data):
        if self.script is not None: self.script.append(data)
        if self.anchor is not None: self.anchor['text'] += data
        if self.meta is not None: self.meta.append(data)
    def handle_endtag(self, tag):
        if tag == 'script' and self.script is not None:
            script=''.join(self.script); self.script=None
            # Decode JSON values, never JavaScript, function bodies or eval.
            for match in list(re.finditer(r'\bdata\s*:\s*(?:function\s*\(\)\s*\{\s*return\s*)?(?=[\[{])', script))[:20]:
                try: self.blobs.append(json.JSONDecoder().raw_decode(script, match.end())[0])
                except (ValueError, RecursionError): pass
            for match in list(re.finditer(r'\[(?:null|0|1)\s*,\s*"[^"\n]{1,200}"\s*,\s*\[\s*"https?[^"\n]{1,8192}"\s*,\s*\d+\s*,\s*\d+\s*\]\s*,\s*\[', script))[:300]:
                try: self.blobs.append(json.JSONDecoder().raw_decode(script, match.start())[0])
                except (ValueError, RecursionError): pass
        if tag == 'a' and self.anchor is not None:
            self.links.append(self.anchor); self.anchor=None
        if tag == 'div' and self.meta is not None:
            try: self.blobs.append(json.loads(''.join(self.meta)))
            except (ValueError, RecursionError): pass
            self.meta=None


def _dimensions(w, h):
    try: w, h = int(w), int(h)
    except (ValueError, TypeError, OverflowError): return None
    return (w, h) if w > 0 and h > 0 and w*h <= MAX_PIXELS else None


def _large(w, h):
    return max(w, h) >= MIN_LONG and min(w, h) >= MIN_SHORT


def _item(provider, image, page, thumbnail, width, height, title):
    dims = _dimensions(width, height)
    if not dims: return None
    try: image, page = _url(image), _url(page)
    except ValueError: return None
    try: thumbnail = _url(thumbnail)
    except ValueError: thumbnail = ''
    # Source pages must come from the actual result, never an invented filename link.
    ident = hashlib.sha256(image.encode('utf8')).hexdigest()
    title = re.sub('<[^>]*>', '', unescape(str(title or ''))).strip()[:250] or urlsplit(page).hostname
    return dict(id=provider+'-'+ident[:24], provider=provider, type='image', title=title,
                url=page, asset_id=ident, preview=thumbnail, thumbnail=thumbnail,
                image_url=image, width=dims[0], height=dims[1], dimensions_verified=False,
                aspect_ratio=dims[0]/dims[1], orientation='landscape' if dims[0]>dims[1] else 'portrait' if dims[0]<dims[1] else 'square')


def _triple(v):
    return isinstance(v, list) and len(v) >= 3 and isinstance(v[0], str) and _dimensions(v[2], v[1])


def parse_results(provider, html):
    """Return observed result metadata only; no network, URL synthesis or eval."""
    if provider not in PROVIDERS: raise ValueError('Choose Google Images or Yandex Images.')
    p = _Page(); p.feed(html); rows=[]; seen=set()
    def add(row):
        if row and row['image_url'] not in seen:
            seen.add(row['image_url']); rows.append(row)
    for blob in p.blobs:
        for node in _walk(blob):
            if provider == 'yandex' and isinstance(node, dict):
                if node.get('origUrl'):
                    meta=node.get('snippet') or {}; view=node.get('viewerData') or {}
                    add(_item(provider, node['origUrl'], meta.get('url'), node.get('image') or (view.get('thumb') or {}).get('url'),
                              node.get('origWidth') or node.get('width'), node.get('origHeight') or node.get('height'), meta.get('title') or node.get('alt')))
                elif isinstance(node.get('serp-item'), dict):
                    item=node['serp-item']; orig=item.get('img_href'); meta=item.get('snippet') or {}; candidates=item.get('preview') or []
                    original=next((x for x in candidates if x.get('url')==orig), {})
                    add(_item(provider, orig, meta.get('url'), (item.get('thumb') or {}).get('url'), original.get('w'), original.get('h'), meta.get('title')))
            if provider == 'google' and isinstance(node, dict) and node.get('ou'):
                add(_item(provider, node['ou'], node.get('ru'), node.get('tu'), node.get('ow'), node.get('oh'), node.get('pt')))
            if provider == 'google' and isinstance(node, list) and len(node) > 3 and isinstance(node[1], str) and _triple(node[2]) and _triple(node[3]):
                thumb, orig = node[2], node[3]
                for meta in _walk(node[4:]):
                    if not isinstance(meta, dict): continue
                    info=meta.get('2003') or meta.get(2003)
                    if isinstance(info, list) and len(info) > 2:
                        add(_item(provider, orig[0], info[1], thumb[0], orig[2], orig[1], info[2])); break
    if provider == 'google':
        for link in p.links:
            parsed=urlsplit(link.get('href') or '')
            if parsed.path != '/imgres': continue
            q=parse_qs(parsed.query)
            add(_item(provider, q.get('imgurl',[''])[0], q.get('imgrefurl',[''])[0], link.get('thumbnail'),
                      q.get('w',[0])[0], q.get('h',[0])[0], link.get('alt') or link.get('text')))
    return rows


def search_url(provider, query, page=1):
    if provider == 'google':
        return 'https://www.google.com/search?' + urlencode(dict(udm=2, q=query, start=(page-1)*PAGE_SIZE, num=PAGE_SIZE, safe='active'))
    if provider == 'yandex':
        return 'https://yandex.com/images/search?' + urlencode(dict(text=query, p=page-1, numdoc=PAGE_SIZE))
    raise ValueError('Choose Google Images or Yandex Images.')


def _search_host(provider, host):
    if provider == 'google': return host in ('www.google.com', 'google.com', 'images.google.com', 'consent.google.com')
    return host in ('yandex.com', 'yandex.ru', 'yandex.com.tr', 'yandex.by', 'yandex.kz', 'yandex.uz') or host in ('www.yandex.com', 'www.yandex.ru', 'www.yandex.com.tr')


def _aspect(item, aspect):
    if aspect in ('any', 'portrait-first', None): return True
    ratio = item['width']/item['height']
    if aspect in ('landscape', 'portrait'): return ratio > 1 if aspect == 'landscape' else ratio < 1
    if aspect in ('16:9', '9:16', '1:1'): return abs(ratio-{'16:9':16/9, '9:16':9/16, '1:1':1}[aspect]) <= .01
    raise ValueError('Choose a valid image orientation.')


def search(provider, query, page=1, aspect='any', cancelled=None):
    if provider not in PROVIDERS: raise ValueError('Choose Google Images or Yandex Images.')
    if not isinstance(query, str) or not query.strip(): raise ValueError('Enter image search words.')
    if type(page) is not int or not 1 <= page <= 1000: raise ValueError('Choose a valid image results page.')
    _check(cancelled); url=search_url(provider, query.strip()[:160], page)
    try:
        body, mime, final = _fetch(url, limit=MAX_HTML, deadline=time.monotonic()+SEARCH_SECONDS, cancelled=cancelled, allowed_host=lambda host:_search_host(provider, host))
        text=body.decode('utf8', errors='replace')
        if re.search(r'(?i)(?:/sorry/|showcaptcha|/checkcaptcha|consent\.google\.)', final) or re.search(r'(?i)(?:unusual traffic from your computer|g-recaptcha|smartcaptcha|confirm you are not a robot|before you continue to google)', text):
            raise SearchError(provider, 'blocked')
        raw=parse_results(provider, text)
        if not raw and not re.search(r'(?i)(?:did not match any|no images found|no results found|ничего не найдено|görsel bulunamadı|sonuç bulunamadı)', text):
            raise SearchError(provider, 'changed')
        rows=[item for item in raw if _large(item['width'],item['height']) and _aspect(item,aspect)]
        # num/numdoc is advisory. Preserve a provider's native page (Yandex
        # commonly sends 30) so advancing to its next page cannot drop six rows.
        return dict(items=rows[:MAX_RESULTS], warnings=[], page=page, has_more=len(raw)>=PAGE_SIZE,
                    search_url=url, minimum_dimensions=dict(longest=MIN_LONG, shortest=MIN_SHORT))
    except SearchError: raise
    except (TimeoutError, socket.timeout): raise SearchError(provider, 'timeout') from None
    except PermissionError: raise SearchError(provider, 'blocked') from None
    except (OSError, ValueError, http.client.HTTPException): raise SearchError(provider, 'unavailable') from None


def validate_item(item):
    if not isinstance(item, dict) or item.get('provider') not in PROVIDERS or item.get('type') != 'image':
        raise ValueError('Choose an image from these search results.')
    result=_item(item['provider'], item.get('image_url'), item.get('url'), item.get('thumbnail') or item.get('preview'), item.get('width'), item.get('height'), item.get('title'))
    if not result or not _large(result['width'],result['height']):
        raise ValueError('Choose a medium or large image.')
    return result


def download(item, target_dir, cancelled=None, progress=None):
    """Download only the selected original; never substitute its thumbnail.

    Static JPEG/PNG/WebP bytes are preserved, except EXIF-rotated images are
    losslessly oriented into PNG so browser, FFmpeg and XML agree.
    """
    item=validate_item(item); _check(cancelled)
    try:
        raw, mime, final = _fetch(item['image_url'], limit=MAX_BYTES, deadline=time.monotonic()+DOWNLOAD_SECONDS,
                                  cancelled=cancelled, progress=progress, image=True)
    except PermissionError: raise ValueError('The original image requires website access. Choose another result.') from None
    except (OSError, http.client.HTTPException): raise ValueError('The original image could not be downloaded. Choose another result.') from None
    _check(cancelled)
    with warnings.catch_warnings():
        warnings.simplefilter('error', Image.DecompressionBombWarning)
        try:
            with Image.open(io.BytesIO(raw)) as image:
                fmt=image.format; dims=_dimensions(*image.size)
                if fmt not in _FORMATS or not dims or getattr(image, 'is_animated', False):
                    raise ValueError('Choose a static JPEG, PNG or WebP image under 80 megapixels.')
                if not _large(*dims): raise ValueError('The original image is too small. Choose another result.')
                image.verify()
            with Image.open(io.BytesIO(raw)) as image:
                orientation=image.getexif().get(274, 1)
                if orientation in (5,6,7,8): dims=dims[::-1]
                image.load()
                if orientation not in (None,1):
                    oriented=ImageOps.exif_transpose(image); output=io.BytesIO();oriented.save(output,format='PNG');raw=output.getvalue();fmt='PNG'
            if len(raw)>MAX_BYTES: raise ValueError('The full-resolution image is larger than 40 MB.')
        except (Image.DecompressionBombError, Image.DecompressionBombWarning):
            raise ValueError('Choose an image under 80 megapixels.') from None
        except (OSError, SyntaxError):
            raise ValueError('The original image is incomplete or unsupported. Choose another result.') from None
    _check(cancelled)
    directory=Path(target_dir);directory.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(raw).hexdigest();target=directory/('image-'+digest[:24]+_FORMATS[fmt]);part=directory/('.image-'+uuid.uuid4().hex+'.part')
    try:
        with part.open('xb') as handle: handle.write(raw);handle.flush();os.fsync(handle.fileno())
        _check(cancelled);os.replace(part,target)
    finally: part.unlink(missing_ok=True)
    return dict(path=target,width=dims[0],height=dims[1],content_sha256=digest,image_url=item['image_url'],
                resolved_image_url=final,dimensions_verified=True,format=fmt)
