"""Offline OCR of finished-video frames using the installed Windows OCR engine."""
import json
import math
from pathlib import Path
import shutil
import subprocess
import threading
import subtitle_ost


def scan(video, directory, captions, language, encode, progress, cancelled):
    frames=directory/'frames';frames.mkdir(parents=True,exist_ok=False)
    duration=float(video['duration']);fps=2
    try:
        progress.update('Sampling Video For On-Screen Text',0,duration,'seconds')
        encode(['-i',video['path'],'-an','-vf',r'fps=2,scale=w=min(1280\,iw):h=-2','-q:v','4',str(frames/'%06d.jpg')],duration,
               lambda a,b:progress.update('Sampling Video For On-Screen Text',a,b,'seconds'),cancelled,directory/'sampling.log')
        files=list(frames.glob('*.jpg'));total=len(files)
        if not total:raise ValueError('No readable video frames were found.')
        command=['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(Path(__file__).with_suffix('.ps1')),
                 '-FramesDir',str(frames.resolve()),'-Language',language]
        rows=[];engine=None
        with (directory/'ocr.log').open('wb') as log:
            proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=log,text=True,encoding='utf8',errors='replace',creationflags=0x08000000)
            done=threading.Event()
            def cancel_watch():
                while not done.wait(.15):
                    if cancelled():proc.kill();return
            threading.Thread(target=cancel_watch,daemon=True).start()
            try:
                for line in proc.stdout:
                    try:row=json.loads(line)
                    except ValueError:continue
                    rows.append(row);engine=row.get('language')
                    progress.update('Reading On-Screen Text',len(rows),total,'frames')
                rc=proc.wait()
                if cancelled():raise ValueError('Cancelled')
                if rc or len(rows)!=total:
                    raise ValueError('Windows text recognition could not finish. Check that a recognition language is installed in Windows Language settings.')
            finally:
                done.set()
                if proc.poll() is None:proc.kill()
                proc.wait();proc.stdout.close()
        windows=[];recent={}
        for row in rows:
            time=(int(Path(row['file']).stem)-1)/fps
            for line in row.get('lines',[]):
                # A Turkish Windows fallback can read Latin i as dotless ı.
                if not language.lower().startswith('tr'):line=line.replace('ı','i')
                key=' '.join(subtitle_ost.tokens(line))
                if not key:continue
                previous=recent.get(key)
                if previous and time-previous['last']<=1.01:
                    previous.update(end=min(duration,time+.25),last=time)
                else:
                    previous=dict(text=line,start=max(0,time-.25),end=min(duration,time+.25),last=time)
                    windows.append(previous);recent[key]=previous
        matches=[]
        for w in windows:
            if any(changed for _,changed in subtitle_ost.parts(captions,[w])):
                matches.append({k:w[k] for k in ('text','start','end')})
        return matches,engine
    finally:
        # Only this job's sampled copies, never uploaded media.
        if frames.is_dir() and not frames.is_symlink() and frames.resolve().parent==directory.resolve():shutil.rmtree(frames)
