# -*- coding: utf-8 -*-
"""Required model assets that are NOT shipped with the app (too large for the update repo) and are
fetched once on first launch, with a real % progress bar in the UI.

Add a new entry to ASSETS and the whole download / progress flow works for it — no UI changes needed.

Contract used by app.py:
    status()            -> [{key, name, why, size, ready, have}]   (bytes)
    missing()           -> the subset that still needs downloading
    start_fetch()       -> job id (downloads every missing asset in a background thread)
    job(job_id)         -> {status: idle|running|done|error, pct, step, error}
"""
import os, json, time, threading, urllib.request, shutil
from pathlib import Path

_UA = "VSLDashboard/1.0 (+model-fetch)"


def _torch_hub_dir() -> Path:
    """torch.hub.get_dir() WITHOUT importing torch (import costs seconds at boot)."""
    th = os.environ.get("TORCH_HOME")
    if th:
        return Path(th) / "hub"
    xdg = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg) if xdg else (Path.home() / ".cache")
    return base / "torch" / "hub"


# MMS-FA (Meta multilingual CTC forced aligner). torchaudio saves it under the URL basename.
_MMS_URL = "https://dl.fbaipublicfiles.com/mms/torchaudio/ctc_alignment_mling_uroman/model.pt"

ASSETS = [
    {
        "key": "mms_fa",
        "name": "Speech Alignment Model",
        "why": "Word-accurate subtitle and karaoke timing",
        "url": _MMS_URL,
        "size": 1262000000,                       # ~1.18 GB, for the progress bar before headers arrive
        "path": lambda: _torch_hub_dir() / "checkpoints" / "model.pt",
        "min_size": 1_000_000_000,                # a smaller file on disk = truncated download
    },
]

_JOBS = {}
_LOCK = threading.Lock()


def _entry_state(a):
    p = a["path"]()
    have = p.stat().st_size if p.exists() else 0
    return {"key": a["key"], "name": a["name"], "why": a["why"],
            "size": a["size"], "have": have,
            "ready": have >= a.get("min_size", 1)}


def status():
    return [_entry_state(a) for a in ASSETS]


def missing():
    return [a for a in ASSETS if not _entry_state(a)["ready"]]


def ready() -> bool:
    return not missing()


def _download(a, on_pct):
    """Stream one asset to its cache path. Writes to .part then renames, so a killed download never
    leaves a half file that later looks 'ready'."""
    dest = a["path"]()
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(a["url"], headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        total = int(r.headers.get("Content-Length") or a["size"] or 0)
        done = 0
        last = 0.0
        with open(part, "wb") as f:
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                now = time.time()
                if now - last > 0.20:
                    last = now
                    on_pct(done, total)
        on_pct(done, total)
    if total and done < total * 0.98:
        try:
            part.unlink()
        except OSError:
            pass
        raise RuntimeError("download incomplete (%d of %d bytes)" % (done, total))
    if dest.exists():
        try:
            dest.unlink()
        except OSError:
            pass
    shutil.move(str(part), str(dest))


def _run(jid):
    j = _JOBS[jid]
    todo = missing()
    if not todo:
        with _LOCK:
            j.update(status="done", pct=100, step="Everything is up to date")
        return
    n = len(todo)
    for i, a in enumerate(todo):
        mb = a["size"] / 1048576.0
        label = "Downloading %s (%.0f MB) - %s" % (a["name"], mb, a["why"])

        def on_pct(done, total, _i=i, _label=label):
            frac = (done / total) if total else 0.0
            with _LOCK:
                j.update(status="running",
                         pct=int(((_i + min(1.0, frac)) / n) * 100),
                         step="%s  %.0f%%" % (_label, min(1.0, frac) * 100))
        with _LOCK:
            j.update(status="running", pct=int((i / n) * 100), step=label)
        try:
            _download(a, on_pct)
        except Exception as e:
            with _LOCK:
                j.update(status="error", error="%s: %s" % (a["name"], e))
            return
    with _LOCK:
        j.update(status="done", pct=100, step="Ready")


def start_fetch():
    jid = "assets-%d" % int(time.time() * 1000)
    with _LOCK:
        _JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting…", "error": None}
    threading.Thread(target=_run, args=(jid,), daemon=True).start()
    return jid


def job(jid):
    with _LOCK:
        j = _JOBS.get(jid)
        return dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""}
