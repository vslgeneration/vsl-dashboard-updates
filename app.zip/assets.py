# -*- coding: utf-8 -*-
"""Required model assets that are NOT shipped with the app (too large for the update repo) and are
fetched once on first launch, with a real % progress bar in the UI.

Add a new entry to ASSETS and the whole download / progress flow works for it — no UI changes needed.

Contract used by app.py:
    status()            -> [{key, name, why, size, ready, have}]   (bytes)
    missing()           -> the subset that still needs downloading
    start_fetch()       -> job id (downloads every missing asset in a background thread)
    job(job_id)         -> {status: idle|running|done|error, pct, step, error}
"""
import os, json, time, threading, urllib.request, shutil, hashlib, uuid
from pathlib import Path

_UA = "VSLDashboard/1.0 (+model-fetch)"


def _torch_hub_dir() -> Path:
    """torch.hub.get_dir() WITHOUT importing torch (import costs seconds at boot)."""
    th = os.environ.get("TORCH_HOME")
    if th:
        return Path(th) / "hub"
    xdg = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg) if xdg else (Path.home() / ".cache")
    return base / "torch" / "hub"


# MMS-FA (Meta multilingual CTC forced aligner). torchaudio saves it under the URL basename.
_MMS_URL = "https://dl.fbaipublicfiles.com/mms/torchaudio/ctc_alignment_mling_uroman/model.pt"


def ytdlp_path():
    return Path(__file__).resolve().parent / 'tools' / 'yt-dlp.exe'


def _ytdlp_available():
    import youtube
    return bool(youtube.ytdlp_exe())

CURATED_MUSIC = [{'path': 'Corporate/331_upbeat-corporate_main-01_full.mp3', 'bytes': 7254117, 'sha256': '4ffa9b8830459dd5c26898af946a3796d55263945e95407823c3860e879ba853'}, {'path': 'Corporate/corporate_1.mp3', 'bytes': 7143286, 'sha256': '71d251b834cec1c7cfcbd5c7c0db73368410cc029cfa5a5a3a0329ce276e5a56'}, {'path': 'Corporate/Discovery.mp3', 'bytes': 7252875, 'sha256': '8d1d6f4b7ba222122a33a0e5a3fc65b4bff6af256cac22176896c487babf7659'}, {'path': 'Corporate/Presentation Background Inspiring Music (Without Acoustic Guitar).mp3', 'bytes': 7334714, 'sha256': '27c3486b56d5a32228da5c0509394547e98b43c33593313a73f5e9cda75ce5b3'}, {'path': 'Corporate/The Promotion.mp3', 'bytes': 7287356, 'sha256': 'ac2d82d8a8463ef2463ada64252ffffdf1ea93b2436fb07848c20bd36904efbb'}, {'path': 'Documentary/Main (1-37).mp3', 'bytes': 7285289, 'sha256': '822200b35d07aa688a973d795e4480ab2f70e359b89d3f7b095aff74e872b689'}, {'path': 'Documentary/That Documentary.mp3', 'bytes': 7240425, 'sha256': '0adfa1e25be2bc460a2b58cf8acf55018b63d7aca5ec6a068d4dc6272923ed2c'}, {'path': 'Dramatic/dramatic_1.mp3', 'bytes': 7272109, 'sha256': 'e4b33a6524589a95b1d0253a342bc7a6aa3bbe1a4c6bd5697e9cbab1511c86b9'}, {'path': 'Dramatic/dramatic_2.mp3', 'bytes': 7228970, 'sha256': '852bf0c26ebecc9af568d8de368124920a43123caa3120ce2b423dacc5dd563f'}, {'path': 'Dramatic/Emotional & Dramatical Pr.mp3', 'bytes': 7294129, 'sha256': '349e57b55d61c63353d58f5f4a72f6686ed7354aef769be84a2d99542ac780e6'}, {'path': 'Dramatic/emotional cinematic main.mp3', 'bytes': 7236828, 'sha256': '066e743d8424b9c1b89eb34fbe784678517316444ec7fd86e1651868fd2084b9'}, {'path': 'Dramatic/Hopeless Cinematic.mp3', 'bytes': 7234414, 'sha256': '78bd8c59979fe740997365607ede26a000d765721e6c3edb7f0325881ec71f50'}, {'path': 'Dramatic/Main (2-27).mp3', 'bytes': 7297327, 'sha256': 'd701bfe3f03bbb23b1c19adf749bd6355e23f04b2c10dbfbd1b7ce32edbec183'}, {'path': 'Fear/Drama Suspense Cinematic.mp3', 'bytes': 7292701, 'sha256': 'f9bd2bd7ffba9930239dc335eed2113ccd6b486ea72d21f18b5d1eb0bd005e91'}, {'path': 'Fear/Insidious Dramatic Tension 60s.mp3', 'bytes': 7169000, 'sha256': 'ae0c82167e29b3ac3d6e06e0212c6f6ab968d7ba516f32c2d165c895a9ee666f'}, {'path': 'Fear/The Science.mp3', 'bytes': 7321581, 'sha256': 'fe105341f1372b7a62321f2b89f3fb5c2d889424fba2088215427d3446c8ad1d'}, {'path': 'Fear/The Suspense.mp3', 'bytes': 7341456, 'sha256': '56f6817f8dc0a8e448dad22a15f4231dd69b03effc63ab1afd2723fdba8193e8'}, {'path': 'Fear Hook/hook_1.mp3', 'bytes': 7244789, 'sha256': 'cdb08c2e5fb2a52085f40b43c32041fde68834bed0874a943c28ac09ef8d85df'}, {'path': 'Inspirational/Epic Inspirational Promo.mp3', 'bytes': 7367933, 'sha256': '094d294779f6b2355fc18533f51b535aa84a97b3d34e0ce9e298e030ba8fcc40'}, {'path': 'Inspirational/Full.mp3', 'bytes': 7284752, 'sha256': 'e2ea5128eebc5f7386adea589f0c8b3084bb6b1017d9e1e765854335639cefed'}, {'path': 'Inspirational/Long.mp3', 'bytes': 7290341, 'sha256': '643f93e0135b780efe892f484e59193532df9670308372604a3b7f6fd342d1ae'}, {'path': 'Inspirational/Main.mp3', 'bytes': 7304407, 'sha256': '88b59ba79ea42b157579fd8da779d85e6d20ebda8f33090f2519693410b7a959'}, {'path': 'Inspirational/Main3.mp3', 'bytes': 7232700, 'sha256': '64e05840c322365376dc6b30a11e6bc6ff7d06b82b06e395f1ab09afc3a039c3'}, {'path': 'Mysterious Hook/hook_2.mp3', 'bytes': 6899627, 'sha256': 'fa9afbcf6304d98cd0152cc2c3a34e28d3418239909a5e6ffefffd4308972d5f'}, {'path': 'Mysterious Hook/mysterious cinematic.mp3', 'bytes': 7104670, 'sha256': '4f43be22ff15895f3eca63bb85a874eb680be6aa7aab73f5d5fdb985f18f0e8e'}, {'path': 'Scientific/1.mp3', 'bytes': 7262054, 'sha256': '5422e6248e359c10a38f487ad1563bd4c25ad40c7de5180c9dd02a5cff7c8792'}, {'path': 'Scientific/chill.mp3', 'bytes': 7233501, 'sha256': '2f7de8293e19ab00c78d123e827042c38b47749434b7ce89184f90ec5107008f'}, {'path': 'Scientific/Documentary Ambient Background.mp3', 'bytes': 7210216, 'sha256': '1ba9c100f8e821691fbc023e990d7cdb9ad7e0bbf04f31a06eaea46b0b276068'}, {'path': 'Scientific/Main (1-43).mp3', 'bytes': 6897193, 'sha256': '1170b04847e8ab2a7fa3fc9a675750ae3fc3e984272af7b8350ef48aa0d3eadc'}, {'path': 'Scientific/Main File (mp3_320).mp3', 'bytes': 7030563, 'sha256': '547739f6e7244d0884bdeb451d8e5a47bc98a5841612f87f4f049cdc84577eff'}]

def _music_root():
    # This historical directory name is retained so existing music plans keep working.
    import app
    return app.BGM_ROOT

def _music_receipt():
    return _music_root()/'.curated-library-v1.json'

def _music_available():
    # Once installed, respect the user's later curation/deletions instead of restoring them.
    try:
        if json.loads(_music_receipt().read_text('utf8')).get('version')==1:return True
    except (OSError,ValueError):pass
    return all((_music_root()/r['path']).is_file() for r in CURATED_MUSIC)

def _install_music(archive):
    import zipfile,tempfile
    root=_music_root();root.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        expected={'data/Suno Music/'+r['path']:r for r in CURATED_MUSIC}
        names=z.namelist()
        if len(names)!=len(set(names)) or set(names)-set(expected)-{'READ ME.txt'}:
            raise ValueError('Unexpected music package contents')
        if not set(expected).issubset(names):raise ValueError('Incomplete music package')
        # Validate the entire archive before copying even the first track.
        for name,row in expected.items():
            data=z.read(name)
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('Music file verification failed')
        added=0
        for name,row in expected.items():
            dest=root/row['path']
            if not dest.resolve().is_relative_to(root.resolve()):raise ValueError('Invalid music destination')
            if dest.exists():continue # Never replace locally edited/curated music.
            dest.parent.mkdir(parents=True,exist_ok=True)
            fd,raw=tempfile.mkstemp(prefix='.music-',suffix='.part',dir=dest.parent)
            temp=Path(raw)
            try:
                with os.fdopen(fd,'wb') as f:f.write(z.read(name))
                # Windows rename refuses to overwrite a file created meanwhile.
                try:
                    if os.name=='nt':os.rename(temp,dest)
                    else:os.link(temp,dest)
                    added+=1
                except FileExistsError:pass
            finally:temp.unlink(missing_ok=True)
    receipt=_music_receipt();temp=receipt.with_name(receipt.name+'.'+uuid.uuid4().hex+'.part')
    try:
        temp.write_text(json.dumps(dict(version=1,files=len(CURATED_MUSIC),added=added)),'utf8')
        os.replace(temp,receipt)
    finally:temp.unlink(missing_ok=True)

ASSETS = [
    {**{'key': 'curated_music', 'name': 'Curated Music Library', 'why': 'The 30 selected background tracks; no Suno generation or starter music', 'url': 'https://github.com/vslgeneration/vsl-dashboard-updates/releases/download/music-library-v1/AI-Dashboard-Music-Library.zip', 'size': 216854953, 'min_size': 216854953, 'sha256': 'bc894778eb834c2b1da5fd58679ad416607bf4baa40eb14812a548866ea4d64f'}, 'path': lambda:_music_root()/'.library-download.zip', 'available':_music_available, 'install':_install_music},
    {
        'key':'ytdlp', 'name':'YouTube Search Helper',
        'why':'YouTube topic-search fallback',
        'url':'https://github.com/yt-dlp/yt-dlp/releases/download/2026.08.19/yt-dlp.exe',
        'size':17840399, 'min_size':17840399,
        'sha256':'66674953fe251b89f4d08c5f0e35e0728679bd67ab3d7d05c0562af101dd3e7a',
        'path':ytdlp_path, 'available':_ytdlp_available,
    },
    {
        "key": "mms_fa",
        "name": "Speech Alignment Model",
        "why": "Word-accurate subtitle and karaoke timing",
        "url": _MMS_URL,
        "size": 1262000000,                       # approximate display size; progress requires actual response headers
        "path": lambda: _torch_hub_dir() / "checkpoints" / "model.pt",
        "min_size": 1_000_000_000,                # a smaller file on disk = truncated download
    },
]

ASSETS.sort(key=lambda a: 0 if a['key']=='ytdlp' else 1)

_JOBS = {}
_LOCK = threading.Lock()


def _entry_state(a):
    p = a["path"]()
    have = p.stat().st_size if p.exists() else 0
    return {"key": a["key"], "name": a["name"], "why": a["why"],
            "size": a["size"], "have": have,
            "ready": bool(a['available']()) if a.get('available') else have >= a.get("min_size", 1)}


def status():
    return [_entry_state(a) for a in ASSETS]


def missing():
    return [a for a in ASSETS if not _entry_state(a)["ready"]]


def ready() -> bool:
    return not missing()


def _download(a, on_pct):
    """Stream one asset to its cache path. Writes to .part then renames, so a killed download never
    leaves a half file that later looks 'ready'."""
    dest = a["path"]()
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name+'.'+uuid.uuid4().hex+'.part')
    try:
        req = urllib.request.Request(a["url"], headers={"User-Agent": _UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            measured_total = int(r.headers.get("Content-Length") or 0)
            total = measured_total or a["size"] or 0
            done = 0
            last = 0.0
            with open(part, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    now = time.time()
                    if now - last > 0.20:
                        last = now
                        on_pct(done, measured_total)
            on_pct(done, measured_total)
        if total and done < total * 0.98:
            try:
                part.unlink()
            except OSError:
                pass
            raise RuntimeError("download incomplete (%d of %d bytes)" % (done, total))
        if a.get('sha256') and hashlib.sha256(part.read_bytes()).hexdigest()!=a['sha256']:
            part.unlink(missing_ok=True)
            raise RuntimeError('Download verification failed; the existing helper was kept.')
        if a.get('install'):
            try:a['install'](part)
            finally:part.unlink(missing_ok=True)
        else:os.replace(part, dest)

    finally:
        part.unlink(missing_ok=True)


def _run(jid):
    j = _JOBS[jid]
    todo = missing()
    if not todo:
        with _LOCK:
            j.update(status="done", pct=100, step="Everything is up to date")
        return
    n = len(todo)
    for i, a in enumerate(todo):
        mb = a["size"] / 1048576.0
        label = "Downloading %s (%.0f MB) - %s" % (a["name"], mb, a["why"])

        def on_pct(done, total, _i=i, _label=label):
            frac = (done / total) if total else None
            with _LOCK:
                j.update(status="running",
                         pct=min(99,int(frac*100)) if frac is not None else None,
                         step="%s · File %d/%d · %.1f MB Received" % (_label, _i+1, n, done/1048576))
        with _LOCK:
            j.update(status="running", pct=None, step=label)
        try:
            _download(a, on_pct)
        except Exception as e:
            with _LOCK:
                j.update(status="error", error="%s: %s" % (a["name"], e))
            return
    with _LOCK:
        j.update(status="done", pct=100, step="Ready")


def start_fetch():
    jid = "assets-%d" % int(time.time() * 1000)
    with _LOCK:
        for existing, state in _JOBS.items():
            if state.get('status')=='running':return existing
        _JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting…", "error": None}
    threading.Thread(target=_run, args=(jid,), daemon=True).start()
    return jid


def job(jid):
    with _LOCK:
        j = _JOBS.get(jid)
        return dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""}
