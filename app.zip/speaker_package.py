"""Portable, deterministic speaker edits. No inference or remote media access.

The imported master audio and source frame ranges are immutable. Generated
visuals can change without changing this editorial clock.
"""
import copy
import hashlib
import json
import re
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from xml.etree import ElementTree as ET

SCHEMA = 'vsl-speaker-package-v1'
MAX_BYTES = 6 * 1024**3
class PackageError(ValueError):
    pass

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def normalized(text):
    return ' '.join(str(text or '').split())

def locked(scene):
    return bool(scene.get('speaker_clip'))

def local(root, rel):
    if not isinstance(rel, str) or not re.fullmatch(r'[A-Za-z0-9_./-]+', rel):
        raise PackageError('Invalid speaker asset path.')
    p = PurePosixPath(rel)
    if p.is_absolute() or '..' in p.parts or '\\' in rel:
        raise PackageError('Invalid speaker asset path.')
    out = (Path(root) / rel).resolve()
    if not out.is_relative_to(Path(root).resolve()):
        raise PackageError('Speaker asset is outside its project.')
    return out

def validate(m):
    if not isinstance(m, dict) or m.get('schema') != SCHEMA:
        raise PackageError('Not a supported speaker video package.')
    fps, duration = m.get('fps'), m.get('duration_frames')
    if type(fps) is not int or fps not in (24,25,30,50,60) or type(duration) is not int or not 0 < duration <= fps*14400:
        raise PackageError('Invalid package frame rate or duration.')
    assets = m.get('assets')
    if not isinstance(assets, dict) or not 1 <= len(assets) <= 500:
        raise PackageError('Invalid package media list.')
    for rel, sha in assets.items():
        local(Path(tempfile.gettempdir()), rel)
        if not re.fullmatch(r'[a-f0-9]{64}', str(sha)) or Path(rel).suffix not in ('.mp3','.mp4'):
            raise PackageError('Invalid package media hash or type.')
    if m.get('voiceover') not in assets or not m['voiceover'].endswith('.mp3'):
        raise PackageError('The master MP3 is missing.')
    rows = m.get('sentences')
    if not isinstance(rows,list) or not 1 <= len(rows) <= 10000:
        raise PackageError('Invalid sentence map.')
    prev = 0
    for row in rows:
        a,b = row.get('start_frame'),row.get('end_frame')
        if type(a) is not int or type(b) is not int or a != prev or not a < b <= duration or not isinstance(row.get('text'),str) or not row['text'].strip():
            raise PackageError('Sentence timing must cover the master audio continuously.')
        prev=b
    if prev != duration: raise PackageError('Sentence timing does not reach the end of the recording.')
    prev=0
    for c in m.get('clips',[]):
        a,b,i,o = [c.get(k) for k in ('start_frame','end_frame','source_in_frame','source_out_frame')]
        if not all(type(x) is int for x in (a,b,i,o)) or not 0<=a<b<=duration or i<0 or o-i != b-a or a<prev or type(c.get('enabled')) is not bool:
            raise PackageError('Invalid or overlapping speaker source ranges.')
        if c.get('file') not in assets or not c['file'].endswith('.mp4'):
            raise PackageError('A speaker video is missing from the package.')
        prev=b
    context=m.get('production_context',{})
    if not isinstance(context,dict) or any(not isinstance(context.get(k,''),str) or len(context.get(k,''))>200000 for k in ('brief','full_script')):
        raise PackageError('Invalid production context.')
    mapping=m.get('full_timeline_mapping',[])
    if not isinstance(mapping,list): raise PackageError('Invalid source block map.')
    cursor=0
    for block in mapping:
        keys=('block','full_start_frame','full_end_frame','package_start_frame','package_end_frame')
        if not isinstance(block,dict) or any(type(block.get(k)) is not int for k in keys):
            raise PackageError('Invalid source block map.')
        a,b=block['package_start_frame'],block['package_end_frame']
        if a!=cursor or not a<b<=duration or block['full_start_frame']<0 or block['full_end_frame']-block['full_start_frame']!=b-a:
            raise PackageError('Source blocks do not cover the recording.')
        cursor=b
    if mapping and cursor!=duration: raise PackageError('Incomplete source block map.')
    # Whole sentences only. Original editorial edges can differ by one frame
    # from silence-detection sentence edges; snap those sentence edges explicitly.
    plan(m)
    return m

def plan(m):
    rows=copy.deepcopy(m['sentences'])
    bounds=[r['start_frame'] for r in rows]+[rows[-1]['end_frame']]
    on=[c for c in m.get('clips',[]) if c['enabled']]
    for c in on:
        for edge in (c['start_frame'],c['end_frame']):
            idx=min(range(len(bounds)),key=lambda n:abs(bounds[n]-edge))
            if abs(bounds[idx]-edge)>1: raise PackageError('A visible speaker edit cuts a sentence; revise the timing map first.')
            bounds[idx]=edge
    for idx,r in enumerate(rows):
        a,b=bounds[idx:idx+2]
        if b<=a: raise PackageError('Invalid sentence boundary after snapping.')
        mapping=m.get('full_timeline_mapping',[])
        if mapping:
            # Assign the source block before the existing one-frame visibility snap.
            blocks=[x for x in mapping if x['package_start_frame']<=r['start_frame']<r['end_frame']<=x['package_end_frame']]
            if len(blocks)!=1: raise PackageError('A sentence crosses a production block boundary.')
            r['production_block']=blocks[0]['block']
        r.update(start_frame=a,end_frame=b)
        matches=[c for c in on if c['start_frame']<b and c['end_frame']>a]
        if matches:
            if len(matches)!=1 or not matches[0]['start_frame']<=a<b<=matches[0]['end_frame']:
                raise PackageError('Speaker ranges cannot be mapped to whole sentences.')
            c=matches[0]
            r['speaker_clip']=dict(file=c['file'],source_in_frame=c['source_in_frame']+a-c['start_frame'],
                source_out_frame=c['source_in_frame']+b-c['start_frame'],fps=m['fps'],speaker=r.get('speaker','Speaker'))
    return rows

def manifest(d,doc=None):
    if doc is None:
        p=Path(d)/'scenes.json'
        doc=json.loads(p.read_text('utf8')) if p.is_file() else {}
    meta=doc.get('speaker_package')
    if not meta: return None
    p=local(d,meta['manifest'])
    if not p.is_file() or digest(p)!=meta['manifest_sha256']:
        raise PackageError('The speaker timing map is missing or has changed. Restore the imported package.')
    return json.loads(p.read_text('utf8'))

def annotate_narration(doc, timing):
    """Derived source-speaker identity, including off-camera speech and merged scenes.

    Never infer the speaker from the picture/cast. Offsets are relative to each
    scene's immutable audio clock, so renumbering or a production-scene split is safe.
    """
    from bisect import bisect_right
    scenes = doc.get('scenes') or []
    for scene in scenes:
        scene.pop('narration', None)
    if not timing:
        return
    rows = timing.get('sentences') or []
    ends = [r['end_frame'] for r in rows]
    fps = timing['fps']
    for scene in scenes:
        t = scene.get('editorial_timing') or {}
        a, b = t.get('start_frame'), t.get('end_frame')
        if (type(a) is not int or type(b) is not int or b <= a or t.get('fps') != fps):
            continue
        hits = []
        for r in rows[bisect_right(ends, a):]:
            if r['start_frame'] >= b:
                break
            if r['end_frame'] > a:
                hits.append(r)
        if not hits or hits[0]['start_frame'] > a or hits[-1]['end_frame'] < b:
            continue
        changes = [(right['start_frame'] - a) / fps for left, right in zip(hits,hits[1:])
                   if left.get('speaker') and right.get('speaker') and left['speaker'] != right['speaker']
                   and left['end_frame'] == right['start_frame']]
        scene['narration'] = dict(first=hits[0].get('speaker'), last=hits[-1].get('speaker'), changes=changes)


def package_dir(d,doc=None):
    if doc is None:
        p=Path(d)/'scenes.json'
        doc=json.loads(p.read_text('utf8')) if p.is_file() else {}
    meta=doc.get('speaker_package')
    return local(d,meta['manifest']).parent if meta else None

def voice(d,doc=None):
    m=manifest(d,doc)
    return local(package_dir(d,doc),m['voiceover']) if m else None

_verified={}
def verify_assets(d,doc,m):
    root=package_dir(d,doc)
    for rel,sha in m['assets'].items():
        p=local(root,rel)
        if not p.is_file(): raise PackageError('Speaker package media is missing: '+Path(rel).name)
        st=p.stat();key=(str(p),st.st_size,st.st_mtime_ns,st.st_ctime_ns,sha)
        if key not in _verified:
            if digest(p)!=sha: raise PackageError('Speaker package media has changed: '+p.name)
            _verified[key]=True
    if len(_verified)>2000: _verified.clear()

def draft(scene):
    return scene.get('editorial_insert') is True and not normalized(scene.get('vo')) and not scene.get('editorial_timing') and not locked(scene)


def pending_text(scene):
    return draft(scene) or (isinstance(scene.get('sentence_draft'),str) and normalized(scene['sentence_draft'])!=normalized(scene.get('vo')))


def editing_plan(m):
    """Production shots may share sentences inside one uninterrupted source block.

    Speaker clips remain individual immutable rows. The original sentence map,
    audio, source blocks and source frame ranges are never rewritten.
    """
    rows=[]
    for row in plan(m):
        if (rows and not row.get('speaker_clip') and not rows[-1].get('speaker_clip')
                and row.get('production_block')==rows[-1].get('production_block')
                and row['start_frame']==rows[-1]['end_frame']):
            rows[-1]['text']=normalized(rows[-1]['text']+' '+row['text'])
            rows[-1]['end_frame']=row['end_frame']
        else: rows.append(row)
    return rows


def authoritative(d,doc):
    m=manifest(d,doc)
    if not m: return None
    verify_assets(d,doc,m)
    rows=editing_plan(m); scenes=doc.get('scenes',[])
    uids=[s.get('uid') for s in scenes]
    if not scenes or any(not isinstance(u,str) or not u for u in uids) or len(set(uids))!=len(uids):
        raise PackageError('Scene identities are missing or duplicated.')
    scenes=[s for s in scenes if not draft(s)]
    at=0
    for r in rows:
        expected=copy.deepcopy(r.get('speaker_clip'))
        if expected: expected['file']=package_dir(d,doc).relative_to(d).as_posix()+'/'+expected['file']
        cursor=r['start_frame']; parts=[]
        while cursor<r['end_frame'] and at<len(scenes):
            s=scenes[at]; t=s.get('editorial_timing') or {}
            a,b,fps=(t.get(k) for k in ('start_frame','end_frame','fps'))
            if any(type(v) is not int for v in (a,b,fps)) or a!=cursor or not a<b<=r['end_frame'] or fps!=m['fps']:
                raise PackageError('Scene timing no longer matches the imported recording.')
            if expected and (a!=r['start_frame'] or b!=r['end_frame']):
                raise PackageError('Speaker scenes cannot be divided.')
            if s.get('speaker_clip')!=expected or s.get('production_block')!=r.get('production_block'):
                raise PackageError('Speaker source binding no longer matches the imported recording.')
            if expected and (s.get('video',{}).get('approved_file')!=expected['file'] or not s.get('approved')):
                raise PackageError('Speaker video is no longer bound to its source.')
            text=normalized(s.get('vo'))
            if not text: raise PackageError('A timed scene must contain part of its recorded sentence.')
            parts.append(text);cursor=b;at+=1
        if cursor!=r['end_frame'] or normalized(' '.join(parts))!=normalized(r['text']):
            raise PackageError('Edited scenes must preserve every word and frame of the recorded production block.')
    if at!=len(scenes): raise PackageError('Extra scenes fall outside the imported recording.')
    annotate_narration(doc,m)
    return m


# Imported source identity, speech, order and timings remain immutable. Only
# presentation fields explicitly exposed on a speaker card can be saved.
def presentation_edits(scene):
    fields = {'vo_tr': str}  # Source runs stay clean; transitions are derived at their boundaries.
    return {key: copy.deepcopy(scene[key]) for key, kind in fields.items()
            if key in scene and isinstance(scene[key], kind)}


def protect(previous,doc,structure=False):
    """Enforce persisted protections even for stale workers and generic PUT requests."""
    if not previous.get('speaker_package'): return
    doc['speaker_package']=copy.deepcopy(previous['speaker_package'])
    for field in ('script','script_draft'):
        if normalized(doc.get(field))!=normalized(previous.get('script')):
            raise PackageError('This script is tied to an edited speaker recording. Use a new project for a different script.')
    old=previous.get('scenes',[]); new=doc.get('scenes',[])
    if not old: return
    if structure:
        # Only the dedicated split and Undo routes can request this. The caller
        # also validates the complete partition against the immutable manifest.
        old_speakers=[s for s in old if locked(s)]
        new_speakers=[s for s in new if locked(s)]
        if [s.get('uid') for s in old_speakers]!=[s.get('uid') for s in new_speakers]:
            raise PackageError('Speaker scenes cannot be added, removed or reordered.')
        by_uid={s['uid']:s for s in old_speakers}
        for index,s in enumerate(new):
            if s.get('uid') in by_uid:
                original=by_uid[s['uid']]
                # Renumbering is cosmetic; every source/media/timing field stays exact.
                new[index]={**copy.deepcopy(original), **presentation_edits(s), 'id':index+1}
            elif locked(s):
                raise PackageError('A new scene cannot become a speaker source.')
            else: s['id']=index+1
        protect_block_continuity(new)
        return
    if [s.get('uid') for s in old]!=[s.get('uid') for s in new]:
        raise PackageError('Speaker package scene order and boundaries are locked to the recording.')
    for index,(a,b) in enumerate(zip(old,new)):
        if locked(a):
            new[index]={**copy.deepcopy(a), **presentation_edits(b)}
        else:
            b['editorial_timing']=copy.deepcopy(a.get('editorial_timing'))
            b['editorial_insert']=bool(a.get('editorial_insert'))
            b['vo']=a['vo']; b['id']=a['id']
            b.pop('speaker_clip',None)
            if 'production_block' in a: b['production_block']=a['production_block']
    protect_block_continuity(new)

def protect_block_continuity(scenes):
    by_uid={s.get('uid'):s for s in scenes}
    for s in scenes:
        parent=by_uid.get(s.get('cont_of'))
        if parent and s.get('production_block')!=parent.get('production_block'):
            s['cont_of']=None



def scene_signature(scene):
    return hashlib.sha256(json.dumps(scene,sort_keys=True,ensure_ascii=False).encode('utf8')).hexdigest()


def split_positions(text):
    """Cut on whitespace without moving a standalone opening quote backwards."""
    spans=list(re.finditer(r'\S+',str(text or '')))
    out=[]
    for i,span in enumerate(spans[1:],1):
        if spans[i-1].group() in ('«','“','‘','(','[','{'): continue
        if not any(c.isalnum() for c in str(text)[span.start():]): continue
        if span.group() in ('»','”','’',')',']','}',',','.',':',';','!','?'): continue
        out.append((i,span.start()))
    return out


def split_scene(doc,uid,word_index,frame):
    """Divide one production shot on the existing frame clock, never the audio."""
    result=copy.deepcopy(doc); scenes=result.get('scenes',[])
    idx=next((i for i,s in enumerate(scenes) if s.get('uid')==uid),None)
    if idx is None: raise PackageError('That scene changed. Refresh and try again.')
    first=scenes[idx]
    if locked(first): raise PackageError('Choose a production scene; speaker videos cannot be divided.')
    pos=dict(split_positions(first.get('vo'))).get(word_index) if type(word_index) is int else None
    if pos is None: raise PackageError('Choose the first word of the new scene.')
    timing=first.get('editorial_timing') or {}
    a,b,fps=(timing.get(k) for k in ('start_frame','end_frame','fps'))
    if any(type(v) is not int for v in (a,b,fps,frame)) or not a<frame<b:
        raise PackageError('The split must be inside the selected scene.')
    second=copy.deepcopy(first);second['uid']=uuid.uuid4().hex
    first['vo'],second['vo']=first['vo'][:pos].strip(),first['vo'][pos:].strip()
    first['vo_tr']=second['vo_tr']=''
    first['editorial_timing']['end_frame']=frame
    second['editorial_timing']['start_frame']=frame
    first['transition']='none'  # original outgoing transition belongs to the end of the second half
    duration=(b-a)/fps;offset=(frame-a)/fps
    def window(items,start,end,ink,outk):
        out=[]
        for item in items or []:
            item=copy.deepcopy(item)
            left=max(start,float(item.get(ink,0))*duration)
            right=min(end,float(item.get(outk,1))*duration)
            if right<=left: continue
            item[ink]=(left-start)/(end-start);item[outk]=(right-start)/(end-start)
            out.append(item)
        return out
    for target,start,end in ((first,0,offset),(second,offset,duration)):
        for key,ink,outk in (('overlays','ost_in','ost_out'),('icons','in','out')):
            if key in scenes[idx]:
                target[key]=window(doc['scenes'][idx].get(key),start,end,ink,outk)
        if target.get('sfx'):
            when=float(doc['scenes'][idx].get('sfx_in',0))*duration
            if start<=when<end: target['sfx_in']=(when-start)/(end-start)
            else: target['sfx']=''
    vid=second.get('video') or {}
    files=set(x for x in [vid.get('file'),vid.get('approved_file'),*(vid.get('versions') or [])] if isinstance(x,str) and x)
    starts=second.setdefault('video_starts',{})
    for rel in files: starts[rel]=float(starts.get(rel,0))+offset
    scenes.insert(idx+1,second)
    for i,s in enumerate(scenes,1): s['id']=i
    protect_block_continuity(scenes)
    return result


def insert_blank(doc,index,new_scene):
    result=copy.deepcopy(doc); scenes=result['scenes']
    neighbors=[s for s in scenes[max(0,index-1):index+1] if not locked(s)]
    if not neighbors:
        raise PackageError('Add a scene beside a production scene. Speaker videos stay intact.')
    row=new_scene(0);row.update(editorial_insert=True,sentence_draft='',editorial_timing=None)
    scenes.insert(index,row)
    for i,sc in enumerate(scenes,1):sc['id']=i
    return result


def sentence_edit_windows(scenes,m,targets=None):
    """Find the smallest complete edits, leaving unrelated unfinished drafts alone."""
    for row in editing_plan(m):
        if row.get('speaker_clip'):continue
        a,b=row['start_frame'],row['end_frame']
        indices=[i for i,s in enumerate(scenes) if not draft(s) and not locked(s)
                 and a<=(s.get('editorial_timing') or {}).get('start_frame',-1)
                 and (s.get('editorial_timing') or {}).get('end_frame',b+1)<=b]
        if not indices:continue
        lo,hi=indices[0],indices[-1]+1
        while lo>0 and draft(scenes[lo-1]):lo-=1
        while hi<len(scenes) and draft(scenes[hi]):hi+=1
        segment=scenes[lo:hi];cursor=0
        old=[normalized(s.get('vo')) for s in segment]
        new=[normalized(s['sentence_draft'] if isinstance(s.get('sentence_draft'),str)
                        else s.get('vo')) for s in segment]
        while cursor<len(segment):
            before=[];after=[];old_len=new_len=0;changed=False;end=cursor
            for end in range(cursor,len(segment)):
                if old[end]:
                    old_len+=len(old[end])+(1 if before else 0);before.append(old[end])
                if new[end]:
                    new_len+=len(new[end])+(1 if after else 0);after.append(new[end])
                changed=changed or old[end]!=new[end]
                if old_len==new_len and ' '.join(before)==' '.join(after):
                    candidates=segment[cursor:end+1]
                    timed=[s for s in candidates if not draft(s)]
                    if changed and timed and (targets is None or any(s['uid'] in targets for s in candidates)):
                        r=dict(row,text=' '.join(before),start_frame=timed[0]['editorial_timing']['start_frame'],
                               end_frame=timed[-1]['editorial_timing']['end_frame'])
                        yield r,candidates
                    cursor=end+1
                    break
            else:cursor+=1


def reconcile_sentences(d,doc,align,busy=lambda s:False,targets=None):
    """Resolve complete cut/paste edits only. Partial edits persist as visible drafts.

    The immutable manifest supplies outer boundaries. Measured onsets supply new
    internal cuts; unchanged boundaries keep their exact frames. No audio editing.
    """
    # Ordinary prompt/settings autosaves do no timing work. Empty placeholders
    # alone are harmless and do not require aligning the whole script.
    if not any(isinstance(s.get('sentence_draft'),str) and normalized(s['sentence_draft'])!=normalized(s.get('vo')) for s in doc.get('scenes',[])):
        return False
    m=authoritative(d,doc)
    if not m:return False
    changed=False;scenes=doc['scenes']
    for r,candidates in sentence_edit_windows(scenes,m,targets):
        a,b,fps=r['start_frame'],r['end_frame'],m['fps']
        texts=[normalized(s['sentence_draft'] if isinstance(s.get('sentence_draft'),str) else s.get('vo')) for s in candidates]
        if normalized(' '.join(texts))!=normalized(r['text']):continue
        active=[(s,text) for s,text in zip(candidates,texts) if text]
        if not active or any(not any(c.isalnum() for c in text) for _,text in active):continue
        original=[copy.deepcopy(s) for s in candidates]
        if any(busy(s) for s in candidates):continue
        # Token counts ignore standalone punctuation just like the word aligner.
        count=lambda t:sum(any(c.isalnum() for c in w) for w in t.split())
        anchors={0:a};offset=0
        for sc in original:
            if draft(sc):continue
            offset+=count(sc['vo']);anchors[offset]=sc['editorial_timing']['end_frame']
        words=None;cursor=0;bounds=[a]
        for sc,text in active[:-1]:
            cursor+=count(text)
            if cursor in anchors:frame=anchors[cursor]
            else:
                if words is None:words=align(r['text'],a/fps,b/fps)
                if not 0<cursor<len(words):break
                frame=round(words[cursor]['s']*fps)
            bounds.append(max(bounds[-1]+1,min(b-1,frame)))
        if len(bounds)!=len(active) or any(x>=b for x in bounds):continue
        bounds.append(b)
        old_by_uid={s['uid']:s for s in original}
        for i,(sc,text) in enumerate(active):
            old=old_by_uid[sc['uid']];t=old.get('editorial_timing') or {}
            start,end=bounds[i:i+2]
            if t and (start!=t['start_frame'] or end!=t['end_frame']):
                old_start,old_end=t['start_frame']/fps,t['end_frame']/fps
                duration=(end-start)/fps
                for key,ink,outk in (('overlays','ost_in','ost_out'),('icons','in','out')):
                    items=[]
                    for item in old.get(key) or []:
                        item=copy.deepcopy(item)
                        left=max(start/fps,old_start+float(item.get(ink,0))*(old_end-old_start))
                        right=min(end/fps,old_start+float(item.get(outk,1))*(old_end-old_start))
                        if right>left:
                            item[ink]=(left-start/fps)/duration;item[outk]=(right-start/fps)/duration;items.append(item)
                    if key in old:sc[key]=items
                if old.get('sfx'):
                    when=old_start+float(old.get('sfx_in',0))*(old_end-old_start)
                    if start/fps<=when<end/fps:sc['sfx_in']=(when-start/fps)/duration
                    else:sc['sfx']=''
                vid=sc.get('video') or {};files=set(x for x in [vid.get('file'),vid.get('approved_file'),*(vid.get('versions') or [])] if isinstance(x,str) and x)
                starts=sc.setdefault('video_starts',{})
                for rel in files:starts[rel]=max(0,float(starts.get(rel,0))+(start-t['start_frame'])/fps)
            sc.update(vo=text,sentence_draft=None,editorial_insert=False,editorial_timing=dict(start_frame=start,end_frame=end,fps=fps),vo_tr='')
            if 'production_block' in r:sc['production_block']=r['production_block']
        for sc,text in zip(candidates,texts):
            if not text:sc.update(vo='',sentence_draft='',editorial_insert=True,editorial_timing=None,vo_tr='')
        # A new empty card has its own media. Existing media/approval are never copied to it.
        changed=changed or any(sc!=old for sc,old in zip(candidates,original))
    if changed:authoritative(d,doc)
    return changed


def bind(doc,m,root_rel,new_scene):
    out=[]
    for idx,r in enumerate(plan(m),1):
        s=new_scene(idx)
        s.update(vo=r['text'],editorial_timing={k:r[k] for k in ('start_frame','end_frame')})
        s['editorial_timing']['fps']=m['fps']
        if 'production_block' in r: s['production_block']=r['production_block']
        # Deterministic IDs make a second Split safe for this same package.
        s['uid']=hashlib.sha256((doc['speaker_package']['manifest_sha256']+':'+str(idx)).encode()).hexdigest()[:32]
        if r.get('speaker_clip'):
            c=copy.deepcopy(r['speaker_clip']);c['file']=root_rel+'/'+c['file']
            s.update(speaker_clip=c,approved=True,prompt='',transition='none',camera='none',style='natural',
                video_cam_lock=True,ost_on=False,overlays=[],icons=[],testimonial=False,tcard_id=None,
                move='hold',fx_on=False,grain_on=False,atmo='',sfx='')
            s['video'].update(status='done',file=c['file'],versions=[c['file']],current=0,approved=True,
                approved_file=c['file'],approved_version=0,uploaded=True)
        out.append(s)
    return out

def srt(m):
    def stamp(f):
        ms=round(f*1000/m['fps']);h,ms=divmod(ms,3600000);mi,ms=divmod(ms,60000);sec,ms=divmod(ms,1000)
        return f'{h:02}:{mi:02}:{sec:02},{ms:03}'
    return '\n\n'.join(f"{i}\n{stamp(r['start_frame'])} --> {stamp(r['end_frame'])}\n{r['text']}" for i,r in enumerate(plan(m),1))+'\n'

def import_zip(stream,d,doc,probe,existing_audio=()):
    """Stage and validate everything before returning a project-owned folder.

    Caller commits the document under its project revision lock. The old project
    remains intact if validation or the final save fails.
    """
    if doc.get('scenes'): raise PackageError('Import the speaker package into a project with no scenes yet.')
    if doc.get('speaker_package'): raise PackageError('This project already has a speaker package.')
    root=Path(d)/'speaker-packages';root.mkdir(exist_ok=True)
    owned=Path(tempfile.mkdtemp(prefix='import-',dir=root))
    try:
        with zipfile.ZipFile(stream) as z:
            members=z.infolist()
            if len(members)>510 or sum(i.file_size for i in members)>MAX_BYTES: raise PackageError('Speaker package is too large.')
            names=[i.filename for i in members]
            if len(set(n.casefold() for n in names))!=len(names): raise PackageError('Duplicate ZIP filenames.')
            for i in members:
                local(owned,i.filename)
                if i.is_dir() or ((i.external_attr>>16)&0o170000)==0o120000: raise PackageError('Unexpected directory or link in ZIP.')
            if 'manifest.json' not in names or z.getinfo('manifest.json').file_size>8*1024**2: raise PackageError('Package timing map is missing or too large.')
            m=validate(json.loads(z.read('manifest.json')))
            if set(names)!={'manifest.json',*m['assets']}: raise PackageError('Unexpected or missing package files.')
            text=' '.join(r['text'] for r in m['sentences'])
            for field in ('script','script_draft'):
                if doc.get(field) and normalized(doc[field])!=normalized(text): raise PackageError('The uploaded script belongs to a different recording. Import into an empty project or use the matching script.')
            for existing in [Path(d)/'voiceover'/'voiceover.mp3',*existing_audio]:
                if existing and Path(existing).exists() and digest(existing)!=m['assets'][m['voiceover']]:
                    raise PackageError('The uploaded voice-over does not match this speaker package. Use the matching original MP3 or a new project.')
            for name in names:
                p=local(owned,name);p.parent.mkdir(parents=True,exist_ok=True)
                with z.open(name) as src,p.open('wb') as dst: shutil.copyfileobj(src,dst,1024*1024)
                if name!='manifest.json' and digest(p)!=m['assets'][name]: raise PackageError('Corrupt media in package: '+name)
            for rel in m['assets']:
                duration,w,h=probe(local(owned,rel))
                needed=max((c['source_out_frame']/m['fps'] for c in m.get('clips',[]) if c['file']==rel),default=0)
                if rel==m['voiceover']:
                    if abs(duration-m['duration_frames']/m['fps'])>.15: raise PackageError('The recording duration does not match its timing map.')
                elif not w or not h or duration+1/m['fps']<needed:
                    raise PackageError('A speaker video is shorter than its edit ranges.')
            (owned/'speaker.srt').write_text(srt(m),'utf8')
        doc=copy.deepcopy(doc)
        rel=owned.relative_to(d).as_posix()
        doc.update(speaker_package=dict(schema=SCHEMA,name=str(m.get('name','Speaker package'))[:120],manifest=rel+'/manifest.json',
            manifest_sha256=digest(owned/'manifest.json'),voiceover=rel+'/'+m['voiceover'],fps=m['fps'],duration_frames=m['duration_frames']),
            script=text,script_draft=text,text_sync={'status':'done','script':text})
        context=(m.get('production_context') or {}).get('brief','').strip()
        if context: doc['brief']=(doc.get('brief','').rstrip()+'\n\n'+context).strip()
        return doc,owned
    except Exception:
        shutil.rmtree(owned)
        raise

def insert_xml(xml,d,doc):
    """Encode clip edits on the sequence clock, source metadata on its native clock.

    OFF source clips stay disabled on a separate track. No source camera audio
    is added: the single imported MP3 remains the voice-over.
    """
    m=authoritative(d,doc)
    if not m:return xml
    root=ET.fromstring(xml)
    seq=next((b.find('children/sequence') for b in root.findall('project/children/bin') if b.findtext('name')=='Main Files'),None)
    if seq is None: raise PackageError('Cannot locate the exported main sequence.')
    fps=int(seq.findtext('rate/timebase'))
    video=seq.find('media/video')
    tracks=[ET.Element('track'),ET.Element('track')]
    first=next((i for i,e in enumerate(video) if e.tag=='track'),len(video))
    video.insert(first,tracks[1])
    # Opaque speaker footage shields against tails of neighbouring effect clips.
    # Keep captions and full-composite fades above it; source ranges stay native.
    top=next((i for i,e in enumerate(video) if e.tag=='track' and any(
        (c.findtext('name') or '') in ('Subtitles','Closing Fade','dip to black','flash (white)')
        for c in e.findall('clipitem'))),len(video))
    video.insert(top,tracks[0])
    base=package_dir(d,doc)
    prefix='speaker-'+uuid.uuid4().hex
    for idx,c in enumerate(m.get('clips',[])):
        a,b=c['start_frame'],c['end_frame'];i,o=c['source_in_frame'],c['source_out_frame']
        item=ET.SubElement(tracks[0 if c['enabled'] else 1],'clipitem',id=f'{prefix}-clip-{idx}')
        def add(parent,tag,value): ET.SubElement(parent,tag).text=str(value)
        add(item,'name',('Speaker ON' if c['enabled'] else 'Speaker OFF - retained')+f' {idx+1}')
        add(item,'enabled','TRUE' if c['enabled'] else 'FALSE')
        # Premiere's mixed-rate interchange uses the sequence clock for the
        # clipitem, including its source offsets. Only the file is native-rate.
        # Native 25fps offsets under a 60fps sequence miscue later source takes;
        # near-zero first takes can appear correct and conceal the error.
        add(item,'duration',round(o*fps/m['fps']))
        rate=ET.SubElement(item,'rate');add(rate,'timebase',fps);add(rate,'ntsc','FALSE')
        add(item,'start',round(a*fps/m['fps']));add(item,'end',round(b*fps/m['fps']))
        add(item,'in',round(i*fps/m['fps']));add(item,'out',round(o*fps/m['fps']))
        add(item,'pproTicksIn',i*254016000000//m['fps']);add(item,'pproTicksOut',o*254016000000//m['fps'])
        f=ET.SubElement(item,'file',id=f'{prefix}-file-{idx}')
        p=local(base,c['file'])
        add(f,'name',p.name)
        # Match the application's local-path dialect and portable bundle resolver.
        from premiere_export import _pathurl,ffprobe_media
        add(f,'pathurl',_pathurl(p))
        duration,w,h=ffprobe_media(p)
        rate=ET.SubElement(f,'rate');add(rate,'timebase',m['fps']);add(rate,'ntsc','FALSE')
        add(f,'duration',round(duration*m['fps']))
        media=ET.SubElement(f,'media');v=ET.SubElement(media,'video');sample=ET.SubElement(v,'samplecharacteristics')
        rate=ET.SubElement(sample,'rate');add(rate,'timebase',m['fps']);add(rate,'ntsc','FALSE')
        add(sample,'width',w);add(sample,'height',h);add(sample,'anamorphic','FALSE');add(sample,'pixelaspectratio','square');add(sample,'fielddominance','none')
        source=ET.SubElement(item,'sourcetrack');add(source,'mediatype','video');add(source,'trackindex',1)
    return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n'+ET.tostring(root,encoding='unicode')

def subtitle_identity(d, doc):
    """Bind measured subtitles to the immutable package, without rewriting its edit."""
    m = manifest(d, doc)
    if not m:
        return None
    verify_assets(d, doc, m)
    if doc.get('scenes'):
        authoritative(d, doc)
    if normalized(doc.get('script')) != normalized(' '.join(r['text'] for r in plan(m))):
        raise PackageError('The subtitle script differs from the package recording.')
    return dict(manifest_sha256=doc['speaker_package']['manifest_sha256'],
                voiceover_sha256=m['assets'][m['voiceover']],
                fps=m['fps'], duration_frames=m['duration_frames'])


def subtitle_clock(doc):
    # Prompt/image approvals may change while alignment runs. Editorial fields may not.
    fields = ('uid', 'vo', 'editorial_timing', 'speaker_clip', 'production_block')
    return copy.deepcopy([{k: s.get(k) for k in fields} for s in doc.get('scenes', []) if not draft(s)])


def subtitle_directory(d, active):
    """Never expose the old sentence-map SRT as measured, completed subtitles."""
    p = Path(d) / 'scenes.json'
    doc = json.loads(p.read_text('utf8')) if p.is_file() else {}
    if not doc.get('speaker_package'):
        return active
    # A reviewed recording revision publishes its audio, timing and subtitles
    # through the single scenes.json commit. Later generated subtitle sets win
    # when their identity matches the current recording.
    selected = (doc.get('speaker_package') or {}).get('reviewed_subtitles')
    if selected:
        record = Path(active) / '_result.json'
        identity = json.loads(record.read_text('utf8')).get('speaker_alignment') if record.is_file() else None
        if identity != subtitle_identity(d, doc): active = local(d, selected)
    result = Path(active) / '_result.json'
    if not result.is_file():
        return Path(d) / 'subtitle' / '_speaker_alignment_required'
    meta = json.loads(result.read_text('utf8'))
    if meta.get('speaker_alignment') != subtitle_identity(d, doc):
        raise PackageError('Subtitles do not match the locked speaker recording. Generate SRT again.')
    return active


def validate_subtitles(d, doc, job, audio, out):
    """Fail before publication if any protected clock, recording or transcript changed."""
    import math
    import premiere_export
    from text_boundaries import normalize_spacing
    if subtitle_identity(d, doc) != job['speaker_alignment'] or subtitle_clock(doc) != job['speaker_clock']:
        raise PackageError('The speaker edit changed while aligning. Previous subtitles were kept; generate again.')
    expected = job['speaker_alignment']['voiceover_sha256']
    if digest(voice(d, doc)) != expected or digest(audio) != expected:
        raise PackageError('The recording changed during alignment. Previous subtitles were kept.')
    words = premiere_export.load_word_tsv(Path(out).parent)
    cues = premiere_export.parse_srt(Path(out).read_text(encoding='utf-8-sig'))
    tokens = lambda text: normalize_spacing(text).split()
    script = tokens(doc['script'])
    lexical = lambda text: [w for w in tokens(text) if any(c.isalnum() for c in w)]
    if not words or lexical(' '.join(w[2] for w in words)) != lexical(doc['script']) or tokens(' '.join(c['text'] for c in cues)) != script:
        raise PackageError('Measured subtitles must contain the complete package script, word for word.')
    duration = job['speaker_alignment']['duration_frames'] / job['speaker_alignment']['fps']
    for rows, tail in (([(a,b) for a,b,_ in words], .15), ([(c['start'],c['end']) for c in cues], 1.0)):
        prev = -1.0
        for a,b in rows:
            if not all(math.isfinite(v) for v in (a,b)) or not 0 <= a <= b <= duration + tail or a < prev or a >= duration:
                raise PackageError('Subtitle alignment contains invalid or out-of-recording times.')
            prev = a


def register(app,g):
    from flask import request,jsonify,abort
    @app.errorhandler(PackageError)
    def package_error(e): return jsonify(error=str(e)),409

    @app.post('/api/speaker-package/<project>')
    def import_speaker_package(project):
        f=request.files.get('file')
        if not f:return jsonify(error='Choose a speaker package ZIP.'),400
        with g['_project_lock'](project):
            doc=g['load_doc'](project)
            if doc is None:abort(404)
            if str(doc.get('_revision',0))!=request.form.get('_revision'):
                raise PackageError('Project changed. Refresh before importing the package.')
            revision=doc.get('_revision',0);d,_=g['proj_dir'](project)
            owned=None
            def cleanup_uncommitted():
                if not owned: return
                try:
                    saved=json.loads((Path(d)/'scenes.json').read_text('utf8'))
                except Exception:
                    return  # retain the staged files if commit state cannot be determined
                rel=owned.relative_to(d).as_posix()+'/manifest.json'
                if saved.get('speaker_package',{}).get('manifest')!=rel: shutil.rmtree(owned)
            try:
                existing=[g['_find_vo_audio'](d)]
                prep=d/'subtitle'/'_audio-prep'
                state=g['audio_prepare'].state(prep)
                if state.get('status')=='running' or g['get_sub_status'](project).get('status')=='running':
                    raise PackageError('Wait for the current audio/subtitle job to finish before importing.')
                if state.get('ref'): existing.append(g['audio_prepare'].selected(prep,state['ref'])[0])
                updated,owned=import_zip(f.stream,d,doc,g['premiere_export'].ffprobe_media,existing)
                g['save_doc'](project,updated,expected_revision=revision)
            except (zipfile.BadZipFile,KeyError,TypeError,json.JSONDecodeError) as e:
                cleanup_uncommitted()
                raise PackageError('Invalid speaker package: '+str(e)) from e
            except Exception:
                cleanup_uncommitted()
                raise
        return jsonify(doc=updated)

    @app.before_request
    def protect_requests():
        if request.method in ('GET','HEAD','OPTIONS'):return
        args=request.view_args or {};project=args.get('project')
        if request.endpoint=='api_audio_prep' and args.get('area')=='subtitle':project=args.get('scope')
        if not project:return
        doc=g['load_doc'](project)
        if not doc or not doc.get('speaker_package'):return
        endpoint=request.endpoint or ''
        # Uploading/generating/alignment can replace or trim audio before save_doc.
        if endpoint in ('api_voiceover','api_audio_prep','api_text_sync','api_text_sync_document'):
            raise PackageError('This project uses the speaker package recording and timing. Create a new project for another recording.')
        if endpoint in ('api_duplicate_scene','api_reorder','api_resplit'):
            raise PackageError('Speaker package scene boundaries and order are locked to the recording.')
        if endpoint in ('api_generate','api_genprompt','api_generate_video','api_gen_video_prompt','api_gen_video_prompt_all'):
            body=request.get_json(silent=True) or {}; ids=body.get('ids','all'); uids=body.get('uids')
            selected=[s for s in doc.get('scenes',[]) if (s.get('uid') in uids if isinstance(uids,list) else ids=='all' or s.get('id') in ids)]
            unfinished=[s['id'] for s in selected if pending_text(s)]
            if unfinished and (uids is not None or ids!='all'):
                raise PackageError('Finish moving the recorded sentence before generating scene(s): '+', '.join(map(str,unfinished)))
        sid=args.get('sid')
        if sid is not None and any(s.get('id')==sid and locked(s) for s in doc.get('scenes',[])):
            raise PackageError('This speaker scene is protected. Its source video and timing are already set.')


def apply_reviewed_revision(directory):
    """Install an explicitly staged, hash-bound editorial revision under caller lock.

    All media already exist in a new immutable package. Only scenes.json is the
    commit point. An intervening user edit aborts instead of being overwritten.
    """
    import os
    d=Path(directory);pending=d/'_pending_timeline_repair.json'
    if not pending.is_file(): return False
    plan=json.loads(pending.read_text('utf8'));path=d/'scenes.json'
    if plan.get('schema') != 'reviewed-timeline-repair-v1': raise PackageError('Unsupported reviewed timeline revision.')
    before=path.read_bytes();doc=json.loads(before)
    applied=d/'_applied_timeline_repair.json'
    if doc.get('_timeline_repair_id')==plan.get('id'):
        os.replace(pending,applied);return False
    if hashlib.sha256(before).hexdigest()!=plan.get('expected_doc_sha256'):
        raise PackageError('Newer project edits were kept; the reviewed timeline revision needs another review.')
    candidate=local(d,plan['document']);raw=candidate.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=plan.get('document_sha256'): raise PackageError('Incomplete reviewed timeline revision.')
    updated=json.loads(raw)
    if updated.get('_timeline_repair_id')!=plan.get('id'):raise PackageError('Timeline revision identity mismatch.')
    m=validate(manifest(d,updated));authoritative(d,updated)
    sd=local(d,updated['speaker_package']['reviewed_subtitles'])
    result=json.loads((sd/'_result.json').read_text('utf8'))
    if result.get('speaker_alignment')!=subtitle_identity(d,updated):raise PackageError('Reviewed subtitle clock mismatch.')
    for rel,sha in plan['files'].items():
        if digest(local(d,rel))!=sha:raise PackageError('Incomplete reviewed timeline file: '+rel)
    backup=local(d,plan['backup']);backup.parent.mkdir(parents=True,exist_ok=True)
    if backup.exists() and backup.read_bytes()!=before:raise PackageError('Revision backup already contains different work.')
    if not backup.exists():backup.write_bytes(before)
    temp=path.with_name('.reviewed-scenes.tmp')
    with temp.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)
    os.replace(pending,applied)
    return True
