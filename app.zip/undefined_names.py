# -*- coding: utf-8 -*-
"""Find names a function USES but nothing ever defines - the NameError you only meet at runtime.

Written after Audit & Fix shipped broken: the YouTube/VSL split added `is_youtube(doc)` inside
`_audit_batch(payload)`, which has no `doc`. Nothing caught it, because the audit runs on a worker
thread inside `_parallel_map`, where an exception is captured as a job error rather than crashing -
so it compiled, imported, passed the smoke test, published, and only failed when a user pressed the
button. `py_compile` cannot see this: an undefined name is legal Python until the line executes.

Deliberately conservative. It resolves the full scope chain (function -> enclosing functions ->
module -> builtins) and gives up on anything it cannot see through (star-imports, `globals()`
tricks, `exec`), so a report means a real problem rather than noise nobody reads.
"""
import ast
import builtins


def _scope_body(node):
    """The nodes that make up a scope's body. A lambda's body is a single EXPRESSION, not a list -
    treating the lambda itself as its own body makes it its own child scope, and the walk never ends."""
    if isinstance(node, ast.Lambda):
        return [node.body]
    return list(getattr(node, "body", []) or [])


def _bound_by(node):
    """Every name this scope binds: parameters, assignments, defs, imports, except-as, comprehension
    targets, with-as, for-targets, global/nonlocal declarations."""
    names = set()
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
        a = node.args
        for arg in list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs):
            names.add(arg.arg)
        if a.vararg:
            names.add(a.vararg.arg)
        if a.kwarg:
            names.add(a.kwarg.arg)

    stack = list(_scope_body(node))
    while stack:
        n = stack.pop()
        # do NOT descend into a nested scope's body - its own bindings are its business
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(n.name)
            continue
        if isinstance(n, ast.Lambda):
            continue
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for al in n.names:
                names.add((al.asname or al.name).split(".")[0])
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            names.update(n.names)
        elif isinstance(n, ast.ExceptHandler) and n.name:
            names.add(n.name)
        elif isinstance(n, (ast.Assign, ast.AugAssign, ast.AnnAssign, ast.For, ast.AsyncFor,
                            ast.With, ast.AsyncWith, ast.NamedExpr)):
            for sub in ast.walk(n):
                if isinstance(sub, ast.Name) and isinstance(sub.ctx, (ast.Store, ast.Del)):
                    names.add(sub.id)
        elif isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            for gen in n.generators:
                for sub in ast.walk(gen.target):
                    if isinstance(sub, ast.Name):
                        names.add(sub.id)
        for child in ast.iter_child_nodes(n):
            stack.append(child)
    # comprehension targets anywhere inside this scope (they leak into our simple model, which is fine:
    # over-binding only makes the check quieter, never noisier)
    for n in ast.walk(node):
        if isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            for gen in n.generators:
                for sub in ast.walk(gen.target):
                    if isinstance(sub, ast.Name):
                        names.add(sub.id)
        elif isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            if isinstance(node, ast.Module):
                names.add(n.id)
    return names


def _loads(node):
    """Names READ directly in this scope (not inside a nested function/lambda/comprehension)."""
    out = []
    stack = [(c, ) for c in _scope_body(node)]
    seen = []
    while stack:
        (n, ) = stack.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            seen.append(n)
        for child in ast.iter_child_nodes(n):
            stack.append((child, ))
    # decorators and default values belong to the ENCLOSING scope, so they are read here too
    return seen


def scan(source, filename="<src>"):
    """-> [(lineno, scope_name, name)] for every name used but never bound anywhere in its chain."""
    tree = ast.parse(source, filename)
    if any(isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names) for n in ast.walk(tree)):
        return []                                    # a star-import hides everything; do not guess
    builtin = set(dir(builtins)) | {"__file__", "__name__", "__doc__", "__package__", "__spec__"}
    # `if "thing" in globals()` is the idiom for a symbol that may legitimately not exist - the code
    # already guards itself, so reporting it would be noise, and noise is how a checker gets ignored.
    for n in ast.walk(tree):
        if (isinstance(n, ast.Compare) and len(n.ops) == 1 and isinstance(n.ops[0], ast.In)
                and isinstance(n.left, ast.Constant) and isinstance(n.left.value, str)
                and isinstance(n.comparators[0], ast.Call)
                and isinstance(n.comparators[0].func, ast.Name)
                and n.comparators[0].func.id in ("globals", "locals", "vars")):
            builtin.add(n.left.value)
    problems = []

    def child_scopes(node):
        """The functions and lambdas defined DIRECTLY in this scope - not ones nested deeper, which
        belong to their own parent. Getting this wrong skips a link in the chain and every closure
        variable then looks undefined."""
        out = []
        stack = list(_scope_body(node))
        while stack:
            n = stack.pop()
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
                out.append(n)
                continue                             # recursion handles what is inside it
            for c in ast.iter_child_nodes(n):
                stack.append(c)
        return out

    def walk(node, chain, scope_name):
        here = _bound_by(node)
        visible = chain | here
        for nm in _loads(node):
            if nm.id not in visible and nm.id not in builtin:
                problems.append((nm.lineno, scope_name, nm.id))
        for sub in child_scopes(node):
            walk(sub, visible,
                 sub.name if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef))
                 else scope_name + " (lambda)")

    walk(tree, set(), "<module>")
    seen, out = set(), []
    for lineno, scope, name in sorted(problems):
        if (scope, name) in seen:
            continue
        seen.add((scope, name))
        out.append((lineno, scope, name))
    return out


if __name__ == "__main__":
    import sys, pathlib
    bad = 0
    for path in (sys.argv[1:] or ["app.py"]):
        p = pathlib.Path(path)
        found = scan(p.read_text(encoding="utf-8"), p.name)
        for lineno, scope, name in found:
            print("%s:%d  %s uses undefined '%s'" % (p.name, lineno, scope, name))
        bad += len(found)
    print("%d undefined name(s)" % bad)
    sys.exit(1 if bad else 0)
