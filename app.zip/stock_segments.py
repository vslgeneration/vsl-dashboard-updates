"""Scene-sized stock suggestions and optional derived excerpts; the full source is retained."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import threading
import stock_cancel

_TIMINGS = {}; _LOCK = threading.RLock()

def timing_stamp(ns,project,doc):
    try:
        d=ns['proj_dir'](project)[0];srt=ns['_find_srt'](d);audio=ns['_find_vo_audio'](d)
        sd=ns['_subtitle_dir'](d)
        paths=[p for p in (srt,audio,d/'voiceover/voiceover.mp3',sd/'aligned_vo.json') if p and p.exists()]+sorted(sd.glob('*.tsv'))
        return hashlib.sha256(json.dumps([[(str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in paths],
            [(s.get('uid'),s.get('id'),s.get('vo')) for s in doc.get('scenes',[])]],sort_keys=True).encode()).hexdigest()
    except Exception:return ''


def number(value):
    if isinstance(value, bool): return None
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError): return None


def probe_duration(path):
    r = stock_cancel.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(path)],
        capture_output=True,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    value = number(json.loads(r.stdout or b'{}').get('format',{}).get('duration'))
    if r.returncode or value is None or value <= 0: raise ValueError('Media duration is unavailable.')
    return value


def timings(ns, project, doc):
    """Called by the review worker or an explicit section editor, never by search/status/typing."""
    import premiere_export as pe
    directory = ns['proj_dir'](project)[0]
    scenes = doc.get('scenes') or []
    result = {s.get('uid'):dict(duration=round(max(1.,len(str(s.get('vo') or '').split())/2.5),3),basis='estimated')
              for s in scenes if str(s.get('vo') or '').strip()}
    try:
        srt = ns['_find_srt'](directory); audio = ns['_find_vo_audio'](directory)
        if not srt or not audio or ns['_vo_is_stale'](directory): return result
        sd = ns['_subtitle_dir'](directory)
        tracked = [srt,audio]+sorted(sd.glob('*.tsv'))
        stamp = [(str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in tracked]
        key = hashlib.sha256(json.dumps([stamp,[(s.get('uid'),s.get('id'),s.get('vo')) for s in scenes]],sort_keys=True).encode()).hexdigest()
        with _LOCK:
            if key in _TIMINGS: return _TIMINGS[key]
        cues = pe.parse_srt(srt.read_text(encoding='utf-8',errors='ignore'))
        if not cues: return result
        words = pe.load_word_tsv(sd); starts = pe.word_scene_starts(scenes,words) if words else None
        total = max(probe_duration(audio),cues[-1]['end'])
        ranges,included = pe.scene_time_ranges(scenes,cues,total,starts)
        for scene,(start,end),inc in zip(scenes,ranges,included):
            if inc and end > start:
                result[scene.get('uid')]=dict(duration=round((round(end*pe.FPS)-round(start*pe.FPS))/pe.FPS,5),basis='aligned')
            else: result.pop(scene.get('uid'),None)
        if stamp != [(str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in tracked]: return {}
        with _LOCK:
            if len(_TIMINGS)>64: _TIMINGS.clear()
            _TIMINGS[key]=result
    except Exception: pass
    return result


def moment(value, sample):
    """The model selects observed sample indexes, never invents frame-accurate timestamps."""
    if not isinstance(value,dict) or not isinstance(sample,dict): return None
    times = sample.get('times') or []; duration=number(sample.get('duration'))
    start,end=value.get('start_sample'),value.get('end_sample')
    if type(start) is not int or type(end) is not int or not 1<=start<=end<=len(times) or not duration or duration<=0: return None
    first,last=number(times[start-1]),number(times[end-1])
    if first is None or last is None or not 0<=first<=last<=duration: return None
    return dict(start=first,end=last,duration=duration,basis='sampled_frames')


def suggest(duration, need, observed=None):
    duration=number(duration); target=number((need or {}).get('duration'))
    if duration is None or duration<=0 or target is None or target<=0: return None
    anchor=number((observed or {}).get('start')) or 0.
    start=max(0.,min(anchor,max(0.,duration-target))); end=min(duration,start+target)
    warnings=[]
    if duration+0.04<target: warnings.append('Clip Is Shorter Than This Scene')
    if observed and number(observed.get('end')) is not None and end+0.04<observed['end']:
        warnings.append('The Suggested Section May Cut The Action')
    if need.get('basis')!='aligned':warnings.append('Scene Duration Is Estimated')
    return dict(start=round(start,3),end=round(end,3),source_duration=duration,scene_duration=target,
                basis=observed.get('basis','sampled_frames') if observed else 'duration_only',timing_basis=need.get('basis','estimated'),warnings=warnings)


def validate(value, duration):
    if value is None: return None
    if not isinstance(value,dict): raise ValueError('Choose a valid video section.')
    start,end=number(value.get('start')),number(value.get('end')); duration=number(duration)
    basis=number(value.get('source_duration'))
    if duration is None or duration<=0 or start is None or end is None or start<0 or end-start<.08 or end>duration+.06:
        raise ValueError('The selected section is outside this video. Adjust it or use the full clip.')
    if basis is not None and abs(basis-duration)>max(.3,duration*.01):
        raise ValueError('Preview timing differs from the full video. Choose Full Clip or adjust the section using the downloaded video.')
    end=min(end,duration)
    if start<=.001 and end>=duration-.04:return None
    return dict(start=start,end=end,source_duration=duration)


def excerpt(source, folder, selected):
    output=Path(folder)/'section.mp4';start=selected['start'];duration=selected['end']-start
    r=stock_cancel.run(['ffmpeg','-nostdin','-v','error','-ss',str(start),'-i',str(source),'-t',str(duration),
        '-map','0:v:0','-map','0:a?','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',
        '-threads','2','-c:a','aac','-b:a','192k','-movflags','+faststart',str(output)],
        capture_output=True,timeout=300,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if r.returncode or not output.is_file() or not output.stat().st_size:raise ValueError('The video section could not be prepared. The full clip and previous scene were kept.')
    actual=probe_duration(output)
    if abs(actual-duration)>max(.15,duration*.01):raise ValueError('The video section timing could not be verified. The previous scene was kept.')
    return output
