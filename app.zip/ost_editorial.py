"""Editorial defaults derived from the user's finished work, without project content."""
import itertools
import re

DEFAULT_STYLE = dict(ost_font='Geomini',ost_size=150,ost_weight='800',ost_upper=True,
    ost_color='#ffffff',ost_fill=True,ost_place='center',ost_x=0,ost_y=0,
    ost_bg=False,ost_shadow=False,ost_stroke=False,ost_anim='fade',ost_out_anim='fade')

RULES = '''
EDITOR'S FINISHED-WORK PREFERENCES:
Read the entire narrative. No numerical quota, density target or maximum share of scenes. Apply OST
wherever meaningful; connective storytelling and repetitions can stay bare if a callout adds nothing.
Emphasize short complete phrases: meaningful evidence WITH its number/unit/timeframe, decisive tangible
benefits, a named ingredient/mechanism at its introduction, or each item of a deliberately emphasized list.
Do not turn every emotional anecdote, product mention, CTA repetition or ordinary sentence into a title.
Keep a related run consistent. A phrase may appear late: its first word determines its onset, then it
stays through the scene end. Never show the claim before its spoken phrase.
For a single callout prefer a readable centered headline; reduce size to fit instead of overflowing.
Use the user's selected preset for font, colour and animation. No unrequested background decoration.
Character limit means per LINE, not per phrase: use two balanced, meaningful lines when allowed.
Break at a phrase/clause boundary, keeping names, number+unit, negation and tightly related words together.
Do not force everything onto one line or truncate a complete idea just because the first line is full.
For visible equal panels, one relevant label belongs at the center of its own panel. Every label in that
image uses the SAME font size, determined by the longest/widest label. Never run text across dividers.
These are editorial preferences in every language, not permission to rewrite the voice-over.
'''

_FUNCTION = set('a an the of to in with for at by on and or de du des la le les un une au aux en et à di il lo gli per con e el los las una del al y der die das ein eine dem den von zu mit und ve bir için ile'.split())

def wrap_phrase(text,max_chars=20,max_lines=2):
    """Retain authored semantic breaks if they fit, otherwise balance whole words."""
    text=str(text or '').strip();limit=max(6,min(80,int(max_chars)));count=max(1,min(3,int(max_lines)))
    lines=text.split('\n')
    if text and len(lines)<=count and all(len(s)<=limit for s in lines):return text
    words=text.split()
    if not words:return ''
    if len(words)>100:return None
    for n in range(1,min(count,len(words))+1):
        candidates=[]
        for cuts in itertools.combinations(range(1,len(words)),n-1):
            bounds=(0,*cuts,len(words));parts=[' '.join(words[a:b]) for a,b in zip(bounds,bounds[1:])]
            if any(len(p)>limit for p in parts):continue
            sizes=[len(p) for p in parts];score=(max(sizes)-min(sizes))**2
            for c in cuts:
                left=words[c-1].casefold();right=words[c].casefold()
                if left in _FUNCTION:score+=160
                if re.fullmatch(r'[$€£]?\d[\d.,%]*',left):score+=240
                if left.endswith((',',':',';','.','!','?')):score-=40
                if right in ('and','but','or','et','mais','und','aber','ve','ama'):score-=20
            candidates.append((score,parts))
        if candidates:return '\n'.join(min(candidates,key=lambda x:x[0])[1])
    return None

def panel_result(value,source_phrase):
    """Accept only an explicit, complete regular panel layout and spoken labels."""
    if not isinstance(value,dict) or value.get('confident') is not True:return None
    rows=value.get('rows');texts=value.get('texts')
    if not isinstance(rows,list) or not rows or len(rows)>3 or any(type(n) is not int or n<1 or n>4 for n in rows):return None
    if not isinstance(texts,list) or not 2<=len(texts)<=9 or sum(rows)!=len(texts):return None
    if any(not isinstance(t,str) or not t.strip() or not source_phrase(t) for t in texts):return None
    return dict(names=texts,rows=rows)
