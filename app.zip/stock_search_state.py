"""Persistent per-source scene results, bounded provider searches and a local search lane."""
import copy
import hashlib
import json
from pathlib import Path
import threading
import time
import uuid
from flask import abort, jsonify, request
import stock_filters
import stock_library
import stock_cancel
import stock_quality
import stock_refinement

def failure_info(error, stage="search"):
    """Stable, safe diagnostics: raw provider text may contain account data or URLs."""
    text = str(error).lower(); name = type(error).__name__
    if name == "ClaudeNotLoggedIn" or any(x in text for x in ("not logged in", "session expired", "authentication_error", "unauthorized")):
        code, message, pause = "account", "Reconnect your Claude or stock account, then use Prepare Stock to resume.", True
    elif any(x in text for x in ("rate limit", "quota", "usage limit", "credit balance", "too many requests", "429")):
        code, message, pause = "limit", "The provider usage limit was reached. Use Prepare Stock to resume when it resets.", True
    elif name == "ClaudeModelError":
        code, message, pause = "claude_setup", "Claude could not use the selected model. Check the Claude connection, then resume.", True
    elif "timeout" in name.lower() or "timed out" in text:
        code, message, pause = "timeout", "This step timed out. Other scenes can continue; use Prepare Stock to retry incomplete results.", False
    else:
        code, message, pause = "unavailable", "This step could not finish. Other scenes can continue; use Prepare Stock to retry incomplete results.", False
    stage = stage if stage in ("planning", "storyblocks", "envato", "ranking", "library", "saving", "search") else "search"
    return dict(code=code,stage=stage,error_type=name,message=stage.title()+": "+message,pause=pause)

def register(app,ns,run_search,doc_scene,read_json,write_json,seed_search=None,quality=None):
    jobs=ns['_user_job_registry']('stock-search')
    schedulers=ns['_user_job_registry']('stock-search-scheduler')
    lock=threading.RLock()
    def scheduler():
        state=schedulers.setdefault('state',{'queue':[],'working':False})
        state.setdefault('local_queue',[]);state.setdefault('local_working',False);state.setdefault('projects',{})
        state.setdefault('library_queue',[]);state.setdefault('library_working',0)
        return state
    def queues():return (scheduler()['queue'],scheduler()['local_queue'],scheduler()['library_queue'])
    def queue_name(job):return 'local_queue' if job.get('_local') else 'library_queue' if job.get('_library') else 'queue'
    def automatic_path():return Path(str(ns['PROJECTS'])).parent/'stock'/'background.json'
    def automatic_config():return read_json(automatic_path(),{}) or {}
    def directory(project):return ns['proj_dir'](project)[0]/'_stock_search'
    def path(project,uid):return directory(project)/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
    def is_automatic_spec(spec):
        return spec.get('provider')=='all' and spec.get('type')=='video' and not spec.get('query') and spec.get('_source_policy')=='web-storyblocks-first-v1'
    def is_library_scene(spec):
        return spec.get('provider')=='library' and spec.get('type')=='video' and not spec.get('query') and not spec.get('_live')
    def record(project,uid):
        r=read_json(path(project,uid),{}) or {}
        # Carry forward a prepared result from older records before live typing trims history.
        if not r.get('automatic_result'):
            old=next((h for h in r.get('history',[]) if is_automatic_spec(h.get('spec',{}))),None)
            if old:r['automatic_result']=old
        return r
    def source_slot(spec):return spec.get('provider','all')+':'+spec.get('type','video')
    def results(r):
        return r.get('history',[])+list(r.get('source_results',{}).values())+[r[k] for k in ('automatic_result','automatic_library_result') if r.get(k)]
    def automatic_job(j):return j.get('_automatic',j.get('_background',False))
    def config(project):return read_json(directory(project)/'settings.json',{}) or {}
    def automatic_spec(r):
        saved=r.get('spec',{})
        return {'filters':saved.get('filters',{}) if saved.get('type','video')=='video' else {}}
    def automatic_library_spec(r):
        saved=r.get('source_specs',{}).get('library:video') or automatic_spec(r)
        return dict(provider='library',type='video',query='',filters=saved.get('filters',{}))
    def library_revision(cfg):
        if not cfg.get('library_auto'):return None
        root=stock_library.configured(Path(str(ns['PROJECTS'])).parent/'stock')
        return stock_library.revision(root) if root else None
    def prepare_scene(project,scene,r,context,resume,revision):
        # Library is independent of All Sources. Neither source can replace the other's queue entry.
        if revision is not None:
            enqueue(project,scene['uid'],spec=automatic_library_spec(r),background=True,retry_incomplete=resume,initial_context=context,library_revision=revision)
        enqueue(project,scene['uid'],spec=automatic_spec(r),background=True,retry_incomplete=resume,initial_context=context)
    def normalize(value,revision=None):
        spec=stock_filters.normalize(value)
        if spec['type']=='video' and spec['provider']=='library':
            root=stock_library.configured(Path(str(ns['PROJECTS'])).parent/'stock')
            spec['_library_revision']=stock_library.revision(root) if revision is None else revision
        if spec['provider']=='all':spec['_source_policy']='web-storyblocks-first-v1'
        if value.get('_live') is True and spec['provider']=='library' and spec['type']=='video':spec['_live']=True
        return spec
    def context_for(doc,scene):
        return stock_quality.scene_context(doc,scene)
    def snapshot(project,uid):
        with ns['_project_lock'](project):
            doc,scene=doc_scene(project,uid)
            return context_for(doc,scene)
    def key_for(spec,context):return hashlib.sha256(json.dumps([1,spec,context],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    def public(job):
        try:visible=quality.present(job) if quality and job.get('status')=='done' else job
        except Exception:visible=job  # Optional refinement must never hide usable search results.
        if job.get('refinement_job') in jobs:
            follow=jobs[job['refinement_job']]
            visible=dict(visible,refinement_status=follow['status'],refinement_added=follow.get('refinement_added',0))
        return {k:copy.deepcopy(v) for k,v in visible.items() if not k.startswith('_')}
    def hydrate(project,uid,cached):
        jid=cached['id']
        # A duplicated/imported project can carry the same persisted result ID.
        # Reuse it only within its owner; never bind the copy to the original job.
        owner=jobs.get(jid)
        if owner and (owner.get('project')!=project or owner.get('uid')!=uid):
            jid=hashlib.sha256(json.dumps([project,uid,cached['id']],separators=(',',':')).encode()).hexdigest()
        jobs.setdefault(jid,dict(cached,id=jid,project=project,uid=uid,status='done',cached=True))
        return jid
    def save_preferences(project,uid,spec):
        r=record(project,uid);r['spec']=spec;r.setdefault('source_specs',{})[source_slot(spec)]=spec;r['revision']=uuid.uuid4().hex;write_json(path(project,uid),r)
        return r
    def enqueue(project,uid,spec=None,force=False,background=False,retry_incomplete=False,initial_context=None,library_revision=None,refinement=None):
        with lock:
            for old_id,old in list(jobs.items()):
                if old.get('status') not in ('queued','running') and time.time()-old.get('created',0)>3600:jobs.pop(old_id,None)
            context=initial_context if initial_context is not None else snapshot(project,uid);r=record(project,uid)
            spec=normalize(spec if spec is not None else r.get('spec',{}),library_revision);key=key_for(spec,context)
            if not background:r=save_preferences(project,uid,spec)
            for jid,j in jobs.items():
                if j.get('project')==project and j.get('uid')==uid and j.get('key')==key and j.get('status') in ('queued','running') and not j.get('_stop_requested'):
                    if background:j['_automatic']=True
                    if not background:
                        if j['status']=='queued':
                            q=scheduler()[queue_name(j)];q.remove(jid);q.insert(0,jid)
                        j['_background']=False
                    if not background and seed_search and not j.get('partial'):seed_search(j,context,spec)
                    return jid
            if not force:
                cached=next((h for h in results(r) if h.get('key')==key),None)
                if cached and not (retry_incomplete and cached.get('warnings')):
                    if not background:r['last_result']=cached;write_json(path(project,uid),r)
                    if quality:quality.schedule(project,uid,cached,context)
                    return hydrate(project,uid,cached)
            # A scene's new search replaces only its queued requests; an in-flight result may finish into history.
            for q in queues():
                for jid in list(q):
                    if jobs[jid]['project']==project and jobs[jid]['uid']==uid and jobs[jid]['_background']==background and source_slot(jobs[jid]['spec'])==source_slot(spec):
                        q.remove(jid);jobs[jid].update(status='cancelled',progress='Replaced by a newer search.')
            jid=uuid.uuid4().hex
            local=spec['provider']=='library' and bool(spec['query'])
            library=spec['provider']=='library' and not local
            jobs[jid]=dict(id=jid,project=project,uid=uid,key=key,spec=spec,status='queued',created=time.time(),
                          progress='Searching Library…' if local or library else 'Waiting for the current stock search…',_context=context,_revision=r.get('revision'),_background=background,_automatic=background,_local=local,_library=library,_cancel_event=threading.Event())
            if refinement:jobs[jid]['_weak_refinement']=copy.deepcopy(refinement)
            if not background and seed_search:seed_search(jobs[jid],context,spec)
            q=scheduler()[queue_name(jobs[jid])]
            if background:q.append(jid)
            else:q.insert(0,jid)
            start_worker(local,library)
            return jid
    def queue_weak(project,uid,result,context,report=None):
        # Called only after the initial result/review is committed, never on a search/status/typing request.
        with lock:
            if not quality or quality.stopped(project) or quality.state().get('paused'):return
            if scheduler().get('project') not in (None,project):return
            rejected={r['asset'] for r in quality.feedback_for(project,uid,context)}
            if not stock_refinement.weak(result,report,rejected):return
            if snapshot(project,uid)!=context:return
            spec=result.get('spec') or {};key=key_for(spec,context)
            current=record(project,uid);latest=current.get('source_results',{}).get(source_slot(spec))
            if latest and latest.get('key')!=key:return
            if any(j.get('project')==project and j.get('uid')==uid and j.get('key')==key and j.get('status') in ('queued','running') for j in jobs.values()):return
            budget=directory(project)/'refinement'/(key+'.json')
            if read_json(budget,{}):return
            write_json(budget,dict(attempts=1,created=time.time(),context=context))
            refinement=dict(base=copy.deepcopy(result),report=copy.deepcopy(report or {}))
            jid=enqueue(project,uid,spec=spec,force=True,background=True,initial_context=context,refinement=refinement)
            original=jobs.get(result.get('id'))
            if original:original['refinement_job']=jid
            write_json(budget,dict(attempts=1,created=time.time(),job=jid,context=context))
    if quality:quality.on_review=queue_weak
    def start_worker(local=False,library=False):
        state=scheduler()
        key='local_working' if local else 'library_working' if library else 'working'
        queue='local_queue' if local else 'library_queue' if library else 'queue'
        limit=1 if local or library else max(1,min(3,int(ns.get('_STOCK_WEB_WORKERS',3))))
        # Calls are serialized by the scheduler lock. Each thread retains its owner's credentials.
        while int(state[key])<limit and state[queue]:
            state[key]=int(state[key])+1
            try:ns['_KeyThread'](target=worker,args=(local,library),daemon=True).start()
            except Exception:
                state[key]-=1
                raise
    def pause(project,message):
        cfg=config(project);cfg['paused']=message;write_json(directory(project)/'settings.json',cfg)
        for q in queues():
            for jid in list(q):
                if jobs[jid]['project']==project and automatic_job(jobs[jid]):
                    q.remove(jid);jobs[jid].update(status='paused',progress='Background preparation paused.')
    def worker(local=False,library=False):
        while True:
            with lock:
                state=scheduler()
                queue=state['local_queue' if local else 'library_queue' if library else 'queue']
                if not queue:
                    key='local_working' if local else 'library_working' if library else 'working';state[key]=max(0,int(state[key])-1);return
                jid=queue.pop(0);j=jobs[jid];j.update(status='running',progress='Searching Library…' if local else 'Planning visual approaches…')
            try:
                current=snapshot(j['project'],j['uid'])
                if key_for(j['spec'],current)!=j['key']:
                    j.update(status='cancelled',progress='Scene changed before this search started.');continue
                started = time.monotonic()
                if seed_search and not j.get('partial'):seed_search(j,j['_context'],j['spec'])
                with stock_cancel.scope(j['_cancel_event']):result=run_search(j,j['_context'],j['spec'])
                if j.get('_weak_refinement'):
                    extra=j['_weak_refinement'];result=stock_refinement.merge(extra['base'],result,extra['report'])
                with lock:
                    if j.get('_stop_requested'):
                        j.update(status='cancelled',progress='Stock preparation stopped.');continue
                    # Deleted scenes/projects must not be recreated by a late worker.
                    snapshot(j['project'],j['uid'])
                    j['_stage']='saving'
                    r=record(j['project'],j['uid'])
                    r.setdefault('errors',{}).pop(source_slot(j['spec']),None)
                    result['elapsed_seconds']=round(time.monotonic()-started,3)
                    cached=dict(id=jid,key=j['key'],created=j['created'],completed=time.time(),**result)
                    r['history']=([cached]+[h for h in r.get('history',[]) if h.get('key')!=j['key']])[:5]
                    slot=source_slot(j['spec'])
                    old=r.get('source_results',{}).get(slot,{})
                    keep_manual=j['_background'] and is_library_scene(j['spec']) and bool(old.get('spec',{}).get('query'))
                    if not keep_manual and cached['created']>=old.get('created',0):r.setdefault('source_results',{})[slot]=cached
                    if is_automatic_spec(j['spec']):r['automatic_result']=cached
                    if is_library_scene(j['spec']):r['automatic_library_result']=cached
                    if not j['_background'] and j['created']>=r.get('last_result',{}).get('created',0):r['last_result']=cached
                    if j.get('_weak_refinement') and r.get('last_result',{}).get('id')==j['_weak_refinement']['base'].get('id'):r['last_result']=cached
                    write_json(path(j['project'],j['uid']),r)
                    j.update(result,status='done',completed=cached['completed'])
                    if quality:quality.schedule(j['project'],j['uid'],cached,j['_context'])
                    scheduler()['projects'][j['project']]=overview(j['project'])
                    if not result.get('items') and not result.get('warnings'):queue_weak(j['project'],j['uid'],cached,j['_context'])
                    if automatic_job(j) and j.get('_pause_required') and not j.get('_weak_refinement'):
                        pause(j['project'],j['_pause_required'])
                        stop_automatic(j['_pause_required'],paused=True)
            except (Exception,stock_cancel.Cancelled) as exc:
                with lock:
                    if j.get('_stop_requested'):
                        j.update(status='cancelled',progress='Stock preparation stopped.');continue
                    failure=failure_info(exc,j.get('_stage','search'))
                    j.update(status='error',error=failure['message'],failure=failure)
                    try:
                        snapshot(j['project'],j['uid'])
                        r=record(j['project'],j['uid']);r.setdefault('errors',{})[source_slot(j['spec'])]=dict(failure,key=j['key'],at=time.time())
                        write_json(path(j['project'],j['uid']),r)
                        if automatic_job(j) and failure['pause'] and not j.get('_weak_refinement'):
                            pause(j['project'],failure['message']);stop_automatic(failure['message'],paused=True)
                    except Exception:pass
    def overview(project):
        cfg=config(project);doc=ns['load_doc'](project)
        if doc is None:abort(404)
        if ns['is_youtube'](doc):abort(400)
        total=ready=web_ready=library_ready=0;revision=library_revision(cfg)
        for scene in doc.get('scenes',[]):
            if not scene.get('uid') or not (scene.get('vo') or scene.get('prompt')):continue
            total+=1;r=record(project,scene['uid']);spec=normalize(automatic_spec(r));key=key_for(spec,context_for(doc,scene))
            web_done=any(h.get('key')==key and not h.get('warnings') for h in results(r));web_ready+=web_done
            local_done=True
            if revision is not None:
                local_key=key_for(normalize(automatic_library_spec(r),revision),context_for(doc,scene))
                local_done=any(h.get('key')==local_key and not h.get('warnings') for h in results(r));library_ready+=local_done
            ready+=web_done and local_done
        active=[j for j in jobs.values() if j.get('project')==project and j.get('status') in ('queued','running')]
        return dict(enabled=cfg.get('enabled',True),paused=cfg.get('paused',''),total=total,ready=ready,
                    web_ready=web_ready,library_ready=library_ready,library_total=total if revision is not None else 0,
                    queued=sum(j['status']=='queued' for j in active),running=sum(j['status']=='running' for j in active))
    @app.get('/api/stock/filter-options')
    def stock_filter_options():return jsonify(video=stock_filters.definitions('video'),image=stock_filters.definitions('image'))
    @app.get('/api/stock/<project>/state/<uid>')
    def stock_search_state(project,uid):
        with lock:
            context=snapshot(project,uid);r=record(project,uid)
            source=request.args.get('provider');kind=request.args.get('type','video')
            if source is not None:
                if source not in ('all','storyblocks','envato','library') or kind not in ('video','image'):abort(400)
                if source=='library':kind='video'
                slot=source+':'+kind
                previous=next((h['spec'] for h in results(r) if source_slot(h.get('spec',{}))==slot),None)
                value=r.get('source_specs',{}).get(slot) or previous or dict(provider=source,type=kind,query='',filters=r.get('spec',{}).get('filters',{}))
                spec=normalize(value)
            else:spec=normalize(r.get('spec',{}))
            key=key_for(spec,context)
            active=next((jid for jid,j in jobs.items() if j.get('project')==project and j.get('uid')==uid and j.get('key')==key and j.get('status') in ('queued','running')),None)
            if active and seed_search and not jobs[active].get('partial'):seed_search(jobs[active],context,spec)
            cached=next((h for h in results(r) if h.get('key')==key),None)
            if quality and cached:quality.schedule(project,uid,cached,context)
            result=public(jobs[hydrate(project,uid,cached)]) if cached else None
            previous=[r.get('last_result',{}),cached or {}]+results(r)
            # Legacy All Sources caches included Library and cannot represent this source anymore.
            last=next((h for h in previous if h and
                (h['spec'].get('provider')!='all' or h['spec'].get('_source_policy')=='web-storyblocks-first-v1') and
                h.get('key')==key_for(h['spec'],context)),None)
            if source is not None:last=cached
            # Web source selection is a view over the last website search, not another search.
            # Keep the original job/spec/key for Use and feedback ownership checks.
            source_filter=False
            if spec['provider'] in ('all','storyblocks','envato'):
                website=next((h for h in sorted(results(r),key=lambda h:h.get('created',0),reverse=True)
                    if h.get('spec',{}).get('provider') in (('all',spec['provider']) if not spec.get('query') else (spec['provider'],))
                    and h['spec'].get('type')==spec['type']
                    and all(h['spec'].get(k)==spec.get(k) for k in ('query','filters','page'))
                    and (h['spec']['provider']!='all' or h['spec'].get('_source_policy')=='web-storyblocks-first-v1')
                    and h.get('key')==key_for(h['spec'],context)),None)
                if website and not active:
                    spec=dict(website['spec'],provider=spec['provider']);cached=website;last=website
                    result=public(jobs[hydrate(project,uid,website)]);source_filter=True
                if not active and not website:
                    # A prepared All Sources search may still be queued/running when a source is selected.
                    active=next((jid for jid,j in jobs.items() if j.get('project')==project and j.get('uid')==uid
                        and j.get('status') in ('queued','running') and is_automatic_spec(j.get('spec',{}))
                        and j.get('key')==key_for(j['spec'],context)),None)
            last_result=public(jobs[hydrate(project,uid,last)]) if last else None
            return jsonify(spec=spec,result=result,job=active,source_filter=source_filter,stale=bool(r.get('history') and not cached),
                last_result=last_result,history=[{'id':h['id'],'spec':h['spec'],'created':h['created']} for h in r.get('history',[])],background=overview(project))
    @app.post('/api/stock/<project>/preferences')
    def stock_search_preferences(project):
        body=request.get_json(silent=True) or {}
        try:spec=normalize(body.get('spec',{}))
        except ValueError as exc:return jsonify(error=str(exc)),400
        with lock:
            context=snapshot(project,body.get('uid'));save_preferences(project,body['uid'],spec)
            key=key_for(spec,context)
            # Changed settings invalidate queued work immediately, without launching a search on each keystroke.
            for q in queues():
                for jid in list(q):
                    if jobs[jid]['project']==project and jobs[jid]['uid']==body['uid'] and not jobs[jid]['_background'] and jobs[jid]['key']!=key:
                        q.remove(jid);jobs[jid].update(status='cancelled')
        return jsonify(ok=True)
    @app.post('/api/stock/<project>/search')
    def stock_search(project):
        body=request.get_json(silent=True) or {}
        try:jid=enqueue(project,body.get('uid'),body,force=body.get('refresh') is True)
        except ValueError as exc:return jsonify(error=str(exc)),400
        return jsonify(job=jid)
    @app.post('/api/stock/<project>/library-search')
    def stock_library_live(project):
        body=request.get_json(silent=True) or {}
        try:spec=normalize(dict(body,provider='library',type='video',_live=True))
        except ValueError as exc:return jsonify(error=str(exc)),400
        uid=body.get('uid')
        with lock:
            context=snapshot(project,uid);r=save_preferences(project,uid,spec);revision=r['revision'];key=key_for(spec,context)
            cached=next((h for h in results(r) if h.get('key')==key),None)
            if cached and not body.get('refresh'):
                r['last_result']=cached;write_json(path(project,uid),r)
                return jsonify(public(jobs[hydrate(project,uid,cached)]))
        # No model, provider, worker queue or scene save is needed for a typed local query.
        root=stock_library.configured(Path(str(ns['PROJECTS'])).parent/'stock')
        items,more=stock_library.search(root,[spec['query']],spec['filters']['aspect'],page=spec['page'],prefix=True)
        created=time.time();jid=uuid.uuid4().hex
        result=dict(id=jid,key=key,created=created,completed=created,spec=spec,items=items,type='video',provider='library',
                    page=spec['page'],has_more=more,warnings=[] if root else ['Library is not connected on this computer.'])
        with lock:
            snapshot(project,uid);r=record(project,uid)
            if r.get('revision')==revision:
                r['history']=([result]+[h for h in r.get('history',[]) if h.get('key')!=key])[:5]
                r.setdefault('source_results',{})[source_slot(spec)]=result
                r['last_result']=result;write_json(path(project,uid),r)
            hydrate(project,uid,result)
            # Typing can create many completed queries. Keep a bounded set of selectable results.
            live=[(k,j) for k,j in jobs.items() if j.get('spec',{}).get('_live') and j.get('status')=='done']
            for k,_ in sorted(live,key=lambda row:row[1].get('created',0))[:-80]:jobs.pop(k,None)
            return jsonify(public(jobs[jid]))
    @app.get('/api/stock/search/<jid>')
    def stock_search_status(jid):
        with lock:
            j=jobs.get(jid)
            if not j:abort(404)
            return jsonify(public(j))
    @app.route('/api/stock/<project>/background',methods=['GET','POST'])
    def stock_background(project):
        with lock:
            doc=ns['load_doc'](project)
            if doc is None:abort(404)
            if ns['is_youtube'](doc):abort(400)
            if request.method=='POST':
                body=request.get_json(silent=True) or {};cfg=config(project)
                if 'enabled' in body:
                    if type(body['enabled']) is not bool:return jsonify(error='Choose whether to prepare stock in the background.'),400
                    cfg['enabled']=body['enabled']
                if body.get('resume') is True:cfg.pop('paused',None)
                write_json(directory(project)/'settings.json',cfg)
                if quality and (body.get('suspend') is True or not cfg.get('enabled',True)):quality.stop(project)
                for q in queues():
                    for jid in list(q):
                        j=jobs[jid]
                        # A delayed suspend for the previous project must not cancel the newly opened one.
                        stop=(j['project']==project) if body.get('suspend') is True else (j['project']==project and not cfg.get('enabled',True))
                        if automatic_job(j) and stop:
                            q.remove(jid);j.update(status='cancelled',progress='Background preparation stopped.')
                if body.get('suspend') is True or not cfg.get('enabled',True):
                    if scheduler().get('project')==project:
                        scheduler()['scan_epoch']=scheduler().get('scan_epoch',0)+1;scheduler()['scanning']=False
                    for j in jobs.values():
                        if j['project']==project and automatic_job(j) and j.get('status')=='running':
                            j['_stop_requested']=True;j['_cancel_event'].set();j.update(status='cancelled')
                else:begin_preparation(project,body.get('resume') is True,body.get('library') is True)
            return jsonify(overview(project))

    def stop_automatic(message='',paused=False):
        if quality:quality.stop()
        cfg=automatic_config();cfg.update(enabled=False,paused=message if paused else '')
        write_json(automatic_path(),cfg)
        state=scheduler();state['scan_stop']=True;state.pop('scan_pending',None)
        state['scan_epoch']=state.get('scan_epoch',0)+1;state['scanning']=False
        for q in queues():
            for jid in list(q):
                if automatic_job(jobs[jid]):
                    q.remove(jid);jobs[jid].update(status='cancelled',progress='Stock preparation stopped.')
        for j in jobs.values():
            if automatic_job(j) and j.get('status')=='running':
                j['_stop_requested']=True;j['_cancel_event'].set()
                j.update(status='cancelled',progress='Stock preparation stopped.')

    def select_project(project):
        state=scheduler()
        if state.get('project') == project:return
        state['project']=project
        state['scan_epoch']=state.get('scan_epoch',0)+1
        state['scanning']=False
        state.pop('scan_pending',None)
        # Only automatic work belongs to this queue. Preserve explicitly requested searches.
        for q in queues():
            for jid in list(q):
                j=jobs[jid]
                if automatic_job(j) and j['project'] != project:
                    q.remove(jid);j['_stop_requested']=True;j['_cancel_event'].set()
                    j.update(status='cancelled',progress='Another project is now active.')
        for j in jobs.values():
            if automatic_job(j) and j['project'] != project and j.get('status')=='running':
                j['_stop_requested']=True;j['_cancel_event'].set()
                j.update(status='cancelled',progress='Another project is now active.')
        if quality:quality.select_project(project)

    def global_overview(project=None):
        cfg=automatic_config();state=scheduler();project=project or state.get('project')
        summary=state['projects'].get(project,{}) if project else {}
        project_cfg=config(project) if project else {}
        active=[j for j in jobs.values() if automatic_job(j) and j['project']==project and j.get('status') in ('queued','running')]
        running=[j for j in active if j['status']=='running']
        latest={}
        for j in sorted(jobs.values(),key=lambda x:x.get('created',0)):
            if automatic_job(j) and j['project']==project:latest[(j['uid'],source_slot(j['spec']))]=j
        needs_attention=sum(j.get('status')=='error' or (j.get('status')=='done' and bool(j.get('warnings'))) for j in latest.values())
        return dict(needs_attention=needs_attention,enabled=cfg.get('enabled',True) and project_cfg.get('enabled',True),
            paused=cfg.get('paused') or project_cfg.get('paused',''),scanning=bool(project and state.get('project')==project and state.get('scanning')),
            total=summary.get('total',0),ready=summary.get('ready',0),projects=int(bool(project)),project=project,
            library_total=summary.get('library_total',0),library_ready=summary.get('library_ready',0),
            queued=sum(j['status']=='queued' for j in active),running=len(running),stopping=False,current_project=project or '',
            **(quality.progress(project) if quality and project else {}))

    def scan_project(project,resume,epoch):
        try:
            doc=ns['load_doc'](project)
            with lock:
                state=scheduler()
                if state.get('scan_epoch')!=epoch or state.get('scan_stop'):return
                if not doc or ns['is_youtube'](doc):return
                cfg=config(project)
                if not cfg.get('enabled',True) or cfg.get('paused'):return
                revision=library_revision(cfg)
                state['projects'][project]=overview(project)
            for scene in doc.get('scenes',[]):
                with lock:
                    if state.get('scan_epoch')!=epoch or state.get('scan_stop'):return
                    if scene.get('uid') and (scene.get('vo') or scene.get('prompt')):
                        r=record(project,scene['uid'])
                        prepare_scene(project,scene,r,context_for(doc,scene),resume,revision)
        except Exception:
            with lock:
                if scheduler().get('scan_epoch')==epoch:
                    stop_automatic('Could not prepare this project. Use Prepare Stock to try again.',paused=True)
        finally:
            with lock:
                if scheduler().get('scan_epoch')==epoch:scheduler()['scanning']=False

    def begin_preparation(project,resume=False,library=False):
        select_project(project)
        cfg=automatic_config();project_cfg=config(project);state=scheduler()
        if library:project_cfg['library_auto']=True
        if resume:
            project_cfg.pop('paused',None);project_cfg['enabled']=True
            if quality:quality.resume()
            cfg.update(enabled=True,paused='');write_json(automatic_path(),cfg)
        if library or resume:write_json(directory(project)/'settings.json',project_cfg)
        state['projects'][project]=overview(project)
        if not cfg.get('enabled',True) or cfg.get('paused') or not project_cfg.get('enabled',True) or project_cfg.get('paused'):return
        # A newer Split replaces the scan snapshot; a late old scan cannot enqueue or clear its progress.
        epoch=state.get('scan_epoch',0)+1;state['scan_epoch']=epoch
        state['scan_stop']=False;state['scanning']=True
        ns['_KeyThread'](target=scan_project,args=(project,resume,epoch),daemon=True).start()

    @app.route('/api/stock/background',methods=['GET','POST'])
    def stock_background_all():
        with lock:
            body=request.get_json(silent=True) or {} if request.method=='POST' else {}
            project=body.get('project') if request.method=='POST' else request.args.get('project')
            if project is not None:
                if not isinstance(project,str) or not project.strip():return jsonify(error='Choose a VSL project.'),400
                doc=ns['load_doc'](project)
                if doc is None:abort(404)
                if ns['is_youtube'](doc):return jsonify(error='Stock preparation is available in VSL projects.'),400
            if request.method=='POST':
                if body.get('stop') is True:stop_automatic()
                elif project is None:
                    # Never interpret an omitted project as permission to scan the entire account.
                    return jsonify(error='Open a VSL project before preparing stock.'),400
                else:begin_preparation(project,body.get('resume') is True,body.get('library') is True)
            return jsonify(global_overview(project))
