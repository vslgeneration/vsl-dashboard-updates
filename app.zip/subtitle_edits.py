"""Display-only caption edits. Canonical speech and scene timing are never mutated."""
import copy
import hashlib
import json
import math
from pathlib import Path
from collections import OrderedDict
import threading
from functools import lru_cache

_BASE_CACHE = OrderedDict()
_CACHE_LOCK = threading.Lock()


def key(cue):
    raw = [round(cue['start'], 5), round(cue['end'], 5), cue['text']]
    return hashlib.sha256(json.dumps(raw, ensure_ascii=False).encode()).hexdigest()[:24]


def read(directory):
    path = Path(directory) / 'subtitle-display.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text('utf8'))
    if not isinstance(data, dict):
        raise ValueError('Saved subtitle edits are unreadable. Restore the backup before exporting.')
    return data


def validate(edit):
    if not isinstance(edit, dict) or not isinstance(edit.get('text'), str):
        raise ValueError('Enter subtitle text, or leave it empty to hide this caption.')
    text = edit['text'].strip()
    if len(text) > 5000:
        raise ValueError('A single caption can contain at most 5,000 characters.')
    try:
        start, end = float(edit['in']), float(edit['out'])
    except (KeyError, TypeError, ValueError):
        raise ValueError('Enter a valid start and end time.')
    if not all(math.isfinite(t) for t in (start, end)) or not 0 <= start < end <= 1:
        raise ValueError('Keep Start before End and inside this caption’s original time window.')
    return dict(text=text, **{'in': start, 'out': end})


def apply(captions, edits, fps=60):
    import caption_layer
    output = copy.deepcopy(captions)
    for cue in output:
        identity = key(cue)
        base = dict(start=cue['start'], end=cue['end'], text=cue['text'])
        cue.update(display_id=identity, display_base=base, display_edited=False)
        edit = edits.get(identity)
        if edit is None:
            continue
        edit = validate(edit)
        duration = base['end'] - base['start']
        cue.update(start=round(round((base['start'] + duration * edit['in']) * fps) / fps, 5),
                   end=round(round((base['start'] + duration * edit['out']) * fps) / fps, 5),
                   text=edit['text'], display_edited=True)
        if cue['end'] <= cue['start']:
            raise ValueError('A caption must remain visible for at least one frame.')
        # Match only THIS caption's original words. Removing its last words must
        # not squeeze all remaining words into a new uniform speech clock.
        aligned = [(w['start'], w['end'], w['text']) for w in cue.get('words', []) if w.get('aligned')]
        caption_layer.timed_caption_words([cue], aligned)
    return output


def remap_bases(captions, remap):
    for cue in captions:
        base = cue.get('display_base')
        if base:
            base['start'], base['end'] = remap(base['start']), remap(base['end'])


def assemble_base(scenes, cues, total, words, script='', fps=60):
    """Exactly the caption cuts used by Assemble, SRT, rendered video and XML."""
    import premiere_export as pe
    import caption_layer
    stamp = hashlib.sha256(json.dumps([scenes, cues, total, words, fps], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    with _CACHE_LOCK:
        if stamp in _BASE_CACHE:
            _BASE_CACHE.move_to_end(stamp)
            return copy.deepcopy(_BASE_CACHE[stamp])
    starts = pe.word_scene_starts(scenes, words) if words else None
    ranges, included = pe.scene_time_ranges(scenes, cues, total, starts)
    cuts = [a for (a, b), inc in zip(ranges, included) if inc and b > a]
    tokens = pe.accurate_cue_token_times(cues, words) if words else None
    caps = pe.split_captions_at_scenes(cues, cuts, tokens)
    for a, b in zip(caps, caps[1:]):
        if 0 < b['start'] - a['end'] <= .6:
            a['end'] = b['start']
    snap = lambda t: round(round(t * fps) / fps, 5)
    caps = [dict(start=snap(c['start']), end=snap(c['end']), text=c['text'])
            for c in caps if snap(c['end']) > snap(c['start'])]
    caption_layer.timed_caption_words(caps, words)
    with _CACHE_LOCK:
        _BASE_CACHE[stamp] = copy.deepcopy(caps)
        while len(_BASE_CACHE) > 12:
            _BASE_CACHE.popitem(last=False)
    return caps


@lru_cache(maxsize=32)
def _pacing_font(family, size, weight, italic):
    """Read TTF advance widths without a native shaping worker or new dependency."""
    import caption_layer, os, struct
    directory = Path(__file__).parent / 'static/fonts'
    filename = caption_layer._VF.get(family) or caption_layer._SINGLE.get(family)
    if family in caption_layer._STATIC:
        filename = min(caption_layer._STATIC[family], key=lambda face: abs(face[1]-weight))[0]
    name='arial'+('bi' if weight>=600 and italic else 'bd' if weight>=600 else 'i' if italic else '')+'.ttf'
    path=directory/filename if filename else Path(os.environ.get('WINDIR',r'C:\Windows'))/'Fonts'/name
    try:
        raw=path.read_bytes()
        u16=lambda at:struct.unpack_from('>H',raw,at)[0]
        u32=lambda at:struct.unpack_from('>I',raw,at)[0]
        tables={raw[i:i+4].decode('ascii'):u32(i+8) for i in range(12,12+16*u16(4),16)}
        units=u16(tables['head']+18);n=u16(tables['hhea']+34)
        advances=[u16(tables['hmtx']+4*i)*size/units for i in range(n)]
        cmap=tables['cmap'];choices=[]
        for i in range(u16(cmap+2)):
            rec=cmap+4+i*8;platform=u16(rec);encoding=u16(rec+2);offset=cmap+u32(rec+4);form=u16(offset)
            if platform==0 or (platform==3 and encoding in (1,10)):
                if form in (4,12):choices.append((form,offset))
        form,at=max(choices);mapping={}
        if form==12:
            for i in range(u32(at+12)):
                group=at+16+12*i;first,last,glyph=u32(group),u32(group+4),u32(group+8)
                for code in range(first,min(last,0x10ffff)+1):mapping[code]=glyph+code-first
        else:
            count=u16(at+6)//2;ends=at+14;starts=ends+count*2+2;deltas=starts+count*2;ranges=deltas+count*2
            for i in range(count):
                first,last=u16(starts+2*i),u16(ends+2*i);delta=u16(deltas+2*i);distance=u16(ranges+2*i)
                for code in range(first,last+1):
                    glyph=u16(ranges+2*i+distance+2*(code-first)) if distance else code
                    if glyph:mapping[code]=(glyph+delta)&65535
        return {code:advances[min(glyph,n-1)] for code,glyph in mapping.items()}
    except (OSError,ValueError,KeyError,IndexError,struct.error):
        return {}


def pages(cue, config, edits):
    """Shorter display groups for square/portrait, using existing speech stamps.

    Original cues and scripts stay canonical. Authored line breaks and edited
    page boundaries take precedence over automatic regrouping.
    """
    if not config or not cue.get('text','').strip():return [cue]
    W,H=config.get('width',1920),config.get('height',1080)
    if not W or not H or W/H>1.1:return [cue]
    words=cue.get('words') or []
    if len(words)<3:return [cue]
    from render_video import cap_units
    breaks=set();count=0
    for i,line in enumerate(cue['text'].replace('\r\n','\n').replace('\r','\n').split('\n')):
        if i:breaks.add(count)
        count+=len(cap_units(line))
    parent=key(cue)
    slices=None
    # A user's edit freezes this parent's cuts. Changing font/preset later must
    # never orphan the edit merely because the automatic width budget changed.
    for edit in edits.values():
        plan=edit.get('page_slices')
        if edit.get('page_parent')!=parent or not isinstance(plan,list):continue
        if (len(plan)>1 and all(isinstance(p,list) and len(p)==2 and all(type(n) is int for n in p) for p in plan)
            and plan[0][0]==0 and plan[-1][1]==len(words) and all(0<=a<b<=len(words) for a,b in plan)
            and all(a[1]==b[0] for a,b in zip(plan,plan[1:]))):
            slices=plan;break
    if slices is None:
        st=config.get('style') or {}
        size=max(12,min(400,float(st.get('ost_size') or 46)))
        weight=800 if st.get('ost_bold') else int(st.get('ost_weight') or 400)
        font=_pacing_font(st.get('ost_font') or 'Arial',round(size),weight,bool(st.get('ost_italic')))
        pop=st.get('sub_effect')=='word-pop'
        letter=float(st.get('ost_letter') or 0)
        padding=float(st.get('ost_bg_pad',14)) if st.get('ost_bg') else size*.19 if pop else 0
        # Leave a small measurement margin for browser rasterization and pop overshoot.
        width=max(size,W*max(20,min(96,float(st.get('sub_width') or 86)))/100-2*padding-size*.14)
        measure=lambda text:sum(font.get(ord(ch),size*.6) for ch in (text.upper() if st.get('ost_upper') else text))+letter*len(text)
        space=max(measure(' '),size*.32 if pop else 0)
        widths=[measure(w['text']) for w in words]
        rows_limit=1 if str(st.get('sub_lines'))=='1' else 2
        max_words=7 if W/H<.7 else 8
        def fits(a,b):
            if st.get('sub_effect') not in ('word-pop','word-box','word-fill'):
                # Classic balances lines before CSS wrapping. Account for those
                # actual breaks too, so a wide first line cannot create row three.
                from render_video import _sub_wrap_lines
                import project_canvas
                text=''.join(('\n' if i in breaks else ' ')+w['text'] if i>a else w['text'] for i,w in enumerate(words[a:b],a))
                with project_canvas.scope(dims=(W,H)):lines=_sub_wrap_lines(text,st)
                rows=0
                for line in lines:
                    rows+=1;used=0
                    for token in cap_units(line):
                        amount=measure(token)
                        if used and used+space+amount>width:rows+=1;used=0
                        if amount>width:rows+=math.ceil(amount/width)-1
                        used=(used+space if used else 0)+amount
                return rows<=rows_limit
            rows=1;used=0
            for i,amount in enumerate(widths[a:b],a):
                if i>a and i in breaks:rows+=1;used=0
                if used and used+space+amount>width:rows+=1;used=0
                if amount>width:rows+=math.ceil(amount/width)-1
                used=(used+space if used else 0)+amount
            return rows<=rows_limit
        if len(words)<=max_words and cue['end']-cue['start']<=4 and fits(0,len(words)):return [cue]
        slices=[];a=0
        while a<len(words):
            end=a+1
            while end<len(words) and end-a<max_words and fits(a,end+1) and words[end]['end']-words[a]['start']<=4:
                end+=1
            # Prefer nearby punctuation; avoid a lone trailing word and flashes.
            choices=[]
            for b in range(max(a+2,end-2),end+1):
                if b>=len(words):choices.append((100,b));continue
                left=words[b]['start']-(cue['start'] if a==0 else words[a]['start'])
                right=cue['end']-words[b]['start']
                if left<.65 or right<.65:continue
                mark=words[b-1]['text'].rstrip().rstrip('"”’')
                score=(3 if mark.endswith(('.', '!', '?', ';', ':')) else 2 if mark.endswith(',') else 0)
                score-=abs(end-b)*.7
                if len(words)-b==1:score-=4
                choices.append((score,b))
            if choices:end=max(choices)[1]
            # Collapsed alignment stamps cannot form a new visible interval.
            while end<len(words) and words[end]['start']-(cue['start'] if a==0 else words[a]['start'])<.35:end+=1
            if end<len(words) and cue['end']-words[end]['start']<.35:end=len(words)
            slices.append([a,end]);a=end
        if len(slices)<2:return [cue]
    result=[]
    boundaries=[cue['start']]+[round(round(words[a]['start']*60)/60,5) for a,b in slices[1:]]+[cue['end']]
    if any(b<=a for a,b in zip(boundaries,boundaries[1:])):return [cue]
    for i,(a,b) in enumerate(slices):
        page=copy.deepcopy(cue)
        for field in ('display_id','display_base','display_edited'):page.pop(field,None)
        text=''.join(('\n' if i in breaks else ' ')+w['text'] if i>a else w['text'] for i,w in enumerate(words[a:b],a))
        page.update(text=text,words=copy.deepcopy(words[a:b]),
                    start=boundaries[i],end=boundaries[i+1],page_parent=parent,page_slices=slices)
        result.append(page)
    return result
