"""Display-only caption edits. Canonical speech and scene timing are never mutated."""
import copy
import hashlib
import json
import math
import re
from pathlib import Path
from collections import OrderedDict
import threading
from functools import lru_cache

_BASE_CACHE = OrderedDict()
_CACHE_LOCK = threading.Lock()
CANONICAL_POLICY = 'speech-v998'


def canonical(cue):
    return cue.get('_caption_policy') == CANONICAL_POLICY


def word_spans(cue):
    """Slice the original Unicode text, retaining its punctuation and spacing.

    Word timing may bind a separated mark with NBSP. Match without whitespace,
    then use original character offsets instead of rebuilding the spoken text.
    """
    text = str(cue.get('text', ''))
    positions = [i for i, char in enumerate(text) if not char.isspace()]
    compact = ''.join(text[i] for i in positions)
    spans = []; offset = 0
    for word in cue.get('words') or []:
        token = ''.join(str(word.get('text', '')).split())
        if not token or compact[offset:offset + len(token)] != token:
            raise ValueError('Caption words no longer match the saved text. Reopen the subtitle editor before exporting.')
        spans.append((positions[offset], positions[offset + len(token) - 1] + 1))
        offset += len(token)
    if offset != len(compact):
        raise ValueError('Caption words no longer match the saved text. Reopen the subtitle editor before exporting.')
    return spans


def word_slice_text(cue, first, last):
    text = str(cue.get('text', ''))
    spans = word_spans(cue)
    if not 0 <= first < last <= len(spans):
        raise ValueError('Caption words no longer match the saved text. Reopen the subtitle editor before exporting.')
    return text[spans[first][0]:spans[last - 1][1]]


def canonical_words(captions, aligned, plan):
    """Restore authoritative token clocks; repeated/CJK text needs no rematching."""
    from render_video import _cap_bind
    from subtitle.phrase_store import canonical_rows
    if not isinstance(plan,dict):raise ValueError('The caption phrase plan is unreadable.')
    aligned=[(start,end,text) for text,start,end in canonical_rows(plan,[(w[2],w[0],w[1]) for w in aligned])]
    groups = plan.get('groups') if isinstance(plan, dict) else None
    if (not isinstance(plan, dict) or plan.get('schema') != 1 or plan.get('policy') != CANONICAL_POLICY
            or plan.get('token_count') != len(aligned) or not isinstance(groups, list) or len(groups) != len(captions)):
        raise ValueError('The caption phrase plan does not match its speech track. Regenerate subtitles.')
    previous = 0
    for cue, group in zip(captions, groups):
        a,b=group.get('a'),group.get('b')
        if (type(a) is not int or type(b) is not int or a != previous or not a < b <= len(aligned)
                or group.get('text') != cue['text']
                or any(type(group.get(k)) not in (int,float) or not math.isfinite(group[k]) or abs(group[k]-cue[k]) > .0011 for k in ('start','end'))):
            raise ValueError('The caption phrase plan does not match its speech track. Regenerate subtitles.')
        previous = b
        rows=aligned[a:b];texts=[str(w[2]) for w in rows];units=[]
        for i,(start,end,text) in enumerate(rows):
            if not all(type(t) in (int,float) and math.isfinite(t) for t in (start,end)) or end < start:
                raise ValueError('The caption phrase plan contains invalid word times.')
            lo,hi=max(cue['start'],start),min(cue['end'],end)
            if units and a+i not in group.get('line_breaks',[]) and (_cap_bind(texts,i)=='back' or _cap_bind(texts,i-1)=='fwd'):
                units[-1]['text']+=' '+str(text);units[-1]['end']=max(units[-1]['end'],hi)
            else:units.append(dict(text=str(text),start=lo,end=max(lo,hi),aligned=True))
        cue['words']=units;cue['word_timing']='aligned'
        spans=word_spans(cue)
        for i,(word,(lo,hi)) in enumerate(zip(units,spans)):
            word['text']=cue['text'][lo:hi]
            word['_separator']=cue['text'][spans[i-1][1]:lo] if i else ''
    if previous != len(aligned):raise ValueError('The caption phrase plan does not cover its speech track.')


def key(cue):
    raw = [round(cue['start'], 5), round(cue['end'], 5), cue['text']]
    return hashlib.sha256(json.dumps(raw, ensure_ascii=False).encode()).hexdigest()[:24]


def path(directory, write=False, selected=None):
    """One selected subtitle set owns both its track and its display choices."""
    import subtitle_store
    selected = Path(selected) if selected is not None else subtitle_store.active_dir(directory)
    manifest = selected / '_result.json'
    if manifest.is_file():
        metadata = json.loads(manifest.read_text('utf8'))
        scoped = metadata.get('display_edits_file') if isinstance(metadata, dict) else None
        if scoped is not None:
            if scoped != 'subtitle-display.json':raise ValueError('Invalid subtitle display edit record.')
            target = selected / scoped
            if not target.resolve().is_relative_to(selected.resolve()):raise ValueError('Invalid subtitle display edit path.')
            return target
    target = Path(directory) / 'subtitle-display.json'
    if not write and not target.exists():
        document=Path(directory)/'scenes.json'
        doc=json.loads(document.read_text('utf8')) if document.is_file() else {}
        reviewed=(doc.get('speaker_package') or {}).get('reviewed_subtitles')
        if not reviewed:return target
        from speaker_package import local
        target=local(directory,reviewed)/'subtitle-display.json'
    return target


def read(directory, selected=None):
    target = path(directory, selected=selected)
    if not target.exists():return {}
    data = json.loads(target.read_text('utf8'))
    if not isinstance(data, dict):
        raise ValueError('Saved subtitle edits are unreadable. Restore the backup before exporting.')
    return data


def validate(edit, total=None):
    if not isinstance(edit, dict) or not isinstance(edit.get('text'), str):
        raise ValueError('Enter subtitle text, or leave it empty to hide this caption.')
    text = edit['text'].strip()
    if len(text) > 5000:
        raise ValueError('A single caption can contain at most 5,000 characters.')
    if 'start' in edit or 'end' in edit:
        try: start,end=float(edit['start']),float(edit['end'])
        except (KeyError,TypeError,ValueError):raise ValueError('Enter a valid start and end time.')
        if not all(math.isfinite(t) for t in (start,end)) or start<0 or end-start<1/60 or (total is not None and end>total+.011):
            raise ValueError('Keep Start before End and inside the video or voice-over duration.')
        return dict(text=text,start=start,end=end)
    try:
        start, end = float(edit['in']), float(edit['out'])
    except (KeyError, TypeError, ValueError):
        raise ValueError('Enter a valid start and end time.')
    if not all(math.isfinite(t) for t in (start, end)) or not 0 <= start < end <= 1:
        raise ValueError('Keep Start before End and inside this caption’s original time window.')
    return dict(text=text, **{'in': start, 'out': end})


def apply(captions, edits, fps=60):
    import caption_layer
    output = copy.deepcopy(captions)
    for cue in output:
        identity = key(cue)
        base = dict(start=cue['start'], end=cue['end'], text=cue['text'])
        cue.update(display_id=identity, display_base=base, display_edited=False)
        edit = edits.get(identity)
        if edit is None:
            continue
        cue['display_deleted'] = bool(edit.get('deleted'))
        edit = validate(edit)
        duration = base['end'] - base['start']
        absolute='start' in edit
        start=edit['start'] if absolute else base['start']+duration*edit['in']
        end=edit['end'] if absolute else base['start']+duration*edit['out']
        cue.update(start=round(round(start * fps) / fps, 5),
                   end=round(round(end * fps) / fps, 5),display_timing=absolute,
                   text=edit['text'], display_edited=True)
        if cue['end'] <= cue['start']:
            raise ValueError('A caption must remain visible for at least one frame.')
        # Match only THIS caption's original words. Removing its last words must
        # not squeeze all remaining words into a new uniform speech clock.
        aligned = [(w['start'], w['end'], w['text']) for w in cue.get('words', []) if w.get('aligned')]
        caption_layer.timed_caption_words([cue], aligned)
    return output


def remap_bases(captions, remap):
    for cue in captions:
        base = cue.get('display_base')
        if base:
            base['start'], base['end'] = remap(base['start']), remap(base['end'])


def assemble_base(scenes, cues, total, words, script='', fps=60, speech_clock=False, caption_policy=None, phrase_plan=None):
    """Exactly the caption cuts used by Assemble, SRT, rendered video and XML."""
    import premiere_export as pe
    import caption_layer
    stamp = hashlib.sha256(json.dumps([scenes, cues, total, words, fps, speech_clock, caption_policy, phrase_plan], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    with _CACHE_LOCK:
        if stamp in _BASE_CACHE:
            _BASE_CACHE.move_to_end(stamp)
            return copy.deepcopy(_BASE_CACHE[stamp])
    if caption_policy == CANONICAL_POLICY:
        # Generation already chose semantic groups and the exact speech clock.
        # Font, aspect, scene boundaries and OST must not re-author this track.
        caps = copy.deepcopy(cues)
        for cue in caps:
            if (not isinstance(cue.get('text'), str)
                    or any(type(cue.get(k)) not in (int, float) or not math.isfinite(cue[k]) for k in ('start', 'end'))
                    or cue['start'] < 0 or cue['end'] <= cue['start']):
                raise ValueError('The generated caption track contains an invalid cue.')
            cue['_caption_policy'] = CANONICAL_POLICY
            cue.pop('_scene_sync', None)
            cue.pop('_speech_onset', None)
        if phrase_plan is not None:
            canonical_words(caps, words, phrase_plan)
        else:
            caption_layer.timed_caption_words(caps, words)
        with _CACHE_LOCK:
            _BASE_CACHE[stamp] = copy.deepcopy(caps)
            while len(_BASE_CACHE) > 12:
                _BASE_CACHE.popitem(last=False)
        return caps
    starts = pe.word_scene_starts(scenes, words) if words else None
    ranges, included = pe.scene_time_ranges(scenes, cues, total, starts)
    cuts = [a for (a, b), inc in zip(ranges, included) if inc and b > a]
    tokens = pe.accurate_cue_token_times(cues, words) if words else None
    # Preserve editor identities from older protected packages, even though
    # their delivery clock now follows speech instead of imported visual cuts.
    legacy_cuts=cuts
    if not speech_clock and any(s.get('editorial_timing') for s in scenes):
        historical,legacy_inc=pe.scene_time_ranges(scenes,cues,total)
        legacy_cuts=[a for (a,b),inc in zip(historical,legacy_inc) if inc and b>a]
    caps = copy.deepcopy(cues) if speech_clock else pe.split_captions_at_scenes(cues, legacy_cuts, tokens)
    for a, b in zip(caps, caps[1:]):
        if 0 < b['start'] - a['end'] <= .6:
            a['end'] = b['start']
    snap = (lambda t: round(pe.frame_time(t,fps),5)) if speech_clock else (lambda t: round(round(t*fps)/fps,5))
    caps = [dict(start=snap(c['start']), end=snap(c['end']), text=c['text'])
            for c in caps if snap(c['end']) > snap(c['start'])]
    caption_layer.timed_caption_words(caps, words)
    # Keep the historical base times/IDs: changing those would orphan saved text,
    # hidden cues and portrait page edits. Apply clock correction only after those
    # display choices have been resolved by subtitle_ost.display.
    if caps:
        if words:
            onsets=pe.accurate_cue_token_times(caps,words)
            for cue,ts in zip(caps,onsets or []):
                if ts:cue['_speech_onset']=pe.frame_time(ts[0],fps)
        caps[0]['_scene_sync'] = [dict(time=a, words=pe._norm_words(s.get('vo'))[:3])
                                for s,(a,b),inc in zip(scenes,ranges,included)
                                if inc and b>a and not s.get('speaker_clip')]
    with _CACHE_LOCK:
        _BASE_CACHE[stamp] = copy.deepcopy(caps)
        while len(_BASE_CACHE) > 12:
            _BASE_CACHE.popitem(last=False)
    return caps


def speech_sync(captions, fps=60):
    """Retain authored edits, align automatic captions before OST word hiding."""
    import premiere_export as pe
    out=copy.deepcopy(captions)
    authored=lambda c: bool(canonical(c) or c.get('display_edited') or c.get('display_timing') or
                            c.get('display_custom') or c.get('display_deleted') or not c.get('text','').strip())
    for c in out:
        if not authored(c) and c.get('_speech_onset') is not None:
            c['start']=pe.frame_time(c['_speech_onset'],fps)
            if c.get('words'):c['words'][0]['start']=c['start']
    for left,right in zip(out,out[1:]):
        if not authored(left) and not authored(right):
            if right['start']<=left['start']:raise ValueError('Measured caption starts overlap; regenerate subtitles.')
            left['end']=right['start']
    return out


def sync_display(captions, cuts, blocked=(), fps=60, edits=None):
    """Resolve automatic display boundaries on the scene/VO frame clock.

    Editor identities and display_base remain on the saved, historical clock.
    Explicit timing, hidden words and custom captions always take precedence.
    """
    import premiere_export as pe
    out=copy.deepcopy(captions)
    blocked=list(blocked)
    def authored(c):
        return bool(canonical(c) or c.get('display_edited') or c.get('display_timing') or
                    c.get('display_custom') or c.get('auto_ost') or not c.get('text','').strip())
    for c in out:
        c.pop('_scene_sync',None)
        if not canonical(c):
            c['start'],c['end']=pe.frame_time(c['start'],fps),pe.frame_time(c['end'],fps)
    def matches_scene_prefix(index, text, needle):
        # A trailing "it." is not the next scene's "It costs ...". Compare
        # the full known prefix, looking into adjacent automatic caption pages
        # when the candidate itself has fewer words. Never cross an authored gap.
        first=pe._norm_words(text)[:len(needle)]
        end=out[index]['end']
        for following in out[index+1:]:
            if len(first)>=len(needle):break
            if authored(following) or following['start']-end>.6:break
            first.extend(pe._norm_words(following['text'])[:len(needle)-len(first)])
            end=following['end']
        return bool(needle) and first==needle
    for cut in cuts:
        t=pe.frame_time(cut['time'],fps);words=cut['words']
        matches=[]
        for i,c in enumerate(out):
            if authored(c) or abs(c['start']-t)>.5 or t>c['end']-1/fps+1e-8:continue
            if not matches_scene_prefix(i,c['text'],words):continue
            if i and t<=out[i-1]['start']:continue
            if i and authored(out[i-1]) and t<out[i-1]['end']-1e-7:continue
            if any(min(c['start'],t)<b and max(c['start'],t)>a for a,b in blocked):continue
            matches.append((abs(c['start']-t),i))
        if matches:
            _,i=min(matches);c=out[i];old=c['start'];c['start']=t
            # The old cue start may have clamped the first aligned word late.
            if c.get('words') and abs(c['words'][0]['start']-old)<1/fps:
                c['words'][0]['start']=t
    # A manually split scene can be shorter than the historical 0.30s caption
    # split threshold. Split its words at the real cut too; never duplicate or
    # drop a word. New pieces get independent, stable editable identities.
    pieces=[]
    for i,c in enumerate(out):
        ws=c.get('words') or [];points=[]
        if not authored(c):
            for cut in cuts:
                t=pe.frame_time(cut['time'],fps)
                if t<c['start']+1/fps-1e-8 or t>c['end']-1/fps+1e-8:continue
                candidates=[]
                for k in range(1,len(ws)):
                    needle=cut['words']
                    if matches_scene_prefix(i,' '.join(w['text'] for w in ws[k:k+3]),needle) and abs(ws[k]['start']-t)<=.5:
                        candidates.append((abs(ws[k]['start']-t),k))
                if candidates:
                    k=min(candidates)[1]
                    if not points or (t>points[-1][1] and k>points[-1][0]):points.append((k,t))
        if not points:
            pieces.append(c);continue
        indexes=[0]+[k for k,t in points]+[len(ws)]
        times=[c['start']]+[t for k,t in points]+[c['end']]
        for j,(a,b) in enumerate(zip(indexes,indexes[1:])):
            raw=dict(start=times[j],end=times[j+1],text=' '.join(w['text'] for w in ws[a:b]),words=copy.deepcopy(ws[a:b]),word_timing=c.get('word_timing'))
            if c.get('_visibility_owner'):raw['_visibility_owner']=c['_visibility_owner']
            if c.get('_visibility_word_keys'):raw['_visibility_word_keys']=copy.deepcopy(c['_visibility_word_keys'][a:b])
            piece=apply([raw],edits or {},fps)[0]
            piece['_sync_base']=raw
            if piece.get('display_deleted'):blocked.append((raw['start'],raw['end']))
            if not piece.get('display_deleted'):pieces.append(piece)
    out=sorted(pieces,key=lambda c:(c['start'],c['end']))
    for a,b in zip(out,out[1:]):
        if authored(a) or authored(b):continue
        if any(a['end']<end and b['start']>start for start,end in blocked):continue
        if b['start']>a['start']:
            # One shared exclusive boundary: never end a frame before the next cue.
            a['end']=b['start']
    return out


@lru_cache(maxsize=32)
def _pacing_font(family, size, weight, italic):
    """Read TTF advance widths without a native shaping worker or new dependency."""
    import caption_layer, os, struct
    directory = Path(__file__).parent / 'static/fonts'
    filename = caption_layer._VF.get(family) or caption_layer._SINGLE.get(family)
    if family in caption_layer._STATIC:
        filename = min(caption_layer._STATIC[family], key=lambda face: abs(face[1]-weight))[0]
    name='arial'+('bi' if weight>=600 and italic else 'bd' if weight>=600 else 'i' if italic else '')+'.ttf'
    path=directory/filename if filename else Path(os.environ.get('WINDIR',r'C:\Windows'))/'Fonts'/name
    try:
        raw=path.read_bytes()
        u16=lambda at:struct.unpack_from('>H',raw,at)[0]
        u32=lambda at:struct.unpack_from('>I',raw,at)[0]
        tables={raw[i:i+4].decode('ascii'):u32(i+8) for i in range(12,12+16*u16(4),16)}
        units=u16(tables['head']+18);n=u16(tables['hhea']+34)
        advances=[u16(tables['hmtx']+4*i)*size/units for i in range(n)]
        cmap=tables['cmap'];choices=[]
        for i in range(u16(cmap+2)):
            rec=cmap+4+i*8;platform=u16(rec);encoding=u16(rec+2);offset=cmap+u32(rec+4);form=u16(offset)
            if platform==0 or (platform==3 and encoding in (1,10)):
                if form in (4,12):choices.append((form,offset))
        form,at=max(choices);mapping={}
        if form==12:
            for i in range(u32(at+12)):
                group=at+16+12*i;first,last,glyph=u32(group),u32(group+4),u32(group+8)
                for code in range(first,min(last,0x10ffff)+1):mapping[code]=glyph+code-first
        else:
            count=u16(at+6)//2;ends=at+14;starts=ends+count*2+2;deltas=starts+count*2;ranges=deltas+count*2
            for i in range(count):
                first,last=u16(starts+2*i),u16(ends+2*i);delta=u16(deltas+2*i);distance=u16(ranges+2*i)
                for code in range(first,last+1):
                    glyph=u16(ranges+2*i+distance+2*(code-first)) if distance else code
                    if glyph:mapping[code]=(glyph+delta)&65535
        return {code:advances[min(glyph,n-1)] for code,glyph in mapping.items()}
    except (OSError,ValueError,KeyError,IndexError,struct.error):
        return {}


_PHRASE_GLUE = {
    'en': 'a an the and or but of to for with from into your my our their its is are was were has have will can not',
    'fr': 'le la les un une des du de au aux et ou mais à pour avec sans mon ma mes votre vos est sont ne',
    'de': 'der die das den dem des ein eine einen einem und oder aber von zu für mit ohne mein meine dein deine ist sind nicht',
    'es': 'el la los las un una unos unas de del al y o pero para con sin mi mis tu tus su sus es son no',
    'it': 'il lo la i gli le un uno una di del della al alla e o ma per con senza mio mia tuo tua è sono non',
    'tr': 've veya ama ile için bir bu şu o çok daha en her',
}


def _phrase_boundary(words, index, lang):
    """Prefer measured pauses and punctuation, keeping small phrase units together."""
    left=words[index-1]['text'].strip();right=words[index]['text'].strip()
    # Quotes, split numbers and units must never be stranded on a different page.
    if (re.fullmatch(r'[«‹„“¿¡(\[{]+',left) or re.fullmatch(r'[»›”!?.,;:%‰°)\]}]+',right)
        or (re.fullmatch(r'\d{1,3}',left) and re.match(r'^\d{3}(?:\D|$)',right))
        or (re.search(r'\d$',left) and re.match(r'^(?:[%‰€$£]|kg\b|mg\b|ml\b|cm\b)',right,re.I))):
        return None
    mark=left.rstrip('"”’»›)]}')
    punctuation=3 if mark.endswith(('.', '!', '?', '…', ';', ':')) else 2 if mark.endswith((',', '—', '–')) else 0
    gap=max(0,words[index]['start']-words[index-1]['end'])
    aligned=words[index].get('aligned') and words[index-1].get('aligned')
    score=punctuation+(min(3,(gap-.10)*8) if aligned and gap>.10 else 0)
    bare=mark.casefold().strip('.,;:!?…')
    glue=set(_PHRASE_GLUE.get(str(lang).lower().split('-')[0],_PHRASE_GLUE['en']).split())
    if not punctuation and (bare in glue or left.endswith(("'",'’'))):score-=5
    if not punctuation and re.fullmatch(r'(?:is|are|was|were|of|est|sont|ist|sind)',right.casefold()):score-=3
    return score


def pages(cue, config, edits):
    """Readable display groups, using existing speech stamps and natural pauses.

    Original cues and scripts stay canonical. Authored line breaks and edited
    page boundaries take precedence over automatic regrouping.
    """
    if canonical(cue) or cue.get('display_timing') or not config or not cue.get('text','').strip():return [cue]
    W,H=config.get('width',1920),config.get('height',1080)
    vsl=bool(config.get('vsl'))
    if not W or not H or (W/H>1.1 and not vsl):return [cue]
    words=cue.get('words') or []
    if len(words)<3:return [cue]
    from render_video import cap_units
    breaks=set();count=0
    for i,line in enumerate(cue['text'].replace('\r\n','\n').replace('\r','\n').split('\n')):
        if i:breaks.add(count)
        count+=len(cap_units(line))
    parent=key(cue)
    slices=None
    # A user's edit freezes this parent's cuts. Changing font/preset later must
    # never orphan the edit merely because the automatic width budget changed.
    for edit in edits.values():
        plan=edit.get('page_slices')
        if edit.get('page_parent')!=parent or not isinstance(plan,list):continue
        if (len(plan)>1 and all(isinstance(p,list) and len(p)==2 and all(type(n) is int for n in p) for p in plan)
            and plan[0][0]==0 and plan[-1][1]==len(words) and all(0<=a<b<=len(words) for a,b in plan)
            and all(a[1]==b[0] for a,b in zip(plan,plan[1:]))):
            slices=plan;break
    if slices is None:
        if vsl and cue.get('display_edited'):return [cue]
        st=config.get('style') or {}
        size=max(12,min(400,float(st.get('ost_size') or 46)))
        weight=800 if st.get('ost_bold') else int(st.get('ost_weight') or 400)
        font=_pacing_font(st.get('ost_font') or 'Arial',round(size),weight,bool(st.get('ost_italic')))
        pop=st.get('sub_effect')=='word-pop'
        letter=float(st.get('ost_letter') or 0)
        padding=float(st.get('ost_bg_pad',14)) if st.get('ost_bg') else size*.19 if pop else 0
        # Leave a small measurement margin for browser rasterization and pop overshoot.
        width=max(size,W*max(20,min(96,float(st.get('sub_width') or 86)))/100-2*padding-size*.14)
        measure=lambda text:sum(font.get(ord(ch),size*.6) for ch in (text.upper() if st.get('ost_upper') else text))+letter*len(text)
        space=max(measure(' '),size*.32 if pop else 0)
        widths=[measure(w['text']) for w in words]
        rows_limit=1 if str(st.get('sub_lines'))=='1' else 2
        max_words=7 if W/H<.7 else 8 if W/H<=1.1 else 10
        max_seconds=4.5 if W/H>1.1 else 4
        def fits(a,b):
            if st.get('sub_effect') not in ('word-pop','word-box','word-fill'):
                # Classic balances lines before CSS wrapping. Account for those
                # actual breaks too, so a wide first line cannot create row three.
                from render_video import _sub_wrap_lines
                import project_canvas
                text=''.join(('\n' if i in breaks else ' ')+w['text'] if i>a else w['text'] for i,w in enumerate(words[a:b],a))
                with project_canvas.scope(dims=(W,H)):lines=_sub_wrap_lines(text,st)
                rows=0
                for line in lines:
                    rows+=1;used=0
                    for token in cap_units(line):
                        amount=measure(token)
                        if used and used+space+amount>width:rows+=1;used=0
                        if amount>width:rows+=math.ceil(amount/width)-1
                        used=(used+space if used else 0)+amount
                return rows<=rows_limit
            rows=1;used=0
            for i,amount in enumerate(widths[a:b],a):
                if i>a and i in breaks:rows+=1;used=0
                if used and used+space+amount>width:rows+=1;used=0
                if amount>width:rows+=math.ceil(amount/width)-1
                used=(used+space if used else 0)+amount
            return rows<=rows_limit
        if len(words)<=max_words and cue['end']-cue['start']<=max_seconds and fits(0,len(words)):return [cue]
        slices=[];a=0
        while a<len(words):
            end=a+1
            while end<len(words) and end-a<max_words and fits(a,end+1) and words[end]['end']-words[a]['start']<=max_seconds:
                end+=1
            # Prefer nearby punctuation; avoid a lone trailing word and flashes.
            choices=[]
            pages_left=max(1,math.ceil((len(words)-a)/max(1,end-a)),math.ceil((cue['end']-words[a]['start'])/max_seconds))
            target=(len(words)-a)/pages_left
            for b in range(a+2 if vsl else max(a+2,end-2),end+1):
                if b>=len(words):choices.append((100,b));continue
                left=words[b]['start']-(cue['start'] if a==0 else words[a]['start'])
                right=cue['end']-words[b]['start']
                if left<.65 or right<.65:continue
                if vsl:
                    score=_phrase_boundary(words,b,config.get('lang','en'))
                    if score is None:continue
                    score-=abs(b-a-target)*.8
                else:
                    mark=words[b-1]['text'].rstrip().rstrip('"”’')
                    score=(3 if mark.endswith(('.', '!', '?', ';', ':')) else 2 if mark.endswith(',') else 0)
                    score-=abs(end-b)*.7
                if len(words)-b==1:score-=4
                choices.append((score,b))
            if choices:end=max(choices)[1]
            # Collapsed alignment stamps cannot form a new visible interval.
            while end<len(words) and words[end]['start']-(cue['start'] if a==0 else words[a]['start'])<.35:end+=1
            if end<len(words) and cue['end']-words[end]['start']<.35:end=len(words)
            if vsl:
                while end<len(words) and _phrase_boundary(words,end,config.get('lang','en')) is None:end+=1
            slices.append([a,end]);a=end
        if len(slices)<2:return [cue]
    result=[]
    boundaries=[cue['start']]+[round(round(words[a]['start']*60)/60,5) for a,b in slices[1:]]+[cue['end']]
    if any(b<=a for a,b in zip(boundaries,boundaries[1:])):return [cue]
    for i,(a,b) in enumerate(slices):
        page=copy.deepcopy(cue)
        for field in ('display_id','display_base','display_edited'):page.pop(field,None)
        text=''.join(('\n' if i in breaks else ' ')+w['text'] if i>a else w['text'] for i,w in enumerate(words[a:b],a))
        page.update(text=text,words=copy.deepcopy(words[a:b]),
                    start=boundaries[i],end=boundaries[i+1],page_parent=parent,page_slices=slices)
        if cue.get('_visibility_word_keys'):page['_visibility_word_keys']=copy.deepcopy(cue['_visibility_word_keys'][a:b])
        result.append(page)
    return result


def custom_validate(value, total=None):
    if not isinstance(value, dict) or not isinstance(value.get('text'), str):
        raise ValueError('Enter subtitle text.')
    text=value['text'].strip()
    if not text or len(text)>5000:
        raise ValueError('Enter between 1 and 5,000 characters.')
    try: start,end=float(value['start']),float(value['end'])
    except (KeyError,TypeError,ValueError): raise ValueError('Enter a valid start and end time.')
    if not all(math.isfinite(t) for t in (start,end)) or start<0 or end-start<1/60 or (total is not None and end>total+.011):
        raise ValueError('Keep Start before End and inside the video or voice-over duration.')
    start,end=round(round(start*60)/60,5),round(round(end*60)/60,5)
    if end<=start: raise ValueError('A caption must remain visible for at least one frame.')
    return dict(custom=True,text=text,start=start,end=end)


def custom_captions(edits):
    import caption_layer
    output=[]
    for identity,record in edits.items():
        if not identity.startswith('custom_') or not record.get('custom'):continue
        value=custom_validate(record)
        cue={k:value[k] for k in ('text','start','end')}
        cue.update(display_id=identity,display_custom=True,display_edited=True,display_base=dict(cue))
        caption_layer.timed_caption_words([cue],[])
        output.append(cue)
    return output


def _rebind_visibility_edits(edits, old_base, new_base, result):
    """Carry explicit choices across regrouping of the same measured words."""
    import subtitle_ost as so
    if not any(k.startswith('visibility_') for k in edits):return []
    if old_base is None:raise ValueError('The original subtitle track is required to preserve visibility choices.')
    source=so.visibility_source(old_base);target=so.visibility_source(new_base)
    active={r['_id']:r for r in so.visibility_rules(edits,source)}
    owners={key(c):c for c in old_base};flat=[]
    for ci,cue in enumerate(new_base):
        for wi,word in enumerate(cue.get('words',[])):
            for token in so.tokens(word['text']):flat.append((token,ci,wi,word))
    hay=[r[0] for r in flat];records=[]
    order=max((r.get('order',0) for k,r in result.items() if k.startswith('visibility_')),default=0)
    for identity,raw in sorted(((k,v) for k,v in edits.items() if k.startswith('visibility_')),key=lambda kv:kv[1].get('order',0)):
        if identity not in active:
            # Keep stale records inert; they never acquire the new source hash.
            result[identity]=copy.deepcopy(raw);records.append(dict(original_id=identity,kind='inactive_visibility',visibility_rules=[identity],replacement=None));continue
        rule=active[identity];owner=rule['owner']
        if owner.startswith('custom_'):
            if owner not in result:raise ValueError('A subtitle visibility choice lost its custom caption: '+identity)
            result[identity]=copy.deepcopy(raw);result[identity].update(source=target,order=order+1);order+=1
            records.append(dict(original_id=identity,kind='visibility',visibility_rules=[identity],replacement=None));continue
        original=owners.get(owner)
        if original is None:raise ValueError('A subtitle visibility choice lost its source caption: '+identity)
        old_words=[]
        for wanted in rule['words']:
            hits=[w for w in original.get('words',[]) if so.word_key(w)==wanted]
            if len(hits)!=1:raise ValueError('A subtitle visibility choice no longer matches one source word: '+identity)
            old_words.append(hits[0])
        if not old_words:raise ValueError('A subtitle visibility choice has no measured words: '+identity)
        needle=[t for w in old_words for t in so.tokens(w['text'])];matches=[]
        for start in range(len(flat)-len(needle)+1):
            rows=flat[start:start+len(needle)]
            if hay[start:start+len(needle)]!=needle:continue
            # Frame rounding can move a clipped caption boundary by one frame.
            # No acoustic clock or lexical change is inferred during regrouping.
            if abs(round(rows[0][3]['start']*60)-round(old_words[0]['start']*60))>1:continue
            if abs(round(rows[-1][3]['end']*60)-round(old_words[-1]['end']*60))>1:continue
            picked={(r[1],r[2]) for r in rows}
            if [r[0] for r in flat if (r[1],r[2]) in picked]!=needle:continue
            matches.append(picked)
        if len(matches)!=1:raise ValueError('Cannot uniquely preserve the timed words of a subtitle visibility choice: '+identity)
        picked=matches[0];ids=[]
        for ci in sorted({ci for ci,wi in picked}):
            cue=new_base[ci];indexes=sorted(wi for cidx,wi in picked if cidx==ci)
            if indexes!=list(range(indexes[0],indexes[-1]+1)):raise ValueError('Discontinuous subtitle visibility choice: '+identity)
            ws=cue['words'];a,b=indexes[0],indexes[-1]+1
            start=max(cue['start'],rule['start']);end=min(cue['end'],rule['end'])
            if end-start<1/60-1e-8:raise ValueError('A subtitle visibility choice no longer fits its authored interval: '+identity)
            new_owner=key(cue);words=[so.word_key(w) for w in ws[a:b]]
            exact=identity.removeprefix('visibility_')==owner and a==0 and b==len(ws)
            destination=('visibility_'+new_owner) if exact else 'visibility_rebound_'+hashlib.sha256(json.dumps([identity,new_owner,words],ensure_ascii=False).encode()).hexdigest()[:24]
            if destination in result:raise ValueError('Conflicting remapped subtitle visibility choices: '+identity)
            order+=1;result[destination]={**copy.deepcopy(raw),'source':target,'owner':new_owner,'words':words,'start':start,'end':end,'order':order,'rebound_from':identity};ids.append(destination)
        records.append(dict(original_id=identity,kind='visibility',visibility_rules=ids,replacement=None))
    return records


def migrate_display_edits(edits, old_bases, old_display, new_base, windows=(), pacing=None, old_base=None, new_scene_cuts=()):
    import subtitle_edits as se
    import subtitle_ost as so
    available={se.key(c):c for c in old_bases}
    flat=[]
    for ci,c in enumerate(new_base):
        for wi,w in enumerate(c.get('words',[])):
            for token in so.tokens(w['text']):flat.append((token,ci,wi,w))
    hay=[x[0] for x in flat];result={};records=[]
    for identity,edit in edits.items():
        if not identity.startswith('custom_'):continue
        if not isinstance(edit,dict) or not edit.get('custom'):raise ValueError('Invalid authored custom caption: '+identity)
        value=se.custom_validate(edit);result[identity]=copy.deepcopy(edit)
        current=next((c for c in old_display if c.get('display_id')==identity),None)
        if current is None:raise ValueError('An authored custom caption no longer has a display item: '+identity)
        records.append(dict(original_id=identity,kind='custom',visibility_rules=[],replacement=dict(id=identity,**{k:value[k] for k in ('text','start','end')}),expected_hidden=bool(current.get('display_hidden'))))
    for identity,edit in edits.items():
        if identity.startswith(('visibility_','custom_')):continue
        # These are automatic edge repairs from a previous migration. Recompute
        # them against the new groups, rather than converting them to new text.
        if edit.get('migrated_neighbor'):continue
        original=available.get(identity)
        if not original:raise ValueError('The authored caption no longer has an editable base: '+identity)
        needle=so.tokens(original['text']);candidates=[]
        for index in range(len(flat)-len(needle)+1):
            if hay[index:index+len(needle)] != needle:continue
            rows=flat[index:index+len(needle)]
            delta=abs(rows[0][3]['start']-original['start'])+abs(rows[-1][3]['end']-original['end'])
            if rows[0][3]['start'] < original['end']+.5 and rows[-1][3]['end'] > original['start']-.5:candidates.append((delta,index,rows))
        if not candidates:raise ValueError('Cannot locate authored words on the new speech clock: '+identity)
        candidates.sort(key=lambda x:x[:2])
        if len(candidates)>1 and abs(candidates[0][0]-candidates[1][0])<1e-6:raise ValueError('Ambiguous repeated authored caption: '+identity)
        _,index,rows=candidates[0]
        picked={(r[1],r[2]) for r in rows}
        # Never conceal an unedited word merely because a numeric expression is
        # one indivisible display unit in the new track.
        touched=[r[0] for r in flat if (r[1],r[2]) in picked]
        if touched!=needle:raise ValueError('Authored edit splits an indivisible expression: '+identity)
        rule_ids=[]
        for ci in sorted({ci for ci,wi in picked}):
            c=new_base[ci];indexes=sorted(wi for cidx,wi in picked if cidx==ci)
            if indexes!=list(range(indexes[0],indexes[-1]+1)):raise ValueError('Discontinuous caption mapping: '+identity)
            a,b=indexes[0],indexes[-1]+1;ws=c['words']
            start=c['start'] if a==0 else ws[a]['start'];end=c['end'] if b==len(ws) else ws[b-1]['end']
            if end-start<1/60-1e-8:raise ValueError('Authored caption is shorter than a frame: '+identity)
            piece=dict(start=start,end=end,text=se.word_slice_text(c,a,b),words=copy.deepcopy(ws[a:b]),_visibility_owner=se.key(c))
            piece['display_id']=se.key(piece)
            key='visibility_'+piece['display_id']
            result[key]=so.visibility_record(new_base,piece,False,result)
            result[key]['migrated_from']=identity;rule_ids.append(key)
        record=dict(original_id=identity,source_text=original['text'],visibility_rules=rule_ids,replacement=None)
        if edit.get('text','').strip():
            # Use the reviewed effective item, including its actual frame clock.
            current=next((c for c in old_display if c.get('display_id')==identity and c.get('text','').strip()),None)
            if not current:
                current=se.apply([original],{identity:edit})[0]
            value=se.custom_validate(current)
            key='custom_migrated_'+hashlib.sha256(identity.encode()).hexdigest()[:24]
            result[key]={**value,'migrated_from':identity}
            record['replacement']=dict(id=key,**{k:value[k] for k in ('text','start','end')})
        records.append(record)
    records.extend(_rebind_visibility_edits(edits,old_base,new_base,result))
    # Authored extended timings win over neighbouring newly regrouped fragments.
    # Trim only display edges; canonical source words and source timing stay fixed.
    adjustments=[]
    for _ in range(3):
        visible=so.display(new_base,result,windows,pacing=pacing)
        authored=[c for c in visible if c.get('display_custom')]
        changed=False
        for c in visible:
            if c.get('display_custom'):continue
            a,b=c['start'],c['end']
            for own in authored:
                if b<=own['start']+1e-6 or a>=own['end']-1e-6:continue
                if a<own['start']<b<=own['end']+1e-6:b=own['start']
                elif own['start']-1e-6<=a<own['end']<b:a=own['end']
                else:raise ValueError('Authored replacement conflicts with another caption: '+own['display_id'])
            if a!=c['start'] or b!=c['end']:
                if b-a<1/60-1e-8:raise ValueError('Authored replacement leaves no readable neighbour interval.')
                result[c['display_id']]=dict(text=c['text'],start=a,end=b,migrated_neighbor=True)
                adjustments.append(dict(id=c['display_id'],text=c['text'],before=[c['start'],c['end']],after=[a,b]));changed=True
        if not changed:break
    visible=so.display(new_base,result,windows,pacing=pacing)
    cuts=list(new_scene_cuts or ())
    if any(type(t) not in (int,float) or not math.isfinite(t) or t<0 for t in cuts):
        raise ValueError('New scene subtitle boundaries are invalid.')
    for cue in visible:
        if not cue.get('display_custom'):continue
        conflict=next((cut for cut in cuts if round(cue['start']*60)<round(cut*60)<round(cue['end']*60)),None)
        if conflict is not None:
            raise ValueError('The authored subtitle '+repr(cue['text'][:80])+' crosses the new scene boundary at %.3fs. Review its text or start/end in the subtitle editor before regrouping; its existing text and timing were preserved.' % conflict)
    for left,right in zip(visible,visible[1:]):
        if round(left['end']*60)>round(right['start']*60):raise ValueError('Remapped captions overlap: '+repr((left,right)))
    complete=so.display(new_base,result,windows,pacing=pacing,include_hidden=True)
    for record in records:
        replacement=record['replacement']
        if replacement:
            actual=next((c for c in complete if c.get('display_id')==replacement['id']),None)
            if not actual or any(actual[k]!=replacement[k] for k in ('text','start','end')):raise ValueError('An authored replacement was lost.')
            if 'expected_hidden' in record and bool(actual.get('display_hidden'))!=record['expected_hidden']:raise ValueError('An authored custom caption visibility choice was lost.')
    return result,dict(passed=True,authored_records=len(records),records=records,neighbor_adjustments=adjustments,
                       explicit_hidden_records=sum(r['replacement'] is None for r in records),replacement_records=sum(r['replacement'] is not None for r in records))

