"""Display-only caption edits. Canonical speech and scene timing are never mutated."""
import copy
import hashlib
import json
import math
from pathlib import Path
from collections import OrderedDict
import threading

_BASE_CACHE = OrderedDict()
_CACHE_LOCK = threading.Lock()


def key(cue):
    raw = [round(cue['start'], 5), round(cue['end'], 5), cue['text']]
    return hashlib.sha256(json.dumps(raw, ensure_ascii=False).encode()).hexdigest()[:24]


def read(directory):
    path = Path(directory) / 'subtitle-display.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text('utf8'))
    if not isinstance(data, dict):
        raise ValueError('Saved subtitle edits are unreadable. Restore the backup before exporting.')
    return data


def validate(edit):
    if not isinstance(edit, dict) or not isinstance(edit.get('text'), str):
        raise ValueError('Enter subtitle text, or leave it empty to hide this caption.')
    text = edit['text'].strip()
    if len(text) > 5000:
        raise ValueError('A single caption can contain at most 5,000 characters.')
    try:
        start, end = float(edit['in']), float(edit['out'])
    except (KeyError, TypeError, ValueError):
        raise ValueError('Enter a valid start and end time.')
    if not all(math.isfinite(t) for t in (start, end)) or not 0 <= start < end <= 1:
        raise ValueError('Keep Start before End and inside this caption’s original time window.')
    return dict(text=text, **{'in': start, 'out': end})


def apply(captions, edits, fps=60):
    import caption_layer
    output = copy.deepcopy(captions)
    for cue in output:
        identity = key(cue)
        base = dict(start=cue['start'], end=cue['end'], text=cue['text'])
        cue.update(display_id=identity, display_base=base, display_edited=False)
        edit = edits.get(identity)
        if edit is None:
            continue
        edit = validate(edit)
        duration = base['end'] - base['start']
        cue.update(start=round(round((base['start'] + duration * edit['in']) * fps) / fps, 5),
                   end=round(round((base['start'] + duration * edit['out']) * fps) / fps, 5),
                   text=edit['text'], display_edited=True)
        if cue['end'] <= cue['start']:
            raise ValueError('A caption must remain visible for at least one frame.')
        # Match only THIS caption's original words. Removing its last words must
        # not squeeze all remaining words into a new uniform speech clock.
        aligned = [(w['start'], w['end'], w['text']) for w in cue.get('words', []) if w.get('aligned')]
        caption_layer.timed_caption_words([cue], aligned)
    return output


def remap_bases(captions, remap):
    for cue in captions:
        base = cue.get('display_base')
        if base:
            base['start'], base['end'] = remap(base['start']), remap(base['end'])


def assemble_base(scenes, cues, total, words, script='', fps=60):
    """Exactly the caption cuts used by Assemble, SRT, rendered video and XML."""
    import premiere_export as pe
    import caption_layer
    stamp = hashlib.sha256(json.dumps([scenes, cues, total, words, fps], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    with _CACHE_LOCK:
        if stamp in _BASE_CACHE:
            _BASE_CACHE.move_to_end(stamp)
            return copy.deepcopy(_BASE_CACHE[stamp])
    starts = pe.word_scene_starts(scenes, words) if words else None
    ranges, included = pe.scene_time_ranges(scenes, cues, total, starts)
    cuts = [a for (a, b), inc in zip(ranges, included) if inc and b > a]
    tokens = pe.accurate_cue_token_times(cues, words) if words else None
    caps = pe.split_captions_at_scenes(cues, cuts, tokens)
    for a, b in zip(caps, caps[1:]):
        if 0 < b['start'] - a['end'] <= .6:
            a['end'] = b['start']
    snap = lambda t: round(round(t * fps) / fps, 5)
    caps = [dict(start=snap(c['start']), end=snap(c['end']), text=c['text'])
            for c in caps if snap(c['end']) > snap(c['start'])]
    caption_layer.timed_caption_words(caps, words)
    with _CACHE_LOCK:
        _BASE_CACHE[stamp] = copy.deepcopy(caps)
        while len(_BASE_CACHE) > 12:
            _BASE_CACHE.popitem(last=False)
    return caps
