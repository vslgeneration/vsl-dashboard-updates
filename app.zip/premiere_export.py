"""
Premiere Pro project export — assembles the whole VSL pipeline into ONE editable
timeline the user opens in Premiere (File > Import).

Output = Final Cut Pro 7 XML (xmeml v4). The XML mirrors, element-for-element and
IN ORDER, what THIS user's Premiere Pro itself exports (from a sample they gave):
bare <sequence> under <xmeml version="4"> (no <project> wrapper), <masterclipid> on
every clip, the exact clipitem field order, pathurl with %-encoded spaces + drive
colon (%3a), native Basic Motion (zoom) and Audio Levels (fade) filters, and the
audio <outputs>/Panner track shape. Earlier attempts (hand-rolled, then OTIO) were
rejected as "The project appears to be damaged" because their element order/shape
differed from what Premiere's importer accepts.

Timeline layout (1920x1080, 60 fps):
  V1  scene clips — the generated VIDEO if it exists, else the approved IMAGE, placed
      at each scene's *audio-driven* time range (derived from the SRT). Every clip gets
      a gentle Ken-Burns zoom-in at a CONSTANT speed (1.4 %/sec). Where a video is
      shorter than its scene's spoken range, the remainder is a RED MATTE clip so the
      gap is impossible to miss. A scene with no media at all is a red matte.
  A1  voice-over.
  A2/A3  background music — one track per emotional segment (segmented by Claude, mapped
      to Background Music/<EMOTION>), each used once, laid on two alternating tracks that
      overlap by 1.5 s with audio-level fades → a smooth cross-fade.

SRT stays a SEPARATE deliverable — the user imports it as captions in Premiere.
"""
import re, json, difflib, subprocess, hashlib
from pathlib import Path

# The dashboard runs windowless (pythonw), so every ffmpeg/ffprobe child would otherwise
# pop up its own console — a black box flashing over the screen once per scene.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
from xml.sax.saxutils import escape
from urllib.parse import quote

FPS = 60
SEQ_W, SEQ_H = 1920, 1080
ZOOM_PCT_PER_SEC = 3.2          # constant Ken-Burns zoom speed (percent of scale per second) — stronger punch
XFADE_SEC = 3.0                 # music cross-fade length (longer = smoother transitions)
MUSIC_LEVEL = 0.15              # fallback background-music level if loudness can't be measured
TARGET_VO_LUFS = -16.0         # voice-over gain-matched to a solid, consistent VSL speech level
TARGET_MUSIC_LUFS = -33.0      # background music gain-matched to a quiet bed ~17 dB under the VO,
                               # so every track sits at the SAME level regardless of its original
PEAK_CEILING_DBTP = -1.0       # never let a gained track's true peak exceed this (avoids clipping)
TPF = 254016000000 // FPS       # Premiere ticks per frame (254016000000 ticks per second)
STILL = FPS * 3600              # a still/graphic's source length (1h) — huge so it never runs out
EMOTIONS = ["DOCUMENTARY", "EMOTIONAL", "FEAR", "INSPIRING", "SCIENTIFIC", "SUSPENSE", "TESTIMONIAL"]   # legacy default

def list_moods(bgm_root):
    """The mood categories that ACTUALLY exist = the subfolders of Background Music that contain audio.
    Dynamic, so renaming/adding/removing mood folders just works (no hardcoded list to keep in sync)."""
    try:
        root = Path(bgm_root)
        out = sorted(d.name for d in root.iterdir()
                     if d.is_dir() and not d.name.startswith(".")
                     and any(p.suffix.lower() in (".wav", ".mp3") for p in d.iterdir()))
        return out or list(EMOTIONS)
    except Exception:
        return list(EMOTIONS)

def _humanize_mood(m):
    """'Problem_Emotional' -> 'Problem / Emotional' for the LLM prompt (labels stay exact for matching)."""
    return (m or "").replace("_", " / ").replace("-", " ")


# ---- media probing ---------------------------------------------------------
def ffprobe_media(path):
    """Return (duration_seconds, width, height) for a video, or (None, w, h) best-effort."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height:format=duration",
             "-of", "json", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        j = json.loads(out.stdout or "{}")
        st = (j.get("streams") or [{}])[0]
        try:
            dur = float(j.get("format", {}).get("duration"))
        except (TypeError, ValueError):
            dur = None
        return dur, int(st.get("width") or SEQ_W), int(st.get("height") or SEQ_H)
    except Exception:
        return None, SEQ_W, SEQ_H


def audio_duration(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=nokey=1:noprint_wrappers=1", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        return float(out.stdout.strip())
    except Exception:
        return None


def audio_channels(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=channels", "-of", "default=nokey=1:noprint_wrappers=1", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        return int(out.stdout.strip())
    except Exception:
        return 2


def image_size(path):
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.width, im.height
    except Exception:
        return SEQ_W, SEQ_H


def measure_lufs(path, cache):
    """(integrated LUFS, true-peak dBTP) of an audio file via ffmpeg loudnorm, cached by
    file+mtime. Used to gain-match tracks to the same level without clipping."""
    p = Path(path)
    try:
        key = f"{p.name}:{p.stat().st_mtime_ns}"
    except Exception:
        key = str(p)
    if key in cache:
        v = cache[key]
        return tuple(v) if isinstance(v, list) else (v, None)   # tolerate old float-only cache
    lufs = tp = None
    try:
        out = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(p),
             "-af", "loudnorm=print_format=json", "-f", "null", "-"],
            capture_output=True, text=True, timeout=180, creationflags=_NO_WINDOW)
        m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", out.stderr)
        if m:
            j = json.loads(m[-1])
            lufs = float(j["input_i"])
            try:
                tp = float(j.get("input_tp"))
            except (TypeError, ValueError):
                tp = None
    except Exception:
        lufs = tp = None
    cache[key] = [lufs, tp]
    return lufs, tp


def normalize_loudness(src, dst, target_i=TARGET_VO_LUFS, target_tp=-1.5, lra=11.0, mono=False):
    """Two-pass ffmpeg loudnorm → dst at `target_i` LUFS WITH limiting, so the voice-over plays
    at a consistent VSL level and never clips (a static gain can't do this for a quiet-but-peaky
    file). Duration is preserved, so SRT alignment stays valid. `mono=True` collapses to a single
    channel FIRST (voice-over must be centred/mono — a stray stereo bed of music/reverb in the source
    otherwise bleeds through even with the music track muted). Returns dst, or None on failure."""
    src, dst = Path(src), Path(dst)
    pre = "aformat=channel_layouts=mono," if mono else ""    # downmix before measuring so the target level is right
    try:
        r1 = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(src),
             "-af", f"{pre}loudnorm=I={target_i}:TP={target_tp}:LRA={lra}:print_format=json", "-f", "null", "-"],
            capture_output=True, text=True, timeout=300, creationflags=_NO_WINDOW)
        m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", r1.stderr)
        meas = ""
        if m:
            j = json.loads(m[-1])
            meas = (f":measured_I={j['input_i']}:measured_TP={j['input_tp']}"
                    f":measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}"
                    f":offset={j.get('target_offset', '0.0')}:linear=true")
        dst.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-nostats", "-i", str(src),
             "-af", f"{pre}loudnorm=I={target_i}:TP={target_tp}:LRA={lra}{meas}",
             "-ar", "44100"] + (["-ac", "1"] if mono else []) + [str(dst)],
            capture_output=True, text=True, timeout=300, check=True, creationflags=_NO_WINDOW)
        return dst if dst.exists() else None
    except Exception:
        return None


def _norm_level(lufs, tp, target):
    """Audio-Levels value that brings `lufs` to `target`, capped so the true peak stays under
    PEAK_CEILING_DBTP (no clipping)."""
    if lufs is None:
        return None
    gain_db = target - lufs
    if tp is not None:
        gain_db = min(gain_db, PEAK_CEILING_DBTP - tp)
    return max(0.02, min(4.0, 10 ** (gain_db / 20.0)))


def music_level(lufs, tp=None):
    # NO intervention on the user's background music: play it at UNITY (0 dB) — exactly the level baked into the
    # file. The user curates + level-matches the pool themselves, so the app applies no gain/normalisation.
    # (Crossfades still ramp 0 -> this peak, so they're 0 dB -> full.)
    return 1.0


def vo_level(lufs, tp=None):
    lvl = _norm_level(lufs, tp, TARGET_VO_LUFS)
    return 1.0 if lvl is None else lvl


# ---- SRT parsing + scene<->SRT alignment -----------------------------------
_TS = re.compile(r"(\d+):(\d\d):(\d\d)[,.](\d\d\d)")


def _ts_to_sec(t):
    h, m, s, ms = (int(x) for x in _TS.match(t).groups())
    return h * 3600 + m * 60 + s + ms / 1000.0


def parse_srt(text):
    """Return [{start, end, text}] in order."""
    cues = []
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n").strip()):
        lines = [ln for ln in block.split("\n") if ln.strip()]
        if not lines:
            continue
        ti = 0
        if "-->" not in lines[0] and len(lines) > 1:
            ti = 1  # first line is the index number
        if ti >= len(lines) or "-->" not in lines[ti]:
            continue
        a, _, b = lines[ti].partition("-->")
        try:
            start, end = _ts_to_sec(a.strip()), _ts_to_sec(b.strip())
        except Exception:
            continue
        cues.append({"start": start, "end": end, "text": " ".join(lines[ti + 1:])})
    return cues


def _norm_words(text):
    return re.findall(r"[a-z0-9']+", (text or "").lower())


def word_scene_starts(scenes, words):
    """ACCURATE per-scene start times from the forced-alignment WORD list [(start, end, word)] —
    matches each scene's VO word sequence onto the word timeline (difflib), giving the real onset of
    each scene's first spoken word instead of a linear interpolation inside an SRT cue."""
    srt_words, srt_times = [], []
    for st, _en, tok in words:
        for w in _norm_words(tok):
            srt_words.append(w); srt_times.append(st)
    scene_words, idx = [], []
    for s in scenes:
        idx.append(len(scene_words)); scene_words.extend(_norm_words(s.get("vo") or ""))
    pos = [None] * len(scene_words)
    for a, b, size in difflib.SequenceMatcher(None, scene_words, srt_words, autojunk=False).get_matching_blocks():
        for k in range(size):
            pos[a + k] = b + k
    def time_at(i):
        for j in range(i, len(pos)):
            if pos[j] is not None:
                return srt_times[pos[j]]
        for j in range(i - 1, -1, -1):
            if pos[j] is not None:
                return srt_times[pos[j]]
        return None
    starts = []
    for si, s in enumerate(scenes):
        if not (s.get("vo") or "").strip():
            starts.append(starts[-1] if starts else 0.0); continue
        t = time_at(idx[si])
        starts.append(t if t is not None else (starts[-1] if starts else 0.0))
    return starts


def accurate_cue_token_times(cues, words):
    """For each cue, the ACCURATE onset time of each display token, by walking the cue tokens in
    lockstep with the word list (both come from the same alignment, same order). Falls back to the
    cue's own start if the sequences drift. Returns a parallel list-of-lists, or None if unusable."""
    tsv = [(w, st) for (st, _en, tok) in words for w in _norm_words(tok)]
    ti, out = 0, []
    for c in cues:
        toks = (c["text"] or "").split()
        times = []
        for t in toks:
            nw = _norm_words(t)
            if nw and ti < len(tsv):
                times.append(tsv[ti][1]); ti += len(nw)
            else:
                times.append(c["start"])
        out.append(times)
    return out


def split_captions_at_scenes(cues, scene_starts, cue_token_times=None):
    """PREVIEW ONLY: split any SRT cue that straddles a scene boundary INTO TWO at that boundary, so
    every scene start coincides with a caption start and the two switch together in the player. Token
    times come from `cue_token_times` (accurate, from the word list) when given, else interpolated.
    The forced-alignment cues otherwise don't break at sentence/scene boundaries. Not the export SRT."""
    cuts = sorted({round(b, 3) for b in scene_starts})
    out = []
    for ci, c in enumerate(cues):
        toks = (c["text"] or "").split()
        inside = [b for b in cuts if c["start"] + 1e-4 < b < c["end"] - 1e-4]
        if not inside or len(toks) < 2:
            out.append(c)
            continue
        n = len(toks)
        if cue_token_times and ci < len(cue_token_times) and len(cue_token_times[ci]) == n:
            wt = cue_token_times[ci]
        else:
            dur = c["end"] - c["start"]
            wt = [c["start"] + dur * k / n for k in range(n)]
        pts = [c["start"]] + inside + [c["end"]]
        for a, b in zip(pts, pts[1:]):
            seg = [toks[k] for k in range(n) if a <= wt[k] < b]
            if seg:
                out.append({"start": a, "end": b, "text": " ".join(seg)})
    return out


def load_word_tsv(subtitle_dir):
    """Forced-alignment word list [(start, end, word)] from the ensemble TSV (accurate per-word
    onsets). Returns None if no usable TSV is present."""
    subtitle_dir = Path(subtitle_dir)
    # English keeps the tuned .en ensemble names; other languages (fr/de/…) drop the "_en" -> add those too
    for name in ("words_medium_en_vad.tsv", "words_small_en_vad.tsv", "words_medium_vad.tsv", "words_small_vad.tsv"):
        p = subtitle_dir / name
        if not p.exists():
            continue
        out = []
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            parts = line.split("\t")
            if len(parts) >= 3:
                try:
                    out.append((float(parts[0]), float(parts[1]), parts[2]))
                except ValueError:
                    pass
        if out:
            return out
    return None


def caps_to_srt(caps):
    """Serialize [{start,end,text}] cues to SRT text."""
    return "\n\n".join(
        f"{i}\n{_sec_to_ts(c['start'])} --> {_sec_to_ts(c['end'])}\n{c['text']}"
        for i, c in enumerate(caps, 1)) + "\n"


def delivery_srt(scenes, cues, total, words):
    """The SRT we DELIVER: captions split at scene boundaries (so a caption and its clip change
    together in Premiere) + frame-quantized. Uses the same scene boundaries as the exported clips."""
    word_starts = word_scene_starts(scenes, words) if words else None
    ranges, included = scene_time_ranges(scenes, cues, total, word_starts)
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    tok_times = accurate_cue_token_times(cues, words) if words else None
    caps = split_captions_at_scenes(cues, scene_starts, tok_times)
    return quantize_srt_to_frames(caps_to_srt(caps))


def _slug(t, n=40):
    # mirrors app.py slugify so the XML clip labels match the delivered zip filenames exactly
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"


def scene_label(s):
    """Friendly, order-accurate label for a scene's clip/master: `NN_<sentence-slug>` using the
    scene's CURRENT id + VO (so a manual split/insert renumbers and relabels everything)."""
    try:
        return f"{int(s.get('id')):02d}_{_slug(s.get('vo'))}"
    except (TypeError, ValueError):
        return _slug(s.get("vo"))


def scene_time_ranges(scenes, cues, total_dur, word_starts=None):
    """Map each scene's VO text onto the SRT word timeline → [(start, end)] per scene.

    HYBRID snap: if a scene's first word is ALSO the first word of its SRT cue (the scene boundary
    is a caption boundary — the normal case), the clip start snaps to the CUE start so it lines up
    frame-for-frame with the imported caption. If the scene starts MID-cue (a manual split of one
    sentence into two scenes), the clip start uses that word's real onset — `word_starts[si]` from
    the forced-alignment word list when provided (ACCURATE), else an interpolation inside the cue.
    Cue-first (caption-aligned) scenes are NEVER moved, so the confirmed frame-exact caption sync is
    preserved; only mid-cue starts are refined."""
    srt_words, srt_cue_starts, srt_word_times, srt_word_cuefirst = [], [], [], []
    for c in cues:
        ws = _norm_words(c["text"])
        n = len(ws)
        dur = max(0.0, c["end"] - c["start"])
        for k, word in enumerate(ws):
            srt_words.append(word)
            srt_cue_starts.append(c["start"])          # the CUE start (= the caption's timecode)
            srt_word_times.append(c["start"] + (dur * k / n if n else 0.0))   # interpolated word time
            srt_word_cuefirst.append(k == 0)

    scene_words, scene_start_idx = [], []
    for s in scenes:
        scene_start_idx.append(len(scene_words))
        scene_words.extend(_norm_words(s.get("vo") or ""))
    scene_start_idx.append(len(scene_words))            # sentinel end for the last scene

    pos = [None] * len(scene_words)
    for a, b, size in difflib.SequenceMatcher(None, scene_words, srt_words, autojunk=False).get_matching_blocks():
        for k in range(size):
            pos[a + k] = b + k

    # Which scenes actually appear in the voice-over? A scene whose spoken text does NOT align to
    # the SRT (a manually-added line that isn't in the script/VO — e.g. "As I said, my name is
    # Mark.") aligns at ~0.0, while real AND manually-SPLIT scenes align ~1.0. Phantom scenes are
    # treated as NON-EXISTENT: excluded from the timeline entirely (no clip, not even a red matte).
    included = []
    for si in range(len(scenes)):
        a, b = scene_start_idx[si], scene_start_idx[si + 1]
        wc = b - a
        matched = sum(1 for j in range(a, b) if pos[j] is not None)
        included.append(not (wc >= 3 and matched / max(1, wc) < 0.5))

    def matched_pos(idx):
        for j in range(idx, len(pos)):
            if pos[j] is not None:
                return pos[j]
        for j in range(idx - 1, -1, -1):
            if pos[j] is not None:
                return pos[j]
        return None

    starts = []
    for si, s in enumerate(scenes):
        if not (s.get("vo") or "").strip():
            starts.append(starts[-1] if starts else 0.0)
            continue
        p = matched_pos(scene_start_idx[si])
        if p is None:
            t = None
        elif srt_word_cuefirst[p]:
            t = srt_cue_starts[p]                              # cue-first → caption timecode (frame-exact)
        elif word_starts is not None and si < len(word_starts) and word_starts[si] is not None:
            t = word_starts[si]                                # mid-cue → real spoken-word onset
        else:
            t = srt_word_times[p]                              # mid-cue → interpolated fallback
        starts.append(t if t is not None else (starts[-1] if starts else 0.0))
    # Anchor the timeline at 0 on the FIRST scene that's actually in the voice-over, so leading
    # phantom scenes don't push the real opening clip past frame 0 (or leave a gap at the start).
    first_inc = next((i for i in range(len(scenes)) if included[i]), 0)
    for i in range(min(first_inc + 1, len(starts))):
        starts[i] = 0.0
    starts = _monotonic(starts)

    ranges = []
    for i in range(len(scenes)):
        end = starts[i + 1] if i + 1 < len(scenes) else total_dur
        ranges.append((starts[i], max(starts[i], end)))
    return ranges, included


def excluded_scene_ids(scenes, cues):
    """Ids of scenes NOT present in the voice-over (manual lines not in the script/VO). These are
    excluded across the whole export so they behave as if they don't exist. Returns a set; empty
    when there are no cues to align against."""
    if not scenes or not cues:
        return set()
    _ranges, included = scene_time_ranges(scenes, cues, 0.0)
    return {scenes[i].get("id") for i in range(len(scenes)) if not included[i]}


def _monotonic(xs):
    out, hi = [], 0.0
    for x in xs:
        hi = max(hi, x if x is not None else hi)
        out.append(hi)
    return out


# ---- background-music: emotion segmentation + track selection --------------
def segment_emotions(cues, total_dur, claude_fn, moods=None, humanize=None):
    """Ask Claude to split the timeline into contiguous emotional segments mapped to the AVAILABLE mood
    names (passed in `moods`). `humanize(mood)->str` supplies the hint shown for each mood (defaults to the
    built-in mapping). Returns [{start, end, emotion}] or [] on failure."""
    moods = list(moods) if moods else list(EMOTIONS)
    hz = humanize or _humanize_mood
    if not claude_fn or total_dur <= 0 or not moods:
        return []
    lines = [f"[{c['start']:.1f}-{c['end']:.1f}] {c['text']}" for c in cues]
    labels = "; ".join(f"{m} ({hz(m)})" for m in moods)
    system = (
        "You are a film music supervisor scoring a VIDEO SALES LETTER (VSL). You get a timed transcript and "
        "must divide its FULL timeline into a FEW contiguous sections driven by the STORY's tone/content, then "
        "assign each section the single best background-music mood.\n"
        "Allowed moods — use ONLY these EXACT labels (left side, spaces included): " + labels + ".\n"
        "MAP THE MOOD TO WHAT THE PASSAGE IS ACTUALLY DOING (do NOT default everything to one mood):\n"
        "  • Testimonials / reviews / real customers / social proof, the PRODUCT REVEAL, and the happy positive "
        "wrap-up toward the end → Corporate.\n"
        "  • Ingredients, science, analyses, research, studies, reports, data, graphs, 'how it works' / mechanism "
        "→ Scientific.\n"
        "  • Neutral storytelling — a character's NON-sad story, a self-introduction, or generic neither-good-nor-"
        "bad narration → Documentary.\n"
        "  • Emotional / sad / dark / pessimistic moments; a character's BAD experiences; heavy downbeat feelings "
        "→ Dramatic.\n"
        "  • VERY critical, alarming danger — death risk, malicious people, major health problems, a bleak high-"
        "stakes threat → Fear. (Milder bad/sad-but-not-alarming stays Dramatic; genuine alarm/danger = Fear.)\n"
        "  • After the product is introduced: the positive PROMISES / benefits to the viewer, the uplifting payoff, "
        "and the CALL-TO-ACTION push → Inspirational.\n"
        "  • HOOK moods are ONLY for the very FIRST section of a script's genuine OPENING teaser (a hook/lead), and "
        "only when the transcript actually STARTS there: a FRIGHTENING opener (first ~15-20s) → Fear Hook; a "
        "MYSTERIOUS / curiosity-arousing opener (first ~20-25s) → Mysterious Hook. If the video opens in the "
        "MIDDLE of the script (no teaser hook — e.g. it starts already in testimonials, science, or a continuing "
        "story), do NOT use ANY hook mood; score the opening by its real content instead.\n"
        "Rules:\n"
        "- Sections must be contiguous and cover the whole timeline from 0 to the end, no gaps or overlaps.\n"
        "- Change the music ONLY at a MAJOR, SHARP transition — a decisive shift to a clearly different chapter of "
        "the VSL (e.g. problem → discovery, science → testimonial, testimonial → CTA). A whole act is ONE section "
        "with ONE track even if it runs for minutes. Ignore brief 20-40s tonal dips/lifts INSIDE an act — they "
        "keep the current mood. When in doubt about a small shift, DON'T change.\n"
        "- TARGET COUNT: about ONE section per ~2 minutes — roughly 5 sections for a 10-minute video (4-6 is fine). "
        "Do NOT over-segment.\n"
        "- HARD LIMIT: no section longer than ~4.5 minutes (270s). If an act genuinely runs longer, split it into "
        "ADJACENT sections of the SAME mood (each ~3.5-4 min) so the music refreshes with a different track.\n"
        "- Minimum section length ~60 seconds (a hook may be shorter, ~15-25s).\n"
        "- Choose each section's mood by its ACTUAL content — never by position (except the hook rule above).\n"
        "- Pick the closest allowed mood for each section.\n"
        "Output ONLY a JSON array like "
        '[{"start":0,"end":42.5,"emotion":"<one of the exact labels>"}, ...]. No prose, no code fences.')
    user = (f"Total duration: {total_dur:.1f} seconds.\n"
            "Segment by the emotional tone of the story only, into a few long sections. Transcript:\n" + "\n".join(lines))
    try:
        text = claude_fn(system, user, 2000)
        m = re.search(r"\[.*\]", text, re.S)
        segs = json.loads(m.group(0) if m else text)
    except Exception:
        return []
    clean = []
    for s in segs:
        try:
            emo = _match_mood(str(s["emotion"]), moods)
            clean.append({"start": float(s["start"]), "end": float(s["end"]), "emotion": emo})
        except Exception:
            continue
    if not clean:
        return []
    clean.sort(key=lambda x: x["start"])
    # Keep music changes RARE — tied to MAJOR arc turns, not every little tone wobble. Two guards, both fold the
    # shortest segment into its larger neighbour (adopting that neighbour's mood):
    #   MIN_SEG   — no section may be shorter than this (kills blips), and
    #   MAX_SEGS  — a soft upper bound that scales with length (~one section per ~75s), so a 5-min VSL lands
    #               around 4 sections instead of 6+. Not a rigid clock — just a ceiling on over-segmentation.
    MIN_SEG = 35.0
    MAX_SEGS = max(3, round(total_dur / 75.0))
    while len(clean) > 1:
        durs = [s["end"] - s["start"] for s in clean]
        i = durs.index(min(durs))                                  # shortest segment
        if durs[i] >= MIN_SEG and len(clean) <= MAX_SEGS:
            break                                                  # long enough AND few enough → stop
        if i == 0:                       j = 1
        elif i == len(clean) - 1:        j = i - 1
        else:                            j = i - 1 if durs[i - 1] >= durs[i + 1] else i + 1
        lo, hi = min(i, j), max(i, j)
        merged = {"start": clean[lo]["start"], "end": clean[hi]["end"], "emotion": clean[j]["emotion"]}
        clean[lo:hi + 1] = [merged]                                # absorb into the larger neighbour's mood
    clean[0]["start"] = 0.0
    clean[-1]["end"] = total_dur
    for i in range(1, len(clean)):
        clean[i]["start"] = clean[i - 1]["end"]
    return [s for s in clean if s["end"] > s["start"]]


def _match_mood(label, moods):
    """Map an LLM-returned mood label to one of the AVAILABLE mood folders (case/underscore-insensitive,
    then substring, then keyword overlap). Returns a real folder name."""
    moods = list(moods) if moods else list(EMOTIONS)
    if not moods:
        return "DOCUMENTARY"
    norm = lambda x: re.sub(r"[^a-z0-9]", "", (x or "").lower())
    L = norm(label)
    for m in moods:                                  # exact (normalized)
        if norm(m) == L:
            return m
    for m in moods:                                  # substring either way
        nm = norm(m)
        if nm and (nm in L or L in nm):
            return m
    lw = set(re.findall(r"[a-z]+", (label or "").lower()))   # keyword overlap
    best, bs = moods[0], 0
    for m in moods:
        sc = len(lw & set(re.findall(r"[a-z]+", m.lower())))
        if sc > bs:
            best, bs = m, sc
    return best

def _closest_emotion(label, moods=None):
    return _match_mood(label, moods or EMOTIONS)


def pick_music(segments, bgm_root):
    """Assign each segment an UNUSED track from its mood folder (each track used at most once), enriched with
    duration and measured loudness (LUFS, cached in bgm_root/.loudness_cache.json) for gain-matching."""
    bgm_root = Path(bgm_root)
    moods = list_moods(bgm_root)
    pool = {}
    for emo in moods:
        folder = bgm_root / emo
        pool[emo] = sorted([p for p in folder.iterdir()
                            if p.suffix.lower() in (".wav", ".mp3")]) if folder.exists() else []
    cache_path = bgm_root / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    used = set()
    out = []
    for seg in segments:
        emo = seg["emotion"] if seg["emotion"] in pool else _closest_emotion(seg["emotion"])
        files = pool.get(emo) or []
        choice = next((f for f in files if f not in used), None) or (files[0] if files else None)
        seg = dict(seg, emotion=emo)
        if choice is not None:
            used.add(choice)
            lufs, tp = measure_lufs(choice, cache)
            seg.update(path=choice, src_dur=audio_duration(choice), lufs=lufs, tp=tp)
        else:
            seg.update(path=None, src_dur=None, lufs=None, tp=None)
        out.append(seg)
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception:
        pass
    return out


# ---- FCP7 XML building — mirror Premiere's OWN export dialect ---------------
def _pathurl(path):
    p = str(Path(path).resolve()).replace("\\", "/")
    # Match Premiere's OWN encoding exactly: it percent-encodes ONLY spaces (%20) and the
    # drive colon (%3a), and leaves everything else (& ' ( ) , etc.) LITERAL — those are
    # then XML-escaped by escape() at emit time (& -> &amp;). url-quoting them (e.g. & ->
    # %26) yields a path Premiere cannot relink (it looks for a file literally named "%26").
    p = p.replace(":", "%3a", 1)
    p = p.replace(" ", "%20")
    return "file://localhost/" + p


def _rate(tb=FPS):
    return f"<rate><timebase>{tb}</timebase><ntsc>FALSE</ntsc></rate>"


def _tc():
    return ("<timecode>" + _rate() +
            "<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>")


def _f(sec):
    # round HALF-UP (not Python's banker's round) so clip frames match quantize_srt_to_frames,
    # which uses the same rule — this is what keeps a caption and its clip on the identical frame.
    return int(sec * FPS + 0.5) if sec > 0 else 0


def _sec_to_ts(sec):
    ms = int(round(max(0.0, sec) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def quantize_srt_to_frames(srt_text, fps=FPS):
    """Rewrite every cue's start/end timestamp so it lands EXACTLY on the frame our clips use.

    For each cue we compute frame = round-half-up(sec*fps) — the SAME frame `_f()` gives the clip
    — then write the timestamp back at (frame + 0.25)/fps seconds. The +0.25-frame nudge (≈4 ms at
    60 fps, invisible) guarantees Premiere's own SRT-import ms→frame conversion recovers the same
    frame whether it floors OR rounds. Result: an imported caption and its scene clip begin on the
    identical frame — zero drift. Only timecodes are touched; all caption text/formatting is kept."""
    def repl(m):
        fa = int(_ts_to_sec(m.group(1)) * fps + 0.5)
        fb = int(_ts_to_sec(m.group(2)) * fps + 0.5)
        if fb <= fa:
            fb = fa + 1
        return f"{_sec_to_ts((fa + 0.25) / fps)} --> {_sec_to_ts((fb + 0.25) / fps)}"
    return re.sub(r"(\d+:\d\d:\d\d[,.]\d\d\d)\s*-->\s*(\d+:\d\d:\d\d[,.]\d\d\d)", repl, srt_text)


_LOGGING = ("<logginginfo><description></description><scene></scene><shottake></shottake>"
            "<lognote></lognote><good></good><originalvideofilename></originalvideofilename>"
            "<originalaudiofilename></originalaudiofilename></logginginfo>")
_COLORINFO = ("<colorinfo><lut></lut><lut1></lut1><asc_sop></asc_sop><asc_sat></asc_sat>"
              "<lut2></lut2></colorinfo>")


# push (slide) direction unit vectors — the way EVERYTHING moves. +horiz=right, +vert=down; 1.0 = a full frame.
_PUSH = {"slide-left": (-1.0, 0.0), "slide-right": (1.0, 0.0),
         "slide-up": (0.0, -1.0), "slide-down": (0.0, 1.0)}
PUSH_FRAMES = int(round(FPS * 0.5))     # push duration ~0.5s (medium — not too fast, not too slow)


def _push_center_kf(direction, incoming, dur):
    """Center (Position) keyframes for a push: the INCOMING clip flies in from the opposite side to rest (0,0);
    the OUTGOING clip flies from rest out toward the push direction. Offsets are normalized full-frame units."""
    mx, my = _PUSH[direction]

    def cv(x, y):
        return f"<value><horiz>{x:.6f}</horiz><vert>{y:.6f}</vert></value>"
    if incoming:
        return f"<keyframe><when>0</when>{cv(-mx, -my)}</keyframe><keyframe><when>{dur}</when>{cv(0, 0)}</keyframe>"
    return f"<keyframe><when>0</when>{cv(0, 0)}</keyframe><keyframe><when>{dur}</when>{cv(mx, my)}</keyframe>"


def _basic_motion(base, end, out_f, center_kf=""):
    """Native Premiere Basic Motion (Motion) filter — scale keyframes give the zoom; optional center_kf
    keyframes give a push/slide (position) move."""
    b, e = round(base, 2), round(end, 2)
    kf = ""
    if abs(e - b) > 0.01:
        kf = (f"<keyframe><when>0</when><value>{b}</value></keyframe>"
              f"<keyframe><when>{out_f}</when><value>{e}</value></keyframe>")
    return (
        "<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
        "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
        "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
        f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>{b}</value>{kf}</parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>rotation</parameterid><name>Rotation</name>'
        "<valuemin>-8640</valuemin><valuemax>8640</valuemax><value>0</value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
        f"<value><horiz>0</horiz><vert>0</vert></value>{center_kf}</parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
        "<value><horiz>0</horiz><vert>0</vert></value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>antiflicker</parameterid><name>Anti-flicker Filter</name>'
        "<valuemin>0.0</valuemin><valuemax>1.0</valuemax><value>0</value></parameter>"
        "</effect></filter>")


_OST_ALLOWED_IN = ("popup", "slide-left", "slide-top", "slide-bottom")
_OST_OUT_FOR = {"popup": "pop", "slide-left": "slide-left", "slide-top": "fade", "slide-bottom": "fade"}


def _ost_anims(ov):
    """(in, out) on-screen-text animations, enforcing the rule: never plain fade-in / slide-right; the OUT is a
    fixed function of the IN (pop->pop, slide-left->slide-left, slide-top/bottom->fade)."""
    a = (ov.get("ost_anim") or "").strip()
    if a not in _OST_ALLOWED_IN:
        a = "slide-bottom"
    return a, _OST_OUT_FOR.get(a, "fade")


def _zoom_center_kf(ix, iy, out_f):
    """Ken-Burns that leans TOWARD a point (an icon): as the clip scales up, drift the frame CENTER so the
    region around (ix,iy) moves toward the middle. Gentle (won't push content off-frame). Empty if centred."""
    hx = round(-(ix - 0.5) * 0.16, 4)                # move image opposite the icon → that side comes to centre
    vy = round(-(iy - 0.5) * 0.16, 4)
    if abs(hx) < 0.004 and abs(vy) < 0.004:
        return ""
    return (f"<keyframe><when>0</when><value><horiz>0</horiz><vert>0</vert></value></keyframe>"
            f"<keyframe><when>{out_f}</when><value><horiz>{hx}</horiz><vert>{vy}</vert></value></keyframe>")


def _audio_levels(clip_f, fade_in_f, fade_out_f, peak=1.0):
    """Native Premiere Audio Levels filter: hold at `peak` (1.0 = 0 dB) with optional
    fade-in/out to silence. Music uses a low peak so the VO sits clearly on top."""
    p = round(peak, 4)
    kf = []
    if fade_in_f > 0:
        kf += [(0, 0), (fade_in_f, p)]
    else:
        kf += [(0, p)]
    if fade_out_f > 0:
        kf += [(max(fade_in_f, clip_f - fade_out_f), p), (clip_f, 0)]
    body = "".join(f"<keyframe><when>{w}</when><value>{v}</value></keyframe>" for w, v in kf)
    return (
        "<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid>"
        "<effectcategory>audiolevels</effectcategory><effecttype>audiolevels</effecttype>"
        "<mediatype>audio</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>level</parameterid><name>Level</name>'
        f"<valuemin>0</valuemin><valuemax>3.98109</valuemax><value>{p}</value>{body}</parameter>"
        "</effect></filter>")


def _video_file(fid, path, src_frames, w, h, still=False):
    # Premiere's export omits <duration> on still-image files (only real footage carries it).
    dur = "" if still else f"<duration>{src_frames}</duration>"
    return (
        f'<file id="{fid}"><name>{escape(Path(path).name)}</name>'
        f"<pathurl>{escape(_pathurl(path))}</pathurl>"
        f"{_rate()}{dur}{_tc()}"
        "<media><video><samplecharacteristics>"
        f"{_rate()}<width>{w}</width><height>{h}</height>"
        "<anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio>"
        "<fielddominance>none</fielddominance></samplecharacteristics></video></media></file>")


def _audio_file(fid, path, src_frames, channels):
    # Declare the file's ACTUAL channel count — a mismatch (e.g. mono clip vs a stereo file)
    # makes Premiere refuse to link the media ("created with 1 audio channel ... file has 2").
    ch = max(1, channels)
    chans = "".join(f"<audiochannel><sourcechannel>{i + 1}</sourcechannel></audiochannel>" for i in range(ch))
    return (
        f'<file id="{fid}"><name>{escape(Path(path).name)}</name>'
        f"<pathurl>{escape(_pathurl(path))}</pathurl>"
        f"{_rate()}<duration>{src_frames}</duration>{_tc()}"
        "<media><audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate>"
        f"</samplecharacteristics><channelcount>{ch}</channelcount>{chans}</audio></media></file>")


def _time_remap(src_f, tl_f):
    """Constant-speed slow-down: play `src_f` source frames across `tl_f` (longer) timeline frames, so a clip
    shorter than its scene fills it exactly instead of freezing/leaving a gap. Native Premiere Time Remap —
    the SAME filter (speed % + graphdict curve) the user's own timeline already uses to stretch short clips."""
    speed = max(1, int(round(100.0 * src_f / max(1, tl_f))))    # e.g. 6s over 8s -> 75(%)
    ht, hs = tl_f // 2, src_f // 2
    return (
        "<filter><effect><name>Time Remap</name><effectid>timeremap</effectid>"
        "<effectcategory>motion</effectcategory><effecttype>motion</effecttype><mediatype>video</mediatype>"
        '<parameter authoringApp="PremierePro"><parameterid>variablespeed</parameterid><name>variablespeed</name>'
        "<valuemin>0</valuemin><valuemax>1</valuemax><value>0</value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>speed</parameterid><name>speed</name>'
        f"<valuemin>-100000</valuemin><valuemax>100000</valuemax><value>{speed}</value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>reverse</parameterid><name>reverse</name><value>FALSE</value></parameter>'
        '<parameter authoringApp="PremierePro"><parameterid>frameblending</parameterid><name>frameblending</name><value>FALSE</value></parameter>'
        '<parameter authoringApp="PremierePro"><parameterid>graphdict</parameterid><name>graphdict</name>'
        f"<valuemin>0</valuemin><valuemax>{src_f}</valuemax><value>0</value>"
        "<keyframe><when>0</when><value>0</value><speedvirtualkf>TRUE</speedvirtualkf><speedkfin>TRUE</speedkfin></keyframe>"
        f"<keyframe><when>{ht}</when><value>{hs}</value><speedvirtualkf>TRUE</speedvirtualkf><speedkfout>TRUE</speedkfout></keyframe>"
        f"<keyframe><when>{tl_f}</when><value>{src_f}</value><speedvirtualkf>TRUE</speedvirtualkf><speedkfend>TRUE</speedkfend></keyframe>"
        "<interpolation><name>FCPCurve</name></interpolation></parameter>"
        "</effect></filter>")


def _video_clipitem(cid, mcid, fid, name, start_f, end_f, shown_f, media_w, media_h, src_frames, zoom, note=None, slow_src=None, center_kf="", xf_in=0, xf_out=0, skip_in=0):
    # References its media by <file id/> — the full <file> is defined once in the bin master clip.
    # COVER the frame (fill BOTH dimensions, crop the overflow) so grok 1.5's 1920x1088 fills the 1080
    # canvas by width and loses the extra 8px, instead of filling by height and pillarboxing the sides.
    base = 100.0 * max(SEQ_W / max(1, media_w), SEQ_H / max(1, media_h))
    end_scale = base * (1 + ZOOM_PCT_PER_SEC / 100.0 * (shown_f / FPS)) if zoom else base
    # slow_src set -> the clip shows `slow_src` SOURCE frames over `shown_f` (longer) TIMELINE frames = slowed to fit.
    out_f = slow_src if slow_src else shown_f
    remap = _time_remap(slow_src, end_f - start_f) if slow_src else ""
    # crossfade handles: xf_out extends this clip's OUT past the cut, xf_in pulls its IN before source 0 — with
    # the -1 sentinel on the abutting edge (the exact shape Premiere itself writes for a centered Cross Dissolve).
    # skip_in advances the IN-point (used for a clip that FOLLOWS a baked slide: the slide already showed the
    # clip's first skip_in frames sliding in, so the real clip continues from there — no back-jump). xf_in and
    # skip_in never coexist on one clip (a clip's incoming edge has ONE transition type).
    x_start = -1 if xf_in else start_f
    x_end = -1 if xf_out else end_f
    x_in = -xf_in + skip_in
    x_out = out_f + xf_out + skip_in
    # a scene the user left a NOTE on → a clip marker carrying the note + a distinct clip colour, so it's
    # instantly spottable in Premiere ("ben anlamis olurum")
    mk, label = "", "Iris"
    raw = (str(note).strip() if note else "")
    if raw:
        mk = (f"<marker><comment>{escape(raw)}</comment><name>NOTE: {escape(raw[:50])}</name>"
              f"<in>0</in><out>-1</out></marker>")
        label = "Rose"
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{x_start}</start><end>{x_end}</end><in>{x_in}</in><out>{x_out}</out>"
        f"<pproTicksIn>{x_in * TPF}</pproTicksIn><pproTicksOut>{x_out * TPF}</pproTicksOut>"
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{_basic_motion(base, end_scale, shown_f, center_kf)}{remap}{mk}{_LOGGING}{_COLORINFO}"
        f"<labels><label2>{label}</label2></labels></clipitem>")


def _opacity_fade(clip_f, fin_f, fout_f):
    """Native Premiere Opacity (fixed effect) with fade in/out keyframes (0->100 in, 100->0 out) — carries
    an on-screen-text overlay's simple fade animation without any mogrt/extension."""
    kf = []
    if fin_f > 0:
        kf += [(0, 0), (fin_f, 100)]
    else:
        kf += [(0, 100)]
    if fout_f > 0:
        kf += [(max(fin_f, clip_f - fout_f), 100), (clip_f, 0)]
    body = "".join(f"<keyframe><when>{int(w)}</when><value>{int(v)}</value></keyframe>" for w, v in kf)
    return (
        "<filter><effect><name>Opacity</name><effectid>opacity</effectid>"
        "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
        "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>opacity</parameterid><name>Opacity</name>'
        f"<valuemin>0</valuemin><valuemax>100</valuemax><value>100</value>{body}</parameter>"
        "</effect></filter>")


# slide start/end centre offsets (normalized: horiz by width, vert by height — +vert is DOWN, per the sample).
# "slide from left" enters from the left (starts off to the left), etc. ~0.30 = a strong but on-screen slide.
_SLIDE = {"slide-left": (-0.30, 0.0), "slide-right": (0.30, 0.0),
          "slide-top": (0.0, -0.30), "slide-bottom": (0.0, 0.30)}


def _ost_basic_motion(shown, anim_in, anim_out, fin, fout, ax, ay):
    """Native Basic Motion carrying the overlay's Pop (Scale 0->100) and Slide (Center offset->0) animations —
    same filter/keyframe shape as the user's sample export. Pop pivots at the text (Anchor Point = the text's
    normalized centre). Returns '' when the overlay only fades (no Motion needed)."""
    pop_in, pop_out = (anim_in == "popup"), (anim_out == "pop")
    off_in, off_out = _SLIDE.get(anim_in), _SLIDE.get(anim_out)
    if not (pop_in or pop_out or off_in or off_out):
        return ""
    mid = max(fin, shown - fout)
    skf = ""
    if pop_in:
        skf += f"<keyframe><when>0</when><value>0</value></keyframe><keyframe><when>{fin}</when><value>100</value></keyframe>"
    if pop_out:
        skf += f"<keyframe><when>{mid}</when><value>100</value></keyframe><keyframe><when>{shown}</when><value>0</value></keyframe>"

    def cv(o):
        return f"<value><horiz>{o[0]:.6f}</horiz><vert>{o[1]:.6f}</vert></value>"
    ckf = ""
    if off_in:
        ckf += f"<keyframe><when>0</when>{cv(off_in)}</keyframe><keyframe><when>{fin}</when>{cv((0, 0))}</keyframe>"
    if off_out:
        ckf += f"<keyframe><when>{mid}</when>{cv((0, 0))}</keyframe><keyframe><when>{shown}</when>{cv(off_out)}</keyframe>"
    anc = (ax, ay) if (pop_in or pop_out) else (0.0, 0.0)   # pivot Pop at the text; slides don't need it
    return (
        "<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
        "<effectcategory>motion</effectcategory><effecttype>motion</effecttype><mediatype>video</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
        f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>100</value>{skf}</parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>rotation</parameterid><name>Rotation</name><valuemin>-8640</valuemin><valuemax>8640</valuemax><value>0</value></parameter>'
        '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
        f"<value><horiz>0</horiz><vert>0</vert></value>{ckf}</parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
        f"<value><horiz>{anc[0]:.6f}</horiz><vert>{anc[1]:.6f}</vert></value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>antiflicker</parameterid><name>Anti-flicker Filter</name><valuemin>0.0</valuemin><valuemax>1.0</valuemax><value>0</value></parameter>'
        "</effect></filter>")


def _ost_clipitem(cid, mcid, fid, name, start_f, end_f, fin_f, fout_f, anim_in="fade", anim_out="none", ax=0.0, ay=0.0):
    """A full-frame transparent PNG (rendered by caption_layer, pixel-identical to preview/render) placed on
    the overlay track V2. The text's REST placement is baked into the PNG; native Basic Motion adds the Pop/
    Slide and Opacity adds the fade. `alphatype=straight` keeps the transparency."""
    shown = end_f - start_f
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{STILL}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{shown}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown * TPF}</pproTicksOut>"
        "<alphatype>straight</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{_ost_basic_motion(shown, anim_in, anim_out, fin_f, fout_f, ax, ay)}"
        f"{_opacity_fade(shown, fin_f, fout_f)}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Lavender</label2></labels></clipitem>")


def _matte_clipitem(cid, mcid, fid, name, start_f, end_f, fade_f, peak):
    """A full-frame BLACK still (readability plate behind the on-screen text): Opacity ramps 0 -> peak% over
    `fade_f` frames, then HOLDS peak to the end (no fade-out — it ends at the scene cut)."""
    shown = end_f - start_f
    kf = [(0, 0), (max(1, min(fade_f, shown - 1)), peak), (shown, peak)]
    body = "".join(f"<keyframe><when>{int(w)}</when><value>{int(v)}</value></keyframe>" for w, v in kf)
    opac = ("<filter><effect><name>Opacity</name><effectid>opacity</effectid>"
            "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
            "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
            '<parameter authoringApp="PremierePro"><parameterid>opacity</parameterid><name>Opacity</name>'
            f"<valuemin>0</valuemin><valuemax>100</valuemax><value>{peak}</value>{body}</parameter>"
            "</effect></filter>")
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{STILL}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{shown}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown * TPF}</pproTicksOut>"
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{opac}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Iris</label2></labels></clipitem>")


def _fx_clipitem(cid, mcid, fid, name, start_f, end_f, src_frames, opacity, slow_src=None, composite=None):
    """A full-frame visual-effect video overlay (V4/V5): constant Opacity, optional Time-Remap slow-down and an
    optional composite (blend) mode. Effects are authored 1920x1080 so no scaling is needed. Each instance plays
    from the effect's start (in=0); the caller repeats it back-to-back to fill a scene."""
    shown = end_f - start_f
    out_f = slow_src if slow_src else shown
    remap = _time_remap(slow_src, shown) if slow_src else ""
    comp = f"<compositemode>{composite}</compositemode>" if composite else ""
    opac = ("<filter><effect><name>Opacity</name><effectid>opacity</effectid>"
            "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
            "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
            '<parameter authoringApp="PremierePro"><parameterid>opacity</parameterid><name>Opacity</name>'
            f"<valuemin>0</valuemin><valuemax>100</valuemax><value>{int(opacity)}</value></parameter>"
            "</effect></filter>")
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{out_f}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{out_f * TPF}</pproTicksOut>"
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f"{comp}"
        f'<file id="{fid}"/>'
        f"{opac}{remap}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Mango</label2></labels></clipitem>")


def _movfx_clipitem(cid, mcid, fid, name, start_f, end_f, src_frames, out_src, scale=100, cx=0.0, cy=0.0, rot=0,
                    composite=None, fin_f=0, fout_f=0, remap="", alpha=True):
    """A VIDEO effect overlay (e.g. a hand-drawn arrow clip) placed like an icon: Basic-Motion scale/center/rotation
    at (cx,cy), an optional screen composite so a BLACK-background clip drops its background, and an opacity fade.
    `out_src` = SOURCE frames to play (<= src_frames); the caller freezes the last frame for the rest of the window."""
    shown = end_f - start_f
    motion = ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
              "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
              "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
              '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
              f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>{int(round(scale))}</value></parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>rotation</parameterid><name>Rotation</name>'
              f"<valuemin>-8640</valuemin><valuemax>8640</valuemax><value>{int(round(rot))}</value></parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
              f"<value><horiz>{cx:.6f}</horiz><vert>{cy:.6f}</vert></value></parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
              "<value><horiz>0</horiz><vert>0</vert></value></parameter>"
              "</effect></filter>")
    comp = f"<compositemode>{composite}</compositemode>" if composite else ""
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{out_src}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{out_src * TPF}</pproTicksOut>"
        f"<alphatype>{'straight' if alpha else 'none'}</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f"{comp}"
        f'<file id="{fid}"/>'
        f"{motion}{_opacity_fade(shown, fin_f, fout_f)}{remap}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Tangerine</label2></labels></clipitem>")


def _arrow_point_kf(shown, fin_f, cx=0.0, cy=0.0, left=False, rot=0):
    """Center (Position) keyframes making the arrow JAB toward WHAT IT POINTS AT and back, over and over, around
    its resting position (cx,cy). The jab follows the arrow's actual facing = its rotation (and flip), so however
    you place/rotate it, it jabs forward-back along its own axis - never just left-right. Offsets are normalized
    full-frame units; the vertical is scaled by 16:9 so the jab is visually equal in both axes."""
    import math
    amp = 0.017                                          # short jab distance (fraction of frame width)
    sgn = -1.0 if left else 1.0                          # flipped arrow points the other way
    a = math.radians(rot or 0)
    dx = amp * sgn * math.cos(a)
    dy = amp * sgn * math.sin(a) * (SEQ_W / SEQ_H)       # vert uses /1080 -> scale so the jab isn't squashed
    def cv(x, y): return f"<value><horiz>{x:.6f}</horiz><vert>{y:.6f}</vert></value>"
    kf = [(0, (cx + dx, cy + dy))]                       # START already jabbed FORWARD so it's visibly MOVING as
    t = 0; step = max(1, int(FPS * 0.42)); out = False   # it fades in (no identical first keyframes), and it keeps
    while t < shown:                                     # jabbing THROUGH the fade-out — no dead "hold at rest"
        t = min(t + step, shown)
        kf.append((t, (cx + dx, cy + dy) if out else (cx, cy))); out = not out
    return "".join(f"<keyframe><when>{int(w)}</when>{cv(o[0], o[1])}</keyframe>" for w, o in kf)


def _icon_clipitem(cid, mcid, fid, name, start_f, end_f, fin_f, fout_f, pulse=False, center_kf="", cx=0.0, cy=0.0, scale=100, rot=0, ax=0.0, ay=0.0, pop=True, composite=None, scale_from=None):
    """A full-frame transparent PNG icon that POPS in ONCE to `scale`% (with a small overshoot), optionally
    PULSES, and/or moves via `center_kf` (arrow jab), then fades via Opacity. `pop=False` skips the scale pop so
    the icon just fades in (arrows). Anchor Point (ax,ay) is kept STANDARD (0,0 = clip centre); the icon art is
    pre-CENTRED in its PNG so 0,0 already sits on the art centre — that keeps the XML position identical to the
    preview (a non-standard anchor made Premiere place it off). Reliable native Basic Motion."""
    shown = end_f - start_f
    tgt = max(10, int(round(scale)))
    over = int(round(tgt * 1.15))
    pk = max(1, int(fin_f * 0.6))
    if pop:                                              # POP in: 0 -> overshoot -> settle
        if scale_from is not None:                       # DRAW in from a set scale (e.g. spotlight 135% -> 100%), no 0-overshoot
            kf = [(0, max(1, int(round(scale_from)))), (max(pk + 1, fin_f), tgt)]
        else:
            kf = [(0, 0), (pk, over), (max(pk + 1, fin_f), tgt)]
        if pulse:                                        # then an OCCASIONAL single pulse
            t = max(pk + 1, fin_f) + int(FPS * 1.2)      # first pulse ~1.2s after it settles
            gap = int(FPS * 1.8); bump = max(2, int(FPS * 0.12))
            while t + 2 * bump < shown - fout_f:
                kf += [(t, tgt), (t + bump, int(round(tgt * 1.13))), (t + 2 * bump, tgt)]
                t += gap
            kf.append((shown, tgt))
        scale_base, scale_kf = 0, "".join(f"<keyframe><when>{int(w)}</when><value>{v}</value></keyframe>" for w, v in kf)
    else:                                                # NO pop: constant scale (it simply fades in via Opacity)
        scale_base, scale_kf = tgt, ""
    motion = ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
              "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
              "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
              '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
              f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>{scale_base}</value>{scale_kf}</parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>rotation</parameterid><name>Rotation</name>'
              f"<valuemin>-8640</valuemin><valuemax>8640</valuemax><value>{int(round(rot))}</value></parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
              f"<value><horiz>{cx:.6f}</horiz><vert>{cy:.6f}</vert></value>{center_kf}</parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
              f"<value><horiz>{ax:.6f}</horiz><vert>{ay:.6f}</vert></value></parameter>"
              "</effect></filter>")
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{STILL}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{shown}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown * TPF}</pproTicksOut>"
        "<alphatype>straight</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{motion}{_opacity_fade(shown, fin_f, fout_f)}{_LOGGING}{_COLORINFO}"
        f"{('<compositemode>' + composite + '</compositemode>') if composite else ''}"
        "<labels><label2>Tangerine</label2></labels></clipitem>")


def _icon_hue_file(src, hue):
    """Return a recoloured copy of an icon PNG. The art is red; `hue` (0-359 degrees) is SET as the ABSOLUTE hue
    for every coloured pixel (saturation + value kept, so the 3D gloss/shadow survive). Because the hue is set
    absolutely (not rotated relative to each icon's own red), EVERY icon lands on the exact same tone for a given
    colour - the arrow's yellow == the X's yellow. Cached next to the source as <stem>_H<deg>.png.
    hue 0 (or any failure) -> the original file (the icons' native red)."""
    try:
        hue = int(round(hue))
    except Exception:
        hue = 0
    if hue not in (900, 901):                             # 900 = White, 901 = Charcoal (achromatic); others = a real hue
        hue = hue % 360
    if not hue:
        return src
    src = Path(src)
    out = src.with_name(f"{src.stem}_H{hue}{src.suffix}")
    if out.exists():
        return out
    try:
        from PIL import Image
        im = Image.open(src).convert("RGBA")
        r, g, b, a = im.split()
        h, s, v = Image.merge("RGB", (r, g, b)).convert("HSV").split()
        if hue in (900, 901):                             # WHITE / CHARCOAL: desaturate + shift brightness (keeps 3D shading)
            s = s.point(lambda _p: 0)
            v = v.point((lambda p: min(255, int(p * 1.35 + 55))) if hue == 900 else (lambda p: int(p * 0.33)))
        else:
            tgt = int(round(hue / 360.0 * 255)) % 256
            h = h.point(lambda _p: tgt)                   # SET absolute hue (uniform across all icons)
        rgb = Image.merge("HSV", (h, s, v)).convert("RGB")
        Image.merge("RGBA", (*rgb.split(), a)).save(out, "PNG")
        return out
    except Exception:
        return src


# On-screen art WIDTH as a fraction of the 1920 frame — MUST match `_ICON_BASE` in static/app.js so the export
# renders each icon at exactly the size shown in the preview editor.
_ICON_ONSCREEN = {"x": 0.24, "arrow": 0.27, "check": 0.27, "sparkle": 0.22}
# VIDEO effect overlays: kind -> a full-frame clip in Icons/ (black background => screen composite drops it). Each
# has a matching `<stem>_t.png` (the keyed last frame) used to FREEZE the animation for the rest of its window and
# as the scene-card thumbnail. Add a new drawn/animated effect = drop the .mp4 + its _t.png here + one JS/button line.
# kind -> (blend, filename). blend "alpha" = the clip already has a real alpha channel (ProRes .mov) -> used
# directly, composited NORMALLY. blend "key" = white-on-black .mp4 -> keyed to a tinted alpha ProRes at build
# time (_movfx_alpha_file). Mirror of _VFX in app.js. Add a clip = one line here + one in app.js.
_VFX = {
    "movarrow": ("key", "icon_movarrow.mp4"),
    "va1": ("alpha", "icon_va1.mov"), "va2": ("alpha", "icon_va2.mov"),
    "va3": ("alpha", "icon_va3.mov"), "va4": ("alpha", "icon_va4.mov"),
    "xv1": ("alpha", "icon_xv1.mov"), "xv2": ("alpha", "icon_xv2.mov"),
    "cancel": ("alpha", "icon_cancel.mov"), "chkg": ("alpha", "icon_chkg.mov"),
    "hw1": ("key", "icon_hw1.mp4"), "hw4": ("key", "icon_hw4.mp4"),
    "hw6": ("key", "icon_hw6.mp4"), "hw9": ("key", "icon_hw9.mp4"),
    "warn": ("alpha", "icon_warn.mov"), "ques": ("key", "icon_ques.mp4"), "time": ("alpha", "icon_time.mov"),
}
_MOV_FX = _VFX
# Palette hue -> tint RGB (matches _ICON_PALETTE in app.js). hue 0 / unknown = native (white). Used to colour a
# white-on-black effect clip for EXPORT (the preview tints live via an SVG filter).
_MOVFX_TINT = {0: (230, 54, 45), 28: (240, 138, 29), 50: (245, 197, 24), 120: (63, 182, 79),
               172: (31, 182, 166), 210: (47, 127, 240), 280: (155, 83, 214), 901: (43, 43, 43)}
# hue 900 (White) is absent -> _movfx_hue_file returns the native (white) clip unchanged.


def _movfx_alpha_file(src, hue):
    """Key a white-on-black effect clip to a REAL-ALPHA ProRes 4444 .mov (black -> TRANSPARENT), FORCING the art to
    the chosen colour so anti-aliased edges fade colour->transparent (no dark halo). Premiere then composites it
    with NORMAL blend — no screen tricks, so it never washes out over a bright scene or shows a black box. The
    colour is baked in, so a whole tinted clip is cached per hue as <stem>_A<deg>.mov. Falls back to the mp4."""
    try:
        hue = int(round(hue))
    except Exception:
        hue = 0
    key = hue if hue in (900, 901) else (hue % 360)
    rgb = _MOVFX_TINT.get(key) or (255, 255, 255)         # 900 (white) / unknown -> white; 0 -> red; 120 -> green; ...
    src = Path(src)
    out = src.with_name(f"{src.stem}_A{hue}.mov")
    if out.exists():
        return out
    R, G, B = rgb
    geq = (f"format=rgba,geq=r='{R}':g='{G}':b='{B}':"
           f"a='clip(0.7*(r(X\\,Y)+g(X\\,Y)+b(X\\,Y))\\,0\\,255)'")
    try:
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-nostats", "-i", str(src),
                        "-vf", geq, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
                        "-an", str(out)],
                       capture_output=True, timeout=180, creationflags=_NO_WINDOW)
        if out.exists() and out.stat().st_size > 0:
            return out
    except Exception:
        pass
    return src
_ICON_GEOM = {}
def _icon_geom(path):
    """(art_width_fraction, art_centre_x_frac, art_centre_y_frac) of a full-frame icon PNG, from its opaque
    bounding box. The art rarely fills the canvas or sits dead-centre, so the export must measure it (exactly like
    the OST overlay does) to place/size it WYSIWYG. Cached per path."""
    key = str(path)
    if key in _ICON_GEOM:
        return _ICON_GEOM[key]
    g = (0.2, 0.5, 0.5)
    try:
        from PIL import Image
        im = Image.open(path).convert("RGBA")
        w, h = im.size
        bb = im.getbbox()
        if bb and w and h:
            g = ((bb[2] - bb[0]) / w, (bb[0] + bb[2]) / 2 / w, (bb[1] + bb[3]) / 2 / h)
    except Exception:
        pass
    _ICON_GEOM[key] = g
    return g


def _ripple_clipitem(cid, mcid, fid, name, start_f, end_f, s0=40, s1=180, op0=85, cx=0.0, cy=0.0):
    """One radiating red ring: Scale GROWS s0->s1 while Opacity FADES op0->0 (a pain-point wave). The caller
    staggers several so new waves keep emerging as old ones expand and vanish."""
    shown = end_f - start_f
    scale_kf = (f"<keyframe><when>0</when><value>{s0}</value></keyframe>"
                f"<keyframe><when>{shown}</when><value>{s1}</value></keyframe>")
    motion = ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
              "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
              "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
              '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
              f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>{s0}</value>{scale_kf}</parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
              f"<value><horiz>{cx:.6f}</horiz><vert>{cy:.6f}</vert></value></parameter>"
              '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
              "<value><horiz>0</horiz><vert>0</vert></value></parameter>"
              "</effect></filter>")
    opac = ("<filter><effect><name>Opacity</name><effectid>opacity</effectid>"
            "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
            "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
            '<parameter authoringApp="PremierePro"><parameterid>opacity</parameterid><name>Opacity</name>'
            f"<valuemin>0</valuemin><valuemax>100</valuemax><value>{op0}</value>"
            f"<keyframe><when>0</when><value>{op0}</value></keyframe>"
            f"<keyframe><when>{shown}</when><value>0</value></keyframe></parameter></effect></filter>")
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{STILL}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{shown}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown * TPF}</pproTicksOut>"
        "<alphatype>straight</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{motion}{opac}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Tangerine</label2></labels></clipitem>")


def _audio_clipitem(cid, mcid, fid, name, start_f, shown_f, src_frames, channels, fin, fout, peak=1.0):
    ctype = "stereo" if channels >= 2 else "mono"
    return (
        f'<clipitem id="{cid}" premiereChannelType="{ctype}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{start_f + shown_f}</end><in>0</in><out>{shown_f}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown_f * TPF}</pproTicksOut>"
        f'<file id="{fid}"/>'
        "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
        f"{_audio_levels(shown_f, fin, fout, peak)}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Caribbean</label2></labels></clipitem>")


# ---- bin master clips (define each media file ONCE; clipitems reference by masterclipid) ----
def _uuid(seed):
    h = hashlib.md5(seed.encode("utf-8")).hexdigest()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def _video_master(e):
    # Mirror Premiere's OWN FCP7 export of a bin master clip (from the user's asdasdasd.xml sample):
    # the <file> lives INSIDE clip/media/video/track/clipitem — NOT as a direct child of <clip>.
    # The old file-as-direct-child form made Premiere fail to recognise the master and dump the
    # media into a "Recovered files" bin instead of the Images/Videos bin.
    # Clip order: uuid, masterclipid, ismasterclip, duration, rate, name, media, logginginfo,
    # colorinfo, labels. The inner clipitem order: masterclipid, name, rate, alphatype,
    # pixelaspectratio, anamorphic, file.
    # <clip>/<clipitem> NAME = the friendly order-accurate label (NN_sentence); the <file><name>
    # inside keeps the REAL basename so Premiere still relinks the media.
    lbl = escape(e.get("label") or e["name"])
    return (
        f'<clip id="{e["mcid"]}" explodedTracks="true"><uuid>{_uuid(e["mcid"])}</uuid>'
        f'<masterclipid>{e["mcid"]}</masterclipid><ismasterclip>TRUE</ismasterclip>'
        f'<duration>{e["src"]}</duration>{_rate()}<name>{lbl}</name>'
        "<media><video><track>"
        f'<clipitem id="{e["icid"]}"><masterclipid>{e["mcid"]}</masterclipid>'
        f'<name>{lbl}</name>{_rate()}'
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'{_video_file(e["fid"], e["path"], e["src"], e["w"], e["h"], still=e["still"])}'
        "</clipitem></track></video></media>"
        f"{_LOGGING}{_COLORINFO}<labels><label2>Lavender</label2></labels></clip>")


def _audio_master(e):
    # Mirror Premiere's OWN audio master clip: a STEREO file is exploded into two mono <track>s,
    # linked together; the full <file> is defined on the first clipitem and referenced empty on the
    # second. Mono files use a single track. (Same nesting fix as _video_master.)
    ch = max(1, e["channels"])
    file_full = _audio_file(e["fid"], e["path"], e["src"], e["channels"])
    file_ref = f'<file id="{e["fid"]}"/>'
    icid1 = e["icid"]
    if ch >= 2:
        icid2 = e.get("icid2") or (icid1 + "-b")
        links = (
            f'<link><linkclipref>{icid1}</linkclipref><mediatype>audio</mediatype>'
            "<trackindex>1</trackindex><clipindex>1</clipindex><groupindex>1</groupindex></link>"
            f'<link><linkclipref>{icid2}</linkclipref><mediatype>audio</mediatype>'
            "<trackindex>2</trackindex><clipindex>1</clipindex><groupindex>1</groupindex></link>")
        tracks = (
            f'<track><clipitem id="{icid1}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_full}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
            f"{links}</clipitem></track>"
            f'<track><clipitem id="{icid2}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_ref}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>2</trackindex></sourcetrack>"
            f"{links}</clipitem></track>")
    else:
        tracks = (
            f'<track><clipitem id="{icid1}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_full}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
            "</clipitem></track>")
    return (
        f'<clip id="{e["mcid"]}" explodedTracks="true"><uuid>{_uuid(e["mcid"])}</uuid>'
        f'<masterclipid>{e["mcid"]}</masterclipid><ismasterclip>TRUE</ismasterclip>'
        f'<duration>{e["src"]}</duration>{_rate()}<name>{escape(e["name"])}</name>'
        f"<media><audio>{tracks}</audio></media>"
        f"{_LOGGING}{_COLORINFO}<labels><label2>Caribbean</label2></labels></clip>")


def _bin(name, inner):
    return f"<bin><name>{escape(name)}</name><children>{inner}</children></bin>" if inner else ""


_VTRACK_ATTRS = 'TL.SQTrackShy="0" TL.SQTrackExpandedHeight="41" TL.SQTrackExpanded="0" MZ.TrackTargeted="1"'
_ATRACK_ATTRS = ('TL.SQTrackAudioKeyframeStyle="0" TL.SQTrackShy="0" TL.SQTrackExpandedHeight="41" '
                 'TL.SQTrackExpanded="0" MZ.TrackTargeted="1" PannerCurrentValue="0.5" PannerIsInverted="true" '
                 'PannerStartKeyframe="-91445760000000000,0.5,0,0,0,0,0,0" PannerName="Balance" '
                 'currentExplodedTrackIndex="0" totalExplodedTrackCount="1" premiereTrackType="Stereo"')


def _vtrack(items):
    # items are (start_frame, rank, xml); sort by (start, rank) so transitions (rank 0) sit just BEFORE the
    # clipitem (rank 1) they lead into — matching Premiere's document order — and clips stay in timeline order.
    body = "".join(x for _, _, x in sorted(items, key=lambda t: (t[0], t[1])))
    return (f"<track {_VTRACK_ATTRS}>" + body +
            "<enabled>TRUE</enabled><locked>FALSE</locked></track>")


def _vtracks_layered(items):
    """items = (start_frame, end_frame, xml). Pack into as FEW stacked video tracks as possible so that clips
    which OVERLAP IN TIME land on DIFFERENT tracks (a clip can't overlap itself on one track — that's why several
    icons in one scene, or the expanding pain-point rings, collided/serialized before). Greedy interval-graph
    lane assignment; returns concatenated <track> XML, lowest lane first (later lanes render on top)."""
    lanes = []                                           # each: {"end": last_end_frame, "xml": [..]}
    for start, end, xml in sorted(items, key=lambda t: (t[0], t[1])):
        lane = next((L for L in lanes if start >= L["end"]), None)
        if lane is None:
            lane = {"end": 0, "xml": []}; lanes.append(lane)
        lane["xml"].append(xml); lane["end"] = end
    return "".join(f"<track {_VTRACK_ATTRS}>" + "".join(L["xml"]) +
                   "<enabled>TRUE</enabled><locked>FALSE</locked></track>" for L in lanes)


XF_D2 = max(1, int(round(FPS * 0.5)) // 2)     # crossfade half-length (each clip extends this far past the cut)


def _xfade_transition(cut_f, effect="Cross Dissolve"):
    """A centered dissolve on the cut (the SAME shape as the user's sample: alignment=center,
    cutPointTicks = half-length, both clips extended by XF_D2 via handles / -1 sentinels).
    `effect` = 'Cross Dissolve' (crossfade, A dissolves into B) or 'Dip to White' (flash: A->white->B)."""
    return (f"<transitionitem><start>{cut_f - XF_D2}</start><end>{cut_f + XF_D2}</end>"
            f"<alignment>center</alignment><cutPointTicks>{XF_D2 * TPF}</cutPointTicks>"
            f"<rate><timebase>{FPS}</timebase><ntsc>FALSE</ntsc></rate>"
            f"<effect><name>{effect}</name><effectid>{effect}</effectid>"
            "<effectcategory>Dissolve</effectcategory><effecttype>transition</effecttype>"
            "<mediatype>video</mediatype><wipecode>0</wipecode><wipeaccuracy>100</wipeaccuracy>"
            "<startratio>0</startratio><endratio>1</endratio><reverse>FALSE</reverse></effect></transitionitem>")


def _dip_transition(start_f, end_f, align, white=False):
    """A single-sided fade against black/white at a clip's start — the SAME native pattern as the user's own
    working export (Cross Dissolve + start-black). It needs NO media handles (the black/white side has no
    footage), so it's safe with our in=0, butt-jointed clips. `align` = 'start-black' / 'start-white'."""
    name = "Dip to White" if white else "Cross Dissolve"
    return (f"<transitionitem><start>{start_f}</start><end>{end_f}</end>"
            f"<alignment>{align}</alignment><cutPointTicks>0</cutPointTicks>"
            f"<rate><timebase>{FPS}</timebase><ntsc>FALSE</ntsc></rate>"
            f"<effect><name>{name}</name><effectid>{name}</effectid>"
            "<effectcategory>Dissolve</effectcategory><effecttype>transition</effecttype>"
            "<mediatype>video</mediatype><wipecode>0</wipecode><wipeaccuracy>100</wipeaccuracy>"
            "<startratio>0</startratio><endratio>1</endratio><reverse>FALSE</reverse></effect></transitionitem>")


def _atrack(items, out_idx):
    return (f"<track {_ATRACK_ATTRS}>" + "".join(items) +
            f"<enabled>TRUE</enabled><locked>FALSE</locked><outputchannelindex>{out_idx}</outputchannelindex></track>")


def _atracks_layered(items):
    """items = (start_frame, end_frame, xml) music clips. Pack into as FEW stacked audio tracks as possible so
    clips that OVERLAP IN TIME — both segment-to-segment crossfades AND loop-to-loop crossfades — land on
    DIFFERENT tracks (a clip can't overlap itself on one track). Greedy interval lane assignment; lanes route to
    output channel 1/2 alternately (the source clips are stereo, so this is just track routing, not panning)."""
    lanes = []                                             # each: {"end": last_end_frame, "xml": [..]}
    for start, end, xml in sorted(items, key=lambda t: (t[0], t[1])):
        lane = next((L for L in lanes if start >= L["end"]), None)
        if lane is None:
            lane = {"end": 0, "xml": []}; lanes.append(lane)
        lane["xml"].append(xml); lane["end"] = end
    return "".join(_atrack(L["xml"], 1 if idx % 2 == 0 else 2) for idx, L in enumerate(lanes))


_AUDIO_HEADER = (
    "<numOutputChannels>2</numOutputChannels>"
    "<format><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics></format>"
    "<outputs>"
    "<group><index>1</index><numchannels>1</numchannels><downmix>0</downmix><channel><index>1</index></channel></group>"
    "<group><index>2</index><numchannels>1</numchannels><downmix>0</downmix><channel><index>2</index></channel></group>"
    "</outputs>")

# Sequence attribute set, matching the user's own working Premiere export (test.xml)
# key-for-key, EXCEPT the timeline-position attributes (edit line, work area, program
# zoom) — those must be within THIS sequence's duration, not copied from a 250-second
# project, or Premiere rejects the file as "damaged".
def _seq_attrs(total_f):
    end_ticks = max(1, total_f) * TPF
    return ('TL.SQAudioVisibleBase="0" TL.SQVideoVisibleBase="0" TL.SQVisibleBaseTime="0" '
            'TL.SQAVDividerPosition="0.5" TL.SQHideShyTracks="0" TL.SQHeaderWidth="204" '
            'TL.SQDataTrackViewControlState="0" '
            f'Monitor.ProgramZoomOut="{end_ticks}" Monitor.ProgramZoomIn="0" '
            'TL.SQTimePerPixel="0.2" MZ.EditLine="0" '
            'MZ.Sequence.PreviewFrameSizeHeight="1080" MZ.Sequence.PreviewFrameSizeWidth="1920" '
            'MZ.Sequence.AudioTimeDisplayFormat="200" MZ.Sequence.PreviewRenderingClassID="1061109567" '
            'MZ.Sequence.PreviewRenderingPresetCodec="1919706400" '
            'MZ.Sequence.PreviewRenderingPresetPath="EncoderPresets\\SequencePreview\\'
            '9678af98-a7b7-4bdb-b477-7ac9c8df4a4e\\QuickTime.epr" '
            'MZ.Sequence.PreviewUseMaxRenderQuality="false" MZ.Sequence.PreviewUseMaxBitDepth="false" '
            'MZ.Sequence.EditingModeGUID="9678af98-a7b7-4bdb-b477-7ac9c8df4a4e" '
            'MZ.Sequence.VideoTimeDisplayFormat="104" '
            f'MZ.WorkOutPoint="{end_ticks}" MZ.WorkInPoint="0" explodedTracks="true"')

# Sequence video codec block, copied verbatim from the working export.
_CODEC = ("<codec><name>Apple ProRes 422</name><appspecificdata>"
          "<appname>Final Cut Pro</appname><appmanufacturer>Apple Inc.</appmanufacturer>"
          "<appversion>7.0</appversion><data><qtcodec>"
          "<codecname>Apple ProRes 422</codecname><codectypename>Apple ProRes 422</codectypename>"
          "<codectypecode>apcn</codectypecode><codecvendorcode>appl</codecvendorcode>"
          "<spatialquality>1024</spatialquality><temporalquality>0</temporalquality>"
          "<keyframerate>0</keyframerate><datarate>0</datarate></qtcodec></data></appspecificdata></codec>")


# ---- baked scene transitions (rendered clips on V2) ------------------------
# FCP7 XML can't carry Push/Slide or motion blur, AND native transitions freeze a clip that has no spare
# frames. So every non-'none' transition is BAKED with ffmpeg (both clips' REAL frames play through it) and
# dropped on an overlay track. Slides also get motion blur + a synced whoosh. Names mirror render_video.
_XFADE = {"crossfade": "fade", "dip-black": "fadeblack", "dip-white": "fadewhite"}   # slides removed
TRANS_SEC = 0.5                                    # transition length (seconds) — dips / crossfade
_COVER_VF = (f"scale={SEQ_W}:{SEQ_H}:force_original_aspect_ratio=increase,"
             f"crop={SEQ_W}:{SEQ_H},setsar=1,fps={FPS},format=yuv420p")


def _gen_whoosh(path):
    """Generate a subtle, QUIET slide whoosh once (filtered pink-noise sweep). No-op if it already exists."""
    if path.exists() and path.stat().st_size > 0:
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "anoisesrc=d=0.5:c=pink:a=0.5",
           "-af", ("afade=t=in:st=0:d=0.08,afade=t=out:st=0.30:d=0.20,"
                   "highpass=f=300,lowpass=f=6000,volume=0.35"),
           "-ar", "48000", "-ac", "2", str(path)]
    try:
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return None
    return path if (path.exists() and path.stat().st_size > 0) else None


def _render_transition(a_path, a_img, b_path, b_img, xfade_name, blur, out_path, zoom_a=1.0, sec=TRANS_SEC):
    """Render a `sec`-second clip: A's REAL tail sliding/dissolving into B's REAL head (both PLAY, no freeze).
    `blur` adds a smooth directional blur (slides). `zoom_a` pre-zooms the OUTGOING side to the Ken-Burns scale
    it reached on V1 (so the outgoing doesn't 'pop out' to un-zoomed at the cut). 1920x1080 @ FPS h264."""
    out_path.parent.mkdir(parents=True, exist_ok=True)   # ffmpeg -y can't create the dir; a missing dir = silent fail
    d = sec
    ain = (["-loop", "1", "-t", "1", "-i", str(a_path)] if a_img else ["-sseof", "-1", "-i", str(a_path)])
    binp = (["-loop", "1", "-t", "1", "-i", str(b_path)] if b_img else ["-t", "1", "-i", str(b_path)])
    acov = _COVER_VF
    if zoom_a and zoom_a > 1.001:                         # match the outgoing clip's Ken-Burns zoom (centre crop)
        acov += f",scale=iw*{zoom_a:.4f}:ih*{zoom_a:.4f},crop={SEQ_W}:{SEQ_H}"
    chain = (f"[0:v]{acov}[a];[1:v]{_COVER_VF}[b];"
             f"[a][b]xfade=transition={xfade_name}:duration={d}:offset={1.0 - d:.3f},"
             f"trim=start={1.0 - d:.3f}:duration={d},setpts=PTS-STARTPTS")
    if blur:
        # SLIDE motion blur — smooth DIRECTIONAL blur (two box passes along the slide axis), IDENTICAL to the
        # in-app render (render_video.py). NOT tmix: tmix averages 4 consecutive frames, which on a fast full-
        # frame slide stacks the picture into a ghost/echo trail. avgblur blurs in space, so it reads as speed.
        rad = max(2, round(SEQ_W / 150))                     # ~13 at 1080p, same as the app render
        horiz = xfade_name in ("slideleft", "slideright")
        sx, sy = (rad, 1) if horiz else (1, rad)
        chain += f",avgblur=sizeX={sx}:sizeY={sy},avgblur=sizeX={sx}:sizeY={sy}"
    chain += ",format=yuv420p[o]"
    cmd = (["ffmpeg", "-y", "-v", "error"] + ain + binp +
           ["-filter_complex", chain, "-map", "[o]", "-t", str(d), "-r", str(FPS),
            "-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p", str(out_path)])
    try:
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=180, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return None
    return out_path if (out_path.exists() and out_path.stat().st_size > 0) else None


# ---- main assembler --------------------------------------------------------
def build_premiere_xml(project_title, proj_dir, doc, srt_text, vo_audio_path,
                       bgm_root, claude_fn=None, music_segments=None, words_override=None,
                       scene_video_override=None):
    """Return (xml_string, info_dict). `music_segments` = pre-resolved segments (with path/lufs/tp/
    src_dur) to honor the user's per-segment track choices; if None, they're computed here."""
    proj_dir = Path(proj_dir)
    warnings = []

    vo_dur = audio_duration(vo_audio_path) or 0.0
    cues = parse_srt(srt_text)
    if not cues:
        raise ValueError("the SRT has no readable cues")
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # refine MID-cue scene starts with the real spoken-word onset (word list); cue-aligned scenes
    # are untouched, so the confirmed frame-exact caption sync is preserved
    words = words_override if words_override is not None else load_word_tsv(proj_dir / "subtitle")   # override = time-remapped words (custom-VO splice)
    word_starts = word_scene_starts(scenes, words) if words else None
    ranges, included = scene_time_ranges(scenes, cues, total, word_starts)

    ids = {"c": 0, "m": 0, "f": 0}
    def nid(k):
        ids[k] += 1
        return ids[k]

    # media registry: each distinct file becomes ONE bin master clip; clipitems reference it by id
    reg = {}
    def register(path, kind, w=0, h=0, src=0, still=False, channels=0, label=None):
        key = str(Path(path).resolve())
        e = reg.get(key)
        if not e:
            # icid = the master clip's OWN internal catalog clipitem (holds the full <file>).
            # Drawn from the same 'c' counter as sequence clipitems so all ids stay globally unique.
            # `label` = the friendly bin/clip name (NN_sentence); `name` stays the real basename.
            e = {"fid": f"file-{nid('f')}", "mcid": f"masterclip-{nid('m')}", "kind": kind,
                 "name": Path(path).name, "label": label or Path(path).name, "path": path,
                 "w": w, "h": h, "src": src,
                 "still": still, "channels": channels, "icid": f"clipitem-{nid('c')}"}
            if kind in ("vo", "music") and channels >= 2:
                e["icid2"] = f"clipitem-{nid('c')}"   # second exploded mono track for a stereo file
            reg[key] = e
        return e

    # ---- red matte still (gaps / blank scenes) ----------------------------
    red_png = proj_dir / "export" / "red_matte.png"
    red_png.parent.mkdir(parents=True, exist_ok=True)
    if not red_png.exists():
        try:
            from PIL import Image
            Image.new("RGB", (SEQ_W, SEQ_H), (200, 30, 30)).save(red_png, "PNG")
        except Exception as e:
            warnings.append(f"could not create red matte image: {e}")
    # white matte for the FLASH transition (a white full-frame still that fades 0->100->0 over the cut).
    white_png = proj_dir / "export" / "white_matte.png"
    if not white_png.exists():
        try:
            from PIL import Image
            Image.new("RGB", (SEQ_W, SEQ_H), (255, 255, 255)).save(white_png, "PNG")
        except Exception as e:
            warnings.append(f"could not create white matte image: {e}")
    # black matte for the on-screen-text readability PLATE (fades in to 20% just before the text, holds to end).
    black_png = proj_dir / "export" / "black_matte.png"
    if not black_png.exists():
        try:
            from PIL import Image
            Image.new("RGB", (SEQ_W, SEQ_H), (0, 0, 0)).save(black_png, "PNG")
        except Exception as e:
            warnings.append(f"could not create black matte image: {e}")

    v_items = []
    ost_specs = []                                   # on-screen text overlays -> transparent PNGs on V6
    trans_items = []                                 # baked slide transition clips + flash matte (V2)
    matte_items = []                                 # dark readability plate behind the on-screen text (V3)
    fx4_items = []                                   # effect2.mp4 overlay (V4) on serious/negative realistic scenes
    fx5_items = []                                   # effect1.mp4 overlay (V5), slowed 25%
    icon_items = []                                  # animated X / arrow / pain-burst icons (V7)
    whoosh_items = []                                # synced slide-whoosh audio clips (low level, under the VO)
    sfx_items = []                                   # scene sound effects (ambulance / monitor / hit / time)

    # Visual-effect overlays: two mp4s (next to this module, in "Visual Effects/") placed on V4 & V5 over the
    # scenes flagged fx_on that are ALSO realistic (style == natural). effect1 -> V5 (slowed to 75% speed,
    # opacity 70, multiply); effect2 -> V4 (opacity 55, hue set in Premiere). Each is repeated to fill the scene.
    _fx_dir = Path(__file__).resolve().parent / "Visual Effects"
    fx_defs = {}
    for key, fn, opac, comp, speed in [("fx5", "effect1.mp4", 70, "multiply", 0.25),
                                       ("fx4", "effect2.mp4", 55, None, 1.0)]:
        p = _fx_dir / fn
        if p.exists():
            ds, fw, fh = ffprobe_media(p)
            fx_defs[key] = {"path": p, "w": fw or SEQ_W, "h": fh or SEQ_H,
                            "src": _f(ds) if ds else 0, "opac": opac, "comp": comp, "speed": speed}
        else:
            warnings.append(f"visual effect not found: {p.name}")

    def _add_fx(key, items, span_start, span_end, label):
        fd = fx_defs.get(key)
        if not fd or fd["src"] <= 0:
            return
        speed = fd["speed"] or 1.0
        eff_len = int(round(fd["src"] / speed))              # this effect's on-timeline length per instance
        if eff_len <= 0:
            return
        cur = span_start
        while cur < span_end:
            L = min(span_end - cur, eff_len)
            slow = None
            if speed != 1.0:
                slow = max(1, min(int(round(L * speed)), fd["src"]))
            er = register(fd["path"], "video", fd["w"], fd["h"], fd["src"], still=False, label=label)
            items.append((cur, 1, _fx_clipitem(f"clipitem-{nid('c')}", er["mcid"], er["fid"], label,
                          cur, cur + L, fd["src"], fd["opac"], slow_src=slow, composite=fd["comp"])))
            cur += L

    # animated ICON overlays (V7): a per-scene `icon` (x / arrow / burst) -> a full-frame transparent PNG that
    # pops in (Basic Motion), holds ~2s (burst pulses), and fades. Art lives in "Icons/" next to this module.
    _icon_dir = Path(__file__).resolve().parent / "Icons"
    _icon_files = {"x": "icon_x.png", "arrow": "icon_arrow.png", "check": "icon_check.png",
                   "sparkle": "icon_sparkle.png"}

    def _add_icon(kind, s_f, e_f, span, label, ix=0.5, iy=0.5, in_frac=0.0, out_frac=1.0, size=1.0, rot=0, flip=False, hue=0):
        """Place ONE animated icon with its CENTRE at normalized position (ix,iy) on the frame (0.5,0.5 = centre),
        scaled by `size`, rotated by `rot`deg; `flip` mirrors the arrow (points left). `in_frac`/`out_frac` are the
        icon's on/off times as a fraction of the scene (set on the Assemble timeline) — default whole scene."""
        kind = (kind or "").strip().lower()
        size = min(1.6, max(0.35, size or 1.0))
        cx, cy = (ix - 0.5), (iy - 0.5)                      # icon CENTRE at (ix,iy) — WYSIWYG with the preview editor
        in_frac = min(1.0, max(0.0, in_frac if in_frac is not None else 0.0))
        out_frac = min(1.0, max(0.0, out_frac if out_frac is not None else 1.0))
        base = s_f + int(round(span * in_frac))              # icon ON time (Assemble timeline; default scene start)
        if kind == "x" and in_frac <= 0.001:
            base += _f(0.4)                                  # ONLY the X pops in a beat after the scene starts (unless timed later)
        iend = s_f + int(round(span * out_frac)) if out_frac < 0.999 else e_f   # icon OFF time (default scene end)
        istart = base
        idur = iend - istart
        if idur < _f(0.4):
            return
        if kind == "burst":
            # PAIN POINT: STEADY, evenly-spaced radiating red rings FROM (ix,iy) — each grows at a constant rate
            # and fades; well spaced so it reads as a calm pulse, not an accelerating swarm.
            rp = _icon_dir / "icon_ring.png"
            if not rp.exists():
                warnings.append("icon not found: icon_ring.png"); return
            rp = _icon_hue_file(rp, hue)
            er = register(rp, "image", SEQ_W, SEQ_H, STILL, still=True, label=label)
            life = _f(1.9); stagger = _f(0.95); win_end = iend   # emit waves until the icon's OFF time (Assemble timeline)
            s0 = int(round(45 * size)); s1 = int(round(170 * size))
            t = istart
            while t < win_end:
                rend = min(t + life, iend)
                if rend - t >= _f(0.6):
                    icon_items.append((t, rend, _ripple_clipitem(f"clipitem-{nid('c')}", er["mcid"], er["fid"],
                                       label, t, rend, s0=s0, s1=s1, cx=cx, cy=cy)))
                t += stagger
            return
        if kind in _VFX:
            # VIDEO effect: real ALPHA, composited NORMALLY. Time-remapped to fill the icon window so the animation
            # completes within the scene. Scale/centre/rotation = the user's placement. `blend "key"` clips are
            # white-on-black and get keyed+tinted to alpha here; `blend "alpha"` clips already have alpha.
            blend, fn = _VFX[kind]
            mv = _icon_dir / fn
            if not mv.exists():
                warnings.append(f"effect clip not found: {mv.name}"); return
            if blend == "key":
                mv = _movfx_alpha_file(mv, hue)         # white-on-black -> tinted REAL-ALPHA ProRes .mov
            vdur, vw, vh = ffprobe_media(mv)
            src_fr = _f(vdur) if vdur else _f(5.0)
            er = register(mv, "video", vw or SEQ_W, vh or SEQ_H, src_fr, still=False, label=label)
            scv = int(round(100 * size)); cxm, cym = (ix - 0.5), (iy - 0.5)
            remap = _time_remap(src_fr, idur) if abs(idur - src_fr) > 1 else ""
            icon_items.append((istart, iend, _movfx_clipitem(f"clipitem-{nid('c')}", er["mcid"], er["fid"], label,
                               istart, iend, src_fr, src_fr, scale=scv, cx=cxm, cy=cym, rot=rot,
                               composite=None, fin_f=_f(0.15), fout_f=0, remap=remap, alpha=True)))
            return
        fn = _icon_files.get(kind)
        if kind == "arrow" and flip:
            fn = "icon_arrow_flip.png"                       # mirrored (points LEFT)
        if not fn:
            return
        ip = _icon_dir / fn
        if not ip.exists():
            warnings.append(f"icon not found: {fn}"); return
        # WYSIWYG with the preview editor: measure the art inside the PNG and pick a Basic-Motion Scale so the
        # art's WIDTH hits _ICON_ONSCREEN[kind]*size of the frame. Anchor Point is kept STANDARD (0,0) and the art
        # is pre-CENTRED in the PNG, so 0,0 == art centre → the XML position matches the preview exactly (a
        # non-standard anchor made Premiere place it off) and scale/rotation still pivot at the art centre.
        af, _acx, _acy = _icon_geom(ip)
        want = _ICON_ONSCREEN.get(kind, 0.24) * size
        k = max(10.0, 100.0 * want / (af or 0.2))
        cx, cy = (ix - 0.5), (iy - 0.5)                  # Center places the (centred) icon at (ix,iy)
        ip = _icon_hue_file(ip, hue)
        # ---- light EFFECT: SPARKLE — screen-blended twinkles that pop in/out at rotating offsets around (ix,iy) ----
        if kind == "sparkle":
            er = register(ip, "image", SEQ_W, SEQ_H, STILL, still=True, label=label)
            _mc, _fi = er["mcid"], er["fid"]; sc = int(round(k))
            offs = [(0.0, 0.0), (-0.05, -0.045), (0.055, -0.04), (-0.04, 0.05), (0.05, 0.05)]
            life, stag, t, i = _f(0.9), _f(0.42), istart, 0
            while t < iend:
                ox, oy = offs[i % len(offs)]; i += 1; rend = min(t + life, iend)
                if rend - t >= _f(0.5):
                    icon_items.append((t, rend, _icon_clipitem(f"clipitem-{nid('c')}", _mc, _fi, label,
                                       t, rend, _f(0.22), _f(0.35), composite="screen", cx=cx + ox, cy=cy + oy, scale=sc, pop=True)))
                t += stag
            return
        fin = min(_f(0.35), max(1, idur // 3))
        fout = 0                                             # icons do NOT fade out — they stay full until the scene ends
        is_arrow = (kind == "arrow")
        ckf = _arrow_point_kf(idur, fin, cx, cy, left=flip, rot=rot) if is_arrow else ""
        er = register(ip, "image", SEQ_W, SEQ_H, STILL, still=True, label=label)
        icon_items.append((istart, iend, _icon_clipitem(f"clipitem-{nid('c')}", er["mcid"], er["fid"], label,
                           istart, iend, fin, fout, pulse=False, center_kf=ckf, cx=cx, cy=cy,
                           scale=int(round(k)), rot=rot, ax=0.0, ay=0.0, pop=(not is_arrow))))

    # SOUND EFFECTS: a per-scene `sfx` -> an audio clip from "Sound Effects/" that sits UNDER the VO but stays
    # audible, and ALWAYS fades out smoothly. "hit" rotates the 3 cinematic hits so consecutive ones differ.
    _sfx_dir = Path(__file__).resolve().parent / "Sound Effects"
    _sfx_map = {"ambulance": ("ambulance.mp3", 0.5), "healthmonitor": ("healthmonitor.wav", 0.45),
                "time": ("time.wav", 0.5)}
    _hits = ["Cinematic Hit 1.mp3", "Cinematic Hit 2.mp3", "Cinematic Hit 3.mp3"]
    _hit_i = [0]
    _last_med = [None]                                # last medical cue played (ambulance/healthmonitor) — for alternation

    def _add_sfx(kind, s_f, e_f, span, label):
        kind = (kind or "").strip().lower()
        if kind == "hit":
            fn, peak = _hits[_hit_i[0] % 3], 0.62; _hit_i[0] += 1
        elif kind in _sfx_map:
            fn, peak = _sfx_map[kind]
        else:
            return
        p = _sfx_dir / fn
        if not p.exists():
            warnings.append(f"sound effect not found: {fn}"); return
        natural = _f(audio_duration(p) or 0)
        if natural <= 0:
            return
        shown = min(natural, span)                        # keep it within the scene
        if shown < 2:
            return
        ch = audio_channels(p) or 2
        fin = min(_f(0.12), shown // 5)
        fout = min(_f(0.9), shown // 2)                   # smooth fade-out at the end (user requirement)
        er = register(p, "sfx", src=natural, channels=ch)
        sfx_items.append(_audio_clipitem(f"clipitem-{nid('c')}", er["mcid"], er["fid"], label,
                         s_f, shown, natural, ch, fin, fout, peak=peak))

    timeline_clips = []                              # (scene, s_f, e_f, media_path, is_img) per REAL clip placed on V1
    timeline_end = 0
    used_video = used_image = gaps = blanks = 0

    def _cf(v, d):                                   # clamp an ost_in/ost_out fraction to 0..1
        try:
            return min(1.0, max(0.0, float(v)))
        except (TypeError, ValueError):
            return d

    def add_matte(start_f, end_f, label):
        e = register(red_png, "matte", SEQ_W, SEQ_H, STILL, still=True)
        v_items.append((start_f, 1, _video_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], label,
                                       start_f, end_f, end_f - start_f, SEQ_W, SEQ_H, STILL, zoom=False)))

    # Native crossfade needs media HANDLES (the clip's IN/OUT extended past the cut). So we record every real
    # clip's full _video_clipitem args + its slot in v_items, then re-emit the two neighbours WITH handles when
    # a crossfade sits between them (see the transition pass below). tc_specs is parallel to timeline_clips.
    tc_specs = []
    def _place_clip(**kw):
        vi = len(v_items)
        v_items.append((kw["start_f"], 1, _video_clipitem(**kw)))
        tc_specs.append((kw, vi))

    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc:
            continue                     # phantom scene (not in the voice-over) — ignore entirely
        s_f, e_f = _f(t0), _f(t1)
        if e_f <= s_f:
            continue
        timeline_end = max(timeline_end, e_f)
        span = e_f - s_f
        name = scene_label(s)            # NN_<sentence> — reflects the scene's CURRENT id + VO
        # (scene transitions are BAKED as clips on V2 after this loop — see timeline_clips below)
        # on-screen text overlays for this scene -> a transparent PNG on the overlay track V2 (built after
        # the loop, in one browser batch), each shown over its own ost_in..ost_out window with a native fade.
        if s.get("ost_on") and s.get("style") != "2d":   # NO on-screen text on 2D animation scenes
            fade = _f(0.3)
            scene_ost_start = None                        # earliest text onset in this scene (for the plate)
            for ov in (s.get("overlays") or []):
                txt = (ov.get("onscreen") or "").strip()
                if not txt:
                    continue
                a = s_f + int(round(span * _cf(ov.get("ost_in"), 0.0)))
                b = s_f + int(round(span * _cf(ov.get("ost_out"), 1.0)))
                if b <= a:
                    b = min(e_f, a + 1)
                fl = min(fade, max(1, (b - a) // 4))
                scene_ost_start = a if scene_ost_start is None else min(scene_ost_start, a)
                _ai, _ao = _ost_anims(ov)                  # enforce the animation rule (no fade-in-only / slide-right)
                ost_specs.append({
                    "item": {"text": txt, "style": ov, "kind": "ost",
                             "place": ov.get("ost_place", "top"), "x": ov.get("ost_x", 0),
                             "y": ov.get("ost_y", 0), "rotation": ov.get("ost_rotation", 0),
                             "anim": _ai, "out_anim": _ao},
                    "start": a, "end": b, "name": f"{name} · text",
                    "fin": fl,
                    "fout": fl,
                })
            # dark readability PLATE behind the text (V3): a black matte that fades 0 -> 20% ending right as the
            # text appears (~1.25s lead) and HOLDS 20% to the scene end. One per scene, from the earliest text.
            if scene_ost_start is not None and black_png.exists():
                lead = _f(2.0)                             # plate comes in EARLIER (was 1.25s) and holds to the scene end
                m_start = max(s_f, scene_ost_start - lead)
                fade_f = scene_ost_start - m_start
                if fade_f < _f(0.4):                       # text starts at/near the scene head -> still fade smoothly
                    fade_f = min(e_f - m_start - 1, _f(1.0))
                mb = register(black_png, "matte", SEQ_W, SEQ_H, STILL, still=True, label="text plate")
                matte_items.append((m_start, 1, _matte_clipitem(f"clipitem-{nid('c')}", mb["mcid"], mb["fid"],
                                    f"{name} · plate", m_start, e_f, fade_f, 70)))
        # ONLY approved media goes on the timeline — matches exactly what the /all zip bundles,
        # so an un-approved image can never sneak into the export. A scene with no APPROVED media
        # becomes a red matte (BLANK), same as before.
        vid = s.get("video") or {}
        vpath = proj_dir / vid["file"] if vid.get("file") else None
        has_video = vid.get("approved") and vid.get("status") == "ready" and vpath and vpath.exists()
        img = s.get("image") or {}
        ipath_rel = img.get("approved_file") or img.get("file")
        ipath = proj_dir / ipath_rel if ipath_rel else None
        has_image = bool(s.get("approved") and ipath and ipath.exists())

        # a written-testimonial scene: NEVER Ken-Burns zoom the card; and if a burned-karaoke clip was
        # provided, use THAT as the video (green highlight animated), not the static still
        is_tcard = bool(s.get("tcard_id"))
        _kclip = (scene_video_override or {}).get(s.get("id")) if is_tcard else None
        if _kclip and Path(_kclip).exists():
            kdur, kw, kh = ffprobe_media(Path(_kclip))
            e = register(Path(_kclip), "video", kw, kh, max(span, _f(kdur) if kdur else span), still=False, label=name)
            _place_clip(cid=f"clipitem-{nid('c')}", mcid=e["mcid"], fid=e["fid"], name=name,
                        start_f=s_f, end_f=e_f, shown_f=span, media_w=kw, media_h=kh, src_frames=e["src"],
                        zoom=False, note=s.get("note"))
            timeline_clips.append((s, s_f, e_f, Path(_kclip), False))
            used_video += 1
            continue
        _icons_list = (s["icons"] if (isinstance(s.get("icons"), list) and s["icons"])
                       else ([{"type": s.get("icon"), "x": s.get("icon_x", 0.5), "y": s.get("icon_y", 0.5)}] if s.get("icon") else []))
        _n_ic = len(_icons_list)
        # ONE icon -> zoom IN leaning toward that icon; SEVERAL icons -> hold the frame still (a fixed icon must
        # not drift under a moving image); NO icons -> normal centred Ken-Burns.
        if is_tcard or _n_ic >= 2:
            _zoom, _zctr = False, ""
        elif _n_ic == 1:
            _zoom = True
            _zctr = _zoom_center_kf(float(_icons_list[0].get("x", 0.5) or 0.5),
                                    float(_icons_list[0].get("y", 0.5) or 0.5), span)
        else:
            _zoom, _zctr = True, ""

        if has_video:
            vdur, vw, vh = ffprobe_media(vpath)
            vframes = _f(vdur) if vdur else span
            if 0 < vframes < span:
                # clip SHORTER than the scene -> slow it (Time Remap) to fill the whole span exactly, instead
                # of a freeze + red GAP matte. shows all vframes source frames over `span` timeline frames.
                e = register(vpath, "video", vw, vh, vframes, still=False, label=name)
                _place_clip(cid=f"clipitem-{nid('c')}", mcid=e["mcid"], fid=e["fid"], name=name,
                            start_f=s_f, end_f=e_f, shown_f=span, media_w=vw, media_h=vh, src_frames=vframes,
                            zoom=_zoom, note=s.get("note"), slow_src=vframes, center_kf=_zctr)
                used_video += 1
            else:
                shown = min(vframes, span)   # clip >= scene: trim to the scene (no gap, no slow-down needed)
                e = register(vpath, "video", vw, vh, max(shown, vframes), still=False, label=name)
                _place_clip(cid=f"clipitem-{nid('c')}", mcid=e["mcid"], fid=e["fid"], name=name,
                            start_f=s_f, end_f=s_f + shown, shown_f=shown, media_w=vw, media_h=vh, src_frames=e["src"],
                            zoom=_zoom, note=s.get("note"), center_kf=_zctr)
                used_video += 1
            timeline_clips.append((s, s_f, e_f, vpath, False))
        elif has_image:
            iw, ih = image_size(ipath)
            e = register(ipath, "image", iw, ih, STILL, still=True, label=name)
            _place_clip(cid=f"clipitem-{nid('c')}", mcid=e["mcid"], fid=e["fid"], name=name,
                        start_f=s_f, end_f=e_f, shown_f=span, media_w=iw, media_h=ih, src_frames=STILL,
                        zoom=_zoom, note=s.get("note"), center_kf=_zctr)
            timeline_clips.append((s, s_f, e_f, ipath, True))
            used_image += 1
        else:
            add_matte(s_f, e_f, f"BLANK scene {s.get('id'):02d} no media")
            blanks += 1

        # visual-effect overlays (V4 + V5) — ONLY on scenes flagged fx_on that are realistic (style==natural)
        # and actually have footage; each effect is repeated back-to-back to fill the whole scene.
        if s.get("fx_on") and (s.get("style") == "natural") and (has_video or has_image):
            _add_fx("fx4", fx4_items, s_f, e_f, f"{name} · fx2")     # effect2 -> V4
            _add_fx("fx5", fx5_items, s_f, e_f, f"{name} · fx1")     # effect1 -> V5 (slowed)

        if (has_video or has_image) and s.get("style") != "2d":      # animated icon(s) -> V7 (NEVER on 2D scenes)
            placements = []                                          # (type, x, y, size, rot, flip, hue, in, out)
            if isinstance(s.get("icons"), list) and s["icons"]:
                for it in s["icons"]:
                    if isinstance(it, dict) and (it.get("type") or it.get("icon")):
                        placements.append((it.get("type") or it.get("icon"),
                                           float(it.get("x", 0.5)), float(it.get("y", 0.5)), float(it.get("size", 1.0)),
                                           float(it.get("rot", 0) or 0), bool(it.get("flip")), float(it.get("hue", 0) or 0),
                                           float(it.get("in", 0) or 0),
                                           float(it.get("out") if it.get("out") is not None else 1.0)))
            elif s.get("icon"):                                      # legacy single-icon fields
                placements.append((s.get("icon"), float(s.get("icon_x", 0.5)), float(s.get("icon_y", 0.5)),
                                   float(s.get("icon_size", 1.0)), 0.0, False, 0.0, 0.0, 1.0))
            for (ik, ix, iy, isz, irot, iflip, ihue, iin, iout) in placements:
                # each icon shows over its OWN window (Assemble timeline: in/out fractions of the scene; default whole)
                _add_icon(ik, s_f, e_f, span, f"{name} · {ik}", ix, iy, in_frac=iin, out_frac=iout,
                          size=isz, rot=irot, flip=iflip, hue=ihue)

        raw_sfx = (s.get("sfx") or "").strip().lower()               # scene sound effect (under the VO)
        if raw_sfx in ("ambulance", "healthmonitor"):
            sfxk = raw_sfx
            if _last_med[0] == sfxk:                                 # NEVER the same medical cue twice in a row →
                alt = "healthmonitor" if sfxk == "ambulance" else "ambulance"   # alternate ambulance <-> monitor
                if not (alt == "healthmonitor" and s.get("style") != "natural"):
                    sfxk = alt
            if not (sfxk == "healthmonitor" and s.get("style") != "natural"):   # monitor only on realistic shots
                _add_sfx(sfxk, s_f, e_f, span, f"{name} · sfx")
                _last_med[0] = sfxk
        elif raw_sfx:
            _add_sfx(raw_sfx, s_f, e_f, span, f"{name} · sfx")

    # ---- scene transitions ------------------------------------------------------------------------------
    #  crossfade / dip-black / flash -> NATIVE Premiere transitions (no baked overlay clip). They act DIRECTLY
    #    on the real clips, so there is NO frame jump. crossfade = centered Cross Dissolve with media HANDLES;
    #    dip-black = A dissolves to black + B dissolves from black; flash = a white matte on V2 fading over the
    #    cut. (Slides were REMOVED — FCP7 XML can't carry a real push and the baked version never looked right.)
    def _has_ic(sc):
        return bool(sc.get("icon")) or (isinstance(sc.get("icons"), list) and len(sc["icons"]) > 0)
    def _has_ost(sc):
        return bool(sc.get("ost_on")) and sc.get("style") != "2d" and \
            any((o.get("onscreen") or "").strip() for o in (sc.get("overlays") or []))
    handle_add = {}                                  # timeline_clips index -> {"xf_in":n,"xf_out":n} (crossfade)
    for _i in range(len(timeline_clips) - 1):
        a_sc, a_sf, a_ef, a_media, a_img = timeline_clips[_i]
        b_sc, b_sf, b_ef, b_media, b_img = timeline_clips[_i + 1]
        prev_sc = timeline_clips[_i - 1][0] if _i > 0 else None
        tr = (a_sc.get("transition") or "none")
        if a_sc.get("style") == "2d" or b_sc.get("style") == "2d":
            continue                                     # NO transition on / between 2D animation scenes
        # a scene with a CINEMATIC HIT dips to black on its cut — but only when NO icon is on the previous, this
        # or the next scene (an icon must never sit over a dissolve). This overrides the no-transition rules below.
        _hit = ((a_sc.get("sfx") or "").strip().lower() == "hit"
                and not _has_ic(a_sc) and not _has_ic(b_sc) and not (prev_sc and _has_ic(prev_sc)))
        if _hit:
            tr = "dip-black"
        # NO transition when an ICON scene is on EITHER side (item 2) or AFTER an on-screen-text scene (item 6):
        # a plain hard cut instead — so a fixed icon / a text plate never dissolves.
        elif _has_ic(a_sc) or _has_ic(b_sc) or _has_ost(a_sc):
            continue
        if b_sc.get("fx_on") and tr in ("crossfade", "dip-white"):
            tr = "dip-black"                             # a VFX scene must start on dip-black (never crossfade/flash)
        if tr not in _XFADE or a_ef != b_sf:             # need a real transition AND the two clips adjacent (no gap)
            continue
        cut = a_ef
        if tr == "crossfade":
            # centered Cross Dissolve (A->B) with media HANDLES on both neighbours (real frames, no freeze)
            if cut - XF_D2 <= 0 or cut + XF_D2 >= timeline_end:
                continue
            if (a_ef - a_sf) <= XF_D2 or (b_ef - b_sf) <= XF_D2:
                continue                                 # a neighbour too short for a handle -> plain cut
            handle_add.setdefault(_i, {})["xf_out"] = XF_D2
            handle_add.setdefault(_i + 1, {})["xf_in"] = XF_D2
            v_items.append((cut - XF_D2, 0, _xfade_transition(cut, effect="Cross Dissolve")))
        elif tr == "dip-white":
            # FLASH: Premiere refuses a native "Dip to White" on FCP7 import (it silently degrades to a fade to
            # BLACK). So the flash is a WHITE full-frame still on V2 that fades 0->100->0 over the cut; the clips
            # hard-cut underneath and the white peak hides the seam.
            flen = 46                                    # ~23 frames before + 23 after the cut (longer flash)
            fst = cut - flen // 2
            fen = fst + flen
            if fst > 0 and fen < timeline_end:
                ew = register(white_png, "matte", SEQ_W, SEQ_H, STILL, still=True, label="flash (white)")
                fhalf = flen // 2
                trans_items.append((fst, 1, _ost_clipitem(f"clipitem-{nid('c')}", ew["mcid"], ew["fid"],
                                    "flash (white)", fst, fen, fhalf, flen - fhalf, anim_in="fade", anim_out="none")))
        elif tr == "dip-black":                          # A dissolves DOWN to black, then B dissolves UP from black
            dlen = _f(TRANS_SEC)                         # two single-sided Cross Dissolves (no handles)
            if cut - dlen > 0:
                v_items.append((cut - dlen, 0, _dip_transition(cut - dlen, cut, "end-black")))
            if cut + dlen < timeline_end:
                v_items.append((cut, 0, _dip_transition(cut, cut + dlen, "start-black")))

    # re-emit each crossfade neighbour IN PLACE with its handle(s) so the native dissolve has real frames.
    for idx, h in handle_add.items():
        kw, vi = tc_specs[idx]
        kw2 = dict(kw, xf_in=h.get("xf_in", 0), xf_out=h.get("xf_out", 0))
        v_items[vi] = (kw2["start_f"], 1, _video_clipitem(**kw2))

    # ---- V2: on-screen text overlays as transparent PNGs (browser-rendered = pixel-identical to the
    #          preview/render), each with a native Opacity fade. Additive: if no headless browser is
    #          available the overlays are simply skipped and the base timeline is unaffected. -----------
    ost_items = []
    if ost_specs:
        pngs = None
        try:
            from caption_layer import render_overlay_stills
            pngs = render_overlay_stills([o["item"] for o in ost_specs],
                                         proj_dir / "export" / "_ost_tmp", SEQ_W, SEQ_H)
        except Exception as ex:
            warnings.append(f"on-screen text overlays could not be rendered into the XML: {ex}")
        if pngs:
            for o, entry in zip(ost_specs, pngs):
                if not entry:
                    continue
                png, bbox = entry
                l, t, r, b = bbox
                ax = ((l + r) / 2 - SEQ_W / 2) / SEQ_W    # text-centre offset (normalized) -> Pop pivot (Anchor)
                ay = ((t + b) / 2 - SEQ_H / 2) / SEQ_H
                it = o["item"]
                e = register(Path(png), "image", SEQ_W, SEQ_H, STILL, still=True, label=o["name"])
                ost_items.append((o["start"], o["end"], _ost_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], o["name"],
                                               o["start"], o["end"], o["fin"], o["fout"],
                                               it.get("anim", "fade"), it.get("out_anim", "none"), ax, ay)))
        if pngs is None:
            warnings.append("on-screen text not added to the XML (no headless browser found to render it)")
        elif not ost_items:                          # browser ran but produced empty plates — don't drop OST silently
            warnings.append(f"on-screen text ({len(ost_specs)} overlay(s)) did not render into the XML")

    # ---- A1: voice-over ----------------------------------------------------
    vo_frames = _f(vo_dur) if vo_dur else _f(total)
    timeline_end = max(timeline_end, vo_frames)
    _vo_l, _vo_tp = measure_lufs(vo_audio_path, {})          # normalize VO to a consistent VSL level
    _vo_ch = audio_channels(vo_audio_path)
    e_vo = register(vo_audio_path, "vo", src=vo_frames, channels=_vo_ch)
    a1 = [_audio_clipitem(f"clipitem-{nid('c')}", e_vo["mcid"], e_vo["fid"], Path(vo_audio_path).name,
                          0, vo_frames, vo_frames, _vo_ch, 0, 0, peak=vo_level(_vo_l, _vo_tp))]

    # ---- background music: crossfaded segments + crossfaded LOOPS, lane-packed --------------------------
    segments = music_segments if music_segments is not None else pick_music(segment_emotions(cues, total, claude_fn), bgm_root)
    music_plan = []
    music_items = []                                        # (start_f, end_f, xml) — lane-packed like the icons
    xf = _f(XFADE_SEC)
    last = len(segments) - 1
    for i, seg in enumerate(segments):
        seg_s, seg_e = _f(seg["start"]), _f(seg["end"])
        span = seg_e - seg_s
        path = seg.get("path")
        music_plan.append({"start": round(seg["start"], 1), "end": round(seg["end"], 1),
                           "emotion": seg["emotion"],
                           "track": Path(path).name if path else None})
        if not path or span <= 0:
            continue
        src_frames = _f(seg["src_dur"]) if seg.get("src_dur") else span
        # A segment crossfades with its neighbours: it pre-rolls xf before its start (fading up to full exactly
        # at seg_s) and fades out over its last xf (silent exactly at seg_e). If the track is SHORTER than the
        # segment it LOOPS — and each loop iteration also OVERLAPS the next by xf and crossfades, so the music
        # never dips to silence at a loop seam (the old butt-join left the track's own tail/silence audible).
        pre = xf if i > 0 else 0
        clip_start = seg_s - pre
        end_tl = seg_e
        fin = pre if i > 0 else _f(1.0)
        fout = xf if i < last else _f(2.0)
        level = music_level(seg.get("lufs"), seg.get("tp"))
        ch = audio_channels(path)
        e = register(path, "music", src=src_frames, channels=ch)
        adv = max(1, src_frames - xf)                       # each loop iteration starts xf before the last ends
        starts, ck, guard = [], clip_start, 0
        while ck < end_tl - 1 and guard < 400:
            guard += 1
            starts.append(ck)
            if ck + src_frames >= end_tl:                   # this full iteration already reaches the end → last
                break
            ck += adv
        for idx, cs in enumerate(starts):
            is_first, is_last = idx == 0, idx == len(starts) - 1
            dur = min(src_frames, end_tl - cs) if is_last else src_frames
            if dur < 1:
                continue
            cfin = min(fin if is_first else xf, dur)        # crossfade IN (segment fade-in, or loop crossfade)
            cfout = min(fout if is_last else xf, dur)       # crossfade OUT (segment fade-out, or loop crossfade)
            clip = _audio_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], seg["emotion"],
                                   cs, dur, src_frames, ch, cfin, cfout, peak=level)
            music_items.append((cs, cs + dur, clip))
        timeline_end = max(timeline_end, end_tl)

    # ---- assemble sequence -------------------------------------------------
    total_f = max(timeline_end, _f(total), 1)
    audio_tracks = _atrack(a1, 1)
    audio_tracks += _atracks_layered(music_items)          # time-overlapping music clips → separate tracks
    if whoosh_items:                                     # A4: synced slide whooshes (low level, under the VO)
        audio_tracks += _atrack(whoosh_items, 1)
    if sfx_items:                                        # A5: scene sound effects (under the VO, smooth fade-out)
        audio_tracks += _atrack(sfx_items, 1)

    h = hashlib.md5(("vsl-" + project_title).encode("utf-8")).hexdigest()
    uuid = f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"
    name = escape(project_title)
    sequence = (
        f'<sequence id="sequence-1" {_seq_attrs(total_f)}>'
        f"<uuid>{uuid}</uuid><duration>{total_f}</duration>{_rate()}<name>{name}</name>"
        "<media><video>"
        "<format><samplecharacteristics>"
        f"{_rate()}{_CODEC}<width>{SEQ_W}</width><height>{SEQ_H}</height>"
        "<anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio>"
        "<fielddominance>none</fielddominance><colordepth>24</colordepth></samplecharacteristics></format>"
        f"{_vtrack(v_items)}"                            # V1: the scene clips
        + _vtrack(trans_items)                           # V2: baked slide transitions + flash matte
        + _vtrack(fx4_items)                             # V3: effect2.mp4 (opacity 55, hue set in Premiere)
        + _vtrack(fx5_items)                             # V4: effect1.mp4 (slowed 25%, opacity 70, multiply)
        + _vtracks_layered(icon_items)                   # animated icons — one track PER time-overlapping icon
        + _vtrack(matte_items)                           # just under the text: dark readability plate
        + _vtracks_layered(ost_items)                    # TOP: on-screen text — one track PER time-overlapping text so 2+ texts in a scene never collide
        + "</video><audio>"
        f"{_AUDIO_HEADER}{audio_tracks}"
        "</audio></media>"
        f"{_tc()}<labels><label2>Forest</label2></labels>{_LOGGING}"
        "</sequence>")

    # Organize the Project panel into bins. Each media file is a master <clip> defined ONCE inside
    # its bin; the sequence's clipitems reference it by id. All masters precede the sequence in
    # document order (Images/Videos/Music bins, then Main Files whose master clips come before the
    # sequence) so every <file id/> reference resolves.
    images = "".join(_video_master(e) for e in reg.values() if e["kind"] == "image")
    videos = "".join(_video_master(e) for e in reg.values() if e["kind"] == "video")
    music = "".join(_audio_master(e) for e in reg.values() if e["kind"] in ("music", "sfx"))
    mainclips = "".join((_audio_master(e) if e["kind"] == "vo" else _video_master(e))
                        for e in reg.values() if e["kind"] in ("vo", "matte"))
    project = (
        f"<project><name>{name}</name><children>"
        + _bin("Images", images) + _bin("Videos", videos) + _bin("Background Music", music)
        + _bin("Main Files", mainclips + sequence)
        + "</children></project>")
    xml = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4">\n'
           + project + "\n</xmeml>\n")

    info = {
        "warnings": warnings,
        "scenes": len(scenes),
        "used_video": used_video,
        "used_image": used_image,
        "gaps": gaps,
        "blanks": blanks,
        "duration_sec": round(total, 1),
        "music": music_plan,
    }
    return xml, info
