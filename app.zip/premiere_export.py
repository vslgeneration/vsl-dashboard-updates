"""
Premiere Pro project export — assembles the whole VSL pipeline into ONE editable
timeline the user opens in Premiere (File > Import).

Output = Final Cut Pro 7 XML (xmeml v4). The XML mirrors, element-for-element and
IN ORDER, what THIS user's Premiere Pro itself exports (from a sample they gave):
bare <sequence> under <xmeml version="4"> (no <project> wrapper), <masterclipid> on
every clip, the exact clipitem field order, pathurl with %-encoded spaces + drive
colon (%3a), native Basic Motion (zoom) and Audio Levels (fade) filters, and the
audio <outputs>/Panner track shape. Earlier attempts (hand-rolled, then OTIO) were
rejected as "The project appears to be damaged" because their element order/shape
differed from what Premiere's importer accepts.

Timeline layout (1920x1080, 60 fps):
  V1  scene clips — the generated VIDEO if it exists, else the approved IMAGE, placed
      at each scene's *audio-driven* time range (derived from the SRT). Every clip gets
      a gentle Ken-Burns zoom-in at a CONSTANT speed (1.4 %/sec). Where a video is
      shorter than its scene's spoken range, the remainder is a RED MATTE clip so the
      gap is impossible to miss. A scene with no media at all is a red matte.
  A1  voice-over.
  A2/A3  background music — one track per emotional segment (segmented by Claude, mapped
      to Background Music/<EMOTION>), each used once, laid on two alternating tracks that
      overlap by 1.5 s with audio-level fades → a smooth cross-fade.

SRT stays a SEPARATE deliverable — the user imports it as captions in Premiere.
"""
import re, json, difflib, subprocess, hashlib
from pathlib import Path

# The dashboard runs windowless (pythonw), so every ffmpeg/ffprobe child would otherwise
# pop up its own console — a black box flashing over the screen once per scene.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
from xml.sax.saxutils import escape
from urllib.parse import quote

FPS = 60
SEQ_W, SEQ_H = 1920, 1080
ZOOM_PCT_PER_SEC = 1.4          # constant Ken-Burns zoom speed (percent of scale per second)
XFADE_SEC = 3.0                 # music cross-fade length (longer = smoother transitions)
MUSIC_LEVEL = 0.15              # fallback background-music level if loudness can't be measured
TARGET_VO_LUFS = -16.0         # voice-over gain-matched to a solid, consistent VSL speech level
TARGET_MUSIC_LUFS = -33.0      # background music gain-matched to a quiet bed ~17 dB under the VO,
                               # so every track sits at the SAME level regardless of its original
PEAK_CEILING_DBTP = -1.0       # never let a gained track's true peak exceed this (avoids clipping)
TPF = 254016000000 // FPS       # Premiere ticks per frame (254016000000 ticks per second)
EMOTIONS = ["DOCUMENTARY", "EMOTIONAL", "FEAR", "INSPIRING", "SCIENTIFIC", "SUSPENSE", "TESTIMONIAL"]   # legacy default

def list_moods(bgm_root):
    """The mood categories that ACTUALLY exist = the subfolders of Background Music that contain audio.
    Dynamic, so renaming/adding/removing mood folders just works (no hardcoded list to keep in sync)."""
    try:
        root = Path(bgm_root)
        out = sorted(d.name for d in root.iterdir()
                     if d.is_dir() and not d.name.startswith(".")
                     and any(p.suffix.lower() in (".wav", ".mp3") for p in d.iterdir()))
        return out or list(EMOTIONS)
    except Exception:
        return list(EMOTIONS)

def _humanize_mood(m):
    """'Problem_Emotional' -> 'Problem / Emotional' for the LLM prompt (labels stay exact for matching)."""
    return (m or "").replace("_", " / ").replace("-", " ")


# ---- media probing ---------------------------------------------------------
def ffprobe_media(path):
    """Return (duration_seconds, width, height) for a video, or (None, w, h) best-effort."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height:format=duration",
             "-of", "json", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        j = json.loads(out.stdout or "{}")
        st = (j.get("streams") or [{}])[0]
        try:
            dur = float(j.get("format", {}).get("duration"))
        except (TypeError, ValueError):
            dur = None
        return dur, int(st.get("width") or SEQ_W), int(st.get("height") or SEQ_H)
    except Exception:
        return None, SEQ_W, SEQ_H


def audio_duration(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=nokey=1:noprint_wrappers=1", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        return float(out.stdout.strip())
    except Exception:
        return None


def audio_channels(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=channels", "-of", "default=nokey=1:noprint_wrappers=1", str(path)],
            capture_output=True, text=True, timeout=60, creationflags=_NO_WINDOW)
        return int(out.stdout.strip())
    except Exception:
        return 2


def image_size(path):
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.width, im.height
    except Exception:
        return SEQ_W, SEQ_H


def measure_lufs(path, cache):
    """(integrated LUFS, true-peak dBTP) of an audio file via ffmpeg loudnorm, cached by
    file+mtime. Used to gain-match tracks to the same level without clipping."""
    p = Path(path)
    try:
        key = f"{p.name}:{p.stat().st_mtime_ns}"
    except Exception:
        key = str(p)
    if key in cache:
        v = cache[key]
        return tuple(v) if isinstance(v, list) else (v, None)   # tolerate old float-only cache
    lufs = tp = None
    try:
        out = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(p),
             "-af", "loudnorm=print_format=json", "-f", "null", "-"],
            capture_output=True, text=True, timeout=180, creationflags=_NO_WINDOW)
        m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", out.stderr)
        if m:
            j = json.loads(m[-1])
            lufs = float(j["input_i"])
            try:
                tp = float(j.get("input_tp"))
            except (TypeError, ValueError):
                tp = None
    except Exception:
        lufs = tp = None
    cache[key] = [lufs, tp]
    return lufs, tp


def normalize_loudness(src, dst, target_i=TARGET_VO_LUFS, target_tp=-1.5, lra=11.0):
    """Two-pass ffmpeg loudnorm → dst at `target_i` LUFS WITH limiting, so the voice-over plays
    at a consistent VSL level and never clips (a static gain can't do this for a quiet-but-peaky
    file). Duration is preserved, so SRT alignment stays valid. Returns dst, or None on failure."""
    src, dst = Path(src), Path(dst)
    try:
        r1 = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(src),
             "-af", f"loudnorm=I={target_i}:TP={target_tp}:LRA={lra}:print_format=json", "-f", "null", "-"],
            capture_output=True, text=True, timeout=300, creationflags=_NO_WINDOW)
        m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", r1.stderr)
        meas = ""
        if m:
            j = json.loads(m[-1])
            meas = (f":measured_I={j['input_i']}:measured_TP={j['input_tp']}"
                    f":measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}"
                    f":offset={j.get('target_offset', '0.0')}:linear=true")
        dst.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-nostats", "-i", str(src),
             "-af", f"loudnorm=I={target_i}:TP={target_tp}:LRA={lra}{meas}",
             "-ar", "44100", str(dst)],
            capture_output=True, text=True, timeout=300, check=True, creationflags=_NO_WINDOW)
        return dst if dst.exists() else None
    except Exception:
        return None


def _norm_level(lufs, tp, target):
    """Audio-Levels value that brings `lufs` to `target`, capped so the true peak stays under
    PEAK_CEILING_DBTP (no clipping)."""
    if lufs is None:
        return None
    gain_db = target - lufs
    if tp is not None:
        gain_db = min(gain_db, PEAK_CEILING_DBTP - tp)
    return max(0.02, min(4.0, 10 ** (gain_db / 20.0)))


def music_level(lufs, tp=None):
    lvl = _norm_level(lufs, tp, TARGET_MUSIC_LUFS)
    return MUSIC_LEVEL if lvl is None else min(lvl, 1.0)


def vo_level(lufs, tp=None):
    lvl = _norm_level(lufs, tp, TARGET_VO_LUFS)
    return 1.0 if lvl is None else lvl


# ---- SRT parsing + scene<->SRT alignment -----------------------------------
_TS = re.compile(r"(\d+):(\d\d):(\d\d)[,.](\d\d\d)")


def _ts_to_sec(t):
    h, m, s, ms = (int(x) for x in _TS.match(t).groups())
    return h * 3600 + m * 60 + s + ms / 1000.0


def parse_srt(text):
    """Return [{start, end, text}] in order."""
    cues = []
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n").strip()):
        lines = [ln for ln in block.split("\n") if ln.strip()]
        if not lines:
            continue
        ti = 0
        if "-->" not in lines[0] and len(lines) > 1:
            ti = 1  # first line is the index number
        if ti >= len(lines) or "-->" not in lines[ti]:
            continue
        a, _, b = lines[ti].partition("-->")
        try:
            start, end = _ts_to_sec(a.strip()), _ts_to_sec(b.strip())
        except Exception:
            continue
        cues.append({"start": start, "end": end, "text": " ".join(lines[ti + 1:])})
    return cues


def _norm_words(text):
    return re.findall(r"[a-z0-9']+", (text or "").lower())


def word_scene_starts(scenes, words):
    """ACCURATE per-scene start times from the forced-alignment WORD list [(start, end, word)] —
    matches each scene's VO word sequence onto the word timeline (difflib), giving the real onset of
    each scene's first spoken word instead of a linear interpolation inside an SRT cue."""
    srt_words, srt_times = [], []
    for st, _en, tok in words:
        for w in _norm_words(tok):
            srt_words.append(w); srt_times.append(st)
    scene_words, idx = [], []
    for s in scenes:
        idx.append(len(scene_words)); scene_words.extend(_norm_words(s.get("vo") or ""))
    pos = [None] * len(scene_words)
    for a, b, size in difflib.SequenceMatcher(None, scene_words, srt_words, autojunk=False).get_matching_blocks():
        for k in range(size):
            pos[a + k] = b + k
    def time_at(i):
        for j in range(i, len(pos)):
            if pos[j] is not None:
                return srt_times[pos[j]]
        for j in range(i - 1, -1, -1):
            if pos[j] is not None:
                return srt_times[pos[j]]
        return None
    starts = []
    for si, s in enumerate(scenes):
        if not (s.get("vo") or "").strip():
            starts.append(starts[-1] if starts else 0.0); continue
        t = time_at(idx[si])
        starts.append(t if t is not None else (starts[-1] if starts else 0.0))
    return starts


def accurate_cue_token_times(cues, words):
    """For each cue, the ACCURATE onset time of each display token, by walking the cue tokens in
    lockstep with the word list (both come from the same alignment, same order). Falls back to the
    cue's own start if the sequences drift. Returns a parallel list-of-lists, or None if unusable."""
    tsv = [(w, st) for (st, _en, tok) in words for w in _norm_words(tok)]
    ti, out = 0, []
    for c in cues:
        toks = (c["text"] or "").split()
        times = []
        for t in toks:
            nw = _norm_words(t)
            if nw and ti < len(tsv):
                times.append(tsv[ti][1]); ti += len(nw)
            else:
                times.append(c["start"])
        out.append(times)
    return out


def split_captions_at_scenes(cues, scene_starts, cue_token_times=None):
    """PREVIEW ONLY: split any SRT cue that straddles a scene boundary INTO TWO at that boundary, so
    every scene start coincides with a caption start and the two switch together in the player. Token
    times come from `cue_token_times` (accurate, from the word list) when given, else interpolated.
    The forced-alignment cues otherwise don't break at sentence/scene boundaries. Not the export SRT."""
    cuts = sorted({round(b, 3) for b in scene_starts})
    out = []
    for ci, c in enumerate(cues):
        toks = (c["text"] or "").split()
        inside = [b for b in cuts if c["start"] + 1e-4 < b < c["end"] - 1e-4]
        if not inside or len(toks) < 2:
            out.append(c)
            continue
        n = len(toks)
        if cue_token_times and ci < len(cue_token_times) and len(cue_token_times[ci]) == n:
            wt = cue_token_times[ci]
        else:
            dur = c["end"] - c["start"]
            wt = [c["start"] + dur * k / n for k in range(n)]
        pts = [c["start"]] + inside + [c["end"]]
        for a, b in zip(pts, pts[1:]):
            seg = [toks[k] for k in range(n) if a <= wt[k] < b]
            if seg:
                out.append({"start": a, "end": b, "text": " ".join(seg)})
    return out


def load_word_tsv(subtitle_dir):
    """Forced-alignment word list [(start, end, word)] from the ensemble TSV (accurate per-word
    onsets). Returns None if no usable TSV is present."""
    subtitle_dir = Path(subtitle_dir)
    for name in ("words_medium_en_vad.tsv", "words_small_en_vad.tsv"):
        p = subtitle_dir / name
        if not p.exists():
            continue
        out = []
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            parts = line.split("\t")
            if len(parts) >= 3:
                try:
                    out.append((float(parts[0]), float(parts[1]), parts[2]))
                except ValueError:
                    pass
        if out:
            return out
    return None


def caps_to_srt(caps):
    """Serialize [{start,end,text}] cues to SRT text."""
    return "\n\n".join(
        f"{i}\n{_sec_to_ts(c['start'])} --> {_sec_to_ts(c['end'])}\n{c['text']}"
        for i, c in enumerate(caps, 1)) + "\n"


def delivery_srt(scenes, cues, total, words):
    """The SRT we DELIVER: captions split at scene boundaries (so a caption and its clip change
    together in Premiere) + frame-quantized. Uses the same scene boundaries as the exported clips."""
    word_starts = word_scene_starts(scenes, words) if words else None
    ranges, included = scene_time_ranges(scenes, cues, total, word_starts)
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    tok_times = accurate_cue_token_times(cues, words) if words else None
    caps = split_captions_at_scenes(cues, scene_starts, tok_times)
    return quantize_srt_to_frames(caps_to_srt(caps))


def _slug(t, n=40):
    # mirrors app.py slugify so the XML clip labels match the delivered zip filenames exactly
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"


def scene_label(s):
    """Friendly, order-accurate label for a scene's clip/master: `NN_<sentence-slug>` using the
    scene's CURRENT id + VO (so a manual split/insert renumbers and relabels everything)."""
    try:
        return f"{int(s.get('id')):02d}_{_slug(s.get('vo'))}"
    except (TypeError, ValueError):
        return _slug(s.get("vo"))


def scene_time_ranges(scenes, cues, total_dur, word_starts=None):
    """Map each scene's VO text onto the SRT word timeline → [(start, end)] per scene.

    HYBRID snap: if a scene's first word is ALSO the first word of its SRT cue (the scene boundary
    is a caption boundary — the normal case), the clip start snaps to the CUE start so it lines up
    frame-for-frame with the imported caption. If the scene starts MID-cue (a manual split of one
    sentence into two scenes), the clip start uses that word's real onset — `word_starts[si]` from
    the forced-alignment word list when provided (ACCURATE), else an interpolation inside the cue.
    Cue-first (caption-aligned) scenes are NEVER moved, so the confirmed frame-exact caption sync is
    preserved; only mid-cue starts are refined."""
    srt_words, srt_cue_starts, srt_word_times, srt_word_cuefirst = [], [], [], []
    for c in cues:
        ws = _norm_words(c["text"])
        n = len(ws)
        dur = max(0.0, c["end"] - c["start"])
        for k, word in enumerate(ws):
            srt_words.append(word)
            srt_cue_starts.append(c["start"])          # the CUE start (= the caption's timecode)
            srt_word_times.append(c["start"] + (dur * k / n if n else 0.0))   # interpolated word time
            srt_word_cuefirst.append(k == 0)

    scene_words, scene_start_idx = [], []
    for s in scenes:
        scene_start_idx.append(len(scene_words))
        scene_words.extend(_norm_words(s.get("vo") or ""))
    scene_start_idx.append(len(scene_words))            # sentinel end for the last scene

    pos = [None] * len(scene_words)
    for a, b, size in difflib.SequenceMatcher(None, scene_words, srt_words, autojunk=False).get_matching_blocks():
        for k in range(size):
            pos[a + k] = b + k

    # Which scenes actually appear in the voice-over? A scene whose spoken text does NOT align to
    # the SRT (a manually-added line that isn't in the script/VO — e.g. "As I said, my name is
    # Mark.") aligns at ~0.0, while real AND manually-SPLIT scenes align ~1.0. Phantom scenes are
    # treated as NON-EXISTENT: excluded from the timeline entirely (no clip, not even a red matte).
    included = []
    for si in range(len(scenes)):
        a, b = scene_start_idx[si], scene_start_idx[si + 1]
        wc = b - a
        matched = sum(1 for j in range(a, b) if pos[j] is not None)
        included.append(not (wc >= 3 and matched / max(1, wc) < 0.5))

    def matched_pos(idx):
        for j in range(idx, len(pos)):
            if pos[j] is not None:
                return pos[j]
        for j in range(idx - 1, -1, -1):
            if pos[j] is not None:
                return pos[j]
        return None

    starts = []
    for si, s in enumerate(scenes):
        if not (s.get("vo") or "").strip():
            starts.append(starts[-1] if starts else 0.0)
            continue
        p = matched_pos(scene_start_idx[si])
        if p is None:
            t = None
        elif srt_word_cuefirst[p]:
            t = srt_cue_starts[p]                              # cue-first → caption timecode (frame-exact)
        elif word_starts is not None and si < len(word_starts) and word_starts[si] is not None:
            t = word_starts[si]                                # mid-cue → real spoken-word onset
        else:
            t = srt_word_times[p]                              # mid-cue → interpolated fallback
        starts.append(t if t is not None else (starts[-1] if starts else 0.0))
    # Anchor the timeline at 0 on the FIRST scene that's actually in the voice-over, so leading
    # phantom scenes don't push the real opening clip past frame 0 (or leave a gap at the start).
    first_inc = next((i for i in range(len(scenes)) if included[i]), 0)
    for i in range(min(first_inc + 1, len(starts))):
        starts[i] = 0.0
    starts = _monotonic(starts)

    ranges = []
    for i in range(len(scenes)):
        end = starts[i + 1] if i + 1 < len(scenes) else total_dur
        ranges.append((starts[i], max(starts[i], end)))
    return ranges, included


def excluded_scene_ids(scenes, cues):
    """Ids of scenes NOT present in the voice-over (manual lines not in the script/VO). These are
    excluded across the whole export so they behave as if they don't exist. Returns a set; empty
    when there are no cues to align against."""
    if not scenes or not cues:
        return set()
    _ranges, included = scene_time_ranges(scenes, cues, 0.0)
    return {scenes[i].get("id") for i in range(len(scenes)) if not included[i]}


def _monotonic(xs):
    out, hi = [], 0.0
    for x in xs:
        hi = max(hi, x if x is not None else hi)
        out.append(hi)
    return out


# ---- background-music: emotion segmentation + track selection --------------
def segment_emotions(cues, total_dur, claude_fn, moods=None):
    """Ask Claude to split the timeline into contiguous emotional segments mapped to the AVAILABLE mood
    folder names (passed in `moods`). Returns [{start, end, emotion}] or [] on failure."""
    moods = list(moods) if moods else list(EMOTIONS)
    if not claude_fn or total_dur <= 0 or not moods:
        return []
    lines = [f"[{c['start']:.1f}-{c['end']:.1f}] {c['text']}" for c in cues]
    labels = "; ".join(f"{m} ({_humanize_mood(m)})" for m in moods)
    system = (
        "You are a film music supervisor scoring a VIDEO SALES LETTER (VSL). You get a timed transcript and "
        "must divide its FULL timeline into a FEW contiguous emotional sections driven ENTIRELY by the STORY's "
        "emotional tone, then assign each section the single best background-music mood.\n"
        "Allowed moods — use ONLY these EXACT labels (left side): " + labels + ".\n"
        "Rules:\n"
        "- Sections must be contiguous and cover the whole timeline from 0 to the end with no gaps or overlaps.\n"
        "- Think like a VSL: the music stays STABLE through a whole ACT and changes ONLY at a MAJOR emotional turn "
        "of the story — the big beats: hook/curiosity → problem/pain → the story/journey → the discovery/solution "
        "→ proof/testimonial → hopeful or upbeat CTA. A whole act is ONE section with ONE track, even if it runs "
        "for minutes.\n"
        "- Be INSENSITIVE to small, momentary tone shifts. Do NOT start a new section for a brief dip, a single "
        "sad line, a small lift, or a passing detail INSIDE an act — those stay in the current section. Only a "
        "genuine, lasting change of the story's emotional chapter earns a new section.\n"
        "- Prefer FEW, LONG sections. A typical VSL has only about 3–6 music sections in TOTAL across the whole "
        "video (a 5-minute VSL is usually ~4). When in doubt, DON'T switch — keep the same track running. Never "
        "create a section shorter than ~35 seconds.\n"
        "- A calm/explanatory stretch with no strong emotion should use the neutral/bed mood if one exists.\n"
        "- Pick the closest allowed mood for each section.\n"
        "Output ONLY a JSON array like "
        '[{"start":0,"end":42.5,"emotion":"<one of the exact labels>"}, ...]. No prose, no code fences.')
    user = (f"Total duration: {total_dur:.1f} seconds.\n"
            "Segment by the emotional tone of the story only, into a few long sections. Transcript:\n" + "\n".join(lines))
    try:
        text = claude_fn(system, user, 2000)
        m = re.search(r"\[.*\]", text, re.S)
        segs = json.loads(m.group(0) if m else text)
    except Exception:
        return []
    clean = []
    for s in segs:
        try:
            emo = _match_mood(str(s["emotion"]), moods)
            clean.append({"start": float(s["start"]), "end": float(s["end"]), "emotion": emo})
        except Exception:
            continue
    if not clean:
        return []
    clean.sort(key=lambda x: x["start"])
    # Keep music changes RARE — tied to MAJOR arc turns, not every little tone wobble. Two guards, both fold the
    # shortest segment into its larger neighbour (adopting that neighbour's mood):
    #   MIN_SEG   — no section may be shorter than this (kills blips), and
    #   MAX_SEGS  — a soft upper bound that scales with length (~one section per ~75s), so a 5-min VSL lands
    #               around 4 sections instead of 6+. Not a rigid clock — just a ceiling on over-segmentation.
    MIN_SEG = 35.0
    MAX_SEGS = max(3, round(total_dur / 75.0))
    while len(clean) > 1:
        durs = [s["end"] - s["start"] for s in clean]
        i = durs.index(min(durs))                                  # shortest segment
        if durs[i] >= MIN_SEG and len(clean) <= MAX_SEGS:
            break                                                  # long enough AND few enough → stop
        if i == 0:                       j = 1
        elif i == len(clean) - 1:        j = i - 1
        else:                            j = i - 1 if durs[i - 1] >= durs[i + 1] else i + 1
        lo, hi = min(i, j), max(i, j)
        merged = {"start": clean[lo]["start"], "end": clean[hi]["end"], "emotion": clean[j]["emotion"]}
        clean[lo:hi + 1] = [merged]                                # absorb into the larger neighbour's mood
    clean[0]["start"] = 0.0
    clean[-1]["end"] = total_dur
    for i in range(1, len(clean)):
        clean[i]["start"] = clean[i - 1]["end"]
    return [s for s in clean if s["end"] > s["start"]]


def _match_mood(label, moods):
    """Map an LLM-returned mood label to one of the AVAILABLE mood folders (case/underscore-insensitive,
    then substring, then keyword overlap). Returns a real folder name."""
    moods = list(moods) if moods else list(EMOTIONS)
    if not moods:
        return "DOCUMENTARY"
    norm = lambda x: re.sub(r"[^a-z0-9]", "", (x or "").lower())
    L = norm(label)
    for m in moods:                                  # exact (normalized)
        if norm(m) == L:
            return m
    for m in moods:                                  # substring either way
        nm = norm(m)
        if nm and (nm in L or L in nm):
            return m
    lw = set(re.findall(r"[a-z]+", (label or "").lower()))   # keyword overlap
    best, bs = moods[0], 0
    for m in moods:
        sc = len(lw & set(re.findall(r"[a-z]+", m.lower())))
        if sc > bs:
            best, bs = m, sc
    return best

def _closest_emotion(label, moods=None):
    return _match_mood(label, moods or EMOTIONS)


def pick_music(segments, bgm_root):
    """Assign each segment an UNUSED track from its mood folder (each track used at most once), enriched with
    duration and measured loudness (LUFS, cached in bgm_root/.loudness_cache.json) for gain-matching."""
    bgm_root = Path(bgm_root)
    moods = list_moods(bgm_root)
    pool = {}
    for emo in moods:
        folder = bgm_root / emo
        pool[emo] = sorted([p for p in folder.iterdir()
                            if p.suffix.lower() in (".wav", ".mp3")]) if folder.exists() else []
    cache_path = bgm_root / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    used = set()
    out = []
    for seg in segments:
        emo = seg["emotion"] if seg["emotion"] in pool else _closest_emotion(seg["emotion"])
        files = pool.get(emo) or []
        choice = next((f for f in files if f not in used), None) or (files[0] if files else None)
        seg = dict(seg, emotion=emo)
        if choice is not None:
            used.add(choice)
            lufs, tp = measure_lufs(choice, cache)
            seg.update(path=choice, src_dur=audio_duration(choice), lufs=lufs, tp=tp)
        else:
            seg.update(path=None, src_dur=None, lufs=None, tp=None)
        out.append(seg)
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception:
        pass
    return out


# ---- FCP7 XML building — mirror Premiere's OWN export dialect ---------------
def _pathurl(path):
    p = str(Path(path).resolve()).replace("\\", "/")
    # Match Premiere's OWN encoding exactly: it percent-encodes ONLY spaces (%20) and the
    # drive colon (%3a), and leaves everything else (& ' ( ) , etc.) LITERAL — those are
    # then XML-escaped by escape() at emit time (& -> &amp;). url-quoting them (e.g. & ->
    # %26) yields a path Premiere cannot relink (it looks for a file literally named "%26").
    p = p.replace(":", "%3a", 1)
    p = p.replace(" ", "%20")
    return "file://localhost/" + p


def _rate(tb=FPS):
    return f"<rate><timebase>{tb}</timebase><ntsc>FALSE</ntsc></rate>"


def _tc():
    return ("<timecode>" + _rate() +
            "<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>")


def _f(sec):
    # round HALF-UP (not Python's banker's round) so clip frames match quantize_srt_to_frames,
    # which uses the same rule — this is what keeps a caption and its clip on the identical frame.
    return int(sec * FPS + 0.5) if sec > 0 else 0


def _sec_to_ts(sec):
    ms = int(round(max(0.0, sec) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def quantize_srt_to_frames(srt_text, fps=FPS):
    """Rewrite every cue's start/end timestamp so it lands EXACTLY on the frame our clips use.

    For each cue we compute frame = round-half-up(sec*fps) — the SAME frame `_f()` gives the clip
    — then write the timestamp back at (frame + 0.25)/fps seconds. The +0.25-frame nudge (≈4 ms at
    60 fps, invisible) guarantees Premiere's own SRT-import ms→frame conversion recovers the same
    frame whether it floors OR rounds. Result: an imported caption and its scene clip begin on the
    identical frame — zero drift. Only timecodes are touched; all caption text/formatting is kept."""
    def repl(m):
        fa = int(_ts_to_sec(m.group(1)) * fps + 0.5)
        fb = int(_ts_to_sec(m.group(2)) * fps + 0.5)
        if fb <= fa:
            fb = fa + 1
        return f"{_sec_to_ts((fa + 0.25) / fps)} --> {_sec_to_ts((fb + 0.25) / fps)}"
    return re.sub(r"(\d+:\d\d:\d\d[,.]\d\d\d)\s*-->\s*(\d+:\d\d:\d\d[,.]\d\d\d)", repl, srt_text)


_LOGGING = ("<logginginfo><description></description><scene></scene><shottake></shottake>"
            "<lognote></lognote><good></good><originalvideofilename></originalvideofilename>"
            "<originalaudiofilename></originalaudiofilename></logginginfo>")
_COLORINFO = ("<colorinfo><lut></lut><lut1></lut1><asc_sop></asc_sop><asc_sat></asc_sat>"
              "<lut2></lut2></colorinfo>")


def _basic_motion(base, end, out_f):
    """Native Premiere Basic Motion (Motion) filter — scale keyframes give the zoom."""
    b, e = round(base, 2), round(end, 2)
    kf = ""
    if abs(e - b) > 0.01:
        kf = (f"<keyframe><when>0</when><value>{b}</value></keyframe>"
              f"<keyframe><when>{out_f}</when><value>{e}</value></keyframe>")
    return (
        "<filter><effect><name>Basic Motion</name><effectid>basic</effectid>"
        "<effectcategory>motion</effectcategory><effecttype>motion</effecttype>"
        "<mediatype>video</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>scale</parameterid><name>Scale</name>'
        f"<valuemin>0</valuemin><valuemax>1000</valuemax><value>{b}</value>{kf}</parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>rotation</parameterid><name>Rotation</name>'
        "<valuemin>-8640</valuemin><valuemax>8640</valuemax><value>0</value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>center</parameterid><name>Center</name>'
        "<value><horiz>0</horiz><vert>0</vert></value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>centerOffset</parameterid><name>Anchor Point</name>'
        "<value><horiz>0</horiz><vert>0</vert></value></parameter>"
        '<parameter authoringApp="PremierePro"><parameterid>antiflicker</parameterid><name>Anti-flicker Filter</name>'
        "<valuemin>0.0</valuemin><valuemax>1.0</valuemax><value>0</value></parameter>"
        "</effect></filter>")


def _audio_levels(clip_f, fade_in_f, fade_out_f, peak=1.0):
    """Native Premiere Audio Levels filter: hold at `peak` (1.0 = 0 dB) with optional
    fade-in/out to silence. Music uses a low peak so the VO sits clearly on top."""
    p = round(peak, 4)
    kf = []
    if fade_in_f > 0:
        kf += [(0, 0), (fade_in_f, p)]
    else:
        kf += [(0, p)]
    if fade_out_f > 0:
        kf += [(max(fade_in_f, clip_f - fade_out_f), p), (clip_f, 0)]
    body = "".join(f"<keyframe><when>{w}</when><value>{v}</value></keyframe>" for w, v in kf)
    return (
        "<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid>"
        "<effectcategory>audiolevels</effectcategory><effecttype>audiolevels</effecttype>"
        "<mediatype>audio</mediatype><pproBypass>false</pproBypass>"
        '<parameter authoringApp="PremierePro"><parameterid>level</parameterid><name>Level</name>'
        f"<valuemin>0</valuemin><valuemax>3.98109</valuemax><value>{p}</value>{body}</parameter>"
        "</effect></filter>")


def _video_file(fid, path, src_frames, w, h, still=False):
    # Premiere's export omits <duration> on still-image files (only real footage carries it).
    dur = "" if still else f"<duration>{src_frames}</duration>"
    return (
        f'<file id="{fid}"><name>{escape(Path(path).name)}</name>'
        f"<pathurl>{escape(_pathurl(path))}</pathurl>"
        f"{_rate()}{dur}{_tc()}"
        "<media><video><samplecharacteristics>"
        f"{_rate()}<width>{w}</width><height>{h}</height>"
        "<anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio>"
        "<fielddominance>none</fielddominance></samplecharacteristics></video></media></file>")


def _audio_file(fid, path, src_frames, channels):
    # Declare the file's ACTUAL channel count — a mismatch (e.g. mono clip vs a stereo file)
    # makes Premiere refuse to link the media ("created with 1 audio channel ... file has 2").
    ch = max(1, channels)
    chans = "".join(f"<audiochannel><sourcechannel>{i + 1}</sourcechannel></audiochannel>" for i in range(ch))
    return (
        f'<file id="{fid}"><name>{escape(Path(path).name)}</name>'
        f"<pathurl>{escape(_pathurl(path))}</pathurl>"
        f"{_rate()}<duration>{src_frames}</duration>{_tc()}"
        "<media><audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate>"
        f"</samplecharacteristics><channelcount>{ch}</channelcount>{chans}</audio></media></file>")


def _video_clipitem(cid, mcid, fid, name, start_f, end_f, shown_f, media_h, src_frames, zoom):
    # References its media by <file id/> — the full <file> is defined once in the bin master clip.
    base = 100.0 * SEQ_H / max(1, media_h)           # fill the 1080 frame by height
    end_scale = base * (1 + ZOOM_PCT_PER_SEC / 100.0 * (shown_f / FPS)) if zoom else base
    return (
        f'<clipitem id="{cid}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{end_f}</end><in>0</in><out>{shown_f}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown_f * TPF}</pproTicksOut>"
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'<file id="{fid}"/>'
        f"{_basic_motion(base, end_scale, shown_f)}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Iris</label2></labels></clipitem>")


def _audio_clipitem(cid, mcid, fid, name, start_f, shown_f, src_frames, channels, fin, fout, peak=1.0):
    ctype = "stereo" if channels >= 2 else "mono"
    return (
        f'<clipitem id="{cid}" premiereChannelType="{ctype}"><masterclipid>{mcid}</masterclipid>'
        f"<name>{escape(name)}</name><enabled>TRUE</enabled>"
        f"<duration>{src_frames}</duration>{_rate()}"
        f"<start>{start_f}</start><end>{start_f + shown_f}</end><in>0</in><out>{shown_f}</out>"
        f"<pproTicksIn>0</pproTicksIn><pproTicksOut>{shown_f * TPF}</pproTicksOut>"
        f'<file id="{fid}"/>'
        "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
        f"{_audio_levels(shown_f, fin, fout, peak)}{_LOGGING}{_COLORINFO}"
        "<labels><label2>Caribbean</label2></labels></clipitem>")


# ---- bin master clips (define each media file ONCE; clipitems reference by masterclipid) ----
def _uuid(seed):
    h = hashlib.md5(seed.encode("utf-8")).hexdigest()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def _video_master(e):
    # Mirror Premiere's OWN FCP7 export of a bin master clip (from the user's asdasdasd.xml sample):
    # the <file> lives INSIDE clip/media/video/track/clipitem — NOT as a direct child of <clip>.
    # The old file-as-direct-child form made Premiere fail to recognise the master and dump the
    # media into a "Recovered files" bin instead of the Images/Videos bin.
    # Clip order: uuid, masterclipid, ismasterclip, duration, rate, name, media, logginginfo,
    # colorinfo, labels. The inner clipitem order: masterclipid, name, rate, alphatype,
    # pixelaspectratio, anamorphic, file.
    # <clip>/<clipitem> NAME = the friendly order-accurate label (NN_sentence); the <file><name>
    # inside keeps the REAL basename so Premiere still relinks the media.
    lbl = escape(e.get("label") or e["name"])
    return (
        f'<clip id="{e["mcid"]}" explodedTracks="true"><uuid>{_uuid(e["mcid"])}</uuid>'
        f'<masterclipid>{e["mcid"]}</masterclipid><ismasterclip>TRUE</ismasterclip>'
        f'<duration>{e["src"]}</duration>{_rate()}<name>{lbl}</name>'
        "<media><video><track>"
        f'<clipitem id="{e["icid"]}"><masterclipid>{e["mcid"]}</masterclipid>'
        f'<name>{lbl}</name>{_rate()}'
        "<alphatype>none</alphatype><pixelaspectratio>square</pixelaspectratio><anamorphic>FALSE</anamorphic>"
        f'{_video_file(e["fid"], e["path"], e["src"], e["w"], e["h"], still=e["still"])}'
        "</clipitem></track></video></media>"
        f"{_LOGGING}{_COLORINFO}<labels><label2>Lavender</label2></labels></clip>")


def _audio_master(e):
    # Mirror Premiere's OWN audio master clip: a STEREO file is exploded into two mono <track>s,
    # linked together; the full <file> is defined on the first clipitem and referenced empty on the
    # second. Mono files use a single track. (Same nesting fix as _video_master.)
    ch = max(1, e["channels"])
    file_full = _audio_file(e["fid"], e["path"], e["src"], e["channels"])
    file_ref = f'<file id="{e["fid"]}"/>'
    icid1 = e["icid"]
    if ch >= 2:
        icid2 = e.get("icid2") or (icid1 + "-b")
        links = (
            f'<link><linkclipref>{icid1}</linkclipref><mediatype>audio</mediatype>'
            "<trackindex>1</trackindex><clipindex>1</clipindex><groupindex>1</groupindex></link>"
            f'<link><linkclipref>{icid2}</linkclipref><mediatype>audio</mediatype>'
            "<trackindex>2</trackindex><clipindex>1</clipindex><groupindex>1</groupindex></link>")
        tracks = (
            f'<track><clipitem id="{icid1}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_full}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
            f"{links}</clipitem></track>"
            f'<track><clipitem id="{icid2}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_ref}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>2</trackindex></sourcetrack>"
            f"{links}</clipitem></track>")
    else:
        tracks = (
            f'<track><clipitem id="{icid1}"><masterclipid>{e["mcid"]}</masterclipid>'
            f'<name>{escape(e["name"])}</name>{_rate()}{file_full}'
            "<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>"
            "</clipitem></track>")
    return (
        f'<clip id="{e["mcid"]}" explodedTracks="true"><uuid>{_uuid(e["mcid"])}</uuid>'
        f'<masterclipid>{e["mcid"]}</masterclipid><ismasterclip>TRUE</ismasterclip>'
        f'<duration>{e["src"]}</duration>{_rate()}<name>{escape(e["name"])}</name>'
        f"<media><audio>{tracks}</audio></media>"
        f"{_LOGGING}{_COLORINFO}<labels><label2>Caribbean</label2></labels></clip>")


def _bin(name, inner):
    return f"<bin><name>{escape(name)}</name><children>{inner}</children></bin>" if inner else ""


_VTRACK_ATTRS = 'TL.SQTrackShy="0" TL.SQTrackExpandedHeight="41" TL.SQTrackExpanded="0" MZ.TrackTargeted="1"'
_ATRACK_ATTRS = ('TL.SQTrackAudioKeyframeStyle="0" TL.SQTrackShy="0" TL.SQTrackExpandedHeight="41" '
                 'TL.SQTrackExpanded="0" MZ.TrackTargeted="1" PannerCurrentValue="0.5" PannerIsInverted="true" '
                 'PannerStartKeyframe="-91445760000000000,0.5,0,0,0,0,0,0" PannerName="Balance" '
                 'currentExplodedTrackIndex="0" totalExplodedTrackCount="1" premiereTrackType="Stereo"')


def _vtrack(items):
    return (f"<track {_VTRACK_ATTRS}>" + "".join(items) +
            "<enabled>TRUE</enabled><locked>FALSE</locked></track>")


def _atrack(items, out_idx):
    return (f"<track {_ATRACK_ATTRS}>" + "".join(items) +
            f"<enabled>TRUE</enabled><locked>FALSE</locked><outputchannelindex>{out_idx}</outputchannelindex></track>")


_AUDIO_HEADER = (
    "<numOutputChannels>2</numOutputChannels>"
    "<format><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics></format>"
    "<outputs>"
    "<group><index>1</index><numchannels>1</numchannels><downmix>0</downmix><channel><index>1</index></channel></group>"
    "<group><index>2</index><numchannels>1</numchannels><downmix>0</downmix><channel><index>2</index></channel></group>"
    "</outputs>")

# Sequence attribute set, matching the user's own working Premiere export (test.xml)
# key-for-key, EXCEPT the timeline-position attributes (edit line, work area, program
# zoom) — those must be within THIS sequence's duration, not copied from a 250-second
# project, or Premiere rejects the file as "damaged".
def _seq_attrs(total_f):
    end_ticks = max(1, total_f) * TPF
    return ('TL.SQAudioVisibleBase="0" TL.SQVideoVisibleBase="0" TL.SQVisibleBaseTime="0" '
            'TL.SQAVDividerPosition="0.5" TL.SQHideShyTracks="0" TL.SQHeaderWidth="204" '
            'TL.SQDataTrackViewControlState="0" '
            f'Monitor.ProgramZoomOut="{end_ticks}" Monitor.ProgramZoomIn="0" '
            'TL.SQTimePerPixel="0.2" MZ.EditLine="0" '
            'MZ.Sequence.PreviewFrameSizeHeight="1080" MZ.Sequence.PreviewFrameSizeWidth="1920" '
            'MZ.Sequence.AudioTimeDisplayFormat="200" MZ.Sequence.PreviewRenderingClassID="1061109567" '
            'MZ.Sequence.PreviewRenderingPresetCodec="1919706400" '
            'MZ.Sequence.PreviewRenderingPresetPath="EncoderPresets\\SequencePreview\\'
            '9678af98-a7b7-4bdb-b477-7ac9c8df4a4e\\QuickTime.epr" '
            'MZ.Sequence.PreviewUseMaxRenderQuality="false" MZ.Sequence.PreviewUseMaxBitDepth="false" '
            'MZ.Sequence.EditingModeGUID="9678af98-a7b7-4bdb-b477-7ac9c8df4a4e" '
            'MZ.Sequence.VideoTimeDisplayFormat="104" '
            f'MZ.WorkOutPoint="{end_ticks}" MZ.WorkInPoint="0" explodedTracks="true"')

# Sequence video codec block, copied verbatim from the working export.
_CODEC = ("<codec><name>Apple ProRes 422</name><appspecificdata>"
          "<appname>Final Cut Pro</appname><appmanufacturer>Apple Inc.</appmanufacturer>"
          "<appversion>7.0</appversion><data><qtcodec>"
          "<codecname>Apple ProRes 422</codecname><codectypename>Apple ProRes 422</codectypename>"
          "<codectypecode>apcn</codectypecode><codecvendorcode>appl</codecvendorcode>"
          "<spatialquality>1024</spatialquality><temporalquality>0</temporalquality>"
          "<keyframerate>0</keyframerate><datarate>0</datarate></qtcodec></data></appspecificdata></codec>")


# ---- main assembler --------------------------------------------------------
def build_premiere_xml(project_title, proj_dir, doc, srt_text, vo_audio_path,
                       bgm_root, claude_fn=None, music_segments=None):
    """Return (xml_string, info_dict). `music_segments` = pre-resolved segments (with path/lufs/tp/
    src_dur) to honor the user's per-segment track choices; if None, they're computed here."""
    proj_dir = Path(proj_dir)
    warnings = []

    vo_dur = audio_duration(vo_audio_path) or 0.0
    cues = parse_srt(srt_text)
    if not cues:
        raise ValueError("the SRT has no readable cues")
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # refine MID-cue scene starts with the real spoken-word onset (word list); cue-aligned scenes
    # are untouched, so the confirmed frame-exact caption sync is preserved
    words = load_word_tsv(proj_dir / "subtitle")
    word_starts = word_scene_starts(scenes, words) if words else None
    ranges, included = scene_time_ranges(scenes, cues, total, word_starts)

    ids = {"c": 0, "m": 0, "f": 0}
    def nid(k):
        ids[k] += 1
        return ids[k]

    # media registry: each distinct file becomes ONE bin master clip; clipitems reference it by id
    reg = {}
    def register(path, kind, w=0, h=0, src=0, still=False, channels=0, label=None):
        key = str(Path(path).resolve())
        e = reg.get(key)
        if not e:
            # icid = the master clip's OWN internal catalog clipitem (holds the full <file>).
            # Drawn from the same 'c' counter as sequence clipitems so all ids stay globally unique.
            # `label` = the friendly bin/clip name (NN_sentence); `name` stays the real basename.
            e = {"fid": f"file-{nid('f')}", "mcid": f"masterclip-{nid('m')}", "kind": kind,
                 "name": Path(path).name, "label": label or Path(path).name, "path": path,
                 "w": w, "h": h, "src": src,
                 "still": still, "channels": channels, "icid": f"clipitem-{nid('c')}"}
            if kind in ("vo", "music") and channels >= 2:
                e["icid2"] = f"clipitem-{nid('c')}"   # second exploded mono track for a stereo file
            reg[key] = e
        return e

    # ---- red matte still (gaps / blank scenes) ----------------------------
    red_png = proj_dir / "export" / "red_matte.png"
    red_png.parent.mkdir(parents=True, exist_ok=True)
    if not red_png.exists():
        try:
            from PIL import Image
            Image.new("RGB", (SEQ_W, SEQ_H), (200, 30, 30)).save(red_png, "PNG")
        except Exception as e:
            warnings.append(f"could not create red matte image: {e}")

    STILL = FPS * 3600
    v_items = []
    timeline_end = 0
    used_video = used_image = gaps = blanks = 0

    def add_matte(start_f, end_f, label):
        e = register(red_png, "matte", SEQ_W, SEQ_H, STILL, still=True)
        v_items.append(_video_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], label,
                                       start_f, end_f, end_f - start_f, SEQ_H, STILL, zoom=False))

    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc:
            continue                     # phantom scene (not in the voice-over) — ignore entirely
        s_f, e_f = _f(t0), _f(t1)
        if e_f <= s_f:
            continue
        timeline_end = max(timeline_end, e_f)
        span = e_f - s_f
        name = scene_label(s)            # NN_<sentence> — reflects the scene's CURRENT id + VO
        # ONLY approved media goes on the timeline — matches exactly what the /all zip bundles,
        # so an un-approved image can never sneak into the export. A scene with no APPROVED media
        # becomes a red matte (BLANK), same as before.
        vid = s.get("video") or {}
        vpath = proj_dir / vid["file"] if vid.get("file") else None
        has_video = vid.get("approved") and vid.get("status") == "ready" and vpath and vpath.exists()
        img = s.get("image") or {}
        ipath_rel = img.get("approved_file") or img.get("file")
        ipath = proj_dir / ipath_rel if ipath_rel else None
        has_image = bool(s.get("approved") and ipath and ipath.exists())

        if has_video:
            vdur, vw, vh = ffprobe_media(vpath)
            vframes = _f(vdur) if vdur else span
            shown = min(vframes, span)
            e = register(vpath, "video", vw, vh, max(shown, vframes), still=False, label=name)
            v_items.append(_video_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], name,
                                           s_f, s_f + shown, shown, vh, e["src"], zoom=True))
            used_video += 1
            if shown < span:
                add_matte(s_f + shown, e_f, f"GAP scene {s.get('id'):02d} needs media")
                gaps += 1
        elif has_image:
            iw, ih = image_size(ipath)
            e = register(ipath, "image", iw, ih, STILL, still=True, label=name)
            v_items.append(_video_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], name,
                                           s_f, e_f, span, ih, STILL, zoom=True))
            used_image += 1
        else:
            add_matte(s_f, e_f, f"BLANK scene {s.get('id'):02d} no media")
            blanks += 1

    # ---- A1: voice-over ----------------------------------------------------
    vo_frames = _f(vo_dur) if vo_dur else _f(total)
    timeline_end = max(timeline_end, vo_frames)
    _vo_l, _vo_tp = measure_lufs(vo_audio_path, {})          # normalize VO to a consistent VSL level
    _vo_ch = audio_channels(vo_audio_path)
    e_vo = register(vo_audio_path, "vo", src=vo_frames, channels=_vo_ch)
    a1 = [_audio_clipitem(f"clipitem-{nid('c')}", e_vo["mcid"], e_vo["fid"], Path(vo_audio_path).name,
                          0, vo_frames, vo_frames, _vo_ch, 0, 0, peak=vo_level(_vo_l, _vo_tp))]

    # ---- A2/A3: background music on two overlapping tracks -----------------
    segments = music_segments if music_segments is not None else pick_music(segment_emotions(cues, total, claude_fn), bgm_root)
    music_plan = []
    a2, a3 = [], []
    xf = _f(XFADE_SEC)
    last = len(segments) - 1
    for i, seg in enumerate(segments):
        seg_s, seg_e = _f(seg["start"]), _f(seg["end"])
        span = seg_e - seg_s
        path = seg.get("path")
        music_plan.append({"start": round(seg["start"], 1), "end": round(seg["end"], 1),
                           "emotion": seg["emotion"],
                           "track": Path(path).name if path else None})
        if not path or span <= 0:
            continue
        src_frames = _f(seg["src_dur"]) if seg.get("src_dur") else span
        # Crossfade COMPLETES at the segment boundary: this clip pre-rolls xf before its start
        # (fading up to full exactly at seg_s) and fades out over its last xf (silent exactly at
        # seg_e = the next boundary). So when the new segment/clip arrives, the new music is
        # already at full and the old one is gone.
        pre = xf if i > 0 else 0
        clip_start = seg_s - pre
        tl_dur = span + pre
        shown = min(src_frames, tl_dur)
        if shown < tl_dur and seg.get("src_dur"):
            warnings.append(f"music '{Path(path).name}' ({seg['src_dur']:.0f}s) is shorter than its "
                            f"{seg['emotion']} segment — it ends early")
        fin = pre if i > 0 else min(FPS, shown)
        fout = xf if i < last else min(2 * FPS, shown)
        level = music_level(seg.get("lufs"), seg.get("tp"))
        ch = audio_channels(path)
        e = register(path, "music", src=src_frames, channels=ch)
        clip = _audio_clipitem(f"clipitem-{nid('c')}", e["mcid"], e["fid"], seg["emotion"],
                               clip_start, shown, src_frames, ch, fin, fout, peak=level)
        timeline_end = max(timeline_end, clip_start + shown)
        (a2 if i % 2 == 0 else a3).append(clip)

    # ---- assemble sequence -------------------------------------------------
    total_f = max(timeline_end, _f(total), 1)
    audio_tracks = _atrack(a1, 1)
    if a2:
        audio_tracks += _atrack(a2, 1)
    if a3:
        audio_tracks += _atrack(a3, 2)

    h = hashlib.md5(("vsl-" + project_title).encode("utf-8")).hexdigest()
    uuid = f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"
    name = escape(project_title)
    sequence = (
        f'<sequence id="sequence-1" {_seq_attrs(total_f)}>'
        f"<uuid>{uuid}</uuid><duration>{total_f}</duration>{_rate()}<name>{name}</name>"
        "<media><video>"
        "<format><samplecharacteristics>"
        f"{_rate()}{_CODEC}<width>{SEQ_W}</width><height>{SEQ_H}</height>"
        "<anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio>"
        "<fielddominance>none</fielddominance><colordepth>24</colordepth></samplecharacteristics></format>"
        f"{_vtrack(v_items)}"
        "</video><audio>"
        f"{_AUDIO_HEADER}{audio_tracks}"
        "</audio></media>"
        f"{_tc()}<labels><label2>Forest</label2></labels>{_LOGGING}"
        "</sequence>")

    # Organize the Project panel into bins. Each media file is a master <clip> defined ONCE inside
    # its bin; the sequence's clipitems reference it by id. All masters precede the sequence in
    # document order (Images/Videos/Music bins, then Main Files whose master clips come before the
    # sequence) so every <file id/> reference resolves.
    images = "".join(_video_master(e) for e in reg.values() if e["kind"] == "image")
    videos = "".join(_video_master(e) for e in reg.values() if e["kind"] == "video")
    music = "".join(_audio_master(e) for e in reg.values() if e["kind"] == "music")
    mainclips = "".join((_audio_master(e) if e["kind"] == "vo" else _video_master(e))
                        for e in reg.values() if e["kind"] in ("vo", "matte"))
    project = (
        f"<project><name>{name}</name><children>"
        + _bin("Images", images) + _bin("Videos", videos) + _bin("Background Music", music)
        + _bin("Main Files", mainclips + sequence)
        + "</children></project>")
    xml = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4">\n'
           + project + "\n</xmeml>\n")

    info = {
        "warnings": warnings,
        "scenes": len(scenes),
        "used_video": used_video,
        "used_image": used_image,
        "gaps": gaps,
        "blanks": blanks,
        "duration_sec": round(total, 1),
        "music": music_plan,
    }
    return xml, info
