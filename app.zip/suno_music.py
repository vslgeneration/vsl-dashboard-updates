"""Suno (via Kie.ai) background-music generation for the VSL dashboard.

The app analyses the script into emotional SECTIONS (Claude subscription, see premiere_export.segment_emotions)
and each section is mapped to ONE of the MOODS below. For a mood with no track in the library yet, we GENERATE
an instrumental track with Suno and store it in the library; existing library tracks are reused. Every prompt is
tuned for MOVEMENT (pulse/ostinato -> layers -> build -> peak) so the beds never sound flat/monotone — the recipe
the user approved during testing.

Generation is async on Kie's side: POST /api/v1/generate returns a taskId; we poll /generate/record-info until
status == SUCCESS, then download data.response.sunoData[].audioUrl. Uses the caller-supplied Kie API key (each
project carries its own key in keys.json), so music is billed to the same project account as images/video.
"""
import time
import requests
from pathlib import Path

GEN_URL = "https://api.kie.ai/api/v1/generate"
REC_URL = "https://api.kie.ai/api/v1/generate/record-info"
MODEL = "V5"

# The 6-mood palette (folder name -> Suno style prompt + short title + negative tags). ORDER matters: it's the
# menu segment_emotions picks from. Prompts push a dynamic ARC (never a flat drone) — the approved recipe.
_NEG_BASE = "vocals, singing, spoken word, flat ambient drone, static, monotone, cheesy corporate jingle, distorted guitar"
MOODS = {
    "Hook": {
        "title": "Mysterious Suspense Hook",
        "neg": _NEG_BASE + ", slow quiet empty intro, heavy rock drums, jump scare",
        "style": ("Gripping cinematic HOOK blending MYSTERIOUS intrigue and SUSPENSE, with a relentless pulsing "
                  "ostinato that GROWS: enters strong from the first second on an insistent ticking pulse and a "
                  "mysterious lone piano/celesta motif, then LAYERS add — staccato strings, subtle risers, rising "
                  "tension pushing forward with real momentum toward a tense peak, then eases and pulses on. "
                  "Enigmatic, high-impact, constantly moving and evolving, cinematic and premium. Purely "
                  "instrumental, no vocals, no heavy drums."),
    },
    "Suspense": {
        "title": "Tense Suspense Build",
        "neg": _NEG_BASE + ", horror screams, jump scare, gore, upbeat happy, heavy rock drums",
        "style": ("Suspenseful cinematic TENSION cue with strong MOVEMENT and a clear arc — not a flat drone: "
                  "starts on a tense pulsing string ostinato and a ticking pulse, LAYERS build (staccato strings, "
                  "low brass stabs, a rising riser and mounting intensity) driving to a dramatic climactic hit, "
                  "then a short release before pulsing again. Dark, anxious, uneasy 'something is wrong' feeling but "
                  "NOT full horror. Constantly evolving. Purely instrumental, no vocals."),
    },
    "Dramatic": {
        "title": "Dramatic Emotional",
        "neg": _NEG_BASE + ", aggressive percussion, heavy rock drums",
        "style": ("Dramatic emotional cinematic score with a clear ARC and MOVEMENT: tender solo piano intro, warm "
                  "strings gradually entering and GROWING over a subtle pulse, swelling to a heartfelt emotional peak "
                  "then easing back down — dynamics that clearly rise and fall through the piece. Expressive, moving, "
                  "cinematic, evolving not static. Purely instrumental, no vocals, no aggressive percussion."),
    },
    "Scientific": {
        "title": "Science Discovery",
        "neg": _NEG_BASE + ", orchestral only, sad, heavy rock drums",
        "style": ("Modern science and discovery underscore with MOVEMENT: clean pulsing arpeggiated synths, soft "
                  "mallets and plucks driving forward, curious and precise, layers ADDING over time and momentum "
                  "DEVELOPING toward a bright feeling of a mechanism working and a discovery unfolding — evolving, "
                  "not repetitive. Intelligent and premium. Purely instrumental, light rhythmic movement, no vocals, "
                  "no heavy drums."),
    },
    "Corporate": {
        "title": "Corporate Testimonial",
        "neg": _NEG_BASE + ", heavy drums, aggressive percussion, EDM, dubstep",
        "style": ("Clean modern uplifting CORPORATE underscore for real customer testimonials, with MOVEMENT: warm "
                  "grand piano and soft synth pads over a light tasteful pluck groove that BUILDS and brightens, "
                  "trustworthy, sincere, professional and hopeful, gentle forward motion, evolving. Polished and "
                  "human. Purely instrumental, very light percussion (no heavy drums), no vocals."),
    },
    "Inspirational": {
        "title": "Dramatic Inspirational",
        "neg": _NEG_BASE + ", heavy drums, big drums, percussion driven, EDM",
        "style": ("Dramatic inspirational cinematic anthem with a powerful emotional BUILD: hopeful piano and "
                  "swelling cinematic strings, energy steadily GROWING and layers stacking toward a goosebumps "
                  "uplifting triumphant peak near the end, empowering and heartfelt. Strings and piano DRIVE it — "
                  "minimal to no drums. Cinematic and tasteful, epic but emotional. Purely instrumental, no vocals."),
    },
}
MOOD_NAMES = list(MOODS.keys())


def humanize(mood):
    """A short human hint for the segmenter prompt (what each mood is FOR in a VSL)."""
    return {
        "Hook": "the opening hook / curiosity — mysterious + suspenseful",
        "Suspense": "problem / danger / tension — dark and uneasy",
        "Dramatic": "the emotional story — heartfelt and moving",
        "Scientific": "the mechanism / ingredients / how-it-works explanation",
        "Corporate": "customer testimonials / social proof — warm and trustworthy",
        "Inspirational": "the solution reveal / hopeful call-to-action — uplifting and rising",
    }.get(mood, mood.lower())


def generate(mood, api_key, out_path, style_weight=0.7, timeout=600, poll=12, variations=1, log=None, should_cancel=None):
    """Generate ONE instrumental track for `mood` with Suno (via Kie), download it to `out_path`, return the Path
    (or None on failure). `variations` extra takes (Suno returns 2 per request) are saved as <stem>_2.mp3 etc.
    `log` is an optional callable(str) for progress. `should_cancel()` -> truthy aborts the wait early (Stop button)."""
    spec = MOODS.get(mood)
    if not spec:
        return None
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    H = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    body = {"customMode": True, "instrumental": True, "model": MODEL,
            "style": spec["style"], "title": spec["title"], "negativeTags": spec["neg"],
            "styleWeight": style_weight, "callBackUrl": "https://example.com/none"}
    def _log(m):
        if log:
            try: log(m)
            except Exception: pass
    try:
        r = requests.post(GEN_URL, headers=H, json=body, timeout=60)
        j = r.json()
        tid = (j.get("data") or {}).get("taskId")
        _log(f"suno submit {mood}: {r.status_code} {j.get('code')} task={tid}")
        if not tid:
            return None
    except Exception as e:
        _log(f"suno submit error {mood}: {e}")
        return None
    deadline = time.time() + timeout
    sd = None
    while time.time() < deadline:
        if should_cancel and should_cancel():
            _log(f"suno cancelled {mood}")
            return None
        time.sleep(poll)
        try:
            r = requests.get(REC_URL, headers=H, params={"taskId": tid}, timeout=30)
            d = (r.json().get("data") or {})
            st = d.get("status")
            tracks = ((d.get("response") or {}).get("sunoData")) or []
            if st == "SUCCESS" and tracks:
                sd = tracks
                break
            if st in ("CREATE_TASK_FAILED", "GENERATE_AUDIO_FAILED", "CALLBACK_EXCEPTION", "SENSITIVE_WORD_ERROR"):
                _log(f"suno failed {mood}: {st}")
                return None
        except Exception as e:
            _log(f"suno poll error {mood}: {e}")
    if not sd:
        _log(f"suno timeout {mood}")
        return None
    saved = None
    want = max(1, min(2, variations))
    for i, tr in enumerate(sd[:want]):
        url = tr.get("audioUrl") or tr.get("streamAudioUrl")
        if not url:
            continue
        dst = out_path if i == 0 else out_path.with_name(f"{out_path.stem}_{i+1}{out_path.suffix}")
        try:
            a = requests.get(url, timeout=180)
            dst.write_bytes(a.content)
            if i == 0:
                saved = dst
            _log(f"suno saved {mood}: {dst.name} ({len(a.content)//1024}KB)")
        except Exception as e:
            _log(f"suno download error {mood}: {e}")
    return saved
