"""Background-music MOOD PALETTE for the VSL dashboard.

The app analyses the script into emotional SECTIONS (Claude, see premiere_export.segment_emotions) and maps each
section to ONE of the MOODS below; each mood is a FOLDER of tracks under BGM_ROOT/<Mood>/. The music library is
CURATED BY THE USER — they drop their own level-matched tracks into these folders. There is NO automatic
generation anymore (the old Suno/Kie generation was removed); the app only SELECTS from the library.

MOOD_NAMES is the exact menu the segmenter picks from (and must match the folder names on disk, spaces included).
`humanize(mood)` tells the segmenter what each mood is FOR in a VSL.
"""

# Folder name -> a short human title. ORDER = the menu the segmenter sees (hooks first: they're script openings).
MOODS = {
    "Mysterious Hook": {"title": "Mysterious Hook"},
    "Fear Hook":       {"title": "Fear Hook"},
    "Documentary":     {"title": "Documentary"},
    "Scientific":      {"title": "Scientific"},
    "Dramatic":        {"title": "Dramatic"},
    "Fear":            {"title": "Fear"},
    "Corporate":       {"title": "Corporate"},
    "Inspirational":   {"title": "Inspirational"},
}
MOOD_NAMES = list(MOODS.keys())


def humanize(mood):
    """A short hint for the segmenter prompt: what each mood is FOR in a VSL."""
    return {
        "Mysterious Hook": ("ONLY the very opening (~20-25s) of a script whose first lines are MYSTERIOUS / "
                            "curiosity-arousing / intriguing — an opening teaser hook"),
        "Fear Hook":       ("ONLY the very opening (~15-20s) of a script whose first lines are FRIGHTENING / "
                            "alarming — a scary opening teaser hook"),
        "Documentary":     ("neutral storytelling — a character's non-sad story, a self-introduction, or generic "
                            "neither-good-nor-bad narration"),
        "Scientific":      ("ingredients, science, analyses, research, studies, reports, graphs — anything "
                            "technical or scientific"),
        "Dramatic":        ("emotional / sad / dark / pessimistic moments; a character's bad experiences; heavy, "
                            "downbeat feelings"),
        "Fear":            ("very critical, alarming danger — death risk, malicious people, major health problems, "
                            "bleak high-stakes threat"),
        "Corporate":       ("testimonials / social proof, the product reveal, and the happy positive stretch "
                            "toward the end of the VSL"),
        "Inspirational":   ("after the product is introduced — the positive promises/benefits to the viewer, and "
                            "the call-to-action push"),
    }.get(mood, mood.lower())
