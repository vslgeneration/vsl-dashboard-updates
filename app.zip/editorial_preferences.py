"""Local editing preferences and conservative experience analysis. No model or network calls."""
from pathlib import Path
import hashlib, json, re, unicodedata

MODE_FIELDS = ('pure', 'no_cast', 'split', 'product', 'testimonial', 'camera', 'style', 'bg', 'ingredients', 'cast', 'refs', 'ref_free', 'packs', 'checkout', 'showcase', 'model')

def clean_rules(value):
    if not isinstance(value, str) or len(value) > 6000:
        raise ValueError('Preferences must be text of at most 6000 characters.')
    return value.strip()


def edit_suggestion_source(example):
    """A recorded difference is evidence of a change, never proof who made it or why."""
    before = str(example.get('baseline') or '').strip()
    after = str(example.get('prompt') or '').strip()
    if not before or not after or before == after:
        raise ValueError('This example has no comparable before/after prompt record.')
    return dict(id=example['id'], vo=example.get('vo') or '', before=before, after=after,
                mode=example.get('mode') or 'Unknown', settings=example.get('settings') or {},
                provenance=example.get('provenance') or '', caution=example.get('caution') or '')


def audit_overview(scenes, target_ids=(), limit=160):
    """All-scene aggregates plus bounded, evenly distributed read-only story context."""
    from collections import Counter, defaultdict
    rows=list(scenes); focus=set(target_ids); selected={i for i,s in enumerate(rows) if s.get('id') in focus}
    slots=max(0,limit-len(selected)); remaining=[i for i in range(len(rows)) if i not in selected]
    if len(remaining)<=slots:selected.update(remaining)
    elif slots:
        selected.update(remaining[round(k*(len(remaining)-1)/max(1,slots-1))] for k in range(slots))
    cameras=Counter(str(s.get('camera') or 'unspecified') for s in rows)
    groups=defaultdict(list)
    for s in rows:
        norm=_normalized(s.get('prompt') or '')
        if norm:groups[norm].append(s.get('id'))
    repeats=[dict(ids=ids[:40],count=len(ids),prompt=p[:240]) for p,ids in groups.items() if len(ids)>1]
    repeats.sort(key=lambda r:(-r['count'],str(r['ids'])))
    sequence=[dict(id=s.get('id'),uid=s.get('uid'),continues=s.get('cont_of'),
        protected=bool(s.get('approved') or s.get('pure') or s.get('no_cast') or s.get('testimonial')),
        vo=str(s.get('vo') or '')[:180],prompt=str(s.get('prompt') or '')[:260],
        camera=s.get('camera') or '',style=s.get('style') or '',product=bool(s.get('product')),
        cast=s.get('cast') or []) for i,s in enumerate(rows) if i in selected]
    return dict(total=len(rows),included=len(sequence),omitted=len(rows)-len(sequence),
                camera_counts=dict(cameras),exact_prompt_repeats=repeats[:20],
                omitted_repeat_groups=max(0,len(repeats)-20),sequence=sequence,
                scope='Aggregates cover all scenes. Sequence text is truncated; omitted counts are explicit. Counts alone do not prove a defect.')

def read_profile(path):
    path = Path(path)
    if not path.exists():
        return {'global_rules': '', 'projects': {}, 'example_ids': []}
    d = json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(d, dict) or not isinstance(d.get('global_rules', ''), str)
            or not isinstance(d.get('projects', {}), dict) or not isinstance(d.get('example_ids', []), list)
            or any(not isinstance(v, str) for v in d.get('projects', {}).values())):
        raise ValueError('Could not read the preference file; the existing file is preserved.')
    clean_example_notes(d.get('example_notes', {}))
    return d

def clean_example_notes(value):
    if (not isinstance(value, dict) or len(value) > 30
            or any(not isinstance(k, str) or not isinstance(v, str) or len(v) > 600 for k, v in value.items())):
        raise ValueError('You can add notes to up to 30 examples, with at most 600 characters per note.')
    return {k: v.strip() for k, v in value.items() if v.strip()}

def revision(profile):
    return hashlib.sha256(json.dumps(profile, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def updated_profile(previous, project, body, valid_examples):
    if body.get('revision') != revision(previous):
        raise ValueError('Preferences changed in another window. Reopen and save again.')
    ids = body.get('example_ids', [])
    if not isinstance(ids, list) or len(ids) > 30 or any(not isinstance(x, str) for x in ids):
        raise ValueError('You can select up to 30 experience examples.')
    if any(x not in valid_examples for x in ids):
        raise ValueError('The selected example changed or is no longer eligible. Refresh the list.')
    out = dict(previous, global_rules=clean_rules(body.get('global_rules', '')),
               example_ids=list(dict.fromkeys(ids)))
    out['projects'] = dict(previous.get('projects') or {})
    out['projects'][project] = clean_rules(body.get('project_rules', ''))
    if 'example_notes' in body or 'example_notes' in previous:
        notes = clean_example_notes(body.get('example_notes', previous.get('example_notes', {})))
        if 'example_notes' in body and any(k not in ids for k in notes):
            raise ValueError('Notes can only be added to selected examples.')
        out['example_notes'] = {k: v for k, v in notes.items() if k in ids}
    return out

def _normalized(t):
    text = unicodedata.normalize('NFKD', (t or '').casefold().replace('ı', 'i'))
    text = ''.join(c for c in text if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[^\W_]+', text))


# Common grammatical words are not evidence that two scenes tell the same story.
_STOP = set('''the and this that these those with from your yours their there they them
you are were was will would could should have has had what which when where who how
into for before after about only just still very then than here also some any every
our out not can une des les dans pour avec sans vous votre vos nous notre nos leur
leurs sont etes etre est avez avoir avait encore deja mais alors donc chaque fois
que qui quoi cette cet ces cela ceux elle elles ils avant apres comme plus moins
meme bien tout tous toute toutes aucun aucune peut peux faut exactement rapidement
probablement maintenant egalement moi mon mes ici irez c est un en du au aux sur ou
bir ve bu su o da de ile icin gibi daha cok her hem ama fakat veya ya ne nasil neden
sen siz sizin biz bizim onun onlar benim bana size sizi bunu sunu olan olarak kadar
sonra once simdi hala tam olabilir var yok'''.split())


def _words(t):
    return {w for w in _normalized(t).split() if len(w) >= 3 and w not in _STOP and not w.isdigit()}


# Conservative local cues, not a claim of full semantic understanding. Inspect narration
# only: an unrelated visual prompt must never manufacture a purpose for its scene.
_PURPOSE_CUES = {
    'delivery': (r'\b(?:shipping (?:costs?|fees?|is free)|free shipping|delivery (?:costs?|fees?)|(?:parcel|package|order) (?:arrives?|delivered)|doorstep|livraison|expedition de votre colis|teslimat\w*|kargo\w*)\b',),
    'financial reassurance': (r'\b(?:money back|refund\w*|rembours\w*|para iade\w*)\b',
        r'\b(?:no|zero|without(?: any)?|aucun|sans(?: aucun)?) (?:risk|risque)\b.{0,55}\b(?:wallet|money|porte monnaie|argent)\b'),
    'bedtime': (r'\b(?:bedtime|(?:go|going|lie|lying) (?:to|in) bed|coucher|yataga|yatarken|yatmadan)\b',),
    'self introduction': (r'\b(?:introduce myself|introducing myself|me presenter|me presente|kendimi tanit\w*)\b',),
    'skepticism': (r'\b(?:skeptic\w*|scepti\w*|doubt\w*|doute\w*|suphe\w*)\b',),
    'product suitability': (r'\b(?:what you need|right for you|ce qu il vous faut|tam size gore|ihtiyaciniz olan)\b',),
}
_PURPOSE_LABELS = {name: name for name in _PURPOSE_CUES}
_PURPOSE_LABELS['shopping channels'] = 'in-store versus online shopping'


def _blocked_purposes(text):
    text = _normalized(text)
    blocked = set()
    if re.search(r'\b(?:no (?:money back|refunds?)|non refundable|pas de remboursement|para iadesi yok)\b', text):
        blocked.add('financial reassurance')
    if re.search(r'\b(?:no doubts?|without (?:any )?doubt|not skeptical|no longer skept\w*|sans (?:aucun )?doute|aucun doute|suphe\w* (?:yok|duymuyorum))\b', text):
        blocked.add('skepticism')
    return blocked


def _purposes(text):
    text = _normalized(text)
    found = {name for name, cues in _PURPOSE_CUES.items() if any(re.search(cue, text) for cue in cues)}
    if (re.search(r'\b(?:stores?|shops?|boutiques?|magasins?|magaza\w*)\b', text)
            and re.search(r'\b(?:online|internet\w*|web|en ligne)\b', text)):
        found.add('shopping channels')
    return found - _blocked_purposes(text)


def _segments(vo):
    # Director callers pass individual scene lines so words in unrelated scenes cannot
    # combine into one lexical match. Older callers passing one string remain supported.
    lines = vo if isinstance(vo, (list, tuple)) else [vo]
    return [part.strip() for line in lines if isinstance(line, str)
            for part in re.split(r'[.!?\n]+', line) if part.strip()]


def _rank_examples(profile, ptype, vo, examples):
    selected = set(profile.get('example_ids') or [])
    segments = [(s, _words(s), _purposes(s), _blocked_purposes(s)) for s in _segments(vo)]
    ranked = []
    for e in examples:
        if e['id'] not in selected or e.get('ptype') != ptype:
            continue
        original = e.get('vo') or ''
        words, purposes = _words(original), _purposes(original)
        best = None
        for index, (line, query_words, query_purposes, query_blocked) in enumerate(segments):
            if purposes & query_blocked or query_purposes & _blocked_purposes(original):
                continue
            common = words & query_words
            overlap = len(common) / max(1, min(len(words), len(query_words)))
            shared = purposes & query_purposes
            exact = _normalized(line) == _normalized(original) and bool(words)
            # Known different purposes override incidental wording. For unknown purposes,
            # keep a conservative meaningful-word fallback (e.g. forest + sunlight).
            lexical = len(common) >= 2 and overlap >= .5 and not (purposes and query_purposes and not shared)
            if not (exact or shared or lexical):
                continue
            score = (3 if exact else 2 if shared else 1, overlap, len(common), -index)
            reason = _PURPOSE_LABELS[sorted(shared)[0]] if shared else 'same narration' if exact else 'shared content words'
            if best is None or score > best[0]:
                best = (score, reason)
        if best:
            ranked.append((best[0], best[1], e))
    ranked.sort(key=lambda row: (tuple(-v for v in row[0]), row[2]['id']))
    result, seen, used_purposes = [], set(), set()
    # Prefer coverage of distinct recognized purposes before repeating one technique.
    deferred = []
    for score, reason, e in ranked:
        fingerprint = (_normalized(e['vo']), _normalized(e['prompt']))
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        if reason in _PURPOSE_LABELS.values() and reason in used_purposes:
            deferred.append((e, reason))
        else:
            result.append((e, reason)); used_purposes.add(reason)
    return (result + deferred)[:3]

def experience(projects, log=None):
    """Approved, narrated examples only. Unknown historic button states stay explicitly unknown."""
    projects = Path(projects)
    # Legacy learn_log is installation-wide and has no account owner. Never join it by project name/UID.
    examples, totals = [], dict(projects=0, scenes=0, approved=0, stored_versions=0,
                               excluded_empty=0, excluded_unapproved=0, excluded_no_media=0,
                               excluded_no_evidence=0, changed_prompt_candidates=0, first_take_approved=0)
    problems = []
    for path in sorted(projects.glob('*/scenes.json')):
        if path.parent.name.startswith('_'):
            continue
        try:
            doc = json.loads(path.read_text(encoding='utf-8'))
            totals['projects'] += 1
            for s in doc.get('scenes', []):
                totals['scenes'] += 1
                im = s.get('image') or {}
                vs = im.get('versions') or []
                totals['stored_versions'] += len(vs)  # includes uploads/copies, not AI attempts
                if not s.get('approved'):
                    totals['excluded_unapproved'] += 1; continue
                totals['approved'] += 1
                av = im.get('approved_version')
                if isinstance(av, int) and not isinstance(av, bool) and av == 0:
                    totals['first_take_approved'] += 1
                vo, prompt = (s.get('vo') or '').strip(), (s.get('prompt') or '').strip()
                rel = im.get('approved_file')
                if not rel and isinstance(av, int) and not isinstance(av, bool) and 0 <= av < len(vs):
                    rel = vs[av]
                if not rel:
                    totals['excluded_no_media'] += 1; continue
                media = (path.parent / rel).resolve()
                if not media.is_relative_to(path.parent.resolve()) or not media.is_file():
                    totals['excluded_no_media'] += 1; continue
                r = (im.get('generation_records') or {}).get(rel) or {}
                known = r.get('basis') == 'submitted_generation' and r.get('uid') == s.get('uid')
                if known:
                    vo, prompt = r.get('vo') or '', r.get('prompt') or ''
                if len(vo.split()) < 4 or len(prompt) < 20:
                    totals['excluded_empty'] += 1; continue
                baseline = (r.get('director_prompt') if known else s.get('director_prompt')) or ''
                changed = bool(baseline.strip() and baseline.strip() != prompt)
                # Current RAW/PURE alone is not proof of a historical generation or a manual edit.
                if not known and not changed:
                    totals['excluded_no_evidence'] += 1; continue
                if changed:
                    totals['changed_prompt_candidates'] += 1
                settings = r.get('settings', {}) if known else {}
                mode = 'PURE' if settings.get('pure') else 'RAW' if settings.get('no_cast') else 'AUTO' if known else 'Unknown'
                # A narrated, approved experiment can still be random: legacy examples require selection.
                # For new records require the narration to belong to the actual script, and no review note.
                in_script = ' '.join(vo.split()).casefold() in ' '.join(str(doc.get('script') or '').split()).casefold()
                eligible = bool(known and in_script and not (s.get('note') or '').strip())
                payload = [path.parent.name, s.get('uid'), vo, prompt, rel, settings]
                eid = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:20]
                examples.append(dict(id=eid, project=path.parent.name, scene=s.get('id'), uid=s.get('uid'),
                                     vo=vo, prompt=prompt, baseline=baseline, changed=changed, mode=mode,
                                     settings=settings, ptype=doc.get('ptype') or 'vsl',
                                     auto_eligible=eligible,
                                     provenance='Generation record linked to the approved image' if known else 'Currently approved scene; historical settings unknown',
                                     caution='' if known else 'It is not established that this prompt produced the approved image or who made the change; select examples you have verified yourself.',
                                     file=rel))
        except (OSError, ValueError, TypeError, AttributeError) as e:
            problems.append({'project':path.parent.name, 'error':type(e).__name__})
    # Manual-looking differences first, but never relabel them as proved human edits.
    examples.sort(key=lambda e: (not e['changed'], e['project'], e['scene'] or 0))
    return {'examples': examples, 'totals': totals, 'unreadable': problems,
            'limits': 'Older records cannot establish the true first-generation success rate, human edit count or QA false-alarm rate. Version counts also include uploads and copies.'}

def context(profile, project, ptype='vsl', vo='', examples=(), include_examples=False):
    general = (profile.get('global_rules') or '').strip()
    local = (profile.get('projects', {}).get(project) or '').strip()
    parts = []
    if general: parts.append('GLOBAL EDITING PREFERENCES:\n' + general)
    if local: parts.append('PROJECT EDITING PREFERENCES (override global defaults):\n' + local)
    if include_examples:
        for e, reason in _rank_examples(profile, ptype, vo, examples):
            note = (profile.get('example_notes') or {}).get(e['id'], '').strip()
            parts.append('USER-SELECTED TECHNIQUE EXAMPLE, NOT CONTENT TO COPY:\n'
                         + 'Local match cue: ' + reason + ' (heuristic; use only if relevant to this scene).\n'
                         + 'Original line: ' + e['vo'][:700] + '\nPreferred visual: ' + e['prompt'][:1200]
                         + '\nRecorded mode: ' + e['mode'] + '; ' + e['provenance']
                         + '\nTransfer only the visual technique. Never copy its brand, person, claims or setting into an unrelated project.')
            if note:
                parts.append('USER EXPLANATION OF WHAT TO LEARN FROM THIS EXAMPLE:\n' + note
                             + '\nUse this explanation to choose the relevant technique, not to import the old scene content. '
                             'It does not override explicit scene instructions, RAW/PURE, references, project rules or global rules.')
    if not parts: return ''
    return ('\nEDITING PREFERENCES: apply relevant preferences as defaults, never alter the narration or invent claims. '
            'Explicit scene settings, RAW/PURE text, selected references and project style remain authoritative. '
            'The project rules override global defaults; examples illustrate technique and never override either.\n'
            + '\n\n'.join(parts))


def focused_edit(instructions, preserve=False, keep=""):
    """A short, explicit edit scope; legacy/RAW instruction-only behavior is opt-out."""
    parts=[]
    if preserve:
        parts.append("EDIT SCOPE: Make only the requested change to the first/base image. Preserve unrelated faces, "
                     "outfits, background, composition and visual style. Allow changes to any attribute explicitly "
                     "requested below; do not freeze a face or body when that is the requested edit. Do not redesign "
                     "the whole image or add unrelated objects. This is guidance, not a pixel mask.")
    if keep:
        parts.append("USER'S EXPLICIT KEEP CONSTRAINTS (preserve these even if the change request is ambiguous): " + keep)
    return "\n\n".join(parts+[instructions])


def make_trial_set(profile, examples, requirements):
    """Frozen user-selected examples test local guidance, never an AI/image quality score."""
    import copy
    selected = [e for e in examples if e['id'] in profile.get('example_ids', [])]
    if not selected: raise ValueError('Select examples first, then click Save preferences.')
    if not isinstance(requirements, dict) or any(k not in {e['id'] for e in selected} for k in requirements):
        raise ValueError('Expectations must belong to saved selected examples.')
    cases=[]
    for e in selected[:30]:
        rules=requirements.get(e['id'], {})
        if not isinstance(rules,dict): raise ValueError('Invalid expectation.')
        for key in ('include','exclude'):
            arr=rules.get(key, [])
            if not isinstance(arr,list) or len(arr)>10 or any(not isinstance(s,str) or not s.strip() or len(s)>200 for s in arr):
                raise ValueError('Each expectation allows at most 10 lines, with 200 characters per line.')
        # All selected examples participate, including competition for the three available slots.
        text=context(profile,e['project'],e['ptype'],e['vo'],selected,True)
        cases.append(dict(id=e['id'],project=e['project'],scene=e['scene'],ptype=e['ptype'],vo=e['vo'],
                          expected=text,include=rules.get('include',[]),exclude=rules.get('exclude',[])))
    return dict(schema=1,profile=copy.deepcopy(profile),examples=copy.deepcopy(selected),cases=cases)


def run_trial_set(suite):
    rows=[]
    for c in suite.get('cases',[]):
        actual=context(suite['profile'],c['project'],c['ptype'],c['vo'],suite['examples'],True)
        missing=[s for s in c['include'] if s.casefold() not in actual.casefold()]
        unwanted=[s for s in c['exclude'] if s.casefold() in actual.casefold()]
        rows.append(dict(id=c['id'],project=c['project'],scene=c['scene'],unchanged=actual==c['expected'],
                         passed=actual==c['expected'] and not missing and not unwanted,
                         missing=missing,unwanted=unwanted,expected=c['expected'],actual=actual))
    return dict(rows=rows,passed=sum(r['passed'] for r in rows),total=len(rows))


def version_evidence(scene):
    """Only records owned by this scene/file; current button states are never historical evidence."""
    im=scene.get('image') or {};records=im.get('generation_records') or {};out=[]
    for i,rel in enumerate(im.get('versions') or []):
        r=records.get(rel) or {}
        known=r.get('basis')=='submitted_generation' and bool(scene.get('uid')) and r.get('uid')==scene['uid']
        out.append(dict(index=i,file=rel,known=known,
            prompt=r.get('prompt','') if known else None,sent_prompt=r.get('sent_prompt','') if known else None,
            model=r.get('model') if known else None,settings={k:r.get('settings',{}).get(k) for k in MODE_FIELDS} if known else None))
    return out


def prompt_conflicts(scene, panels=False, continuity_available=False):
    """A few explainable local mismatches; no claim to understand every prompt."""
    text=scene.get('prompt') or ''
    if not text.strip():return []
    out=[]
    def add(code,message,fix):out.append(dict(code=code,message=message,fix=fix))
    manual=bool(scene.get('pure') or scene.get('no_cast'))
    if panels and not scene.get('split'):
        add('panels_off','The prompt describes a panelled image, but Split is off.','Enable Split if you want panels, or remove the panel instructions.')
    # Split is also honored in RAW/PURE. Lack of LEFT/RIGHT alone is not proof of a conflict.
    plain=_normalized(text)
    if scene.get('split') and any(x in plain for x in ('single unsplit image','no split screen','tek bolunmemis gorsel','sans ecran partage')):
        add('panels_on','Split is on, but the prompt requests a single unsplit image.','Change the Split setting or the single-image instruction.')
    if manual:return out
    # Explicitly negated style words must never cause a warning.
    affirmative=re.sub(r"\b(?:not|no|without|avoid|pas de|sans)\s+(?:a\s+)?(?:photorealistic|photorealism|realistic photo|cartoon|2d animation|3d render)\b",'',plain)
    photo=bool(re.search(r'\b(?:photorealistic|photorealism|realistic photo)\b',affirmative))
    if photo and scene.get('style') in ('2d','3d','scientific'):
        add('style','The selected style is illustration/animation, but the prompt requests photorealism.','Review the style selection or the photorealistic/photo request in the prompt.')
    if scene.get('cont_of') and not continuity_available:
        add('continuity_missing','A continuation scene is selected, but the previous scene has no usable reference image.','Generate/approve the source scene image first, or remove the continuation link.')
    return out
