"""Horizontal video reflection into a new local take; originals and timing stay intact."""
import copy
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import uuid

import browser_video
import project_canvas
from scene_video_download import display_size

_ENCODER = threading.BoundedSemaphore(1)
_WATCH = ('image', 'video', 'approved', 'media_framing', 'video_starts', 'speaker_clip')


def file_signature(path):
    stat = Path(path).stat()
    return [stat.st_size, stat.st_mtime_ns]


def mirror_filters(info):
    """Autorotation is applied by the decoder; mirror the displayed orientation."""
    _, _, dw, dh = display_size(info)
    dims = (max(2, round(dw / 2) * 2), max(2, round(dh / 2) * 2))
    chain = []
    if info['video'].get('color_transfer') in ('smpte2084', 'arib-std-b67'):
        chain += ['zscale=t=linear:npl=100', 'format=gbrpf32le', 'zscale=p=bt709',
                  'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv']
    chain += ['hflip', f'scale={dims[0]}:{dims[1]}:flags=lanczos', 'setsar=1', 'format=yuv420p']
    return ','.join(chain), dims


def mirror_video(source, target, progress=lambda *a: None, cancelled=lambda: False):
    """Streaming encode, one worker/two threads; keep source timestamps and audio."""
    source, target = Path(source).resolve(), Path(target).resolve()
    if source == target:
        raise ValueError('The original video cannot be overwritten.')
    identity = file_signature(source)
    def check():
        if cancelled():
            raise InterruptedError('Video mirroring stopped.')
    while not _ENCODER.acquire(timeout=.2):
        check()
    part = target.with_name('.mirror-' + uuid.uuid4().hex + '.part.mp4')
    try:
        check()
        info = browser_video.probe(source)
        vf, dims = mirror_filters(info)
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)
        args = ['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-filter_threads', '1',
                '-i', str(source), '-map', '0:v:0', '-map', '0:a:0?', '-map_metadata', '-1',
                '-vf', vf, '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-threads', '2',
                '-fps_mode', 'passthrough', '-metadata:s:v:0', 'rotate=0']
        if info['audio'] and info['audio'].get('codec_name') == 'aac':
            args += ['-c:a', 'copy']
        else:
            args += ['-c:a', 'aac', '-b:a', '192k']
        if info['video'].get('color_transfer') in ('smpte2084', 'arib-std-b67'):
            args += ['-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709']
        args += ['-movflags', '+faststart', '-progress', 'pipe:1', '-n', str(part)]
        progress('Mirroring Video…', 0)
        with tempfile.TemporaryDirectory(prefix='mirror-log-', dir=target.parent) as logs, \
             open(Path(logs) / 'progress', 'wb') as writer, \
             open(Path(logs) / 'progress', 'rb') as log, tempfile.TemporaryFile() as errors:
            process = subprocess.Popen(args, stdout=writer, stderr=errors, creationflags=flags)
            started = time.monotonic(); position = 0; pending = b''
            try:
                while process.poll() is None:
                    check()
                    if time.monotonic() - started > 1800:
                        raise TimeoutError('Mirroring this video took too long. Please retry.')
                    log.seek(position); chunk = log.read(); position += len(chunk); pending += chunk
                    lines = pending.split(b'\n'); pending = lines.pop()
                    for line in lines:
                        if line.startswith(b'out_time_us='):
                            try:
                                elapsed = max(0, int(line.split(b'=')[1]) / 1_000_000)
                                progress('Mirroring Video…', min(99, elapsed / info['duration'] * 100))
                            except ValueError:
                                pass
                    time.sleep(.2)
                if process.returncode:
                    errors.seek(0)
                    raise ValueError('Could not mirror this video: ' + errors.read().decode('utf8', 'replace')[-350:])
            finally:
                if process.poll() is None:
                    process.kill(); process.wait()
        check()
        actual = browser_video.probe(part)
        if ((actual['video']['width'], actual['video']['height']) != dims or actual['rotation'] != 0
                or bool(actual['audio']) != bool(info['audio'])
                or abs(actual['duration'] - info['duration']) > max(.1, 2 / info['fps'])
                or abs(actual['fps'] - info['fps']) > max(.01, info['fps'] * .001)):
            raise ValueError('The mirrored copy did not preserve the source timing or dimensions.')
        if file_signature(source) != identity:
            raise ValueError('The original video changed. Please retry.')
        os.replace(part, target)
        return actual
    finally:
        part.unlink(missing_ok=True)
        _ENCODER.release()


def make_poster(source, target, start=0):
    """A small preview-only thumbnail, independent of the take's canonical image source."""
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)
    result = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-ss', str(start),
                             '-i', str(source), '-map', '0:v:0', '-frames:v', '1',
                             '-vf', 'scale=960:960:force_original_aspect_ratio=decrease',
                             '-threads', '2', '-y', str(target)], capture_output=True, timeout=60, creationflags=flags)
    if result.returncode or not Path(target).is_file() or Path(target).stat().st_size < 100:
        raise ValueError('The mirrored video preview could not be prepared.')


def register(g):
    app, request, jsonify = g['app'], g['request'], g['jsonify']
    jobs = g['_user_job_registry']('video-mirror')

    @app.route('/api/video-mirror/<project>', methods=['POST'], endpoint='video_mirror_start')
    def start(project):
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return jsonify(error='Invalid mirror request.'), 400
        uid, source = body.get('uid'), body.get('file')
        with g['_project_lock'](project):
            doc = g['load_doc'](project)
            if doc is None:
                g['abort'](404)
            scene = next((s for s in doc.get('scenes', []) if s.get('uid') == uid), None)
            d = g['proj_dir'](project)[0]
            if not scene or not isinstance(source, str):
                return jsonify(error='Select a video first.'), 400
            if g['speaker_package'].locked(scene):
                return jsonify(error='Spokesperson source videos are protected.'), 409
            video = scene.get('video') or {}
            if source not in g['_video_takes'](video) or not g['_inside'](d/source, d) or not (d/source).is_file():
                return jsonify(error='The selected video is no longer available.'), 409
            if video.get('status') in g['_JOB_BUSY'] or g['_image_busy'](scene):
                return jsonify(error='Wait for this scene’s generation to finish before mirroring.'), 409
            if any(j.get('status') == 'running' and j.get('project') == project and j.get('uid') == uid for j in jobs.values()):
                return jsonify(error='This video is already being mirrored.'), 409
            if any(j.get('status') == 'running' and j.get('project') == project and j.get('uid') == uid
                   for j in g.get('_VIDEO_REVERSE_JOBS', {}).values()):
                return jsonify(error='Wait for this scene’s video edit to finish.'), 409
            snapshot = {key: copy.deepcopy(scene.get(key)) for key in _WATCH}
            folder = g['_split_folder_identity'](project); signature = file_signature(d/source)
            job = dict(id=uuid.uuid4().hex, project=project, uid=uid, source=source, status='running',
                       step='Mirroring Video…', pct=None, cancel=False)
            jobs[job['id']] = job

        def work():
            owned = []
            try:
                original_video = snapshot['video'] or {}
                pairs = original_video.get('mirror_pairs') or {}
                signatures = original_video.get('mirror_signatures') or {}
                partner = pairs.get(source)
                valid = (isinstance(partner, str) and partner in g['_video_takes'](original_video)
                         and g['_inside'](d/partner, d) and (d/partner).is_file()
                         and pairs.get(partner) == source and signatures.get(source) == signature
                         and signatures.get(partner) == file_signature(d/partner))
                poster = None
                if not valid:
                    (d/'videos').mkdir(parents=True, exist_ok=True)
                    partner = g['_claim_new_file'](d, lambda: 'videos/mirrored_' + uuid.uuid4().hex + '.mp4')
                    owned.append(d/partner)
                    actual = mirror_video(d/source, d/partner, lambda step, pct: job.update(step=step, pct=pct), lambda: job['cancel'])
                    poster = g['_claim_new_file'](d, lambda: 'videos/mirrored_' + uuid.uuid4().hex + '_poster.jpg')
                    owned.append(d/poster)
                    make_poster(d/partner, d/poster, project_canvas.video_start(scene, source, actual['duration']))
                with g['_project_lock'](project):
                    current = g['load_doc'](project)
                    sc = next((s for s in (current or {}).get('scenes', []) if s.get('uid') == uid), None)
                    if job['cancel']:
                        raise InterruptedError('Video mirroring stopped.')
                    if (g['_split_folder_identity'](project) != folder or not sc
                            or any(sc.get(k) != snapshot[k] for k in _WATCH)
                            or file_signature(d/source) != signature):
                        raise ValueError('The scene changed while mirroring. Your current video was kept.')
                    approved_source = g['_approved_video_take'](sc)[1] == source
                    v = sc['video']; g['_freeze_one_take'](v); takes = v.setdefault('versions', [])
                    src_index = takes.index(source)
                    if partner not in takes:
                        provenance = g['_video_take_source'](v, src_index)
                        takes.append(partner); g['_record_take_source'](v, len(takes)-1, provenance)
                        for key in ('stock_assets', 'linked_takes'):
                            if source in (v.get(key) or {}):
                                v.setdefault(key, {})[partner] = copy.deepcopy(v[key][source])
                        v.setdefault('local_edits', {})[partner] = dict(operation='mirror', source=source, poster=poster)
                    v.setdefault('mirror_pairs', {})[source] = partner
                    v['mirror_pairs'][partner] = source
                    v.setdefault('mirror_signatures', {}).update({source: signature, partner: file_signature(d/partner)})
                    sc.setdefault('video_starts', {})[partner] = project_canvas.video_start(sc, source)
                    index = takes.index(partner)
                    v.update(current=index, file=partner, status='ready', taskId=None, error=None, appr_manual=True)
                    for key in ('from_video', 'from_scene', 'waiting_for_uid'):
                        v.pop(key, None)
                    if approved_source:
                        v.update(approved_file=partner, approved_version=index)
                        framing = project_canvas.framing_map(sc.get('media_framing'))
                        for frame in framing.values():
                            frame['x'] = -frame['x']
                        if framing:
                            sc['media_framing'] = framing
                    g['save_doc'](project, current, expected_revision=current.get('_revision', 0))
                    owned.clear()
                    job.update(status='done', step='Mirrored Video Ready', pct=100, file=partner,
                               video=copy.deepcopy(v), video_starts=copy.deepcopy(sc.get('video_starts') or {}),
                               media_framing=copy.deepcopy(sc.get('media_framing')),
                               framing_changed=sc.get('media_framing') != snapshot['media_framing'])
            except Exception as error:
                for path in owned:
                    g['_drop_own_file'](path)
                job.update(status='cancelled' if isinstance(error, InterruptedError) else 'error',
                           error=str(error)[:600], pct=None)
        g['_KeyThread'](target=work, daemon=True).start()
        return jsonify(job=job['id']), 202

    @app.route('/api/video-mirror-job/<job_id>', methods=['GET', 'POST'], endpoint='video_mirror_status')
    def status(job_id):
        job = jobs.get(job_id)
        if not job:
            g['abort'](404)
        if request.method == 'POST' and job['status'] == 'running':
            job['cancel'] = True
        return jsonify({k: v for k, v in job.items() if k != 'cancel'})
