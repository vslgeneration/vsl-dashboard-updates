"""Ownership receipts for new Cloud erase inputs; never discover or delete legacy assets."""
import json
import time
import uuid
from pathlib import Path
from storage_maintenance import _within

class EraseAssets:
    def __init__(self, project, cloud, writer):
        self.cloud=cloud
        self.writer=writer
        self.id=uuid.uuid4().hex
        self.path=_within(Path(project),Path(project)/'export/_cloud_assets'/(self.id+'.json'))
        self.record=dict(version=1,operation=self.id,cloud=cloud,created=time.time(),
                         state='prepared',task_id=None,downloaded=False,assets=[])
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.save()

    def save(self):
        self.writer(self.path,json.dumps(self.record,ensure_ascii=False,indent=2))

    def uploaded(self, public_id, receipt):
        # Only a successful, non-overwriting upload to this operation's unique
        # name qualifies. Public ID alone is never used as deletion authority.
        valid=(receipt.get('owned') is True and receipt.get('public_id')==public_id
               and self.id in public_id.split('/')[-1] and isinstance(receipt.get('asset_id'),str)
               and bool(receipt['asset_id']))
        self.record['assets'].append(dict(public_id=public_id,asset_id=receipt.get('asset_id') if valid else None,
                                          owned=valid,cleanup='retained'))
        self.save()

    def submitting(self):
        self.record['state']='submission_unknown'; self.save()

    def accepted(self,task_id):
        self.record.update(state='accepted',task_id=task_id); self.save()

    def terminal(self,state):
        if state not in ('success','fail') or not self.record['task_id']:
            raise ValueError('An explicit terminal provider result with task ID is required')
        self.record['state']='provider_'+state; self.save()

    def downloaded(self):
        self.record['downloaded']=True; self.save()

    def cleanup(self, request_post, api_key, api_secret, cloud):
        # A timeout, elapsed lease, unknown submission or failed download is not
        # permission to remove provider inputs. Old records are never replayed.
        if (cloud!=self.cloud or self.record['state']!='provider_success'
            or not self.record['downloaded'] or not self.record['task_id']): return 0
        removed=0
        for asset in self.record['assets']:
            if not asset['owned'] or asset['cleanup']!='retained': continue
            asset['cleanup']='delete_requested'; self.save()
            try:
                response=request_post('https://api.cloudinary.com/v1_1/'+cloud+'/asset/destroy',
                                      auth=(api_key,api_secret),data={'asset_id':asset['asset_id']},timeout=15)
                body=response.json()
                if 200<=response.status_code<300 and body.get('result') in ('ok','not found'):
                    asset['cleanup']='deleted'; removed+=1
                else: asset['cleanup']='delete_unknown'
            except Exception:
                asset['cleanup']='delete_unknown'
            self.save()
        return removed
