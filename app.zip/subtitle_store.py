"""Publish a complete subtitle/audio set with one atomic pointer change.

Caller must hold the project's commit lock
and validate job/project ownership. Old completed sets are retained.
"""
import json
import os
import re
import shutil
import tempfile
import uuid
from pathlib import Path


def active_dir(project):
    root = Path(project) / 'subtitle'
    pointer = root / '_current.json'
    if not pointer.exists():
        return root  # existing projects need no migration
    data = json.loads(pointer.read_text(encoding='utf-8'))
    key = data.get('set') if isinstance(data, dict) else None
    if not isinstance(key, str) or not re.fullmatch(r'[0-9a-f]{32}', key):
        raise ValueError('Invalid subtitle set record')
    chosen = root / '_sets' / key
    if not chosen.is_dir() or not chosen.resolve().is_relative_to(root.resolve()):
        raise ValueError('The published subtitle set is missing or outside its project')
    return chosen


def source_dir(project):
    active = active_dir(project)
    staged_inputs = active / '_inputs'
    return staged_inputs if staged_inputs.is_dir() else Path(project) / 'srt_src'


def _write_pointer(path, value):
    fd, raw = tempfile.mkstemp(prefix='._subtitle_pointer_', suffix='.tmp', dir=path.parent)
    owned = Path(raw)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(value, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(owned, path)
    finally:
        try:
            owned.unlink(missing_ok=True)
        except OSError:
            pass


def publish(project, completed):
    """Copy only a complete workspace, then expose it with one file rename.

    This does not validate SRT/audio formats or job identity. Those belong to the
    route/worker transaction. No old set or source input is deleted here.
    """
    project, completed = Path(project), Path(completed)
    if not (project / 'scenes.json').is_file():
        raise FileNotFoundError('Project no longer exists')
    if not completed.is_dir():
        raise FileNotFoundError('Completed subtitle workspace missing')
    # Reject links in the generated workspace instead of copying anything outside it.
    if completed.is_symlink() or any(p.is_symlink() for p in completed.rglob('*')):
        raise ValueError('Subtitle workspace contains a link')
    root = project / 'subtitle'
    sets = root / '_sets'
    sets.mkdir(parents=True, exist_ok=True)
    owned = None
    for _ in range(50):
        key = uuid.uuid4().hex
        candidate = sets / key
        try:
            candidate.mkdir()
        except FileExistsError:
            continue
        owned = candidate
        break
    if owned is None:
        raise OSError('No free subtitle set directory')
    published = False
    try:
        shutil.copytree(completed, owned, dirs_exist_ok=True)
        # File list and byte lengths catch incomplete copies without interpreting media.
        original = {p.relative_to(completed): p.stat().st_size for p in completed.rglob('*') if p.is_file()}
        copied = {p.relative_to(owned): p.stat().st_size for p in owned.rglob('*') if p.is_file()}
        if original != copied:
            raise OSError('Subtitle set copy was incomplete')
        _write_pointer(root / '_current.json', {'version': 1, 'set': key})
        published = True
        return owned
    finally:
        if not published:
            shutil.rmtree(owned, ignore_errors=True)  # only the directory this call created
