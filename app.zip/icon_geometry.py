"""Shared placement and lossless source reflection for icon preview/export parity."""
from pathlib import Path
import hashlib,json,math,os,subprocess,tempfile


def transformed_offset(x,y,rotation=0,flip=False):
    x=-x if flip else x
    angle=math.radians(float(rotation or 0));c,s=math.cos(angle),math.sin(angle)
    return x*c-y*s,x*s+y*c


def bounds(width,height,rotation=0):
    angle=math.radians(float(rotation or 0));c,s=abs(math.cos(angle)),abs(math.sin(angle))
    return max(2,math.ceil(width*c+height*s-1e-7)),max(2,math.ceil(width*s+height*c-1e-7))


def mirror_file(source,directory):
    """Never alter original artwork; XML references a private mirrored copy."""
    source=Path(source);directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    image=source.suffix.lower() in ('.png','.jpg','.jpeg','.webp')
    stamp=source.stat();key=hashlib.sha256(json.dumps([str(source.resolve()),stamp.st_size,stamp.st_mtime_ns,'mirror-v1']).encode()).hexdigest()[:20]
    dest=directory/(key+('.png' if image else '.mov'))
    if dest.is_file() and dest.stat().st_size:return dest
    fd,raw=tempfile.mkstemp(prefix='mirror-',suffix=dest.suffix,dir=directory);os.close(fd);temp=Path(raw)
    try:
        if image:
            from PIL import Image,ImageOps
            with Image.open(source) as im:ImageOps.mirror(im.convert('RGBA')).save(temp)
        else:
            result=subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-vf','hflip,format=rgba','-an','-c:v','qtrle','-pix_fmt','argb',str(temp)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            if result.returncode:raise RuntimeError('Could not reflect icon: '+result.stderr.decode('utf8',errors='replace')[-400:])
        os.replace(temp,dest);return dest
    finally:temp.unlink(missing_ok=True)
