"""Explicit, single-scene stock placement using existing reviewed search/import APIs.

No image generation, blind asset URL, account scan, or automatic download retry.
Interrupted license/import steps stop for inspection rather than starting again.
"""
import json,time,uuid,threading
from pathlib import Path
from flask import request,jsonify,abort
import speaker_package,stock_media

def has_media(scene):
 return bool((scene.get('image') or {}).get('file') or (scene.get('video') or {}).get('file'))

def choose_candidate(result):
 for item in result.get('items',[]):
  review=item.get('visual_review') or {}
  if item.get('provider') not in ('storyblocks','library'):continue
  if review.get('fit')!='match' or review.get('evidence')!='sampled_frames':continue
  if item.get('repetition') in ('used','similar'):continue
  section=item.get('section')
  if not isinstance(section,dict) or section.get('warning') or section.get('warnings'):continue
  return item
 return None

def register(app,ns):
 lock=threading.RLock();jobs=ns['_user_job_registry']('stock-autoplace')
 def path(project,uid):return ns['proj_dir'](project)[0]/'_stock_auto'/(uid+'.json')
 def call(user,method,url,body=None):
  with app.test_client() as c:
   with c.session_transaction() as sess:sess['user']=user
   response=c.open(url,method=method,json=body)
   value=response.get_json(silent=True) or {}
   if response.status_code>=400:raise ValueError(value.get('error') or 'Stock operation failed.')
   return value
 def save(j,**changes):
  with lock:
   j.update(changes,updated=time.time())
   for attempt in range(6):
    try:
     stock_media.write_json(path(j['project'],j['uid']),{k:v for k,v in j.items() if k!='cancel'});break
    except PermissionError:
     if attempt==5:raise
     time.sleep(.05*(attempt+1))
 def worker(j,user):
  project,uid=j['project'],j['uid']
  try:
   save(j,status='running',stage='searching')
   result=None;item=None
   for provider in ('all','library'):
    if j.get('cancel'):raise ValueError('Stopped before placing stock.')
    search=call(user,'POST',f'/api/stock/{project}/search',dict(uid=uid,provider=provider,type='video',query='',filters={'aspect':'16:9'}))
    save(j,search_job=search['job'],provider=provider)
    deadline=time.monotonic()+900
    while time.monotonic()<deadline:
     if j.get('cancel'):raise ValueError('Stopped before placing stock.')
     result=call(user,'GET','/api/stock/search/'+search['job'])
     if result.get('status') in ('error','cancelled'):raise ValueError(result.get('error') or 'Stock search did not finish.')
     if result.get('status')=='done' and result.get('quality_status') not in ('pending','queued','running'):
      item=choose_candidate(result);break
     time.sleep(1)
    else:raise ValueError('Stock search/review timed out. Results are retained; no download was sent.')
    if item:break
   if not item:
    save(j,status='needs_review',stage='alternatives_ready',message='No visually verified automatic-download match. Alternatives remain in Find Stock.');return
   doc=ns['load_doc'](project);scene=next((s for s in doc['scenes'] if s.get('uid')==uid),None)
   if scene is None or speaker_package.locked(scene) or has_media(scene):
    save(j,status='skipped',stage='preserved',message='A newer selection or protected source was preserved.');return
   # Journal BEFORE requesting a license. A crash here must not trigger an automatic retry.
   save(j,stage='download_requested',selected_item=item['id'],selected_provider=item['provider'])
   download=call(user,'POST',f'/api/stock/{project}/use',dict(uid=uid,search_job=result['id'],item_id=item['id']))
   save(j,download_job=download['job'])
   deadline=time.monotonic()+600
   while time.monotonic()<deadline:
    status=call(user,'GET','/api/stock/use/'+download['job'])
    if status.get('status')=='error':raise ValueError(status.get('error') or 'Stock download failed; no retry was sent.')
    if status.get('status')=='ready':break
    time.sleep(1)
   else:raise ValueError('Stock download timed out; inspect the existing job before retrying.')
   if j.get('cancel'):save(j,status='needs_review',stage='download_ready',message='Downloaded file retained; placement stopped.');return
   save(j,stage='applying',prepared_id=status['id'])
   body=dict(uid=uid,id=status['id'])
   if item.get('section'):body['section']=item['section']
   call(user,'POST',f'/api/stock/{project}/apply',body)
   save(j,status='done',stage='placed',message='Verified stock placed. Alternatives remain in Find Stock.')
  except Exception as error:save(j,status='needs_review',message=str(error)[:500])

 @app.post('/api/stock/<project>/auto-place')
 def stock_auto_place(project):
  body=request.get_json(silent=True) or {};uid=body.get('uid')
  if not isinstance(uid,str) or not uid or len(uid)>80 or not all(c.isalnum() or c in '-_' for c in uid):return jsonify(error='Choose exactly one scene UID.'),400
  with lock,ns['_project_lock'](project):
   doc=ns['load_doc'](project)
   if doc is None:abort(404)
   scene=next((s for s in doc.get('scenes',[]) if s.get('uid')==uid),None)
   if scene is None:abort(404)
   if speaker_package.locked(scene) or scene.get('testimonial') or scene.get('tcard_id'):return jsonify(error='Protected speaker/testimonial scene cannot be replaced.'),409
   if has_media(scene):return jsonify(status='skipped',message='Existing media preserved.'),200
   if ns['_image_busy'](scene) or (scene.get('video') or {}).get('status') in ns['_JOB_BUSY']:return jsonify(error='This scene already has an active media job.'),409
   saved=stock_media.read_json(path(project,uid),{}) or {}
   if saved:
    jid=saved.get('id')
    if jid in jobs:return jsonify(job=jid,status=jobs[jid]['status'])
    return jsonify(status='needs_review',message='A prior placement journal exists. Review the saved job before starting another download.',record=saved),409
   jid=uuid.uuid4().hex;j=dict(id=jid,project=project,uid=uid,status='queued',stage='queued',created=time.time())
   jobs[jid]=j;save(j)
   ns['_KeyThread'](target=worker,args=(j,ns['_user_field']('user')),daemon=True).start()
   return jsonify(job=jid,status='queued')

 @app.get('/api/stock/auto-place/<jid>')
 def stock_auto_place_status(jid):
  if jid not in jobs:abort(404)
  return jsonify({k:v for k,v in jobs[jid].items() if k!='cancel'})

 @app.post('/api/stock/auto-place/<jid>/stop')
 def stock_auto_place_stop(jid):
  if jid not in jobs:abort(404)
  jobs[jid]['cancel']=True
  return jsonify(ok=True)
