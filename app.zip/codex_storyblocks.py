"""Dashboard-owned Storyblocks MCP sessions, using the official Codex app-server.

Codex plans/reviews stock through codex_provider. Catalog calls are deterministic:
no model turn, shell, filesystem tool or unrequested license call is ever started.
OAuth is handled by Codex and stored in Windows Credential Manager. Each Dashboard
user + ChatGPT registration has its own CODEX_HOME and MCP server name.
"""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import threading
import time
from urllib.parse import urlsplit
import webbrowser

import codex_provider
import stock_cancel

SERVER = 'https://mcp.storyblocks.com/mcp'
TOOLS = ('search_videos', 'search_images', 'get_stock_item_details', 'get_download_url')
CONNECT = 'Connect Storyblocks for Codex in Settings → API Keys → Stock Accounts.'
_LOCK = threading.Lock()
_CLIENTS = {}
_SLOTS = threading.BoundedSemaphore(2)


class StoryblocksError(ValueError):
    pass


def executable():
    # Current Desktop builds extract the CLI into a versioned per-user folder.
    # WindowsApps enumeration can be unavailable to a normal desktop process.
    candidates = []
    local = os.environ.get('LOCALAPPDATA')
    if local:
        try:
            binaries = list((Path(local) / 'OpenAI/Codex/bin').glob('*/codex.exe'))
            candidates.extend(sorted(binaries, key=lambda p: p.stat().st_mtime_ns, reverse=True))
        except OSError:
            pass
    candidates.append(Path(__file__).parent.parent / 'runtime/codex.exe')
    try:
        packages = (Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'WindowsApps').glob('OpenAI.Codex_*__2p2nqsd0c76g0')
        candidates.extend(p / 'app/resources/codex.exe' for p in sorted(packages, key=lambda p: tuple(map(int, re.findall(r'\d+', p.name.split('_')[1]))), reverse=True))
    except OSError:
        pass
    found = shutil.which('codex.exe')
    if found:
        candidates.append(Path(found))
    for path in candidates:
        try:
            if path.is_file():
                return str(path)
        except OSError:
            continue
    raise StoryblocksError('Codex could not be located. Open the official Codex desktop app once on this computer, then try Connect again. If it is not installed, install Codex first. Claude remains available.')


def context(ns):
    ai = ns['_ai_context_now']()
    if ai.get('provider') != 'codex':
        raise StoryblocksError('Select Codex in AI Provider before connecting Storyblocks for Codex.')
    aid = ai.get('account_id')
    user_root = Path(ns['PROJECTS']).parent.resolve()
    status = codex_provider.service(user_root).status()
    if not aid or not any(a.get('id') == aid and a.get('connected') for a in status.get('accounts', [])):
        raise StoryblocksError('Connect your ChatGPT account in Settings → AI Provider first.')
    return user_root, aid


def client(ns):
    user_root, aid = context(ns)
    key = hashlib.sha256((str(user_root).casefold() + '\0' + aid).encode()).hexdigest()[:32]
    with _LOCK:
        if key not in _CLIENTS:
            home = Path(os.environ['LOCALAPPDATA']) / 'VSLDashboard/codex-storyblocks' / key
            _CLIENTS[key] = Client(home, 'storyblocks_' + key)
        return _CLIENTS[key]


def config(name):
    # No ChatGPT credentials are needed by this catalog-only subprocess. Inference
    # stays in codex_provider; RPC.request disallows turn/start and all local tools.
    return f'''mcp_oauth_credentials_store = "keyring"
model_provider = "dashboard_catalog"
history.persistence = "none"
analytics.enabled = false
feedback.enabled = false
mcp_optional_startup_grace_ms = 0
[model_providers.dashboard_catalog]
name = "Dashboard catalog transport"
base_url = "https://api.openai.com/v1"
wire_api = "responses"
requires_openai_auth = false
[mcp_servers.{name}]
url = "{SERVER}"
startup_timeout_sec = 25
tool_timeout_sec = 60
enabled_tools = {json.dumps(TOOLS)}
'''


def process_environment(home):
    allowed = {'SYSTEMROOT', 'WINDIR', 'PATH', 'PATHEXT', 'COMSPEC', 'TEMP', 'TMP',
        'USERPROFILE', 'LOCALAPPDATA', 'APPDATA', 'PROGRAMDATA', 'PROGRAMFILES',
        'PROGRAMFILES(X86)', 'COMMONPROGRAMFILES', 'COMMONPROGRAMFILES(X86)',
        'HOMEDRIVE', 'HOMEPATH', 'USERNAME', 'USERDOMAIN', 'OS', 'HTTP_PROXY',
        'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY', 'SSL_CERT_FILE', 'SSL_CERT_DIR'}
    env = {k: v for k, v in os.environ.items() if k.upper() in allowed}
    env.update(CODEX_HOME=str(home), RUST_LOG='off')
    return env


class RPC:
    METHODS = {'initialize', 'thread/start', 'mcpServerStatus/list', 'mcpServer/oauth/login', 'mcpServer/tool/call'}

    def __init__(self, home, name):
        self.home, self.name = Path(home), name
        self.seq, self.events = 0, []
        self.messages = queue.Queue(maxsize=128)
        self.stop = threading.Event()
        exe = executable()
        self.home.mkdir(parents=True, exist_ok=True)
        codex_provider.atomic_write(self.home / 'config.toml', config(name).encode())
        cwd = self.home / 'empty'; cwd.mkdir(exist_ok=True)
        env = process_environment(self.home)
        try:
            self.proc = subprocess.Popen([exe, 'app-server', '--listen', 'stdio://'], cwd=cwd, env=env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except OSError:
            raise StoryblocksError('Codex could not start the Storyblocks connection. Update the Codex desktop app and try again.') from None
        threading.Thread(target=self._read, daemon=True).start()
        try:
            self.request('initialize', dict(clientInfo=dict(name='AI Dashboard', title='AI Dashboard', version='949'),
                capabilities=dict(experimentalApi=True, explicitGatewayOauth=True)), timeout=15)
            self._send(dict(method='initialized'))
        except BaseException:
            self.close(); raise

    def _read(self):
        received = 0
        try:
            while not self.stop.is_set():
                raw = self.proc.stdout.readline(12 * 1024 * 1024 + 1)
                received += len(raw)
                if not raw or len(raw) > 12 * 1024 * 1024 or received > 16 * 1024 * 1024: break
                try: value = json.loads(raw)
                except (ValueError, UnicodeError): continue
                if not isinstance(value, dict): continue
                while not self.stop.is_set():
                    try: self.messages.put(value, timeout=.1); break
                    except queue.Full: pass
        finally:
            self.stop.set()

    def _send(self, value):
        try:
            self.proc.stdin.write((json.dumps(value) + '\n').encode()); self.proc.stdin.flush()
        except (OSError, ValueError):
            raise StoryblocksError('The Codex Storyblocks connection closed. No automatic repeat was sent.') from None

    def _next(self, deadline):
        while time.monotonic() < deadline:
            stock_cancel.check()
            try:
                msg = self.messages.get(timeout=.1)
            except queue.Empty:
                if self.stop.is_set(): break
                continue
            if msg.get('method') and 'id' in msg:
                # Unexpected provider forms / tool or filesystem approval requests
                # cannot expand the user's search/download authorization.
                if msg['method'] == 'mcpServer/elicitation/request':
                    self._send(dict(id=msg['id'], result=dict(action='cancel', content=None)))
                else:
                    self._send(dict(id=msg['id'], error=dict(code=-32601, message='Not authorized by Dashboard.')))
                continue
            return msg
        raise StoryblocksError('The Codex Storyblocks request did not finish. No automatic repeat was sent. Check the connection and try again.')

    def request(self, method, params, timeout=75):
        if method not in self.METHODS:
            raise StoryblocksError('Unsupported Storyblocks operation.')
        self.seq += 1; seq = self.seq
        self._send(dict(id=seq, method=method, params=params))
        deadline = time.monotonic() + timeout
        while True:
            msg = self._next(deadline)
            if msg.get('id') == seq:
                if 'error' in msg:
                    code = (msg.get('error') or {}).get('code')
                    if code == -32601:
                        raise StoryblocksError('Update the official Codex desktop app: this version does not support the Storyblocks connection.')
                    raise StoryblocksError('Storyblocks could not complete this request through Codex. Check your Storyblocks connection and membership. No automatic repeat was sent.')
                value = msg.get('result')
                if not isinstance(value, dict):
                    raise StoryblocksError('Storyblocks returned an invalid response.')
                return value
            if msg.get('method') == 'mcpServer/oauthLogin/completed':
                self.events.append(msg)
                self.events = self.events[-8:]

    def thread(self):
        data = self.request('thread/start', dict(cwd=str(self.home / 'empty'), ephemeral=True,
            model='gpt-6-astra', modelProvider='dashboard_catalog', approvalPolicy='never', sandbox='read-only'), timeout=45)
        tid = (data.get('thread') or {}).get('id')
        if not isinstance(tid, str) or not tid:
            raise StoryblocksError('Codex could not prepare the Storyblocks session.')
        return tid

    def inventory(self, tid=None):
        args = dict(serverName=self.name, detail='toolsAndAuthOnly')
        if tid: args['threadId'] = tid
        data = self.request('mcpServerStatus/list', args, timeout=40)
        return next((x for x in data.get('data', []) if x.get('name') == self.name), {})

    def close(self):
        self.stop.set()
        if self.proc.poll() is None:
            self.proc.kill()
        try: self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired: pass
        for stream in (self.proc.stdin, self.proc.stdout):
            try: stream.close()
            except (OSError, ValueError): pass


@contextlib.contextmanager
def opened(home, name):
    deadline = time.monotonic() + 90
    while not _SLOTS.acquire(timeout=.1):
        stock_cancel.check()
        if time.monotonic() > deadline:
            raise StoryblocksError('Two Storyblocks operations are still running. Try again when one finishes.')
    rpc = None
    try:
        rpc = RPC(home, name)
        yield rpc
    finally:
        if rpc: rpc.close()
        _SLOTS.release()


class Client:
    def __init__(self, home, name):
        self.home, self.name = Path(home), name
        self.lock = threading.RLock()
        self.session_lock = threading.Lock()
        self.pending = False
        self.login_rpc = None
        self.login_generation = 0
        self.current = None

    def _set(self, state, message):
        value = dict(provider='codex', state=state, message=message, checked_at=time.time())
        with self.lock:
            self.current = value
            codex_provider.atomic_write(self.home / 'status.json', json.dumps(value).encode())
        return value

    def status(self):
        with self.lock:
            if self.pending:
                return dict(provider='codex', state='connecting', pending=True, message='Finish Storyblocks sign-in in your browser. You can keep working here.')
            if self.current is None:
                try: self.current = json.loads((self.home / 'status.json').read_text())
                except (OSError, ValueError): pass
            return self.current or dict(provider='codex', state='not_connected', message=CONNECT)

    def check(self):
        with self._open() as rpc:
            tid = rpc.thread(); entry = rpc.inventory(tid)
            if entry.get('runtimeStatus') == 'connected' and all(t in entry.get('tools', {}) for t in TOOLS):
                return self._set('connected', 'Storyblocks connected through Codex. Search verifies catalog access; downloads require your Storyblocks membership.')
            return self._set('unavailable', CONNECT)

    def begin_login(self):
        executable()  # fast actionable error before starting the background login
        with self.lock:
            if self.pending: return self.status()
            self.pending = True
            self.login_generation += 1
            generation = self.login_generation
        def work():
            try:
                with self._open() as rpc:
                    with self.lock:
                        if generation != self.login_generation: return
                        self.login_rpc = rpc
                    result = rpc.request('mcpServer/oauth/login', dict(name=self.name, timeoutSecs=300, clientRegistration='cimd'), timeout=35)
                    url = result.get('authorizationUrl', '')
                    parsed = urlsplit(url)
                    if parsed.scheme != 'https' or parsed.hostname != 'auth.storyblocks.com' or parsed.port not in (None, 443) or parsed.username or parsed.password:
                        raise StoryblocksError('Storyblocks returned an unexpected sign-in page. The browser was not opened.')
                    with self.lock:
                        if generation != self.login_generation: return
                        if not webbrowser.open(url):
                            raise StoryblocksError('The Storyblocks sign-in browser could not open. Try Connect again.')
                    deadline = time.monotonic() + 300
                    while True:
                        msg = rpc.events.pop(0) if rpc.events else rpc._next(deadline)
                        if msg.get('method') != 'mcpServer/oauthLogin/completed': continue
                        p = msg.get('params') or {}
                        if p.get('name') != self.name or (result.get('loginId') and p.get('loginId') != result['loginId']): continue
                        if not p.get('success'):
                            raise StoryblocksError('Storyblocks sign-in was not completed. Try Connect again; your Claude connection was kept.')
                        with self.lock:
                            if generation != self.login_generation: return
                            self._set('connected', 'Storyblocks sign-in completed for Codex. Check connection or start a search.')
                        return
            except Exception as exc:
                with self.lock:
                    if generation == self.login_generation:
                        self._set('unavailable', str(exc) if isinstance(exc, StoryblocksError) else 'Storyblocks sign-in failed. Try Connect again.')
            finally:
                with self.lock:
                    if generation == self.login_generation:
                        self.pending = False; self.login_rpc = None
        threading.Thread(target=work, daemon=True).start()
        return self.status()

    def cancel_login(self):
        with self.lock:
            self.login_generation += 1
            rpc = self.login_rpc
            self.pending = False; self.login_rpc = None
        if rpc: rpc.close()
        return self.status()

    @contextlib.contextmanager
    def _open(self):
        # A rotating Storyblocks token is used by one process at a time per
        # account. Different Dashboard accounts may still work independently.
        deadline = time.monotonic() + 90
        while not self.session_lock.acquire(timeout=.1):
            stock_cancel.check()
            if time.monotonic() >= deadline:
                raise StoryblocksError('This Storyblocks account is busy. Finish sign-in or wait for its current operation.')
        try:
            with opened(self.home, self.name) as rpc: yield rpc
        finally: self.session_lock.release()

    @contextlib.contextmanager
    def session(self):
        with self._open() as rpc:
            tid = rpc.thread(); entry = rpc.inventory(tid)
            tools = entry.get('tools') or {}
            if entry.get('runtimeStatus') != 'connected':
                self._set('unavailable', CONNECT)
                raise StoryblocksError(CONNECT)
            def call(tool, args, claim=None):
                stock_cancel.check()
                if tool not in TOOLS or tool not in tools:
                    raise StoryblocksError('Storyblocks does not expose the requested catalog tool. Check the connection.')
                # Claim only after a working authenticated tool has been discovered,
                # immediately before sending. Never retry a potentially licensed item.
                if claim: claim()
                data = rpc.request('mcpServer/tool/call', dict(threadId=tid, server=self.name, tool=tool, arguments=args))
                if data.get('isError'):
                    raise StoryblocksError('Storyblocks could not return this item. Check your membership. No automatic repeat was sent.')
                return data
            yield call
