"""Content-addressed previews encoded by the final renderer, never by a second compositor."""
from pathlib import Path
import hashlib
import json
import os

VERSION = 'final-preview-997-1'
VOLATILE = frozenset(('_revision', 'history', 'undo_history', 'redo_history',
    'preview_built', 'generation_completed', 'updated_at', 'modified_at', 'last_opened'))

def signature(doc, timeline, options, runtime):
    assets = {}
    def visit(value):
        if isinstance(value, dict):
            for v in value.values(): visit(v)
        elif isinstance(value, (list, tuple)):
            for v in value: visit(v)
        elif isinstance(value, (str, Path)):
            try:
                p = Path(value)
                if len(str(value)) < 512 and p.is_absolute() and p.is_file():
                    s = p.stat(); assets[str(p.resolve())] = (s.st_size, s.st_mtime_ns)
            except (OSError, ValueError): pass
    visit(timeline)
    runtime = Path(runtime)
    for folder in ('Icons', 'Sound Effects', 'Transitions', 'Visual Effects', 'static/fonts'):
        for p in (runtime/folder).rglob('*'):
            if p.is_file(): visit(p)
    for name in ('app.py', 'render_video.py', 'premiere_export.py', 'caption_layer.py',
                 'project_canvas.py', 'subtitle_ost.py', 'media_delivery.py', 'icon_geometry.py',
                 'effect_timing.py', 'ost_rich.py', 'static/ost-rich.js', 'static/style.css'):
        visit(runtime/name)
    clean = {k:v for k,v in doc.items() if k not in VOLATILE}
    opts = {k:v for k,v in options.items() if not k.startswith('_') and k not in ('gpu','low_priority')}
    # Saved caption edits/visibility and authoritative source timings can change
    # the derived timeline without rewriting scenes.json or a media file.
    semantic_timeline = {k:v for k,v in timeline.items() if k not in ('music_revision',)}
    payload = (VERSION, clean, semantic_timeline, assets, opts)
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()

def cached(directory, token):
    d = Path(directory)/'export'
    try:
        p = d/filename(token)
        meta = json.loads(p.with_suffix('.json').read_text('utf8'))
        if meta.get('fingerprint') != token or not p.is_file(): return None
        s = p.stat()
        if not s.st_size or s.st_size != meta.get('size') or s.st_mtime_ns != meta.get('mtime_ns'): return None
        return {'file':'export/'+p.name, 'fingerprint':token, 'cached':True}
    except (OSError, ValueError, TypeError): return None

def commit(path, token):
    p = Path(path); s = p.stat()
    data = {'fingerprint':token, 'size':s.st_size, 'mtime_ns':s.st_mtime_ns, 'version':VERSION}
    dest = p.with_suffix('.json'); tmp = dest.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(data, sort_keys=True), 'utf8'); os.replace(tmp, dest)
    # Retain three owned, complete previews; never touch delivered renders or
    # a still-open movie if Windows refuses deletion.
    owned=[]
    for meta in p.parent.glob('preview_*.json'):
        try:
            record=json.loads(meta.read_text('utf8'))
            if record.get('version')==VERSION and meta.with_suffix('.mp4').name==filename(record.get('fingerprint')):
                owned.append(meta)
        except (OSError,ValueError):pass
    for meta in sorted(owned,key=lambda x:x.stat().st_mtime_ns,reverse=True)[3:]:
        try: meta.with_suffix('.mp4').unlink(missing_ok=True);meta.unlink(missing_ok=True)
        except OSError:pass

def filename(token):
    return 'preview_' + hashlib.sha256(str(token).encode()).hexdigest()[:24] + '.mp4'
