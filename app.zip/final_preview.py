"""Content-addressed previews encoded by the final renderer, never by a second compositor."""
from pathlib import Path
import hashlib
import json
import os
from copy import deepcopy

VERSION = 'final-preview-1000-1'
VOLATILE = frozenset(('_revision', 'history', 'undo_history', 'redo_history',
    'preview_built', 'generation_completed', 'updated_at', 'modified_at', 'last_opened'))

LIVE_VERSION = 'live-overlay-base-1036-effects-30fps'

def base_projection(timeline, options=None):
    """Picture-only editing base; the original timeline remains the delivery truth."""
    import premiere_export as pe
    from editorial_policy import delivery_sfx
    base = deepcopy(timeline)
    # Quantize absolute picture boundaries, never sum rounded durations.
    # The editor, XML, overlays and source audio retain their original clocks.
    # At 30 fps the picture cut differs by at most half a display frame.
    fps = 30
    grid = lambda t: int(float(t)*fps+.5+1e-7)/fps
    for scene in base.get('scenes', []):
        scene['start'] = grid(scene['start'])
        scene['end'] = grid(scene['end'])
    base['total'] = __import__('math').ceil(float(base['total'])*fps-1e-7)/fps
    base['sfx'] = delivery_sfx(base.get('sfx'),options)
    base.update(captions=[], sub_style=None, ost_plates=[], visuals=[])
    for name in ('music_catalog', 'music_revision', 'media_notes', 'words_remapped',
                 '_dip_windows', '_user_transition_events', 'film_dust'):
        base.pop(name, None)
    for scene in base.get('scenes', []):
        scene.update(texts=[], icons=[])
        # These layers now follow the decoded movie clock in the editor. Their
        # timing, deletion and opacity must never change the picture cache key.
        for name in ('effect_windows', 'fx_on', 'grain_on', 'grain', 'atmo'):
            scene.pop(name, None)
        for name in ('label', 'img', 'narration', 'narration_origin', 'sfx', 'sfx_in', 'sfx_events', 'sfx_suppressed', 'ost_matte_policy'):
            scene.pop(name, None)
        if scene.get('transition') in pe._UTX or scene.get('transition') in ('dip-black', 'dip-white'):
            scene['transition'] = 'none'
    # Keep the resolved camera fields. Removing overlays must not recompute the
    # framing or move already selected by the authoritative scene timeline.
    return base

def base_options(options):
    return {**dict(options or {}), 'burnsubs': False, 'onscreentext': False, 'crossfade': True,
            '_live_overlay_base': True, 'final_preview': True, 'fast': False, 'preview_fps': 30}

def fingerprints(timeline, options, runtime):
    import preview_chunks as chunks
    base, opts = base_projection(timeline, options), base_options(options)
    cores = chunks.plan(base, opts)
    video = chunks.digest((LIVE_VERSION, [(c['start_frame'], c['end_frame'],
        chunks.video_key(c, opts, runtime)) for c in cores]))
    audio = chunks.audio_key(base, opts, runtime)
    return dict(base_fingerprint=chunks.digest((LIVE_VERSION, video, audio)),
                video_fingerprint=video, audio_fingerprint=audio)

def signature(doc, timeline, options, runtime):
    if options.get('live_overlays'):
        return fingerprints(timeline, options, runtime)['base_fingerprint']
    assets = {}
    def visit(value):
        if isinstance(value, dict):
            for v in value.values(): visit(v)
        elif isinstance(value, (list, tuple)):
            for v in value: visit(v)
        elif isinstance(value, (str, Path)):
            try:
                p = Path(value)
                if len(str(value)) < 512 and p.is_absolute() and p.is_file():
                    s = p.stat(); assets[str(p.resolve())] = (s.st_size, s.st_mtime_ns)
            except (OSError, ValueError): pass
    visit(timeline)
    runtime = Path(runtime)
    for folder in ('Icons', 'Sound Effects', 'Transitions', 'Visual Effects', 'static/fonts'):
        for p in (runtime/folder).rglob('*'):
            if p.is_file(): visit(p)
    for name in ('app.py', 'render_video.py', 'premiere_export.py', 'caption_layer.py',
                 'project_canvas.py', 'subtitle_ost.py', 'media_delivery.py', 'icon_geometry.py',
                 'effect_timing.py', 'icon_motion.py', 'preview_chunks.py', 'final_preview.py',
                 'ost_rich.py', 'static/ost-rich.js', 'static/style.css'):
        visit(runtime/name)
    clean = {k:v for k,v in doc.items() if k not in VOLATILE}
    opts = {k:v for k,v in options.items() if not k.startswith('_') and k not in ('gpu','low_priority')}
    # Saved caption edits/visibility and authoritative source timings can change
    # the derived timeline without rewriting scenes.json or a media file.
    semantic_timeline = {k:v for k,v in timeline.items() if k not in ('music_revision',)}
    payload = (VERSION, clean, semantic_timeline, assets, opts)
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()

def cached(directory, token):
    d = Path(directory)/'export'
    try:
        p = d/filename(token)
        meta = json.loads(p.with_suffix('.json').read_text('utf8'))
        if meta.get('fingerprint') != token or not p.is_file(): return None
        s = p.stat()
        if not s.st_size or s.st_size != meta.get('size') or s.st_mtime_ns != meta.get('mtime_ns'): return None
        return {'file':'export/'+p.name, 'fingerprint':token, 'cached':True}
    except (OSError, ValueError, TypeError): return None

def commit(path, token):
    p = Path(path); s = p.stat()
    data = {'fingerprint':token, 'size':s.st_size, 'mtime_ns':s.st_mtime_ns, 'version':VERSION}
    dest = p.with_suffix('.json'); tmp = dest.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(data, sort_keys=True), 'utf8'); os.replace(tmp, dest)
    # Retain three owned, complete previews; never touch delivered renders or
    # a still-open movie if Windows refuses deletion.
    owned=[]
    for meta in p.parent.glob('preview_*.json'):
        try:
            record=json.loads(meta.read_text('utf8'))
            if record.get('version')==VERSION and meta.with_suffix('.mp4').name==filename(record.get('fingerprint')):
                owned.append(meta)
        except (OSError,ValueError):pass
    for meta in sorted(owned,key=lambda x:x.stat().st_mtime_ns,reverse=True)[3:]:
        try: meta.with_suffix('.mp4').unlink(missing_ok=True);meta.unlink(missing_ok=True)
        except OSError:pass

def filename(token):
    return 'preview_' + hashlib.sha256(str(token).encode()).hexdigest()[:24] + '.mp4'

def render(timeline, out_path, workdir, opts=None, progress=None, on_proc=None, on_status=None, should_cancel=None):
    import preview_chunks
    if (opts or {}).get('live_overlays'):
        timeline, opts = base_projection(timeline, opts), base_options(opts)
    return preview_chunks.render(timeline, out_path, workdir, opts, progress, on_proc, on_status, should_cancel)
