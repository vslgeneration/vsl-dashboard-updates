"""Depth-based 2.5D parallax for still scenes.

A Ken-Burns zoom scales the picture as one flat plane, and the eye reads that as a photograph. Real
parallax needs to know what is NEAR and what is FAR, so this runs a depth model (Depth Anything V2
small, ONNX, on the CPU) over the still and then warps it per frame: near pixels swing further than
far ones. On the 2D artwork this channel uses the model separates a figure from its background
cleanly, which is exactly what the effect needs.

Everything the camera does to a still happens in ONE resample here - the zoom, the handheld float and
the parallax - so the picture is interpolated once instead of three times.

No model file, no OpenCV, or no onnxruntime -> `available()` is False and the caller keeps the old
flat Ken-Burns path. This is an enhancement, never a dependency.
"""
import hashlib
import json
import math
import os
import subprocess
from pathlib import Path

import numpy as np

MODEL = Path(__file__).resolve().parent / "models" / "depth_anything_v2_small.onnx"
_MEAN = np.array([0.485, 0.456, 0.406], np.float32)
_STD = np.array([0.229, 0.224, 0.225], np.float32)
_SIDE = 518                      # the model's native square input

# How far the nearest pixels swing against the farthest, in px at 1080p. Big enough to read as depth,
# small enough that the stretched edges it leaves behind never become visible.
PARALLAX_PX = 34.0
PARALLAX_HZ = (0.050, 0.037)     # horizontal / vertical arcs, deliberately not multiples of each other
BASE_ZOOM = 1.025                # the still is always slightly in, so the warp has somewhere to sample
PUSH_RANGE = 0.055               # how much a push-in or pull-out travels
FLOAT_AMP = (2.6, 1.5)
FLOAT_HZ = (0.13, 0.31)

_SESS = None


def available():
    if not MODEL.exists():
        return False
    try:
        import cv2, onnxruntime           # noqa: F401
    except Exception:
        return False
    return True


def _session():
    global _SESS
    if _SESS is None:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, (os.cpu_count() or 4) // 2)
        _SESS = ort.InferenceSession(str(MODEL), so, providers=["CPUExecutionProvider"])
    return _SESS


def depth_map(img_bgr, cache=None, key=None):
    """Near=1, far=0, float32, same size as the picture. Cached as a PNG when a cache dir is given."""
    import cv2
    h, w = img_bgr.shape[:2]
    cp = (Path(cache) / f"_depth_{key}.png") if (cache and key) else None
    if cp and cp.exists():
        d = cv2.imread(str(cp), cv2.IMREAD_GRAYSCALE)
        if d is not None and d.shape == (h, w):
            return d.astype(np.float32) / 255.0
    rgb = cv2.cvtColor(cv2.resize(img_bgr, (_SIDE, _SIDE), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
    x = ((rgb.astype(np.float32) / 255.0 - _MEAN) / _STD).transpose(2, 0, 1)[None]
    d = _session().run(None, {"pixel_values": x})[0][0].astype(np.float32)
    d = (d - d.min()) / max(1e-6, float(d.max() - d.min()))
    d = cv2.resize(d, (w, h), interpolation=cv2.INTER_CUBIC)
    # A hard depth edge tears the warp; softening it trades a little separation for clean edges.
    d = cv2.GaussianBlur(d, (0, 0), max(2.0, w / 220.0))
    d = np.clip(d, 0.0, 1.0)
    if cp:
        try:
            cv2.imwrite(str(cp), (d * 255).astype(np.uint8))
        except Exception:
            pass
    return d


def _cover(img_bgr, w, h):
    """Fill the frame, crop the overflow - the same COVER the flat path uses."""
    import cv2
    ih, iw = img_bgr.shape[:2]
    s = max(w / iw, h / ih)
    nw, nh = int(math.ceil(iw * s)), int(math.ceil(ih * s))
    r = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
    x0, y0 = (nw - w) // 2, (nh - h) // 2
    return r[y0:y0 + h, x0:x0 + w]


def clip_key(src, dur, move, seed, w, h, fps):
    st = Path(src).stat()
    payload = [str(src), int(st.st_size), int(st.st_mtime), round(float(dur), 3), move, int(seed),
               w, h, fps, PARALLAX_PX, BASE_ZOOM, PUSH_RANGE, 2]
    return hashlib.md5(json.dumps(payload).encode()).hexdigest()[:16]


def build_clip(src, out, dur, fps, w, h, move="hold", seed=0, cache=None, ffmpeg="ffmpeg"):
    """Write a clip of the still with the camera baked in. Returns the path, or None if it could not."""
    import cv2
    out = Path(out)
    if out.exists() and out.stat().st_size > 1000:
        return out
    img = cv2.imread(str(src), cv2.IMREAD_COLOR)
    if img is None:
        return None
    base = _cover(img, w, h)
    d = depth_map(base, cache=cache, key=clip_key(src, 0, "d", 0, w, h, fps))
    d = (d - 0.5).astype(np.float32)              # -0.5 far .. +0.5 near
    n = max(2, int(round(float(dur) * fps)))
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    rng = np.random.default_rng(seed)
    ph = rng.random(4) * 6.283
    cmd = [ffmpeg, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
           "-s", f"{w}x{h}", "-r", str(fps), "-i", "-",
           "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "13",
           "-pix_fmt", "yuv420p", str(out)]
    creation = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=creation)
    try:
        for i in range(n):
            u = i / (n - 1)
            t = i / float(fps)
            if move == "push":
                z = BASE_ZOOM + PUSH_RANGE * u
            elif move == "pull":
                z = BASE_ZOOM + PUSH_RANGE * (1.0 - u)
            else:                                  # hold - the camera stays put and only breathes
                z = BASE_ZOOM + PUSH_RANGE * 0.35
            hx = hy = 0.0
            if move == "hold":                     # a locked-off shot is the one that needs the float
                a1, a2 = FLOAT_AMP
                f1, f2 = FLOAT_HZ
                hx = a1 * math.sin(2 * math.pi * f1 * t + ph[0]) + a2 * math.sin(2 * math.pi * f2 * t + ph[1])
                hy = a1 * math.sin(2 * math.pi * f2 * t + ph[1]) + a2 * math.sin(2 * math.pi * f1 * t + ph[0])
            px = PARALLAX_PX * math.sin(2 * math.pi * PARALLAX_HZ[0] * t + ph[2])
            py = PARALLAX_PX * 0.35 * math.sin(2 * math.pi * PARALLAX_HZ[1] * t + ph[3])
            mx = cx + (xs - cx) / z + px * d + hx
            my = cy + (ys - cy) / z + py * d + hy
            frame = cv2.remap(base, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            p.stdin.write(frame.tobytes())
    finally:
        try:
            p.stdin.close()
        except Exception:
            pass
        p.wait(timeout=300)
    return out if out.exists() and out.stat().st_size > 1000 else None
