"""Depth-based 2.5D parallax for still scenes.

A Ken-Burns zoom scales the picture as one flat plane, and the eye reads that as a photograph. Real
parallax needs to know what is NEAR and what is FAR, so this runs a depth model (Depth Anything V2
small, ONNX, on the CPU) over the still and then warps it per frame: near pixels swing further than
far ones. On the 2D artwork this channel uses the model separates a figure from its background
cleanly, which is exactly what the effect needs.

Everything the camera does to a still happens in ONE resample here - the zoom, the handheld float and
the parallax - so the picture is interpolated once instead of three times.

No model file, no OpenCV, or no onnxruntime -> `available()` is False and the caller keeps the old
flat Ken-Burns path. This is an enhancement, never a dependency.
"""
import hashlib
import json
import threading
import time
import math
import os
import subprocess
from pathlib import Path

import numpy as np

MODEL = Path(__file__).resolve().parent / "models" / "depth_anything_v2_small.onnx"
# The model is 99 MB, which is too big to push through the update channel, so the app fetches it once
# and keeps it. Downloaded to a .part file and only renamed once the SHA-256 matches - a half-written
# or a swapped file must never be loaded as a model.
MODEL_URL = "https://huggingface.co/onnx-community/depth-anything-v2-small/resolve/main/onnx/model.onnx"
MODEL_SHA = "afb6a5c28f3b6bf1618c6e43f02073ef9dfdc70e937502d51603e57b0a1df10c"
MODEL_BYTES = 99060839
_MEAN = np.array([0.485, 0.456, 0.406], np.float32)
_STD = np.array([0.229, 0.224, 0.225], np.float32)
_SIDE = 518                      # the model's native square input

# How far the nearest pixels swing against the farthest, in px at 1080p. Big enough to read as depth,
# small enough that the stretched edges it leaves behind never become visible.
PARALLAX_PX = 34.0
PARALLAX_HZ = (0.050, 0.037)     # horizontal / vertical arcs, deliberately not multiples of each other
# The zoom is what gives the depth warp somewhere to sample from. At 1.025 the margin was 24px against
# a parallax that reaches 17px plus the drift, so the near layer kept running off the edge and
# BORDER_REPLICATE smeared the last column across - which on flat cartoon linework reads as the picture
# breaking up rather than moving. The floor now covers the full displacement with room to spare.
BASE_ZOOM = 1.06                 # >= PARALLAX_PX/2 / (1920/2) with headroom
PUSH_RANGE = 0.055               # how much a push-in or pull-out travels
HOLD_RANGE = 0.018               # a "hold" is a very slow push, never a locked frame

_SESS = None


_DL = {"state": "idle", "pct": 0, "error": "", "started": 0.0}
_DL_LOCK = threading.Lock()


def have_model():
    try:
        return MODEL.exists() and MODEL.stat().st_size == MODEL_BYTES
    except OSError:
        return False


def runnable():
    """The libraries are here. Says nothing about the model file."""
    try:
        import cv2, onnxruntime           # noqa: F401
    except Exception:
        return False
    return True


def available():
    return have_model() and runnable()


def download_state():
    with _DL_LOCK:
        return dict(_DL)


def _download(progress=None):
    import urllib.request
    tmp = MODEL.with_suffix(".part")
    MODEL.parent.mkdir(parents=True, exist_ok=True)
    try:
        req = urllib.request.Request(MODEL_URL, headers={"User-Agent": "VSLDashboard"})
        with urllib.request.urlopen(req, timeout=60) as r:
            total = int(r.headers.get("Content-Length") or MODEL_BYTES)
            done = 0
            h = hashlib.sha256()
            with open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b); h.update(b); done += len(b)
                    pct = int(done * 100 / max(1, total))
                    with _DL_LOCK:
                        _DL["pct"] = pct
                    if progress:
                        progress(pct)
        if h.hexdigest() != MODEL_SHA:
            tmp.unlink(missing_ok=True)
            raise RuntimeError("the downloaded model did not match its checksum")
        os.replace(tmp, MODEL)
        with _DL_LOCK:
            _DL.update(state="ready", pct=100, error="")
        return True
    except Exception as e:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        with _DL_LOCK:
            _DL.update(state="error", error=str(e)[:200])
        return False


def ensure_model(progress=None, wait=True):
    """True once the model is on disk. wait=False just starts the fetch and returns.

    Depth is an ENHANCEMENT: every caller falls back to the flat Ken-Burns path when this returns
    False, so no failure here can stop a render."""
    if have_model():
        return True
    if not runnable():
        return False
    with _DL_LOCK:
        busy = _DL["state"] == "downloading"
        if not busy:
            _DL.update(state="downloading", pct=0, error="", started=time.time())
    if busy:
        if not wait:
            return False
        for _ in range(1800):                      # someone else is fetching it; sit with them
            time.sleep(1)
            if have_model():
                return True
            if download_state()["state"] == "error":
                return False
        return False
    if not wait:
        threading.Thread(target=_download, daemon=True).start()
        return False
    return _download(progress)


def prefetch():
    """Fire and forget - called when a YouTube project is opened, so the first render does not wait."""
    if have_model() or not runnable():
        return
    if download_state()["state"] == "downloading":
        return
    threading.Thread(target=lambda: ensure_model(wait=True), daemon=True).start()


def _session():
    global _SESS
    if _SESS is None:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, (os.cpu_count() or 4) // 2)
        _SESS = ort.InferenceSession(str(MODEL), so, providers=["CPUExecutionProvider"])
    return _SESS


def depth_map(img_bgr, cache=None, key=None):
    """Near=1, far=0, float32, same size as the picture. Cached as a PNG when a cache dir is given."""
    import cv2
    h, w = img_bgr.shape[:2]
    cp = (Path(cache) / f"_depth_{key}.png") if (cache and key) else None
    if cp and cp.exists():
        d = cv2.imread(str(cp), cv2.IMREAD_GRAYSCALE)
        if d is not None and d.shape == (h, w):
            return d.astype(np.float32) / 255.0
    rgb = cv2.cvtColor(cv2.resize(img_bgr, (_SIDE, _SIDE), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
    x = ((rgb.astype(np.float32) / 255.0 - _MEAN) / _STD).transpose(2, 0, 1)[None]
    d = _session().run(None, {"pixel_values": x})[0][0].astype(np.float32)
    d = (d - d.min()) / max(1e-6, float(d.max() - d.min()))
    d = cv2.resize(d, (w, h), interpolation=cv2.INTER_CUBIC)
    # A hard depth edge tears the warp; softening it trades a little separation for clean edges.
    d = cv2.GaussianBlur(d, (0, 0), max(2.0, w / 220.0))
    d = np.clip(d, 0.0, 1.0)
    if cp:
        try:
            cv2.imwrite(str(cp), (d * 255).astype(np.uint8))
        except Exception:
            pass
    return d


def _cover(img_bgr, w, h):
    """Fill the frame, crop the overflow - the same COVER the flat path uses."""
    import cv2
    ih, iw = img_bgr.shape[:2]
    s = max(w / iw, h / ih)
    nw, nh = int(math.ceil(iw * s)), int(math.ceil(ih * s))
    r = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
    x0, y0 = (nw - w) // 2, (nh - h) // 2
    return r[y0:y0 + h, x0:x0 + w]


def clip_key(src, dur, move, seed, w, h, fps):
    st = Path(src).stat()
    payload = [str(src), int(st.st_size), int(st.st_mtime), round(float(dur), 3), move, int(seed),
               w, h, fps, PARALLAX_PX, BASE_ZOOM, PUSH_RANGE, 2]
    return hashlib.md5(json.dumps(payload).encode()).hexdigest()[:16]


def build_clip(src, out, dur, fps, w, h, move="hold", seed=0, cache=None, ffmpeg="ffmpeg"):
    """Write a clip of the still with the camera baked in. Returns the path, or None if it could not."""
    import cv2
    out = Path(out)
    if out.exists() and out.stat().st_size > 1000:
        return out
    img = cv2.imread(str(src), cv2.IMREAD_COLOR)
    if img is None:
        return None
    base = _cover(img, w, h)
    d = depth_map(base, cache=cache, key=clip_key(src, 0, "d", 0, w, h, fps))
    d = (d - 0.5).astype(np.float32)              # -0.5 far .. +0.5 near
    n = max(2, int(round(float(dur) * fps)))
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    rng = np.random.default_rng(seed)
    ph = rng.random(4) * 6.283
    # which way this shot's depth slides; neighbouring scenes get different seeds, so the direction
    # changes from shot to shot instead of the whole video drifting one way
    dir_x = 1.0 if rng.random() < 0.5 else -1.0
    dir_y = 1.0 if rng.random() < 0.5 else -1.0
    cmd = [ffmpeg, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
           "-s", f"{w}x{h}", "-r", str(fps), "-i", "-",
           "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "13",
           "-pix_fmt", "yuv420p", str(out)]
    creation = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=creation)
    try:
        for i in range(n):
            u = i / (n - 1)
            t = i / float(fps)
            # No handheld. A drawn frame has no camera to shake, and a few pixels of wobble on flat
            # linework reads as the drawing trembling rather than as a camera. Every shot is a zoom -
            # in, out, or barely - and the depth drift supplies the life.
            if move == "pull":
                z = BASE_ZOOM + PUSH_RANGE * (1.0 - u)   # starts wide enough to have somewhere to go
            elif move == "hold":
                z = BASE_ZOOM + HOLD_RANGE * u           # so slow it reads as still, but never frozen
            else:
                z = BASE_ZOOM + PUSH_RANGE * u
            hx = hy = 0.0
            # The drift used to be a 20-second sine sampled at a random phase, so a four-second shot
            # covered a fifth of a cycle - and a shot that happened to start near the peak barely moved
            # at all. That is why the depth was invisible on short scenes and visible on long ones.
            # Now it travels the SAME distance across every shot, whatever its length: from one side of
            # the arc to the other, with the direction varying per scene so consecutive shots do not
            # all slide the same way.
            sway = (u - 0.5) * 2.0                          # -1 at the start .. +1 at the end
            px = PARALLAX_PX * sway * dir_x
            py = PARALLAX_PX * 0.35 * sway * dir_y
            mx = cx + (xs - cx) / z + px * d + hx
            my = cy + (ys - cy) / z + py * d + hy
            frame = cv2.remap(base, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            p.stdin.write(frame.tobytes())
    finally:
        try:
            p.stdin.close()
        except Exception:
            pass
        p.wait(timeout=300)
    return out if out.exists() and out.stat().st_size > 1000 else None
