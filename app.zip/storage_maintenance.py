"""Conservative, reversible maintenance of derived render cache only.

Scene media, approved output, render history and cloud objects are never selected.
Quarantine offers 30 days to restore derived cache. Only still-unreferenced cache
is purged after that grace period. Callers must exclude concurrent cache writers.
"""
import json
import os
from pathlib import Path
import stat
import time
import uuid

def _plain(path):
    st = path.lstat()
    return not stat.S_ISLNK(st.st_mode) and not (getattr(st, 'st_file_attributes', 0) & 0x400)

def _within(root, path):
    root, path = Path(root).absolute(), Path(path).absolute()
    if '..' in path.parts: raise ValueError('Parent traversal is not supported')
    if path == root or not path.is_relative_to(root):
        raise ValueError('Maintenance path must stay inside its project')
    for part in [root] + list(reversed(path.parents[:len(path.parts)-len(root.parts)-1])) + [path]:
        if part.exists() or part.is_symlink():
            if not _plain(part): raise ValueError('Linked maintenance paths are not supported')
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Maintenance path escapes its project')
    return path

def _files(root):
    if not root.exists(): return
    if not _plain(root): raise ValueError('Linked folder in maintenance scope')
    with os.scandir(root) as entries:
        for entry in entries:
            p = Path(entry.path)
            if not _plain(p): raise ValueError('Linked file or folder in maintenance scope')
            if entry.is_dir(follow_symlinks=False): yield from _files(p)
            elif entry.is_file(follow_symlinks=False): yield p

def _strings(value):
    if isinstance(value, str): yield value
    elif isinstance(value, dict):
        for item in value.values(): yield from _strings(item)
    elif isinstance(value, (list, tuple)):
        for item in value: yield from _strings(item)
    elif isinstance(value, Path): yield str(value)

def _fold(value): return str(value).replace('\\', '/').casefold()

def _references(project, protect=()):
    refs = {_fold(s) for s in _strings(protect)}
    for path in _files(project):
        if '_cache_quarantine' in path.relative_to(project).parts: continue
        if path.name.endswith(('.json', '.json.bak')):
            if path.stat().st_size > 64*1024**2: raise ValueError('Metadata too large to verify')
            refs.update(_fold(s) for s in _strings(json.loads(path.read_text(encoding='utf-8-sig'))))
    return refs

def cache_plan(project, cap=3*1024**3, min_age=7*86400, protect=()):
    project = Path(project).absolute()
    cache = _within(project, project/'export/_render_tmp')
    try:
        # Read primary and backup metadata. Any unreadable metadata makes the
        # whole plan non-actionable, rather than guessing that its files are unused.
        refs = _references(project, protect)
        rows=[]
        for path in _files(cache):
            st=path.stat()
            rel=path.relative_to(project).as_posix()
            used = any(v in refs for v in (_fold(rel), _fold(path), _fold(path.name)))
            rows.append(dict(file=rel, bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                             inode=st.st_ino, eligible=not used and time.time()-st.st_mtime >= min_age))
        total=sum(r['bytes'] for r in rows)
        remaining=total; candidates=[]
        for row in sorted(rows, key=lambda r:(r['mtime_ns'],r['file'])):
            if remaining <= cap: break
            if row['eligible']:
                candidates.append(row); remaining-=row['bytes']
        return dict(cache_bytes=total, candidates=candidates, blocked=None)
    except (OSError, ValueError) as e:
        return dict(cache_bytes=None, candidates=[], blocked=str(e))

def cache_report(project):
    """Read local cache and recovery records only; never move files or query providers."""
    project = Path(project).absolute()
    report = cache_plan(project)
    report.update(candidate_bytes=sum(r['bytes'] for r in report['candidates']),
                  quarantine_bytes=0, batches=[], quarantine_warning=None, grace_days=30)
    try:
        area = _within(project, project/'export/_cache_quarantine')
        report['quarantine_bytes'] = sum(p.stat().st_size for p in _files(area) if p.suffix == '.cache')
        if not area.exists(): return report
        for folder in area.iterdir():
            _within(project, folder)
            if not folder.is_dir() or len(folder.name) != 32 or any(c not in '0123456789abcdef' for c in folder.name):
                continue
            row = dict(batch=folder.name, created=None, eligible_after=None,
                       files=0, bytes=0, restorable=0, blocked=None)
            try:
                journal = _within(project, folder/'manifest.json')
                if journal.stat().st_size > 64*1024**2: raise ValueError('Recovery record is too large')
                manifest = json.loads(journal.read_text(encoding='utf-8'))
                created = manifest['created']
                if manifest.get('version') != 1 or not isinstance(created, (int, float)) or not 0 < created <= time.time():
                    raise ValueError('Invalid recovery record')
                row.update(created=created, eligible_after=created + 30*86400)
                seen = set()
                for entry in manifest['entries']:
                    stored = _within(project, folder/entry['stored'])
                    original = _within(project, project/entry['source'])
                    if stored.parent != folder or stored.suffix != '.cache' or not original.is_relative_to(project/'export/_render_tmp'):
                        raise ValueError('Invalid recovery entry')
                    if stored in seen: raise ValueError('Duplicate recovery entry')
                    seen.add(stored)
                    if not stored.exists(): continue
                    st = stored.stat()
                    row['files'] += 1; row['bytes'] += st.st_size
                    if not original.exists() and st.st_size == entry['bytes'] and st.st_mtime_ns == entry['mtime_ns']:
                        row['restorable'] += 1
            except (OSError, ValueError, TypeError, KeyError) as e:
                row.update(blocked=str(e), restorable=0)
            if row['files'] or row['blocked']: report['batches'].append(row)
        report['batches'].sort(key=lambda r:r['created'] or 0, reverse=True)
    except (OSError, ValueError, TypeError, KeyError) as e:
        report.update(quarantine_bytes=None, quarantine_warning=str(e))
    return report


def _journal(path, data):
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('x',encoding='utf-8') as f:
            json.dump(data,f); f.flush(); os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp.exists(): temp.unlink()

def quarantine_cache(project, cap=3*1024**3, min_age=7*86400, protect=()):
    project=Path(project).absolute()
    plan=cache_plan(project,cap,min_age,protect)
    result=dict(moved_bytes=0, moved_files=0, reclaimed_bytes=0, batch=None, blocked=plan['blocked'])
    if not plan['candidates']: return result
    batch=uuid.uuid4().hex
    folder=_within(project,project/'export/_cache_quarantine'/batch)
    folder.mkdir(parents=True,exist_ok=False)
    manifest=dict(version=1,created=time.time(),entries=[])
    journal=folder/'manifest.json'
    _journal(journal,manifest)
    result['batch']=batch
    for row in plan['candidates']:
        source=_within(project, project/row['file'])
        try:
            st=source.stat()
            if (st.st_size,st.st_mtime_ns,st.st_ino)!=(row['bytes'],row['mtime_ns'],row['inode']): continue
            target=folder/(uuid.uuid4().hex+'.cache')
            entry=dict(source=row['file'],stored=target.name,bytes=st.st_size,mtime_ns=st.st_mtime_ns)
            manifest['entries'].append(entry)
            # Durable intent before moving. Recovery works even if the process
            # stops immediately after rename; no post-move journal is required.
            _journal(journal,manifest)
            os.rename(source,target)
            result['moved_bytes']+=st.st_size; result['moved_files']+=1
        except OSError:
            # Readers can hold a file open on Windows. Leave it in place.
            continue
    return result

def restore_cache(project,batch):
    project=Path(project).absolute()
    if len(batch)!=32 or any(c not in '0123456789abcdef' for c in batch): raise ValueError('Invalid batch')
    folder=_within(project,project/'export/_cache_quarantine'/batch)
    journal=_within(project,folder/'manifest.json')
    manifest=json.loads(journal.read_text(encoding='utf-8'))
    result=dict(restored=0,kept=0)
    for entry in manifest['entries']:
        source=_within(project,folder/entry['stored'])
        target=_within(project,project/entry['source'])
        if source.parent!=folder or not target.is_relative_to(project/'export/_render_tmp'):
            raise ValueError('Invalid restore entry')
        if not source.exists(): continue
        st=source.stat()
        if target.exists() or st.st_size!=entry['bytes'] or st.st_mtime_ns!=entry['mtime_ns']:
            result['kept']+=1; continue
        target.parent.mkdir(parents=True,exist_ok=True)
        try:
            # Exclusive link never replaces a cache file regenerated meanwhile.
            os.link(source,target)
            source.unlink()
            result['restored']+=1
        except OSError:
            result['kept']+=1
    return result

def purge_expired_cache(project, protect=(), grace=30*86400):
    """Delete only unchanged, unreferenced cache that completed its recovery period."""
    project=Path(project).absolute()
    area=_within(project,project/'export/_cache_quarantine')
    if not area.exists(): return 0
    refs=_references(project,protect)  # fail closed before the first delete
    freed=0
    for folder in area.iterdir():
        _within(project,folder)
        if not folder.is_dir() or len(folder.name)!=32 or any(c not in '0123456789abcdef' for c in folder.name): continue
        try:
            manifest=json.loads(_within(project,folder/'manifest.json').read_text(encoding='utf-8'))
            created=manifest['created']
            if manifest.get('version')!=1 or not isinstance(created,(float,int)) or not 0<created<=time.time()-grace: continue
            for entry in manifest['entries']:
                source=_within(project,folder/entry['stored'])
                original=_within(project,project/entry['source'])
                if source.parent!=folder or source.suffix!='.cache' or not original.is_relative_to(project/'export/_render_tmp'): continue
                if not source.exists(): continue
                spellings=(entry['source'],str(original),original.name,str(source),source.relative_to(project).as_posix(),source.name)
                if any(_fold(v) in refs for v in spellings): continue
                st=source.stat()
                if st.st_size!=entry['bytes'] or st.st_mtime_ns!=entry['mtime_ns']: continue
                source.unlink(); freed+=st.st_size
        except (OSError,ValueError,TypeError,KeyError):
            continue
    return freed
