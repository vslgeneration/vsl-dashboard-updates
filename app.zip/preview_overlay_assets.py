"""Native-canvas foreground contract for the cached Assemble picture.

The exporter/renderer own placement, artwork and keyframes. This module only
serializes those decisions and prepares immutable browser media, independently
of an overlay's position, wording or timeline window.
"""
from pathlib import Path
import copy
import hashlib
import json
import math
import os
import shutil
import subprocess
import threading
import time
import uuid

import caption_layer
import icon_motion
import ost_rich
import premiere_export as pe
import project_canvas
import render_video

VERSION = 1
FPS = 60
_ENCODER = threading.BoundedSemaphore(1)
_LOCKS = [threading.RLock() for _ in range(32)]
_FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)


def _check(options):
    cancel = options.get('_should_cancel')
    if callable(cancel) and cancel():
        raise RuntimeError('Preview preparation cancelled.')


def _status(options, message):
    callback = options.get('_on_status')
    if callable(callback): callback(message)


def _run(command, options, timeout=300):
    """One bounded encoder, cancellable even while waiting for another request."""
    while not _ENCODER.acquire(timeout=.2): _check(options)
    proc = None
    try:
        _check(options)
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                creationflags=_FLAGS)
        deadline = time.monotonic() + timeout
        while True:
            _check(options)
            try:
                _, error = proc.communicate(timeout=.2)
                break
            except subprocess.TimeoutExpired:
                if time.monotonic() > deadline:
                    raise RuntimeError('Preview overlay preparation timed out.')
        if proc.returncode:
            raise RuntimeError('A preview overlay could not be prepared: ' + error.decode('utf8', errors='replace')[-500:])
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill(); proc.communicate()
        _ENCODER.release()


def _stamp(source):
    stat = source.stat()
    return [str(source.resolve()).casefold(), stat.st_size, stat.st_mtime_ns]


def _probe(source):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format',
                             '-of', 'json', str(source)], capture_output=True, timeout=30,
                            creationflags=_FLAGS)
    if result.returncode: raise RuntimeError('A preview overlay source could not be read.')
    data = json.loads(result.stdout)
    video = next((s for s in data.get('streams', []) if s.get('codec_type') == 'video'), None)
    if not video: raise RuntimeError('A preview overlay has no video stream.')
    duration = float(video.get('duration') or data.get('format', {}).get('duration') or 0)
    if not math.isfinite(duration) or not 0 < duration <= 120:
        raise RuntimeError('A preview overlay has an unsupported duration.')
    if not 0 < int(video.get('width', 0)) <= 8192 or not 0 < int(video.get('height', 0)) <= 8192:
        raise RuntimeError('A preview overlay has unsupported dimensions.')
    return data, video, duration


def _asset(source, directory, options, alpha=None, frame_rate=FPS, tint=None):
    """Copy stills; convert source movies once. All returned paths are project-local."""
    source = Path(source).resolve()
    if not source.is_file(): raise RuntimeError('A preview overlay asset is missing.')
    stamp = _stamp(source)
    movie = alpha is not None
    extension = ('.webm' if alpha else '.mp4') if movie else source.suffix.lower()
    if not movie and extension not in ('.png', '.jpg', '.jpeg', '.webp'):
        raise RuntimeError('Unsupported preview overlay artwork.')
    key = hashlib.sha256(json.dumps([VERSION, stamp, alpha, frame_rate, tint], sort_keys=True).encode()).hexdigest()[:32]
    target, record = directory / (key + extension), directory / (key + '.json')
    lock = _LOCKS[int(key[:8], 16) % len(_LOCKS)]
    with lock:
        _check(options)
        try:
            saved = json.loads(record.read_text('utf8'))
            if saved.get('stamp') == stamp and saved.get('size', 0) == target.stat().st_size and target.stat().st_size > 0:
                return target, saved
        except (OSError, ValueError, TypeError): pass
        directory.mkdir(parents=True, exist_ok=True)
        part = directory / ('.' + uuid.uuid4().hex + extension)
        meta = dict(stamp=stamp, alpha=bool(alpha), fps=frame_rate, version=VERSION)
        try:
            if movie:
                _, stream, duration = _probe(source)
                _status(options, 'Preparing preview overlay…')
                filters = ('fps=60,' if frame_rate else '')+'setsar=1'
                if tint is not None:
                    hue = int(round(float(tint))); key_hue = hue if hue in (900,901) else hue % 360
                    r,g,b = pe._MOVFX_TINT.get(key_hue) or (255,255,255)
                    filters += f",format=rgba,geq=r='{r}':g='{g}':b='{b}':a='clip(0.7*(r(X\\,Y)+g(X\\,Y)+b(X\\,Y))\\,0\\,255)'"
                command = ['ffmpeg', '-nostdin', '-y', '-v', 'error', '-threads', '1',
                           '-filter_threads', '1', '-i', str(source), '-map', '0:v:0', '-an',
                           '-map_metadata', '-1', '-vf', filters, '-threads', '2']
                if frame_rate is None: command += ['-fps_mode', 'passthrough']
                if alpha:
                    command += ['-c:v', 'libvpx-vp9', '-lossless', '1', '-pix_fmt', 'yuva420p',
                                '-auto-alt-ref', '0', '-deadline', 'good', '-cpu-used', '4']
                else:
                    command += ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '12',
                                '-pix_fmt', 'yuv420p', '-movflags', '+faststart']
                command.append(str(part))
                _run(command, options)
                data, actual, converted_duration = _probe(part)
                if any(s.get('codec_type') == 'audio' for s in data.get('streams', [])):
                    raise RuntimeError('A preview overlay unexpectedly contains audio.')
                if abs(converted_duration - duration) > max(.05, 2/FPS):
                    raise RuntimeError('A preview overlay changed source timing.')
                if alpha and str(actual.get('tags', {}).get('alpha_mode')) != '1':
                    raise RuntimeError('A preview overlay lost its transparency.')
                meta.update(width=actual['width'], height=actual['height'], duration=converted_duration, source_duration=duration)
            else:
                shutil.copyfile(source, part)
                from PIL import Image
                with Image.open(part) as image: meta.update(width=image.width, height=image.height)
            _check(options)
            if _stamp(source) != stamp: raise RuntimeError('The preview overlay source changed while preparing it.')
            meta['size'] = part.stat().st_size
            os.replace(part, target)
            temp = record.with_name('.' + uuid.uuid4().hex + '.json')
            try:
                temp.write_text(json.dumps(meta), 'utf8'); os.replace(temp, record)
            finally: temp.unlink(missing_ok=True)
            return target, meta
        finally: part.unlink(missing_ok=True)


def _frames(item):
    out = copy.deepcopy(item)
    for field in ('start', 'end', 'peak', 'hold_until'):
        if field in out: out[field + '_frame'] = pe.frame_number(float(out[field]), FPS)
    return out


def _animation(item):
    """Resolve the exact frame counts sampled by caption_layer._caption_clip."""
    duration = min(caption_layer._MAX_CLIP_SEC, max(0., float(item['end']) - float(item['start'])))
    incoming, outgoing = item.get('anim') or 'fade', item.get('out_anim') or 'none'
    first, last = caption_layer._IN.get(incoming), caption_layer._OUT.get(outgoing)
    di, do = first[0] if first else 0., last[0] if last else 0.
    if item.get('kind') == 'ost':
        di = min(.65 if incoming == 'fade' else di, duration/2) if first else 0.
        do = min(do, duration/2) if last else 0.
    if di + do > duration:
        factor = duration / (di + do); di *= factor; do *= factor
    count = max(1, round(duration * FPS))
    ni = min(count, round(di * FPS)); no = min(count-ni, round(do * FPS))
    def specification(name, entry, entrance):
        if not entry: return None
        description = entry[2]; kind = description[0]
        curve = ([.2,.85,.3,1.1] if entrance else [.5,-.3,.7,.3]) if kind in ('popup','pop') else (
            ([.2,.7,.2,1] if entrance else [.6,.1,.8,.4]) if kind == 'slide' else [.25,.1,.25,1])
        return dict(name=name, kind=kind, curve=curve,
                    x=description[1] if kind == 'slide' else 0, y=description[2] if kind == 'slide' else 0)
    return dict(frames=count, in_frames=ni, out_frames=no, sample='midpoint',
                **{'in':specification(incoming, first, True), 'out':specification(outgoing, last, False)})


def _text(item, width, height):
    item = _frames(item)
    narrow = width / height < 1.7
    canonical = item.get('_caption_policy') == 'speech-v998'
    style = item.get('style') or {}
    outer = caption_layer._outer_css(item)
    if narrow and item.get('kind') != 'caption':
        outer += ';width:max-content;max-width:' + ('none' if item.get('oneline') else '96%')
    inner = caption_layer._inner_css(style, item.get('kind'), item.get('oneline'), narrow, canonical)
    if style.get('ost_runs'): inner += ';text-decoration:none;text-transform:none'
    item.update(outer_css=outer, inner_css=inner, html=ost_rich.render(item.get('text') or '', style),
                canonical=canonical, signed_layout=ost_rich._signed_rows(item.get('text') or '', style,
                    ost_rich.normalize(item.get('text') or '', style.get('ost_runs'))) is not None,
                fit_narrow=narrow and item.get('kind') != 'caption',
                animation=_animation(item), word_motion=caption_layer.motion_enabled(style) and item.get('kind') == 'caption')
    return item


def build(timeline, options, project_dir, asset_url_callback):
    """Return JSON-safe overlay layers; never change the project or measured clocks."""
    options = dict(options or {})
    project_dir = Path(project_dir).resolve()
    directory = project_dir / 'export' / '_live_overlay_assets'
    # Do not follow a cache symlink outside the owning project's media namespace.
    if not directory.resolve().is_relative_to(project_dir):
        raise RuntimeError('Invalid project preview asset directory.')
    directory.mkdir(parents=True, exist_ok=True)
    width, height = project_canvas.dimensions(timeline)
    total = float(timeline.get('total', 0))
    if not math.isfinite(total) or total <= 0: raise ValueError('Invalid preview duration.')
    def asset(source, alpha=None, frame_rate=FPS, tint=None):
        path, metadata = _asset(source, directory, options, alpha, frame_rate, tint)
        if not path.resolve().is_relative_to(directory.resolve()): raise RuntimeError('Invalid preview asset.')
        return str(asset_url_callback(path)), metadata
    with project_canvas.scope(timeline):
        _check(options)
        texts = [_text(item, width, height) for item in render_video._browser_items(
            timeline.get('captions') or [], timeline.get('scenes') or [], timeline.get('sub_style'), options)]
        icons = []
        # Explicit canvas avoids renderer-global 720p state from a concurrent job.
        for scene in timeline.get('scenes') or []:
            if scene.get('kind') not in ('image','video'): continue
            for index, authored in enumerate(scene.get('icons') or []):
                if not isinstance(authored,dict): continue
                kind = str(authored.get('type') or authored.get('icon') or '').strip().lower()
                raw_icons = render_video._build_icon_specs([dict(scene,icons=[authored])], directory,
                    canvas=(width,height),key_asset=lambda path,hue:path)
                for raw in raw_icons:
                    _check(options)
                    icon = _frames(raw); source = icon.pop('src')
                    tint = (float(authored.get('hue') or 0) if pe._VFX.get(kind, (None,None))[0]=='key' and kind not in pe._VFX_SCREEN else None)
                    icon['url'], metadata = asset(source, icon.get('blend') != 'screen' if icon.get('video') else None,tint=tint)
                    icon.update(scene_id=scene.get('id'),scene_uid=scene.get('uid'),icon_index=index,kind=kind)
                    icon['asset_width'], icon['asset_height'] = metadata['width'], metadata['height']
                    if icon.get('video'): icon['asset_duration'] = metadata['duration']
                    icons.append(icon)
        plates = [_frames(p) for p in (timeline.get('ost_plates') or [])] if options.get('onscreentext', True) else []
        transitions = []
        enabled = options.get('transitions', True)
        if enabled:
            events = timeline.get('_user_transition_events')
            if events is None:
                events = [dict(key=s.get('transition'),cut=s['end']) for s in (timeline.get('scenes') or [])[:-1]
                          if s.get('transition') in pe._UTX and pe.transition_window(s['transition'],s['end'],total)]
            speakers = [dict(start=s['start'], end=s['end']) for s in timeline.get('scenes') or [] if s.get('speaker_clip')]
            for event in events:
                spec = pe._UTX.get(event['key'])
                if not spec: continue
                source = pe._UTX_DIR / spec['file']
                if not source.is_file(): raise RuntimeError('A preview transition asset is missing.')
                # Transitions retime the original before output FPS conversion;
                # a 60fps proxy first would alter 25/30fps boundary samples.
                url, metadata = asset(source, spec['blend'] != 'screen', None)
                source_duration = pe.ffprobe_media(source)[0]
                start = max(0., float(event['cut']) - spec['hit']/FPS)
                transitions.append(_frames(dict(key=event['key'],url=url,blend=spec['blend'],speed=spec['speed'],
                    start=start,end=start+source_duration/spec['speed'],source_duration=source_duration,
                    width=metadata['width'],height=metadata['height'],speaker_windows=speakers)))
        dips = [_frames(p) for p in timeline.get('_dip_windows', pe.dip_windows(timeline.get('scenes') or [],total))] if enabled else []
        outro_seconds = float(options.get('outro_fade') or 0)
        outro = _frames(dict(start=total-outro_seconds,end=total,color='black',layer='before-text')) if outro_seconds>.05 and total>outro_seconds+1 else None
        result = dict(schema=1,asset_version=VERSION,fps=FPS,width=width,height=height,total_frames=pe.frame_number(total,FPS),
            plates=plates,icons=icons,transitions=transitions,texts=texts,dips=dips,outro=outro,
            layer_order=['base','plates','icons','transitions','outro','ost','captions','dips'])
        # Catch accidental Paths/non-finite values at the API boundary.
        json.dumps(result, allow_nan=False)
        return result
