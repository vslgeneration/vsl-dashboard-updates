"""Missing ingredient portraits: persistent paid task IDs, bounded workers, guarded commits."""
import copy
import shutil
import tempfile
import threading
import time
import uuid
from pathlib import Path
from flask import abort, jsonify, request

def register(app, ns):
    running = ns['_user_job_registry']('ingredient-reference-workers')
    guard = threading.RLock()
    busy = ('queued', 'submitting', 'generating')

    def signature(ing):
        return {k: ing.get(k) for k in ('name', 'desc', 'scientific', 'split')}

    def read(project, iid, token=None):
        doc = ns['load_doc'](project)
        ing = next((i for i in (doc or {}).get('ingredients', []) if i.get('id') == iid), None)
        if not ing or (token and ing.get('auto_image', {}).get('token') != token): return None, None
        return doc, ing

    def update(project, iid, token, **fields):
        with ns['_project_lock'](project):
            doc, ing = read(project, iid, token)
            if not ing: return False
            ing['auto_image'].update(fields)
            ns['save_doc'](project, doc)
            return True

    def generate(project, iid):
        with ns['_project_lock'](project):
            doc, ing = read(project, iid)
            if not ing: return
            job = copy.deepcopy(ing['auto_image']); token = job['token']
            if ing.get('urls') or signature(ing) != job['basis']:
                ing['auto_image'].update(status='cancelled', error='Ingredient changed; your current reference was kept.')
                ns['save_doc'](project, doc); return
            prompt = ns['_ingredient_portrait_prompt'](ing)
            task = job.get('taskId')
            if not task:
                if job['status'] != 'queued':
                    ing['auto_image'].update(status='error', error='Submission status is unknown. Check your Kie account before generating again.')
                    ns['save_doc'](project, doc); return
                ing['auto_image'].update(status='submitting', started=time.time())
                ns['save_doc'](project, doc)
        try:
            if not task:
                model, inputs = ns['build_kie_image_request'](ns['IMAGE_MODEL'], prompt, [], aspect='16:9', resolution='2K')
                # One submission only. An ambiguous response never buys a second portrait.
                task, error = ns['kie_create'](model, inputs)
                if not task:
                    update(project, iid, token, status='error', error=error or 'Image submission failed.'); return
                job['started'] = time.time()
                if not update(project, iid, token, status='generating', taskId=task, started=job['started'], prompt=prompt): return
            start = job.get('started') or time.time()
            while True:
                with ns['_project_lock'](project):
                    current, item = read(project, iid, token)
                    if not item: return
                    if item.get('urls') or signature(item) != job['basis']:
                        update(project, iid, token, status='cancelled', error='Ingredient changed; your current reference was kept.'); return
                try: rec = ns['kie_record'](task)
                except Exception: rec = {}
                state = (rec.get('data') or {}).get('state')
                if state == 'fail':
                    update(project, iid, token, status='error', error='The provider could not generate this ingredient reference.', provider_failed=True); return
                if state == 'success':
                    url = ns['result_url'](rec)
                    if not url: raise ValueError('The completed image has no download URL.')
                    # Download outside the project: a deleted project must not be recreated by a late result.
                    with tempfile.TemporaryDirectory(prefix='ingredient-result-') as tmp:
                        downloaded = Path(tmp)/'reference.png'
                        ns['download_as_png'](url, downloaded)
                        with ns['_project_lock'](project):
                            current, item = read(project, iid, token)
                            if item and not item.get('urls') and signature(item) == job['basis']:
                                d, _ = ns['proj_dir'](project); (d/'refs').mkdir(parents=True, exist_ok=True)
                                rel = ns['_claim_new_file'](d, lambda: 'refs/ingauto_%s_%s.png' % (iid, uuid.uuid4().hex))
                                committed = False
                                try:
                                    shutil.copyfile(downloaded, d/rel)
                                    item['urls'] = [rel]
                                    item['auto_image'].update(status='ready', error=None, file=rel)
                                    ns['save_doc'](project, current); committed = True
                                finally:
                                    if not committed: ns['_drop_own_file'](d/rel)
                            elif item:
                                item['auto_image'].update(status='cancelled', error='Ingredient changed; your current reference was kept.')
                                ns['save_doc'](project, current)
                    return
                if time.time()-start >= ns.get('IMG_GEN_TIMEOUT', 1800):
                    update(project, iid, token, status='error', error='The existing job is still unconfirmed. Check Existing Result; no new generation was sent.'); return
                time.sleep(2)
        except Exception:
            update(project, iid, token, status='error', error='The reference could not finish. No automatic second generation was sent; check the existing task before trying again.')

    def worker(project):
        try:
            while True:
                with guard, ns['_project_lock'](project):
                    doc = ns['load_doc'](project)
                    active = running[project]['active']
                    ing = next((i for i in (doc or {}).get('ingredients', [])
                                if i.get('auto_image', {}).get('status') in busy and i['id'] not in active), None)
                    if not ing: return
                    iid = ing['id']; active.add(iid)
                try: generate(project, iid)
                finally:
                    with guard: active.discard(iid)
        finally:
            with guard: running[project]['workers'] -= 1

    def start(project):
        with guard:
            state = running.setdefault(project, {'workers':0, 'active':set()})
            doc = ns['load_doc'](project)
            count = sum(i.get('auto_image', {}).get('status') in busy for i in (doc or {}).get('ingredients', []))
            while state['workers'] < min(2, count):
                state['workers'] += 1
                try: ns['_KeyThread'](target=worker, args=(project,), daemon=True).start()
                except Exception:
                    state['workers'] -= 1; raise

    def enqueue(project):
        with ns['_project_lock'](project):
            doc = ns['load_doc'](project)
            if doc is None: abort(404)
            if ns['is_youtube'](doc): return []
            added = []
            for ing in doc.get('ingredients', []):
                if not ing.get('name') or ing.get('urls') or ing.get('auto_image'): continue
                ing['auto_image'] = dict(token=uuid.uuid4().hex, status='queued', basis=signature(ing))
                added.append(ing['id'])
            if added: ns['save_doc'](project, doc)
        start(project)
        return added

    @app.post('/api/ingredients/<project>/prepare')
    def prepare(project):
        err = ns['_keys_ok'](('kie',))
        if err: return err
        recover = (request.get_json(silent=True) or {}).get('recover')
        if recover:
            with ns['_project_lock'](project):
                doc, ing = read(project, recover)
                if not ing: abort(404)
                job = ing.get('auto_image', {})
                if ing.get('urls') or not job.get('taskId') or job.get('provider_failed') or job.get('status') != 'error':
                    return jsonify(error='This ingredient has no interrupted reference to check.'), 409
                if signature(ing) != job.get('basis'):
                    return jsonify(error='This ingredient changed. The old job will not replace it.'), 409
                job.update(status='generating', error=None, started=time.time())
                ns['save_doc'](project, doc)
            start(project); return jsonify(ok=True)
        return jsonify(queued=enqueue(project))

    @app.get('/api/ingredients/<project>/status')
    def status(project):
        doc = ns['load_doc'](project)
        if doc is None: abort(404)
        # Resume persisted paid jobs / already-authorized queued entries after reopening the app.
        start(project)
        return jsonify(ingredients=[{k:i.get(k) for k in ('id','urls','auto_image')} for i in doc.get('ingredients',[])])

    return enqueue
