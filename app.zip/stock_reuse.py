"""Reuse complete stock media within one account/project; immutable bytes only.

Project ownership is supplied by the caller. No cross-project/account lookup,
network access, deleted-media restore, or catalog-title-based identity matching.
"""
from pathlib import Path
from urllib.parse import urlparse
import hashlib,os,re,shutil,uuid

def identity(item):
    provider=item.get('provider');kind=item.get('type') or 'video'
    if provider=='envato':
        p=urlparse(str(item.get('url') or ''))
        if p.scheme!='https' or p.hostname!='elements.envato.com':return ''
        tail=p.path.rstrip('/').split('/')[-1]
        code=re.search(r'-([A-Z0-9]{6,16})$',tail)
        value=code[1] if code else tail
    elif provider in ('storyblocks','library'):
        value=str(item.get('asset_id') or '')
    elif provider=='ugc':value=str(item.get('url') or '')
    else:return ''
    return provider+':'+kind+':'+value if value else ''

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def inside_file(root,rel):
    if not isinstance(rel,str) or not rel:return None
    root=Path(root).resolve();p=(root/rel).resolve()
    return p if p.is_relative_to(root) and p.is_file() else None

def link_or_copy(source,target):
    """Separate owned names, shared immutable storage on the same volume."""
    source,target=Path(source),Path(target)
    # _claim_new_file may have reserved an empty destination already.
    if target.exists():
        if target.stat().st_size:raise FileExistsError(str(target))
        target.unlink()
    try:os.link(source,target)
    except OSError:shutil.copyfile(source,target)
    return target

def project_assets(doc,directory,item):
    wanted=identity(item);rows=[];seen=set()
    if not wanted:return rows
    for scene in doc.get('scenes',[]):
        media=scene.get('video' if item.get('type')=='video' else 'image') or {}
        versions=set(media.get('versions') or [])|{media.get('file'),media.get('approved_file')}
        for rel,meta in (media.get('stock_assets') or {}).items():
            if rel not in versions or not isinstance(meta,dict) or identity(meta)!=wanted or meta.get('section'):continue
            source=inside_file(directory,rel);poster=inside_file(directory,meta.get('poster'))
            if not source or not poster:continue
            sha=digest(source)
            if meta.get('content_sha256') and sha!=meta['content_sha256']:continue
            if sha in seen:continue
            seen.add(sha);rows.append(dict(meta,_source=source,_poster=poster,content_sha256=sha))
    return sorted(rows,key=lambda r:(r.get('asset_order',0),r.get('archive_member','')))

def completed_imports(root,project,item,read_json,exclude=None):
    wanted=identity(item)
    if not wanted:return []
    for path in sorted((Path(root)/'imports').glob('*/prepared.json'),key=lambda p:p.stat().st_mtime,reverse=True):
        if path.parent==exclude:continue
        meta=read_json(path,{}) or {}
        if meta.get('project')!=project or identity(meta)!=wanted:continue
        rows=[]
        for entry in [meta]+list(meta.get('alternates') or []):
            source=inside_file(path.parent,entry.get('source'));poster=inside_file(path.parent,entry.get('poster','poster.jpg'))
            if not source or not poster:break
            sha=digest(source)
            if entry.get('content_sha256') and sha!=entry['content_sha256']:break
            rows.append(dict(entry,_source=source,_poster=poster,content_sha256=sha))
        else:
            if rows:return rows
    return []

def completed_envato(root,project,item,read_json):
    """A failed extraction can reuse its original complete ZIP without downloading again."""
    wanted=identity(item)
    for request_path in sorted((Path(root)/'inbox').glob('*/request.json'),key=lambda p:p.stat().st_mtime,reverse=True):
        request=read_json(request_path,{}) or {}
        if request.get('project')!=project or identity(request)!=wanted:continue
        for path in sorted(request_path.parent.glob('*.receipt.json')):
            r=read_json(path,{}) or {};name=str(r.get('file') or '')
            if not re.fullmatch(r'[a-f0-9]{32}\.(zip|mp4|mov|m4v|webm|png|jpg|jpeg|webp)',name):continue
            if not r.get('completed') or identity(dict(item,url=r.get('source_url')))!=wanted:continue
            source=inside_file(path.parent,name)
            if source and source.stat().st_size:return path.parent,r
    return None

def identical_take(media,directory,sha):
    if not sha:return None
    for rel in media.get('versions') or []:
        meta=(media.get('stock_assets') or {}).get(rel) or {}
        if not meta or (meta.get('content_sha256') and meta['content_sha256']!=sha):continue
        source=inside_file(directory,rel);poster=inside_file(directory,meta.get('poster'))
        if source and poster and digest(source)==sha:return rel,meta['poster']
    return None

def deduplicate_receipts(root,project,item,read_json):
    """Keep every receipt/name; replace only verified byte-identical complete files with links."""
    wanted=identity(item);groups={};saved=0;linked=0
    if not wanted:return dict(linked=0,saved_bytes=0)
    for request_path in (Path(root)/'inbox').glob('*/request.json'):
        request=read_json(request_path,{}) or {}
        if request.get('project')!=project or identity(request)!=wanted:continue
        for rec in request_path.parent.glob('*.receipt.json'):
            row=read_json(rec,{}) or {};name=str(row.get('file') or '')
            if not re.fullmatch(r'[a-f0-9]{32}\.(zip|mp4|mov|m4v|webm|png|jpg|jpeg|webp)',name):continue
            if not row.get('completed') or identity(dict(item,url=row.get('source_url')))!=wanted:continue
            p=inside_file(rec.parent,name)
            if p and p.stat().st_size:groups.setdefault(p.stat().st_size,[]).append(p)
    for size,paths in groups.items():
        if len(paths)<2:continue
        known={}
        for p in paths:
            stat=p.stat();sha=digest(p);first=known.setdefault(sha,p)
            if first==p or os.path.samefile(first,p):continue
            # Files completed by the native downloader must not change during hashing.
            now=p.stat()
            if (stat.st_size,stat.st_mtime_ns)!=(now.st_size,now.st_mtime_ns):continue
            tmp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.reuse-link')
            try:
                os.link(first,tmp);os.replace(tmp,p);linked+=1;saved+=size
            except OSError:pass
            finally:tmp.unlink(missing_ok=True)
    return dict(linked=linked,saved_bytes=saved)
