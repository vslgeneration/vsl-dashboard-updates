"""Durable tracking and free recovery for manually requested reference portraits/images."""
import hashlib,json,re,threading,time,uuid
from pathlib import Path
from flask import request,jsonify,abort

_guard=threading.Lock()
_locks={}
PENDING={'submitting','waiting','generating','downloading','unconfirmed'}
KINDS={'characters':'charcand','ingredients':'ingcand','testimonials':'tpcand'}

def path(d,prefix,cid):
    if prefix not in KINDS.values() or not re.fullmatch(r'[A-Za-z0-9_-]+',str(cid)):
        raise ValueError('Invalid reference identity.')
    return Path(d)/'_reference_jobs'/f'{prefix}_{cid}.json'

def lock(p):
    with _guard:return _locks.setdefault(str(p.resolve()),threading.Lock())

def read(p):
    if not p.exists():return None
    row=json.loads(p.read_text('utf8'))
    if not isinstance(row,dict) or row.get('version')!=1:raise ValueError('Saved reference task is unreadable; no new image was submitted.')
    return row

def key_id(ns):return hashlib.sha256(ns['_key']('KIE_API_KEY').encode()).hexdigest()

def write(ns,p,row,**fields):
    if not p.parent.parent.is_dir():raise ValueError('The original project is no longer available.')
    row.update(fields,updated=time.time());p.parent.mkdir(parents=True,exist_ok=True)
    ns['_write_atomic'](p,json.dumps(row,ensure_ascii=False))

def generate(ns,d,cid,prompt,refs,prefix,**kwargs):
    p=path(d,prefix,cid);lk=lock(p)
    if not lk.acquire(False):return None,'This reference already has a running request. Follow its progress; no new image was submitted.'
    try:
        old=read(p)
        if old and old.get('task_id') and old.get('state') in PENDING:
            return None,'This reference has an unconfirmed Kie task. Use Check Existing Result; no new generation was submitted.'
        sequence=int((old or {}).get('sequence') or 0)+1
        # Resolve a new casting recipe only after acquiring this person's job lock.
        # Candidate cleanup, applying a photo and roster reordering cannot reset it.
        if callable(prompt):prompt=prompt(sequence)
        row=dict(version=1,id=uuid.uuid4().hex,cid=cid,prefix=prefix,sequence=sequence,state='submitting',created=time.time(),key_id=key_id(ns),prompt=prompt,task_id=None)
        write(ns,p,row)
        def progress(state,**fields):write(ns,p,row,state=state,**fields)
        try:
            rel,error=ns['_run_char_candidate_raw'](d,cid,prompt,refs,prefix=prefix,observer=progress,**kwargs)
        except Exception:
            write(ns,p,row,state='unconfirmed',error='Request interrupted. Check the existing result before starting another image.')
            raise
        if rel:write(ns,p,row,state='ready',url=rel,error=None)
        else:write(ns,p,row,state='failed' if row.get('state')=='failed' else 'unconfirmed',error=error)
        return rel,error
    finally:lk.release()

def recover(ns,d,prefix,cid):
    p=path(d,prefix,cid);lk=lock(p)
    if not lk.acquire(False):return None,'The existing request is still being checked. No new image was submitted.'
    try:
        row=read(p)
        if not row or not row.get('task_id'):return None,'No saved Kie task ID is available to check.'
        if row.get('key_id')!=key_id(ns):return None,'Use the same Kie account that started this reference before checking its result.'
        if row.get('state')=='ready' and row.get('url') and (Path(d)/row['url']).is_file():return row['url'],None
        tid=row['task_id'];deadline=time.monotonic()+900
        write(ns,p,row,state='waiting',error=None)
        while time.monotonic()<deadline:
            try:record=ns['kie_record'](tid)
            except Exception:record={}
            data=record.get('data') if isinstance(record,dict) else None
            data=data if isinstance(data,dict) else {}
            state=data.get('state');url=ns['result_url'](record) if state=='success' else None
            if state=='fail':
                error=str(data.get('failMsg') or 'Kie reported that the existing image failed.')
                write(ns,p,row,state='failed',provider_state=state,error=error);return None,error
            if url:
                write(ns,p,row,state='downloading',provider_state=state)
                rel=ns['_claim_new_file'](Path(d),lambda:f'refs/{prefix}_{cid}_{uuid.uuid4().hex}.png')
                try:
                    ns['download_as_png'](url,Path(d)/rel)
                    ns['_write_atomic'](Path(d)/(rel+'.json'),json.dumps({'prompt':row.get('prompt','')},ensure_ascii=False))
                except Exception:
                    ns['_drop_own_file'](Path(d)/rel)
                    error='The saved task completed, but its image could not be downloaded. Check Existing Result retries the download without buying another image.'
                    write(ns,p,row,state='unconfirmed',error=error);return None,error
                write(ns,p,row,state='ready',url=rel,error=None);return rel,None
            write(ns,p,row,state='waiting' if state in ('waiting','queuing') else 'generating' if state=='generating' else 'unconfirmed',provider_state=state)
            time.sleep(2)
        error=f'Kie has not returned the existing task {tid} yet. Check Existing Result is free; no new image was submitted.'
        write(ns,p,row,state='unconfirmed',error=error);return None,error
    finally:lk.release()

def register(app,ns):
    def target(project,kind,cid):
        if kind not in KINDS:abort(404)
        doc=ns['load_doc'](project)
        item=next((x for x in (doc or {}).get(kind,[]) if x.get('id')==cid),None)
        if not item:abort(404)
        d,_=ns['proj_dir'](project);return d,item
    @app.get('/api/reference-jobs/<project>/<kind>/<cid>')
    def reference_job_status(project,kind,cid):
        d,item=target(project,kind,cid);p=path(d,KINDS[kind],cid)
        try:row=read(p)
        except ValueError as e:return jsonify(error=str(e)),409
        if not row:return jsonify(job=None)
        active=lock(p).locked()
        public={k:row.get(k) for k in ('id','state','task_id','provider_state','error')}
        saved_unapplied=row.get('state')=='ready' and row.get('url') not in [*(item.get('urls') or []),*(item.get('urls_end') or [])] and bool(row.get('url')) and (Path(d)/row['url']).is_file()
        public.update(name=item.get('name') or kind,elapsed_seconds=max(0,int(time.time()-row['created'])),active=active,
                      recoverable=not active and bool(row.get('task_id')) and (row.get('state') in PENDING or saved_unapplied))
        return jsonify(job=public)
    @app.post('/api/reference-jobs/<project>/<kind>/<cid>/recover')
    def reference_job_recover(project,kind,cid):
        err=ns['_keys_ok'](('kie',))
        if err:return err
        d,item=target(project,kind,cid)
        rel,error=recover(ns,d,KINDS[kind],cid)
        if error:return jsonify(error=error),409
        return jsonify(ok=True,url=rel)
