"""Local, bounded-memory reverse of a copy. Original files are never modified."""
import json
import subprocess
import tempfile
from pathlib import Path


def reverse_video(source, target, progress, cancelled=lambda:False):
    def run(args):
        if cancelled():raise InterruptedError('Video reversal stopped.')
        process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                 creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        try:
            while True:
                try:
                    stdout,stderr=process.communicate(timeout=.2);break
                except subprocess.TimeoutExpired:
                    if cancelled():raise InterruptedError('Video reversal stopped.')
            if process.returncode:raise RuntimeError(stderr.decode('utf8','replace')[-700:])
            return stdout
        finally:
            if process.poll() is None:process.kill();process.communicate()
    probe=json.loads(run(['ffprobe','-v','error','-select_streams','v:0','-show_entries',
                         'stream=width,height,avg_frame_rate:format=duration','-of','json',str(source)]))
    stream=probe['streams'][0];rate=stream['avg_frame_rate'];a,b=map(int,rate.split('/'));fps=a/b if b else 0
    if not 0<fps<=240:raise ValueError('Unsupported video frame rate.')
    # At most ~96 MB of decoded pixels per reverse segment, even for 4K footage.
    frames=max(1,min(round(fps),int(96*1024**2/(stream['width']*stream['height']*1.5))))
    with tempfile.TemporaryDirectory(prefix='reverse-',dir=Path(target).parent) as temp:
        folder=Path(temp);progress('Preparing Video Frames…',None)
        run(['ffmpeg','-v','error','-nostdin','-i',str(source),'-map','0:v:0','-an','-r',rate,
             '-c:v','libx264','-preset','ultrafast','-crf','0','-threads','2','-g',str(frames),
             '-keyint_min',str(frames),'-sc_threshold','0','-f','segment','-segment_time',str(frames/fps),
             '-reset_timestamps','1',str(folder/'part-%06d.mp4')])
        parts=sorted(folder.glob('part-*.mp4'))
        if not parts:raise ValueError('No video frames were decoded.')
        output=[]
        for i,part in enumerate(reversed(parts)):
            progress(f'Reversing Video · {i}/{len(parts)} Sections',100*i/len(parts))
            dest=folder/f'reversed-{i:06d}.mp4'
            run(['ffmpeg','-v','error','-nostdin','-i',str(part),'-map','0:v:0','-an',
                 '-vf','reverse,setpts=PTS-STARTPTS','-c:v','libx264','-preset','fast','-crf','12',
                 '-pix_fmt','yuv420p','-threads','2',str(dest)])
            output.append(dest)
        progress('Finishing Reversed Video…',None)
        listing=folder/'join.txt';listing.write_text(''.join("file '"+p.name+"'\n" for p in output),'utf8')
        run(['ffmpeg','-v','error','-nostdin','-f','concat','-safe','1','-i',str(listing),
             '-map','0:v:0','-an','-c','copy','-movflags','+faststart','-y',str(target)])
        if cancelled():raise InterruptedError('Video reversal stopped.')
        if not Path(target).is_file() or Path(target).stat().st_size<100:raise ValueError('The reversed video is incomplete.')
