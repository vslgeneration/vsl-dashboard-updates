/* Shared, clock-driven subtitle painter. Preview and exported alpha clips execute this file.
   All measurements are in project-canvas pixels, independent of preview window size. */
(() => {
  'use strict';
  const effects = ['word-box', 'word-pop', 'word-fill'];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
  const smooth = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };
  const enabled = st => effects.includes(st?.sub_effect);
  const textOf = w => String(w.text ?? w.w ?? '');
  function units(text) {
    const out = []; let prefix = '';
    for (const t of String(text || '').split(/\s+/).filter(Boolean)) {
      if (/^[«“‘(\[{$£€]+$/u.test(t)) { prefix += t + '\u00a0'; continue; }
      if (!/[\p{L}\p{N}]/u.test(t) && out.length) out[out.length - 1] += '\u00a0' + t;
      else { out.push(prefix + t); prefix = ''; }
    }
    if (prefix) { if (out.length) out[out.length - 1] += prefix; else out.push(prefix); }
    return out;
  }
  function wordsFor(cue) {
    if (cue.words?.length) return cue.words;
    const ts = units(cue.text), dur = Math.max(.01, cue.end - cue.start);
    return ts.map((text, i) => ({text, start:cue.start + dur * i / ts.length, end:cue.start + dur * (i + 1) / ts.length}));
  }
  function font(st, size) { return `${st.ost_italic ? 'italic ' : ''}${st.ost_bold ? 800 : (st.ost_weight || 700)} ${size}px "${String(st.ost_font || 'Poppins').replace(/["\\]/g, '')}", sans-serif`; }
  function setup(ctx, st, size) { ctx.font = font(st, size); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; if ('letterSpacing' in ctx) ctx.letterSpacing = `${Number(st.ost_letter) || 0}px`; }
  function layout(cue, st, W, H) {
    const ctx = document.createElement('canvas').getContext('2d');
    const words = wordsFor(cue).map(w => ({...w, text:st.ost_upper ? textOf(w).toLocaleUpperCase() : textOf(w)}));
    const maxW = W * clamp(st.sub_width || 86, 20, 96) / 100;
    let size = clamp(st.ost_size || 54, 12, 1000), rows, leading, space, pad;
    function measure() {
      setup(ctx, st, size); space = ctx.measureText(' ').width; pad = size * .19;
      rows = [[]]; let lineW = 0;
      for (const w of words) {
        w.width = ctx.measureText(w.text).width;
        if (String(st.sub_lines) !== '1' && lineW && lineW + space + w.width > maxW - 2 * pad) { rows.push([]); lineW = 0; }
        rows.at(-1).push(w); lineW += (lineW ? space : 0) + w.width;
      }
      leading = size * Math.max(1.28, Number(st.ost_leading) || 1.28);
      return Math.max(1, ...rows.map(r => r.reduce((n, w) => n + w.width, 0) + space * (r.length - 1))) + 2 * pad;
    }
    let width = measure();
    // A long token, an explicit single line, or a very large font still stays inside the canvas.
    for (let i = 0; i < 12 && (width > maxW || rows.length * leading + 2 * pad > H * .7 || (String(st.sub_lines) === '2' && rows.length > 2)); i++) {
      size *= Math.min(.94, maxW / width, (H * .7) / (rows.length * leading + 2 * pad)); width = measure();
    }
    const height = rows.length * leading + 2 * pad;
    // Every word on a row shares one alphabetic baseline. Centering each word's
    // ink bounds separately makes short letters, ascenders and descenders jump.
    const fontMetrics = ctx.measureText('HÉÅgjpq');
    const metric = (primary, fallback, estimate) => Number.isFinite(primary) ? primary : Number.isFinite(fallback) ? fallback : estimate;
    const ascent = metric(fontMetrics.fontBoundingBoxAscent, fontMetrics.actualBoundingBoxAscent, size * .78);
    const descent = metric(fontMetrics.fontBoundingBoxDescent, fontMetrics.actualBoundingBoxDescent, size * .2);
    const baselineOffset = (ascent - descent) / 2;
    const x = clamp(W / 2 + Number(st.ost_x || 0), width / 2 + W * .02, W - width / 2 - W * .02);
    const place = st.ost_place || 'bottom';
    let y = (place === 'top' ? H * .14 + height / 2 : place === 'center' ? H / 2 : H * .955 - height / 2) + Number(st.ost_y || 0);
    y = clamp(y, height / 2 + H * .02, H - height / 2 - H * .02);
    rows.forEach((row, ri) => {
      let xx = - (row.reduce((n, w) => n + w.width, 0) + space * (row.length - 1)) / 2;
      row.forEach(w => { w.x = xx; w.y = -height / 2 + pad + (ri + .5) * leading; xx += w.width + space; });
    });
    const angle = clamp(st.ost_rotation || 0, -180, 180) * Math.PI / 180;
    const margin = Math.max(12, size * .32, Number(st.ost_shadow_size || 0) * 3);
    const bw = Math.abs(Math.cos(angle)) * width + Math.abs(Math.sin(angle)) * height + margin * 2;
    const bh = Math.abs(Math.sin(angle)) * width + Math.abs(Math.cos(angle)) * height + margin * 2;
    const bounds = {x:Math.max(0, Math.floor(x - bw / 2)), y:Math.max(0, Math.floor(y - bh / 2))};
    bounds.width = Math.max(2, Math.min(W, Math.ceil(x + bw / 2)) - bounds.x);
    bounds.height = Math.max(2, Math.min(H, Math.ceil(y + bh / 2)) - bounds.y);
    return {cue, st, W, H, words, rows, size, leading, width, height, x, y, angle, bounds, baselineOffset};
  }
  function paint(canvas, l, t, cropped = false) {
    const {st, size, words, bounds:b} = l, W = cropped ? b.width : l.W, H = cropped ? b.height : l.H;
    if (canvas.width !== W) canvas.width = W; if (canvas.height !== H) canvas.height = H;
    const ctx = canvas.getContext('2d'); ctx.clearRect(0, 0, W, H);
    if (t < l.cue.start || t >= l.cue.end) return;
    ctx.save(); ctx.translate(l.x - (cropped ? b.x : 0), l.y - (cropped ? b.y : 0)); ctx.rotate(l.angle); setup(ctx, st, size);
    if (st.ost_bg) { ctx.fillStyle = st.ost_bg_color || '#000000'; ctx.globalAlpha = clamp(st.ost_bg_opacity ?? 62, 0, 100) / 100; ctx.beginPath(); ctx.roundRect(-l.width / 2, -l.height / 2, l.width, l.height, Math.max(0, Number(st.ost_bg_radius) || 10)); ctx.fill(); ctx.globalAlpha = 1; }
    const current = words.findLastIndex(w => t >= Number(w.start));
    words.forEach((w, i) => {
      const active = i === current, u = clamp((t - w.start) / Math.max(.02, w.end - w.start), 0, 1);
      const hot = st.sub_highlight || '#b8f36b', base = st.ost_color || '#ffffff';
      ctx.save();
      if (active && st.sub_effect === 'word-pop') { const z = 1 + .12 * Math.sin(Math.PI * clamp((t - w.start) / Math.min(.24, Math.max(.04, w.end - w.start)), 0, 1)); ctx.translate(w.x + w.width / 2, w.y); ctx.scale(z, z); ctx.translate(-w.x - w.width / 2, -w.y); }
      const baseline = w.y + l.baselineOffset;
      if (active && st.sub_effect === 'word-box') { ctx.globalAlpha = smooth((t - w.start) / Math.min(.075, Math.max(.02, w.end - w.start))); ctx.fillStyle = hot; ctx.beginPath(); ctx.roundRect(w.x - size * .12, w.y - size * .57, w.width + size * .24, size * 1.14, size * .16); ctx.fill(); ctx.globalAlpha = 1; }
      function text(color) {
        ctx.fillStyle = color; ctx.strokeStyle = st.ost_stroke_color || '#000000'; ctx.lineWidth = Math.max(0, Number(st.ost_stroke_w) || 0); ctx.lineJoin = 'round';
        if (st.ost_shadow) { const r = Number(st.ost_shadow_dir ?? 135) * Math.PI / 180, n = Number(st.ost_shadow_size ?? 4); ctx.shadowColor = (st.ost_shadow_color || '#000000') + Math.round(clamp(st.ost_shadow_opacity ?? 80, 0, 100) * 2.55).toString(16).padStart(2, '0'); ctx.shadowBlur = n; ctx.shadowOffsetX = n * Math.cos(r); ctx.shadowOffsetY = n * Math.sin(r); }
        if (st.ost_stroke && ctx.lineWidth) ctx.strokeText(w.text, w.x, baseline);
        if (st.ost_fill !== false) ctx.fillText(w.text, w.x, baseline);
        ctx.shadowColor = 'transparent';
        if (st.ost_underline) { ctx.fillRect(w.x, baseline + size * .1, w.width, Math.max(1, size * .055)); }
      }
      text(active && st.sub_effect === 'word-pop' ? hot : base);
      if (st.sub_effect === 'word-fill' && i <= current) { ctx.save(); ctx.beginPath(); ctx.rect(w.x - 4, w.y - size, (w.width + 8) * (i < current ? 1 : smooth(u)), size * 2); ctx.clip(); text(hot); ctx.restore(); }
      ctx.restore();
    });
    ctx.restore();
  }
  const common = {ost_font:'Poppins',ost_size:54,ost_weight:'700',ost_bold:false,ost_italic:false,ost_upper:false,ost_underline:false,ost_fill:true,ost_color:'#ffffff',ost_letter:0,ost_leading:1.3,ost_place:'bottom',ost_stroke:true,ost_stroke_w:2,ost_stroke_color:'#15201a',ost_bg:false,ost_shadow:false,ost_anim:'none',ost_out_anim:'none',sub_width:86,sub_lines:'auto'};
  const presets = [{name:'Classic',builtin:true,kind:'subtitle',style:{sub_effect:'none',ost_anim:'fade'}},
    ...[['Word Highlight','word-box','#257749'],['Word Pop','word-pop','#ffd44f'],['Smooth Karaoke','word-fill','#b8f36b']].map(([name,sub_effect,sub_highlight])=>({name,builtin:true,kind:'subtitle',style:{...common,sub_effect,sub_highlight}}))];
  window.SubtitleMotion = {enabled, units, wordsFor, layout, paint, presets, effects};
})();
