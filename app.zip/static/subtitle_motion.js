/* Shared, clock-driven subtitle painter. Preview and exported alpha clips execute this file.
   All measurements are in project-canvas pixels, independent of preview window size. */
(() => {
  'use strict';
  const effects = ['word-box', 'word-pop', 'word-fill'];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
  const smooth = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };
  const enabled = st => effects.includes(st?.sub_effect);
  const textOf = w => String(w.text ?? w.w ?? '');
  function units(text) {
    const out = []; let prefix = '';
    for (const t of String(text || '').split(/\s+/).filter(Boolean)) {
      if (/^[«“‘(\[{$£€]+$/u.test(t)) { prefix += t + '\u00a0'; continue; }
      if (!/[\p{L}\p{N}]/u.test(t) && out.length) out[out.length - 1] += '\u00a0' + t;
      else { out.push(prefix + t); prefix = ''; }
    }
    if (prefix) { if (out.length) out[out.length - 1] += prefix; else out.push(prefix); }
    return out;
  }
  function wordsFor(cue) {
    if (cue.words?.length) return cue.words;
    const ts = units(cue.text), dur = Math.max(.01, cue.end - cue.start);
    return ts.map((text, i) => ({text, start:cue.start + dur * i / ts.length, end:cue.start + dur * (i + 1) / ts.length}));
  }
  // Anchor every word to its own speech interval. A sentence-wide width sweep
  // drifts whenever word length and spoken duration differ, even with exact stamps.
  function sweepTrack(words, cue, space) {
    let distance = 0;
    words.forEach((w, i) => { w.from = distance; distance += w.width; w.to = distance; if(i < words.length-1) distance += space; });
    const lo=Number(cue.start),hi=Number(cue.end),anchors=[];
    const valid=(n,fallback)=>Number.isFinite(Number(n))&&n!=null?Number(n):fallback;
    const add=(t,x)=>{const last=anchors.at(-1);if(last&&t<=last[0]+1e-8){last[1]=Math.max(last[1],x);}else anchors.push([t,x]);};
    let previous=lo;
    for(let i=0;i<words.length;) {
      const start=clamp(Math.max(previous,valid(words[i].start,previous)),lo,hi);let j=i+1;
      // Only collapsed/invalid local stamps need interpolation. Never stretch a
      // correctly aligned neighbouring word to smooth an unrelated bad interval.
      while(j<words.length&&valid(words[j].start,start)<=start+.001)j++;
      const limit=clamp(j<words.length?valid(words[j].start,hi):hi,start,hi);
      let end=clamp(Math.max(...words.slice(i,j).map(w=>valid(w.end,start))),start,limit);
      if(end-start<.001*(j-i))end=limit;
      const weights=words.slice(i,j).map(w=>Math.max(1,Array.from(w.text||'').filter(c=>/[\p{L}\p{N}]/u.test(c)).length));
      const total=weights.reduce((a,b)=>a+b,0);let used=0;
      for(let k=i;k<j;k++) {
        const w=words[k],a=start+(end-start)*used/total;used+=weights[k-i];
        const b=start+(end-start)*used/total;
        w.highlightStart=a;w.highlightEnd=b;
        add(a,w.from);add(b,w.to);
      }
      previous=end;i=j;
    }
    if(!anchors.length)anchors.push([lo,0]);
    if(anchors.at(-1)[0]<hi)anchors.push([hi,distance]);
    return {anchors,total:distance};
  }
  function sweepAt(track,t) {
    const a=track.anchors;if(t<=a[0][0]) return 0;
    for(let i=1;i<a.length;i++) if(t<a[i][0]) return a[i-1][1]+(a[i][1]-a[i-1][1])*(t-a[i-1][0])/(a[i][0]-a[i-1][0]);
    return track.total;
  }
  function font(st, size) { return `${st.ost_italic ? 'italic ' : ''}${st.ost_bold ? 800 : (st.ost_weight || 700)} ${size}px "${String(st.ost_font || 'Poppins').replace(/["\\]/g, '')}", sans-serif`; }
  function setup(ctx, st, size) { ctx.font = font(st, size); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; if ('letterSpacing' in ctx) ctx.letterSpacing = `${Number(st.ost_letter) || 0}px`; }
  // Whole-sentence entrance/exit is independent of the word highlight clock.
  // Easing and durations mirror caption_layer.py for Classic caption exports.
  function bezier(u, x1, y1, x2, y2) {
    if (u <= 0) return 0; if (u >= 1) return 1;
    const at = (t,a,b) => 3*(1-t)*(1-t)*t*a + 3*(1-t)*t*t*b + t*t*t;
    let lo=0,hi=1;for(let i=0;i<40;i++){const mid=(lo+hi)/2;if(at(mid,x1,x2)<u)lo=mid;else hi=mid;}
    return at((lo+hi)/2,y1,y2);
  }
  function sentenceState(cue, st, t) {
    const incoming=st.ost_anim ?? cue.anim ?? 'fade', outgoing=st.ost_out_anim ?? cue.out_anim ?? 'none';
    const valid=k=>['fade','popup','pop','slide-left','slide-right','slide-top','slide-bottom'].includes(k);
    let di=valid(incoming)?(incoming==='popup'?.55:.5):0, dout=valid(outgoing)?.4:0;
    const duration=Math.max(0,Number(cue.end)-Number(cue.start));
    if(di+dout>duration){const k=duration/(di+dout);di*=k;dout*=k;}
    const state={opacity:1,x:0,y:0,scale:1};
    if(t<cue.start||t>=cue.end||!duration)return {...state,opacity:0};
    const isIn=di>0&&t-cue.start<di,isOut=dout>0&&t>cue.end-dout;
    if(!isIn&&!isOut)return state;
    const key=isIn?incoming:outgoing,u=clamp(isIn?(t-cue.start)/di:(t-(cue.end-dout))/dout,0,1);
    const slide=key.startsWith('slide-'),pop=key==='pop'||key==='popup';
    const curve=isIn?(pop?[.2,.85,.3,1.1]:slide?[.2,.7,.2,1]:[.25,.1,.25,1]):(pop?[.5,-.3,.7,.3]:slide?[.6,.1,.8,.4]:[.25,.1,.25,1]);
    const ease=v=>bezier(v,...curve),e=ease(u);
    state.opacity=clamp(isIn?e:1-e,0,1);
    if(pop){
      if(isIn){const p=u<=.7?ease(u/.7):ease((u-.7)/.3);state.scale=u<=.7?.5+.58*p:1.08-.08*p;state.opacity=u<=.7?clamp(p,0,1):1;}
      else state.scale=1-.4*e;
    }
    if(slide){const p=isIn?1-e:e;state.x=(key==='slide-left'?-70:key==='slide-right'?70:0)*p;state.y=(key==='slide-top'?-48:key==='slide-bottom'?48:0)*p;}
    return state;
  }
  function layout(cue, st, W, H) {
    const ctx = document.createElement('canvas').getContext('2d');
    const breaks = new Set(); let count = 0;
    String(cue.text || '').replace(/\r\n?/g, '\n').split('\n').forEach((line, i) => { if (i) breaks.add(count); count += units(line).length; });
    let words = wordsFor(cue).map((w, i) => ({...w, breakBefore:breaks.has(i), text:st.ost_upper ? textOf(w).toLocaleUpperCase() : textOf(w)}));
    const maxW = W * clamp(st.sub_width || 86, 20, 96) / 100;
    let size = clamp(st.ost_size || 54, 12, 1000), rows, leading, space, pad;
    function measure() {
      setup(ctx, st, size); space = ctx.measureText(' ').width;
      if(st.sub_effect==='word-pop')space=Math.max(space,size*.32);
      // Background Size is canvas-pixel padding, just like Classic captions.
      // Keep the word highlight's existing spacing when the background is off.
      const bgPad = Number(st.ost_bg_pad ?? 14);
      pad = st.ost_bg ? clamp(Number.isFinite(bgPad) ? bgPad : 14, 0, 80) : size * .19;
      // An unusually long token can wrap without changing its font or speech clock.
      const available = Math.max(size, maxW - 2 * pad);
      words = words.flatMap(w => {
        if (ctx.measureText(w.text).width <= available) return [w];
        const letters = typeof Intl.Segmenter === 'function'
          ? Array.from(new Intl.Segmenter(undefined, {granularity:'grapheme'}).segment(w.text), s => s.segment)
          : Array.from(w.text);
        const chunks = []; let chunk = '';
        for (const letter of letters) {
          if (chunk && ctx.measureText(chunk + letter).width > available) { chunks.push(chunk); chunk = ''; }
          chunk += letter;
        }
        if (chunk) chunks.push(chunk);
        return chunks.map((text, i) => ({...w, text, breakBefore:i > 0 || w.breakBefore}));
      });
      rows = [[]]; let lineW = 0;
      for (const w of words) {
        w.width = ctx.measureText(w.text).width;
        // Bound each word's overshoot by the real gap, especially long words.
        // At the peak, its neighbours still retain breathing room.
        const stroke=st.ost_stroke?Math.max(0,Number(st.ost_stroke_w)||0):0;
        w.popScale=Math.min(.07,Math.max(0,space-stroke*2-size*.05)*1.4/Math.max(1,w.width));
        if (lineW && (w.breakBefore || lineW + space + w.width > maxW - 2 * pad)) { rows.push([]); lineW = 0; }
        rows.at(-1).push(w); lineW += (lineW ? space : 0) + w.width;
      }
      leading = size * Math.max(1.28, Number(st.ost_leading) || 1.28);
      return Math.max(1, ...rows.map(r => r.reduce((n, w) => n + w.width, 0) + space * (r.length - 1))) + 2 * pad;
    }
    let width = measure();
    // Keep the user's selected size for every caption. The line count is a
    // layout preference, never permission to reduce the font for longer text.
    const height = rows.length * leading + 2 * pad;
    // Every word on a row shares one alphabetic baseline. Centering each word's
    // ink bounds separately makes short letters, ascenders and descenders jump.
    const fontMetrics = ctx.measureText('HÉÅgjpq');
    const metric = (primary, fallback, estimate) => Number.isFinite(primary) ? primary : Number.isFinite(fallback) ? fallback : estimate;
    const ascent = metric(fontMetrics.fontBoundingBoxAscent, fontMetrics.actualBoundingBoxAscent, size * .78);
    const descent = metric(fontMetrics.fontBoundingBoxDescent, fontMetrics.actualBoundingBoxDescent, size * .2);
    const baselineOffset = (ascent - descent) / 2;
    const x = clamp(W / 2 + Number(st.ost_x || 0), width / 2 + W * .02, W - width / 2 - W * .02);
    const place = st.ost_place || 'bottom';
    let y = (place === 'top' ? H * .14 + height / 2 : place === 'center' ? H / 2 : H * .955 - height / 2) + Number(st.ost_y || 0);
    y = clamp(y, height / 2 + H * .02, H - height / 2 - H * .02);
    rows.forEach((row, ri) => {
      let xx = - (row.reduce((n, w) => n + w.width, 0) + space * (row.length - 1)) / 2;
      row.forEach(w => { w.x = xx; w.y = -height / 2 + pad + (ri + .5) * leading; xx += w.width + space; });
    });
    const angle = clamp(st.ost_rotation || 0, -180, 180) * Math.PI / 180;
    const animations=[st.ost_anim,st.ost_out_anim];
    const moving=animations.some(a=>a&&a!=='none');
    // Include every entrance/exit position and pop overshoot in the exported crop.
    let margin = Math.max(12, size * .32, Number(st.ost_shadow_size || 0) * 3,
      moving ? 78 + Math.max(width,height)*.06 : 0);
    // New shadow offsets must fit inside the transparent export crop too.
    const shadowExtent = Math.max(
      st.ost_shadow && st.ost_shadow_distance != null ? Number(st.ost_shadow_distance) + Number(st.ost_shadow_size ?? 4) * 3 : 0,
      st.ost_bg && st.ost_bg_shadow ? Number(st.ost_bg_shadow_distance ?? 8) + Number(st.ost_bg_shadow_size ?? 12) * 3 : 0);
    margin += shadowExtent;
    const bw = Math.abs(Math.cos(angle)) * width + Math.abs(Math.sin(angle)) * height + margin * 2;
    const bh = Math.abs(Math.sin(angle)) * width + Math.abs(Math.cos(angle)) * height + margin * 2;
    const bounds = {x:Math.max(0, Math.floor(x - bw / 2)), y:Math.max(0, Math.floor(y - bh / 2))};
    bounds.width = Math.max(2, Math.min(W, Math.ceil(x + bw / 2)) - bounds.x);
    bounds.height = Math.max(2, Math.min(H, Math.ceil(y + bh / 2)) - bounds.y);
    return {cue, st, W, H, words, rows, size, leading, width, height, x, y, angle, bounds, baselineOffset, sweep:sweepTrack(words,cue,space)};
  }
  const paintSurfaces = new WeakMap();
  function paint(canvas, l, t, cropped = false, outputScale = 1) {
    // Rasterize glyph edges above delivery resolution, then resolve RGBA together.
    // This preserves alpha edges and keeps preview, MP4 and XML geometry identical.
    const rasterScale = 2;
    let surface = paintSurfaces.get(canvas);
    if (!surface) { surface = document.createElement('canvas'); paintSurfaces.set(canvas, surface); }
    paintRaster(surface, l, t, cropped, rasterScale);
    outputScale = outputScale === 2 ? 2 : 1;
    const W = (cropped ? l.bounds.width : l.W) * outputScale, H = (cropped ? l.bounds.height : l.H) * outputScale;
    if (canvas.width !== W) canvas.width = W; if (canvas.height !== H) canvas.height = H;
    const ctx = canvas.getContext('2d'); ctx.clearRect(0, 0, W, H);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    // Fade the completed sentence once. Fading each stroke/fill/highlight pass
    // separately stacks their alpha and makes a word preset resist the fade.
    ctx.save();ctx.globalAlpha=sentenceState(l.cue,l.st,t).opacity;
    ctx.drawImage(surface, 0, 0, W, H);ctx.restore();
  }
  function paintRaster(canvas, l, t, cropped, rasterScale) {
    const {st, size, words, bounds:b} = l, W = cropped ? b.width : l.W, H = cropped ? b.height : l.H;
    if (canvas.width !== W * rasterScale) canvas.width = W * rasterScale; if (canvas.height !== H * rasterScale) canvas.height = H * rasterScale;
    const ctx = canvas.getContext('2d'); ctx.clearRect(0, 0, canvas.width, canvas.height);
    // Hidden captions retain their time window for editing but paint nothing,
    // including background padding, shadows and stale word highlights.
    if (t < l.cue.start || t >= l.cue.end || (l.cue.text != null && !String(l.cue.text).trim()) || !words.some(w => w.text.trim())) return;
    const phrase=sentenceState(l.cue,st,t),alpha=1;
    ctx.save(); ctx.scale(rasterScale, rasterScale); ctx.translate(l.x - (cropped ? b.x : 0), l.y - (cropped ? b.y : 0)); ctx.rotate(l.angle);ctx.translate(phrase.x,phrase.y);ctx.scale(phrase.scale,phrase.scale);ctx.globalAlpha=alpha;setup(ctx, st, size);
    if (st.ost_bg) {
      const box = () => ctx.roundRect(-l.width / 2, -l.height / 2, l.width, l.height, clamp(st.ost_bg_radius ?? 10, 0, 80));
      if (st.ost_bg_shadow) {
        ctx.save();
        // CSS box-shadow is outside the rounded box and independent of its fill opacity.
        ctx.beginPath(); ctx.rect(-l.W * 4, -l.H * 4, l.W * 8, l.H * 8); box(); ctx.clip('evenodd');
        const r = Number(st.ost_bg_shadow_dir ?? 135) * Math.PI / 180 + l.angle;
        const d = Number(st.ost_bg_shadow_distance ?? 8) * rasterScale * phrase.scale;
        ctx.shadowColor = (st.ost_bg_shadow_color || '#000000') + Math.round(clamp(st.ost_bg_shadow_opacity ?? 60, 0, 100) * 2.55).toString(16).padStart(2, '0');
        ctx.shadowBlur = Number(st.ost_bg_shadow_size ?? 12) * rasterScale * phrase.scale;
        ctx.shadowOffsetX = d * Math.cos(r); ctx.shadowOffsetY = d * Math.sin(r);
        ctx.fillStyle = '#000000'; ctx.beginPath(); box(); ctx.fill(); ctx.restore();
      }
      ctx.fillStyle = st.ost_bg_color || '#000000'; ctx.globalAlpha = alpha * clamp(st.ost_bg_opacity ?? 62, 0, 100) / 100;
      ctx.beginPath(); box(); ctx.fill(); ctx.globalAlpha = alpha;
    }
    words.forEach((w, i) => {
      const duration=Math.max(.001,w.highlightEnd-w.highlightStart);
      const u=clamp((t-w.highlightStart)/duration,0,1),active=t>=w.highlightStart&&t<w.highlightEnd;
      const ramp=Math.min(.025,duration*.2);
      const glow=active?smooth(Math.min((t-w.highlightStart)/ramp,(w.highlightEnd-t)/ramp)):0;
      const hot = st.sub_highlight || '#b8f36b', base = st.ost_color || '#ffffff';
      ctx.save();
      if (active && st.sub_effect === 'word-pop') { const z = 1 + (w.popScale ?? .05) * Math.sin(Math.PI * u); ctx.translate(w.x + w.width / 2, w.y); ctx.scale(z, z); ctx.translate(-w.x - w.width / 2, -w.y); }
      const baseline = w.y + l.baselineOffset;
      if (active && st.sub_effect === 'word-box') { ctx.globalAlpha = alpha * glow; ctx.fillStyle = hot; ctx.beginPath(); ctx.roundRect(w.x - size * .12, w.y - size * .57, w.width + size * .24, size * 1.14, size * .16); ctx.fill(); ctx.globalAlpha = alpha; }
      function text(color) {
        ctx.fillStyle = color; ctx.strokeStyle = st.ost_stroke_color || '#000000'; ctx.lineWidth = Math.max(0, Number(st.ost_stroke_w) || 0); ctx.lineJoin = 'round';
        if (st.ost_shadow) { const r = Number(st.ost_shadow_dir ?? 135) * Math.PI / 180, n = Number(st.ost_shadow_size ?? 4) * rasterScale; const d = Number(st.ost_shadow_distance ?? st.ost_shadow_size ?? 4) * rasterScale; ctx.shadowColor = (st.ost_shadow_color || '#000000') + Math.round(clamp(st.ost_shadow_opacity ?? 80, 0, 100) * 2.55).toString(16).padStart(2, '0'); ctx.shadowBlur = n; ctx.shadowOffsetX = d * Math.cos(r); ctx.shadowOffsetY = d * Math.sin(r); }
        if (st.ost_stroke && ctx.lineWidth) ctx.strokeText(w.text, w.x, baseline);
        if (st.ost_fill !== false) ctx.fillText(w.text, w.x, baseline);
        ctx.shadowColor = 'transparent';
        if (st.ost_underline) { ctx.fillRect(w.x, baseline + size * .1, w.width, Math.max(1, size * .055)); }
      }
      text(base);
      if (active && st.sub_effect === 'word-pop') { ctx.globalAlpha=alpha*glow;text(hot);ctx.globalAlpha=alpha; }
      if (st.sub_effect === 'word-fill' && u>0) { ctx.save(); ctx.beginPath(); ctx.rect(w.x - 4, w.y - size, (w.width + 8) * u, size * 2); ctx.clip(); text(hot); ctx.restore(); }
      ctx.restore();
    });
    ctx.restore();
  }
  const common = {ost_font:'Poppins',ost_size:54,ost_weight:'700',ost_bold:false,ost_italic:false,ost_upper:false,ost_underline:false,ost_fill:true,ost_color:'#ffffff',ost_letter:0,ost_leading:1.3,ost_place:'bottom',ost_stroke:true,ost_stroke_w:2,ost_stroke_color:'#15201a',ost_bg:false,ost_shadow:false,ost_anim:'none',ost_out_anim:'none',sub_width:86,sub_lines:'auto'};
  const presets = [{name:'Classic',builtin:true,kind:'subtitle',style:{sub_effect:'none',ost_anim:'fade'}},
    ...[['Word Highlight','word-box','#257749'],['Word Pop','word-pop','#ffd44f'],['Smooth Karaoke','word-fill','#b8f36b']].map(([name,sub_effect,sub_highlight])=>({name,builtin:true,kind:'subtitle',style:{...common,sub_effect,sub_highlight}}))];
  window.SubtitleMotion = {enabled, units, wordsFor, layout, paint, presets, effects, sweepTrack, sweepAt, sentenceState};
})();
