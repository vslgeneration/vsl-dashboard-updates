/* Opt-in, device-local UI scheduling. Never reads/writes project or render settings. */
(() => {
  'use strict';
  const key = 'vslLightInterface';
  let on = false, io = null, rowIO = null, rowSizes = null, listObserver = null, settleTimer = 0;
  const videos = new Map();
  const rows = new Map();
  const rowSelector = '#scenesList .scene-row,#videosList .video-row,#videosList .speaker-scene';
  try { on = localStorage.getItem(key) === '1'; } catch (_) {}
  const paintMode = () => {
    if (on) document.documentElement.dataset.lightUi = '1';
    else delete document.documentElement.dataset.lightUi;
    document.querySelectorAll('[data-light-ui-toggle]').forEach(button => {
      button.setAttribute('aria-checked', String(on));
      button.title = `${on ? 'Lite' : 'Full'} interface · This computer only`;
    });
  };
  paintMode(); // before styles load: a saved device setting has no startup flash

  function attach(record) {
    const {video, audio, source, audioSource} = record;
    if (!video.isConnected || document.hidden) return;
    video.preload = 'metadata';
    if (audio && audioSource && !audio.getAttribute('src')) audio.src = audioSource;
    if (video.getAttribute('src') !== source) video.src = source;
  }
  function release(record) {
    const {video, audio} = record;
    // Releasing a speaker source must not collapse its intrinsic height while scrolling.
    if (audio && video.videoWidth && video.videoHeight && !record.aspectRatio) {
      video.style.aspectRatio = `${video.videoWidth} / ${video.videoHeight}`;
    }
    if (audio) {
      audio.pause();
      if (audio.hasAttribute('src')) { audio.removeAttribute('src'); audio.load(); }
    }
    video.pause();
    if (video.hasAttribute('src')) { video.removeAttribute('src'); video.load(); }
    video.preload = 'none';
  }
  function prune() {
    for (const [video, record] of videos) {
      if (video.isConnected) continue;
      release(record); io?.unobserve(video); videos.delete(video);
    }
    for (const [row] of rows) if (!row.isConnected) { rowIO?.unobserve(row); rowSizes?.unobserve(row); row.classList.remove('light-ui-dormant'); row.style.removeProperty('--light-row-height'); rows.delete(row); }
  }
  function ensureObserver() {
    if (io || !('IntersectionObserver' in window)) return;
    io = new IntersectionObserver(entries => {
      for (const entry of entries) {
        const record = videos.get(entry.target);
        if (!record) continue;
        record.near = entry.isIntersecting;
        if (!on || !record.near || document.hidden) release(record);
      }
      settle();
    }, {rootMargin: '500px 0px'});
  }
  function settle() {
    clearTimeout(settleTimer);
    // Don't decode every clip passed during a fast scroll. Load the area where the user stops.
    settleTimer = setTimeout(() => {
      settleTimer = 0;
      if (!on || document.hidden) return;
      for (const record of videos.values()) if (record.near) attach(record);
    }, 100);
  }
  function registerVideo(video, source, options = {}) {
    if (!on || !source || !('IntersectionObserver' in window)) return false;
    ensureObserver();
    const known = videos.get(video);
    if (known && known.source === source) return true;
    if (known) { release(known); io.unobserve(video); }
    const audio = options.audio || video.closest('.speaker-scene')?.querySelector('audio');
    const record = {video, source, audio, audioSource: audio?.getAttribute('src') || known?.audioSource || '',
      preload: known ? known.preload : video.getAttribute('preload'),
      aspectRatio: known ? known.aspectRatio : video.style.aspectRatio, near: false};
    videos.set(video, record);
    video.playsInline = true;
    release(record);
    io.observe(video);
    return true;
  }
  function adoptExisting() {
    for (const video of document.querySelectorAll('#scenesList video,#videosList video')) {
      registerVideo(video, video.dataset.src || video.getAttribute('src'));
    }
    prune();
  }
  function start() {
    if (!on || !document.body) return;
    ensureObserver(); adoptExisting();
    const paintRow = row => {
      const r = rows.get(row); if (!r) return;
      const hidden = !r.near && r.height > 0 && !row.contains(document.activeElement);
      const wasHidden = row.classList.contains('light-ui-dormant');
      if (hidden) row.style.setProperty('--light-row-height', r.height + 'px');
      row.classList.toggle('light-ui-dormant', hidden);
      if (wasHidden && !hidden) window.dispatchEvent(new CustomEvent('light-ui-row-visible', {detail: {row}}));
    };
    if (!rowIO && 'IntersectionObserver' in window && 'ResizeObserver' in window
        && window.CSS?.supports('content-visibility','hidden') && window.CSS.supports('contain-intrinsic-block-size','1px')) {
      rowSizes = new ResizeObserver(entries => {
        for (const entry of entries) {
          const r = rows.get(entry.target);
          if (r && entry.target.classList.contains('light-ui-dormant') && Math.abs((r.width || 0) - entry.contentRect.width) > .5) {
            r.width = entry.contentRect.width; r.height = 0;
            entry.target.classList.remove('light-ui-dormant'); continue;
          }
          if (r && !entry.target.classList.contains('light-ui-dormant') && entry.contentRect.height > 0) {
            r.height = entry.contentRect.height; r.width = entry.contentRect.width; paintRow(entry.target);
          }
        }
      });
      rowIO = new IntersectionObserver(entries => {
        for (const entry of entries) { const r = rows.get(entry.target); if (r) { r.near=entry.isIntersecting; paintRow(entry.target); } }
      }, {rootMargin: '500px 0px'});
    }
    const observeRows = root => {
      if (!rowIO) return;
      const found = root.matches?.(rowSelector) ? [root] : [...root.querySelectorAll(rowSelector)];
      for (const row of found) if (!rows.has(row)) { rows.set(row,{near:true,height:0}); rowSizes.observe(row); rowIO.observe(row); }
    };
    observeRows(document);
    if (!listObserver) {
      listObserver = new MutationObserver(changes => {
        // Video clock text changes every frame; those never require a media sweep.
        if (changes.some(change => [...change.removedNodes].some(node => node.nodeType === 1))) prune();
        for (const change of changes) for (const node of change.addedNodes) if (node.nodeType === 1) observeRows(node);
      });
      for (const id of ['scenesList', 'videosList']) {
        const list = document.getElementById(id);
        if (list) listObserver.observe(list, {childList: true, subtree: true});
      }
    }
  }
  function stop() {
    clearTimeout(settleTimer); settleTimer = 0;
    io?.disconnect(); io = null;
    rowIO?.disconnect(); rowIO = null;
    rowSizes?.disconnect(); rowSizes = null;
    const restoredRows = [...rows.keys()].filter(row => row.classList.contains('light-ui-dormant'));
    for (const [row] of rows) { row.classList.remove('light-ui-dormant'); row.style.removeProperty('--light-row-height'); } rows.clear();
    for (const row of restoredRows) window.dispatchEvent(new CustomEvent('light-ui-row-visible', {detail: {row}}));
    listObserver?.disconnect(); listObserver = null;
    for (const record of videos.values()) {
      const {video, audio} = record;
      if (!video.isConnected) { release(record); continue; }
      if (record.preload === null) video.removeAttribute('preload');
      else video.setAttribute('preload', record.preload);
      if (record.audio) video.style.aspectRatio = record.aspectRatio;
      if (audio && record.audioSource && !audio.getAttribute('src')) audio.src = record.audioSource;
      if (!video.getAttribute('src')) video.src = record.source;
    }
    videos.clear();
  }
  function set(value) {
    const next = !!value;
    if (on === next) return;
    on = next;
    try { localStorage.setItem(key, on ? '1' : '0'); } catch (_) {}
    paintMode();
    if (on) start(); else stop();
    window.dispatchEvent(new CustomEvent('light-ui-change', {detail: {enabled: on}}));
  }
  function toggle() {
    set(!on);
    if (typeof window.toast === 'function') {
      window.toast(`Interface: ${on ? 'Lite' : 'Full'} · This Computer Only`, 'info', 4500);
    }
  }
  function bind(button) {
    if (!button) return;
    button.dataset.lightUiToggle = '';
    button.title = 'This computer only. Same controls and output quality; less background decoration and fewer idle video decoders.';
    let down = null, dragged = false;
    button.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      down = event.clientX; dragged = false; button.setPointerCapture(event.pointerId);
    });
    button.addEventListener('pointerup', event => {
      if (down === null) return;
      const delta = event.clientX - down; down = null;
      if (Math.abs(delta) > 7) { dragged = true; set(delta > 0); }
      if (button.hasPointerCapture(event.pointerId)) button.releasePointerCapture(event.pointerId);
    });
    button.addEventListener('pointercancel', () => { down = null; dragged = false; });
    button.addEventListener('click', () => { if (dragged) { dragged = false; return; } toggle(); });
    button.addEventListener('keydown', event => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      event.preventDefault(); event.stopPropagation(); set(event.key === 'ArrowRight');
    });
    paintMode();
  }
  window.LightUI = Object.freeze({enabled: () => on, set, toggle, bind, registerVideo});
  window.addEventListener('keydown', event => {
    if (!event.ctrlKey || !event.altKey || event.shiftKey || event.metaKey || event.code !== 'KeyL'
        || event.repeat || event.isComposing || event.getModifierState?.('AltGraph')) return;
    // Ctrl+Alt is also AltGr on some international keyboard layouts. Never intercept text entry.
    if (event.target?.closest?.('input,textarea,select,[contenteditable="true"]')) return;
    event.preventDefault(); event.stopImmediatePropagation(); toggle();
  }, true);
  document.addEventListener('visibilitychange', () => {
    if (!on) return;
    for (const record of videos.values()) {
      if (record.near && !document.hidden) attach(record); else release(record);
    }
  });
  window.addEventListener('storage', event => {
    if (event.key === key) set(event.newValue === '1');
  });
  window.addEventListener('scroll', () => { if (on && settleTimer) settle(); }, {passive: true});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();
