/* Ordered references share one prompt and a timed sequence of connected jobs. */
(() => {
  const busy = s => ['queued','generating'].includes(s.video?.status);
  const norm = text => String(text||'').trim().replace(/\s+/g,' ');
  function unavailable(s) {
    if(!s)return 'This scene is no longer available.';
    if(s.speaker_clip)return 'This scene already uses a spokesperson video.';
    if((typeof s.sentence_draft==='string' && norm(s.sentence_draft)!==norm(s.vo)) ||
       (s.editorial_insert===true && !norm(s.vo) && !s.editorial_timing))return 'Finish saving this scene’s sentence first.';
    const im=s.image||{}, file=im.approved_file||im.file;
    if(!s.approved||!file)return 'Approve this scene’s image first.';
    if(im.stock_assets?.[file]?.type==='video')return 'This scene already uses a stock video.';
    return '';
  }
  const eligible = s => !unavailable(s);
  const selectedUids = () => {
    const selected=new Set([...VSEL].map(String));
    return (DOC?.scenes||[]).filter(s=>selected.has(String(s.id))).map(s=>s.uid);
  };
  const node = (tag, text, cls) => { const e=document.createElement(tag); if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e; };
  const button = (text, action, cls='ghost') => {const b=node('button',text,cls);b.type='button';b.onclick=action;return b;};
  const groupScenes = s => s.video_link ? (DOC?.scenes||[]).filter(x=>s.video_link.scene_uids.includes(x.uid)) : [s];
  function syncPrompt(s, text) {
    for(const member of groupScenes(s)) {
      member.video_desc=text;member.video_prompt='';
      const input=document.querySelector(`#videosList [data-uid="${CSS.escape(member.uid)}"] .video-desc`);
      if(input&&input!==document.activeElement)input.value=text;
    }
  }
  async function call(project, path, body) {
    const r=await fetch(`/api/scenes/${encodeURIComponent(project)}/video-links${path}`,{
      method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data=await r.json();if(!r.ok||data.error)throw Error(data.error||'Could not save the video link.');return data;
  }
  function decorate(el,s) {
    if(!eligible(s))return;
    const line=node('div',undefined,'linked-video-banner');
    const names=groupScenes(s).map(x=>'#'+x.id).join(' → ');
    const b=button(s.video_link?`🔗 ${names}`:'🔗 Link Images',()=>{
      const selected=selectedUids();open(s.video_link?.scene_uids||(selected.includes(s.uid)?selected:[s.uid]));
    });
    b.title=s.video_link?'Edit linked image order and narration timing':'Create one Grok video from selected images';
    line.append(b);
    if(s.video_link) {
      const seconds=s.video_link.frames&&s.video_link.fps?s.video_link.frames/s.video_link.fps:s.video_dur;
      const count=s.video_link.generation_count||1;
      line.append(node('span',`One video · ${Number(seconds).toFixed(2)}s · ${count===1?'1 generation':count+' connected generations'} · Grok 1.5`,'hint'));
      if(s.video_link.output_mode==='upscale')line.append(node('span','1080p output · Generated at 720p','hint'));
      else if(s.video_res==='1080p')line.append(node('span','Choose a supported quality in Link Images: 720p or 1080p upscaled output.','hint'));
      for(const selector of ['.dur-dd','.vmodel-dd','.res-dd']) {
        const control=el.querySelector(selector);if(!control)continue;
        control.style.pointerEvents='none';control.setAttribute('aria-disabled','true');
        control.querySelectorAll('button,summary,input,select').forEach(x=>{x.disabled=true;x.tabIndex=-1;});
        control.title='Linked duration follows the voice-over. Quality is set in Link Images.';
      }
    }
    const take=s.video?.linked_takes?.[s.video?.file];
    if(take?.master)line.append(button('↓ Full video',()=>downloadMedia(take.master,`linked-scenes-${s.id}.mp4`,'Linked video')));
    el.querySelector('.video-desc')?.closest('label')?.before(line);
    if(s.video?.link_wait_token&&busy(s)){
      const badge=el.querySelector('.vid-status'),p=s.video.link_progress;
      if(badge)badge.textContent=p?`⏳ Linked video · Part ${p.part}/${p.total}`:'⏳ Linked video generating…';
    }
  }
  async function open(initial) {
    if(!PROJECT)return;
    document.getElementById('linkedVideoModal')?.remove();
    const context=musicContext();
    const all=[...DOC.scenes], byUid=new Map(all.map(s=>[s.uid,s]));
    const selected=new Set(initial), missing=[...selected].some(u=>!byUid.has(u));
    let uids=all.filter(s=>selected.has(s.uid)).map(s=>s.uid), images=[];
    const firstLink=byUid.get(uids[0])?.video_link;
    const existing=firstLink && uids.every(u=>firstLink.scene_uids.includes(u)) ? firstLink : null;
    if(existing)uids=[...existing.scene_uids];
    images=[...(existing?.image_uids||uids)];
    let currentPlan=null, revision=0, saving=false;
    const overlay=node('div',undefined,'linked-video-modal');overlay.id='linkedVideoModal';
    const card=node('section',undefined,'linked-video-dialog');card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');
    card.setAttribute('aria-label','Link images into one video');
    const close=()=>{if(saving)return;overlay.remove();document.removeEventListener('keydown',key);};
    const key=e=>{if(e.key==='Escape')close();};document.addEventListener('keydown',key);
    const head=node('div',undefined,'linked-video-head');head.append(node('h3','Link Images · Grok 1.5'),button('×',close));
    const intro=node('p','Your selected scenes appear below in script order. One continuous video starts with the first image, follows each sentence’s timing and ends with the last image.','hint');
    const addRow=node('div',undefined,'linked-video-add'), select=node('select'), startLabel=node('strong');
    select.setAttribute('aria-label','End scene');
    select.onchange=()=>{
      const start=all.findIndex(s=>s.uid===uids[0]),end=all.findIndex(s=>s.uid===select.value);
      if(start<0||end<start)return;
      uids=all.slice(start,end+1).map(s=>s.uid);images=[...uids];paint();
    };
    const endLabel=node('label','End scene ');endLabel.append(select);addRow.append(startLabel,endLabel);
    const quality=node('select');quality.setAttribute('aria-label','Linked video quality');
    for(const [value,label] of [['','Choose quality…'],['480p','480p'],['720p','720p'],['1080p-upscaled','1080p output · Upscaled from 720p']]){
      const option=node('option',label);option.value=value;option.disabled=!value;quality.append(option);
    }
    const oldQuality=byUid.get(uids[0])?.video_res;
    quality.value=existing?.output_mode==='upscale'?'1080p-upscaled':oldQuality==='1080p'?'':oldQuality||'720p';addRow.append(quality);
    const qualityBody=()=>({resolution:quality.value==='1080p-upscaled'?'1080p':quality.value,output_mode:quality.value==='1080p-upscaled'?'upscale':'native'});
    const rows=node('div',undefined,'linked-video-rows'), status=node('p','', 'linked-video-status');status.setAttribute('role','status');
    const parts=node('div',undefined,'linked-video-parts');
    const caveat=node('p','2–5 consecutive scenes · up to 75s total. Over 15s uses connected generations; each continuation starts from the preceding video’s final frame. Review the generated motion before approving.','hint');
    const reorder=button('Change image order',()=>{showOrder=!showOrder;paint();});
    let showOrder=images.some((u,i)=>u!==uids[i]);
    const foot=node('div',undefined,'linked-video-foot');
    const save=button('Link Images',async()=>{
      if(saving||!currentPlan||!musicCurrent(context))return;
      saving=true;save.disabled=true;
      try {
        if(!(await saveBeforeGeneration(context))||!musicCurrent(context))return;
        const baseline=_docCopy(DOC);
        const result=await call(context.project,'',{uids,image_uids:images,...qualityBody()});
        if(!musicCurrent(context))return;
        _keepPendingEdits(result.doc,baseline,DOC);adoptDocInPlace(result.doc);renderVideos();
        saving=false;close();toast('Images linked. Generate Prompt on any linked scene.','ok');
      } catch(e){status.textContent=e.message;}finally{saving=false;save.disabled=!currentPlan;}
    },'primary');
    if(existing)foot.append(button('Unlink',async()=>{
      if(saving||!musicCurrent(context))return;saving=true;
      try{
        if(!(await saveBeforeGeneration(context))||!musicCurrent(context))return;
        const baseline=_docCopy(DOC), result=await call(context.project,'/remove',{uid:uids[0]});
        if(!musicCurrent(context))return;
        _keepPendingEdits(result.doc,baseline,DOC);adoptDocInPlace(result.doc);renderVideos();saving=false;close();
      }catch(e){status.textContent=e.message;}finally{saving=false;}
    }));
    foot.append(button('Cancel',close),save);card.append(head,intro,addRow,rows,reorder,status,parts,caveat,foot);overlay.append(card);document.body.append(overlay);
    overlay.onclick=e=>{if(e.target===overlay)close();};
    async function review() {
      const check=++revision;currentPlan=null;save.disabled=true;parts.replaceChildren();
      if(missing){status.textContent='The selected scenes changed. Close this window and select them again.';return;}
      const invalid=uids.map(u=>byUid.get(u)).find(s=>unavailable(s));
      if(invalid){status.textContent=`Scene #${invalid.id}: ${unavailable(invalid)}`;return;}
      if(uids.length<2){status.textContent=uids.length?'Choose the last scene above to extend this sequence.':'Select consecutive scene cards, then click Link Images.';return;}
      if(uids.length>5){status.textContent='Grok supports up to five linked images. Choose an earlier end scene.';return;}
      const positions=uids.map(u=>all.findIndex(s=>s.uid===u));
      if(positions.some((p,i)=>i && p!==positions[i-1]+1)){status.textContent='Select consecutive scenes without gaps. The end-scene selector can include the scenes between them.';return;}
      if(uids.some(u=>busy(byUid.get(u)))){status.textContent='Wait for these scenes’ video generation to finish before changing their link.';return;}
      if(!quality.value){status.textContent='Grok linked images generate at up to 720p. Choose 720p, or 1080p output upscaled from 720p; native 1080p is unavailable for this mode.';return;}
      status.textContent='Reading voice-over timing…';
      try{
        if(!(await saveBeforeGeneration(context))||!musicCurrent(context))return;
        const r=await call(context.project,'/plan',{uids,image_uids:images,...qualityBody()});
        if(check!==revision||!overlay.isConnected||!musicCurrent(context))return;
        currentPlan=r.plan;save.disabled=false;
        const p=r.plan,count=p.generation_count||1;
        status.textContent=`Scenes #${byUid.get(uids[0]).id}–#${byUid.get(uids.at(-1)).id} · Total video: ${p.seconds.toFixed(2)}s · ${count===1?'One generation':count+' connected generations'}`;
        if(p.estimated_credits!=null){
          const sourceQuality=p.resolution||qualityBody().resolution;
          const estimate=node('p',`Estimated ${Number(p.estimated_credits).toLocaleString('en-US')} credits · ${p.billed_seconds}s generated at ${sourceQuality}${p.output_mode==='upscale'?' · 1080p output':''}`,'hint');
          estimate.title=`Kie rate: ${p.credit_rate} credits/s, checked ${p.pricing_checked||'2026-11-12'}. Includes whole-second rounding and continuation frames; retries are additional.`;
          parts.append(estimate);
          if(p.output_mode==='upscale')parts.append(node('p','1080p output is resized locally from 720p; it is not native 1080p generation.','hint'));
        }
        if(count>1)for(const c of p.chunks||[]){
          parts.append(node('div',`Part ${c.index+1}: ${(c.start_frame/p.fps).toFixed(2)}–${(c.end_frame/p.fps).toFixed(2)}s · ${c.duration}s generation${c.index?' · Continues from previous part':''}`,'hint'));
        }
        r.plan.slots.forEach((slot,i)=>{const timing=rows.children[i]?.querySelector('.linked-video-time');
          if(timing)timing.textContent=`${(slot.frames/r.plan.fps).toFixed(2)}s · Video ${(slot.offset_frame/r.plan.fps).toFixed(2)}–${((slot.offset_frame+slot.frames)/r.plan.fps).toFixed(2)}s · Voice-over ${(slot.start_frame/r.plan.fps).toFixed(2)}–${(slot.end_frame/r.plan.fps).toFixed(2)}s`;});
      }catch(e){if(check===revision&&overlay.isConnected)status.textContent=e.message;}
    }
    function paint() {
      rows.replaceChildren();select.replaceChildren();
      const first=byUid.get(uids[0]), start=all.findIndex(s=>s.uid===uids[0]);
      startLabel.textContent=first?`Start: Scene #${first.id}`:'No scenes selected';
      let blocked='';
      for(const s of (start<0?[]:all.slice(start,start+5))){
        blocked=blocked || unavailable(s) || (busy(s)?'Video generation is running.':'') || (s.video_link && s.video_link.id!==existing?.id?'Already in another link.':'');
        const o=node('option',`#${s.id}${blocked?' · '+blocked:''}`);o.value=s.uid;o.disabled=!!blocked;select.append(o);
      }
      select.value=uids.at(-1)||'';select.disabled=!!existing||!first;
      reorder.hidden=uids.length<2;reorder.textContent=showOrder?'Keep this image order':'Change image order';
      uids.forEach((uid,i)=>{
        const target=byUid.get(uid), source=byUid.get(images[i]);if(!target||!source)return;
        const row=node('div',undefined,'linked-video-row'), thumb=node('img');
        thumb.src=thumbUrl(source.image.approved_file||source.image.file);thumb.alt=`Image from scene ${source.id}`;
        const info=node('div');info.append(node('strong',`Scene #${target.id}${i===0?' · First frame':i===uids.length-1?' · Last frame':''}`),node('p',target.vo||''),node('span','', 'linked-video-time'),node('small',`Image from #${source.id}`));
        const reason=unavailable(target);if(reason){row.classList.add('unavailable');info.append(node('small',reason,'linked-video-error'));}
        const controls=node('div',undefined,'linked-video-order');
        const swap=j=>{[images[i],images[j]]=[images[j],images[i]];paint();};
        const up=button('↑',()=>swap(i-1)), down=button('↓',()=>swap(i+1));
        up.disabled=i===0;down.disabled=i===uids.length-1;
        up.setAttribute('aria-label',`Move image ${source.id} earlier`);down.setAttribute('aria-label',`Move image ${source.id} later`);
        controls.append(up,down);
        controls.hidden=!showOrder;
        row.append(thumb,info,controls);rows.append(row);
      });
      void review();
    }
    quality.onchange=()=>review();paint();
  }
  document.getElementById('vidSelLink')?.addEventListener('click',()=>open(selectedUids()));
  window.LinkedVideo={open,decorate,syncPrompt};
})();
