/* GPU colour lookup sampled from the production FFmpeg grade. Text stays above it. */
window.LiveGrade = (() => {
  function mount(host,source,repaint,onError){
    let canvas=null,gl=null,program=null,textures=[],images=[],dead=false,reported=false,lastTable=null;
    const tables=new Map();
    const fail=()=>{if(!reported){reported=true;onError('The preview colour filter could not load.');}};
    function init(){
      if(canvas)return !!gl;
      canvas=document.createElement('canvas');canvas.className='live-grade';canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;';host.append(canvas);
      gl=canvas.getContext('webgl',{alpha:false,antialias:false,preserveDrawingBuffer:false});
      if(!gl){fail();canvas.hidden=true;return false;}
      const shader=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
      try{
        const vs=shader(gl.VERTEX_SHADER,'attribute vec2 p; varying vec2 uv; void main(){uv=(p+1.0)*0.5;gl_Position=vec4(p,0.0,1.0);}');
        const fs=shader(gl.FRAGMENT_SHADER,`precision highp float;
          varying vec2 uv; uniform sampler2D picture; uniform sampler2D lut; uniform vec2 size; uniform float angle;
          vec3 sampleLut(vec3 c,float b){vec2 tile=vec2(mod(b,8.0),floor(b/8.0));return texture2D(lut,(tile*64.0+c.rg*63.0+0.5)/512.0).rgb;}
          void main(){vec2 pos=vec2(uv.x,1.0-uv.y);vec3 c=texture2D(picture,pos).rgb;float b=c.b*63.0;
            vec3 graded=mix(sampleLut(c,floor(b)),sampleLut(c,ceil(b)),fract(b));
            float r=length((pos-0.5)*size)/length(size*0.5);float vignette=pow(cos(r*angle),4.0);
            gl_FragColor=vec4(graded*vignette,1.0);}`);
        program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
        const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
        const p=gl.getAttribLocation(program,'p');gl.enableVertexAttribArray(p);gl.vertexAttribPointer(p,2,gl.FLOAT,false,0,0);
        for(let i=0;i<2;i++){const tex=gl.createTexture();textures.push(tex);gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,tex);
          gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);}
        gl.uniform1i(gl.getUniformLocation(program,'picture'),0);gl.uniform1i(gl.getUniformLocation(program,'lut'),1);
      }catch(_){fail();canvas.hidden=true;gl=null;return false;}
      return true;
    }
    function table(youtube){
      const key=youtube?'youtube':'vsl';if(tables.has(key))return tables.get(key);
      tables.set(key,null);const im=new Image();im.crossOrigin='anonymous';images.push(im);im.onload=()=>{if(dead)return;tables.set(key,im);repaint();};im.onerror=fail;
      im.src='/static/preview-grade-'+key+'.png';return null;
    }
    function paint(enabled,youtube){
      if(dead)return;if(!enabled){if(canvas)canvas.hidden=true;source.style.visibility='';return;}
      if(!init())return;const im=table(youtube);if(!im){canvas.hidden=true;return;}
      if(canvas.width!==source.width||canvas.height!==source.height){canvas.width=source.width;canvas.height=source.height;}
      try{
      canvas.hidden=false;source.style.visibility='hidden';gl.viewport(0,0,canvas.width,canvas.height);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,textures[0]);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,source);
      gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,textures[1]);if(lastTable!==im){gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,im);lastTable=im;}
      gl.uniform2f(gl.getUniformLocation(program,'size'),canvas.width,canvas.height);gl.uniform1f(gl.getUniformLocation(program,'angle'),Math.PI/(youtube?7:14));gl.drawArrays(gl.TRIANGLES,0,6);
      }catch(_){canvas.hidden=true;source.style.visibility='';fail();}
    }
    function clear(){dead=true;for(const im of images){im.onload=null;im.onerror=null;}if(gl){textures.forEach(t=>gl.deleteTexture(t));gl.deleteProgram(program);gl.getExtension('WEBGL_lose_context')?.loseContext();}canvas?.remove();source.style.visibility='';}
    return {paint,clear};
  }
  return {mount};
})();
