/* Independent upload -> optional Trim -> transcription. Scoped to the current project/workshop. */
window.AudioPrep = class AudioPrep {
  constructor(host, options) {
    this.host=host; this.o=options; this.state=null; this.epoch=0; this.pending=false; this.timer=null; this.key='';
    host.innerHTML=`<div class="audio-prep-row"><select class="audio-prep-pace" aria-label="Trim Pace"><option value="slow">Slow</option><option value="natural" selected>Natural</option><option value="fast">Fast</option></select><button type="button" class="ghost audio-prep-trim">✂ Trim Silences</button><button type="button" class="ghost audio-prep-original" hidden>Use Original</button><button type="button" class="ghost audio-prep-download" hidden>⬇ Download Audio</button></div><div class="audio-prep-status hint" aria-live="polite"></div><audio class="audio-prep-player" controls preload="none" hidden></audio>`;
    this.button=host.querySelector('.audio-prep-trim');this.pace=host.querySelector('select');this.original=host.querySelector('.audio-prep-original');this.download=host.querySelector('.audio-prep-download');this.player=host.querySelector('audio');this.label=host.querySelector('.audio-prep-status');
    this.button.onclick=()=>this.run();this.original.onclick=()=>this.choose();this.download.onclick=()=>{const c=this.capture();if(this.ref())this.o.download(this.url(c,'file/'+this.ref())+'?download=1',this.name());};
  }
  capture() {
    const c=this.o.context();
    if(this.key!==c.key){this.reset();this.key=c.key;}
    const epoch=this.epoch;
    return {...c,valid:()=>this.key===c.key&&this.epoch===epoch&&c.current()};
  }
  reset(){this.epoch++;clearTimeout(this.timer);this.timer=null;this.pending=false;this.state=null;this.key='';this.failedUpload=false;if(this.toast)this.toast.close();this.toast=null;this.player.pause();this.player.removeAttribute('src');delete this.player.dataset.source;this.player.hidden=true;this.paint();}
  url(c,tail){return '/api/audio-prep/'+c.area+'/'+encodeURIComponent(c.scope)+'/'+tail;}
  ref(){return this.state?.ref||'';}
  name(){const s=this.state;return s?.selected==='trimmed'?(s.name.replace(/\.[^.]+$/,'')+'_Trimmed.wav'):(s?.name||'voiceover.wav');}
  busy(){return this.pending||this.state?.status==='running';}
  ready(){return !this.busy()&&!this.failedUpload;}
  async request(c,tail,options){const r=await fetch(this.url(c,tail),options);let s;try{s=await r.json();}catch(_){throw Error('Audio preparation could not be reached.');}if(!r.ok)throw Error(s.error||'Audio preparation failed.');return s;}
  async load(){const c=this.capture();if(!c.scope||this.pending)return;try{const s=await this.request(c,'status');if(c.valid()){this.state=s;this.paint();if(s.status==='running')this.poll(c);}}catch(e){if(c.valid())this.label.textContent=e.message;}}
  async upload(file){if(!file)return;let c=this.capture();if(this.busy()||this.o.blocked?.()){this.paint();this.o.message('Wait for the current audio operation to finish.','warn');return;}this.epoch++;c=this.capture();this.pending=true;this.failedUpload=true;this.paint();this.label.textContent='Uploading Audio…';
    try{const fd=new FormData();fd.append('audio',file);const s=await this.request(c,'upload',{method:'POST',body:fd});if(!c.valid())return;this.state=s;this.failedUpload=false;this.o.uploaded?.(s);this.o.message('Voice-over Uploaded. Trim is optional.','ok');}
    catch(e){if(c.valid())this.o.message(e.message,'err');}
    finally{if(c.valid()){this.pending=false;this.paint();}}
  }
  async run(){const c=this.capture();if(this.pending)return;if(this.o.blocked?.()){this.o.message('Wait for subtitle generation to finish first.','warn');return;}if(!this.ref())return;this.pending=true;this.paint();
    try{const s=await this.request(c,this.state.status==='running'?'cancel':'trim',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ref:this.ref(),mode:this.pace.value})});if(c.valid()){this.state=s;this.paint();if(this.state.status==='running')this.poll(c);}}
    catch(e){if(c.valid())this.o.message(e.message,'err');}
    finally{if(c.valid()){this.pending=false;this.paint();}}
  }
  async choose(){const c=this.capture();if(this.busy()||this.o.blocked?.())return;this.pending=true;this.paint();try{const s=await this.request(c,'select',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ref:this.ref(),selected:this.state.selected==='trimmed'?'original':'trimmed'})});if(c.valid()){this.state=s;this.paint();}}catch(e){if(c.valid())this.o.message(e.message,'err');}finally{if(c.valid()){this.pending=false;this.paint();}}}
  poll(c){clearTimeout(this.timer);if(!c.valid())return;this.timer=setTimeout(async()=>{try{const s=await this.request(c,'status');if(!c.valid())return;this.state=s;this.paint();if(s.status==='running')this.poll(c);else this.o.message(s.error|| (s.has_trimmed?'Trim Complete. Selected audio is ready.':'Trim Stopped. Original Audio Selected.'),s.error?'err':'ok');}catch(e){if(c.valid()){this.label.textContent='Checking Trim Status…';this.poll(c);}}},700);}
  paint(){const s=this.state,busy=s?.status==='running';this.button.textContent=busy?'⏹ Stop Trim':'✂ Trim Silences';this.button.disabled=this.pending||!s?.ref||(!busy&&s.has_trimmed);this.pace.disabled=busy||this.pending||!!s?.has_trimmed;this.original.hidden=!s?.has_trimmed;this.original.disabled=this.busy();this.original.textContent=s?.selected==='trimmed'?'Use Original':'Use Trimmed';this.download.hidden=!s?.ref;this.download.disabled=this.busy();
    if(busy){this.player.pause();if(!this.toast)this.toast=this.o.progress('Trimming Silences…',()=>this.run());this.toast.update(s.step||'Trimming Silences…',s.pct);this.label.textContent=s.step||'Trimming Silences…';}
    else{if(this.toast)this.toast.close();this.toast=null;this.label.textContent=s?.error||(s?.has_trimmed?`${s.selected==='trimmed'?'Trimmed':'Original'} Audio Selected · ${Number(s.removed_seconds||0).toFixed(1)}s of quiet gaps removed · Original kept`:(s?.ref?'Original Audio Selected · Trim before generating subtitles.':''));}
    if(s?.ref){const c=this.o.context(),url=this.url(c,'file/'+s.ref);if(this.player.dataset.source!==url){this.player.pause();this.player.src=url;this.player.dataset.source=url;}this.player.hidden=false;this.o.named?.(this.name());}else this.player.hidden=true;
    this.o.changed?.();
  }
};

// Cards keep their existing upload/align pipeline. Only the selected prepared file is handed to it.
window.prepareVoiceFile = function(file, options) {
  return new Promise(async resolve => {
    if(!options.current()) { resolve(null); return; }
    const bg=document.createElement('div');bg.className='modal-bg audio-prep-modal';bg.innerHTML='<div class="modal" role="dialog" aria-modal="true" aria-label="Prepare Voice-over"><h2>Prepare Voice-over</h2><p class="hint">Trim quiet gaps before syncing captions. Your original recording is kept.</p><div class="audio-prep"></div><div class="modal-actions"><button type="button" class="ghost prep-cancel">Cancel</button><button type="button" class="primary prep-use" disabled>Use Audio</button></div></div>';
    document.body.appendChild(bg);const host=bg.querySelector('.audio-prep'),use=bg.querySelector('.prep-use'),cancel=bg.querySelector('.prep-cancel');let closed=false,ctl;
    const current=()=>!closed&&options.current();
    const end=value=>{if(closed)return;closed=true;clearInterval(watch);ctl?.reset();bg.remove();document.removeEventListener('keydown',key);resolve(value);};
    const key=e=>{if(e.key==='Escape'&&!ctl.busy())end(null);};document.addEventListener('keydown',key);
    const watch=setInterval(()=>{if(!options.current())end(null);},500);
    ctl=new AudioPrep(host,{context:()=>({area:'slot',scope:options.key,key:options.key,current}),message:options.message,progress:options.progress,
      download:(url,name)=>{const a=document.createElement('a');a.href=url;a.download=name;a.click();},
      changed:()=>{use.disabled=!ctl?.ref()||!ctl.ready();cancel.disabled=!!ctl?.pending;}});
    cancel.onclick=async()=>{if(ctl.state?.status==='running'){try{await ctl.request(ctl.capture(),'cancel',{method:'POST'});}catch(e){options.message(e.message,'warn');return;}}end(null);};
    use.onclick=async()=>{if(!current()||!ctl.ready())return;ctl.pending=true;ctl.paint();
      try{const ref=ctl.ref(),c=ctl.capture();const r=await fetch(ctl.url(c,'file/'+ref));if(!r.ok)throw Error('Prepared audio is unavailable.');const blob=await r.blob();if(!current()||ref!==ctl.ref())return;const out=new File([blob],ctl.name(),{type:blob.type});out.preparedRef=ref;end(out);}
      catch(e){if(current())options.message(e.message,'err');}
      finally{if(current()){ctl.pending=false;ctl.paint();}}
    };
    if(options.reuseRef){await ctl.load();if(!current())return;if(ctl.ref()!==options.reuseRef)await ctl.upload(file);}else await ctl.upload(file);
  });
};
