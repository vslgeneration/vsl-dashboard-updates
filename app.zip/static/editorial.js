// Account preferences, project overrides and evidence. Opening never generates or edits a project.
(() => {
  const trigger = document.getElementById('editorPrefsBtn');
  if (!trigger) return;
  let open = null, resume = null;
  const el = (tag, text, cls) => { const n = document.createElement(tag); if (text) n.textContent = text; if (cls) n.className = cls; return n; };
  trigger.addEventListener('click', async () => {
    if (!PROJECT || open) return;
    const owner = musicContext(), project = PROJECT;
    const returning=resume&&musicCurrent(resume.owner)?resume:null;resume=null;
    const drafts = []; let saving = 0, rememberView=()=>{}, lastReview=null;
    const box = el('dialog', '', 'editor-prefs'); open = box;
    const close = () => { if(musicCurrent(owner))rememberView();box.close(); box.remove(); if (open === box) open = null; trigger.focus({preventScroll:true}); };
    box.addEventListener('cancel', e => { e.preventDefault(); requestClose(); });
    const head = el('div', '', 'editor-prefs-head'); head.append(el('h2','Automatic Editing Preferences'));
    const x = el('button','Close','ghost'); x.onclick = ()=>requestClose(); head.append(x); box.append(head);
    const status = el('p','Reading preferences and local examples…'); box.append(status);
    document.body.append(box); box.showModal();
    const current = () => open === box && musicCurrent(owner);
    // Navigation must not discard drafts from any section of this dialog.
    const reveal = node => {
      for(let p=node.parentElement;p&&p!==box;p=p.parentElement){p.hidden=false;if(p.tagName==='DETAILS')p.open=true;}
      node.scrollIntoView({block:'center'});node.focus({preventScroll:true});
    };
    const navigationStatus=el('p');navigationStatus.setAttribute('role','status');box.append(navigationStatus);
    const closeWarning=el('div','','editor-close-warning');closeWarning.hidden=true;
    closeWarning.append(el('p','You have unsaved changes. Return to editing, or discard the changes and close.'));
    const stay=el('button','Return to editing','ghost'),discard=el('button','Discard changes and close','ghost');
    stay.onclick=()=>{closeWarning.hidden=true;const d=drafts.find(d=>d.dirty());if(d)reveal(d.node);};
    discard.onclick=()=>{if(!saving)close();};closeWarning.append(stay,discard);box.append(closeWarning);
    const requestClose=()=>{
      if(!current()){close();return;}
      if(saving){navigationStatus.textContent='Saving in progress. You can close this when it finishes.';return;}
      if(drafts.some(d=>d.dirty())){closeWarning.hidden=false;closeWarning.scrollIntoView({block:'center'});stay.focus({preventScroll:true});return;}
      close();
    };
    const sceneButton = (uid,reviewId=null) => {
      const target=uid&&(DOC?.scenes||[]).find(s=>s.uid===uid);
      const go=el('button',target?'Current scene #'+target.id+' →':uid?'Scene no longer exists':'Scene record is unknown','ghost');
      go.disabled=!target;
      go.onclick=()=>{
        if(!current())return;
        const latest=(DOC?.scenes||[]).find(s=>s.uid===uid);
        if(!latest){go.disabled=true;go.textContent='Scene no longer exists';return;}
        if(saving){navigationStatus.textContent='Saving in progress. You can open the scene when it finishes.';return;}
        const draft=drafts.find(d=>d.dirty());
        if(draft){
          const message='Before opening the scene, save or revert '+draft.label+'. Your edits are kept here.';
          navigationStatus.textContent=message;draft.message.textContent=message;reveal(draft.node);return;
        }
        if (!document.getElementById('modalBg').hidden) {
          navigationStatus.textContent='Close this review and Settings first, then open Scene '+latest.id+'. Your Settings edits are kept.';
          navigationStatus.scrollIntoView({block:'center'});return;
        }
        lastReview=reviewId;close();
        jumpToScene(latest.id);
      };
      return go;
    };
    let state;
    try {
      const r = await fetch('/api/editor-profile/'+encodeURIComponent(project)); state = await r.json();
      if (!current()) { if (open === box) close(); return; }
      if (!r.ok || state.error) throw Error(state.error || 'Could not read preferences.');
    } catch(e) { if(current())status.textContent=e.message; return; }
    status.textContent = 'Already applied automatically to future scene planning, AI prompts, stock suggestions and image checks. Editing these rules is optional. Project preferences override global defaults; explicit scene settings, references and RAW/PURE remain in control. Past examples are used only when selected and relevant.';
    const field = (label,value,placeholder) => {
      const l=el('label',label), t=el('textarea');t.value=value||'';t.maxLength=6000;t.rows=5;t.placeholder=placeholder;
      l.append(t);box.append(l);return t;
    };
    const global = field('My global editing preferences',state.global_rules,'Example: Show a concrete action from everyday life instead of an abstract feeling of trust.');
    const local = field(project+' — project preferences',state.project_rules,'Rules for this project only; other projects are not affected.');
    const report=state.experience, validIds=new Set(report.examples.map(e=>e.id)), selected=new Set((state.example_ids||[]).filter(id=>validIds.has(id)));
    const exampleNotes={...(state.example_notes||{})}, editSuggestions=new Map(), suggestionViews=new Map();
    const selectedNotes=()=>Object.fromEntries([...selected].sort().filter(id=>(exampleNotes[id]||'').trim()).map(id=>[id,exampleNotes[id]]));
    const preferenceSnapshot=()=>JSON.stringify([global.value,local.value,[...selected].sort(),selectedNotes()]);
    let savedPreferences=preferenceSnapshot();
    drafts.push({dirty:()=>preferenceSnapshot()!==savedPreferences,node:global,message:status,label:'your editing preferences / example selections'});
    const details=el('details'), summary=el('summary','Examples from past projects');details.append(summary);
    details.append(el('p','All projects are scanned; trials without narration, approval or sufficient records are excluded. Older examples are only candidates: leave unrelated or random trials unselected. Only the relevant storytelling technique from selected examples is added to new direction. Generation-time RAW/PURE and other settings are shown only when recorded for that image.'));
    details.append(el('p','Note what you like about a selected example, such as “showing delivery through a concrete action at the door”. Notes are used only for matching examples; the new project subject, product and explicit settings take priority. Use Save preferences to save notes. Deselecting an example and saving also removes its note.'));
    const search=el('input');search.type='search';search.placeholder='Search project, scene, text or RAW/PURE';details.append(search);
    const count=el('p'), list=el('div','','editor-example-list');details.append(count,list);
    let page=0; const pages=el('div','','editor-prefs-actions'),prev=el('button','Previous','ghost'),next=el('button','Next','ghost'),clear=el('button','Clear selection','ghost');
    const only=el('label','Selected only'),onlyTick=el('input');onlyTick.type='checkbox';only.prepend(onlyTick);details.append(only);
    pages.append(prev,next,clear);details.append(pages);
    const paint=()=>{
      suggestionViews.clear();
      const q=search.value.toLocaleLowerCase(); const all=report.examples.filter(e=>(!onlyTick.checked||selected.has(e.id))&&[e.project,e.scene,e.vo,e.prompt,e.mode].join(' ').toLocaleLowerCase().includes(q));
      page=Math.min(page,Math.max(0,Math.ceil(all.length/20)-1));prev.disabled=page===0;next.disabled=(page+1)*20>=all.length;
      list.replaceChildren();count.textContent=all.length+' candidates · '+selected.size+'/30 selected · page '+(page+1);
      all.slice(page*20,(page+1)*20).forEach(e=>{
        const card=el('div','','editor-example');const line=el('label');const tick=el('input');tick.type='checkbox';tick.checked=selected.has(e.id);
        const noteLabel=el('label','What matters to me in this example'),note=el('textarea');note.rows=2;note.maxLength=600;note.value=exampleNotes[e.id]||'';note.disabled=!tick.checked;note.placeholder='Which storytelling technique should be used as an example?';noteLabel.append(note);
        note.oninput=()=>{exampleNotes[e.id]=note.value;};
        tick.onchange=()=>{if(tick.checked&&selected.size>=30){tick.checked=false;status.textContent='You can select up to 30 examples.';return;}tick.checked?selected.add(e.id):selected.delete(e.id);note.disabled=!tick.checked;count.textContent=all.length+' candidates · '+selected.size+'/30 selected · page '+(page+1);};
        line.append(tick,el('span',e.project+' · #'+e.scene+' · '+e.mode));
        const img=el('img');img.loading='lazy';img.alt='Approved example — '+e.project+' scene '+e.scene;img.src='/media/'+encodeURIComponent(e.project)+'/'+e.file.split('/').map(encodeURIComponent).join('/');img.style.cssText='width:180px;max-height:110px;object-fit:contain';
        card.append(line,img,el('p',e.vo),el('p',e.prompt),el('small',e.provenance+' '+e.caution),noteLabel);
        if(e.changed&&e.baseline){
          const comparison=el('details');comparison.append(el('summary','Before / after prompt comparison'));
          comparison.append(el('b','Original direction'),el('p',e.baseline),el('b','Selected example prompt'),el('p',e.prompt));card.append(comparison);
          const infer=el('button','Suggest a preference from this change (Claude)','ghost'), suggestionBox=el('div'), suggestionMessage=el('p');
          card.append(infer,suggestionMessage,suggestionBox);
          const display=()=>{
            const entry=editSuggestions.get(e.id)||{};infer.disabled=!selected.has(e.id)||entry.pending===true;
            suggestionMessage.textContent=entry.pending?'Claude is comparing the original and revised prompts…':entry.error||'';
            suggestionBox.replaceChildren();
            if(!entry.result)return;
            const r=entry.result;
            suggestionBox.append(el('p',r.suggestion||'No reliable storytelling preference could be inferred from this change.'),el('p','Evidence: '+r.evidence),el('small',r.caution));
            if(r.suggestion){
              const accept=el('button','Add to example note','ghost');accept.disabled=!selected.has(e.id);
              accept.onclick=()=>{
                if(!current()||!selected.has(e.id))return;
                const old=(exampleNotes[e.id]||'').trim(),added=r.suggestion.trim();
                const value=old.includes(added)?old:[old,added].filter(Boolean).join('\n');
                if(value.length>600){suggestionMessage.textContent='The note exceeds 600 characters. Shorten the existing note or edit the suggestion manually.';return;}
                exampleNotes[e.id]=value;note.value=value;
                status.textContent='The suggestion was added to the example note. It is not used yet; confirm it with Save preferences.';
                accept.disabled=true;
              };suggestionBox.append(accept);
            }
          };
          infer.onclick=async()=>{
            if(!current()||!selected.has(e.id)||editSuggestions.get(e.id)?.pending)return;
            if(saving||preferenceSnapshot()!==savedPreferences){suggestionMessage.textContent='Save your preferences and example selection first.';return;}
            editSuggestions.set(e.id,{pending:true});display();
            try{
              const response=await fetch('/api/editor-edit-suggestion/'+encodeURIComponent(project),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:state.revision,example_id:e.id})});
              const value=await response.json();if(!current())return;
              if(!response.ok||value.error)throw Error(value.error||'Could not prepare the suggestion.');
              editSuggestions.set(e.id,{result:value});
            }catch(err){if(current())editSuggestions.set(e.id,{error:err.message});}
            finally{if(current())suggestionViews.get(e.id)?.();}
          };
          const selectionChange=tick.onchange;tick.onchange=()=>{selectionChange();display();};suggestionViews.set(e.id,display);display();
        }
        const labels={style:'Visual style',camera:'Camera',bg:'Background',split:'Split image',product:'Product',testimonial:'Testimonial',ingredients:'Ingredient references',cast:'Cast',refs:'Attached references',ref_free:'Free references',packs:'Packs',checkout:'Checkout page',showcase:'Product showcase',model:'Model'};
        const settings=Object.entries(e.settings||{}).filter(([k,v])=>labels[k]&&v!==null).map(([k,v])=>labels[k]+': '+(Array.isArray(v)?v.length+' selected':typeof v==='boolean'?(v?'on':'off'):String(v))).join(' · ');if(settings)card.append(el('small',settings));list.append(card);
      });
    };search.oninput=()=>{page=0;paint();};onlyTick.onchange=()=>{page=0;paint();};prev.onclick=()=>{page--;paint();};next.onclick=()=>{page++;paint();};clear.onclick=()=>{selected.clear();paint();};paint();box.append(details);
    const m=report.totals,metrics=el('details');metrics.append(el('summary','Quality metrics — available records'));
    metrics.append(el('p',m.projects+' projects · '+m.scenes+' scenes · '+m.approved+' approved scenes · '+m.first_take_approved+' scenes with the first recorded version approved.'));
    metrics.append(el('p',m.stored_versions+' stored image versions (including uploads/copies) · '+m.changed_prompt_candidates+' changed-prompt candidates.'));
    metrics.append(el('p',report.limits));
    const q=state.metrics;
    if(q){
      metrics.append(el('h3',project+' — new metrics'));
      metrics.append(el('p',q.submitted+' recorded generation submissions · '+q.repeat_submissions+' repeat submissions · '+q.prompt_edits+' prompt edit records.'));
      metrics.append(el('p','First-generation approval: '+(q.first_rate===null?'Not enough records yet':q.first_rate+'% ('+q.first_approved+'/'+q.first_eligible+' completed scenes)')));
      metrics.append(el('p','False alarms among QA warnings you reviewed: '+(q.false_rate===null?'No feedback yet':q.false_rate+'% ('+q.qa_false+'/'+q.qa_reviewed+')')));
      metrics.append(el('p',q.limits));
      const usage=q.usage;
      if(usage){
        const activity=el('details');activity.append(el('summary','Actual usage — where am I doing rework?'));
        activity.append(el('p',usage.note));
        if(!usage.enough)activity.append(el('p','Not enough activity records yet. Generations, edits and approvals will appear here as you use them.'));
        (usage.versions||[]).forEach(v=>activity.append(el('p',`Version ${v.version}: ${v.submitted} generation submissions · ${v.image_edits} image edits · ${v.prompt_edits} prompt changes · ${v.approved_scenes} distinct scenes with approval records`)));
        if(usage.attention?.length)activity.append(el('p','Scenes with the most repeat submissions or edits; this list does not identify defects.'));
        (usage.attention||[]).forEach(s=>{const line=el('p',`${s.repeat_submissions} repeat generations · ${s.image_edits} image edits · ${s.prompt_edits} prompt changes `);
          line.append(sceneButton(s.uid));activity.append(line);});
        metrics.append(activity);
      }
      const feedback=el('details');feedback.append(el('summary','Review QA warning history ('+q.issues.length+')'));
      feedback.append(el('p','Enter a reason and opt in to use it in future image checks for this project. The five most recently saved active reasons are used; genuine defects are still checked. Each review has its own Save button.'));
      feedback.append(el('p','Statuses reflect the selected/approved image when this window opens. Reopen it after changing an image. A matching file does not mean an older review used the current prompt and settings.'));
      const filterLabel=el('label','Image status'),filter=el('select');
      [['all','All statuses'],['current','Latest warning for the current image'],['history','Older image / older review'],['unknown','Unknown source']].forEach(([v,t])=>{const n=el('option',t);n.value=v;filter.append(n);});filter.value=returning?.filter||'all';filterLabel.append(filter);
      const verdictLabel=el('label','Feedback status'),verdict=el('select');
      [['all','All feedback'],['unreviewed','Not reviewed yet'],['valid','Marked valid'],['false_alarm','False alarms']].forEach(([v,t])=>{const n=el('option',t);n.value=v;verdict.append(n);});verdict.value=returning?.verdict||'all';verdictLabel.append(verdict);
      const qaSearch=el('input');qaSearch.type='search';qaSearch.placeholder='Search warnings, scene numbers or reasons';qaSearch.setAttribute('aria-label','Search QA history');qaSearch.value=returning?.search||'';
      const qaCount=el('p');qaCount.setAttribute('role','status');feedback.append(filterLabel,verdictLabel,qaSearch,qaCount);
      const cards=[];let pinnedReview=returning?.reviewId||null;
      const applyFilters=()=>{
        const query=qaSearch.value.trim().toLocaleLowerCase('en-US');let shown=0,preserved=0;
        cards.forEach(r=>{
          const it=r.it,state=it.history_status,ver=it.feedback||'clear';
          const match=(filter.value==='all'||(filter.value==='history'?['older_image','older_review','scene_missing','no_current_image'].includes(state):state===filter.value))
            &&(verdict.value==='all'||(verdict.value==='unreviewed'?ver==='clear':ver===verdict.value))
            &&(!query||[it.current_scene,it.scene,it.issue,it.observation,it.correction,it.feedback_reason].join(' ').toLocaleLowerCase('en-US').includes(query));
          const keep=r.dirty()||it.id===pinnedReview;r.card.hidden=!match&&!keep;if(!r.card.hidden)shown++;if(keep&&!match)preserved++;
        });
        qaCount.textContent=shown+' / '+cards.length+' warnings shown. Filters apply to the latest 50 retrieved warnings.'+(preserved?' Unsaved or revisited warnings also kept visible: '+preserved+'.':'')+(!shown?' No warnings match this filter.':'');
      };
      filter.onchange=verdict.onchange=qaSearch.oninput=()=>{pinnedReview=null;applyFilters();};
      rememberView=()=>{resume={owner,filter:filter.value,verdict:verdict.value,search:qaSearch.value,reviewId:lastReview,metricsOpen:metrics.open,feedbackOpen:feedback.open,scrollTop:box.scrollTop};};
      q.issues.forEach(it=>{
        const card=el('div','','editor-example');
        const sceneLabel=it.current_scene!=null?'Scene #'+it.current_scene+(it.current_scene!==it.scene?' (reviewed as #'+it.scene+')':''):
          it.history_status==='scene_missing'?'Deleted scene (reviewed as #'+it.scene+')':'Scene at review #'+it.scene;
        card.append(el('p',sceneLabel+' · '+it.issue));
        if(it.category_label)card.append(el('p',it.category_label+(it.advisory?' · advice only, not automatically changed':'')));
        const labels={current:'Selected image when opened · latest review of this file',older_image:'Warning for an older image · a different image is selected',older_review:'A newer review exists for this image',scene_missing:'This scene is no longer in the project',no_current_image:'This scene has no selected image',unknown:'Cannot verify which current image this belongs to'};
        card.append(el('p',labels[it.history_status]||labels.unknown));
        card.append(sceneButton(it.uid,it.id));
        card.append(el('small','Opens the current scene without selecting the image from this review. Hidden approved scenes are made visible.'));

        const date=typeof it.ts==='number'&&Number.isFinite(it.ts)?new Date(it.ts*1000):null;
        if(date&&!Number.isNaN(date.getTime()))card.append(el('small','Review: '+date.toLocaleString('en-US')));
        if(it.observation)card.append(el('p','Observation: '+it.observation));
        card.append(el('p',it.basis?.length?'Evidence: '+it.basis.join(', '):'Evidence details were not recorded for this older review.'));
        if(it.correction)card.append(el('p','Suggested correction: '+it.correction));
        if(it.file){const img=el('img');img.loading='lazy';img.alt='Reviewed image';img.src='/media/'+encodeURIComponent(project)+'/'+it.file.split('/').map(encodeURIComponent).join('/');img.style.cssText='width:180px;height:110px;object-fit:contain';img.onerror=()=>{if(!current())return;img.style.visibility='hidden';card.append(el('p','The reviewed image is no longer accessible; no substitute image is shown.'));};card.append(img);}
        const select=el('select');[['clear','Not reviewed yet'],['valid','Valid warning'],['false_alarm','False alarm']].forEach(([v,label])=>{const o=el('option',label);o.value=v;select.append(o);});select.value=it.feedback||'clear';
        select.setAttribute('aria-label',sceneLabel+' — warning feedback');
        const reasonLabel=el('label','My reason'),reason=el('textarea');reason.rows=2;reason.maxLength=800;
        reason.value=it.feedback_reason||'';reason.placeholder='Example: This scene shows the product reflected in a mirror; no second product was added.';reasonLabel.append(reason);
        const applyLabel=el('label','Use in future checks for this project'),apply=el('input');apply.type='checkbox';
        apply.checked=it.feedback_use_in_checks===true;applyLabel.prepend(apply);
        const msg=el('small'),saveFeedback=el('button','Save feedback','ghost');
        const sync=()=>{apply.disabled=select.value!=='false_alarm';if(apply.disabled)apply.checked=false;};sync();
        const feedbackSnapshot=()=>JSON.stringify([select.value,reason.value,apply.checked]);
        let savedFeedback=feedbackSnapshot();
        drafts.push({dirty:()=>feedbackSnapshot()!==savedFeedback,node:reason,message:msg,label:'your warning feedback'});
        cards.push({it,card,dirty:()=>feedbackSnapshot()!==savedFeedback});
        select.onchange=()=>{sync();msg.textContent='Not saved yet.';applyFilters();};
        reason.oninput=apply.onchange=()=>{msg.textContent='Not saved yet.';applyFilters();};
        saveFeedback.onclick=async()=>{
          if(!current()){close();return;}
          if(apply.checked&&!reason.value.trim()){msg.textContent='Enter a reason to use this in future checks.';reason.focus();return;}
          const body={review_id:it.id,verdict:select.value,reason:reason.value.trim(),use_in_checks:apply.checked};
          saving++;[select,reason,apply,saveFeedback].forEach(n=>n.disabled=true);
          try{const r=await fetch('/api/editor-feedback/'+encodeURIComponent(project),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const result=await r.json();if(!current())return;if(!r.ok||result.error)throw Error(result.error||'Could not save');
            if(body.verdict==='clear')reason.value='';
            savedFeedback=feedbackSnapshot();navigationStatus.textContent='';
            it.feedback=body.verdict;it.feedback_reason=body.verdict==='clear'?'':body.reason;applyFilters();
            msg.textContent=body.use_in_checks?'Saved; this will be considered in future image checks for this project.':'Saved; this feedback does not create a rule for future checks.';
          }catch(e){if(current())msg.textContent=e.message+' Your edits are still in this box; you can try saving again.';}
          finally{saving--;if(current()){[select,reason,apply,saveFeedback].forEach(n=>n.disabled=false);sync();}}
        };card.append(select,reasonLabel,applyLabel,saveFeedback,msg);feedback.append(card);
      });metrics.append(feedback);applyFilters();
      if(returning){
        metrics.open=returning.metricsOpen||!!returning.reviewId;feedback.open=returning.feedbackOpen||!!returning.reviewId;
        requestAnimationFrame(()=>{if(!current())return;const card=cards.find(r=>r.it.id===returning.reviewId)?.card;
          if(card){card.tabIndex=-1;card.scrollIntoView({block:'center'});card.focus({preventScroll:true});}
          else{box.scrollTop=returning.scrollTop||0;if(returning.reviewId)navigationStatus.textContent='The previous warning is no longer among the latest 50 records; the current list is shown.';}
        });
      }
    }
    if(report.unreadable.length)metrics.append(el('p',report.unreadable.length+' projects could not be read and are excluded from these counts.'));
    box.append(metrics);
    const trials=el('details');trials.append(el('summary','Test my examples without generation'));
    trials.append(el('p','Saved selected examples, preferences and narration form a test set. This checks the local preference/example text supplied to automatic direction, not AI responses or image quality. It does not generate media or call Claude.'));
    const loadTrials=el('button','Open test set','ghost'),trialStatus=el('p'),trialBody=el('div');trials.append(loadTrials,trialStatus,trialBody);box.append(trials);
    let trialRevision=null,trialInputs=[],trialSaved='';
    const requirements=()=>Object.fromEntries(trialInputs.map(r=>[r.id,{include:r.include.value.split('\n').map(s=>s.trim()).filter(Boolean),exclude:r.exclude.value.split('\n').map(s=>s.trim()).filter(Boolean)}]));
    const trialSnapshot=()=>JSON.stringify(requirements());
    drafts.push({dirty:()=>trialRevision!==null&&trialSnapshot()!==trialSaved,node:trials,message:trialStatus,label:'your test expectations'});
    const showTrialResult=(value)=>{
      trialStatus.textContent=value.result?`${value.result.passed}/${value.result.total} tests passed. Uses saved inputs; current preferences do not automatically change an older set.`:'No saved test set yet.';
      trialBody.querySelectorAll('.trial-result').forEach(n=>n.remove());
      for(const r of value.result?.rows||[]){const detail=el('details','','trial-result');detail.append(el('summary',`${r.passed?'Passed':'Review'} · ${r.project} #${r.scene}`));
        detail.append(el('p',r.unchanged?'The local direction text matches the saved version.':'The local direction text differs from the saved version.'));
        if(r.missing.length)detail.append(el('p','Not found: '+r.missing.join(' · ')));if(r.unwanted.length)detail.append(el('p','Unwanted phrase found: '+r.unwanted.join(' · ')));
        for(const [label,text] of [['Saved direction',r.expected],['Current direction',r.actual]]){const l=el('label',label),t=el('textarea');t.readOnly=true;t.value=text;t.rows=5;l.append(t);detail.append(l);}trialBody.append(detail);
      }
    };
    loadTrials.onclick=async()=>{
      if(!current()||trialRevision!==null)return;loadTrials.disabled=true;
      try{const res=await fetch('/api/editor-trials/'+encodeURIComponent(project)),value=await res.json();if(!current())return;if(!res.ok)throw Error(value.error||'Could not read the test set.');trialRevision=value.revision;
        trialBody.append(el('p','The optional expectations below are matched literally against the direction text, ignoring case. Enter one phrase per line. This does not check whether the example image actually has that feature.'));
        for(const e of report.examples.filter(e=>(state.example_ids||[]).includes(e.id))){const card=el('div','','editor-example');card.append(el('b',e.project+' · #'+e.scene));const old=(value.cases||[]).find(c=>c.id===e.id)||{};const row={id:e.id};
          for(const [key,label] of [['include','Must appear in direction'],['exclude','Must not appear in direction']]){const l=el('label',label),t=el('textarea');t.rows=2;t.maxLength=2010;t.value=(old[key]||[]).join('\n');l.append(t);card.append(l);row[key]=t;}trialInputs.push(row);trialBody.append(card);}
        trialSaved=trialSnapshot();const create=el('button','Save / refresh test set from selected examples','ghost'),run=el('button','Run saved tests','ghost');trialBody.append(create,run);
        create.onclick=async()=>{if(!current()||saving)return;if(preferenceSnapshot()!==savedPreferences){trialStatus.textContent='Save preferences first, then reopen this window.';return;}const submitted=trialSnapshot();saving++;create.disabled=true;
          try{const r=await fetch('/api/editor-trials/'+encodeURIComponent(project),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:trialRevision,profile_revision:state.revision,requirements:JSON.parse(submitted)})}),v=await r.json();if(!current())return;if(!r.ok)throw Error(v.error||'Could not save.');trialRevision=v.revision;trialSaved=submitted;showTrialResult(v);}
          catch(e){if(current())trialStatus.textContent=e.message;}finally{saving--;create.disabled=false;}
        };
        run.onclick=async()=>{if(!current()||saving)return;run.disabled=true;try{const r=await fetch('/api/editor-trials/'+encodeURIComponent(project)),v=await r.json();if(!current())return;if(!r.ok)throw Error(v.error||'Could not read.');showTrialResult(v);if(trialSnapshot()!==trialSaved)trialStatus.textContent+=' Unsaved expectations on screen were not used in this run.';}catch(e){if(current())trialStatus.textContent=e.message;}finally{run.disabled=false;}};
        showTrialResult(value);
      }catch(e){if(current())trialStatus.textContent=e.message;loadTrials.disabled=false;}
    };
    const actions=el('div','','editor-prefs-actions'),cancel=el('button','Cancel','ghost'),save=el('button','Save preferences','primary');
    cancel.onclick=requestClose;actions.append(cancel,save);box.append(actions);
    save.onclick=async()=>{
      if(!current()) {close();return;}
      const submittedPreferences=preferenceSnapshot();
      saving++;save.disabled=true;
      try{
        const r=await fetch('/api/editor-profile/'+encodeURIComponent(project),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:state.revision,global_rules:global.value,project_rules:local.value,example_ids:[...selected],example_notes:selectedNotes()})});
        const result=await r.json();if(!current()){if(open===box)close();return;}
        if(!r.ok||result.error)throw Error(result.error||'Save failed.');
        savedPreferences=submittedPreferences;navigationStatus.textContent='';
        state=result;status.textContent='Saved. Preferences will be used in future automatic direction, prompts and image checks; existing images were not changed.';
      }catch(e){if(current())status.textContent=e.message;}finally{saving--;if(current())save.disabled=false;}
    };
  });
})();
