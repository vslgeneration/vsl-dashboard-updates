/* Authored OST formatting. Offsets are UTF-16 code units (DOM/textarea offsets).
 * Save data, never editable HTML. Background, placement and timing belong to the whole box. */
(function (root) {
  'use strict';
  const bools = ['fill','bold','italic','upper','underline','stroke','shadow'];
  const nums = {size:[12,1000],letter:[-20,60],leading:[.8,3],stroke_w:[0,40],shadow_opacity:[0,100],shadow_size:[0,40],shadow_dir:[0,360],shadow_distance:[0,200]};
  function clean(style) {
    const out={};
    for(const [key,v] of Object.entries(style||{})) {
      const k=key.replace(/^ost_/,'');
      if(bools.includes(k) && typeof v==='boolean') out['ost_'+k]=v;
      else if(nums[k] && v!==null && Number.isFinite(+v)) out['ost_'+k]=Math.max(nums[k][0],Math.min(nums[k][1],+v));
      else if(['color','stroke_color','shadow_color'].includes(k) && /^#[0-9a-f]{6}$/i.test(String(v))) out['ost_'+k]=v.toLowerCase();
      else if(k==='font' && /^[\p{L}\p{N} _-]{1,80}$/u.test(String(v))) out.ost_font=v;
      else if(k==='weight' && /^(100|200|300|400|500|600|700|800|900)$/.test(String(v))) out.ost_weight=String(v);
    }
    return Object.fromEntries(Object.keys(out).sort().map(k=>[k,out[k]]));
  }
  const supports=k=>Object.keys(clean({[k]:k==='ost_font'?'Arial':k.includes('color')?'#ffffff':k==='ost_weight'?'400':bools.includes(k.slice(4))?true:12})).includes(k);
  function normalize(text,runs) {
    text=String(text||'');const length=text.length, rows=[];
    const boundary=x=>{x=Math.max(0,Math.min(length,Math.trunc(Number(x)||0)));return x>0&&/[\uDC00-\uDFFF]/.test(text[x]||'')?x-1:x;};
    for(const r of (Array.isArray(runs)?runs:[]).slice(0,2048)) {
      if(!r||typeof r!=='object')continue;
      const start=boundary(r.start),end=boundary(r.end),style=clean(r.style);
      if(end>start&&Object.keys(style).length)rows.push({start,end,style});
    }
    const points=[...new Set([0,length,...rows.flatMap(r=>[r.start,r.end])])].sort((a,b)=>a-b), out=[];
    for(let i=1;i<points.length;i++){
      const start=points[i-1],end=points[i],style=clean(Object.assign({},...rows.filter(r=>r.start<=start&&r.end>=end).map(r=>r.style)));
      if(!Object.keys(style).length)continue;
      const last=out[out.length-1];if(last&&last.end===start&&JSON.stringify(last.style)===JSON.stringify(style))last.end=end;else out.push({start,end,style});
    }return out;
  }
  function pieces(text,runs){
    const out=[];let at=0;
    for(const r of normalize(text,runs)){if(r.start>at)out.push({text:text.slice(at,r.start),style:{}});out.push({text:text.slice(r.start,r.end),style:r.style});at=r.end;}
    if(at<text.length)out.push({text:text.slice(at),style:{}});return out;
  }
  function styleAt(ov,at){return Object.assign({},ov,normalize(ov.onscreen,ov.ost_runs).find(r=>r.start<=at&&r.end>at)?.style||{});}
  function apply(ov,start,end,key,value){
    if(!supports(key)) {ov[key]=value;return;}
    if(end>start){ov.ost_runs=normalize(ov.onscreen,[...normalize(ov.onscreen,ov.ost_runs),{start,end,style:{[key]:value}}]);}
    else {ov[key]=value;ov.ost_runs=normalize(ov.onscreen,normalize(ov.onscreen,ov.ost_runs).map(r=>{const style={...r.style};delete style[key];return {...r,style};}));}
  }
  function edit(ov,next){
    const old=String(ov.onscreen||'');next=String(next).replace(/\r\n?/g,'\n');if(old===next)return;
    let a=0,b=0;while(a<old.length&&a<next.length&&old[a]===next[a])a++;
    while(b<old.length-a&&b<next.length-a&&old[old.length-1-b]===next[next.length-1-b])b++;
    const stop=old.length-b,insert=next.length-a-b,delta=next.length-old.length,runs=normalize(old,ov.ost_runs),out=[];
    for(const r of runs){if(r.start<a)out.push({...r,end:Math.min(a,r.end)});if(r.end>stop)out.push({...r,start:Math.max(stop,r.start)+delta,end:r.end+delta});}
    const inherit=runs.find(r=>r.start<=(a<stop?a:Math.max(0,a-1))&&r.end>(a<stop?a:Math.max(0,a-1)));
    if(insert&&inherit)out.push({start:a,end:a+insert,style:inherit.style});
    ov.onscreen=next;ov.ost_runs=normalize(next,out);
  }
  function css(st,baseSize){
    const n=(k,d)=>Number.isFinite(+st['ost_'+k])&&st['ost_'+k]!=null?+st['ost_'+k]:d;
    const col=st.ost_color||'#ffffff',shadow=st.ost_shadow!==false,dir=n('shadow_dir',135)*Math.PI/180,distance=n('shadow_distance',n('shadow_size',6));
    const sh=st.ost_shadow_color||'#000000',rgb=[1,3,5].map(i=>parseInt(sh.slice(i,i+2),16)||0);
    const em=x=>(x/baseSize).toFixed(6)+'em';
    return {color:col,webkitTextFillColor:st.ost_fill===false?'transparent':col,fontFamily:`"${st.ost_font||'Arial'}", sans-serif`,
      fontSize:em(n('size',56)),fontWeight:String(st.ost_bold?800:n('weight',400)),fontStyle:st.ost_italic?'italic':'normal',
      textDecoration:st.ost_underline?'underline':'none',textTransform:st.ost_upper?'uppercase':'none',
      letterSpacing:(n('letter',0)/n('size',56)).toFixed(6)+'em',lineHeight:String(n('leading',1.15)),
      webkitTextStroke:st.ost_stroke!==false?`${(n('stroke_w',0)/n('size',56)).toFixed(6)}em ${st.ost_stroke_color||'#000000'}`:'0px',paintOrder:'stroke fill',
      textShadow:shadow?`${(distance*Math.cos(dir)/n('size',56)).toFixed(6)}em ${(distance*Math.sin(dir)/n('size',56)).toFixed(6)}em ${(n('shadow_size',6)/n('size',56)).toFixed(6)}em rgba(${rgb.join(',')},${n('shadow_opacity',80)/100})`:'none'};
  }
  function render(el,text,st){
    text=String(text||'');const runs=normalize(text,st.ost_runs);el.replaceChildren();el.style.textDecoration=st.ost_underline?'underline':'none';el.style.textTransform=st.ost_upper?'uppercase':'none';
    if(!runs.length){el.textContent=text;return;}
    el.style.textDecoration='none';el.style.textTransform='none';
    for(const p of pieces(text,runs)){const s=document.createElement('span');s.textContent=p.text;Object.assign(s.style,css({...st,...p.style},+st.ost_size||56));el.appendChild(s);}
  }
  // A selection survives toolbar focus and canvas redraws, but never leaks into another overlay.
  let active=null;const bindings=new WeakMap();
  function remember(ov,start,end){active={ov,start:Math.min(start,end),end:Math.max(start,end)};bindings.get(ov)?.refresh?.();}
  function selection(ov){return active?.ov===ov?active:{start:0,end:0};}
  function current(ov,key){const r=selection(ov);return r.end>r.start?styleAt(ov,r.start)[key]:ov[key];}
  function set(ov,key,v){const r=selection(ov);apply(ov,r.start,r.end,key,v);}
  function offset(el,node,pos){const r=document.createRange();r.selectNodeContents(el);r.setEnd(node,pos);return r.toString().length;}
  function capture(el,ov){const s=getSelection();if(!s?.rangeCount||!el.contains(s.anchorNode)||!el.contains(s.focusNode))return;remember(ov,offset(el,s.anchorNode,s.anchorOffset),offset(el,s.focusNode,s.focusOffset));}
  function bindPanel(panel,ov,refresh){panel._ostOwner=ov;bindings.set(ov,{panel,refresh});}
  function bindTextarea(ta,ov){
    ta._ostOwner=ov;const save=()=>remember(ov,ta.selectionStart,ta.selectionEnd);
    for(const event of ['select','keyup','pointerup','focus'])ta.addEventListener(event,save);
    ta.addEventListener('input',save);
  }
  function bindEditor(el,ov,ta,commit,scale){
    el._ostOwner=ov;
    const sync=()=>{edit(ov,el.textContent);if(ta)ta.value=ov.onscreen;};
    el.addEventListener('dblclick',e=>{e.stopPropagation();el.contentEditable='true';el.classList.add('ost-editing');el.focus();const r=document.createRange();r.selectNodeContents(el);const s=getSelection();s.removeAllRanges();s.addRange(r);capture(el,ov);});
    el.addEventListener('pointerdown',e=>{if(el.isContentEditable)e.stopPropagation();});
    el.addEventListener('keydown',e=>{
      if(e.key==='Enter'&&!e.isComposing){e.preventDefault();if(e.shiftKey)document.execCommand('insertText',false,'\n');else el.blur();}
      if(e.key==='Escape'){e.preventDefault();el.blur();}
    });
    el.addEventListener('beforeinput',e=>{if(['insertParagraph','insertLineBreak'].includes(e.inputType)){e.preventDefault();document.execCommand('insertText',false,'\n');}});
    el.addEventListener('paste',e=>{e.preventDefault();document.execCommand('insertText',false,(e.clipboardData?.getData('text/plain')||'').replace(/\r\n?/g,'\n'));});
    el.addEventListener('input',()=>{sync();capture(el,ov);});
    el.addEventListener('blur',()=>{capture(el,ov);sync();el.contentEditable='false';el.classList.remove('ost-editing');render(el,ov.onscreen,ov);commit();});
  }
  if(typeof document!=='undefined'){
    document.addEventListener('selectionchange',()=>{const s=getSelection(),node=s?.anchorNode,el=node?.parentElement?.closest('[contenteditable="true"]');if(el?._ostOwner)capture(el,el._ostOwner);});
    document.addEventListener('pointerdown',e=>{
      if(!active)return;const panel=bindings.get(active.ov)?.panel;
      if(panel?.contains(e.target)||e.target.closest('.cpick')||e.target.closest('[contenteditable="true"]')?._ostOwner===active.ov)return;
      const old=active.ov;active=null;bindings.get(old)?.refresh?.();
    },true);
  }
  const api={clean,supports,normalize,pieces,apply,edit,css,render,styleAt,selection,current,set,bindPanel,bindTextarea,bindEditor,remember};
  root.OSTRich=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
