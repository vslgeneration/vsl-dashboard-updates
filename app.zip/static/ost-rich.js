/* Authored OST formatting. Offsets are UTF-16 code units (DOM/textarea offsets).
 * Save data, never editable HTML. Background, placement and timing belong to the whole box. */
(function (root) {
  'use strict';
  const bools = ['fill','bold','italic','upper','underline','stroke','shadow'];
  const nums = {size:[12,1000],letter:[-20,60],leading:[-3,3],stroke_w:[0,40],shadow_opacity:[0,100],shadow_size:[0,40],shadow_dir:[0,360],shadow_distance:[0,200]};
  function clean(style) {
    const out={};
    for(const [key,v] of Object.entries(style||{})) {
      const k=key.replace(/^ost_/,'');
      if(bools.includes(k) && typeof v==='boolean') out['ost_'+k]=v;
      else if(nums[k] && v!==null && Number.isFinite(+v)) out['ost_'+k]=Math.max(nums[k][0],Math.min(nums[k][1],+v));
      else if(['color','stroke_color','shadow_color'].includes(k) && /^#[0-9a-f]{6}$/i.test(String(v))) out['ost_'+k]=v.toLowerCase();
      else if(k==='font' && /^[\p{L}\p{N} _-]{1,80}$/u.test(String(v))) out.ost_font=v;
      else if(k==='weight' && /^(100|200|300|400|500|600|700|800|900)$/.test(String(v))) out.ost_weight=String(v);
    }
    return Object.fromEntries(Object.keys(out).sort().map(k=>[k,out[k]]));
  }
  const supports=k=>Object.keys(clean({[k]:k==='ost_font'?'Arial':k.includes('color')?'#ffffff':k==='ost_weight'?'400':bools.includes(k.slice(4))?true:12})).includes(k);
  function normalize(text,runs) {
    text=String(text||'');const length=text.length, rows=[];
    const boundary=x=>{x=Math.max(0,Math.min(length,Math.trunc(Number(x)||0)));return x>0&&/[\uDC00-\uDFFF]/.test(text[x]||'')?x-1:x;};
    for(const r of (Array.isArray(runs)?runs:[]).slice(0,2048)) {
      if(!r||typeof r!=='object')continue;
      const start=boundary(r.start),end=boundary(r.end),style=clean(r.style);
      if(end>start&&Object.keys(style).length)rows.push({start,end,style});
    }
    const points=[...new Set([0,length,...rows.flatMap(r=>[r.start,r.end])])].sort((a,b)=>a-b), out=[];
    for(let i=1;i<points.length;i++){
      const start=points[i-1],end=points[i],style=clean(Object.assign({},...rows.filter(r=>r.start<=start&&r.end>=end).map(r=>r.style)));
      if(!Object.keys(style).length)continue;
      const last=out[out.length-1];if(last&&last.end===start&&JSON.stringify(last.style)===JSON.stringify(style))last.end=end;else out.push({start,end,style});
    }return out;
  }
  function pieces(text,runs){
    const out=[];let at=0;
    for(const r of normalize(text,runs)){if(r.start>at)out.push({text:text.slice(at,r.start),style:{}});out.push({text:text.slice(r.start,r.end),style:r.style});at=r.end;}
    if(at<text.length)out.push({text:text.slice(at),style:{}});return out;
  }
  function styleAt(ov,at){return Object.assign({},ov,normalize(ov.onscreen,ov.ost_runs).find(r=>r.start<=at&&r.end>at)?.style||{});}
  function apply(ov,start,end,key,value){
    if(!supports(key)) {ov[key]=value;return;}
    // An explicit weight must override Bold, including a Bold flag inherited
    // from the whole label. Keep that override scoped to the selected range.
    const chosen=key==='ost_weight'?{[key]:value,ost_bold:false}:{[key]:value};
    if(end>start){ov.ost_runs=normalize(ov.onscreen,[...normalize(ov.onscreen,ov.ost_runs),{start,end,style:chosen}]);}
    else {Object.assign(ov,chosen);ov.ost_runs=normalize(ov.onscreen,normalize(ov.onscreen,ov.ost_runs).map(r=>{const style={...r.style};Object.keys(chosen).forEach(k=>delete style[k]);return {...r,style};}));}
  }
  function edit(ov,next){
    const old=String(ov.onscreen||'');next=String(next).replace(/\r\n?/g,'\n');if(old===next)return;
    let a=0,b=0;while(a<old.length&&a<next.length&&old[a]===next[a])a++;
    while(b<old.length-a&&b<next.length-a&&old[old.length-1-b]===next[next.length-1-b])b++;
    const stop=old.length-b,insert=next.length-a-b,delta=next.length-old.length,runs=normalize(old,ov.ost_runs),out=[];
    for(const r of runs){if(r.start<a)out.push({...r,end:Math.min(a,r.end)});if(r.end>stop)out.push({...r,start:Math.max(stop,r.start)+delta,end:r.end+delta});}
    const inherit=runs.find(r=>r.start<=(a<stop?a:Math.max(0,a-1))&&r.end>(a<stop?a:Math.max(0,a-1)));
    if(insert&&inherit)out.push({start:a,end:a+insert,style:inherit.style});
    ov.onscreen=next;ov.ost_runs=normalize(next,out);
  }
  function css(st,baseSize){
    const n=(k,d)=>Number.isFinite(+st['ost_'+k])&&st['ost_'+k]!=null?+st['ost_'+k]:d;
    const col=st.ost_color||'#ffffff',shadow=st.ost_shadow!==false,dir=n('shadow_dir',135)*Math.PI/180,distance=n('shadow_distance',n('shadow_size',6));
    const sh=st.ost_shadow_color||'#000000',rgb=[1,3,5].map(i=>parseInt(sh.slice(i,i+2),16)||0);
    const em=x=>(x/baseSize).toFixed(6)+'em';
    return {color:col,webkitTextFillColor:st.ost_fill===false?'transparent':col,fontFamily:`"${st.ost_font||'Arial'}", sans-serif`,
      fontSize:em(n('size',56)),fontWeight:String(st.ost_bold?800:n('weight',400)),fontStyle:st.ost_italic?'italic':'normal',
      textDecoration:st.ost_underline?'underline':'none',textTransform:st.ost_upper?'uppercase':'none',
      letterSpacing:(n('letter',0)/n('size',56)).toFixed(6)+'em',lineHeight:String(n('leading',1.15)>0?n('leading',1.15):1),
      webkitTextStroke:st.ost_stroke!==false?`${(n('stroke_w',0)/n('size',56)).toFixed(6)}em ${st.ost_stroke_color||'#000000'}`:'0px',paintOrder:'stroke fill',
      textShadow:shadow?`${(distance*Math.cos(dir)/n('size',56)).toFixed(6)}em ${(distance*Math.sin(dir)/n('size',56)).toFixed(6)}em ${(n('shadow_size',6)/n('size',56)).toFixed(6)}em rgba(${rgb.join(',')},${n('shadow_opacity',80)/100})`:'none'};
  }

  // CSS rejects negative line-height. Signed spacing uses actual line positions;
  // the grid retains the visible text bounds even when baseline advance is zero.
  function leading(st){const v=st.ost_leading;return v!=null&&Number.isFinite(+v)?+v:1.15;}

  function wrappedSignedRows(el,text,st,runs){
    if(!el?.isConnected||!['pre-wrap','pre-line','normal'].includes(getComputedStyle(el).whiteSpace))return null;
    const prior=el.style.lineHeight;el.style.lineHeight='1';el.replaceChildren();
    const base=+st.ost_size||56,ps=pieces(text,runs),nodes=[];
    for(const p of ps){const span=document.createElement('span');span.textContent=p.text;Object.assign(span.style,css({...st,...p.style},base));span.style.lineHeight='1';el.appendChild(span);nodes.push({span,p});}
    if(!el.clientWidth){el.style.lineHeight=prior;el.replaceChildren();return null;}
    const probe=el.cloneNode(true),computed=getComputedStyle(el);probe.removeAttribute('id');probe.removeAttribute('contenteditable');
    Object.assign(probe.style,{position:'fixed',left:'-100000px',top:'0',visibility:'hidden',transform:'none',width:computed.width,maxWidth:'none',fontSize:computed.fontSize,fontFamily:computed.fontFamily,whiteSpace:computed.whiteSpace,lineHeight:'1'});
    document.body.appendChild(probe);nodes.forEach((n,i)=>n.span=probe.children[i]);
    const context=document.createElement('canvas').getContext('2d'),rows=[[]],separators=[];let baseline=null;
    const append=(ch,style)=>{const row=rows[rows.length-1],last=row[row.length-1];if(last&&last.style===style)last.text+=ch;else row.push({text:ch,style});};
    for(const {span,p} of nodes){
      const cs=getComputedStyle(span);context.font=`${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
      const descent=context.measureText('Mg').fontBoundingBoxDescent||0;let at=0;
      for(const ch of p.text){
        if(ch==='\n'){rows.push([]);separators.push('\n');baseline=null;at++;continue;}
        const r=document.createRange();r.setStart(span.firstChild,at);r.setEnd(span.firstChild,at+ch.length);at+=ch.length;
        const box=r.getBoundingClientRect(),next=box.bottom-descent;
        if(baseline!=null&&Math.abs(next-baseline)>2&&rows[rows.length-1].length){rows.push([]);separators.push('');}
        if(box.height)baseline=next;append(ch,p.style);
      }
    }
    probe.remove();el.style.lineHeight=prior;el.replaceChildren();return {rows,separators};
  }
  function signedRows(text,st,runs,el){
    const base=+st.ost_size||56;
    if(leading(st)>0&&!runs.some(r=>(r.style.ost_leading!=null&&leading(r.style)!==leading(st))||(r.style.ost_size!=null&&+r.style.ost_size!==base)))return null;
    const rows=[[]];
    for(const p of pieces(text,runs))p.text.split('\n').forEach((part,i)=>{if(i)rows.push([]);if(part)rows[rows.length-1].push({text:part,style:p.style});});
    const wrapped=el?wrappedSignedRows(el,text,st,runs):null;
    if(wrapped)rows.splice(0,rows.length,...wrapped.rows);
    const separators=wrapped?wrapped.separators:rows.slice(1).map(()=> '\n');
    // Each row owns its font strut. A small second line must not reserve the
    // first line's font height. A selected row's spacing controls its incoming
    // gap; otherwise use the preceding row's value (whole-label legacy behavior).
    const sizes=rows.map(row=>row.length?Math.max(...row.map(p=>+(p.style.ost_size??st.ost_size)||56)):base),pos=[0];
    for(let i=1;i<rows.length;i++){
      const overrides=rows[i].filter(p=>p.style.ost_leading!=null);
      const source=overrides.length?overrides:rows[i-1];
      const gap=source.length?Math.min(...source.map(p=>leading({...st,...p.style}))):leading(st);
      const previous=sizes[i-1]/base,current=sizes[i]/base;
      pos.push(pos[i-1]+(previous+current)*gap/2+(previous-current)/2);
    }
    const lo=Math.min(...pos),hi=Math.max(...pos);
    return {rows,separators,sizes,pos:pos.map(v=>v-lo),extent:hi-lo};
  }
  function renderSigned(el,st,layout){
    const grid=document.createElement('span');grid.dataset.ostSigned='';
    grid.style.cssText=`display:inline-grid;grid-template-columns:minmax(0,1fr);white-space:normal;line-height:1;vertical-align:middle;max-width:100%;box-sizing:content-box;padding-bottom:${layout.extent}em`;
    layout.rows.forEach((parts,i)=>{
      if(i&&layout.separators[i-1])grid.appendChild(document.createTextNode(layout.separators[i-1]));
      const row=document.createElement('span');row.dataset.ostLine=String(i);
      const size=layout.sizes[i],ratio=size/(+st.ost_size||56);
      row.style.cssText=`grid-area:1/1;white-space:pre;overflow-wrap:normal;text-align:${['left','center','right'].includes(st.ost_align)?st.ost_align:'center'};font-size:${ratio}em;line-height:1;min-height:1em;align-self:start;justify-self:stretch;transform:translateY(${layout.pos[i]/ratio}em)`;
      for(const p of parts){const s=document.createElement('span');s.textContent=p.text;Object.assign(s.style,css({...st,...p.style},size));s.style.lineHeight='1';row.appendChild(s);}
      grid.appendChild(row);
    });
    el.style.textDecoration='none';el.style.textTransform='none';el.appendChild(grid);
    // Reserve the union of real line boxes, not max-height + distance, so mixed
    // font sizes remain centred and the automatic text stack uses visible bounds.
    if(el.isConnected){
      const em=parseFloat(getComputedStyle(grid).fontSize)||1,rows=[...grid.children],width=parseFloat(getComputedStyle(grid).width)||grid.offsetWidth;
      const height=Math.max(...rows.map((row,i)=>layout.pos[i]*em+(parseFloat(getComputedStyle(row).height)||row.offsetHeight)));
      grid.style.position='relative';grid.style.width=(width/em)+'em';grid.style.height=(height/em)+'em';grid.style.paddingBottom='0';
      for(const row of rows){row.style.position='absolute';row.style.left='0';row.style.top='0';row.style.width='100%';}
    }

  }
  function restoreSelection(el,start,end){
    const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),nodes=[];let node;
    while(node=walker.nextNode())nodes.push(node);
    if(!nodes.length)return;
    const point=at=>{for(const n of nodes){if(at<=n.length)return [n,at];at-=n.length;}const n=nodes[nodes.length-1];return [n,n.length];};
    const a=point(start),b=point(end),r=document.createRange();r.setStart(...a);r.setEnd(...b);
    const s=getSelection();s.removeAllRanges();s.addRange(r);
  }
  function render(el,text,st){
    text=String(text||'');const runs=normalize(text,st.ost_runs);el.replaceChildren();el.style.textDecoration=st.ost_underline?'underline':'none';el.style.textTransform=st.ost_upper?'uppercase':'none';
    const signed=signedRows(text,st,runs,el);el._ostSignedState=signed?{text,st}:null;if(signed){renderSigned(el,st,signed);return;}
    if(!runs.length){el.textContent=text;return;}
    el.style.textDecoration='none';el.style.textTransform='none';
    for(const p of pieces(text,runs)){const s=document.createElement('span');s.textContent=p.text;Object.assign(s.style,css({...st,...p.style},+st.ost_size||56));el.appendChild(s);}
  }
  // A selection survives toolbar focus and canvas redraws, but never leaks into another overlay.
  let active=null;const bindings=new WeakMap();
  function remember(ov,start,end){active={ov,start:Math.min(start,end),end:Math.max(start,end)};bindings.get(ov)?.refresh?.();}
  function selection(ov){return active?.ov===ov?active:{start:0,end:0};}
  function current(ov,key){
    const r=selection(ov);if(r.end>r.start)return styleAt(ov,r.start)[key];
    const values=pieces(String(ov.onscreen||''),ov.ost_runs).map(p=>p.style[key]??ov[key]);
    return values.length&&values.every(v=>v===values[0])?values[0]:ov[key];
  }
  function set(ov,key,v){const r=selection(ov);apply(ov,r.start,r.end,key,v);}
  function offset(el,node,pos){const r=document.createRange();r.selectNodeContents(el);r.setEnd(node,pos);return r.toString().length;}
  function capture(el,ov){const s=getSelection();if(!s?.rangeCount||!el.contains(s.anchorNode)||!el.contains(s.focusNode))return;remember(ov,offset(el,s.anchorNode,s.anchorOffset),offset(el,s.focusNode,s.focusOffset));}
  function bindPanel(panel,ov,refresh){panel._ostOwner=ov;bindings.set(ov,{panel,refresh});}
  function bindTextarea(ta,ov){
    ta._ostOwner=ov;const save=()=>remember(ov,ta.selectionStart,ta.selectionEnd);
    for(const event of ['select','keyup','pointerup','focus'])ta.addEventListener(event,save);
    ta.addEventListener('input',save);
  }
  function bindEditor(el,ov,ta,commit,scale){
    el._ostOwner=ov;
    const sync=()=>{edit(ov,el.textContent);if(ta)ta.value=ov.onscreen;};
    const insertSigned=text=>{
      if(!signedRows(ov.onscreen,ov,normalize(ov.onscreen,ov.ost_runs)))return false;
      capture(el,ov);const r=selection(ov),next=ov.onscreen.slice(0,r.start)+text+ov.onscreen.slice(r.end),at=r.start+text.length;
      edit(ov,next);if(ta)ta.value=ov.onscreen;render(el,ov.onscreen,ov);restoreSelection(el,at,at);remember(ov,at,at);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));return true;
    };

    el.addEventListener('dblclick',e=>{e.stopPropagation();el.contentEditable='true';el.classList.add('ost-editing');el.focus();const r=document.createRange();r.selectNodeContents(el);const s=getSelection();s.removeAllRanges();s.addRange(r);capture(el,ov);});
    el.addEventListener('pointerdown',e=>{if(el.isContentEditable)e.stopPropagation();});
    el.addEventListener('keydown',e=>{
      if(e.key==='Enter'&&!e.isComposing){e.preventDefault();if(e.shiftKey){if(!insertSigned('\n'))document.execCommand('insertText',false,'\n');}else el.blur();}
      if(e.key==='Escape'){e.preventDefault();el.blur();}
    });
    el.addEventListener('beforeinput',e=>{if(['insertParagraph','insertLineBreak'].includes(e.inputType)){e.preventDefault();if(!insertSigned('\n'))document.execCommand('insertText',false,'\n');}});
    el.addEventListener('paste',e=>{e.preventDefault();const text=(e.clipboardData?.getData('text/plain')||'').replace(/\r\n?/g,'\n');if(!insertSigned(text))document.execCommand('insertText',false,text);});
    el.addEventListener('input',()=>{sync();capture(el,ov);if(signedRows(ov.onscreen,ov,normalize(ov.onscreen,ov.ost_runs))){const r=selection(ov);render(el,ov.onscreen,ov);restoreSelection(el,r.start,r.end);}});
    el.addEventListener('blur',()=>{capture(el,ov);sync();el.contentEditable='false';el.classList.remove('ost-editing');render(el,ov.onscreen,ov);commit();});
  }
  if(typeof document!=='undefined'){
    document.fonts?.addEventListener('loadingdone',()=>{
      for(const grid of document.querySelectorAll('[data-ost-signed]')){
        const el=grid.parentElement,state=el?._ostSignedState;if(!state||!el.isConnected)continue;
        const editing=el.isContentEditable&&el._ostOwner;if(editing)capture(el,el._ostOwner);
        const range=editing?selection(el._ostOwner):null;render(el,state.text,state.st);
        if(range)restoreSelection(el,range.start,range.end);
      }
    });

    document.addEventListener('selectionchange',()=>{const s=getSelection(),node=s?.anchorNode,el=node?.parentElement?.closest('[contenteditable="true"]');if(el?._ostOwner)capture(el,el._ostOwner);});
    document.addEventListener('pointerdown',e=>{
      if(!active)return;const panel=bindings.get(active.ov)?.panel;
      if(panel?.contains(e.target)||e.target.closest('.cpick')||e.target.closest('[contenteditable="true"]')?._ostOwner===active.ov)return;
      const old=active.ov;active=null;bindings.get(old)?.refresh?.();
    },true);
  }
  const api={clean,supports,normalize,pieces,apply,edit,css,render,styleAt,selection,current,set,bindPanel,bindTextarea,bindEditor,remember};
  root.OSTRich=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
