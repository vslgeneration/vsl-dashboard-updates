/* Testimonial image framing and layout. Shared, non-destructive geometry for both scopes. */
const TestimonialLayout = (() => {
  const num = (v, d) => Number.isFinite(+v) ? +v : d;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function crop(raw = {}, aspect = 1) {
    const z = clamp(num(raw.zoom, 1), 1, 4), a = Math.max(.01, num(aspect, 1));
    const w = Math.max(1, a) * z, h = Math.max(1, 1 / a) * z;
    return { x: clamp(num(raw.x, 0), -(w - 1) / 2, (w - 1) / 2), y: clamp(num(raw.y, 0), -(h - 1) / 2, (h - 1) / 2), zoom: z, aspect: a };
  }
  function cropStyle(raw) {
    const c = crop(raw, raw.aspect);
    return `position:absolute;width:${100 * Math.max(1, c.aspect) * c.zoom}%;height:${100 * Math.max(1, 1 / c.aspect) * c.zoom}%;max-width:none;left:${50 + c.x * 100}%;top:${50 + c.y * 100}%;transform:translate(-50%,-50%);object-fit:fill;`;
  }
  function transform(raw = {}) { return { x: clamp(num(raw.x, 0), -1544, 1544), y: clamp(num(raw.y, 0), 0, 600), scale: clamp(num(raw.scale, 1), .4, 2.2) }; }
  const parts = el => ({ identity: el.querySelector('.tc-star-id'), product: el.querySelector('.tc-prodwrap') });
  function resetGeometry(el) {
    const head = el.querySelector('.tc-star-head'); if (!head) return;
    head.style.height = '';
    Object.values(parts(el)).filter(Boolean).forEach(p => { for (const k of ['position','left','top','width','transform','transformOrigin']) p.style[k] = ''; });
  }
  function apply(el, layout = {}) {
    const head = el.querySelector('.tc-star-head'); if (!head || !head.offsetWidth) return;
    const ps = parts(el), base = {}, width = head.clientWidth;
    for (const [key, p] of Object.entries(ps)) if (p) base[key] = { left:p.offsetLeft, w:p.offsetWidth, h:p.offsetHeight };
    el._tcLayoutBase = base; el._tcLayoutWidth = width;
    let height = 0;
    for (const [key, b] of Object.entries(base)) {
      const p = ps[key], t = transform(layout[key]), z = Math.min(t.scale, width / Math.max(1, b.w));
      const left = clamp(b.left + b.w / 2 - b.w * z / 2 + t.x, 0, Math.max(0, width - b.w * z));
      Object.assign(p.style, {position:'absolute',left:left+'px',top:t.y+'px',width:b.w+'px',transformOrigin:'top left',transform:`scale(${z})`});
      height = Math.max(height, t.y + b.h * z);
    }
    head.style.height = Math.ceil(height) + 'px';
  }
  function button(text, fn) { const b=document.createElement('button'); b.type='button'; b.textContent=text; b.addEventListener('click',fn); return b; }
  async function portrait({url, initial, current, save}) {
    const bg=document.createElement('div'); bg.className='modal-bg tc-crop-bg';
    bg.innerHTML='<section class="modal tc-crop-modal" role="dialog" aria-modal="true" aria-label="Frame portrait"><h2>Frame portrait</h2><p>Drag the photo to position it inside the circle. The original image stays unchanged.</p><div class="tc-crop-circle" tabindex="0" aria-label="Drag portrait; arrow keys move it"><img alt="Portrait preview" draggable="false"></div><label>Zoom <input class="tc-crop-zoom" type="range" min="1" max="4" step="0.01" value="1"></label><p class="tc-crop-status" role="status">Loading image…</p><div class="tc-crop-actions"></div></section>';
    document.body.append(bg);
    const circle=bg.querySelector('.tc-crop-circle'), im=circle.querySelector('img'), zoom=bg.querySelector('input'), status=bg.querySelector('.tc-crop-status'), actions=bg.querySelector('.tc-crop-actions');
    let state=crop(), ready=false, busy=false, drag=null;
    const close=()=>{if(!busy)bg.remove();};
    const paint=()=>{state=crop(state,im.naturalWidth/im.naturalHeight);im.style.cssText=cropStyle(state);zoom.value=state.zoom;};
    const use=button('Save framing',async()=>{
      if(!ready||busy)return;if(!current()){close();return;}busy=true;use.disabled=true;status.textContent='Saving…';
      try{await save(state);busy=false;bg.remove();}catch(e){busy=false;use.disabled=false;status.textContent=e.message||'Framing could not be saved. Please try again.';}
    });use.disabled=true;
    actions.append(button('Reset',()=>{if(ready&&!busy){state=crop({},im.naturalWidth/im.naturalHeight);paint();}}),button('Cancel',close),use);
    im.onload=()=>{ready=true;state=crop(initial||{},im.naturalWidth/im.naturalHeight);paint();use.disabled=false;status.textContent='Drag to move. Use the slider to zoom.';circle.focus();};
    im.onerror=()=>{ready=false;use.disabled=true;status.textContent='Image could not be loaded. Close this window and try again.';};im.src=url;
    zoom.addEventListener('input',()=>{if(ready&&!busy){state.zoom=+zoom.value;paint();}});
    circle.addEventListener('pointerdown',e=>{if(!ready||busy)return;e.preventDefault();drag={x:e.clientX,y:e.clientY,state:{...state}};circle.setPointerCapture(e.pointerId);});
    circle.addEventListener('pointermove',e=>{if(!drag)return;const size=circle.getBoundingClientRect().width;state={...drag.state,x:drag.state.x+(e.clientX-drag.x)/size,y:drag.state.y+(e.clientY-drag.y)/size};paint();});
    circle.addEventListener('pointerup',()=>{drag=null;});circle.addEventListener('pointercancel',()=>{if(drag){state=drag.state;paint();drag=null;}});
    bg.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close();}if(e.target===circle&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)&&!busy){e.preventDefault();const d=e.shiftKey?.05:.01;state.x+=(e.key==='ArrowRight'?d:e.key==='ArrowLeft'?-d:0);state.y+=(e.key==='ArrowDown'?d:e.key==='ArrowUp'?-d:0);paint();}});
    bg.addEventListener('click',e=>{if(e.target===bg)close();});
  }
  function attach(el, {wrap, getLayout, commit, current, refit}) {
    const ps=parts(el), bar=document.createElement('div'), overlay=document.createElement('div');
    bar.className='tc-layout-tools';bar.hidden=true;
    bar.innerHTML='<strong class="tc-layout-label"></strong><label>Size <input type="range" min="0.4" max="2.2" step="0.01" aria-label="Selected item size"></label><span class="tc-layout-percent"></span>';
    overlay.className='tc-layout-box';overlay.hidden=true;overlay.tabIndex=0;overlay.setAttribute('aria-label','Move selected item with arrow keys or drag');
    const handle=document.createElement('button');handle.type='button';handle.className='tc-layout-handle';handle.title='Drag to resize';handle.setAttribute('aria-label','Resize selected item');overlay.append(handle);
    wrap.before(bar);wrap.append(overlay);
    let selected=null, draft=null, drag=null;
    const layout=()=>draft||getLayout()||{};
    const place=()=>{const p=ps[selected];if(!p||!selected)return;const a=wrap.getBoundingClientRect(),r=p.getBoundingClientRect();Object.assign(overlay.style,{left:(r.left-a.left)+'px',top:(r.top-a.top)+'px',width:r.width+'px',height:r.height+'px'});};
    const refresh=()=>{el._tcStarLayoutDraft=draft;refit();requestAnimationFrame(place);};
    const finish=()=>{if(draft&&current()){const value=draft;draft=null;el._tcStarLayoutDraft=null;commit(value);}else{draft=null;el._tcStarLayoutDraft=null;}refresh();};
    const end=()=>{draft=null;el._tcStarLayoutDraft=null;selected=null;overlay.hidden=bar.hidden=true;refresh();};
    const controls=()=>{const t=transform(layout()[selected]);bar.querySelector('input').value=t.scale;bar.querySelector('.tc-layout-percent').textContent=Math.round(t.scale*100)+'%';};
    const edit=(key,e)=>{if(!current())return;e.preventDefault();e.stopPropagation();selected=key;overlay.hidden=bar.hidden=false;bar.querySelector('strong').textContent=key==='product'?'Product image':'Profile, name & stars';controls();place();overlay.focus();};
    for(const [key,p] of Object.entries(ps))if(p){p.title='Double-click to move or resize';p.addEventListener('dblclick',e=>edit(key,e));}
    bar.append(button('Align tops',()=>{draft=structuredClone(getLayout()||{});const other=selected==='product'?'identity':'product';draft[selected]={...transform(draft[selected]),y:transform(draft[other]).y};finish();controls();}),button('Reset position & size',()=>{draft=structuredClone(getLayout()||{});delete draft[selected];finish();controls();}),button('Done',end));
    const slider=bar.querySelector('input');slider.addEventListener('input',()=>{if(!selected||!current())return;draft=structuredClone(getLayout()||{});draft[selected]={...transform(draft[selected]),scale:+slider.value};controls();refresh();});slider.addEventListener('change',finish);
    overlay.addEventListener('pointerdown',e=>{
      if(!selected||!current())return;e.preventDefault();e.stopPropagation();
      const p=ps[selected],r=p.getBoundingClientRect();drag={x:e.clientX,y:e.clientY,start:transform(layout()[selected]),layout:structuredClone(layout()),resize:e.target===handle,width:r.width,ratio:el.getBoundingClientRect().width/el.offsetWidth};overlay.setPointerCapture(e.pointerId);
    });
    overlay.addEventListener('pointermove',e=>{
      if(!drag||!current())return;draft=structuredClone(drag.layout);const t={...drag.start};
      if(drag.resize)t.scale=clamp(drag.start.scale*(1+(e.clientX-drag.x)/Math.max(1,drag.width)),.4,2.2);
      else{t.x+=(e.clientX-drag.x)/drag.ratio;t.y+=(e.clientY-drag.y)/drag.ratio;
        // Snap to the original column alignment and the other group's top.
        if(Math.abs(t.x)<10)t.x=0;const other=transform(draft[selected==='product'?'identity':'product']);if(Math.abs(t.y-other.y)<10)t.y=other.y;t.y=clamp(t.y,0,600);
      }
      draft[selected]=t;controls();refresh();
    });
    overlay.addEventListener('pointerup',()=>{if(drag){drag=null;finish();}});
    overlay.addEventListener('pointercancel',()=>{drag=null;draft=null;refresh();controls();});
    overlay.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();end();}else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)&&selected&&current()){e.preventDefault();draft=structuredClone(getLayout()||{});const t=transform(draft[selected]),d=e.shiftKey?20:4;t.x+=e.key==='ArrowRight'?d:e.key==='ArrowLeft'?-d:0;t.y=clamp(t.y+(e.key==='ArrowDown'?d:e.key==='ArrowUp'?-d:0),0,600);draft[selected]=t;finish();}});
    el._tcPlaceHandles=place;el._tcDisposeLayout=()=>{bar.remove();overlay.remove();};
  }
  return {crop,cropStyle,transform,resetGeometry,apply,portrait,attach};
})();
