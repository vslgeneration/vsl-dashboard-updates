/* Cached production picture/audio movie with independently editable foreground layers. */
window.FinalPreview = (() => {
  const byId=id=>document.getElementById(id);
  let stamp='',checkedStamp='',dirty=false,checking=0,building=false,editVersion=0;
  let timer=0,epoch=0,refreshing=null,refreshAgain=false,overlayReady=Promise.resolve(),audioRequest=0,audioTask=null,audioWanted=null;
  const options=()=>({final_preview:true,live_overlays:true,kenburns:!!byId('rndKenburns')?.checked,
    music:byId('rndMusic')?.checked!==false,burnsubs:byId('rndBurnSubs')?.checked!==false,
    onscreentext:byId('rndOnscreen')?.checked!==false,transitions:byId('rndTransitions')?.checked!==false,
    low_priority:true});
  const active=()=>!!PV.m?.final_preview;
  function viewStamp(){
    const d={...DOC};for(const k of ['_revision','history','undo_history','redo_history','preview_built','generation_completed','updated_at','modified_at','last_opened'])delete d[k];
    return JSON.stringify([d,options(),editVersion],(key,value)=>key==='generation_records'?undefined:value);
  }
  function notice(text){
    let node=byId('pvFinalNotice');
    if(!node&&text){node=document.createElement('div');node.id='pvFinalNotice';byId('pvStage').append(node);}
    if(node){node.textContent=text||'';node.hidden=!text;}
  }
  const overlayError=()=>{if(active())notice('A preview overlay could not load. Build Preview again.');};
  function reset(){
    epoch++;audioRequest++;audioWanted=null;audioTask=null;clearTimeout(timer);timer=0;refreshing=null;refreshAgain=false;
    stamp='';checkedStamp='';dirty=false;checking=0;building=false;overlayReady=Promise.resolve();window.LiveOverlays?.clear();
    byId('pvStage')?.removeEventListener('liveoverlayerror',overlayError);
    byId('pvStage')?.classList.remove('pv-final-mode');byId('pvVo').hidden=true;notice('');
  }
  function begin(m){
    reset();if(!m.final_preview)return;
    byId('pvStage').classList.add('pv-final-mode');byId('pvVo').hidden=false;byId('pvImgOnly').hidden=true;
    byId('pvStage').addEventListener('liveoverlayerror',overlayError);
    overlayReady=Promise.resolve(window.LiveOverlays?.mount(byId('pvStage'),byId('pvVo'),m.final_preview.overlays));
  }
  function ready(){
    stamp=PV.m?.final_preview?.viewStamp||viewStamp();checkedStamp=stamp;dirty=false;checking=0;invalidate();
    const f=PV.m?.final_preview;
    if(f?.desired_audio_fingerprint&&f.audio_fingerprint!==f.desired_audio_fingerprint)
      void refreshAudio({audio_fingerprint:f.desired_audio_fingerprint,base_fingerprint:f.desired_base_fingerprint},musicContext(),PV.m,epoch,stamp);
  }
  function markBaseDirty(){
    dirty=true;audioRequest++;audioWanted=null;byId('pvVo').pause();cancelAnimationFrame(PV.raf);
    byId('pvPlay').textContent='▶';byId('pvBig').hidden=false;
    byId('buildPreviewBtn').textContent='🔄 Rebuild Preview';notice('Video changes pending · Rebuild Preview');
  }
  async function compose(project,current){
    const owner=musicContext(),known=typeof _serverDocument!=='undefined'?_serverDocument:null;
    const revision=known?.project===project&&known.epoch===owner.epoch?known.doc?._revision:DOC?._revision;
    const r=await fetch(`/api/preview-live/${encodeURIComponent(project)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options(),project_revision:revision})});
    const data=await r.json();if(!current())return null;
    if(!r.ok||data.error){const error=Error(data.error||'Preview layers could not be prepared.');error.retry=r.status===409;throw error;}
    if(!data.overlays||!data.video_fingerprint||!data.base_fingerprint)throw Error('Preview layers are incomplete.');
    return data;
  }
  async function saved(){
    const value=await flushSave();
    if(!value||value.error||!Array.isArray(value.scenes))throw Error(value?.error||'Changes could not be saved.');
  }
  function adoptManifest(data){
    if(data.manifest)Object.assign(PV.m,data.manifest);
    PV.scene=-1;PV.cap=-1;
    if(!document.querySelector('.pv-tt-bar.dragging'))pvBuildTextTrack();
    window.CaptionEditor?.renderTimeline?.();
  }
  async function refresh(){
    if(!active()||!stamp)return;
    if(refreshing){refreshAgain=true;return refreshing;}
    const mine=epoch,owner=musicContext(),model=PV.m;
    const current=()=>epoch===mine&&musicCurrent(owner)&&PV.m===model&&active();
    const task=(async()=>{
      try{
        await saved();if(!current())return;
        const wanted=viewStamp(),data=await compose(owner.project,current);if(!data||!current())return;
        if(wanted!==viewStamp()){refreshAgain=true;return;}
        checkedStamp=wanted;
        if(data.video_fingerprint!==model.final_preview.video_fingerprint){markBaseDirty();return;}
        const old=model.final_preview;
        await window.LiveOverlays.update(data.overlays,()=>current()&&wanted===viewStamp());if(!current())return;
        if(wanted!==viewStamp()){refreshAgain=true;return;}
        adoptManifest(data);old.overlays=data.overlays;old.overlay_revision=data.overlay_revision;old.viewStamp=wanted;old.desired_audio_fingerprint=data.audio_fingerprint;
        dirty=false;stamp=wanted;notice('');tick(byId('pvVo').currentTime||0);
        // A clock icon can move its automatic sound. Reuse all picture sections
        // and refresh only the continuous audio/mux without blocking layer edits.
        if(data.audio_fingerprint!==old.audio_fingerprint)void refreshAudio(data,owner,model,mine,wanted);
      }catch(error){if(current()){if(error.retry)refreshAgain=true;else notice(error.message||'Preview layers could not refresh.');}}
    })();
    refreshing=task;
    try{await task;}finally{if(epoch===mine){refreshing=null;if(refreshAgain){refreshAgain=false;clearTimeout(timer);timer=setTimeout(()=>void refresh(),160);}}}
  }
  function invalidate(force=false){
    if(!active()||!stamp)return;
    if(!force&&checkedStamp===viewStamp())return;
    clearTimeout(timer);timer=setTimeout(()=>{timer=0;void refresh();},140);
  }
  function tick(t){
    if(!active())return false;
    if(performance.now()-checking>500){checking=performance.now();invalidate();}
    const m=PV.m;PV.renderTime=t;PV.scene=m.scenes.findIndex(s=>t>=s.start&&t<s.end);
    PV.cap=(m.captions||[]).findIndex(c=>t>=c.start&&t<c.end);window.LiveOverlays?.tick(t);
    const pct=m.duration?Math.max(0,Math.min(100,t/m.duration*100)):0;
    byId('pvProgress').style.width=pct+'%';byId('pvHead').style.left=pct+'%';
    pvTextTrackHead(t);byId('pvTime').textContent=`${pvFmt(t)} / ${pvFmt(m.duration)}`;pvUpdateSceneLink();return true;
  }
  function canPlay(){
    if(!active())return true;
    if(!dirty&&stamp===viewStamp())return true;
    if(!building){building=true;const owner=musicContext(),mine=epoch;
      (async()=>{await refresh();if(epoch!==mine||!musicCurrent(owner)||!active())return;
        if(dirty)await buildPreview({currentTarget:byId('buildPreviewBtn')});
        if(musicCurrent(owner)&&active()&&!dirty&&stamp===viewStamp())pvPlay();
      })().catch(error=>{if(epoch===mine&&musicCurrent(owner))notice(error.message||'Preview could not refresh.');}).finally(()=>{if(epoch===mine)building=false;});}
    return false;
  }
  async function movie(project,current,status,restore,expected){
    const post=await fetch(`/api/render/${encodeURIComponent(project)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options(),cache_only:!!restore,base_fingerprint:expected?.base_fingerprint})});
    let response=await post.json();if(!current())return null;
    if(!post.ok||response.error){const error=Error(response.error||'Preview failed');error.retry=post.status===409;throw error;}
    if(restore&&!response.cached)return null;
    const token=response.fingerprint;
    while(!response.cached){
      await new Promise(r=>setTimeout(r,450));if(!current())return null;
      const r=await fetch(`/api/render/${encodeURIComponent(project)}`);if(!r.ok)throw Error('Could not read preview progress');
      response=await r.json();if(!current())return null;
      if(response.fingerprint!==token||!response.final_preview)throw Error('The preview job changed. Build Preview again.');
      if(response.status==='error')throw Error(response.error||'Preview failed');
      if(response.status==='cancelled')throw Error('Preview cancelled');
      if(response.status==='done')break;
      if(status)status.textContent=(response.step||'Preparing preview…')+(Number.isFinite(response.pct)?` ${Math.round(response.pct)}%`:'');
    }
    return {...response,file:response.file,fingerprint:token,url:`/media/${encodeURIComponent(project)}/${response.file}?preview=${token}`};
  }
  async function request(project,current,status,restore,requestedStamp=viewStamp()){
    let data=await compose(project,current);if(!data||!current())return null;
    if(!data.manifest?.scenes?.length)throw Error('Approve an image or video before building the preview.');
    const rendered=await movie(project,current,status,restore,data);if(!rendered||!current())return null;
    // Resolve edits made during the long base build before revealing its layers.
    let attempts=0;
    while(requestedStamp!==viewStamp()){
      if(++attempts>3)throw Error('The project is still changing. Build Preview again after editing.');
      if(!restore)await saved();if(!current())return null;
      requestedStamp=viewStamp();data=await compose(project,current);if(!data)return null;
    }
    if(rendered.video_fingerprint!==data.video_fingerprint)throw Error('The video changed while preparing the preview. Build Preview again.');
    return {...rendered,desired_audio_fingerprint:data.audio_fingerprint,desired_base_fingerprint:data.base_fingerprint,viewStamp:requestedStamp,overlays:data.overlays,overlay_revision:data.overlay_revision,manifest:data.manifest};
  }
  async function refreshAudio(data,owner,model,mine,wanted){
    audioWanted={data,owner,model,mine};if(audioTask)return audioTask;
    const id=++audioRequest;
    const task=(async()=>{
      while(audioWanted&&id===audioRequest){
        const target=audioWanted;audioWanted=null;
        const {owner,model,mine}=target,current=()=>id===audioRequest&&epoch===mine&&musicCurrent(owner)&&PV.m===model&&!dirty;
        if(!current())return;notice('Updating preview audio…');
        try{
          // Complete one audio job before starting the newest requested mix.
          const next=await movie(owner.project,current,null,false,target.data);if(!next||!current())return;
          if(next.video_fingerprint!==model.final_preview.video_fingerprint){markBaseDirty();return;}
          if(next.audio_fingerprint!==model.final_preview.desired_audio_fingerprint)continue;
          const v=byId('pvVo'),playing=!v.paused,time=v.currentTime,muted=v.muted,rate=v.playbackRate,previous=v.src;
          let seek=null;const seeking=()=>{seek=v.currentTime;};
          try{
            v.pause();v.src=next.url;v.load();v.addEventListener('seeking',seeking);
            await waitDecoded(v,current);if(!current())return;
            v.removeEventListener('seeking',seeking);
            v.currentTime=Math.min(seek??time,Math.max(0,(model.duration||time)-1/60));v.muted=muted;v.playbackRate=rate;
            Object.assign(model.final_preview,next);notice('');if(playing)await v.play();tick(v.currentTime);
          }catch(error){
            v.removeEventListener('seeking',seeking);
            if(current()){
              v.src=previous;v.load();await waitDecoded(v,current);if(!current())return;
              v.currentTime=seek??time;v.muted=muted;v.playbackRate=rate;if(playing)await v.play();
            }
            throw error;
          }finally{v.removeEventListener('seeking',seeking);}
        }catch(error){if(current()){if(error.retry)invalidate(true);else notice(error.message||'Preview audio could not refresh.');}}
      }
    })();audioTask=task;
    try{await task;}finally{
      if(audioTask===task){
        audioTask=null;
        // A media edit can invalidate a running mix and then be undone before
        // it finishes. Start the newest pending request after that job settles.
        if(audioWanted){const next=audioWanted;void refreshAudio(next.data,next.owner,next.model,next.mine);}
      }
    }
  }
  async function waitDecoded(v,current){
    if(v.readyState>=2)return;
    await new Promise((resolve,reject)=>{const clean=()=>{clearTimeout(timeout);v.removeEventListener('loadeddata',ok);v.removeEventListener('error',bad);};
      const ok=()=>{clean();resolve();},bad=()=>{clean();reject(Error('The preview video could not be played.'));};
      const timeout=setTimeout(()=>{clean();reject(Error('Preview loading timed out.'));},20000);
      v.addEventListener('loadeddata',ok);v.addEventListener('error',bad);});
    if(!current())return;
  }
  async function decoded(current){await Promise.all([waitDecoded(byId('pvVo'),current),overlayReady]);}
  const changed=()=>{editVersion++;invalidate(true);};
  return {active,options,reset,begin,ready,invalidate,tick,canPlay,request,decoded,changed,snapshot:viewStamp,refresh};
})();
