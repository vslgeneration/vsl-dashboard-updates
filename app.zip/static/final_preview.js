/* Assemble playback uses a single movie from the production renderer. */
window.FinalPreview = (() => {
  const byId=id=>document.getElementById(id);
  let stamp='',dirty=false,checking=0,building=false,editVersion=0;
  const options=()=>({final_preview:true,kenburns:!!byId('rndKenburns')?.checked,
    music:byId('rndMusic')?.checked!==false,burnsubs:byId('rndBurnSubs')?.checked!==false,
    onscreentext:byId('rndOnscreen')?.checked!==false,transitions:byId('rndTransitions')?.checked!==false,
    low_priority:true});
  const active=()=>!!PV.m?.final_preview;
  function viewStamp(){
    const d={...DOC};for(const k of ['_revision','history','undo_history','redo_history','preview_built','generation_completed','updated_at','modified_at','last_opened'])delete d[k];
    return JSON.stringify([d,options(),editVersion]);
  }
  function reset(){stamp='';dirty=false;checking=0;byId('pvStage')?.classList.remove('pv-final-mode');byId('pvVo').hidden=true;const badge=byId('pvFinalNotice');if(badge)badge.hidden=true;}
  function begin(m){reset();if(!m.final_preview)return;byId('pvStage').classList.add('pv-final-mode');byId('pvVo').hidden=false;byId('pvImgOnly').hidden=true;}
  function ready(){stamp=PV.m?.final_preview?.viewStamp||viewStamp();dirty=false;checking=0;invalidate();}
  function invalidate(force=false){
    if(!active()||dirty||!stamp||(!force&&stamp===viewStamp()))return;
    dirty=true;byId('pvVo').pause();cancelAnimationFrame(PV.raf);
    byId('pvPlay').textContent='▶';byId('pvBig').hidden=false;
    byId('buildPreviewBtn').textContent='🔄 Rebuild Preview';
    let note=byId('pvFinalNotice');if(!note){note=document.createElement('div');note.id='pvFinalNotice';byId('pvStage').append(note);}
    note.textContent='Changes pending · Rebuild Preview';note.hidden=false;
  }
  function tick(t){
    if(!active())return false;
    if(performance.now()-checking>500){checking=performance.now();invalidate();}
    const m=PV.m;PV.renderTime=t;PV.scene=m.scenes.findIndex(s=>t>=s.start&&t<s.end);
    const pct=m.duration?Math.max(0,Math.min(100,t/m.duration*100)):0;
    byId('pvProgress').style.width=pct+'%';byId('pvHead').style.left=pct+'%';
    pvTextTrackHead(t);byId('pvTime').textContent=`${pvFmt(t)} / ${pvFmt(m.duration)}`;pvUpdateSceneLink();
    return true;
  }
  function canPlay(){
    if(!active())return true;invalidate();if(!dirty)return true;
    if(!building){building=true;const owner=musicContext();
      buildPreview({currentTarget:byId('buildPreviewBtn')}).then(()=>{if(musicCurrent(owner)&&active()&&!dirty)pvPlay();}).finally(()=>{building=false;});}
    return false;
  }
  async function request(project,current,status,restore,requestedStamp=viewStamp()){
    const post=await fetch(`/api/render/${project}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options(),cache_only:!!restore})});
    let response=await post.json();if(!current())return null;
    if(!post.ok||response.error)throw Error(response.error||'Preview failed');
    if(restore&&!response.cached)return null;
    const token=response.fingerprint;
    while(!response.cached){
      await new Promise(r=>setTimeout(r,900));if(!current())return null;
      const r=await fetch(`/api/render/${project}`);if(!r.ok)throw Error('Could not read preview progress');
      response=await r.json();if(!current())return null;
      if(response.fingerprint!==token||!response.final_preview)throw Error('The preview job changed. Build Preview again.');
      if(response.status==='error')throw Error(response.error||'Preview failed');
      if(response.status==='cancelled')throw Error('Preview cancelled');
      if(response.status==='done')break;
      status.textContent=(response.step||'Preparing preview…')+(Number.isFinite(response.pct)?` ${Math.round(response.pct)}%`:'');
    }
    return {file:response.file,fingerprint:token,viewStamp:requestedStamp,url:`/media/${project}/${response.file}?preview=${token}`};
  }
  async function decoded(current){
    const v=byId('pvVo');if(v.readyState>=2)return;
    await new Promise((resolve,reject)=>{const clean=()=>{clearTimeout(timer);v.removeEventListener('loadeddata',ok);v.removeEventListener('error',bad);};
      const ok=()=>{clean();resolve();},bad=()=>{clean();reject(Error('The preview video could not be played.'));};
      const timer=setTimeout(()=>{clean();reject(Error('Preview loading timed out.'));},20000);
      v.addEventListener('loadeddata',ok);v.addEventListener('error',bad);v.load();});
    if(!current())return;
  }
  const changed=()=>{editVersion++;invalidate(true);};
  return {active,options,reset,begin,ready,invalidate,tick,canPlay,request,decoded,changed,snapshot:viewStamp};
})();
