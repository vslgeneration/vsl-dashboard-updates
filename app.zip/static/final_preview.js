/* Live source-media preview with independently editable production overlay layers. */
window.FinalPreview = (() => {
  const byId=id=>document.getElementById(id);
  let stamp='',checkedStamp='',dirty=false,checking=0,building=false,editVersion=0;
  let timer=0,epoch=0,refreshing=null,refreshAgain=false,overlayReady=Promise.resolve(),audioRequest=0,audioTask=null,audioWanted=null;
  let foregroundBase='',localStamp='',bindings=[],visualSources=new Map(),timingPreview=[],captionPreview=[],localSerial=0,captionStyleStamp='';
  let playIntent=null,playTicket=0;
  const textStyleStamp=ref=>JSON.stringify(ref,(k,v)=>['ost_in','ost_out','timeline_lane'].includes(k)?undefined:v);
  const options=()=>({final_preview:true,live_overlays:true,realtime:true,kenburns:!!byId('rndKenburns')?.checked,
    music:byId('rndMusic')?.checked!==false,burnsubs:byId('rndBurnSubs')?.checked!==false,
    onscreentext:byId('rndOnscreen')?.checked!==false,transitions:byId('rndTransitions')?.checked!==false,
    low_priority:true});
  const active=()=>!!PV.m?.final_preview;
  function viewStamp(){
    const d={...DOC};for(const k of ['_revision','history','undo_history','redo_history','preview_built','generation_completed','updated_at','modified_at','last_opened'])delete d[k];
    return JSON.stringify([d,options(),editVersion],(key,value)=>key==='generation_records'?undefined:value);
  }
  function foregroundBaseStamp(){
    // Only a known foreground edit may keep playback running before the server
    // confirms its picture fingerprint. Media, cuts and framing remain guarded.
    const d={...DOC,scenes:(DOC?.scenes||[]).map(s=>{
      const row={...s};for(const k of ['effect_windows','fx_on','grain_on','grain','atmo','overlays','icons','ost_on','split_people','product_mode','ref_free'])delete row[k];
      // Saving older projects fills generation-only defaults. That must not
      // turn a foreground deletion into a pending picture change.
      if(Array.isArray(s.overlays))delete row.onscreen;
      if(row.cont_of==null)delete row.cont_of;
      if(s.video){row.video={...s.video};delete row.video.api;}
      if(s.image){row.image={...s.image};delete row.image.version_models;if(row.image.approved_file==null)delete row.image.approved_file;}
      return row;
    })};
    for(const k of ['_revision','history','undo_history','redo_history','preview_built','generation_completed','updated_at','modified_at','last_opened','film_dust','ost_matte_policy','subtitle_style'])delete d[k];
    const opt={...options()};delete opt.onscreentext;delete opt.burnsubs;
    return JSON.stringify([d,opt],(k,v)=>k==='generation_records'?undefined:
      v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(key=>[key,v[key]])):v);
  }
  function sourceScene(spec){return (DOC?.scenes||[]).find(s=>spec.scene_uid?s.uid===spec.scene_uid:s.id===spec.scene_id);}
  function captureLayers(manifest){
    bindings=[];localStamp='';captionStyleStamp=JSON.stringify(DOC?.subtitle_style||{});
    for(const type of ['texts','icons'])for(const spec of manifest?.[type]||[]){
      if(type==='texts'&&spec.kind!=='ost')continue;
      const sc=sourceScene(spec),rows=type==='icons'?sc?.icons:(sc?.overlays||[]).filter(o=>(o.onscreen||'').trim());
      const ref=rows?.[type==='icons'?spec.icon_index:spec.text_index];
      if(ref)bindings.push({type,spec,ref,signature:JSON.stringify(ref),styleSignature:textStyleStamp(ref)});
    }
    for(const spec of manifest?.visuals||[])visualSources.set(JSON.stringify([spec.scene_uid??spec.scene_id,spec.key]),spec);
  }
  function textTiming(spec,start,end,sceneEnd){
    const s={...spec,start,end,start_frame:pvEffectFrame(start*60),end_frame:pvEffectFrame(end*60)};
    let template=spec.animation_template||spec.animation||{};
    const catalog=PV.m?.final_preview?.overlays?.text_animations,duration=Math.max(0,end-start),ost=s.kind==='ost';
    if(catalog){const incoming=catalog.in[spec.anim||'fade'],outgoing=catalog.out[spec.desired_out_anim??spec.out_anim??'none'];template={...template,in:incoming?.in,out:outgoing?.out,in_frames:incoming?.in_frames||0,out_frames:outgoing?.out_frames||0};}
    let di=(template.in_frames||0)/60,do_=(template.out_frames||0)/60;
    if(ost){di=Math.min(spec.anim==='fade'?.65:di,duration/2);do_=pvEffectFrame(end*60)>=pvEffectFrame(sceneEnd*60)?0:Math.min(do_,duration/2);}
    if(di+do_>duration){const f=duration/(di+do_);di*=f;do_*=f;}
    const count=Math.max(1,pvEffectFrame(duration*60)),ni=Math.min(count,pvEffectFrame(di*60)),no=Math.min(count-ni,pvEffectFrame(do_*60));
    s.animation={...template,frames:count,in_frames:ni,out_frames:no};return s;
  }
  function localText(spec,ref,start,end,sceneEnd){
    const s=textTiming({...spec,anim:ref.ost_anim??spec.anim,desired_out_anim:ref.ost_out_anim??spec.desired_out_anim},start,end,sceneEnd),style={...spec.style,...ref};delete style.onscreen;
    s.text=ref.onscreen??s.text;s.style=style;s.html=null;s.signed_layout=true;
    if(typeof ostTextStyle==='function'){
      const inner=document.createElement('span');inner.style.cssText=spec.inner_css;
      const opts=Object.fromEntries(Object.entries(style).filter(([k])=>k.startsWith('ost_')).map(([k,v])=>[k.slice(4),v]));
      ostTextStyle(inner,{size:46,bg_opacity:62,bg_pad:14,bg_radius:10,...opts},1);s.inner_css=inner.style.cssText;
      const outer=document.createElement('div');outer.style.cssText=spec.outer_css;
      const place=ref.ost_place||spec.place||'top';outer.style.top=place==='top'?'6%':place==='center'?'50%':'auto';outer.style.bottom=place==='bottom'?'6%':'auto';
      ostWrapPos(outer,place,ref.ost_x??spec.x,ref.ost_y??spec.y,1,ref.ost_rotation??spec.rotation);s.outer_css=outer.style.cssText;
    }
    return s;
  }
  function previewTiming(bars){timingPreview=bars?[...bars]:[];localLayers('drag-'+(++localSerial));}
  function previewCaptions(changes){captionPreview=changes||[];localLayers('caption-'+(++localSerial));}
  function localCaption(spec,cue){
    const style={...(typeof subDefaults==='function'?subDefaults():{}),...spec.style,...(DOC?.subtitle_style||{})};
    const s=textTiming({...spec,anim:style?.ost_anim??spec.anim,desired_out_anim:style?.ost_out_anim??spec.out_anim},cue.start,cue.end,Infinity);
    if(cue.text===(spec.source_text??spec.text)&&captionStyleStamp===JSON.stringify(DOC?.subtitle_style||{}))return s;
    s.text=cue.text;s.words=cue.words||spec.words;s.style=style;s.html=null;
    if(typeof styleCaption==='function'){
      const inner=document.createElement('span'),outer=document.createElement('div');
      inner.style.cssText=spec.inner_css;outer.style.cssText=spec.outer_css;
      styleCaption(inner,outer,PV.m.final_preview.overlays.width,style,PV.m.final_preview.overlays.width,true);
      if(s.canonical){inner.style.whiteSpace='pre';inner.style.overflowWrap='normal';inner.style.maxWidth='none';inner.style.width='max-content';}
      s.inner_css=inner.style.cssText;s.outer_css=outer.style.cssText;
    }
    return s;
  }
  function localLayers(wanted=viewStamp()){
    if(!active()||!PV.m.final_preview.overlays||PV.owner&&!musicCurrent(PV.owner))return;
    if(localStamp===wanted)return;localStamp=wanted;
    if(PV.m.final_preview.realtime)window.LiveMedia?.local(DOC,options());
    const original=PV.m.final_preview.overlays,manifest={...original};
    const framed=s=>({...s,start_frame:pvEffectFrame(s.start*60),end_frame:pvEffectFrame(s.end*60)});
    const dragFor=(sc,key,ref)=>timingPreview.find(b=>b.sceneUid===sc?.uid&&(key?b.effect?.key===key:(b.ic||b.ov)===ref));
    const dragEffect=spec=>{const b=dragFor(sourceScene(spec),spec.key);if(!b)return spec;const half=Math.floor((pvEffectFrame(b.absEnd*60)-pvEffectFrame(b.absStart*60))/2)/60;return {...spec,start:pvEffectFrame(b.absStart*60)/60,end:pvEffectFrame(b.absEnd*60)/60,fade_in:Math.min(half,spec.fade_in||0),fade_out:Math.min(half,spec.fade_out||0)};};
    manifest.visuals=[...visualSources.values()].filter(spec=>{
      const sc=sourceScene(spec);if(!sc||sc.speaker_clip||sc.tcard_id||sc.testimonial)return false;
      if(['effect1','effect2','dust'].includes(spec.key))return sc.fx_on&&['natural','scientific'].includes(sc.style)&&(spec.key!=='dust'||DOC.film_dust);
      if(['grain','filmgrain'].includes(spec.key))return sc.grain_on||sc.grain;
      if(spec.key.startsWith('atmo-'))return spec.key==='atmo-'+sc.atmo;
      return true;
    }).map(spec=>pvEffectWindow(spec,pvEffectScene(spec))).filter(Boolean).map(dragEffect).map(framed);
    manifest.plates=options().onscreentext?(PV.m.scenes||[]).flatMap(ps=>{
      const sc=sourceScene({scene_uid:ps.uid,scene_id:ps.id});
      let texts=sc?sceneTL(sc):ps.texts;
      if(sc&&timingPreview.length){const refs=(sc.overlays||[]).filter(o=>(o.onscreen||'').trim());texts=(texts||[]).map((o,i)=>{const b=dragFor(sc,null,refs[i]);return b?{...o,text_in:(b.absStart-ps.start)/(ps.end-ps.start),text_out:(b.absEnd-ps.start)/(ps.end-ps.start)}:o;});}
      return pvPlateWindows({...ps,texts});
    }).map(dragEffect).map(framed):[];
    manifest.icons=[];manifest.texts=[];
    if(options().burnsubs)for(const spec of original.texts||[]){
      if(spec.kind!=='caption')continue;
      const cue=spec.display_id?(PV.m.caption_items||PV.m.captions||[]).find(c=>c.display_id===spec.display_id):null;
      const edit=captionPreview.find(c=>c.id===spec.display_id)?.edit;
      const next={...(cue||spec),...(edit||{})};
      if(next.display_hidden||next.hidden||!(next.text||'').trim())continue;
      manifest.texts.push(localCaption(spec,next));
    }
    const used=new Set(),resolvedRefs=new Map();
    for(const b of bindings){
      const sc=sourceScene(b.spec);if(!sc||b.type==='texts'&&(!sc.ost_on||!options().onscreentext))continue;
      const rows=b.type==='icons'?sc.icons||[]:sc.overlays||[];
      const ref=rows.includes(b.ref)?b.ref:resolvedRefs.get(b.ref)||rows.find(o=>!used.has(o)&&JSON.stringify(o)===b.signature);
      // A burst/sparkle has several native animation events for one icon.
      if(!ref)continue;used.add(ref);resolvedRefs.set(b.ref,ref);
      const ps=pvEffectScene(b.spec);if(!ps)continue;
      const drag=dragFor(sc,null,ref),span=ps.end-ps.start,clamp=v=>Math.max(0,Math.min(1,Number(v)||0));
      let start=drag?.absStart??ps.start+span*clamp(ref[b.type==='icons'?'in':'ost_in']??0);
      let end=drag?.absEnd??ps.start+span*clamp(ref[b.type==='icons'?'out':'ost_out']??1);
      if(end<=start)continue;
      if(b.type==='texts')manifest.texts.push(textStyleStamp(ref)===b.styleSignature?textTiming(b.spec,start,end,ps.end):localText(b.spec,ref,start,end,ps.end));
      else{
        start=pvEffectFrame(start*60)/60;end=pvEffectFrame(end*60)/60;
        const s={...b.spec},delta=start-(s.authored_start??s.start),repeated=['burst','sparkle'].includes(s.kind);
        const prior=JSON.parse(b.signature);
        s.live_transform={x:((ref.x??.5)-(prior.x??.5))*original.width,y:((ref.y??.5)-(prior.y??.5))*original.height,
          scale:(ref.size||1)/(prior.size||1),rotation:(ref.rot||0)-(prior.rot||0),flip:!!ref.flip!==!!prior.flip};
        if(Number.isInteger(ref.overlay_layer))s.overlay_rank=ref.overlay_layer;
        s.start+=delta;s.end=repeated?Math.min(end,s.end+delta):end;s.window_end=end;
        if(s.end<=s.start)continue;
        const fade=s.kind==='cancel'||end<ps.end-1e-6?Math.min(.3,(end-start)/2):0;
        if(s.motion)s.motion={...s.motion,exit_start:end-fade-s.start,exit_duration:fade};
        else{s.fade_out=fade;if(s.loop&&s.source_duration){const tail=(pvEffectFrame(end*60)-pvEffectFrame(start*60))%pvEffectFrame(s.source_duration*60);if(tail>0&&tail<12)s.end-=tail/60;}}
        manifest.icons.push(framed(s));
      }
    }
    // Newly added/duplicated text has no server binding yet. It is still a local
    // text layer, so create it now using the same style/animation renderer.
    if(options().onscreentext)for(const ps of PV.m.scenes||[]){
      const sc=sourceScene({scene_uid:ps.uid,scene_id:ps.id});if(!sc?.ost_on)continue;
      for(const ref of sc.overlays||[]){if(used.has(ref)||!(ref.onscreen||'').trim())continue;
        const start=ps.start+(ps.end-ps.start)*(ref.ost_in??0),end=ps.start+(ps.end-ps.start)*(ref.ost_out??1);
        const seed={kind:'ost',scene_id:ps.id,scene_uid:sc.uid,style:{},outer_css:'position:absolute;left:50%;width:max-content;',inner_css:'display:inline-block;white-space:pre;',start,end};
        manifest.texts.push(localText(seed,ref,start,end,ps.end));
      }
    }
    if(PV.m.final_preview.realtime&&typeof pvDipWindows==='function'){
      const scenes=PV.m.scenes.map(ps=>{const sc=sourceScene({scene_uid:ps.uid,scene_id:ps.id});return {...ps,...(sc?{transition:effectiveSceneTransition(sc,DOC.scenes[DOC.scenes.indexOf(sc)+1])}: {})};});
      manifest.dips=options().transitions?pvDipWindows({...PV.m,scenes}).map(framed):[];
      if(!options().transitions)manifest.transitions=[];
      else{
        const catalog=new Map((original.transitions||[]).map(s=>[s.key,s]));
        manifest.transitions=scenes.slice(0,-1).flatMap(ps=>{
          const spec=catalog.get(ps.transition);if(!spec)return [];
          const start=Math.max(0,ps.end-(spec.hit??((spec.cut??ps.end)-spec.start)));
          return [framed({...spec,cut:ps.end,start,end:start+spec.source_duration/spec.speed})];
        });
      }
    }
    // No HTTP or renderer in this path. The save/manifest reconciliation still
    // validates the authoritative result and cannot resurrect an older edit.
    void window.LiveOverlays?.update(manifest,()=>active()&&localStamp===wanted).catch(overlayError);
  }
  function notice(text){
    let node=byId('pvFinalNotice');
    if(!node&&text){node=document.createElement('div');node.id='pvFinalNotice';byId('pvStage').append(node);}
    if(node){node.textContent=text||'';node.hidden=!text;}
  }
  const overlayError=()=>{if(active())notice('A preview overlay could not load. Build Preview again.');};
  const mediaError=event=>{if(active())notice(event.detail?.message||'A preview source could not load.');};
  function reset(){
    cancelPlay(false);
    epoch++;audioRequest++;audioWanted=null;audioTask=null;clearTimeout(timer);timer=0;refreshing=null;refreshAgain=false;
    stamp='';checkedStamp='';dirty=false;checking=0;building=false;overlayReady=Promise.resolve();window.LiveOverlays?.clear();
    window.LiveMedia?.clear();
    foregroundBase='';localStamp='';bindings=[];visualSources.clear();timingPreview=[];captionPreview=[];
    byId('pvStage')?.removeEventListener('liveoverlayerror',overlayError);
    byId('pvStage')?.removeEventListener('livemediaerror',mediaError);PV.nativeKaraScene=null;
    byId('pvStage')?.classList.remove('pv-final-mode','pv-native-mode');byId('pvVo').hidden=true;notice('');
  }
  function begin(m){
    reset();if(!m.final_preview)return;
    byId('pvStage').classList.add('pv-final-mode');byId('pvVo').hidden=false;byId('pvImgOnly').hidden=true;
    byId('pvStage').addEventListener('liveoverlayerror',overlayError);
    byId('pvStage').addEventListener('livemediaerror',mediaError);
    captureLayers(m.final_preview.overlays);foregroundBase=foregroundBaseStamp();
    if(m.final_preview.realtime){
      const owner=musicContext(),mine=epoch;
      byId('pvStage').classList.add('pv-native-mode');
      window.LiveMedia.mount(byId('pvStage'),byId('pvVo'),m,options(),()=>epoch===mine&&PV.m===m&&musicCurrent(owner));
    }
    overlayReady=Promise.resolve(window.LiveOverlays?.mount(byId('pvStage'),byId('pvVo'),m.final_preview.overlays));
  }
  function ready(){
    stamp=PV.m?.final_preview?.viewStamp||viewStamp();checkedStamp=stamp;dirty=false;checking=0;invalidate();
    const f=PV.m?.final_preview;
    if(!f?.realtime&&f?.desired_audio_fingerprint&&f.audio_fingerprint!==f.desired_audio_fingerprint)
      void refreshAudio({audio_fingerprint:f.desired_audio_fingerprint,base_fingerprint:f.desired_base_fingerprint},musicContext(),PV.m,epoch,stamp);
  }
  function markBaseDirty(){
    dirty=true;audioRequest++;audioWanted=null;byId('pvVo').pause();cancelAnimationFrame(PV.raf);
    byId('pvPlay').textContent='▶';byId('pvBig').hidden=false;
    byId('buildPreviewBtn').textContent='🔄 Rebuild Preview';notice('Video changes pending · Rebuild Preview');
    // A revision-conflict retry may discover a real picture change after the
    // original click's refresh task has finished. Continue that same request.
    const intent=playIntent;
    if(intent&&!building)setTimeout(()=>{if(playIntent===intent&&!building)canPlay();},0);
  }
  async function compose(project,current){
    const owner=musicContext(),known=typeof _serverDocument!=='undefined'?_serverDocument:null;
    const revision=known?.project===project&&known.epoch===owner.epoch?known.doc?._revision:DOC?._revision;
    const r=await fetch(`/api/preview-live/${encodeURIComponent(project)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options(),project_revision:revision})});
    const data=await r.json();if(!current())return null;
    if(!r.ok||data.error){const error=Error(data.error||'Preview layers could not be prepared.');error.retry=r.status===409;throw error;}
    if(!data.overlays||!data.video_fingerprint||!data.base_fingerprint)throw Error('Preview layers are incomplete.');
    return data;
  }
  async function saved(){
    const value=await flushSave();
    if(!value||value.error||!Array.isArray(value.scenes))throw Error(value?.error||'Changes could not be saved.');
  }
  function adoptManifest(data){
    if(data.manifest)Object.assign(PV.m,data.manifest);
    PV.scene=-1;PV.cap=-1;
    if(!document.querySelector('.pv-tt-bar.dragging'))pvBuildTextTrack();
    window.CaptionEditor?.renderTimeline?.();
  }
  async function refresh(){
    if(!active()||!stamp)return;
    if(refreshing){refreshAgain=true;return refreshing;}
    const mine=epoch,owner=musicContext(),model=PV.m;
    const current=()=>epoch===mine&&musicCurrent(owner)&&PV.m===model&&active();
    const task=(async()=>{
      try{
        await saved();if(!current())return;
        const wanted=viewStamp(),data=await compose(owner.project,current);if(!data||!current())return;
        if(wanted!==viewStamp()){refreshAgain=true;return;}
        checkedStamp=wanted;
        if(!model.final_preview.realtime&&data.video_fingerprint!==model.final_preview.video_fingerprint){markBaseDirty();return;}
        const old=model.final_preview;
        // The picture is already decoded. A foreground font/icon decoder must
        // not hold Play or the accepted manifest behind its readiness promise.
        void window.LiveOverlays.update(data.overlays,()=>current()&&wanted===viewStamp()).catch(error=>{if(current()&&wanted===viewStamp())overlayError(error);});
        if(!current())return;
        if(wanted!==viewStamp()){refreshAgain=true;return;}
        adoptManifest(data);old.overlays=data.overlays;old.overlay_revision=data.overlay_revision;old.viewStamp=wanted;old.desired_audio_fingerprint=data.audio_fingerprint;
        if(old.realtime){
          old.video_fingerprint=data.video_fingerprint;old.audio_fingerprint=data.audio_fingerprint;
          window.LiveMedia.update(model,options());window.LiveMedia.capture(DOC);
          if(model.vo&&model.vo!==old.url){window.LiveMedia.voice(model.vo);old.url=model.vo;}
        }
        captureLayers(data.overlays);foregroundBase=foregroundBaseStamp();
        dirty=false;stamp=wanted;notice('');localLayers();tick(byId('pvVo').currentTime||0);
        resumePlay();
        // A clock icon can move its automatic sound. Reuse all picture sections
        // and refresh only the continuous audio/mux without blocking layer edits.
        if(!old.realtime&&data.audio_fingerprint!==old.audio_fingerprint)void refreshAudio(data,owner,model,mine,wanted);
      }catch(error){if(current()){if(error.retry)refreshAgain=true;else{cancelPlay();notice(error.message||'Preview layers could not refresh.');}}}
    })();
    refreshing=task;
    try{await task;}finally{if(epoch===mine){refreshing=null;if(refreshAgain){refreshAgain=false;clearTimeout(timer);timer=setTimeout(()=>void refresh(),160);}}}
  }
  function invalidate(force=false){
    if(!active()||!stamp)return;
    const wanted=viewStamp();localLayers(wanted);
    if(!force&&checkedStamp===wanted)return;
    clearTimeout(timer);timer=setTimeout(()=>{timer=0;void refresh();},140);
  }
  function tick(t){
    if(!active())return false;
    if(performance.now()-checking>500){checking=performance.now();invalidate();}
    const m=PV.m;PV.renderTime=t;PV.scene=m.scenes.findIndex(s=>t>=s.start&&t<s.end);
    if(m.final_preview.realtime){
      window.LiveMedia?.tick(t);
      const sc=m.scenes[PV.scene];
      if(typeof pvSetKaraoke==='function'&&PV.nativeKaraScene!==sc){PV.nativeKaraScene=sc;pvSetKaraoke(sc);}
      if(typeof pvKaraokeTick==='function')pvKaraokeTick(t);
    }
    PV.cap=(m.captions||[]).findIndex(c=>t>=c.start&&t<c.end);window.LiveOverlays?.tick(t);
    const pct=m.duration?Math.max(0,Math.min(100,t/m.duration*100)):0;
    byId('pvProgress').style.width=pct+'%';byId('pvHead').style.left=pct+'%';
    pvTextTrackHead(t);byId('pvTime').textContent=`${pvFmt(t)} / ${pvFmt(m.duration)}`;pvUpdateSceneLink();return true;
  }
  function cancelPlay(user=true){playIntent=null;if(user){playTicket++;window.LiveMedia?.cancelResume?.();}}
  function playPending(){return !!playIntent;}
  function resumePlay(){
    const intent=playIntent;if(!intent)return;
    if(intent.epoch!==epoch||!musicCurrent(intent.owner)||PV.m!==intent.model){cancelPlay();return;}
    if(dirty||!active()||(stamp!==viewStamp()&&foregroundBase!==foregroundBaseStamp()))return;
    playIntent=null;pvPlay();
  }
  function canPlay(){
    if(!active())return true;
    if(PV.m.final_preview.realtime){cancelPlay();localLayers();invalidate();return true;}
    if(!dirty&&stamp===viewStamp())return true;
    if(!dirty&&foregroundBase===foregroundBaseStamp()){localLayers();invalidate();return true;}
    if(!playIntent)playIntent={owner:musicContext(),epoch,model:PV.m};
    if(!building){building=true;const intent=playIntent,mine=epoch;
      (async()=>{await refresh();if(epoch!==mine||!musicCurrent(intent.owner)||!active()||playIntent!==intent)return;
        if(dirty){
          const task=buildPreview({currentTarget:byId('buildPreviewBtn')}),ticket=playTicket,request=PV.buildRequest;
          await task;
          // begin() resets the old model. A successful explicit rebuild owns a
          // new one; never carry a queued click across project/tab changes.
          if(ticket===playTicket&&request===PV.buildRequest&&musicCurrent(intent.owner)&&active()&&PV.m!==intent.model&&!dirty&&stamp===viewStamp())pvPlay();
        }else resumePlay();
      })().catch(error=>{if(epoch===mine&&musicCurrent(intent.owner)){cancelPlay();notice(error.message||'Preview could not refresh.');}}).finally(()=>{if(epoch===mine)building=false;});}
    return false;
  }
  async function movie(project,current,status,restore,expected){
    const post=await fetch(`/api/render/${encodeURIComponent(project)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options(),cache_only:!!restore,base_fingerprint:expected?.base_fingerprint})});
    let response=await post.json();if(!current())return null;
    if(!post.ok||response.error){const error=Error(response.error||'Preview failed');error.retry=post.status===409;throw error;}
    if(restore&&!response.cached)return null;
    const token=response.fingerprint;
    while(!response.cached){
      await new Promise(r=>setTimeout(r,450));if(!current())return null;
      const r=await fetch(`/api/render/${encodeURIComponent(project)}`);if(!r.ok)throw Error('Could not read preview progress');
      response=await r.json();if(!current())return null;
      if(response.fingerprint!==token||!response.final_preview)throw Error('The preview job changed. Build Preview again.');
      if(response.status==='error')throw Error(response.error||'Preview failed');
      if(response.status==='cancelled')throw Error('Preview cancelled');
      if(response.status==='done')break;
      if(status)status.textContent=(response.step||'Preparing preview…')+(Number.isFinite(response.pct)?` ${Math.round(response.pct)}%`:'');
    }
    return {...response,file:response.file,fingerprint:token,url:`/media/${encodeURIComponent(project)}/${response.file}?preview=${token}`};
  }
  async function request(project,current,status,restore,requestedStamp=viewStamp()){
    let data=await compose(project,current);if(!data||!current())return null;
    if(!data.manifest?.scenes?.length)throw Error('Approve an image or video before building the preview.');
    if(data.realtime)return {realtime:true,final_preview:true,live_overlays:true,url:data.manifest.vo,
      video_fingerprint:data.video_fingerprint,audio_fingerprint:data.audio_fingerprint,base_fingerprint:data.base_fingerprint,
      viewStamp:requestedStamp,overlays:data.overlays,overlay_revision:data.overlay_revision,manifest:data.manifest};
    const rendered=await movie(project,current,status,restore,data);if(!rendered||!current())return null;
    // Resolve edits made during the long base build before revealing its layers.
    let attempts=0;
    while(requestedStamp!==viewStamp()){
      if(++attempts>3)throw Error('The project is still changing. Build Preview again after editing.');
      if(!restore)await saved();if(!current())return null;
      requestedStamp=viewStamp();data=await compose(project,current);if(!data)return null;
    }
    if(rendered.video_fingerprint!==data.video_fingerprint)throw Error('The video changed while preparing the preview. Build Preview again.');
    return {...rendered,desired_audio_fingerprint:data.audio_fingerprint,desired_base_fingerprint:data.base_fingerprint,viewStamp:requestedStamp,overlays:data.overlays,overlay_revision:data.overlay_revision,manifest:data.manifest};
  }
  async function refreshAudio(data,owner,model,mine,wanted){
    audioWanted={data,owner,model,mine};if(audioTask)return audioTask;
    const id=++audioRequest;
    const task=(async()=>{
      while(audioWanted&&id===audioRequest){
        const target=audioWanted;audioWanted=null;
        const {owner,model,mine}=target,current=()=>id===audioRequest&&epoch===mine&&musicCurrent(owner)&&PV.m===model&&!dirty;
        if(!current())return;notice('Updating preview audio…');
        try{
          // Complete one audio job before starting the newest requested mix.
          const next=await movie(owner.project,current,null,false,target.data);if(!next||!current())return;
          if(next.video_fingerprint!==model.final_preview.video_fingerprint){markBaseDirty();return;}
          if(next.audio_fingerprint!==model.final_preview.desired_audio_fingerprint)continue;
          const v=byId('pvVo'),playing=!v.paused,time=v.currentTime,muted=v.muted,rate=v.playbackRate,previous=v.src;
          let seek=null;const seeking=()=>{seek=v.currentTime;};
          try{
            v.pause();v.src=next.url;v.load();v.addEventListener('seeking',seeking);
            await waitDecoded(v,current);if(!current())return;
            v.removeEventListener('seeking',seeking);
            v.currentTime=Math.min(seek??time,Math.max(0,(model.duration||time)-1/60));v.muted=muted;v.playbackRate=rate;
            Object.assign(model.final_preview,next);notice('');if(playing)await v.play();tick(v.currentTime);
          }catch(error){
            v.removeEventListener('seeking',seeking);
            if(current()){
              v.src=previous;v.load();await waitDecoded(v,current);if(!current())return;
              v.currentTime=seek??time;v.muted=muted;v.playbackRate=rate;if(playing)await v.play();
            }
            throw error;
          }finally{v.removeEventListener('seeking',seeking);}
        }catch(error){if(current()){if(error.retry)invalidate(true);else notice(error.message||'Preview audio could not refresh.');}}
      }
    })();audioTask=task;
    try{await task;}finally{
      if(audioTask===task){
        audioTask=null;
        // A media edit can invalidate a running mix and then be undone before
        // it finishes. Start the newest pending request after that job settles.
        if(audioWanted){const next=audioWanted;void refreshAudio(next.data,next.owner,next.model,next.mine);}
      }
    }
  }
  async function waitDecoded(v,current){
    if(v.readyState>=2)return;
    await new Promise((resolve,reject)=>{const clean=()=>{clearTimeout(timeout);v.removeEventListener('loadeddata',ok);v.removeEventListener('error',bad);};
      const ok=()=>{clean();resolve();},bad=()=>{clean();reject(Error('The preview video could not be played.'));};
      const timeout=setTimeout(()=>{clean();reject(Error('Preview loading timed out.'));},20000);
      v.addEventListener('loadeddata',ok);v.addEventListener('error',bad);});
    if(!current())return;
  }
  async function decoded(current){
    if(PV.m?.final_preview?.realtime){void overlayReady.catch(overlayError);return;}
    await Promise.all([waitDecoded(byId('pvVo'),current),overlayReady]);
  }
  const changed=()=>{editVersion++;invalidate(true);};
  return {active,options,reset,begin,ready,invalidate,tick,canPlay,cancelPlay,playPending,request,decoded,changed,previewTiming,previewCaptions,snapshot:viewStamp,refresh};
})();
