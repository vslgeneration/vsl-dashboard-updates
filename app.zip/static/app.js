const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
// clean line-art trash icon (clearer than the OS emoji) for all delete buttons
const TRASH_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/><path d="M10 11v6M14 11v6"/></svg>';
// sparkle / magic-wand — "generate this character's portrait"
const MAGIC_SVG = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M10.5 2.2l1.9 5.4 5.4 1.9-5.4 1.9-1.9 5.4-1.9-5.4L3.2 9.5l5.4-1.9z"/><path d="M18.2 13.5l.85 2.45 2.45.85-2.45.85-.85 2.45-.85-2.45-2.45-.85 2.45-.85z"/></svg>';
// mirror line-art icons for project transfer: export = arrow up out of a tray, import = arrow down into a tray
const EXPORT_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M12 15V3"/><path d="M7 8l5-5 5 5"/></svg>';
const IMPORT_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/></svg>';
// folder with a "+" — matches the Import / Removed Projects icon weight
const GROUP_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v5"/><path d="M9.5 13.5h5"/></svg>';
let PROJECT = null;
let DOC = null;
let pollTimer = null;
let saveTimer = null;
let hideApproved = false;   // Scenes tab: hide approved scenes toggle
let _lastGenImgId = null, _lastGenVidId = null;   // most-recently generated image/video scene id (for the "jump to latest" button)
// Close a modal ONLY on a genuine backdrop click — a press that STARTS on the backdrop and releases on it.
// A drag that starts inside the panel (e.g. selecting text) and releases outside still fires a "click"
// whose target is the backdrop; without this guard that would wrongly close the window. Sets .onmousedown
// + .onclick (both cleared by callers that null bg.onclick / bg.onmousedown in their cleanup).
function bdClose(bg, closeFn) {
  bg.onmousedown = (e) => { bg.__downBg = (e.target === bg); };
  bg.onclick = (e) => { const hit = (e.target === bg && bg.__downBg); bg.__downBg = false; if (hit) closeFn(); };
}
// in-dashboard confirm popup (replaces the browser's native confirm)
function confirmDialog(message, { title = "Are you sure?", okText = "Delete", danger = true } = {}) {
  return new Promise((resolve) => {
    const bg = $("#confirmBg"), ok = $("#confirmOk"), cancel = $("#confirmCancel");
    $("#confirmTitle").textContent = title;
    $("#confirmMsg").textContent = message;
    ok.textContent = okText;
    ok.classList.toggle("danger", !!danger);
    bg.hidden = false;
    const onKey = (e) => { if (e.key === "Escape") done(false); else if (e.key === "Enter") done(true); };
    function done(v) {
      bg.hidden = true;
      ok.onclick = null; cancel.onclick = null; bg.onclick = null; bg.onmousedown = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    ok.onclick = () => done(true);
    cancel.onclick = () => done(false);
    bdClose(bg, () => done(false));
    document.addEventListener("keydown", onKey);
  });
}
// Two-way delete picker for a project. Resolves "dashboard" (soft, keep files) | "disk" (hard) | null.
function deleteProjectDialog(title) {
  return new Promise((resolve) => {
    const bg = $("#delChoiceBg");
    $("#delChoiceTitle").textContent = `Delete “${title}”?`;
    bg.hidden = false;
    const dash = $("#delFromDash"), disk = $("#delFromDisk"), cancel = $("#delChoiceCancel");
    const onKey = (e) => { if (e.key === "Escape") done(null); };
    function done(v) {
      bg.hidden = true;
      dash.onclick = disk.onclick = cancel.onclick = bg.onclick = bg.onmousedown = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    dash.onclick = () => done("dashboard");
    disk.onclick = () => done("disk");
    cancel.onclick = () => done(null);
    bdClose(bg, () => done(null));
    document.addEventListener("keydown", onKey);
  });
}
// parse "m:ss" / "h:mm:ss" / plain seconds → seconds (NaN if unparseable)
function parseTime(str) {
  str = String(str || "").trim(); if (!str) return NaN;
  if (str.includes(":")) {
    const p = str.split(":").map(x => parseFloat(x));
    if (p.some(n => isNaN(n))) return NaN;
    return p.reduce((s, n) => s * 60 + n, 0);
  }
  const n = parseFloat(str); return isFinite(n) ? n : NaN;
}
// Render-range picker: choose Full video or a Custom [start,end] slice. Resolves {start,end,full} or null.
function rangeDialog(fast, total) {
  return new Promise((resolve) => {
    const bg = $("#rndRangeBg"), ok = $("#rrOk"), cancel = $("#rrCancel");
    const fieldsWrap = $("#rrFieldsWrap"), startI = $("#rrStart"), endI = $("#rrEnd"), info = $("#rrInfo");
    const modes = bg.querySelectorAll(".rr-mode");
    $("#rrTitle").textContent = fast ? "Test Render" : "Render Video";
    const fmtTotal = pvFmt(total || 0);
    let mode = "full";
    const clampR = () => {
      let s = parseTime(startI.value), e = parseTime(endI.value);
      if (!isFinite(s)) s = 0;
      if (!isFinite(e)) e = total || 0;
      s = Math.max(0, Math.min(s, total || 0));
      e = Math.max(0, Math.min(e, total || 0));
      if (e <= s) e = Math.min(total || 0, s + 1);
      return { start: s, end: e };
    };
    const updateInfo = () => {
      if (mode !== "range") { info.textContent = `Whole video · ${fmtTotal}`; return; }
      const { start, end } = clampR();
      info.textContent = `${pvFmt(start)}–${pvFmt(end)} · ${pvFmt(end - start)} of ${fmtTotal}`;
    };
    const setMode = (m) => {
      mode = m; modes.forEach(b => b.classList.toggle("on", b.dataset.mode === m));
      fieldsWrap.classList.toggle("open", m === "range");   // smooth grid-rows expand / collapse
      if (m === "range" && !endI.value) endI.value = pvFmt(Math.min(30, total || 30));
      updateInfo();
    };
    const chips = bg.querySelectorAll(".rr-chip");
    const clearChips = () => chips.forEach(c => c.classList.remove("on"));
    startI.oninput = () => { clearChips(); updateInfo(); };     // manual edit -> no preset is "selected"
    endI.oninput = () => { clearChips(); updateInfo(); };
    modes.forEach(b => b.onclick = () => setMode(b.dataset.mode));
    chips.forEach(c => c.onclick = () => {
      startI.value = "0:00"; endI.value = pvFmt(Math.min(+c.dataset.secs, total || +c.dataset.secs));
      clearChips(); c.classList.add("on");                     // show which preset is active
      updateInfo();
    });
    setMode("full");
    try { const _g = localStorage.getItem("rndGpu"); $("#rrGpu").checked = (_g === null ? true : _g === "1"); $("#rrCpu").checked = localStorage.getItem("rndCpu") === "1"; } catch (e) {}
    bg.hidden = false;
    const onKey = (e) => { if (e.key === "Escape") done(null); else if (e.key === "Enter") submit(); };
    const renderOpts = () => { const gpu = $("#rrGpu").checked, cpu = $("#rrCpu").checked; try { localStorage.setItem("rndGpu", gpu ? "1" : ""); localStorage.setItem("rndCpu", cpu ? "1" : ""); } catch (e) {} return { gpu, cpu }; };
    function submit() { if (mode === "full") return done(Object.assign({ start: 0, end: total || 0, full: true }, renderOpts())); done(Object.assign({ ...clampR(), full: false }, renderOpts())); }
    function done(v) {
      ok.onclick = cancel.onclick = bg.onclick = bg.onmousedown = null;
      document.removeEventListener("keydown", onKey);
      bg.classList.add("closing");                          // smooth fade-out on Cancel / Render / Escape
      setTimeout(() => { bg.hidden = true; bg.classList.remove("closing"); resolve(v); }, 175);
    }
    ok.onclick = submit; cancel.onclick = () => done(null);
    bdClose(bg, () => done(null));
    document.addEventListener("keydown", onKey);
  });
}
// Styled replacement for window.prompt — same look as confirmDialog. Resolves the trimmed input,
// or null on cancel/Escape/empty.
function promptDialog(message, { title = "Name", okText = "Save", placeholder = "", value = "" } = {}) {
  return new Promise((resolve) => {
    const bg = $("#promptBg"), ok = $("#promptOk"), cancel = $("#promptCancel"), input = $("#promptInput");
    $("#promptTitle").textContent = title;
    const msg = $("#promptMsg"); msg.textContent = message || ""; msg.hidden = !message;
    ok.textContent = okText;
    input.placeholder = placeholder; input.value = value;
    bg.hidden = false;
    input.focus(); input.select();
    const onKey = (e) => { if (e.key === "Escape") done(null); else if (e.key === "Enter") submit(); };
    function submit() { const v = input.value.trim(); done(v || null); }
    function done(v) {
      bg.hidden = true;
      ok.onclick = null; cancel.onclick = null; bg.onclick = null; bg.onmousedown = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    ok.onclick = submit;
    cancel.onclick = () => done(null);
    bdClose(bg, () => done(null));
    document.addEventListener("keydown", onKey);
  });
}
let hideApprovedVideos = false;   // Videos tab: hide approved videos toggle

// Parse a fetch Response as JSON, but if the server returned HTML (a 401 login page, a 500 error page, etc.)
// return a clean {error} instead of throwing the cryptic "Unexpected token '<'" SyntaxError.
async function _safeJson(r) {
  const ct = r.headers.get("content-type") || "";
  if (ct.includes("application/json")) { try { return await r.json(); } catch (_) {} }
  const txt = (await r.text().catch(() => "")).slice(0, 200);
  if (r.status === 401 || /login\s*required/i.test(txt)) return { error: "Session expired — reload the app and sign in." };
  return { error: `Server error (${r.status || "no response"}).` };
}

const api = {
  projects: () => fetch("/api/projects").then(r => r.json()),
  createProject: (name, audience, brief) => fetch("/api/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, audience, brief }) }).then(r => r.json()),
  deleteProject: (p, mode = "disk") => fetch(`/api/projects/${p}?mode=${mode}`, { method: "DELETE" }).then(r => r.json()),
  listTrash: () => fetch(`/api/trash`).then(r => r.json()),
  restoreTrash: (t) => fetch(`/api/trash/${t}/restore`, { method: "POST" }).then(r => r.json()),
  deleteTrash: (t) => fetch(`/api/trash/${t}`, { method: "DELETE" }).then(r => r.json()),
  duplicate: (p) => fetch(`/api/projects/${p}/duplicate`, { method: "POST" }).then(r => r.json()),
  renameProject: (p, title) => fetch(`/api/projects/${p}/rename`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) }).then(r => r.json()),
  get: (p) => fetch(`/api/scenes/${p}`).then(r => r.json()),
  save: (p, doc) => fetch(`/api/scenes/${p}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(doc) }).then(r => r.json()),
  split: (p, script, signal) => fetch(`/api/scenes/${p}/split`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ script }), signal }).then(r => r.json()),
  redirect: (p, ids, signal) => fetch(`/api/scenes/${p}/redirect`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(ids && ids.length ? { ids } : {}), signal }).then(r => r.json()),
  resplit: (p, signal) => fetch(`/api/scenes/${p}/resplit`, { method: "POST", signal }).then(r => r.json()),
  auditStart: (p) => fetch(`/api/scenes/${p}/audit`, { method: "POST" }).then(r => r.json()),
  auditJob: (jid) => fetch(`/api/scenes/audit-job/${jid}`).then(r => r.json()),
  auditCancel: (jid) => fetch(`/api/scenes/audit-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  analyze: (p, script, signal) => fetch(`/api/scenes/${p}/analyze`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ script }), signal }).then(r => r.json()),
  translate: (texts, source) => fetch("/api/translate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ texts, source }) }).then(r => r.json()),
  genPrompt: (p, ids, signal) => fetch(`/api/scenes/${p}/genprompt`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }), signal }).then(r => r.json()),
  generate: (p, ids) => fetch(`/api/scenes/${p}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  genVideo: (p, ids) => fetch(`/api/scenes/${p}/generate-video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  genVideoPrompt: (p, ids, signal) => fetch(`/api/scenes/${p}/gen-video-prompt`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }), signal }).then(r => r.json()),
  vidPromptStart: (p, ids) => fetch(`/api/scenes/${p}/gen-video-prompt-all`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(ids && ids.length ? { ids } : {}) }).then(r => r.json()),
  vidPromptJob: (jid) => fetch(`/api/scenes/video-prompt-job/${jid}`).then(r => r.json()),
  vidPromptCancel: (jid) => fetch(`/api/scenes/video-prompt-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  imageQaStart: (p) => fetch(`/api/scenes/${p}/image-qa`, { method: "POST" }).then(r => r.json()),
  imageQaJob: (jid) => fetch(`/api/scenes/image-qa-job/${jid}`).then(r => r.json()),
  imageQaCancel: (jid) => fetch(`/api/scenes/image-qa-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  videoQaStart: (p) => fetch(`/api/scenes/${p}/video-qa`, { method: "POST" }).then(r => r.json()),
  videoQaJob: (jid) => fetch(`/api/scenes/video-qa-job/${jid}`).then(r => r.json()),
  videoQaCancel: (jid) => fetch(`/api/scenes/video-qa-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  preflight: (p) => fetch(`/api/preflight/${p}`).then(r => r.json()),
  qaSystemRequest: (p, suggestions) => fetch(`/api/qa/system-request/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ suggestions }) }).then(r => r.json()),
  genOst: (p, params) => fetch(`/api/scenes/${p}/gen-ost`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(params) }).then(r => r.json()),
  ostJob: (jid) => fetch(`/api/scenes/ost-job/${jid}`).then(r => r.json()),
  ostCancel: (jid) => fetch(`/api/scenes/ost-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  overlaysStart: (p, opts) => fetch(`/api/scenes/${p}/overlays`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(opts || {}) }).then(r => r.json()),
  overlaysJob: (jid) => fetch(`/api/scenes/overlays-job/${jid}`).then(r => r.json()),
  overlaysCancel: (jid) => fetch(`/api/scenes/overlays-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  autoTransStart: (p) => fetch(`/api/scenes/${p}/auto-transitions`, { method: "POST" }).then(r => r.json()),
  transJob: (jid) => fetch(`/api/scenes/transitions-job/${jid}`).then(r => r.json()),
  transCancel: (jid) => fetch(`/api/scenes/transitions-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  poll: (p) => {
    // Hard timeout so a poll can NEVER hang forever — a wedged poll used to leave _pollBusy stuck true,
    // which killed all polling so finished images/videos never appeared (endless "Generating…" spinner).
    const c = new AbortController(); const t = setTimeout(() => c.abort(), 45000);
    return fetch(`/api/scenes/${p}/poll`, { method: "POST", signal: c.signal }).then(r => r.json()).finally(() => clearTimeout(t));
  },
  uploadSceneRef: (p, sid, file) => { const fd = new FormData(); fd.append("file", file); return fetch(`/api/scenes/${p}/${sid}/ref`, { method: "POST", body: fd }).then(r => r.json()); },
  refScene: (p, sid, from) => fetch(`/api/scenes/${p}/${sid}/ref-scene`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ from }) }).then(r => r.json()),
  copyImage: (p, sid, from) => fetch(`/api/scenes/${p}/${sid}/copy-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ from }) }).then(r => r.json()),
  deleteSceneRef: (p, sid, index) => fetch(`/api/scenes/${p}/${sid}/ref`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(r => r.json()),
  setSceneRefLock: (p, sid, url, locked) => fetch(`/api/scenes/${p}/${sid}/ref-lock`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, locked }) }).then(r => r.json()),
  addIngredient: (p, name, files, desc) => { const fd = new FormData(); fd.append("name", name); if (desc) fd.append("desc", desc); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/ingredients/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  updateIngredient: (p, iid, { name, files, desc, scientific, split, use_directly } = {}) => { const fd = new FormData(); if (name) fd.append("name", name); if (desc !== undefined) fd.append("desc", desc); if (scientific !== undefined) fd.append("scientific", scientific ? "true" : "false"); if (split !== undefined) fd.append("split", split ? "true" : "false"); if (use_directly !== undefined) fd.append("use_directly", use_directly ? "true" : "false"); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/ingredients/${p}/${iid}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeIngredientImage: (p, iid, url) => fetch(`/api/ingredients/${p}/${iid}/remove-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  delIngredient: (p, iid) => fetch(`/api/ingredients/${p}/${iid}`, { method: "DELETE" }).then(r => r.json()),
  genIngredient: (p, iid, fresh, prompt) => fetch(`/api/ingredients/${p}/${iid}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fresh: !!fresh, prompt: prompt || "" }) }).then(r => r.json()),
  editIngCandidate: (p, iid, url, instructions) => fetch(`/api/ingredients/${p}/${iid}/edit-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, instructions }) }).then(r => r.json()),
  useIngCandidate: (p, iid, url) => fetch(`/api/ingredients/${p}/${iid}/use-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  discardIngCandidate: (p, iid, opts) => fetch(`/api/ingredients/${p}/${iid}/discard-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(opts || {}) }).then(r => r.json()),
  getKeys: (p) => fetch(`/api/keys/${p}`).then(r => r.json()),
  setKeys: (p, body) => fetch(`/api/keys/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  getGlobalKeys: () => fetch("/api/global-keys").then(r => r.json()),
  setGlobalKeys: (body) => fetch("/api/global-keys", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  projectKeys: (p) => fetch(`/api/project-keys/${p}`).then(r => r.json()),
  alignLang: (p) => fetch(`/api/align-lang/${p}`).then(r => r.json()),
  projectGroups: () => fetch("/api/project-groups").then(r => r.json()),
  saveProjectGroups: (body) => fetch("/api/project-groups", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  getConfig: () => fetch("/api/config").then(r => r.json()),
  setConfig: (body) => fetch("/api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  exportProject: (p) => fetch(`/api/projects/${p}/export`, { method: "POST" }).then(r => r.json()),
  exportStatus: (job) => fetch(`/api/export-status/${job}`).then(r => r.json()),
  listImports: () => fetch("/api/imports").then(r => r.json()),
  importProject: (file, overwrite) => fetch("/api/import", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file, overwrite: !!overwrite }) }).then(r => r.json()),
  deleteImport: (file) => fetch("/api/imports/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file }) }).then(r => r.json()),
  addCharacter: (p, name, files) => { const fd = new FormData(); fd.append("name", name); (Array.isArray(files) ? files : [files]).forEach(f => fd.append("file", f)); return fetch(`/api/characters/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  updateCharacter: (p, cid, { name, files, bucket, transforms, note } = {}) => { const fd = new FormData(); if (name) fd.append("name", name); if (bucket) fd.append("bucket", bucket); if (transforms !== undefined) fd.append("transforms", transforms ? "1" : "0"); if (note !== undefined) fd.append("transform_note", note); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/characters/${p}/${cid}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeCharacterImage: (p, cid, url, bucket) => fetch(`/api/characters/${p}/${cid}/remove-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, bucket }) }).then(r => r.json()),
  delCharacter: (p, cid) => fetch(`/api/characters/${p}/${cid}`, { method: "DELETE" }).then(r => r.json()),
  addProduct: (p, files) => { const fd = new FormData(); (Array.isArray(files) ? files : [files]).forEach(f => fd.append("file", f)); return fetch(`/api/product/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeProduct: (p, url) => fetch(`/api/product/${p}/remove`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  renameProduct: (p, url, name) => fetch(`/api/product/${p}/rename`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, name }) }).then(r => r.json()),
  setProductName: (p, name) => fetch(`/api/product/${p}/name`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) }).then(r => r.json()),
  genCharacter: (p, cid, fresh, prompt) => fetch(`/api/characters/${p}/${cid}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fresh: !!fresh, prompt: prompt || "" }) }).then(r => r.json()),
  editCharCandidate: (p, cid, url, instructions) => fetch(`/api/characters/${p}/${cid}/edit-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, instructions }) }).then(r => r.json()),
  useCharCandidate: (p, cid, url) => fetch(`/api/characters/${p}/${cid}/use-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  discardCharCandidate: (p, cid, opts) => fetch(`/api/characters/${p}/${cid}/discard-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(opts || {}) }).then(r => r.json()),
  addTPerson: (p, name, desc, files) => { const fd = new FormData(); fd.append("name", name); if (desc) fd.append("desc", desc); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/testimonial-people/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  updateTPerson: (p, pid, { name, desc, age, gender, location, files } = {}) => { const fd = new FormData(); if (name) fd.append("name", name); if (desc !== undefined) fd.append("desc", desc); if (age !== undefined) fd.append("age", age); if (gender !== undefined) fd.append("gender", gender); if (location !== undefined) fd.append("location", location); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/testimonial-people/${p}/${pid}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeTPersonImage: (p, pid, url) => fetch(`/api/testimonial-people/${p}/${pid}/remove-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  delTPerson: (p, pid) => fetch(`/api/testimonial-people/${p}/${pid}`, { method: "DELETE" }).then(r => r.json()),
  genTPerson: (p, pid, fresh) => fetch(`/api/testimonial-people/${p}/${pid}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fresh: !!fresh }) }).then(r => r.json()),
  editTPCandidate: (p, pid, url, instructions) => fetch(`/api/testimonial-people/${p}/${pid}/edit-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, instructions }) }).then(r => r.json()),
  useTPCandidate: (p, pid, url) => fetch(`/api/testimonial-people/${p}/${pid}/use-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  discardTPCandidate: (p, pid, opts) => fetch(`/api/testimonial-people/${p}/${pid}/discard-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(opts || {}) }).then(r => r.json()),
  renderTCard: (p, html, w, h) => fetch(`/api/testimonial-cards/${p}/render`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ html, w, h }) }).then(r => r.json()),
  tcardToScene: (p, cid, url) => fetch(`/api/testimonial-cards/${p}/${cid}/to-scene`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  tcardVideo: (p, cid, body) => fetch(`/api/testimonial-cards/${p}/${cid}/video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  tcardAlign: (p, cid, body) => fetch(`/api/testimonial-cards/${p}/${cid}/align`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }).then(r => r.json()),
  tcardAlignJob: (p, cid, body) => fetch(`/api/testimonial-cards/${p}/${cid}/align-job`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }).then(r => r.json()),
  tcardAlignJobStatus: (jid) => fetch(`/api/tcard-align-job/${jid}`).then(r => r.json()),
  saveTCards: (p, cards) => fetch(`/api/testimonial-cards/${p}/save`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cards }) }).then(r => r.json()),
  tvGenImage: (p, cid, charId, env, dim) => fetch(`/api/testimonial-cards/${p}/${cid}/gen-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ charId, env, dim }) }).then(r => r.json()),
  tvVoiceover: (p, cid, voice_id, text) => fetch(`/api/testimonial-cards/${p}/${cid}/voiceover`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ voice_id, text }) }).then(r => r.json()),
  tvUploadAudio: (p, cid, file) => { const fd = new FormData(); fd.append("file", file); return fetch(`/api/testimonial-cards/${p}/${cid}/upload-audio`, { method: "POST", body: fd }).then(r => r.json()); },
  tvGenVideo: (p, cid, image, vo, prompt, resolution) => fetch(`/api/testimonial-cards/${p}/${cid}/gen-video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ image, vo, prompt, resolution }) }).then(r => r.json()),
  reorder: (p, order) => fetch(`/api/scenes/${p}/reorder`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ order }) }).then(r => r.json()),
  musicOverride: (p, index, track) => fetch(`/api/music-override/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index, track }) }).then(r => r.json()),
  musicResegment: (p) => fetch(`/api/music-resegment/${p}`, { method: "POST" }).then(r => r.json()),
  musicGenerate: (p, resegment) => fetch(`/api/music-generate/${p}${resegment ? "?resegment=1" : ""}`, { method: "POST" }).then(_safeJson),
  musicJob: (job) => fetch(`/api/music-job/${job}`).then(_safeJson),
  musicReroll: (p, index) => fetch(`/api/music-reroll/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(_safeJson),
  musicCancel: (job) => job ? fetch(`/api/music-cancel/${job}`, { method: "POST" }).then(r => r.json()).catch(() => {}) : Promise.resolve(),
  restore: (p, doc) => fetch(`/api/scenes/${p}/restore`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(doc) }).then(r => r.json()),
  editImage: (p, sid, instructions) => fetch(`/api/scenes/${p}/${sid}/edit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ instructions }) }).then(r => r.json()),
  inpaint: (p, sid, mask, prompt, engine) => fetch(`/api/inpaint/${p}/${sid}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mask, prompt, engine }) }).then(r => r.json()),
  inpaintJob: (jid) => fetch(`/api/inpaint-job/${jid}`).then(r => r.json()),
  previewPrompt: (p, sid) => fetch(`/api/scenes/${p}/${sid}/preview-prompt`).then(r => r.json()),
  setCurrent: (p, sid, index) => fetch(`/api/scenes/${p}/${sid}/current`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(r => r.json()),
  syncApprovedCurrent: (p) => fetch(`/api/scenes/${p}/sync-approved-current`, { method: "POST" }).then(r => r.json()),
  credits: (p) => fetch(`/api/credits/${p}`).then(r => r.json()),
  resetImage: (p, sid) => fetch(`/api/scenes/${p}/${sid}/reset-image`, { method: "POST" }).then(r => r.json()),
  cancelImage: (p, sid) => fetch(`/api/scenes/${p}/${sid}/cancel-image`, { method: "POST" }).then(r => r.json()),
  cancelVideo: (p, sid) => fetch(`/api/scenes/${p}/${sid}/cancel-video`, { method: "POST" }).then(r => r.json()),
  deleteVersion: (p, sid, index) => fetch(`/api/scenes/${p}/${sid}/delete-version`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(r => r.json()),
  resetVideo: (p, sid) => fetch(`/api/scenes/${p}/${sid}/reset-video`, { method: "POST" }).then(r => r.json()),
  videoApprove: (p, sid, approved) => fetch(`/api/scenes/${p}/${sid}/video-approve`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ approved }) }).then(r => r.json()),
  approve: (p, sid, approved, version) => fetch(`/api/scenes/${p}/${sid}/approve`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ approved, version }) }).then(r => r.json()),
  approveBatch: (p, ids, approved) => fetch(`/api/scenes/${p}/approve-batch`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids, approved }) }).then(r => r.json()),
  insertScene: (p, after) => fetch(`/api/scenes/${p}/insert`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ after }) }).then(r => r.json()),
  deleteScene: (p, sid) => fetch(`/api/scenes/${p}/${sid}/delete-scene`, { method: "POST" }).then(r => r.json()),
  deleteScenes: (p, ids) => fetch(`/api/scenes/${p}/delete-scenes`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  duplicateScene: (p, sid) => fetch(`/api/scenes/${p}/${sid}/duplicate`, { method: "POST" }).then(r => r.json()),
  subStatus: (p) => fetch(`/api/subtitle/${p}`).then(r => r.json()),
  subCancel: (p) => fetch(`/api/subtitle/${p}/cancel`, { method: "POST" }).then(r => r.json()),
  studioUpload: (scope, file) => { const fd = new FormData(); fd.append("file", file); return fetch(`/api/studio/upload/${scope}`, { method: "POST", body: fd }).then(r => r.json()); },
  studioGenerate: (body) => fetch(`/api/studio/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  studioMockup: (body) => fetch(`/api/studio/mockup`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  studioDownloadZip: (scope, files) => fetch(`/api/studio/download-zip/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ files }) }).then(r => r.json()),
  studioVideo: (body) => fetch(`/api/studio/video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  studioEdit: (body) => fetch(`/api/studio/edit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  studioJob: (jid) => fetch(`/api/studio/job/${jid}`).then(r => r.json()),
  studioGallery: (scope) => fetch(`/api/studio/gallery/${scope}`).then(r => r.json()),
  studioDelete: (scope, id) => fetch(`/api/studio/delete/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) }).then(r => r.json()),
  studioRestore: (scope, item, at) => fetch(`/api/studio/restore/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ item, at }) }).then(r => r.json()),
  studioCancel: (jid) => fetch(`/api/studio/cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  studioFav: (scope, id, fav) => fetch(`/api/studio/fav/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, fav }) }).then(r => r.json()),
  studioSave: (scope, item) => fetch(`/api/studio/save/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ item }) }).then(r => r.json()),
  studioToScene: (project, ref, sceneId) => fetch(`/api/studio/to-scene/${project}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ref, sceneId }) }).then(r => r.json()),
  studioToNewScene: (scope, ref, project) => fetch(`/api/studio/to-new-scene`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scope, ref, project }) }).then(r => r.json()),
  faqKeywords: (scope, script, lang) => fetch(`/api/faq/keywords`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scope, script, lang }) }).then(r => r.json()),
  faqBuild: (scope, audio, docx, script, lang) => { const fd = new FormData(); fd.append("scope", scope); if (script) fd.append("script", script); if (audio) fd.append("audio", audio); if (docx) fd.append("docx", docx); if (lang) fd.append("lang", lang); return fetch(`/api/faq/build`, { method: "POST", body: fd }).then(r => r.json()); },
  faqJob: (jid) => fetch(`/api/faq/job/${jid}`).then(r => r.json()),
  assetsStatus: () => fetch(`/api/assets/status`).then(r => r.json()),
  assetsFetch: () => fetch(`/api/assets/fetch`, { method: "POST" }).then(r => r.json()),
  assetsJob: (jid) => fetch(`/api/assets/job/${jid}`).then(r => r.json()),
  faqCancel: (jid) => fetch(`/api/faq/cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  faqRender: (scope, bg, bgColor, hlColor, opts) => fetch(`/api/faq/render/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ bg: bg !== false, bg_color: bgColor || "#ffffff", hl_color: hlColor || "#e5322d" }, opts || {})) }).then(r => r.json()),
  faqGallery: (scope) => fetch(`/api/faq/gallery/${scope}`).then(r => r.json()),
  faqGalleryAdd: (scope, items) => fetch(`/api/faq/gallery-add/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items }) }).then(r => r.json()),
  faqGalleryUpdate: (scope, op, files) => fetch(`/api/faq/gallery-update/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op, files: files || [] }) }).then(r => r.json()),
  faqRenderJob: (jid) => fetch(`/api/faq/render-job/${jid}`).then(r => r.json()),
  faqRenderCancel: (jid) => fetch(`/api/faq/render-cancel/${jid}`, { method: "POST" }).then(r => r.json()),
  faqState: (scope) => fetch(`/api/faq/state/${scope}`).then(r => r.json()),
  faqStateSave: (scope, data) => fetch(`/api/faq/state/${scope}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
  subRun: (p, o) => {
    const fd = new FormData();
    fd.append("use_generated_vo", o.useGenVo ? "1" : "0");
    fd.append("use_script", o.useScript ? "1" : "0");
    fd.append("trim", o.trim ? "1" : "0");
    fd.append("trim_mode", o.trimMode || "natural");
    if (!o.useGenVo && o.audio) fd.append("audio", o.audio);
    if (o.useScript) fd.append("script_text", o.scriptText || "");
    else if (o.docx) fd.append("docx", o.docx);
    return fetch(`/api/subtitle/${p}`, { method: "POST", body: fd }).then(r => r.json());
  },
  getOstPresets: () => fetch(`/api/ost-presets`).then(r => r.json()),
  saveOstPresets: (presets) => fetch(`/api/ost-presets`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(presets) }).then(r => r.json()).catch(() => {}),
  getVoices: () => fetch(`/api/voices`).then(r => r.json()),
  addVoice: (name, voice_id) => fetch(`/api/voices`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, voice_id }) }).then(r => r.json()),
  delVoice: (name) => fetch(`/api/voices/${encodeURIComponent(name)}`, { method: "DELETE" }).then(r => r.json()),
  genVoiceover: (p, voice_id, text, trim, trim_mode) => fetch(`/api/voiceover/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ voice_id, text, trim, trim_mode }) }).then(r => r.json()),
  videoModels: () => fetch(`/api/video-models`).then(r => r.json()),
  exportPremiere: (p) => fetch(`/api/export-premiere/${p}`, { method: "POST" }).then(r => r.json()),
  previewModel: (p) => fetch(`/api/preview/${p}`).then(r => r.json()),
  words: (p) => fetch(`/api/words/${p}`).then(r => r.json()),
};

function setStatus(t) {
  // Quiet autosave ticks ("saving…/saved") stay as the small inline indicator (typing must not spam toasts).
  if (t && /^(saving|saved)/i.test(t)) { $("#statusLine").textContent = t; return; }
  // Every other action status (submitting, generating, splitting, …) comes ONLY as a top-right toast,
  // not as text below History.
  $("#statusLine").textContent = "";
  if (t) toast(t, "info", 3800, { noHist: true });   // transient action status (submitting/splitting/…) → toast only, never clutters History
}
// stable URL so the browser CACHES the image (no reload/flicker on scroll or re-render).
// `key` (the generation taskId) changes only when the file content changes, forcing a fresh
// fetch exactly when needed (regenerate / reset-and-regenerate reuse the same filename).
function mediaUrl(rel, key) { return `/media/${PROJECT}/${rel}` + (key ? `?v=${encodeURIComponent(key)}` : ""); }
// A light cached preview (WebP ~1000px) of a generated image — used ONLY for the Scenes-card thumbnail so
// the tab isn't loading dozens of 5-7MB PNGs. Everything else (lightbox / download / export / video) uses
// mediaUrl (full 2K). Sized so it looks pixel-identical at the card's on-screen size.
function thumbUrl(rel, key) { return `/media-thumb/${PROJECT}/${rel}` + (key ? `?v=${encodeURIComponent(key)}` : ""); }
function pad2(n) { return String(n).padStart(2, "0"); }
function slug(t) { return ((t || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40)) || "scene"; }
// Download ANY server URL. Desktop app (pywebview/WebView2): <a download> / window.location don't
// trigger a save, so stream it through the native Save-As bridge in desktop.py (works for generated
// .zip exports too). Normal browser: the anchor download works as before.
// Returns a Promise that stays pending while the file is being assembled/saved, so callers can
// wrap the click in withBusy() to show a spinner over the (sometimes slow) server-side generation.
function downloadUrl(url, fallbackName, label) {
  const what = label || fallbackName || "file";
  if (window.pywebview && window.pywebview.api && window.pywebview.api.save_download) {
    return window.pywebview.api.save_download(url, document.cookie, fallbackName || "download").then(r => {
      if (r && r.ok) toast("Saved " + what + " — click here to open the folder", "ok", 6000,
        { onClick: () => { try { window.pywebview.api.reveal && window.pywebview.api.reveal(r.path); } catch (e) {} } });
      else if (r && !r.cancelled) toast("Save failed: " + (r.error || ""), "err");
    }).catch(() => toast("Save failed", "err"));
  }
  const a = document.createElement("a"); a.href = url; a.download = fallbackName || ""; document.body.appendChild(a); a.click(); a.remove();
  toast("Downloaded " + what, "ok");
  return Promise.resolve();
}
function downloadMedia(rel, filename, label) { downloadUrl(`/media/${PROJECT}/${rel}?dl=${encodeURIComponent(filename)}`, filename, label); }
// open the folder that holds a render (Explorer, file selected) — desktop/local only
async function revealMedia(rel) {
  try {
    const r = await (await fetch(`/api/reveal/${PROJECT}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file: rel }) })).json();
    if (!r || !r.ok) toast("Couldn't open the folder", "err");
  } catch (e) { toast("Couldn't open the folder", "err"); }
}
function trunc(t, n) { t = t || ""; return t.length > n ? t.slice(0, n) + "…" : t; }

// Ctrl+Scroll (and Ctrl +/-/0) page zoom for the DESKTOP window only — WebView2 has no built-in
// browser zoom, so small screens can clip. In a real browser we leave native zoom alone. On each
// change a small "100%" pill flashes top-center (like a browser) and fades after ~1.2s.
(function () {
  let DESKTOP = false, z = 1, zoomTimer = null;
  try { z = parseFloat(localStorage.getItem("uiZoom")) || 1; } catch (e) {}
  const clamp = (v) => Math.min(2.5, Math.max(0.4, Math.round(v * 100) / 100));
  const apply = () => { if (DESKTOP) document.documentElement.style.zoom = z; };
  const save = () => { try { localStorage.setItem("uiZoom", String(z)); } catch (e) {} };
  const enable = () => { DESKTOP = true; apply(); };
  if (window.pywebview) enable();
  window.addEventListener("pywebviewready", enable);
  const showZoom = () => {                    // ephemeral zoom-level pill under the History button
    let el = document.getElementById("zoomInd");
    if (!el) { el = document.createElement("div"); el.id = "zoomInd"; (document.querySelector(".tb-stack") || document.querySelector(".tb-right") || document.body).appendChild(el); }
    el.textContent = Math.round(z * 100) + "%";
    el.classList.add("show");
    clearTimeout(zoomTimer);
    zoomTimer = setTimeout(() => el.classList.remove("show"), 1200);
  };
  window.addEventListener("wheel", (e) => {
    if (!DESKTOP || !e.ctrlKey) return;
    e.preventDefault();
    z = clamp(z + (e.deltaY < 0 ? 0.1 : -0.1)); apply(); save(); showZoom();
  }, { passive: false });
  window.addEventListener("keydown", (e) => {
    if (!DESKTOP || !(e.ctrlKey || e.metaKey)) return;
    if (e.key === "=" || e.key === "+") z = clamp(z + 0.1);
    else if (e.key === "-") z = clamp(z - 0.1);
    else if (e.key === "0") z = 1;
    else return;
    e.preventDefault(); apply(); save(); showZoom();
  });
})();

// remember + restore scroll position across refreshes
try { history.scrollRestoration = "manual"; } catch (e) {}
let _scrollT;
window.addEventListener("scroll", () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(() => { try { localStorage.setItem("scrollY", String(window.scrollY)); } catch (e) {} }, 150);
}, { passive: true });
// Scrollbars: (1) inner containers get a thin themed scrollbar shown only while scrolling;
// (2) the PAGE gets a custom overlay thumb that floats OVER the content (the native viewport
// scrollbar is hidden in CSS, so there's no reserved gutter / dark strip on the right).
(function () {
  let t;
  document.addEventListener("scroll", () => {
    document.documentElement.classList.add("scrolling");
    clearTimeout(t);
    t = setTimeout(() => document.documentElement.classList.remove("scrolling"), 900);
  }, { passive: true, capture: true });

  const bar = document.createElement("div");
  bar.id = "ovScroll";
  document.body.appendChild(bar);
  const INSET = 80;                        // top/bottom gap (px) — scrollbar starts/ends this far in
  let hideT;
  function place() {
    const dh = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
    const vh = window.innerHeight;
    if (dh <= vh + 4) { bar.style.height = "0"; return; }        // nothing to scroll
    const trackH = vh - INSET * 2;
    const thumbH = Math.max(40, trackH * (vh / dh));
    const maxScroll = dh - vh;
    const ratio = maxScroll > 0 ? window.scrollY / maxScroll : 0;
    bar.style.height = thumbH + "px";
    bar.style.top = (INSET + ratio * (trackH - thumbH)) + "px";
  }
  function show() { place(); bar.classList.add("on"); clearTimeout(hideT); hideT = setTimeout(() => bar.classList.remove("on"), 900); }
  window.addEventListener("scroll", show, { passive: true });
  window.addEventListener("resize", place, { passive: true });
  try { new ResizeObserver(place).observe(document.body); } catch (e) {}
})();

// Desktop app: mark <body> so the custom (frameless) title bar shows, and wire its window buttons.
(function () {
  function setMaxIcon(isMax) {
    document.body.classList.toggle("win-maximized", !!isMax);   // hide resize handles while maximized
    const m = document.getElementById("winMax"); if (!m) return;
    m.innerHTML = isMax
      ? '<svg viewBox="0 0 12 12"><rect x="2.2" y="3.7" width="6.1" height="6.1" rx="1"/><path d="M4.4 3.7 V2.2 H10.3 V8.1 H8.6"/></svg>'
      : '<svg viewBox="0 0 12 12"><rect x="2.7" y="2.7" width="6.6" height="6.6" rx="1"/></svg>';
    m.title = isMax ? "Restore" : "Maximize";
  }
  // edge/corner drag-resize for the frameless window (physical px via the win_set_bounds bridge)
  function wireResize(api) {
    if (!api || !api.win_bounds) return;
    let edge = null, sx = 0, sy = 0, sb = null, pending = null, raf = 0;
    const flush = () => { raf = 0; if (pending) { api.win_set_bounds(pending.x, pending.y, pending.w, pending.h); pending = null; } };
    document.querySelectorAll(".win-rz").forEach(hd => {
      hd.addEventListener("pointerdown", async (e) => {
        e.preventDefault();
        const b = await api.win_bounds(); if (!b) return;
        edge = hd.dataset.edge; sx = e.screenX; sy = e.screenY; sb = b;
        try { hd.setPointerCapture(e.pointerId); } catch (_) {}
      });
      hd.addEventListener("pointermove", (e) => {
        if (edge !== hd.dataset.edge || !sb) return;
        const dpr = window.devicePixelRatio || 1;
        const dx = Math.round((e.screenX - sx) * dpr), dy = Math.round((e.screenY - sy) * dpr);
        let x = sb.x, y = sb.y, w = sb.w, h = sb.h;
        if (edge.includes("e")) w = sb.w + dx;
        if (edge.includes("s")) h = sb.h + dy;
        if (edge.includes("w")) { x = sb.x + dx; w = sb.w - dx; }
        if (edge.includes("n")) { y = sb.y + dy; h = sb.h - dy; }
        const MINW = Math.round(900 * dpr), MINH = Math.round(600 * dpr);
        if (w < MINW) { if (edge.includes("w")) x -= (MINW - w); w = MINW; }
        if (h < MINH) { if (edge.includes("n")) y -= (MINH - h); h = MINH; }
        pending = { x, y, w, h };
        if (!raf) raf = requestAnimationFrame(flush);
        document.body.classList.remove("win-maximized");
      });
      const end = (e) => { edge = null; try { hd.releasePointerCapture(e.pointerId); } catch (_) {} };
      hd.addEventListener("pointerup", end);
      hd.addEventListener("pointercancel", end);
    });
  }
  function enable() {
    document.body.classList.add("desktop");
    const api = window.pywebview && window.pywebview.api;
    const min = document.getElementById("winMin"), max = document.getElementById("winMax"), close = document.getElementById("winClose");
    if (min) min.onclick = () => { if (api && api.win_minimize) api.win_minimize(); };
    if (max) max.onclick = () => { if (api && api.win_maximize) api.win_maximize().then(setMaxIcon); };
    if (close) close.onclick = () => { if (api && api.win_close) api.win_close(); };   // closes to the tray (no confirm needed)
    const bar = document.getElementById("titlebar");
    if (bar) bar.addEventListener("dblclick", (e) => {          // double-click the bar to maximize/restore
      if (e.target.closest(".tb-win-btn")) return;
      if (api && api.win_maximize) api.win_maximize().then(setMaxIcon);
    });
    wireResize(api);
    setMaxIcon(true);   // opens maximized
  }
  if (window.pywebview) enable();
  window.addEventListener("pywebviewready", enable);
})();
function restoreScroll() {
  let y = 0; try { y = parseInt(localStorage.getItem("scrollY") || "0", 10); } catch (e) {}
  if (!y) return;
  const go = () => window.scrollTo(0, y);
  requestAnimationFrame(go);
  setTimeout(go, 250);
  setTimeout(go, 700);   // re-apply after images/layout settle
}
function setBusy(btn, on) { if (!btn) return; btn.classList.toggle("busy", on); btn.disabled = on; }
// run an async action with a spinner on the clicked button
async function withBusy(btn, fn) { setBusy(btn, true); try { await fn(); } finally { setBusy(btn, false); } }
// Like withBusy, but the button turns into a red "⏹ Stop" while running; a second click aborts the
// in-flight request. fn(signal) must forward the AbortSignal into its fetch — on abort the whole op is
// abandoned client-side (nothing is applied), so DOC stays exactly as it was before the click.
// Call sites with their own pre-checks should first run: if (btn._stopCtl) { btn._stopCtl.abort(); return; }
async function stoppable(btn, fn) {
  if (!btn) return fn(undefined);
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }        // a 2nd click while running = Stop
  const ctl = new AbortController(); btn._stopCtl = ctl;
  const keepHTML = btn.innerHTML;
  btn.classList.add("stopmode"); btn.disabled = false; btn.innerHTML = "⏹ Stop";
  try {
    await fn(ctl.signal);
  } catch (err) {
    const aborted = err && (err.name === "AbortError" || /abort/i.test(String(err.message || err)));
    if (!aborted) throw err;
    setStatus("");                                            // user cancelled — quietly stop
  } finally {
    btn._stopCtl = null; btn.classList.remove("stopmode");
    btn.innerHTML = keepHTML; btn.disabled = false;
  }
}
// Themed inline field validation — red border + shake + focus, cleared on next input (no popup).
function flagInvalid(el) {
  if (!el) return;
  el.classList.remove("invalid"); void el.offsetWidth;      // restart the shake if already flagged
  el.classList.add("invalid"); el.focus();
  el.addEventListener("input", () => el.classList.remove("invalid"), { once: true });
}

// ---------- themed right-click menu for text fields (Cut / Copy / Paste / Select All / Delete) ----------
(function () {
  let menu = null, field = null, selStart = 0, selEnd = 0;
  const replaceSel = (f, text) => {
    const a = f.selectionStart, b = f.selectionEnd;
    f.value = f.value.slice(0, a) + text + f.value.slice(b);
    const p = a + text.length; f.selectionStart = f.selectionEnd = p;
    f.dispatchEvent(new Event("input", { bubbles: true }));    // so autosave / auto-grow / translate fire
  };
  const copyText = async (s) => { try { await navigator.clipboard.writeText(s); } catch (e) { try { document.execCommand("copy"); } catch (_) {} } };
  const ACTIONS = [
    { label: "Cut", key: "Ctrl+X", needSel: true, run: async (f) => { const s = f.value.slice(f.selectionStart, f.selectionEnd); if (s) { await copyText(s); replaceSel(f, ""); } } },
    { label: "Copy", key: "Ctrl+C", needSel: true, run: async (f) => { const s = f.value.slice(f.selectionStart, f.selectionEnd); if (s) await copyText(s); } },
    { label: "Paste", key: "Ctrl+V", needSel: false, run: async (f) => { try { const t = await navigator.clipboard.readText(); if (t) replaceSel(f, t); } catch (e) {} } },
    { sep: true },
    { label: "Select All", key: "Ctrl+A", needSel: false, run: (f) => f.select() },
    { label: "Delete", key: "Del", needSel: true, run: (f) => { if (f.selectionStart !== f.selectionEnd) replaceSel(f, ""); } },
  ];
  function build() {
    menu = document.createElement("div"); menu.className = "ctx-menu"; menu.hidden = true;
    ACTIONS.forEach(a => {
      if (a.sep) { const s = document.createElement("div"); s.className = "ctx-sep"; menu.appendChild(s); return; }
      const b = document.createElement("button"); b.type = "button"; b.className = "ctx-item";
      b.innerHTML = `<span>${a.label}</span><span class="ctx-key">${a.key}</span>`;
      b.dataset.needSel = a.needSel ? "1" : "";
      b.addEventListener("mousedown", e => e.preventDefault());   // keep the field's focus + selection
      b.addEventListener("click", async () => {
        if (b.classList.contains("ctx-disabled")) return;
        const f = field; hide();
        if (f) { f.focus(); try { f.selectionStart = selStart; f.selectionEnd = selEnd; } catch (e) {} await a.run(f); }
      });
      menu.appendChild(b);
    });
    document.body.appendChild(menu);
  }
  function hide() { if (menu) menu.hidden = true; field = null; }
  function isEditable(t) {
    if (!t || t.disabled || t.readOnly) return false;
    if (t.tagName === "TEXTAREA") return true;
    if (t.tagName === "INPUT") return /^(text|search|url|email|tel|password|number|)$/i.test(t.type || "");
    return false;
  }
  document.addEventListener("contextmenu", (e) => {
    if (!isEditable(e.target)) { hide(); return; }               // only our text fields get the themed menu
    e.preventDefault();
    if (!menu) build();
    field = e.target; selStart = field.selectionStart; selEnd = field.selectionEnd;
    const hasSel = selStart !== selEnd;
    menu.querySelectorAll(".ctx-item").forEach(b => b.classList.toggle("ctx-disabled", b.dataset.needSel === "1" && !hasSel));
    menu.hidden = false;
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    let x = e.clientX, y = e.clientY;
    if (x + mw > innerWidth) x = Math.max(6, innerWidth - mw - 6);
    if (y + mh > innerHeight) y = Math.max(6, innerHeight - mh - 6);
    menu.style.left = x + "px"; menu.style.top = y + "px";
  });
  document.addEventListener("mousedown", (e) => { if (menu && !menu.hidden && !menu.contains(e.target)) hide(); });
  document.addEventListener("scroll", () => { if (menu && !menu.hidden) hide(); }, true);
  window.addEventListener("blur", hide);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") hide(); });
})();

// ---------- toast notifications (non-blocking, replace the jarring native alert) ----------
const TITLE_SMALL = new Set(["a","an","the","and","but","or","nor","for","so","yet","at","by","in",
  "of","on","to","up","as","if","per","via","off","out","with","from","into","onto","over","than"]);
function titleCase(s) {
  const parts = String(s).split(" ");
  const n = parts.length;
  return parts.map((w, i) => {
    if (!w) return w;
    const m = w.match(/^([^\p{L}]*)(\p{L}[\s\S]*)?$/u);      // split leading punctuation ("(or) → ( + or)
    const lead = m[1] || "", rest = m[2] || "";
    if (!rest) return w;
    const bare = rest.toLowerCase().replace(/[^\p{L}][\s\S]*$/u, "");   // word without trailing punctuation
    if (i > 0 && i < n - 1 && TITLE_SMALL.has(bare)) return lead + rest.toLowerCase();   // keep small words lowercase
    return lead + rest.charAt(0).toUpperCase() + rest.slice(1);
  }).join(" ");
}
function toast(msg, kind = "info", ms = 3800, opts = {}) {
  let host = $("#toastHost");
  if (!host) { host = document.createElement("div"); host.id = "toastHost"; host.className = "toast-host"; document.body.appendChild(host); }
  // Sit BELOW whatever occupies the top: the frameless title bar (34px on desktop) and, on the
  // project view, the header. On the home/login screen the header is hidden, so without the title-bar
  // baseline the toast slid up under the title bar and got clipped ("half hidden").
  let topPx = document.body.classList.contains("desktop") ? 34 : 0;
  const hdr = document.querySelector("header");
  if (hdr) { const r = hdr.getBoundingClientRect(); if (r.height > 0) topPx = Math.max(topPx, r.bottom); }
  host.style.top = (topPx + 12) + "px";
  const t = document.createElement("div");
  t.className = "toast toast-" + kind;
  if (kind === "err") { try { playErrorChime(); } catch (e) {} }   // negative sound on ANY error toast (respects the notif mute)
  t.textContent = titleCase(msg);
  host.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  const close = () => { if (t._dismissCleanup) t._dismissCleanup(); t.classList.remove("show"); setTimeout(() => t.remove(), 320); };
  t.addEventListener("click", () => { if (opts.onClick) { try { opts.onClick(); } catch (e) {} } close(); });
  if (ms > 0) armToastDismiss(t, close, ms);
  if (!opts.noHist) { try { histLog(msg, kind); } catch (e) {} }   // mirror every toast into the History panel
  return t;
}
// A toast counts down toward auto-dismiss ONLY while the user is actually looking (window focused AND
// visible). If they're away doing something else on the PC, it waits; when they return it lingers a few
// seconds so they can read it, then goes. Works in the desktop WebView (Page Visibility + window focus).
function pageSeen() { return document.visibilityState !== "hidden" && document.hasFocus(); }
function armToastDismiss(el, close, ms) {
  const linger = Math.min(Math.max(ms, 2600), 4000);   // how long it stays AFTER the user comes back
  let timer = null;
  const clear = () => { if (timer) { clearTimeout(timer); timer = null; } };
  const cleanup = () => { clear(); document.removeEventListener("visibilitychange", onChange); window.removeEventListener("focus", onChange); window.removeEventListener("blur", onChange); };
  const onChange = () => {
    if (!el.isConnected) { cleanup(); return; }
    if (pageSeen()) { clear(); timer = setTimeout(close, linger); }   // came back → linger, then dismiss
    else clear();                                                     // away → hold indefinitely
  };
  el._dismissCleanup = cleanup;
  document.addEventListener("visibilitychange", onChange);
  window.addEventListener("focus", onChange);
  window.addEventListener("blur", onChange);
  if (pageSeen()) timer = setTimeout(close, ms);   // looking right now → normal countdown
  // else: stay until they return, then onChange arms the linger timer
}
// A toast-STYLED progress card (label + % + bar) that lives in the toast host and stays until close() —
// so a long background job's progress reads as a toast (top, with the others), not the old grey box.
function progressToast(label, onStop) {
  let host = $("#toastHost");
  if (!host) { host = document.createElement("div"); host.id = "toastHost"; host.className = "toast-host"; document.body.appendChild(host); }
  let topPx = document.body.classList.contains("desktop") ? 34 : 0;   // sit below the title bar + header (same as toast())
  const hdr = document.querySelector("header");
  if (hdr) { const r = hdr.getBoundingClientRect(); if (r.height > 0) topPx = Math.max(topPx, r.bottom); }
  host.style.top = (topPx + 12) + "px";
  const t = document.createElement("div");
  t.className = "toast toast-info toast-progress";
  t.innerHTML = '<div class="tp-row"><span class="tp-label"></span><span class="tp-pct">0%</span>'
    + (onStop ? '<button class="tp-stop" title="Stop"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor"/></svg></button>' : '')
    + '</div><div class="tp-bar"><div class="tp-fill"></div></div>';
  if (onStop) t.querySelector(".tp-stop").addEventListener("click", (e) => { e.stopPropagation(); try { onStop(); } catch (_) {} });
  host.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  const update = (text, pct) => {
    if (!t.isConnected) return;
    const p = Math.max(0, Math.min(100, Math.round(pct || 0)));
    t.querySelector(".tp-label").textContent = text || label || "Working…";
    t.querySelector(".tp-pct").textContent = p + "%";
    t.querySelector(".tp-fill").style.width = p + "%";
  };
  update(label, 0);
  return { update, close: () => { t.classList.remove("show"); setTimeout(() => t.remove(), 320); } };
}
// ---------- themed colour picker (replaces the OS-native <input type=color> popup, which can't be styled) ----------
function _cpHsvToRgb(h, s, v) {
  const c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c; let r, g, b;
  if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; }
  else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function _cpRgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
  if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  return [h, mx ? d / mx : 0, mx];
}
function _cpHex(r, g, b) { return "#" + [r, g, b].map(x => Math.max(0, Math.min(255, x)).toString(16).padStart(2, "0")).join(""); }
function _cpParse(h) { h = (h || "").trim().replace(/^#/, ""); if (h.length === 3) h = h.split("").map(c => c + c).join(""); if (!/^[0-9a-fA-F]{6}$/.test(h)) return null; return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
let _cpEl = null, _cpAnchor = null;
function closeColorPicker() { if (_cpEl) { _cpEl.remove(); _cpEl = null; _cpAnchor = null; document.removeEventListener("mousedown", _cpOutside, true); } }
function _cpOutside(e) { if (_cpEl && !_cpEl.contains(e.target) && e.target !== _cpAnchor) closeColorPicker(); }
function openColorPicker(anchor, hex, onChange) {
  closeColorPicker(); _cpAnchor = anchor;
  const rgb = _cpParse(hex) || [229, 50, 45]; let hsv = _cpRgbToHsv(rgb[0], rgb[1], rgb[2]);
  const el = document.createElement("div"); el.className = "cpick"; _cpEl = el;
  el.innerHTML = '<div class="cpick-body"><div class="cpick-sv"><div class="cpick-sv-w"></div><div class="cpick-sv-b"></div><div class="cpick-sv-dot"></div></div>'
    + '<div class="cpick-hue"><div class="cpick-hue-h"></div></div></div>'
    + '<div class="cpick-foot"><span class="cpick-prev"></span><input class="cpick-hex" spellcheck="false" maxlength="7"></div>'
    + '<div class="cpick-swatches"></div>';
  document.body.appendChild(el);
  const sv = el.querySelector(".cpick-sv"), dot = el.querySelector(".cpick-sv-dot"), hue = el.querySelector(".cpick-hue"),
    hueH = el.querySelector(".cpick-hue-h"), prev = el.querySelector(".cpick-prev"), hexI = el.querySelector(".cpick-hex");
  function render(fire) {
    const [h, s, v] = hsv, [r, g, b] = _cpHsvToRgb(h, s, v), hx = _cpHex(r, g, b);
    sv.style.background = `hsl(${h}, 100%, 50%)`;
    dot.style.left = (s * 100) + "%"; dot.style.top = ((1 - v) * 100) + "%"; dot.style.background = hx;
    hueH.style.top = (h / 360 * 100) + "%"; prev.style.background = hx;
    if (document.activeElement !== hexI) hexI.value = hx;
    if (fire) try { onChange(hx); } catch (_) {}
  }
  function drag(elm, fn) { elm.addEventListener("mousedown", e => { e.preventDefault(); fn(e); const mv = fn, up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); }; document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); }); }
  drag(sv, e => { const r = sv.getBoundingClientRect(); hsv[1] = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); hsv[2] = 1 - Math.min(1, Math.max(0, (e.clientY - r.top) / r.height)); render(true); });
  drag(hue, e => { const r = hue.getBoundingClientRect(); hsv[0] = Math.min(359.9, Math.max(0, (e.clientY - r.top) / r.height * 360)); render(true); });
  hexI.addEventListener("input", () => { const p = _cpParse(hexI.value); if (p) { hsv = _cpRgbToHsv(p[0], p[1], p[2]); render(true); } });
  const presets = ["#000000", "#2b2b2b", "#7f8c8d", "#ffffff", "#e5322d", "#f5a623", "#f8e71c", "#2f9e54", "#17a2b8", "#2d6cdf", "#8e44ad", "#e83e8c"];
  const sw = el.querySelector(".cpick-swatches");
  presets.forEach(p => { const b = document.createElement("button"); b.type = "button"; b.className = "cpick-sw"; b.style.background = p; b.setAttribute("data-title", p); b.addEventListener("click", () => { const pr = _cpParse(p); hsv = _cpRgbToHsv(pr[0], pr[1], pr[2]); render(true); }); sw.appendChild(b); });
  render(false);
  const r = anchor.getBoundingClientRect();
  el.style.left = Math.max(8, Math.min(window.innerWidth - el.offsetWidth - 8, r.left)) + "px";
  el.style.top = (r.bottom + 6 + el.offsetHeight > window.innerHeight ? Math.max(8, r.top - el.offsetHeight - 6) : r.bottom + 6) + "px";
  setTimeout(() => document.addEventListener("mousedown", _cpOutside, true), 0);
}
// turn a native <input type=color> into a swatch that opens OUR themed picker instead of the OS dialog
function attachThemedPicker(input) {
  if (!input || input._themed) return; input._themed = true;
  const open = (e) => { e.preventDefault(); e.stopPropagation(); openColorPicker(input, input.value, (hx) => { input.value = hx; input.dispatchEvent(new Event("input", { bubbles: true })); }); };
  input.addEventListener("mousedown", (e) => { e.preventDefault(); });   // block the OS-native colour dialog from opening
  input.addEventListener("click", open);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") open(e); });
}
window.alert = (m) => toast(String(m), "err");   // route every validation/error alert to an error toast
// Suppress ALL native hover tooltips program-wide. The browser only shows a `title` tooltip after a short
// hover delay, so stripping `title` the instant the pointer enters an element (mouseover) prevents it from
// ever appearing — for static AND dynamically-created elements, however the title was set. The value is
// parked in data-title so nothing that might read it later breaks.
document.addEventListener("mouseover", (e) => {
  let el = e.target;
  while (el && el.nodeType === 1) {
    if (el.hasAttribute && el.hasAttribute("title")) {
      const t = el.getAttribute("title");
      if (t) el.setAttribute("data-title", t);
      el.removeAttribute("title");
    }
    el = el.parentElement;
  }
}, true);
// Error surfacing that ALWAYS uses our toast (never a native popup) and detects the Kie credit/balance
// case so it reads clearly instead of dumping a raw provider string. Also lands in the History panel.
function toastErr(msg) {
  const m = String(msg || "").trim() || "Something went wrong.";
  if (/not logged in|Claude Code is not installed|not installed on this PC|not logged in on this PC|claude.{0,20}log ?in/i.test(m)) {
    if (typeof showClaudeConnect === "function") showClaudeConnect();   // Claude not connected -> open Connect dialog
    return;
  }
  if (/credit|balance|insufficient|top ?up|quota/i.test(m))
    return toast("⚠ Kie.ai balance too low — top up your credits (and check Settings → API Keys is the funded account).", "err", 14000);
  return toast("⚠ " + m, "err", 9000);
}

// ---------- tabs ----------
// one green highlight that GLIDES to the active tab instead of jumping
const tabsNav = $(".tabs");
const tabSlider = document.createElement("span");
tabSlider.className = "tab-slider";
if (tabsNav) tabsNav.appendChild(tabSlider);
let tabSliderPlaced = false;
function placeTabSlider(animate) {
  const active = $(".tab.active");
  if (!active || !tabsNav || !active.offsetWidth) return;   // skip while hidden (offsetWidth 0)
  if (!animate) tabSlider.style.transition = "none";         // no slide for the first placement
  tabSlider.style.width = active.offsetWidth + "px";
  tabSlider.style.height = active.offsetHeight + "px";
  tabSlider.style.transform = `translate(${active.offsetLeft}px, ${active.offsetTop}px)`;
  tabSlider.classList.add("on");
  if (!animate) { void tabSlider.offsetWidth; tabSlider.style.transition = ""; }   // reflow, then restore CSS transition
}
const tabScroll = {};          // remember each tab's scroll position so switching back lands where you left
let currentTab = null;
function activateTab(name) {
  if (name === "studio") { if (typeof openStudio === "function") openStudio(); return; }   // Studio is a tab that opens the Studio view
  if (typeof closeStudio === "function") closeStudio();   // leaving to a tab closes the Studio overlay
  if (currentTab && currentTab !== name) { tabScroll[currentTab] = window.scrollY; if (currentTab === "testimonials" && typeof tcStopPlay === "function") tcStopPlay(); }   // save where we were; stop any testimonial karaoke on leave
  $$(".tab").forEach(x => x.classList.toggle("active", x.dataset.tab === name));
  document.body.classList.toggle("tab-scenes", name === "scenes");   // shows the scene navigation rail
  document.body.classList.toggle("tab-videos", name === "videos");   // shows the video navigation rail
  $$(".tab-panel").forEach(x => x.classList.remove("active"));
  $(`#tab-${name}`).classList.add("active");
  try { localStorage.setItem("lastTab", name); } catch (e) {}
  placeTabSlider(tabSliderPlaced);   // first placement instant, later ones glide
  tabSliderPlaced = true;
  if (name === "videos") renderVideos();
  if (name === "testimonials") renderTestimonials();
  if (name === "export") { pvSyncFromDoc(); setTimeout(pvRepaint, 50); }   // reflect re-approved scenes + repaint the paused frame (not black)
  // refs thumbnails are sized from the container's laid-out height, which is 0 while the tab is
  // hidden — (re)fit them once Scenes is visible
  if (name === "scenes") {
    if (snapApprovedToVersion()) { patchAllSceneMedia(); api.syncApprovedCurrent(PROJECT).catch(() => {}); }   // approved scenes show their approved version (✓ stays lit)
    [0, 120].forEach(d => setTimeout(() => { document.querySelectorAll(".scene-refs-list").forEach(fitRefs); redrawAllOst(); redrawAllIcons(); autoGrowAllVo(); }, d));
  }
  // restore this tab's previous scroll position (0 the first time we open it).
  // setTimeout(0), not rAF: runs after the panel-swap reflow so the page is already tall
  // enough to scroll to y (and it fires reliably even when rAF is throttled).
  const y = tabScroll[name] || 0;
  const wasTab = currentTab;
  currentTab = name;
  if (wasTab !== name) setTimeout(() => window.scrollTo(0, y), 0);
  if (typeof sizeHistoryBar === "function") requestAnimationFrame(sizeHistoryBar);   // header visible now → size History to the trio
}
$$(".tab").forEach(t => t.addEventListener("click", () => activateTab(t.dataset.tab)));
window.addEventListener("resize", () => placeTabSlider(false));
// the first placement can be off before layout/fonts settle (e.g. refreshing on a restored
// non-first tab, where the slider lands mid-tab) — re-measure once everything has loaded
window.addEventListener("load", () => placeTabSlider(false));
if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => placeTabSlider(false));

// ---------- fake loading overlay (shown briefly when opening a project) ----------
const loadOverlay = document.createElement("div");
loadOverlay.className = "load-overlay";
loadOverlay.innerHTML = '<div class="load-anim"><span></span><span></span><span></span></div><div class="load-text"></div>';
document.body.appendChild(loadOverlay);
function showLoading(name) {
  loadOverlay.querySelector(".load-text").textContent = name ? `Opening ${name}…` : "Loading…";
  loadOverlay.classList.add("show");
}
function hideLoading() { loadOverlay.classList.remove("show"); }

// ---------- home ----------
// smooth collapse-out of a single home row (no full re-render pop); the -10px margin eats the flex
// gap so the rows below slide up cleanly.
function collapseRow(row) {
  row.style.height = row.offsetHeight + "px";
  void row.offsetHeight;
  row.classList.add("removing");
  row.style.height = "0px";
  row.style.marginBottom = "-10px";
  setTimeout(() => row.remove(), 340);
}
let _groupsFoldedOnBoot = false;   // groups start folded once per app launch (see showHome)
async function showHome() {
  if (typeof closeStudio === "function") closeStudio();   // going home closes the Studio overlay
  tabSliderPlaced = false;   // re-open a project → place the highlight instantly, no stale glide
  document.body.classList.add("on-home");
  PROJECT = null; DOC = null;
  try { localStorage.removeItem("lastProject"); } catch (e) {}
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  const [list, groupData] = await Promise.all([api.projects(), api.projectGroups().catch(() => ({ groups: [], assign: {} }))]);
  const groups = (groupData && groupData.groups) || [];
  const assign = (groupData && groupData.assign) || {};
  // Start every session with the groups folded, so the first thing you see is a short, tidy list. Persisted
  // once (not on every visit) so opening a group and coming back from a project keeps it open.
  if (!_groupsFoldedOnBoot) {
    _groupsFoldedOnBoot = true;
    if (groups.some(g => !g.collapsed)) {
      groups.forEach(g => { g.collapsed = true; });
      api.saveProjectGroups({ groups, assign }).catch(() => {});
    }
  }
  list.sort((a, b) => String(b.created || "").localeCompare(String(a.created || "")));   // newest first
  const box = $("#homeList");
  box.innerHTML = "";
  const buildRow = (p) => {
    const row = document.createElement("div");
    row.className = "proj-row";
    row.draggable = true;                       // drag onto a group header to file it there
    row.dataset.proj = p.name;
    row.addEventListener("dragstart", (e) => { e.dataTransfer.setData("text/plain", p.name); e.dataTransfer.effectAllowed = "move"; row.classList.add("pr-dragging"); });
    row.addEventListener("dragend", () => row.classList.remove("pr-dragging"));
    const b = document.createElement("button");
    b.className = "proj-item";
    b.innerHTML = `<span class="t"></span><span class="meta"></span>`;
    b.querySelector(".t").textContent = p.title;
    b.querySelector(".meta").textContent = `${p.scenes} scenes`;
    b.addEventListener("click", () => openProject(p.name, p.title));   // loader shows the display title
    const edit = document.createElement("button");
    edit.className = "proj-edit"; edit.title = "Rename Project"; edit.textContent = "✏️";
    edit.addEventListener("click", (e) => { e.stopPropagation(); openRenameModal(p); });
    const dup = document.createElement("button");
    dup.className = "proj-dup"; dup.title = "Duplicate Project"; dup.textContent = "⧉";
    dup.addEventListener("click", (e) => { e.stopPropagation(); withBusy(dup, async () => {
      const r = await api.duplicate(p.name);
      if (r.error) { alert(r.error); return; }
      toast(`Duplicated → “${r.title}”`, "ok");
      showHome();
    }); });
    const exp = document.createElement("button");
    exp.className = "proj-exp"; exp.title = "Export — write a .zip to the sync folder"; exp.innerHTML = EXPORT_SVG;
    exp.addEventListener("click", (e) => { e.stopPropagation(); withBusy(exp, async () => {
      const start = await api.exportProject(p.name);
      if (start.error) {
        if (start.error === "no-sync-dir") toast("First set a sync folder under Settings → API Keys", "err");
        else if (start.error === "sync-dir-missing") toast("Sync folder not found — check the path", "err");
        else toast("Export failed: " + start.error, "err");
        return;
      }
      await pollExport(start.job, p.title || start.title || p.name);
    }); });
    const del = document.createElement("button");
    del.className = "proj-del"; del.title = "Delete Project"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", async () => {
      const choice = await deleteProjectDialog(p.title);
      if (!choice) return;
      if (choice === "disk") {
        // second, explicit warning before an irreversible disk wipe
        if (!(await confirmDialog(`Permanently delete “${p.title}” from this computer? Its scenes, images and videos will be erased and cannot be recovered.`, { title: "Delete From Disk", okText: "Delete Forever" }))) return;
        const r = await api.deleteProject(p.name, "disk");
        if (r.error) { alert(r.error); return; }
        collapseRow(row);
        return;
      }
      // soft: move to trash (no warning), then offer an immediate Undo
      const r = await api.deleteProject(p.name, "dashboard");
      if (r.error) { alert(r.error); return; }
      collapseRow(row);
      toast(`Removed “${p.title}” — tap to undo`, "ok", 6000, { onClick: async () => {
        const rr = await api.restoreTrash(r.trash);
        if (rr.error) { toast("Restore failed: " + rr.error, "err"); return; }
        toast(`Restored “${rr.title}”`, "ok");
        showHome();
      } });
    });
    row.appendChild(b); row.appendChild(edit); row.appendChild(dup); row.appendChild(exp); row.appendChild(del);
    return row;
  };

  // ---- groups: a display layer only. Nothing moves on disk; a group just decides where a card is shown.
  const saveGroups = () => api.saveProjectGroups({ groups, assign }).catch(() => {});
  // Keep each group's header count and its "drag a project here" placeholder honest after a card moves,
  // so a drop never needs a full re-render (re-rendering the whole list is what made this flash).
  const refreshGroupChrome = () => {
    box.querySelectorAll(".proj-group").forEach(w => {
      const body = w.querySelector(".pg-body");
      const rows = body.querySelectorAll(".proj-row").length;
      const c = w.querySelector(".pg-count"); if (c) c.textContent = `${rows} project${rows === 1 ? "" : "s"}`;
      let ph = body.querySelector(".pg-empty");
      if (!rows && !ph) { ph = document.createElement("div"); ph.className = "pg-empty"; ph.textContent = "Drag a project here"; body.appendChild(ph); }
      if (rows && ph) ph.remove();
      if (!w.classList.contains("collapsed")) body.style.height = "auto";
    });
  };
  const fileInto = (projName, gid) => {            // gid null/"" = back to the ungrouped list
    if (assign[projName] === (gid || undefined)) return;
    if (gid) assign[projName] = gid; else delete assign[projName];
    saveGroups();
    const row = box.querySelector('.proj-row[data-proj="' + (window.CSS && CSS.escape ? CSS.escape(projName) : projName) + '"]');
    const dest = gid ? box.querySelector('.proj-group[data-gid="' + gid + '"] .pg-body') : looseBox;
    if (!row || !dest) { showHome(); return; }     // fall back to a redraw only if the DOM surprises us
    if (dest.contains(row)) return;
    row.style.transition = "opacity .16s ease, transform .16s ease";
    row.style.opacity = "0"; row.style.transform = "scale(.97)";
    setTimeout(() => {
      const g = groups.find(x => x.id === gid);
      if (g && g.collapsed) { g.collapsed = false; const w = dest.closest(".proj-group"); if (w) { w.classList.remove("collapsed"); dest.style.height = "auto"; } saveGroups(); }
      dest.appendChild(row);                        // move the real card — no list rebuild, no flash
      refreshGroupChrome();
      requestAnimationFrame(() => { row.style.opacity = ""; row.style.transform = ""; });
    }, 160);
  };
  const dropTarget = (el, gid) => {
    el.addEventListener("dragover", (e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; el.classList.add("pg-over"); });
    el.addEventListener("dragleave", () => el.classList.remove("pg-over"));
    el.addEventListener("drop", (e) => {
      e.preventDefault(); el.classList.remove("pg-over");
      const n = e.dataTransfer.getData("text/plain"); if (n) fileInto(n, gid);
    });
  };

  groups.forEach(g => {
    const members = list.filter(p => assign[p.name] === g.id);
    const wrap = document.createElement("div"); wrap.className = "proj-group" + (g.collapsed ? " collapsed" : "");
    wrap.dataset.gid = g.id;
    const head = document.createElement("div"); head.className = "pg-head";
    const chev = document.createElement("button"); chev.className = "pg-chev"; chev.textContent = "▾"; chev.title = "Show / hide the projects in this group";
    const nm = document.createElement("span"); nm.className = "pg-name"; nm.textContent = g.name;
    const cnt = document.createElement("span"); cnt.className = "pg-count"; cnt.textContent = `${members.length} project${members.length === 1 ? "" : "s"}`;
    const ren = document.createElement("button"); ren.className = "pg-btn"; ren.textContent = "✏️"; ren.title = "Rename Group";
    const del = document.createElement("button"); del.className = "pg-btn pg-x"; del.textContent = "×"; del.title = "Delete Group (the projects stay)";
    head.append(chev, nm, cnt, ren, del);
    const body = document.createElement("div"); body.className = "pg-body";
    members.forEach(p => body.appendChild(buildRow(p)));
    if (!members.length) { const e = document.createElement("div"); e.className = "pg-empty"; e.textContent = "Drag a project here"; body.appendChild(e); }
    // fold with a real height transition; CSS display:none would just snap it open/shut
    const toggle = () => {
      const opening = wrap.classList.contains("collapsed");
      clearTimeout(body._t);
      body.style.height = (opening ? 0 : body.scrollHeight) + "px";
      void body.offsetHeight;                        // reflow so the transition has a start value
      wrap.classList.toggle("collapsed", !opening);
      body.style.height = (opening ? body.scrollHeight : 0) + "px";
      if (opening) {                                  // hand height back to the layout the moment the
        const done = (e) => {                         // transition really ends — a fixed timer landed
          if (e && e.propertyName !== "height") return;   // early/late and showed as a final jump
          body.style.height = "auto"; body.removeEventListener("transitionend", done);
        };
        body.addEventListener("transitionend", done);
        body._t = setTimeout(done, 420);              // safety net if the event never fires
      }
      g.collapsed = !opening; saveGroups();
    };
    chev.addEventListener("click", toggle);
    nm.addEventListener("click", toggle);
    ren.addEventListener("click", async (e) => {
      e.stopPropagation();
      const v = await promptDialog("Rename this group.", { title: "Rename Group", okText: "Save", value: g.name });
      if (v && v.trim()) { g.name = v.trim(); saveGroups(); showHome(); }
    });
    del.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!(await confirmDialog(`Delete the group “${g.name}”? Its ${members.length} project(s) move back to the main list — nothing is deleted.`, { title: "Delete Group", okText: "Delete Group", danger: false }))) return;
      members.forEach(p => delete assign[p.name]);
      groups.splice(groups.indexOf(g), 1);
      saveGroups(); showHome();
    });
    dropTarget(head, g.id); dropTarget(body, g.id);
    body.style.height = g.collapsed ? "0px" : "auto";   // start state without animating on first paint
    wrap.append(head, body); box.appendChild(wrap);
  });

  const loose = list.filter(p => !assign[p.name] || !groups.some(g => g.id === assign[p.name]));
  // Ungrouped projects are just rows — a group is only a header strip above its own rows, so everything in
  // the list shares one width and nothing looks boxed in.
  const looseBox = document.createElement("div"); looseBox.className = "proj-loose";
  loose.forEach(p => looseBox.appendChild(buildRow(p)));
  dropTarget(looseBox, "");                        // drop here to take a project out of its group
  box.appendChild(looseBox);

  // three equal utility buttons, then New Project, then Studio
  const utilRow = document.createElement("div");
  utilRow.className = "proj-util-row";
  const ng = document.createElement("button");
  ng.className = "proj-import";
  ng.innerHTML = `${GROUP_SVG}<span>Create Group</span>`;
  ng.addEventListener("click", async () => {
    const v = await promptDialog("Projects you file into this group are shown together on this screen. Nothing moves on disk.", { title: "Create Group", okText: "Create", placeholder: "e.g. Cardio-360" });
    if (!v || !v.trim()) return;
    groups.push({ id: "g" + Date.now().toString(36), name: v.trim(), collapsed: false });
    await saveGroups(); showHome();
  });
  utilRow.appendChild(ng);
  const imp = document.createElement("button");
  imp.className = "proj-import";
  imp.innerHTML = `${IMPORT_SVG}<span>Import a Project</span>`;
  imp.addEventListener("click", openImportModal);
  utilRow.appendChild(imp);
  const trash = document.createElement("button");
  trash.className = "proj-import proj-trash-btn";
  trash.innerHTML = `${TRASH_SVG}<span>Removed Projects</span>`;
  trash.addEventListener("click", openTrashModal);
  utilRow.appendChild(trash);
  box.appendChild(utilRow);

  const nw = document.createElement("button");
  nw.className = "proj-new";
  nw.textContent = "New Project";
  nw.addEventListener("click", () => openModal("new"));
  box.appendChild(nw);
  const studioBtn = document.createElement("button");
  studioBtn.className = "proj-import home-studio-btn";
  studioBtn.innerHTML = `<span>🎨 Studio</span>`;
  studioBtn.title = "Generate images & product mockups — no project needed";
  studioBtn.addEventListener("click", () => { if (typeof openStudio === "function") openStudio(); });
  box.appendChild(studioBtn);
  box.classList.remove("home-enter"); void box.offsetWidth; box.classList.add("home-enter");   // glide the items in
}
async function openProject(name, loadLabel, tab) {
  if (typeof resetHistory === "function") resetHistory();   // clear the activity log when switching projects
  PROJECT = name;
  try { localStorage.setItem("lastProject", name); } catch (e) {}
  if (loadLabel) {
    showLoading(loadLabel);                // loadLabel = the display TITLE, not the folder name
    await new Promise(r => setTimeout(r, 340));   // let the loader FADE IN over the home first
  }
  document.body.classList.remove("on-home");   // then swap to the project view BEHIND the opaque loader
  activateTab(tab || "script");            // land on the requested tab (from a reload) instead of always resetting to script
  // keep the loader up a moment longer so the transition feels deliberate, then reveal
  const minWait = loadLabel ? new Promise(r => setTimeout(r, 1150)) : Promise.resolve();
  try {
    await loadDoc();
    rndReset();               // pick up a render this project already has (or one still running)
    await minWait;
  } catch (e) {
    toast("Could not open the project — please try again.", "err");   // never leave the loader stuck
  } finally {
    if (loadLabel) hideLoading();
  }
  // On load, silently restore the preview ONLY if it's byte-for-byte unchanged since the last build
  // (restore mode): instant, no re-buffer, no spinner. If anything changed — or it was never built —
  // the preview stays blank until the user clicks Build / Re-build Preview themselves.
  if (DOC && DOC.preview_built) buildPreview(null, true);
  renderSubLang();      // the subtitle language picker reflects this project (saved choice, else its audience)
}
// ---------- one-time model download (first launch) ----------
// Large model files are not shipped with the update (too big for the repo), so the first launch
// fetches them once. Shows the same progress toast every long job uses.
async function ensureAssets() {
  let st;
  try { st = await api.assetsStatus(); } catch (_) { return; }
  if (!st || st.ready || !Array.isArray(st.assets)) return;
  const need = st.assets.filter(a => !a.ready);
  if (!need.length) return;
  let r;
  try { r = await api.assetsFetch(); } catch (_) { return; }
  if (!r || !r.job) return;
  const total = need.reduce((n, a) => n + (a.size || 0), 0);
  const prog = progressToast(`Downloading ${need.length} required model file${need.length === 1 ? "" : "s"} (${(total / 1073741824).toFixed(2)} GB)…`);
  const poll = async () => {
    let j;
    try { j = await api.assetsJob(r.job); } catch (_) { setTimeout(poll, 1500); return; }
    if (j.status === "running") { prog.update(j.step || "Downloading…", j.pct || 0); setTimeout(poll, 700); return; }
    prog.close();
    if (j.status === "error") toastErr("Model download failed: " + (j.error || "unknown error"));
    else toast("Model files ready", "ok");
  };
  poll();
}
async function boot() {
  api.getConfig().then(c => { if (c && typeof c.notif_sound === "boolean") NOTIF_SOUND = c.notif_sound; }).catch(() => {});
  ensureAssets();       // first launch: fetch the large model files once, with a % progress toast
  renderVoices();       // load the saved ElevenLabs voices now that we're authenticated (was failing pre-auth)
  loadVideoModels();    // same: video model / duration / quality dropdowns need the authed fetch
  loadOstPresets();     // load saved on-screen-text style presets from the server (+ migrate localStorage)
  let last = null, t = null, title = null;
  try { last = localStorage.getItem("lastProject"); t = localStorage.getItem("lastTab"); title = localStorage.getItem("lastTitle"); } catch (e) {}
  const tab = ["script", "scenes", "videos", "testimonials", "export"].includes(t) ? t : "script";
  if (last) {
    // Paint the saved tab + project name SYNCHRONOUSLY (before the first paint / the async load) so a
    // reload lands exactly where you were — no script-tab flash, no tiny-empty-name flash.
    document.body.classList.remove("on-home");
    const pn = document.getElementById("projName"); if (pn && title) pn.textContent = title;
    document.body.classList.toggle("tab-scenes", tab === "scenes");
    document.body.classList.toggle("tab-videos", tab === "videos");
    $$(".tab").forEach(x => x.classList.toggle("active", x.dataset.tab === tab));
    $$(".tab-panel").forEach(x => x.classList.toggle("active", x.id === `tab-${tab}`));
    const list = await api.projects();
    if (list.find(p => p.name === last)) {
      await openProject(last, null, tab);   // load onto the saved tab (no reset to script)
      // re-place after layout AND any glide transition settle — a single early rAF can measure
      // the tab before the grid sizes it, leaving the slider stuck mid-bar until the next click
      [120, 400, 800].forEach(d => setTimeout(() => placeTabSlider(false), d));
      restoreScroll();
      return;
    }
  }
  showHome();
}
// Set the project-name button text and smoothly animate its width old→new, so the Home / Settings
// buttons beside it slide out/in instead of jumping when you switch projects.
function setProjName(text) {
  const btn = document.getElementById("projName");
  if (!btn) return;
  text = text || "";
  if (!btn.textContent) { btn.textContent = text; return; }   // first set: no animation
  if (btn.textContent === text) return;
  const startW = btn.getBoundingClientRect().width;
  btn.textContent = text;
  btn.style.width = "auto";
  const endW = btn.getBoundingClientRect().width;
  btn.style.width = startW + "px";
  void btn.offsetWidth;                                        // reflow at the start width
  btn.style.transition = "width .32s cubic-bezier(.33,1,.68,1)";
  btn.style.width = endW + "px";
  clearTimeout(btn._nameAnim);
  btn._nameAnim = setTimeout(() => { btn.style.transition = ""; btn.style.width = ""; }, 340);
}
// An APPROVED scene must SHOW its approved image version (so the ✓ stays lit + matches the green frame).
// Version-flipping / regenerating can leave `current` on a different version. Returns true if it fixed any.
function snapApprovedToVersion() {
  if (!DOC) return false;
  const needFix = (DOC.scenes || []).filter(s => {
    const im = s.image; if (!(s.approved && im)) return false;
    const av = im.approved_version, n = (im.versions || []).length;
    return Number.isInteger(av) && av >= 0 && av < n && im.current !== av;
  });
  if (!needFix.length) return false;
  needFix.forEach(s => { s.image.current = s.image.approved_version; s.image.file = s.image.versions[s.image.approved_version]; });
  return true;
}
// The model that actually generated a scene's SHOWN image: the approved version's model if approved,
// else the current version's model. null if the scene has no image / no recorded models.
function sceneImageModel(s) {
  const img = (s && s.image) || {}; const vm = img.version_models || []; const vs = img.versions || [];
  if (!vs.length || !vm.length) return null;
  const av = img.approved_version;
  let idx = (Number.isInteger(av) && av >= 0 && av < vm.length) ? av
          : (Number.isInteger(img.current) && img.current >= 0 && img.current < vm.length ? img.current : -1);
  return (idx >= 0 && idx < vm.length) ? vm[idx] : null;
}
async function loadDoc() {
  if (!PROJECT) return;
  DOC = await api.get(PROJECT);
  // On project open, make each model dropdown reflect the model that actually made that scene's shown image
  // (approved version's model if approved, else the current version's) — not a stray last dropdown click.
  // Frontend-only: picking a model + generating still uses your pick; the server never overwrites it.
  (DOC.scenes || []).forEach(s => { const m = sceneImageModel(s); if (m) s.model = m; });
  // On (re)open, an APPROVED scene must show its APPROVED image version — not whatever version was last
  // flipped-to before leaving. (Also re-run on Scenes-tab entry, see snapApprovedToVersion.)
  if (snapApprovedToVersion()) { try { await api.syncApprovedCurrent(PROJECT); } catch (e) {} }
  setProjName(DOC.title || PROJECT);
  tcTL = null; tcLoadTL();   // warm the VO timeline for this project so the testimonial segment players are ready the moment the tab opens
  try { localStorage.setItem("lastTitle", DOC.title || PROJECT); } catch (e) {}   // for an instant, flicker-free reload
  $("#scriptText").value = (DOC.script_draft != null ? DOC.script_draft : (DOC.script || ""));   // prefer the live draft (autosaved before Split) so a restart never loses typed script
  undoStack = []; redoStack = []; _textBase = null; updateUndoBtn();   // fresh undo/redo history per project
  _lastImgQaReport = null; QA_FLAGGED = new Set();   // fresh Image-QA state per project (button re-opens THIS project's report only)
  renderScenes(); renderVideos(); updateSplitBtn();
  ensurePolling(); renderGenProgress();
  if (subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
  $("#subAudioName").textContent = "No file selected"; $("#subAudioName").classList.remove("fd-remembered");
  $("#subDocxName").textContent = "No file selected"; $("#subDocxName").classList.remove("fd-remembered");
  $("#subAudio").value = ""; $("#subDocx").value = "";
  _subRememberedAudio = null; _subRememberedDocx = null;
  // only restore a RUNNING job on open; never surface a stale "ready/done" from a past run
  api.subStatus(PROJECT).then(st => {
    updateSrtBtn(st);                                       // reflect an existing SRT in the button label
    if (st) {                                              // restore the last-used sources + mode so the SRT form isn't blank after reopening
      if (typeof st.use_gen_vo === "boolean") $("#subUseGenVo").checked = st.use_gen_vo;
      if (typeof st.use_script === "boolean") $("#subUseScript").checked = st.use_script;
      if (st.audio_name && st.audio_name !== "Generated voice-over") { _subRememberedAudio = st.audio_name; $("#subAudioName").textContent = st.audio_name; $("#subAudioName").classList.add("fd-remembered"); }
      if (st.docx_name) { _subRememberedDocx = st.docx_name; $("#subDocxName").textContent = st.docx_name; $("#subDocxName").classList.add("fd-remembered"); }
      syncSubSources();
    }
    if (st && st.status === "running") renderSubStatus(st);
    else { subProgress(false); $("#subStatus").hidden = true; $("#subResult").hidden = true; }
  });
}

// ---------- tab 1: script ----------
$("#splitBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop (don't re-run the pre-checks)
  if (!PROJECT) { alert("Create a project first."); return; }
  const script = $("#scriptText").value.trim();
  if (!script) return;
  if (DOC.scenes.length && !(await confirmDialog("This rebuilds all scenes from the script. Continue?", { title: "Rebuild Scenes", okText: "Continue", danger: false }))) return;
  if (DOC.scenes.length) pushUndo("split into scenes");
  await stoppable(btn, async (signal) => {
    setStatus("splitting into scenes…");
    // same persistent %-progress toast as Re-Director (split runs one big director pass → animate an estimate)
    const nEst = Math.max(8, Math.round(script.split(/[.!?…]+/).filter(x => x.trim()).length));
    const prog = _redirectProgress(nEst, "Splitting into scenes…");
    let res; try { res = await api.split(PROJECT, script, signal); } finally { prog.done(); }
    if (res.error) { toastErr(res.error); setStatus(""); return; }
    const warn = res.director_warning, note = res.director_note;
    DOC = res; DOC.script = script; DOC.script_draft = script; delete DOC.director_warning; delete DOC.director_note; await api.save(PROJECT, DOC);   // draft == baseline after a split (keeps change-detection correct)
    $("#splitInfo").textContent = `${DOC.scenes.length} scenes created →`;
    renderScenes(); updateSplitBtn();
    activateTab("scenes");
    if (note) toast(note, "info");   // which model actually ran the director (Fable 5 / Opus 4.8)
    if (warn) toast(warn, "err");    // director couldn't write some prompts — surfaced (error sound fires via the toast hook)
    else { toast(`${DOC.scenes.length} scenes ready.`, "ok"); playNotifChime(); }   // success chime on a clean split
    if (autoTr()) { setStatus("translating to Turkish…"); await translateAllScenes(); }   // FR/DE only
    setStatus("");
  });
});
// Analyze Cast: read the whole script, detect the recurring people, add them to the project's Cast so
// the user can give each a reference photo BEFORE splitting → same face across every scene.
const _analyzeBtn = $("#analyzeBtn");
if (_analyzeBtn) _analyzeBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!PROJECT) { alert("Create a project first."); return; }
  const script = $("#scriptText").value.trim();
  if (!script) { alert("Paste your script first."); return; }
  await stoppable(btn, async (signal) => {
    setStatus("analyzing cast…");
    let res;
    try { res = await api.analyze(PROJECT, script, signal); }
    catch (err) { if (err && (err.name === "AbortError" || /abort/i.test(String(err)))) throw err; setStatus(""); alert("Analyze failed: " + err); return; }
    setStatus("");
    if (res.error) { toastErr(res.error); return; }
    DOC = res.doc; DOC.script = script;
    const det = res.detected || [];
    openModal("edit"); setModalTab("cast", false);           // land on the Cast tab so photos can be added
    toast(det.length
      ? `Detected ${det.length} character${det.length > 1 ? "s" : ""} — give each a reference photo (upload one, or ✨ generate one) for a consistent face, then Split.`
      : "No recurring characters found — you can Split; ordinary people stay generic.",
      det.length ? "ok" : "info");
    const autoAud = res.auto_audience || [];
    if (autoAud.length) toast("Pre-filled Brief & Audience (" + autoAud.join(", ") + ") from the script — review them in the Audience tab.", "info", 9000);
    playNotifChime();   // Analyze Cast finished → success chime
  });
});
// editing the script re-opens the Split / SRT buttons (→ "Re-Split Into Scenes" / "Re-Generate SRT")
// …and autosaves the live text to a DRAFT field so a restart before Split never loses it (keeps DOC.script,
// the last-split baseline, intact so the Re-Split / change detection still works).
$("#scriptText").addEventListener("input", () => {
  updateGenBtns();
  if (PROJECT && DOC) { DOC.script_draft = $("#scriptText").value; queueSave(); }
});

// ---------- Ctrl+F: in-script word search (custom box, not the browser's native find) ----------
(function scriptFind() {
  const ta = $("#scriptText"), box = $("#scriptFind"), inp = $("#sfInput"), cnt = $("#sfCount"), bd = $("#sfBackdrop");
  if (!ta || !box || !inp) return;
  let matches = [], cur = -1;
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const render = () => { cnt.textContent = matches.length ? `${cur + 1}/${matches.length}` : (inp.value.trim() ? "0/0" : ""); };
  function syncMetrics() {   // mirror the textarea's box exactly so the orange marks line up behind the real text
    if (!bd) return;
    const cs = getComputedStyle(ta);
    ["fontFamily", "fontSize", "fontWeight", "fontStyle", "lineHeight", "letterSpacing", "wordSpacing", "textIndent", "tabSize",
      "paddingTop", "paddingBottom", "paddingLeft", "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth"].forEach(p => { bd.style[p] = cs[p]; });
    const bl = parseFloat(cs.borderLeftWidth) || 0, br = parseFloat(cs.borderRightWidth) || 0;
    const sb = Math.max(0, ta.offsetWidth - ta.clientWidth - bl - br);   // vertical scrollbar width → keep wrap widths equal
    bd.style.paddingRight = (parseFloat(cs.paddingRight) + sb) + "px";
  }
  function paintHighlights() {
    if (!bd) return;
    if (!box.classList.contains("show") || !matches.length) { bd.innerHTML = ""; return; }
    syncMetrics();
    const q = inp.value, text = ta.value; let html = "", last = 0;
    matches.forEach((start, idx) => {
      html += esc(text.slice(last, start)) + `<mark class="${idx === cur ? "cur" : ""}">` + esc(text.slice(start, start + q.length)) + "</mark>";
      last = start + q.length;
    });
    html += esc(text.slice(last));
    bd.innerHTML = html; bd.scrollTop = ta.scrollTop; bd.scrollLeft = ta.scrollLeft;
  }
  function scrollToSel(pos) {   // center the match vertically in the textarea
    const line = ta.value.slice(0, pos).split("\n").length - 1;
    const lh = parseFloat(getComputedStyle(ta).lineHeight) || 20;
    ta.scrollTop = Math.max(0, line * lh - ta.clientHeight / 2);
    if (bd) bd.scrollTop = ta.scrollTop;
  }
  function select(k) {          // select the match WITHOUT stealing focus from the search input
    const q = inp.value, start = matches[k];
    ta.setSelectionRange(start, start + q.length); scrollToSel(start); render(); paintHighlights();
  }
  function compute() {
    const q = inp.value, tl = ta.value.toLowerCase(), ql = q.toLowerCase();
    matches = [];
    if (ql) { let i = tl.indexOf(ql); while (i !== -1) { matches.push(i); i = tl.indexOf(ql, i + ql.length); } }
    cur = matches.length ? 0 : -1; render();
    if (cur >= 0) select(cur); else paintHighlights();
  }
  function step(dir) { if (!matches.length) return; cur = (cur + dir + matches.length) % matches.length; select(cur); }
  function grow() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 150) + "px"; }   // grow downward smoothly (CSS transitions height)
  function open() { syncMetrics(); box.classList.add("show"); inp.focus(); inp.select(); grow(); compute(); }
  function close() { box.classList.remove("show"); if (bd) bd.innerHTML = ""; ta.focus(); }
  inp.addEventListener("input", () => { grow(); compute(); });
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); step(e.shiftKey ? -1 : 1); }
    else if (e.key === "Escape") { e.preventDefault(); close(); }
  });
  ta.addEventListener("scroll", () => { if (bd) { bd.scrollTop = ta.scrollTop; bd.scrollLeft = ta.scrollLeft; } });
  ta.addEventListener("input", () => { if (box.classList.contains("show")) compute(); });   // script edited → re-find + repaint marks
  window.addEventListener("resize", () => { if (box.classList.contains("show")) paintHighlights(); });
  $("#sfNext").addEventListener("click", () => step(1));
  $("#sfPrev").addEventListener("click", () => step(-1));
  $("#sfClose").addEventListener("click", close);
  document.addEventListener("keydown", (e) => {   // capture so it beats the WebView's native find
    if ((e.ctrlKey || e.metaKey) && (e.key === "f" || e.key === "F")) {
      const onScript = $("#tab-script") && $("#tab-script").classList.contains("active");
      if (onScript) { e.preventDefault(); open(); }
    }
  }, true);
  // drag the find box anywhere (grab any non-control part of it)
  let drag = null;
  box.addEventListener("pointerdown", (e) => {
    if (e.target.closest("textarea, input, button")) return;
    const r = box.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    box.classList.add("dragging"); box.style.right = "auto";
    try { box.setPointerCapture(e.pointerId); } catch (_) {}
  });
  box.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const par = box.offsetParent || box.parentElement, pr = par.getBoundingClientRect();
    let left = Math.max(0, Math.min(e.clientX - pr.left - drag.dx, pr.width - box.offsetWidth));
    let top = Math.max(0, Math.min(e.clientY - pr.top - drag.dy, pr.height - box.offsetHeight));
    box.style.left = left + "px"; box.style.top = top + "px";
  });
  const endDrag = (e) => { if (drag) { drag = null; box.classList.remove("dragging"); try { box.releasePointerCapture(e.pointerId); } catch (_) {} } };
  box.addEventListener("pointerup", endDrag);
  box.addEventListener("pointercancel", endDrag);
})();

// edit-instruction textareas grow/shrink smoothly with their content (delegated → covers every scene row)
document.addEventListener("input", (e) => {
  const t = e.target;
  if (t && t.tagName === "TEXTAREA" && (t.classList.contains("edit-instr") || t.classList.contains("video-edit-instr"))) {
    t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 220) + "px";
  }
});

// ---------- tab 1: subtitles (SRT) ----------
let subPollTimer = null;
let _subRememberedAudio = null, _subRememberedDocx = null;   // last-used source file names remembered by the server → reusable on re-run
function bindFileDrop(inputSel, nameSel) {
  const inp = $(inputSel), nm = $(nameSel);
  inp.addEventListener("change", () => { nm.textContent = inp.files[0] ? inp.files[0].name : "No file selected"; if (inp.files[0]) nm.classList.remove("fd-remembered"); });
}
bindFileDrop("#subAudio", "#subAudioName");
bindFileDrop("#subDocx", "#subDocxName");
// auto-source toggles: when checked, hide the matching upload (default: both on)
function syncSubSources() {
  const upload = !$("#subUseGenVo").checked;              // manual audio upload mode
  const hasAudio = $("#subAudio").files.length > 0 || !!_subRememberedAudio;   // a file picked now, or one remembered from last run
  $("#subAudioDrop").hidden = !upload;
  $("#subDocxDrop").hidden = $("#subUseScript").checked;
  // trim option shows only after a voice-over file is uploaded (between the two upload boxes)
  const showTrim = upload && hasAudio;
  $("#subTrimWrap").hidden = !showTrim;
  if (!showTrim) $("#subTrim").checked = false;
  $("#subTrimModeWrap").hidden = !(showTrim && $("#subTrim").checked);
}
$("#subUseGenVo").addEventListener("change", syncSubSources);
$("#subUseScript").addEventListener("change", syncSubSources);
$("#subTrim").addEventListener("change", syncSubSources);
$("#subAudio").addEventListener("change", syncSubSources);
syncSubSources();

// SRT generation shows a PERCENTAGE progress toast (top, with the other toasts) — same component as Audit & Fix.
let _subToast = null;
function subProgress(show, text, pct) {
  if (!show) { if (_subToast) { _subToast.close(); _subToast = null; } return; }
  if (!_subToast) _subToast = progressToast(text || "Generating subtitles…", () => { try { api.subCancel(PROJECT); } catch (_) {} });
  _subToast.update(text || "Generating subtitles…", pct || 0);
}
let _lastSubStatus = null;
// STEP 0 of Generate SRT can rewrite the script to match the real voice-over. Push it into the Script box as
// ONE undoable step (Ctrl+Z brings back the pre-reconcile text). The server already persisted it to disk +
// kept a backup, so here we only sync the visible box + in-memory DOC.
function applyReconciledScript(corrected) {
  const ta = $("#scriptText"); if (!ta || !DOC) return;
  corrected = (corrected || "").trim(); if (!corrected) return;
  if ((ta.value || "").trim() === corrected) return;                 // already matches → nothing to do
  commitTextUndo();                                                  // flush any pending text edit first
  undoStack.push({ label: "match script to voice-over", textSafe: true, text: textState() });   // pre-reconcile text
  if (undoStack.length > 40) undoStack.shift();
  redoStack = [];
  ta.value = corrected;
  DOC.script_draft = corrected;                                      // keep memory in sync with what the server saved
  _textBase = textState();
  updateUndoBtn(); if (typeof updateGenBtns === "function") updateGenBtns();
  toast("Script matched to the voice-over.", "ok");
}
function renderSubStatus(st) {
  const _sp = _lastSubStatus; _lastSubStatus = (st && st.status) || null;
  if (st && st.status === "done" && _sp === "running") playNotifChime();        // SRT finished → success chime
  else if (st && st.status === "error" && _sp === "running") playErrorChime();  // SRT failed → error chime
  // If STEP 0 corrected the script to the actual voice-over, drop it straight into the Script box (once, on
  // the running→done edge) so Split Into Scenes uses the corrected text. Ctrl+Z restores what was there before.
  if (st && st.status === "done" && _sp === "running" && st.reconciled_script) applyReconciledScript(st.reconciled_script);
  // …and if that correction was REFUSED for looking nothing like the script, say so. The subtitles were
  // still made, from the original text — but the voice-over and the script disagreeing is worth knowing.
  if (st && st.status === "done" && _sp === "running" && st.reconcile_note) {
    toast("Script left unchanged — " + st.reconcile_note, "warn", 11000);
  }
  const box = $("#subStatus"), res = $("#subResult");
  const running = st && st.status === "running";
  // running progress now lives in the percentage TOAST (like Audit & Fix); the inline box is only for errors
  if (running) subProgress(true, st.step || "Generating subtitles…", st.pct || 0);
  else subProgress(false);
  box.hidden = !(st && st.status === "error");
  $(".sub-spin", box).hidden = true;
  if (st && st.status === "error") { $(".sub-step", box).textContent = "⚠ " + (st.error || "failed"); }
  res.hidden = !(st && st.status === "done" && st.srt);
  $("#subDownloadMp3Btn").hidden = !(st && st.status === "done" && st.trimmed);
  // while the SRT job runs, the Generate button becomes a red "⏹ Stop" (subtitle jobs are long — the
  // user must be able to abort). setGenBtn() skips relabelling any button in stopmode, so the label sticks.
  const rb = $("#subRunBtn");
  if (rb) {
    rb.classList.toggle("stopmode", !!running);
    if (running) { rb.textContent = "⏹ Stop"; rb.disabled = false; }
  }
  if (running && !subPollTimer) startSubPolling();
  if (!running && subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
  updateSrtBtn(st);
}
// Reflect completion on the Script page: once a project has scenes / an SRT, the button switches to a
// darker-green "…Generated" label (still clickable to redo).
let _hasSrt = false;
function scriptChanged() {   // has the script been edited since the last split / SRT?
  return !!(DOC && ($("#scriptText").value || "").trim() !== (DOC.script || "").trim());
}
function setGenBtn(b, label, done) {
  if (!b) return;
  if (b.classList.contains("stopmode") || b._stopCtl) return;   // mid-generation: keep the red "⏹ Stop" label
  const apply = () => { b.textContent = label; b.classList.toggle("gen-done", done); b.disabled = done || b.classList.contains("busy"); };
  if (b.textContent && b.textContent !== label) {   // smooth: quick fade-out → swap → fade-in on state change
    b.style.transition = "opacity .16s ease"; b.style.opacity = "0";
    clearTimeout(b._genAnim);
    b._genAnim = setTimeout(() => { apply(); b.style.opacity = "1"; }, 160);
  } else { apply(); }
}
function updateGenBtns() {
  const changed = scriptChanged();
  const hasScenes = !!(DOC && DOC.scenes && DOC.scenes.length);
  // scenes can ALWAYS be re-split (the split handler confirms before rebuilding), not only after a script edit
  setGenBtn($("#splitBtn"), !hasScenes ? "Split Into Scenes →" : "Re-Split Into Scenes", false);
  // SRT can ALWAYS be re-generated (e.g. after an aligner improvement or new VO), not only after a script edit.
  setGenBtn($("#subRunBtn"), !_hasSrt ? "Generate SRT →" : "Re-Generate SRT", false);
}
function updateSplitBtn() { updateGenBtns(); }                              // kept for existing call sites
function updateSrtBtn(st) { if (st !== undefined) _hasSrt = !!(st && st.srt); updateGenBtns(); }
function startSubPolling() {
  subPollTimer = setInterval(async () => {
    if (!PROJECT) return;
    const st = await api.subStatus(PROJECT);
    renderSubStatus(st);
  }, 1500);
}
$("#subRunBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn.classList.contains("stopmode")) {                 // a job is running → Stop it
    btn.disabled = true;
    try { await api.subCancel(PROJECT); } catch (_) {}
    btn.disabled = false; btn.classList.remove("stopmode");
    if (subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
    $("#subStatus").hidden = true;
    updateGenBtns(); setStatus("");
    toast("Subtitle generation stopped.", "info");
    return;
  }
  if (!PROJECT) { alert("Create or open a project first."); return; }
  const useGenVo = $("#subUseGenVo").checked, useScript = $("#subUseScript").checked;
  const audio = $("#subAudio").files[0], docx = $("#subDocx").files[0];
  const scriptText = $("#scriptText").value.trim();
  if (!useGenVo && !audio && !_subRememberedAudio) { alert("Select the voice-over .mp3 (or tick “use the voice-over above”)."); return; }
  if (useScript && !scriptText) { alert("The script box on the left is empty."); return; }
  if (!useScript && !docx && !_subRememberedDocx) { alert("Select the script .docx (or tick “use the script from the left”)."); return; }
  const trim = useGenVo ? false : $("#subTrim").checked;
  const trimMode = $("#subTrimMode").value;
  await withBusy(e.currentTarget, async () => {
    const r = await api.subRun(PROJECT, { audio, docx, useGenVo, useScript, scriptText, trim, trimMode });
    if (r.error) { alert(r.error); return; }
    renderSubStatus({ status: "running", step: "Starting…" });
  });
});
$("#subDownloadBtn").addEventListener("click", async () => {
  const st = await api.subStatus(PROJECT);
  if (st && st.srt) downloadMedia(st.srt, st.srt_name || "subtitles.srt");
});
$("#subDownloadMp3Btn").addEventListener("click", async () => {
  const st = await api.subStatus(PROJECT);
  if (st && st.trimmed) downloadMedia(st.trimmed, st.trimmed_name || "voiceover_trimmed.mp3");
});

// ---------- tab 1: voice-over (ElevenLabs) ----------
async function renderVoices() {
  const menu = $("#voVoicesMenu");
  if (!menu) return;
  const voices = await api.getVoices();
  menu.innerHTML = "";
  if (!voices.length) {
    const empty = document.createElement("div"); empty.className = "vo-empty"; empty.textContent = "No saved voices yet";
    menu.appendChild(empty);
    return;
  }
  voices.forEach(v => {
    const row = document.createElement("div"); row.className = "vo-opt-row";
    const pick = document.createElement("button");
    pick.className = "model-opt"; pick.textContent = v.name;
    pick.title = v.voice_id || "no voice ID saved";
    pick.addEventListener("click", (e) => { e.stopPropagation(); $("#voVoiceId").value = v.voice_id || ""; menu.hidden = true; });
    const del = document.createElement("button");
    del.className = "vo-opt-x"; del.textContent = "×"; del.title = "Remove";
    del.addEventListener("click", async (e) => { e.stopPropagation(); await api.delVoice(v.name); renderVoices(); });
    row.appendChild(pick); row.appendChild(del);
    menu.appendChild(row);
  });
}
$("#voVoicesBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  const menu = $("#voVoicesMenu");
  const willOpen = menu.hidden;
  $$(".model-menu").forEach(m => m.hidden = true);
  menu.hidden = !willOpen;
});

// ---------- subtitle language ----------
// The language decides which model transcribes the voice-over for the script-reconcile step, and which
// language's grammar the caption line breaks follow. It used to come only from the audience's country in
// Settings, which is easy to miss when you land on this page and just drop in a script + voice-over.
// The first seven are the languages the caption line-break rules actually know.
const SUB_LANGS = [
  { v: "en", n: "English" }, { v: "de", n: "German" }, { v: "fr", n: "French" },
  { v: "es", n: "Spanish" }, { v: "it", n: "Italian" }, { v: "pt", n: "Portuguese" },
  { v: "nl", n: "Dutch" }, { v: "tr", n: "Turkish" }, { v: "pl", n: "Polish" },
  { v: "sv", n: "Swedish" }, { v: "da", n: "Danish" }, { v: "no", n: "Norwegian" },
  { v: "fi", n: "Finnish" }, { v: "ru", n: "Russian" },
];
const AUD_COUNTRY_LANG = { "United States": "en", "United Kingdom": "en", "Canada": "en", "Australia": "en",
  "Ireland": "en", "New Zealand": "en", "France": "fr", "Belgium": "fr", "Switzerland": "fr",
  "Germany": "de", "Austria": "de", "Spain": "es", "Mexico": "es", "Argentina": "es", "Italy": "it",
  "Portugal": "pt", "Brazil": "pt", "Netherlands": "nl", "Turkey": "tr", "Poland": "pl",
  "Sweden": "sv", "Norway": "no", "Denmark": "da", "Finland": "fi", "Russia": "ru" };
function subLangCode() {
  if (!DOC) return "en";
  const saved = (DOC.subtitle_lang || "").trim();
  if (saved) return saved;
  const loc = ((DOC.audience && DOC.audience.locations) || [])[0];   // same fallback the server uses
  return AUD_COUNTRY_LANG[loc] || "en";
}
function renderSubLang() {
  const btn = $("#subLangBtn"), menu = $("#subLangMenu");
  if (!btn || !menu) return;
  const cur = subLangCode();
  const name = (SUB_LANGS.find(l => l.v === cur) || { n: cur.toUpperCase() }).n;
  btn.innerHTML = `🌐 Language: <b></b> <span class="caret">▾</span>`;
  btn.querySelector("b").textContent = name;
  menu.innerHTML = "";
  SUB_LANGS.forEach(l => {
    const b = document.createElement("button");
    b.className = "model-opt" + (l.v === cur ? " sel" : "");   // .sel = the existing "current choice" style
    b.textContent = l.n;
    b.addEventListener("click", (e) => {
      e.stopPropagation();
      menu.hidden = true;
      if (!DOC || l.v === subLangCode()) return;
      DOC.subtitle_lang = l.v; queueSave(); renderSubLang();
      toast(`Subtitles will be generated in ${l.n}`, "ok", 2600);
    });
    menu.appendChild(b);
  });
}
$("#subLangBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  const menu = $("#subLangMenu");
  const willOpen = menu.hidden;
  $$(".model-menu").forEach(m => m.hidden = true);
  menu.hidden = !willOpen;
});
$("#voTrim").addEventListener("change", () => { $("#voTrimModeWrap").hidden = !$("#voTrim").checked; });
$("#voSaveToggle").addEventListener("click", () => {
  const f = $("#voSaveForm");
  f.hidden = !f.hidden;
  if (!f.hidden) $("#voSaveName").focus();
});
$("#voSaveConfirm").addEventListener("click", async () => {
  const name = $("#voSaveName").value.trim();
  const vid = $("#voVoiceId").value.trim();
  if (!name) { alert("Type a name for this voice."); return; }
  if (!vid) { alert("Enter a Voice ID in the box above first."); return; }
  const r = await api.addVoice(name, vid);
  if (r.error) { alert(r.error); return; }
  $("#voSaveName").value = ""; $("#voSaveForm").hidden = true;
  renderVoices();
});
$("#voGenBtn").addEventListener("click", async (e) => {
  if (!PROJECT) { alert("Create or open a project first."); return; }
  const voiceId = $("#voVoiceId").value.trim();
  const text = $("#scriptText").value.trim();
  if (!voiceId) { alert("Enter a Voice ID (or click a saved voice)."); return; }
  if (!text) { alert("The script box on the left is empty."); return; }
  const status = $("#voStatus"), step = $(".vo-step", status), spin = $(".sub-spin", status);
  status.hidden = false; spin.hidden = false; step.textContent = "Generating voice-over…";
  $("#voResult").hidden = true;
  await withBusy(e.currentTarget, async () => {
    const r = await api.genVoiceover(PROJECT, voiceId, text, $("#voTrim").checked, $("#voTrimMode").value);
    if (r.error) { step.textContent = "⚠ " + r.error; spin.hidden = true; return; }
    status.hidden = true;
    $("#voAudio").src = mediaUrl(r.file, Date.now());   // fresh per generation
    $("#voResult").hidden = false;
    $("#voDownloadBtn").onclick = () => downloadMedia(r.file, r.name || "voiceover.mp3");
  });
});
// NOTE: voices are loaded inside boot() (which runs AFTER sign-in). Calling it here at module load
// would hit /api/voices while still on the login gate → 401 → an empty dropdown that never refills.

// ---------- image model selector (per scene) ----------
const MODEL_OPTIONS = [
  { key: "nano-banana-2", label: "NanoBanana 2" },
  { key: "gpt-image-2", label: "GPT Image 2" },
  { key: "seedream-5-pro", label: "Seedream 5.0 Pro" },
];
function modelLabel(key) { return (MODEL_OPTIONS.find(m => m.key === key) || MODEL_OPTIONS[0]).label; }
function buildModelDropdown(container, s) {
  if (!container) return;
  const cur = s.model || "nano-banana-2";
  container.innerHTML = "";
  const btn = document.createElement("button");
  btn.className = "model-btn";
  btn.innerHTML = `Model: <b></b> <span class="caret">▾</span>`;
  btn.querySelector("b").textContent = modelLabel(cur);
  const menu = document.createElement("div");
  menu.className = "model-menu"; menu.hidden = true;
  MODEL_OPTIONS.forEach(m => {
    const o = document.createElement("button");
    o.className = "model-opt" + (m.key === (s.model || "nano-banana-2") ? " sel" : "");
    o.textContent = m.label;
    o.addEventListener("click", (e) => {
      e.stopPropagation();
      s.model = m.key;
      btn.querySelector("b").textContent = m.label;
      [...menu.children].forEach(c => c.classList.toggle("sel", c === o));
      menu.hidden = true;
      queueSave();
    });
    menu.appendChild(o);
  });
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = menu.hidden;
    $$(".model-menu").forEach(mm => mm.hidden = true);   // close others
    menu.hidden = !willOpen;
  });
  container.appendChild(btn); container.appendChild(menu);
}
// click anywhere else closes any open model menu
document.addEventListener("click", () => { $$(".model-menu").forEach(m => m.hidden = true); });

// video model capability matrix (durations/resolutions per model) — fetched once
let VIDEO_MODELS = [];
// Loaded inside boot() (AFTER sign-in). At module load we're still on the login gate, so
// /api/video-models would 401 → VIDEO_MODELS stays empty → the Videos tab shows no model/
// duration/quality dropdowns. (Same pre-auth pitfall as the voices list.)
function loadVideoModels() {
  return api.videoModels().then(m => { VIDEO_MODELS = m || []; if (PROJECT && DOC) renderVideos(); }).catch(() => {});
}
// generic labeled dropdown (reuses the model dropdown styling)
function vDropdown(container, prefix, curLabel, items, onPick) {
  if (!container) return;
  container.innerHTML = "";
  const btn = document.createElement("button");
  btn.className = "model-btn";
  btn.innerHTML = `${prefix}: <b></b> <span class="caret">▾</span>`;
  btn.querySelector("b").textContent = curLabel;
  const menu = document.createElement("div");
  menu.className = "model-menu"; menu.hidden = true;
  items.forEach(it => {
    const o = document.createElement("button");
    o.className = "model-opt" + (it.selected ? " sel" : "");
    o.textContent = it.label;
    o.addEventListener("click", (e) => { e.stopPropagation(); menu.hidden = true; onPick(it.value); });
    menu.appendChild(o);
  });
  btn.addEventListener("click", (e) => { e.stopPropagation(); const open = menu.hidden; $$(".model-menu").forEach(m => m.hidden = true); menu.hidden = !open; });
  container.appendChild(btn); container.appendChild(menu);
}

// camera framing/angle options (keys must match app.py CAMERA_ANGLES)
// on-screen text overlay — fonts (must exist on the render machine too) and animations.
// EVERY animation also fades in (see the CSS keyframes / the render ass tags).
const OST_FONTS = ["Arial", "Montserrat", "Poppins", "Open Sans", "Roboto", "Geomini", "Inter", "Google Sans", "Noto Serif", "Flatshoes"];
const OST_ANIMS = [
  { key: "none",         label: "None" },
  { key: "fade",         label: "Fade in" },
  { key: "popup",        label: "Pop-up" },
  { key: "slide-left",   label: "Slide from left" },
  { key: "slide-right",  label: "Slide from right" },
  { key: "slide-top",    label: "Slide from top" },
  { key: "slide-bottom", label: "Slide from bottom" },
];
const OST_OUT_ANIMS = [
  { key: "none",         label: "None" },
  { key: "fade",         label: "Fade out" },
  { key: "pop",          label: "Pop out" },
  { key: "slide-left",   label: "Slide out left" },
  { key: "slide-right",  label: "Slide out right" },
  { key: "slide-top",    label: "Slide out top" },
  { key: "slide-bottom", label: "Slide out bottom" },
];
const OST_WEIGHTS = [
  { v: "300", l: "Light" }, { v: "400", l: "Regular" }, { v: "500", l: "Medium" },
  { v: "600", l: "Semibold" }, { v: "700", l: "Bold" }, { v: "800", l: "Extrabold" }, { v: "900", l: "Black" },
];
// hex (#RRGGBB) + alpha (0..1) -> rgba() for the background box
function hexToRgba(hex, a) {
  const h = (hex || "#000000").replace("#", "");
  const n = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
  const r = parseInt(n.slice(0, 2), 16) || 0, g = parseInt(n.slice(2, 4), 16) || 0, b = parseInt(n.slice(4, 6), 16) || 0;
  return `rgba(${r},${g},${b},${a})`;
}
// map a scene's ost_* fields (or a timeline scene's text_* fields) to the shared style object
function ostOpts(s) {
  return { fill: s.ost_fill !== false, color: s.ost_color, font: s.ost_font, size: s.ost_size, weight: s.ost_weight,
    bold: s.ost_bold, italic: s.ost_italic, upper: s.ost_upper, underline: s.ost_underline,
    letter: s.ost_letter, leading: s.ost_leading, shadow: s.ost_shadow !== false,
    shadow_color: s.ost_shadow_color, shadow_opacity: s.ost_shadow_opacity, shadow_size: s.ost_shadow_size, shadow_dir: s.ost_shadow_dir,
    stroke: s.ost_stroke !== false, stroke_w: s.ost_stroke_w, stroke_color: s.ost_stroke_color,
    bg: !!s.ost_bg, bg_color: s.ost_bg_color, bg_opacity: s.ost_bg_opacity, bg_pad: s.ost_bg_pad, bg_radius: s.ost_bg_radius };
}
// Map a raw overlay (ov.onscreen + ov.ost_*) to the timeline shape the preview player consumes
// (mirror of _overlay_timeline in app.py) so the preview can refresh OST without a server rebuild.
function ovToTL(ov) {
  return {
    text: (ov.onscreen || "").trim(),
    text_fill: ov.ost_fill !== false, text_color: ov.ost_color || "#ffffff", text_font: ov.ost_font || "Arial",
    text_size: parseInt(ov.ost_size) || 56, text_weight: String(ov.ost_weight || "400"),
    text_bold: !!ov.ost_bold, text_italic: !!ov.ost_italic, text_upper: !!ov.ost_upper, text_underline: !!ov.ost_underline,
    text_letter: parseInt(ov.ost_letter) || 0, text_leading: parseFloat(ov.ost_leading) || 1.15,
    text_place: ov.ost_place || "top", text_x: parseInt(ov.ost_x) || 0, text_y: parseInt(ov.ost_y) || 0,
    text_rotation: parseInt(ov.ost_rotation) || 0,
    text_stroke: ov.ost_stroke !== false, text_stroke_w: parseInt(ov.ost_stroke_w) || 0,
    text_stroke_color: ov.ost_stroke_color || "#000000", text_stroke_pos: ov.ost_stroke_pos || "outer",
    text_bg: !!ov.ost_bg, text_bg_color: ov.ost_bg_color || "#000000", text_bg_opacity: parseInt(ov.ost_bg_opacity) || 0,
    text_bg_pad: parseInt(ov.ost_bg_pad) || 0, text_bg_radius: parseInt(ov.ost_bg_radius) || 0,
    text_shadow: ov.ost_shadow !== false, text_shadow_color: ov.ost_shadow_color || "#000000",
    text_shadow_opacity: parseInt(ov.ost_shadow_opacity) || 0, text_shadow_size: parseInt(ov.ost_shadow_size) || 0,
    text_shadow_dir: parseInt(ov.ost_shadow_dir) || 0,
    text_anim: ov.ost_anim || "fade", text_out_anim: ov.ost_out_anim || "none",
    text_in: ov.ost_in != null ? +ov.ost_in : 0, text_out: ov.ost_out != null ? +ov.ost_out : 1,
  };
}
function sceneTL(s) {   // timeline texts for a scene (mirror of _scene_overlays)
  if (!s || !s.ost_on) return [];
  return (s.overlays || []).filter(ov => (ov.onscreen || "").trim()).map(ovToTL);
}
function ostOptsTL(sc) {
  return { fill: sc.text_fill !== false, color: sc.text_color, font: sc.text_font, size: sc.text_size, weight: sc.text_weight,
    bold: sc.text_bold, italic: sc.text_italic, upper: sc.text_upper, underline: sc.text_underline,
    letter: sc.text_letter, leading: sc.text_leading, shadow: sc.text_shadow !== false,
    shadow_color: sc.text_shadow_color, shadow_opacity: sc.text_shadow_opacity, shadow_size: sc.text_shadow_size, shadow_dir: sc.text_shadow_dir,
    stroke: sc.text_stroke !== false, stroke_w: sc.text_stroke_w, stroke_color: sc.text_stroke_color,
    bg: !!sc.text_bg, bg_color: sc.text_bg_color, bg_opacity: sc.text_bg_opacity, bg_pad: sc.text_bg_pad, bg_radius: sc.text_bg_radius };
}
// on-screen-text slider popovers (Stroke/Background/Drop shadow): close on click-outside
function closeAllPops() { document.querySelectorAll(".ost-pop:not([hidden])").forEach(p => { p.hidden = true; }); }
document.addEventListener("click", (e) => { if (!e.target.closest(".ost-feat")) closeAllPops(); });

// ---- custom colour picker (singleton; replaces the native OS swatch dialog) ----
const CPICK = (() => {
  const clamp = (v) => Math.min(1, Math.max(0, v));
  function hsvToRgb(h, s, v) {
    h /= 360; const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    const m = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6];
    return { r: Math.round(m[0] * 255), g: Math.round(m[1] * 255), b: Math.round(m[2] * 255) };
  }
  function hexToRgb(hex) { const h = (hex || "").replace("#", ""); if (!/^[0-9a-f]{6}$/i.test(h)) return null; return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) }; }
  const toHex = (r, g, b) => "#" + [r, g, b].map(x => x.toString(16).padStart(2, "0")).join("");
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0; if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return { h, s: mx ? d / mx : 0, v: mx };
  }
  let el, sv, svThumb, hue, hex, prev, H = 0, S = 0, V = 0, onChange = null, anchor = null;
  function ensure() {
    if (el) return;
    el = document.getElementById("colorPicker"); if (!el) return;
    sv = el.querySelector(".cpick-sv"); svThumb = el.querySelector(".cpick-sv-thumb");
    hue = el.querySelector(".cpick-hue"); hex = el.querySelector(".cpick-hex"); prev = el.querySelector(".cpick-preview");
    const svPick = (e) => { const r = sv.getBoundingClientRect(); S = clamp((e.clientX - r.left) / r.width); V = clamp(1 - (e.clientY - r.top) / r.height); emit(true); };
    sv.addEventListener("pointerdown", (e) => { try { sv.setPointerCapture(e.pointerId); } catch (x) {} svPick(e); const mv = (ev) => svPick(ev); const up = () => { sv.removeEventListener("pointermove", mv); sv.removeEventListener("pointerup", up); }; sv.addEventListener("pointermove", mv); sv.addEventListener("pointerup", up); });
    hue.addEventListener("input", () => { H = +hue.value; emit(true); });
    hex.addEventListener("input", () => { const rgb = hexToRgb(hex.value.trim()); if (rgb) { const c = rgbToHsv(rgb.r, rgb.g, rgb.b); H = c.h; S = c.s; V = c.v; render(); if (onChange) onChange(hex.value.trim()); } });
    document.addEventListener("click", (e) => { if (el && !el.hidden && !el.contains(e.target) && e.target !== anchor && !(anchor && anchor.contains && anchor.contains(e.target))) el.hidden = true; });
  }
  function render() {
    sv.style.backgroundColor = "hsl(" + H + ",100%,50%)";
    svThumb.style.left = (S * 100) + "%"; svThumb.style.top = ((1 - V) * 100) + "%";
    const { r, g, b } = hsvToRgb(H, S, V), hx = toHex(r, g, b);
    prev.style.background = hx; if (document.activeElement !== hex) hex.value = hx; hue.value = Math.round(H);
    return hx;
  }
  function emit(cb) { const hx = render(); if (cb && onChange) onChange(hx); }
  return {
    open(anchorEl, hexColor, cb) {
      ensure(); if (!el) return;
      if (!el.hidden && anchor === anchorEl) { el.hidden = true; return; }   // click same swatch again → close
      anchor = anchorEl; onChange = cb;
      const rgb = hexToRgb(hexColor) || { r: 255, g: 255, b: 255 }, c = rgbToHsv(rgb.r, rgb.g, rgb.b);
      H = c.h; S = c.s; V = c.v; el.hidden = false; render();
      const r = anchorEl.getBoundingClientRect(), W = 216, Ht = 190;
      let left = r.left + window.scrollX, top = r.bottom + 6 + window.scrollY;
      left = Math.max(8, Math.min(left, window.scrollX + window.innerWidth - W));
      if (r.bottom + Ht > window.innerHeight) top = r.top + window.scrollY - Ht - 6;
      el.style.left = left + "px"; el.style.top = top + "px";
    }
  };
})();
function clampNum(val, min, max, def, float) {
  let v = float ? parseFloat(val) : parseInt(val);
  if (isNaN(v)) return def;
  return Math.min(max, Math.max(min, v));
}
// press + drag left/right on a number input to scrub its value (a click still focuses to type)
function makeScrubbable(inp) {
  inp.classList.add("scrubbable");
  inp.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const startX = e.clientX, startVal = parseFloat(inp.value) || 0;
    const step = parseFloat(inp.step) || 1, dec = String(inp.step).includes(".") ? 2 : 0;
    const min = inp.min !== "" ? parseFloat(inp.min) : -1e9, max = inp.max !== "" ? parseFloat(inp.max) : 1e9;
    let active = false;
    const move = (ev) => {
      const dx = ev.clientX - startX;
      if (!active) { if (Math.abs(dx) < 4) return; active = true; try { inp.setPointerCapture(e.pointerId); } catch (x) {} }
      ev.preventDefault();
      let v = Math.min(max, Math.max(min, startVal + (dx / 5) * step));
      inp.value = dec ? v.toFixed(dec) : String(Math.round(v));
      inp.dispatchEvent(new Event("input", { bubbles: true }));
    };
    const up = () => { inp.removeEventListener("pointermove", move); inp.removeEventListener("pointerup", up); };
    inp.addEventListener("pointermove", move);
    inp.addEventListener("pointerup", up);
  });
}
// shared text styling for the overlay in preview + scene card (color/font/weight/style flags/
// leading/letter-spacing/shadow/stroke/background box)
function ostTextStyle(el, o, scale) {
  el.style.color = o.color || "#ffffff";
  el.style.webkitTextFillColor = (o.fill === false) ? "transparent" : (o.color || "#ffffff");   // Fill off = stroke only
  el.style.fontFamily = `"${o.font || "Arial"}", sans-serif`;
  el.style.fontSize = ((o.size || 56) * scale).toFixed(1) + "px";
  el.style.lineHeight = String(o.leading || 1.15);
  el.style.fontWeight = String(o.bold ? 800 : (parseInt(o.weight) || 400));
  el.style.fontStyle = o.italic ? "italic" : "normal";
  el.style.textDecoration = o.underline ? "underline" : "none";
  el.style.textTransform = o.upper ? "uppercase" : "none";
  el.style.letterSpacing = ((o.letter || 0) * scale).toFixed(2) + "px";
  if (o.shadow) {                                 // drop shadow: colour / opacity / size / direction
    const sz = (o.shadow_size != null ? o.shadow_size : 6) * scale;
    const rad = (o.shadow_dir != null ? o.shadow_dir : 135) * Math.PI / 180;
    const ox = (sz * Math.cos(rad)).toFixed(1), oy = (sz * Math.sin(rad)).toFixed(1);
    const col = hexToRgba(o.shadow_color || "#000000", (o.shadow_opacity != null ? o.shadow_opacity : 80) / 100);
    el.style.textShadow = `${ox}px ${oy}px ${(sz).toFixed(1)}px ${col}`;
  } else { el.style.textShadow = "none"; }
  const sw = (o.stroke && o.stroke_w > 0) ? o.stroke_w * scale : 0;
  el.style.webkitTextStroke = sw > 0 ? `${sw.toFixed(2)}px ${o.stroke_color || "#000000"}` : "0px";
  el.style.paintOrder = "stroke fill";
  if (o.bg) {                                     // background box hugs the text (padding = "Size")
    el.style.background = hexToRgba(o.bg_color || "#000000", (o.bg_opacity != null ? o.bg_opacity : 60) / 100);
    el.style.padding = ((o.bg_pad || 0) * scale).toFixed(1) + "px";
    el.style.borderRadius = ((o.bg_radius || 0) * scale).toFixed(1) + "px";
  } else {
    el.style.background = "none"; el.style.padding = "0"; el.style.borderRadius = "0";
  }
}
// position the placement wrapper (centre horizontally + placement anchor + X/Y offset + rotation)
function ostWrapPos(wrap, place, x, y, scale, rotation) {
  const tx = (x || 0) * scale, ty = (y || 0) * scale;
  const rot = rotation ? ` rotate(${rotation}deg)` : "";
  wrap.style.transform = (place === "center")
    ? `translate(calc(-50% + ${tx.toFixed(1)}px), calc(-50% + ${ty.toFixed(1)}px))${rot}`
    : `translate(calc(-50% + ${tx.toFixed(1)}px), ${ty.toFixed(1)}px)${rot}`;
}
// Make an on-screen-text overlay directly draggable / resizable / rotatable on the image.
// It mutates ov.* live and mirrors the values into the panel inputs via sync(); commit() saves.
// scale = preview px per 1920 unit, so screen deltas convert straight to ost_x/ost_y units.
const OST_INP = { ost_x: ".ost-x", ost_y: ".ost-y", ost_rotation: ".ost-rot", ost_size: ".ost-size" };
// snap the dragged overlay's edges/centre to the image centre and to other overlays (Figma-style guides).
// returns pixel nudges (dx/dy) to apply and the guide-line positions (gx/gy, screen px) or null.
function ostSnap(ostEl, container, th) {
  const R = ostEl.getBoundingClientRect(), IR = container.getBoundingClientRect();
  const others = [...container.querySelectorAll(".scene-ost")].filter(e => e !== ostEl).map(e => e.getBoundingClientRect());
  const pick = (pts, targets) => {
    let best = null;
    pts.forEach(p => targets.forEach(t => { const d = t - p; if (Math.abs(d) < th && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, g: t }; }));
    return best;
  };
  const txX = [IR.left + IR.width / 2]; others.forEach(o => txX.push(o.left + o.width / 2, o.left, o.right));
  const txY = [IR.top + IR.height / 2]; others.forEach(o => txY.push(o.top + o.height / 2, o.top, o.bottom));
  const bx = pick([R.left + R.width / 2, R.left, R.right], txX);
  const by = pick([R.top + R.height / 2, R.top, R.bottom], txY);
  return { dx: bx ? bx.d : 0, dy: by ? by.d : 0, gx: bx ? bx.g : null, gy: by ? by.g : null };
}
function ostGuides(container, gx, gy) {
  const IR = container.getBoundingClientRect();
  const put = (cls, on, pos, prop) => {
    let g = container.querySelector("." + cls);
    if (on == null) { if (g) g.remove(); return; }
    if (!g) { g = document.createElement("div"); g.className = "ost-guide " + cls; container.appendChild(g); }
    g.style[prop] = (pos - (prop === "left" ? IR.left : IR.top)) + "px";
  };
  put("ost-guide-v", gx, gx, "left"); put("ost-guide-h", gy, gy, "top");
}
function ostClearGuides(container) { container.querySelectorAll(".ost-guide").forEach(n => n.remove()); }
const _LOCK_CLOSED = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const _LOCK_OPEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.6-1.9"/></svg>';
function ostInteractive(ostEl, ov, scale, container, cb) {
  ostEl.classList.add("ost-editable");
  const rotH = document.createElement("div"); rotH.className = "ost-h ost-h-rot"; rotH.title = "Rotate";
  const sizeH = document.createElement("div"); sizeH.className = "ost-h ost-h-size"; sizeH.title = "Resize";
  const delB = document.createElement("button"); delB.className = "ost-del-btn"; delB.textContent = "×"; delB.title = "Delete this text";
  const lockB = document.createElement("button"); lockB.className = "ost-lock-btn"; lockB.title = "Lock / unlock position on the preview";
  ostEl.append(rotH, sizeH, delB, lockB);
  const span = ostEl.querySelector("span");
  const paintLock = () => { const on = !!ov.ost_locked; ostEl.classList.toggle("ost-locked", on); lockB.classList.toggle("on", on); lockB.innerHTML = on ? _LOCK_CLOSED : _LOCK_OPEN; };
  paintLock();
  lockB.addEventListener("pointerdown", e => e.stopPropagation());
  lockB.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); ov.ost_locked = !ov.ost_locked; paintLock(); if (cb.commit) cb.commit(); });
  delB.addEventListener("pointerdown", e => e.stopPropagation());
  delB.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); if (cb.onDelete) cb.onDelete(); });
  const start = (e, mode) => {
    if (ov.ost_locked) return;                           // LOCKED → no move/resize/rotate on the preview (unlock first)
    e.preventDefault(); e.stopPropagation();
    container.querySelectorAll(".scene-ost.ost-selected").forEach(n => n.classList.remove("ost-selected"));
    ostEl.classList.add("ost-selected");                 // highlight the one you grabbed
    const r = ostEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const s0 = { x: e.clientX, y: e.clientY, ox: +ov.ost_x || 0, oy: +ov.ost_y || 0, rot: +ov.ost_rotation || 0,
      size: +ov.ost_size || 56, ang: Math.atan2(e.clientY - cy, e.clientX - cx), dist: Math.hypot(e.clientX - cx, e.clientY - cy) || 1 };
    ostEl.classList.add("ost-dragging");
    const move = (ev) => {
      if (mode === "move") {
        ov.ost_x = Math.round(s0.ox + (ev.clientX - s0.x) / scale);
        ov.ost_y = Math.round(s0.oy + (ev.clientY - s0.y) / scale);
        ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
        const snap = ostSnap(ostEl, container, 6);        // pull to centre / other overlays
        if (snap.dx || snap.dy) {
          ov.ost_x = Math.round(ov.ost_x + snap.dx / scale);
          ov.ost_y = Math.round(ov.ost_y + snap.dy / scale);
          ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
        }
        ostGuides(container, snap.gx, snap.gy);
        cb.sync("ost_x", ov.ost_x); cb.sync("ost_y", ov.ost_y);
      } else if (mode === "rot") {
        let d = s0.rot + (Math.atan2(ev.clientY - cy, ev.clientX - cx) - s0.ang) * 180 / Math.PI;
        d = Math.max(-180, Math.min(180, Math.round(d)));
        if (Math.abs(d) < 4) d = 0;                       // snap to upright
        ov.ost_rotation = d;
        ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, d);
        cb.sync("ost_rotation", d);
      } else {   // resize -> font size, scaled by how far the corner is dragged from the centre
        let sz = Math.max(12, Math.min(1000, Math.round(s0.size * Math.hypot(ev.clientX - cx, ev.clientY - cy) / s0.dist)));
        ov.ost_size = sz;
        if (span) ostTextStyle(span, ostOpts(ov), scale);
        cb.sync("ost_size", sz);
      }
    };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      ostEl.classList.remove("ost-dragging"); ostClearGuides(container); cb.commit();
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  ostEl.addEventListener("pointerdown", e => start(e, "move"));
  rotH.addEventListener("pointerdown", e => start(e, "rot"));
  sizeH.addEventListener("pointerdown", e => start(e, "size"));
}
// live on-screen-text overlay drawn on a scene card's image preview, so you SEE the styling/placement
function drawSceneOst(el, s, _isRetry) {
  const prev = el.querySelector(".img-preview"); if (!prev) return;
  // Every FRESH call restarts the retry budget. Without this the counter below was permanent: a card whose
  // preview happened to be 0-wide for 30 frames once (tab not visible yet / card still being built) could
  // never draw again — the first on-screen text you typed simply never appeared, and toggling the checkbox
  // did not help, because each later call hit the exhausted counter and gave up immediately.
  if (!_isRetry) el._ostRetry = 0;
  prev.querySelectorAll(".scene-ost").forEach(n => n.remove());      // redraw all overlays
  if (!s.ost_on) return;                                             // section off = no overlay
  // scale = preview px per 1920 unit. NEVER use a guessed fallback width — a wrong scale makes the text
  // jump size between renders. If the preview isn't laid out yet (0 width), retry next frame when visible,
  // else bail (redrawAllOst() on tab-activation / resize will draw it once it has a real width).
  const w = prev.clientWidth || Math.round(prev.getBoundingClientRect().width);
  if (!w) {   // preview not laid out yet (just added / section mid-open) → keep retrying for a few frames, not once
    const n = (el._ostRetry = (el._ostRetry || 0) + 1);
    if (prev.isConnected && n < 30) requestAnimationFrame(() => drawSceneOst(el, s, true));
    return;
  }
  el._ostRetry = 0;
  const scale = w / 1920;
  (s.overlays || []).forEach((ov, i) => {
    const txt = (ov.onscreen || "").trim(); if (!txt) return;
    const ost = document.createElement("div"); ost.innerHTML = '<span class="scene-ost-txt"></span>';
    ost.className = "scene-ost place-" + (ov.ost_place || "top");
    prev.appendChild(ost);
    ostWrapPos(ost, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
    const span = ost.querySelector(".scene-ost-txt");
    span.textContent = txt;
    ostTextStyle(span, ostOpts(ov), scale);
    const panel = el.querySelectorAll(".ost-panel")[i];   // mirror drags into this overlay's inputs
    const delBtn = panel && panel.querySelector(".ost-del-overlay");
    ostInteractive(ost, ov, scale, prev, {
      sync: (f, v) => { const inp = panel && panel.querySelector(OST_INP[f]); if (inp) inp.value = v; },
      commit: () => queueSave(),
      onDelete: () => { if (delBtn) delBtn.click(); },   // reuse the panel's remove (animation + rebuild)
    });
    // EDIT the words right on the image: DOUBLE-CLICK to type; it syncs live into this overlay's text box on
    // the left (and vice-versa). Single-click/drag still moves it (edit only after a dblclick, until blur).
    const panelTa = panel && panel.querySelector(".onscreen");
    ost.title = "Double-click to edit the text; drag to move";
    span.addEventListener("dblclick", (e) => {
      e.stopPropagation(); span.contentEditable = "true"; span.classList.add("ost-editing"); span.focus();
      const r = document.createRange(); r.selectNodeContents(span); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
    });
    span.addEventListener("pointerdown", (e) => { if (span.isContentEditable) e.stopPropagation(); });   // don't start a drag while typing
    span.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); span.blur(); } });
    span.addEventListener("input", () => { ov.onscreen = span.textContent; if (panelTa && panelTa.value !== ov.onscreen) panelTa.value = ov.onscreen; });
    span.addEventListener("blur", () => {
      span.contentEditable = "false"; span.classList.remove("ost-editing");
      ov.onscreen = span.textContent; if (panelTa) panelTa.value = ov.onscreen; queueSave();
    });
  });
}
function redrawAllOst() {
  document.querySelectorAll(".scene-row").forEach(el => {
    const s = (DOC.scenes || []).find(x => x.id === +el.dataset.id);
    if (s) drawSceneOst(el, s);
  });
}
function redrawAllIcons() {   // mirror redrawAllOst: (re)draw overlay icons once the cards have a real width
  document.querySelectorAll(".scene-row").forEach(el => {
    const s = (DOC.scenes || []).find(x => x.id === +el.dataset.id);
    if (s) renderSceneIcons(el, s);
  });
}
function newOverlay() {   // default look = the saved "Montserrat White" style (matches OST_OVERLAY_DEFAULTS in app.py)
  return { onscreen: "", ost_fill: true, ost_color: "#ffffff", ost_font: "Montserrat", ost_size: 115, ost_weight: "800",
    ost_bold: false, ost_italic: false, ost_upper: true, ost_underline: false, ost_letter: 0, ost_leading: 0.85,
    ost_place: "center", ost_x: 0, ost_y: 0, ost_rotation: 0,
    ost_stroke: false, ost_stroke_w: 4, ost_stroke_color: "#000000", ost_stroke_pos: "outer",
    ost_bg: false, ost_bg_color: "#000000", ost_bg_opacity: 60, ost_bg_pad: 12, ost_bg_radius: 8,
    ost_shadow: false, ost_shadow_color: "#000000", ost_shadow_opacity: 80, ost_shadow_size: 6, ost_shadow_dir: 135,
    ost_anim: "slide-bottom", ost_out_anim: "fade" };
}
// on-screen-text STYLE preset keys (look only — not the text, fine offset, rotation or timing)
const OST_STYLE_KEYS = ["ost_fill", "ost_color", "ost_font", "ost_size", "ost_weight", "ost_bold", "ost_italic",
  "ost_upper", "ost_underline", "ost_letter", "ost_leading", "ost_place",
  "ost_stroke", "ost_stroke_w", "ost_stroke_color", "ost_stroke_pos",
  "ost_bg", "ost_bg_color", "ost_bg_opacity", "ost_bg_pad", "ost_bg_radius",
  "ost_shadow", "ost_shadow_color", "ost_shadow_opacity", "ost_shadow_size", "ost_shadow_dir",
  "ost_anim", "ost_out_anim"];
// OST style presets — now SERVER-SIDE (data/ost_presets.json) so they persist across app restarts
// and travel with the data folder to another PC. Backed by an in-memory cache so the callers stay
// synchronous; localStorage is kept only as an offline mirror + migration source.
let OST_PRESETS = null;
function ostPresets(set) {
  if (set !== undefined) {
    OST_PRESETS = set;
    try { localStorage.setItem("ostStylePresets", JSON.stringify(set)); } catch (e) {}
    api.saveOstPresets(set);   // persist server-side (fire-and-forget)
    return set;
  }
  if (OST_PRESETS) return OST_PRESETS;
  try { return JSON.parse(localStorage.getItem("ostStylePresets") || "[]"); } catch (e) { return []; }
}
async function loadOstPresets() {
  try {
    const server = await api.getOstPresets();
    let local = [];
    try { local = JSON.parse(localStorage.getItem("ostStylePresets") || "[]"); } catch (e) {}
    if ((!Array.isArray(server) || !server.length) && local.length) {
      OST_PRESETS = local; api.saveOstPresets(local);   // one-time migration of browser-saved presets
    } else {
      OST_PRESETS = Array.isArray(server) ? server : [];
      try { localStorage.setItem("ostStylePresets", JSON.stringify(OST_PRESETS)); } catch (e) {}
    }
  } catch (e) { /* server unreachable → stay on the localStorage value */ }
}
// wire one overlay panel's controls to an overlay object; redraw() re-renders the scene-card overlays,
// rebuild() re-builds all overlay panels from the overlays (used after applying a style preset)
function wireOstPanel(panel, ov, redraw, rebuild, presetKind) {
  const q = (sel) => panel.querySelector(sel);
  const qa = (sel) => panel.querySelectorAll(sel);
  const changed = () => redraw();
  const kind = presetKind || "ost";   // "ost" = on-screen text presets, "subtitle" = subtitle presets (kept separate)
  const ofKind = (list) => list.filter(p => (p.kind || "ost") === kind);
  // --- style presets (save this look, apply it to another) — scoped to this panel's kind ---
  const psSave = q(".ost-preset-save"), psApply = q(".ost-preset-apply"), psMenu = q(".ost-preset-menu");
  if (psSave) psSave.addEventListener("click", async (e) => {
    e.stopPropagation();
    const name = await promptDialog("Give this style a name so you can re-apply it later.", { title: kind === "subtitle" ? "Save Subtitle Style" : "Save Style Preset", okText: "Save", placeholder: "e.g. Big yellow headline" });
    if (!name) return;
    const presets = ostPresets(), style = {};
    OST_STYLE_KEYS.forEach(k => style[k] = ov[k]);
    const ex = presets.findIndex(p => p.name === name && (p.kind || "ost") === kind);
    if (ex >= 0) { presets[ex].style = style; presets[ex].kind = kind; } else presets.push({ name, style, kind });
    ostPresets(presets);
    toast(`Style preset saved: ${name}`, "ok");
  });
  if (psApply) psApply.addEventListener("click", (e) => {
    e.stopPropagation();
    const wasOpen = !psMenu.hidden;
    $$(".model-menu").forEach(m => m.hidden = true);
    if (wasOpen) return;
    const presets = ofKind(ostPresets());   // only this kind's presets show here
    psMenu.innerHTML = "";
    if (!presets.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No presets yet — save one first"; psMenu.appendChild(d); }
    presets.forEach(p => {
      const row = document.createElement("div"); row.className = "ost-preset-opt";
      const nm = document.createElement("span"); nm.className = "ost-preset-name"; nm.textContent = p.name;
      nm.addEventListener("click", () => {
        OST_STYLE_KEYS.forEach(k => { if (p.style[k] !== undefined) ov[k] = p.style[k]; });
        psMenu.hidden = true; if (rebuild) rebuild(); redraw(); queueSave();
        toast(`Applied style: ${p.name}`, "ok");
      });
      const del = document.createElement("button"); del.className = "ost-preset-del ghost"; del.textContent = "×"; del.title = "Delete this preset";
      del.addEventListener("click", (ev) => { ev.stopPropagation(); ostPresets(ostPresets().filter(x => !(x.name === p.name && (x.kind || "ost") === kind))); row.remove(); if (!psMenu.querySelector(".ost-preset-opt")) psMenu.hidden = true; });
      row.append(nm, del); psMenu.appendChild(row);
    });
    psMenu.hidden = false;
  });
  const ta = q(".onscreen"); if (ta) { ta.value = ov.onscreen || ""; ta.addEventListener("input", e => { ov.onscreen = e.target.value; changed(); }); }   // absent on the global subtitle panel (no text box)
  // --- selects ---
  const ostFont = q(".ost-font"), ostWeight = q(".ost-weight"), ostAnim = q(".ost-anim"), ostOut = q(".ost-out-anim");
  OST_FONTS.forEach(f => ostFont.appendChild(new Option(f, f, false, f === (ov.ost_font || "Arial"))));
  OST_WEIGHTS.forEach(w => ostWeight.appendChild(new Option(w.l, w.v, false, w.v === String(ov.ost_weight || "400"))));
  OST_ANIMS.forEach(a => ostAnim.appendChild(new Option(a.label, a.key, false, a.key === (ov.ost_anim || "fade"))));
  OST_OUT_ANIMS.forEach(a => ostOut.appendChild(new Option(a.label, a.key, false, a.key === (ov.ost_out_anim || "none"))));
  ostFont.addEventListener("change", e => { ov.ost_font = e.target.value; changed(); });
  ostWeight.addEventListener("change", e => { ov.ost_weight = e.target.value; changed(); });
  ostAnim.addEventListener("change", e => { ov.ost_anim = e.target.value; changed(); });
  ostOut.addEventListener("change", e => { ov.ost_out_anim = e.target.value; changed(); });
  // --- numeric inputs ---
  const numWire = (sel, key, min, max, def, float) => {
    const inp = q(sel); if (!inp) return;
    inp.value = (ov[key] != null ? ov[key] : def);
    inp.addEventListener("input", e => { ov[key] = clampNum(e.target.value, min, max, def, float); changed(); });
  };
  numWire(".ost-size", "ost_size", 12, 1000, 56);
  numWire(".ost-leading", "ost_leading", 0.8, 3, 1.15, true);
  numWire(".ost-letter", "ost_letter", -20, 60, 0);
  numWire(".ost-x", "ost_x", -2000, 2000, 0);
  numWire(".ost-y", "ost_y", -2000, 2000, 0);
  numWire(".ost-rot", "ost_rotation", -180, 180, 0);
  // --- colours + eyedroppers ---
  const colWire = (sel, key, def) => {
    const inp = q(sel); inp.value = ov[key] || def;
    inp.addEventListener("input", e => { ov[key] = e.target.value; changed(); });
    inp.addEventListener("click", (e) => { e.preventDefault(); CPICK.open(inp, inp.value, (hx) => { inp.value = hx; inp.dispatchEvent(new Event("input", { bubbles: true })); }); });
  };
  colWire(".ost-color", "ost_color", "#ffffff");
  colWire(".ost-stroke-color", "ost_stroke_color", "#000000");
  colWire(".ost-bg-color", "ost_bg_color", "#000000");
  colWire(".ost-shadow-color", "ost_shadow_color", "#000000");
  const eyeMap = { color: [".ost-color", "ost_color"], stroke: [".ost-stroke-color", "ost_stroke_color"], bg: [".ost-bg-color", "ost_bg_color"], shadow: [".ost-shadow-color", "ost_shadow_color"] };
  qa(".ost-eyedrop").forEach(btn => {
    if (!window.EyeDropper) { btn.hidden = true; return; }
    btn.addEventListener("click", async () => {
      const [csel, ckey] = eyeMap[btn.dataset.eye] || [];
      try { const r = await new EyeDropper().open(); const inp = q(csel); inp.value = r.sRGBHex; ov[ckey] = r.sRGBHex; changed(); } catch (x) {}
    });
  });
  // --- checkboxes: fill / stroke / background / shadow ---
  const chkWire = (sel, key, def, after) => {
    const inp = q(sel); inp.checked = (ov[key] != null ? !!ov[key] : def);
    inp.addEventListener("change", e => { ov[key] = e.target.checked; if (after) after(e.target.checked); changed(); });
  };
  const showCw = (cwSel, on) => { const cw = q(cwSel); if (cw) cw.hidden = !on; };
  chkWire(".ost-fill", "ost_fill", true, (on) => showCw(".ost-cw-fill", on));
  showCw(".ost-cw-fill", ov.ost_fill !== false);
  const featWire = (chkSel, key, def, cwSel) => {
    const chk = q(chkSel), feat = chk.closest(".ost-feat"), pop = feat.querySelector(".ost-pop");
    const title = feat.querySelector(".ost-feat-title");
    chk.checked = (ov[key] != null ? !!ov[key] : def);
    showCw(cwSel, chk.checked);
    if (pop) pop.hidden = true;
    // checkbox = enable / disable only (no longer opens the values popover)
    chk.addEventListener("change", () => { ov[key] = chk.checked; showCw(cwSel, chk.checked); changed(); });
    // clicking the heading text opens/closes the values popover (Opacity / Size / Radius …), without toggling
    if (title && pop) title.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const willOpen = pop.hidden; closeAllPops(); pop.hidden = !willOpen;
    });
  };
  featWire(".ost-stroke", "ost_stroke", true, ".ost-cw-stroke");
  featWire(".ost-bg", "ost_bg", false, ".ost-cw-bg");
  featWire(".ost-shadow", "ost_shadow", true, ".ost-cw-shadow");
  // --- sliders with live read-outs ---
  const rngWire = (sel, key, def, vsel, suffix) => {
    const inp = q(sel); if (!inp) return;
    const vEl = q(vsel);
    inp.value = (ov[key] != null ? ov[key] : def);
    const show = () => { if (vEl) vEl.textContent = inp.value + (suffix || ""); };
    show();
    inp.addEventListener("input", e => { ov[key] = clampNum(e.target.value, +inp.min, +inp.max, def); show(); changed(); });
  };
  rngWire(".ost-stroke-w", "ost_stroke_w", 4, ".ost-stroke-w-v", "");
  rngWire(".ost-bg-opacity", "ost_bg_opacity", 60, ".ost-bg-opacity-v", "%");
  rngWire(".ost-bg-pad", "ost_bg_pad", 12, ".ost-bg-pad-v", "");
  rngWire(".ost-bg-radius", "ost_bg_radius", 8, ".ost-bg-radius-v", "");
  rngWire(".ost-shadow-opacity", "ost_shadow_opacity", 80, ".ost-shadow-opacity-v", "%");
  rngWire(".ost-shadow-size", "ost_shadow_size", 6, ".ost-shadow-size-v", "");
  rngWire(".ost-shadow-dir", "ost_shadow_dir", 135, ".ost-shadow-dir-v", "°");
  // --- placement icon buttons ---
  qa(".ost-place-btn").forEach(b => {
    b.classList.toggle("on", b.dataset.place === (ov.ost_place || "top"));
    b.addEventListener("click", () => {
      ov.ost_place = b.dataset.place;
      ov.ost_x = 0; ov.ost_y = 0;                       // placement snaps to its clean anchor, independent of the X/Y position
      const xi = q(".ost-x"), yi = q(".ost-y"); if (xi) xi.value = 0; if (yi) yi.value = 0;
      qa(".ost-place-btn").forEach(x => x.classList.toggle("on", x === b));
      changed();
    });
  });
  // --- Bold / Italic / UPPERCASE / Underline toggles ---
  const sbKey = { bold: "ost_bold", italic: "ost_italic", upper: "ost_upper", underline: "ost_underline" };
  qa(".ost-sb").forEach(b => {
    const key = sbKey[b.dataset.sb];
    b.classList.toggle("on", !!ov[key]);
    b.addEventListener("click", () => { ov[key] = !ov[key]; b.classList.toggle("on", !!ov[key]); changed(); });
  });
  qa(".scrub").forEach(makeScrubbable);
}

const CAMERA_OPTIONS = [
  { key: "none",    label: "None" },
  { key: "closeup", label: "Close-up" },
  { key: "extreme", label: "Extreme Close-up" },
  { key: "medium",  label: "Medium Shot" },
  { key: "wide",    label: "Wide Shot" },
  { key: "ots",     label: "Over the Shoulder" },
  { key: "top",     label: "Top View" },
  { key: "side",    label: "Side View" },
];
const cameraLabel = k => (CAMERA_OPTIONS.find(c => c.key === k) || CAMERA_OPTIONS.find(c => c.key === "medium")).label;
function buildCameraDropdown(container, s) {
  if (!container) return;
  const cur = s.camera || "medium";
  vDropdown(container, "Camera", cameraLabel(cur),
    CAMERA_OPTIONS.map(c => ({ value: c.key, label: c.label, selected: c.key === cur })),
    (v) => { s.camera = v; buildCameraDropdown(container, s); queueSave(); });   // rebuild to refresh the label
}

// scene transition = how this scene hands off to the NEXT one (keys must match app.py TRANSITIONS).
const TRANSITION_OPTIONS = [
  { key: "none",        label: "No Transition" },
  { key: "crossfade",   label: "Crossfade" },
  { key: "dip-black",   label: "Dip to Black" },
  { key: "dip-white",   label: "Flash (White)" },
  { key: "corporate",   label: "Corporate" },     // user clip — hit aligned to the cut
  { key: "film",        label: "Film" },
  { key: "lightleak",   label: "Light Leak" },
];
const transitionLabel = k => (TRANSITION_OPTIONS.find(t => t.key === k) || TRANSITION_OPTIONS[0]).label;
function buildTransitionDropdown(container, s) {
  if (!container) return;
  const cur = s.transition || "none";
  vDropdown(container, "Transition", transitionLabel(cur),
    TRANSITION_OPTIONS.map(t => ({ value: t.key, label: t.label, selected: t.key === cur })),
    (v) => { s.transition = v; buildTransitionDropdown(container, s); queueSave(); });
}

// ---------- tab 2: scenes ----------
function updateSceneCounts() {
  const scenes = DOC?.scenes || [];
  const total = scenes.length;
  const withImg = scenes.filter(s => (s.image?.versions || []).length || s.image?.file).length;
  const approved = scenes.filter(s => s.approved).length;
  const el = $("#scenesApproveCount");
  // combined: how many scenes total, how many have an image generated, how many approved
  if (el) el.textContent = total ? `${total} scenes · ${withImg} images generated · ${approved} approved` : "";
}
$("#hideApprovedBtn").addEventListener("click", () => {
  hideApproved = !hideApproved;
  const b = $("#hideApprovedBtn");
  b.classList.toggle("on", hideApproved);
  b.textContent = hideApproved ? "🙉 Show Approved" : "🙈 Hide Approved";
  renderScenes();
});
$("#hideApprovedVidBtn").addEventListener("click", () => {
  hideApprovedVideos = !hideApprovedVideos;
  const b = $("#hideApprovedVidBtn");
  b.classList.toggle("on", hideApprovedVideos);
  b.textContent = hideApprovedVideos ? "🙉 Show Approved" : "🙈 Hide Approved";
  renderVideos();
});
let _flashApprove = null;   // scene id to play the approve check-burst on after the next render (#7)
let _flashImg = null;       // scene id to crossfade the image on after the next render (version switch)
let _flashApproveVideo = null;   // same, but for the Videos tab
// Update a scene card's approved state in place (approved class + ✓ button) instead of a full
// renderScenes — so the reference thumbnails and on-screen-text swatches don't flash away and rebuild.
function patchApprove(el, s, cur, bA) {
  const approvedThis = s.approved && (s.image || {}).approved_version === cur;
  el.classList.toggle("approved", !!s.approved);
  bA.classList.toggle("on", approvedThis);
  bA.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
  if (approvedThis) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); }
}

// loading overlay over a scene's image preview WHILE it's generating/queued (spinner/clock + shimmer)
function addGenOverlay(imgPrev, status) {
  if (!imgPrev) return;
  let o = imgPrev.querySelector(".gen-overlay");
  if (!o) { o = document.createElement("div"); o.className = "gen-overlay"; imgPrev.appendChild(o); }
  if (o.dataset.st === status) return;
  o.dataset.st = status;
  o.innerHTML = (status === "queued"
    ? '<span class="gen-clock">🕒</span><span>Queued…</span>'
    : '<span class="sub-spin"></span><span>Generating…</span>')
    + '<button type="button" class="gen-stop" title="Stop this generation">⛔ Stop</button>';
}

// Stroked chevrons matching the app's icon language (same style as the Download icon).
const CHEV_L = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5.5 8.5 12 15 18.5"/></svg>';
const CHEV_R = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5.5 15.5 12 9 18.5"/></svg>';

// Carousel-style slide between image versions inside a positioned, clipped container.
// dir > 0 = next (new frame enters from the right); dir < 0 = prev (enters from the left).
// Animates a temporary overlay of the old + new frames, then commits the real swap so the
// underlying element already shows the new image before the overlay is removed (no flash).
function slideSwap(container, refImg, dir, newSrc, opts) {
  opts = opts || {};
  const commit = opts.commit || (() => {});
  if (!container || !refImg || !dir || !newSrc || container._sliding) { commit(); return; }
  const oldSrc = refImg.currentSrc || refImg.src;
  if (!oldSrc) { commit(); return; }
  container._sliding = true;
  const D = 340, ease = `transform ${D}ms cubic-bezier(.22,.61,.36,1)`;
  const fit = getComputedStyle(refImg).objectFit || "contain";
  const lay = document.createElement("div");
  lay.className = "slide-layer";
  // z-index 1: above the base <img> (static) so it covers it, but BELOW the fixed overlays —
  // the approve/change/delete icons (.img-actions, z2) and the version arrows (z2) — so those
  // stay put while the frames slide underneath (no disappear/reappear blink).
  lay.style.cssText = "position:absolute;inset:0;overflow:hidden;z-index:1;pointer-events:none;";
  const mk = (src, x) => {
    const i = document.createElement("img");
    i.src = src;
    i.style.cssText = `position:absolute;top:0;left:0;width:100%;height:100%;object-fit:${fit};transform:translateX(${x});will-change:transform;`;
    return i;
  };
  const outI = mk(oldSrc, "0"), inI = mk(newSrc, (dir * 100) + "%");
  lay.append(outI, inI);
  container.appendChild(lay);
  let launched = false;
  const start = () => {
    if (launched) return; launched = true;
    requestAnimationFrame(() => {
      outI.style.transition = ease; inI.style.transition = ease;
      requestAnimationFrame(() => {
        outI.style.transform = `translateX(${-dir * 100}%)`;
        inI.style.transform = "translateX(0)";
      });
    });
    setTimeout(commit, Math.round(D * 0.5));                         // swap the real src UNDER the layer (no old-image flash when it lifts)
    setTimeout(() => {
      lay.remove(); container._sliding = false;
      if (opts.onDone) opts.onDone();                               // heavier reconcile AFTER the layer is gone
    }, D + 40);
  };
  // Start the animation only once the INCOMING frame is decoded — the first slide to a not-yet-
  // loaded version would otherwise pop in blank mid-slide (that's the "first transition" stutter).
  // Cached versions decode instantly, so already-seen slides start with no perceptible delay.
  if (inI.decode) inI.decode().then(start, start);
  else if (inI.complete && inI.naturalWidth) start();
  else { inI.addEventListener("load", start, { once: true }); inI.addEventListener("error", start, { once: true }); }
  setTimeout(start, 500);                                            // hard fallback so a slow load never stalls the slide
}

// Version arrows OVER the image (left/right, fullscreen-preview style). Created lazily inside the
// image preview so they survive its innerHTML rebuilds; only shown when there's >1 version.
function wireVerArrows(imgPrev, s, cur, vsLen) {
  if (!imgPrev) return;
  let prevA = imgPrev.querySelector(".img-arrow.prev");
  let nextA = imgPrev.querySelector(".img-arrow.next");
  let badge = imgPrev.querySelector(".ver-badge");
  if (vsLen <= 1) { if (prevA) prevA.remove(); if (nextA) nextA.remove(); if (badge) badge.remove(); return; }
  if (!prevA) {
    prevA = document.createElement("button");
    prevA.type = "button"; prevA.className = "img-arrow prev"; prevA.title = "Previous version"; prevA.innerHTML = CHEV_L;
    imgPrev.appendChild(prevA);
  }
  if (!nextA) {
    nextA = document.createElement("button");
    nextA.type = "button"; nextA.className = "img-arrow next"; nextA.title = "Next version"; nextA.innerHTML = CHEV_R;
    imgPrev.appendChild(nextA);
  }
  if (!badge) { badge = document.createElement("span"); badge.className = "ver-badge"; imgPrev.appendChild(badge); }
  badge.textContent = `${cur + 1} / ${vsLen}`;   // version indicator overlaid on the image (bottom-centre)
  prevA.disabled = cur <= 0;
  nextA.disabled = cur >= vsLen - 1;
  // warm the neighbouring versions so their slide has the frame already decoded (instant, no stutter)
  [cur - 1, cur + 1].forEach(i => {
    if (i >= 0 && i < vsLen) { const im = new Image(); im.src = mediaUrl(s.image.versions[i], s.image.taskId); }
  });
  const go = (to, dir) => async (e) => {
    e.stopPropagation(); e.preventDefault();
    await flushSave();
    const under = imgPrev.querySelector("img");                          // the currently-shown image
    const newSrc = mediaUrl(s.image.versions[to], s.image.taskId);
    const commit = () => { if (under) under.src = newSrc; };             // show the new one underneath BEFORE the layer lifts (no old-image flash)
    const onDone = () => {
      // reconcile only THIS card (label, arrows, approve/download) — NOT renderScenes(), which
      // wipes #scenesList innerHTML and rebuilds every card mid-animation (that was the first-slide jank).
      s.image.current = to;
      s._appLock = Date.now() + 8000;                                     // guard the shown version against a poll snap-back
      const el = imgPrev.closest(".scene-row");
      if (el) patchSceneMedia(el, s);
      // patchSceneMedia rebuilds the <img> with an .img-loading opacity fade; but the pixels are
      // already the slid-in frame, so kill that fade — show it instantly (no post-slide fade-in).
      const nimg = imgPrev.querySelector("img");
      if (nimg) {
        imgPrev.classList.remove("img-loading");
        nimg.style.transition = "none"; nimg.style.opacity = "1";
        requestAnimationFrame(() => { nimg.style.transition = ""; });
      }
      api.setCurrent(PROJECT, s.id, to);                                 // persist in the background — no full re-render
    };
    slideSwap(imgPrev, under, dir, newSrc, { commit, onDone });          // slide the new version in
  };
  prevA.onclick = go(cur - 1, -1);
  nextA.onclick = go(cur + 1, +1);
}

// ---- drag-to-reorder + undo ----
let DRAG_SID = null;
function clearDrop() { $$(".scene-row").forEach(r => r.classList.remove("drop-before", "drop-after")); }
function _sceneRowTops() {   // viewport tops keyed by the CURRENT (old) scene id — for FLIP
  const map = {};
  $$(".scene-row").forEach(r => { map[r.dataset.id] = r.getBoundingClientRect().top; });
  return map;
}
function _flipScenes(firstTops, newOrderOfOldIds) {
  const rows = $$(".scene-row");
  rows.forEach((row, i) => {
    const from = firstTops[newOrderOfOldIds[i]];          // where this scene's row USED to be
    if (from == null) return;
    const dy = from - row.getBoundingClientRect().top;
    if (Math.abs(dy) < 1) return;
    row.style.transition = "none";
    row.style.transform = `translateY(${dy}px)`;          // start at the old position
    requestAnimationFrame(() => {
      row.style.transition = "transform .34s cubic-bezier(.2,.8,.2,1)";
      row.style.transform = "";                           // glide to the new position
    });
    setTimeout(() => { row.style.transition = ""; }, 380);
  });
}
async function reorderScene(srcId, targetId, after) {
  await flushSave();
  pushUndo("reorder scenes");
  const ids = DOC.scenes.map(s => s.id).filter(i => i !== srcId);
  let idx = ids.indexOf(targetId);
  if (after) idx += 1;
  ids.splice(idx, 0, srcId);                              // ids = new order, in terms of the OLD ids
  const firstTops = _sceneRowTops();                      // FIRST (before) positions
  DOC = await api.reorder(PROJECT, ids);
  renderScenes(); renderVideos();
  _flipScenes(firstTops, ids);                            // LAST/INVERT/PLAY → rows glide into place
}
let undoStack = [], redoStack = [];
// ---- text-edit undo/redo ----
// Typing in the script or a scene's text fields (voice-over, image prompt, video prompt, notes) is grouped
// into undo steps that revert ONLY the text — never a generated image/video. A step is captured when you
// leave a field or pause typing. Ctrl+Z reverts it; Ctrl+Y (Redo) brings it back.
const TEXT_FIELDS = ["vo", "vo_tr", "prompt", "note", "video_desc", "video_prompt"];
const TEXT_SEL = "#scriptText, .prompt, .vo, .video-desc, .video-prompt";
let _textBase = null, _textTimer = null;
function textState() {
  const st = $("#scriptText");
  return {
    script: st ? st.value : ((DOC && DOC.script) || ""),
    scenes: ((DOC && DOC.scenes) || []).map(s => { const o = { id: s.id }; TEXT_FIELDS.forEach(f => o[f] = s[f]); return o; })
  };
}
function applyTextState(ts) {
  const st = $("#scriptText"); if (st && ts.script != null) st.value = ts.script;
  const byId = {}; (ts.scenes || []).forEach(s => byId[s.id] = s);
  ((DOC && DOC.scenes) || []).forEach(s => { const o = byId[s.id]; if (o) TEXT_FIELDS.forEach(f => { if (f in o) s[f] = o[f]; }); });
}
function commitTextUndo() {                     // push the pending text edit (if any) as one undo step
  clearTimeout(_textTimer); _textTimer = null;
  if (_textBase == null || !DOC) return;
  const now = textState();
  if (JSON.stringify(now) === JSON.stringify(_textBase)) { return; }
  undoStack.push({ label: "edit text", textSafe: true, text: _textBase });
  if (undoStack.length > 40) undoStack.shift();
  redoStack = []; _textBase = now; updateUndoBtn();
}
document.addEventListener("focusin", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL) && _textBase == null) _textBase = textState(); });
document.addEventListener("focusout", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL)) commitTextUndo(); });
document.addEventListener("input", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL)) { if (_textBase == null) _textBase = textState(); clearTimeout(_textTimer); _textTimer = setTimeout(commitTextUndo, 1500); } });

function pushUndo(label) {
  if (!DOC) return;
  commitTextUndo();                            // record any pending text edit as its own step first
  undoStack.push({ label, doc: JSON.parse(JSON.stringify(DOC)) });   // snapshot BEFORE the action
  if (undoStack.length > 25) undoStack.shift();
  redoStack = [];                              // a fresh action invalidates the redo history
  updateUndoBtn();
}
async function _restoreTextStep(snap, intoStack) {
  intoStack.push({ label: snap.label, textSafe: true, text: textState() });   // current text → the other stack
  if (intoStack.length > 40) intoStack.shift();
  applyTextState(snap.text);
  try { await api.save(PROJECT, DOC); } catch (e) {}
  renderScenes(); if (typeof updateGenBtns === "function") updateGenBtns();
  _textBase = textState(); updateUndoBtn();
}
async function doUndo() {
  commitTextUndo();                            // flush any in-progress text edit as its own step first
  if (!undoStack.length || !PROJECT) return;
  const snap = undoStack.pop();
  if (snap.textSafe) { await _restoreTextStep(snap, redoStack); toast(`Undone: ${snap.label}`, "ok"); return; }
  redoStack.push({ label: snap.label, doc: JSON.parse(JSON.stringify(DOC)) });   // current state → redo
  if (redoStack.length > 25) redoStack.shift();
  DOC = await api.restore(PROJECT, snap.doc);
  renderScenes(); renderVideos(); renderGenProgress(); _textBase = textState(); updateUndoBtn();
  toast(`Undone: ${snap.label}`, "ok");
}
async function doRedo() {
  commitTextUndo();
  if (!redoStack.length || !PROJECT) return;
  const snap = redoStack.pop();
  if (snap.textSafe) { await _restoreTextStep(snap, undoStack); toast(`Redone: ${snap.label}`, "ok"); return; }
  undoStack.push({ label: snap.label, doc: JSON.parse(JSON.stringify(DOC)) });   // current state → undo
  if (undoStack.length > 25) undoStack.shift();
  DOC = await api.restore(PROJECT, snap.doc);
  renderScenes(); renderVideos(); renderGenProgress(); _textBase = textState(); updateUndoBtn();
  toast(`Redone: ${snap.label}`, "ok");
}
function updateUndoBtn() {
  const b = $("#undoBtn");
  if (b) { b.disabled = !undoStack.length; b.title = undoStack.length ? `Undo: ${undoStack[undoStack.length - 1].label}` : "Nothing to undo"; }
  const r = $("#redoBtn");
  if (r) { r.disabled = !redoStack.length; r.title = redoStack.length ? `Redo: ${redoStack[redoStack.length - 1].label}` : "Nothing to redo"; }
}

// ---- bilingual VO: a faint, read-only Turkish translation under each scene's sentence ----
// French/German projects auto-translate on split (and keep in sync as you edit); English projects are
// manual (a ⇄ TR button per scene). Prompts are always English and untouched.
const LANG_BY_LOC = { "France": "French", "Germany": "German", "United States": "English", "United Kingdom": "English" };
function projectLang() {
  const locs = (DOC && DOC.audience && DOC.audience.locations) || [];
  return LANG_BY_LOC[locs[0]] || "English";
}
function autoTr() { const l = projectLang(); return l === "French" || l === "German"; }
function showVoTr(el, text) {
  const d = el && el.querySelector(".vo-tr");
  if (!d) return;
  if (text && String(text).trim()) { d.textContent = text; d.hidden = false; }
  else { d.textContent = ""; d.hidden = true; }
}
function autoGrowVo(ta) {                        // hug the sentence's height so there's no empty row before the translation
  if (!ta) return;
  ta.style.height = "auto";                     // rows=1 fallback (1 line) when the field is hidden
  const h = ta.scrollHeight;
  if (h > 0) ta.style.height = h + "px";        // only size when laid out — a HIDDEN field reports 0; never collapse it
}
function autoGrowAllVo() { $$(".sc-vo-box textarea.vo").forEach(autoGrowVo); }   // re-fit when the Scenes tab becomes visible
// Kept OUTSIDE the scene object (never serialized into scenes.json): which source text we last
// translated per scene + an in-flight guard. Together they make translation idempotent — translating
// the SAME text again is a no-op — which breaks any accidental repeat-trigger loop.
const _trBusy = {}, _trLastSrc = {};
async function translateSceneVo(s, el, btn, manual) {
  const src = (s.vo || "").trim();
  if (!src) { s.vo_tr = ""; _trLastSrc[s.id] = ""; showVoTr(el, ""); queueSave(); return; }
  if (_trBusy[s.id]) return;                              // one translation at a time per scene
  if (_trLastSrc[s.id] === src && s.vo_tr) {              // already translated this EXACT text → skip
    if (manual) toast(`Already translated: Scene ${s.id}`, "info");
    return;
  }
  _trBusy[s.id] = true;
  if (btn) btn.classList.add("busy-tr");     // small spinner over the flag while it generates
  try {
    const r = await api.translate([src], projectLang());
    if (r && r.error) { toast("Translation failed: " + r.error, "err"); return; }
    const tr = (r && r.translations && r.translations[0]) || "";
    s.vo_tr = tr; _trLastSrc[s.id] = src; showVoTr(el, tr); queueSave();
    if (manual) toast(`Translated to Turkish: Scene ${s.id}`, "ok");   // only on a manual flag click
  } catch (e) { toast("Translation failed", "err"); }
  finally { _trBusy[s.id] = false; if (btn) btn.classList.remove("busy-tr"); }
}
async function translateAllScenes() {           // batch-translate every scene's VO (used right after split)
  if (!DOC || !DOC.scenes || !DOC.scenes.length) return;
  const src = DOC.scenes.map(s => (s.vo || ""));
  if (!src.some(t => t.trim())) return;
  try {
    const r = await api.translate(src, projectLang());
    if (r && r.error) { toast("Translation failed: " + r.error, "err"); return; }
    const trs = (r && r.translations) || [];
    DOC.scenes.forEach((s, i) => { s.vo_tr = trs[i] || ""; _trLastSrc[s.id] = (s.vo || "").trim(); });
    await api.save(PROJECT, DOC);
    renderScenes();
  } catch (e) { toast("Translation failed", "err"); }
}

// Draw a scene's overlay icons (s.icons) over an image. Each is draggable (snaps to the image centre and to the
// other icons, Figma-style); when CLICKED it shows rotate/resize/delete (+flip for arrows) handles and a green
// highlight. Position (x,y) = icon CENTRE in normalized frame coords — exactly what the XML export uses. The
// icon PNG is recoloured SERVER-SIDE (/icons/name?h=<hue>) so the preview tone == the exported tone, and every
// icon lands on the identical tone per colour. Double-click opens a colour palette. Used by BOTH the scene card
// and the fullscreen lightbox — they just hand a different `layer` (which always overlays the image exactly).
const _ICON_BASE = { x: 0.24, arrow: 0.27, burst: 0.34, check: 0.27, sparkle: 0.22 };   // art width as a fraction of the frame (preview only)
const _ICON_SRC = { x: "icon_x_t.png", arrow: "icon_arrow_t.png", burst: "icon_ring_t.png", check: "icon_check_t.png",
  sparkle: "icon_sparkle_t.png" };
const _FX_KINDS = new Set(["sparkle"]);   // light/motion EFFECT (screen-blend feel)
// ================= VIDEO EFFECT registry (single source of truth) =================
// kind -> { blend, art:{aw,ah,fw,fh} }.  blend "alpha" = source has real alpha (preview .webm / export ProRes,
// NORMAL composite, no recolour).  blend "key" = white-on-black (preview .mp4 + luma-key/tint filter; export
// keyed to alpha).  `art` = where the drawing sits inside the full frame so the selection box hugs it.
const _VFX = {
  movarrow: { blend: "key",   art: { aw: 536, ah: 119, fw: 1920, fh: 1080 } },
  va1:  { blend: "alpha", art: { aw: 788, ah: 946, fw: 3840, fh: 2160 } },
  va2:  { blend: "alpha", art: { aw: 558, ah: 747, fw: 3840, fh: 2160 } },
  va3:  { blend: "alpha", art: { aw: 602, ah: 320, fw: 1920, fh: 1080 } },
  va4:  { blend: "alpha", art: { aw: 1041, ah: 1049, fw: 2560, fh: 1440 } },
  xv1:  { blend: "alpha", art: { aw: 830, ah: 830, fw: 1920, fh: 1080 } },
  xv2:  { blend: "alpha", art: { aw: 765, ah: 816, fw: 1440, fh: 1440 } },
  cancel: { blend: "alpha", art: { aw: 1141, ah: 1215, fw: 2560, fh: 1440 } },
  chkg: { blend: "alpha", art: { aw: 614, ah: 615, fw: 1920, fh: 1080 } },
  hw9:  { blend: "key",   art: { aw: 402, ah: 342, fw: 1920, fh: 1080 } },
  hw1:  { blend: "key",   art: { aw: 470, ah: 344, fw: 1920, fh: 1080 } },
  hw4:  { blend: "key",   art: { aw: 379, ah: 286, fw: 1920, fh: 1080 } },
  hw6:  { blend: "key",   art: { aw: 568, ah: 625, fw: 1920, fh: 1080 } },
  warn: { blend: "alpha", art: { aw: 558, ah: 532, fw: 1600, fh: 900 } },   // green-screen -> chroma-keyed to alpha
  ques: { blend: "key",   art: { aw: 669, ah: 847, fw: 1920, fh: 1080 } },
  time: { blend: "alpha", mode: "loop", art: { aw: 695, ah: 695, fw: 1600, fh: 900 } },   // clock: LOOP at native speed
};
const _MOV_MODE = k => (_VFX[k] || {}).mode || "once";   // "once" = play once then FREEZE last frame; "loop" = repeat
// art-CENTRE offset from the frame centre (normalized) — the drawing isn't always centred, so shift it so the
// selection box hugs it and it lands exactly at the placed point (no clipping). [acx, acy]; default [0,0].
const _MOV_OFF = { va1: [-0.046, 0.084], va2: [-0.042, 0.073], va4: [0.019, 0.062], xv2: [-0.018, -0.007],
  cancel: [0.008, 0.009], ques: [0.015, -0.038], time: [0.008, 0.001] };
const _MOV_FX = new Set(Object.keys(_VFX));
const _MOV_SRC = {}, _MOV_ART = {};
Object.keys(_VFX).forEach(k => {
  const v = _VFX[k]; const off = _MOV_OFF[k] || [0, 0];
  _MOV_ART[k] = { ...v.art, acx: off[0], acy: off[1] };
  _MOV_SRC[k] = "icon_" + k + (v.blend === "alpha" ? ".webm" : ".mp4");
  _ICON_SRC[k] = "icon_" + k + "_t.png";        // thumbnail (a late frame, keyed to alpha)
  _ICON_BASE[k] = v.art.aw / v.art.fw;          // on-screen width fraction = art bbox / frame
});
const _MOV_BLEND = k => (_VFX[k] || {}).blend;  // "alpha" | "key"

// The grouped "Icons" panel. Each entry is a LEAF (kind -> adds directly) or a PARENT (variants -> opens a
// flyout of styled choices). Adding a new clip = drop it in _VFX + add a line here.
const _ICON_PANEL = [
  ["Mark", [
    { label: "X", emoji: "❌", variants: [["x", "Plain X"], ["xv1", "Pop Up X"], ["xv2", "Turning X"]] },
    { label: "Check", emoji: "✅", variants: [["check", "Plain"], ["chkg", "Pop Up"]] },
    { label: "Cancel", emoji: "🚫", kind: "cancel" },
  ]],
  ["Point", [
    { label: "Arrow", emoji: "➡️", variants: [["va1", "Bold"], ["va2", "Point Circle"], ["va4", "Point"], ["va3", "3-Arrow"], ["arrow", "Plain"]] },
    { label: "Handwritten", emoji: "✍️", variants: [["movarrow", "Style 1"], ["hw1", "Style 2"], ["hw4", "Style 3"], ["hw6", "Style 4"], ["hw9", "Style 5"]] },
  ]],
  ["Emphasis", [
    { label: "Pain Point", emoji: "⭕", kind: "burst" },
    { label: "Warning", emoji: "⚠️", kind: "warn" },
    { label: "Question", emoji: "❓", kind: "ques" },
  ]],
  ["Time", [
    { label: "Time", emoji: "⏱️", kind: "time" },
  ]],
];
// per-kind DEFAULT colour when first added (else red/native). 900 = white, 120 = green.
const _DEF_HUE = { check: 120, chkg: 120, ques: 900 };
function _mkAddBtn(kind, emoji, label) {
  const b = document.createElement("button"); b.type = "button"; b.className = "icon-add"; b.dataset.icon = kind;
  b.innerHTML = `<span class="ia-e">${emoji}</span><span class="ia-l">${label}</span>`;
  return b;
}
function _mkVariantBtn(kind, label) {
  const b = document.createElement("button"); b.type = "button"; b.className = "icon-add icon-variant"; b.dataset.icon = kind;
  const dh = _DEF_HUE[kind] || 0;
  const src = _MOV_FX.has(kind) ? ("/icons/icon_" + kind + "_c.png") : _iconSrc({ type: kind, hue: dh });   // _c = cropped to the art so every thumbnail fills the box uniformly
  const flt = (dh && _MOV_FX.has(kind) && _MOV_BLEND(kind) === "key") ? (`filter:url(#${movfxFilterId(dh)});`) : "";   // key clip thumbnail tints
  b.innerHTML = `<img class="ia-thumb" src="${src}" draggable="false" style="${flt}"><span class="ia-l">${label}</span>`;
  return b;
}
function buildIconsPanel(menu) {
  if (!menu || menu.dataset.built) return;        // build once per card
  menu.dataset.built = "1"; menu.innerHTML = "";
  _ICON_PANEL.forEach(([group, entries]) => {
    const g = document.createElement("div"); g.className = "icons-grp";
    const t = document.createElement("div"); t.className = "icons-grp-t"; t.textContent = group; g.appendChild(t);
    const body = document.createElement("div"); body.className = "icons-grp-b"; g.appendChild(body);
    entries.forEach(en => {
      if (en.kind) { body.appendChild(_mkAddBtn(en.kind, en.emoji, en.label)); return; }
      const wrap = document.createElement("div"); wrap.className = "icons-parent";
      const p = document.createElement("button"); p.type = "button"; p.className = "icon-parent-btn";
      p.innerHTML = `<span class="ia-e">${en.emoji}</span><span class="ia-l">${en.label}</span><span class="ia-c">▸</span>`;
      const sub = document.createElement("div"); sub.className = "icons-sub"; sub.hidden = true;
      en.variants.forEach(([kind, vl]) => sub.appendChild(_mkVariantBtn(kind, vl)));
      p.addEventListener("click", (e) => {
        e.stopPropagation();
        menu.querySelectorAll(".icons-sub").forEach(s => { if (s !== sub) s.hidden = true; });
        menu.querySelectorAll(".icon-parent-btn").forEach(b => { if (b !== p) b.classList.remove("open"); });
        sub.hidden = !sub.hidden; p.classList.toggle("open", !sub.hidden);
      });
      wrap.append(p, sub); body.appendChild(wrap);
    });
    menu.appendChild(g);
  });
}
// palette: [label, absolute hue deg, swatch colour]. Red = 0 = the icons' native red (no tint).
const _ICON_PALETTE = [["Red", 0, "#e6362d"], ["Orange", 28, "#f08a1d"], ["Yellow", 50, "#f5c518"],
  ["Green", 120, "#3fb64f"], ["Teal", 172, "#1fb6a6"], ["Blue", 210, "#2f7ff0"], ["Purple", 280, "#9b53d6"],
  ["White", 900, "#ffffff"], ["Charcoal", 901, "#2b2b2b"]];   // 900/901 = achromatic (desaturate, not hue-rotate)
function _hueToCss(hue) { const e = _ICON_PALETTE.find(p => p[1] === (hue == null ? 900 : hue)); return e ? e[2] : "#ffffff"; }
// PREVIEW-ONLY simplification: these kinds render as a plain recolourable glyph in the image preview + the
// assemble preview (their real animated clip is unchanged in the render and the Premiere XML).
const _PLAIN_PREVIEW = new Set(["ques"]);
const _PLAIN_GLYPH = { ques: "?" };
function _iconSrc(ic) {
  const nm = ic.type === "arrow" ? (ic.flip ? "icon_arrow_flip_t.png" : "icon_arrow_t.png") : (_ICON_SRC[ic.type] || _ICON_SRC.x);
  if (_MOV_FX.has(ic.type)) return "/icons/" + nm;   // video effect: colour comes from the CSS tint filter, not a server recolour
  return "/icons/" + nm + (ic.hue ? "?h=" + ic.hue : "");
}
function _deselectIcons() {
  document.querySelectorAll(".sc-icon.sel").forEach(n => n.classList.remove("sel"));
  document.querySelectorAll(".sc-ic-palette").forEach(n => n.remove());
}
function _deselectOst() {   // drop the on-screen-text selection highlight everywhere
  document.querySelectorAll(".scene-ost.ost-selected").forEach(n => n.classList.remove("ost-selected"));
}
if (!window._iconDeselWired) {   // click anywhere outside an icon / on-screen text → drop the selection
  window._iconDeselWired = true;
  document.addEventListener("pointerdown", (e) => {
    const t = e.target;
    if (!t.closest || (!t.closest(".sc-icon") && !t.closest(".sc-ic-palette"))) _deselectIcons();
    if (!t.closest || !t.closest(".scene-ost")) _deselectOst();   // clicked away from any on-screen text → deselect it
  }, true);
}
// snap the dragged icon's CENTRE to the image centre and to the other icons' centres (returns px nudge + guide px)
function iconSnap(node, layer, th) {
  const R = node.getBoundingClientRect(), IR = layer.getBoundingClientRect();
  const others = [...layer.querySelectorAll(".sc-icon")].filter(e => e !== node).map(e => e.getBoundingClientRect());
  const pick = (p, ts) => { let best = null; ts.forEach(t => { const d = t - p; if (Math.abs(d) < th && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, g: t }; }); return best; };
  const txX = [IR.left + IR.width / 2]; others.forEach(o => txX.push(o.left + o.width / 2));
  const txY = [IR.top + IR.height / 2]; others.forEach(o => txY.push(o.top + o.height / 2));
  const bx = pick(R.left + R.width / 2, txX), by = pick(R.top + R.height / 2, txY);
  return { dx: bx ? bx.d : 0, dy: by ? by.d : 0, gx: bx ? bx.g : null, gy: by ? by.g : null };
}
// Build ONE interactive icon node inside `layer` (which overlays the coordinate image). cb.commit() saves;
// cb.redraw() rebuilds the whole layer (after a delete). cb.mirror() (optional) redraws the twin surface.
function buildIconNode(ic, s, layer, cb) {
  const clamp = v => Math.min(1, Math.max(0, v));
  const node = document.createElement("div"); node.className = "sc-icon";
  const isMov = _MOV_FX.has(ic.type);
  const isPlain = _PLAIN_PREVIEW.has(ic.type);   // question mark etc.: a simple recolourable glyph in the preview
  const img = document.createElement(isPlain ? "div" : "img");
  if (!isPlain) img.draggable = false;
  const setSrc = () => {
    if (isPlain) { img.className = "sc-ic-glyph"; img.textContent = _PLAIN_GLYPH[ic.type] || "?"; img.style.color = _hueToCss(ic.hue); return; }
    img.src = _iconSrc(ic);
    img.style.filter = (isMov && _MOV_BLEND(ic.type) === "key") ? ("url(#" + movfxFilterId(ic.hue) + ")")   // key clip: luma->alpha + tint
      : (isMov ? "none" : "drop-shadow(0 2px 4px rgba(0,0,0,.45))");   // alpha clip: thumbnail already has colour+alpha
  };
  setSrc();
  if (isPlain) node.appendChild(img);
  else if (isMov) {   // clip the scaled-up thumbnail to the ART bbox in an inner div so the resize/rotate handles (on the node) aren't clipped
    const clip = document.createElement("div"); clip.style.cssText = "position:absolute;inset:0;overflow:hidden"; clip.appendChild(img); node.appendChild(clip);
  } else node.appendChild(img);
  const hRot = Object.assign(document.createElement("div"), { className: "ost-h ost-h-rot", title: "Rotate" });
  const hSize = Object.assign(document.createElement("div"), { className: "ost-h ost-h-size", title: "Resize" });
  const delB = Object.assign(document.createElement("button"), { className: "ost-del-btn", textContent: "×", title: "Delete icon" });
  node.append(hRot, hSize, delB);
  let hFlip = null;
  if (ic.type === "arrow") { hFlip = Object.assign(document.createElement("div"), { className: "sc-ic-flip", textContent: "⇄", title: "Flip left / right" }); node.appendChild(hFlip); }
  const place = () => {
    const w = layer.clientWidth || 1;
    node.style.left = (ic.x * 100) + "%"; node.style.top = (ic.y * 100) + "%";
    node.style.transform = `translate(-50%,-50%) rotate(${ic.rot || 0}deg)`;
    if (isMov && !isPlain) {   // node hugs the ART bbox; the thumbnail is scaled up + centred inside the clip so the art fills it
      const art = _MOV_ART[ic.type] || { aw: 1, ah: 1, fw: 1, fh: 1 };
      const nodeW = w * (_ICON_BASE[ic.type] || 0.28) * (ic.size || 1);   // base already = the art's frame fraction
      const nodeH = nodeW * (art.ah / art.aw);
      node.style.width = nodeW + "px"; node.style.height = nodeH + "px";
      const vw = nodeW * art.fw / art.aw, vh = nodeW * art.fh / art.aw;
      img.style.position = "absolute"; img.style.left = "50%"; img.style.top = "50%";
      img.style.transform = "translate(calc(-50% + " + (-(art.acx || 0) * vw) + "px),calc(-50% + " + (-(art.acy || 0) * vh) + "px))";
      img.style.width = vw + "px"; img.style.height = vh + "px";
      return;
    }
    const base = w * (_ICON_BASE[ic.type] || 0.26) * (ic.size || 1);
    node.style.width = base + "px"; node.style.height = base + "px";
    if (isPlain) img.style.fontSize = (base * 1.1) + "px";
  };
  place();
  const rect = () => layer.getBoundingClientRect();
  const select = () => { _deselectIcons(); node.classList.add("sel"); };
  const commit = () => { if (cb.commit) cb.commit(); };
  // MOVE — grab offset so it doesn't jump; snap centre to image centre / other icons
  node.addEventListener("pointerdown", (e) => {
    if (e.target === hRot || e.target === hSize || e.target === delB || e.target === hFlip) return;
    e.preventDefault(); e.stopPropagation(); select();
    const r = rect(); const gx = e.clientX - (r.left + ic.x * r.width), gy = e.clientY - (r.top + ic.y * r.height);
    let _snapd = false;
    const move = (ev) => {
      if (!_snapd) { _snapd = true; pushUndo("move icon"); }   // snapshot once, only if the icon actually moves
      ic.x = clamp((ev.clientX - gx - r.left) / r.width); ic.y = clamp((ev.clientY - gy - r.top) / r.height); place();
      const snap = iconSnap(node, layer, 7);
      if (snap.dx || snap.dy) { ic.x = clamp(ic.x + snap.dx / r.width); ic.y = clamp(ic.y + snap.dy / r.height); place(); }
      ostGuides(layer, snap.gx, snap.gy);
    };
    const up = () => { document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up); ostClearGuides(layer); commit(); };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
  });
  hSize.addEventListener("pointerdown", (e) => {
    e.preventDefault(); e.stopPropagation(); select();
    // RELATIVE resize: remember the size + grab distance, then scale proportionally — so it never jumps at grab.
    const r0 = rect(); const d0 = Math.max(6, Math.hypot(e.clientX - (r0.left + ic.x * r0.width), e.clientY - (r0.top + ic.y * r0.height)));
    const s0 = ic.size || 1; let _snapd = false;
    const move = (ev) => { if (!_snapd) { _snapd = true; pushUndo("resize icon"); } const r = rect(); const d = Math.hypot(ev.clientX - (r.left + ic.x * r.width), ev.clientY - (r.top + ic.y * r.height)); ic.size = Math.min(3, Math.max(0.3, s0 * d / d0)); place(); };
    const up = () => { document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up); commit(); };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
  });
  hRot.addEventListener("pointerdown", (e) => {
    e.preventDefault(); e.stopPropagation(); select();
    let _snapd = false;
    // fresh badge helpers each drag (tiny floating "90°" readout near the cursor, green when it snaps)
    const showRotBadge = (x, y, deg, snapped) => {
      let b = document.getElementById("iconRotBadge");
      if (!b) { b = document.createElement("div"); b.id = "iconRotBadge"; document.body.appendChild(b); }
      b.className = "icon-rot-badge" + (snapped ? " snapped" : "");
      b.textContent = deg + "°";
      b.style.left = (x + 16) + "px"; b.style.top = (y - 10) + "px"; b.style.display = "block";
    };
    const hideRotBadge = () => { const b = document.getElementById("iconRotBadge"); if (b) b.style.display = "none"; };
    const move = (ev) => {
      if (!_snapd) { _snapd = true; pushUndo("rotate icon"); }
      const r = rect(); const cxp = r.left + ic.x * r.width, cyp = r.top + ic.y * r.height;
      let d = Math.round(Math.atan2(ev.clientY - cyp, ev.clientX - cxp) * 180 / Math.PI + 90);
      d = ((d % 360) + 360) % 360;                                   // normalize to 0..359
      // SNAP to the nice angles while rotating: 0/90/180/270 (strong pull), then 45/135/225/315 (diagonals)
      const snap = (step, tol) => { const n = Math.round(d / step) * step; return Math.abs(d - n) <= tol ? ((n % 360) + 360) % 360 : null; };
      const s90 = snap(90, 8); const s45 = snap(45, 5);
      const snapped = s90 !== null || s45 !== null;
      d = s90 !== null ? s90 : (s45 !== null ? s45 : d);
      ic.rot = d; place();
      showRotBadge(ev.clientX, ev.clientY, d, snapped);   // live angle readout (green when snapped to 45/90…)
    };
    const up = () => { document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up); hideRotBadge(); commit(); };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
  });
  delB.addEventListener("pointerdown", e => e.stopPropagation());
  delB.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); const i = s.icons.indexOf(ic); if (i >= 0) { pushUndo("delete icon"); s.icons.splice(i, 1); } if (cb.redraw) cb.redraw(); commit(); });
  if (hFlip) { hFlip.addEventListener("pointerdown", e => e.stopPropagation()); hFlip.addEventListener("click", (e) => { e.stopPropagation(); pushUndo("flip icon"); ic.flip = !ic.flip; setSrc(); commit(); }); }
  // DOUBLE-CLICK → colour palette (server-recolours the PNG to that absolute hue)
  node.addEventListener("dblclick", (e) => {
    e.preventDefault(); e.stopPropagation(); select();
    // pre-coloured video clips (real-alpha) can't be recoloured -> no palette. Static icons + white "key" clips can.
    if (_MOV_FX.has(ic.type) && _MOV_BLEND(ic.type) !== "key") return;
    layer.querySelectorAll(".sc-ic-palette").forEach(n => n.remove());
    const pal = document.createElement("div"); pal.className = "sc-ic-palette";
    pal.style.left = (ic.x * 100) + "%"; pal.style.top = "calc(" + (ic.y * 100) + "% + 16px)"; pal.style.transform = "translate(-50%,0)";
    _ICON_PALETTE.forEach(([nm, hue, col]) => {
      const sw = document.createElement("div"); sw.className = "sc-ic-sw" + ((ic.hue || 0) === hue ? " on" : ""); sw.title = nm;
      sw.style.background = col;
      sw.addEventListener("pointerdown", ev => ev.stopPropagation());
      sw.addEventListener("click", (ev) => { ev.stopPropagation(); ic.hue = hue; setSrc(); pal.remove(); commit(); });
      pal.appendChild(sw);
    });
    layer.appendChild(pal);
  });
  layer.appendChild(node);
  return node;
}
function renderSceneIcons(el, s) {
  const prev = el.querySelector(".img-preview"); if (!prev) return;
  const old = prev.querySelector(".icon-layer"); if (old) old.remove();
  // migrate legacy single-icon fields into the unified list so already-placed icons SHOW immediately
  if ((!Array.isArray(s.icons) || !s.icons.length) && s.icon) {
    s.icons = [{ type: s.icon, x: (s.icon_x ?? 0.5), y: (s.icon_y ?? 0.5), size: (s.icon_size ?? 1), rot: 0, flip: false }];
    delete s.icon; delete s.icon_x; delete s.icon_y; delete s.icon_size;
  }
  const icons = Array.isArray(s.icons) ? s.icons : [];
  if (!icons.length || !prev.dataset.file) return;   // 2D scenes CAN show manually-placed icons (auto never adds them)
  // On first render the card isn't laid out yet → clientWidth is 0 → icons would size to 0px (invisible).
  // Keep retrying for a few frames while the card is in the DOM (not just a single offsetParent-gated retry),
  // so the icons draw as soon as the card gets a real width — this is what made placed icons sometimes not
  // appear until a tab switch. We also need the IMAGE loaded (naturalWidth) to size the layer to it.
  const img = prev.querySelector("img");
  if (!prev.clientWidth || !img || !img.naturalWidth) {
    const n = (el._icRetry = (el._icRetry || 0) + 1);
    if (img && !img.naturalWidth && img.isConnected) img.addEventListener("load", () => renderSceneIcons(el, s), { once: true });
    if (prev.isConnected && n < 40) requestAnimationFrame(() => renderSceneIcons(el, s));
    return;
  }
  el._icRetry = 0;
  const layer = document.createElement("div"); layer.className = "icon-layer";
  // Size the layer to the ACTUAL displayed (object-fit:contain) image rect — NOT the 16:9 box. The generated
  // images aren't always exactly 16:9 (e.g. 2752x1536 = 1.79), so they're LETTERBOXED inside the box; sizing the
  // layer to the box (the old behaviour) made icons land off their spot vs the fullscreen lightbox (which hugs
  // the image). Now both use the same reference → placement is identical small ↔ fullscreen.
  const bw = prev.clientWidth, bh = prev.clientHeight, iAR = img.naturalWidth / img.naturalHeight, bAR = bw / bh;
  let cw, ch, cl, ct;
  if (iAR > bAR) { cw = bw; ch = bw / iAR; cl = 0; ct = (bh - ch) / 2; }   // fit width → letterbox top/bottom
  else { ch = bh; cw = bh * iAR; ct = 0; cl = (bw - cw) / 2; }             // fit height → pillarbox left/right
  layer.style.left = cl + "px"; layer.style.top = ct + "px"; layer.style.right = "auto"; layer.style.bottom = "auto";
  layer.style.width = cw + "px"; layer.style.height = ch + "px";
  prev.appendChild(layer);
  icons.forEach((ic) => buildIconNode(ic, s, layer, { commit: () => { queueSave(); pvSyncIcons(); }, redraw: () => renderSceneIcons(el, s) }));
}

// ERASE / FILL: paint a mask over the scene image, then remove (empty prompt) or generatively fill it (local
// SD inpainting on the GPU). The result is saved as a NEW image version.
function openInpaint(el, s) {
  const prev = el.querySelector(".img-preview"); if (!prev) return;
  const img = prev.querySelector("img");
  if (!img || !img.complete || !img.naturalWidth) { toastErr("Generate an image first."); return; }
  if (prev.querySelector(".inpaint-ov")) { prev.querySelector(".inpaint-ov").remove(); return; }   // toggle
  const ov = document.createElement("div"); ov.className = "inpaint-ov";
  const cv = document.createElement("canvas"); cv.className = "inpaint-cv"; ov.appendChild(cv);
  ov.insertAdjacentHTML("beforeend",
    '<div class="inpaint-bar"><span class="ib-lbl">Brush</span>' +
    '<input type="range" class="ib-size" min="8" max="140" value="46">' +
    '<button type="button" class="ib-clear ghost">Clear</button>' +
    '<div class="ib-engine" title="Local = free, on your GPU. Cloud = Kie Ideogram (better on realistic photos, costs credits)">' +
      '<button type="button" class="ibe-opt active" data-eng="local">Local</button>' +
      '<button type="button" class="ibe-opt" data-eng="cloud">Cloud</button></div>' +
    '<button type="button" class="ib-go primary">Erase</button>' +
    '<button type="button" class="ib-x ghost" title="Close">✕</button></div>');
  prev.appendChild(ov);
  const ctx = cv.getContext("2d");
  const sizeCanvas = () => {
    const r = img.getBoundingClientRect(), pr = prev.getBoundingClientRect();
    cv.style.left = (r.left - pr.left) + "px"; cv.style.top = (r.top - pr.top) + "px";
    cv.style.width = r.width + "px"; cv.style.height = r.height + "px";
    if (cv.width !== Math.round(r.width) || cv.height !== Math.round(r.height)) { cv.width = Math.round(r.width); cv.height = Math.round(r.height); }
  };
  sizeCanvas();
  let brush = 46, drawing = false;
  ov.querySelector(".ib-size").addEventListener("input", e => brush = +e.target.value);
  const at = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
  const dab = (x, y) => { ctx.fillStyle = "rgba(255,45,95,0.5)"; ctx.beginPath(); ctx.arc(x, y, brush / 2, 0, 7); ctx.fill(); };
  cv.addEventListener("pointerdown", e => { e.preventDefault(); e.stopPropagation(); drawing = true; const [x, y] = at(e); dab(x, y); });
  cv.addEventListener("pointermove", e => { if (drawing) { const [x, y] = at(e); dab(x, y); } });
  window.addEventListener("pointerup", () => drawing = false);
  ov.querySelector(".inpaint-bar").addEventListener("pointerdown", e => e.stopPropagation());
  ov.querySelector(".ib-x").addEventListener("click", () => ov.remove());
  ov.querySelector(".ib-clear").addEventListener("click", () => ctx.clearRect(0, 0, cv.width, cv.height));
  let engine = "local";
  ov.querySelectorAll(".ibe-opt").forEach(b => b.addEventListener("click", () => {
    engine = b.dataset.eng;
    ov.querySelectorAll(".ibe-opt").forEach(x => x.classList.toggle("active", x === b));
  }));
  ov.querySelector(".ib-go").addEventListener("click", async (ev) => {
    const md = ctx.getImageData(0, 0, cv.width, cv.height).data;
    const ex = document.createElement("canvas"); ex.width = cv.width; ex.height = cv.height;
    const exc = ex.getContext("2d"); const ed = exc.createImageData(cv.width, cv.height); let any = false;
    for (let i = 0; i < md.length; i += 4) { const on = md[i + 3] > 10; if (on) any = true; ed.data[i] = ed.data[i + 1] = ed.data[i + 2] = on ? 255 : 0; ed.data[i + 3] = 255; }
    if (!any) { toastErr("Paint over an area first."); return; }
    exc.putImageData(ed, 0, 0);
    const mask = ex.toDataURL("image/png");
    const btn = ev.currentTarget; setBusy(btn, true); btn.textContent = "Erasing…";
    try {
      const r = await api.inpaint(PROJECT, s.id, mask, "", engine);
      if (r.error) { toastErr(r.error); setBusy(btn, false); btn.textContent = "Erase"; return; }
      const poll = async () => {
        let st; try { st = await api.inpaintJob(r.job); } catch (e) { setTimeout(poll, 1500); return; }
        if (st.status === "done") { toast("Erased — new version added", "ok"); ov.remove(); DOC = await api.get(PROJECT); renderScenes(); renderVideos(); return; }
        if (st.status === "error") { toastErr("Failed: " + (st.error || "")); setBusy(btn, false); btn.textContent = "Erase"; return; }
        btn.textContent = st.step || "Erasing…"; setTimeout(poll, 1200);
      };
      poll();
    } catch (e) { toastErr("Erase failed"); setBusy(btn, false); btn.textContent = "Erase"; }
  });
}

function renderScenes() {
  const wrap = $("#scenesList");
  // Full rebuild momentarily collapses the list → the browser clamps scroll to the top. Preserve the
  // scroll position (only on the Scenes tab) so a background generate/poll re-render doesn't yank the
  // page to the top mid-work. rAF fires after this synchronous rebuild finishes.
  const _sy = window.scrollY;
  if (_sy > 0 && document.body.classList.contains("tab-scenes")) requestAnimationFrame(() => window.scrollTo(0, _sy));
  wrap.innerHTML = "";
  const empty = !DOC || !DOC.scenes.length;
  $("#scenesEmpty").hidden = !empty;
  updateSceneCounts();
  if (empty) return;
  const tpl = $("#sceneTpl");
  const insertDivider = (afterId) => {
    const d = document.createElement("div");
    d.className = "insert-divider";
    const b = document.createElement("button");
    b.className = "insert-btn ghost"; b.textContent = "+ Add scene here";
    b.addEventListener("click", async () => { await flushSave(); pushUndo("insert scene"); DOC = await api.insertScene(PROJECT, afterId); renderScenes(); });   // flush pending vo/prompt edits FIRST so the insert+renumber can't race them onto shifted scenes
    d.appendChild(b); wrap.appendChild(d);
  };
  insertDivider(0);
  for (const s of DOC.scenes) {
    if (hideApproved && s.approved) continue;   // toggle: hide approved scenes
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = s.id;
    if (s.approved) el.classList.add("approved");
    if (_flashApprove === s.id) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); _flashApprove = null; }
    $(".scene-num", el).textContent = `#${s.id}`;
    // (testimonial badge is overlaid on the scene IMAGE top-left below, after the image renders)
    $(".scene-caption", el).textContent = trunc(s.vo, 90);
    const noteBtn = $(".scene-note", el);
    if (noteBtn) {
      noteBtn.classList.toggle("has-note", !!(s.note && s.note.trim()));   // filled dot when a note exists
      noteBtn.addEventListener("click", () => openNoteModal(s));
    }
    const selBtn = $(".scene-sel", el);
    if (selBtn) {
      if (isSelected(s.id)) { selBtn.classList.add("on"); el.classList.add("sel-on"); }
      selBtn.addEventListener("click", (e) => { e.stopPropagation(); toggleSelect(s.id, e.shiftKey); });
    }
    $(".scene-del", el).addEventListener("click", async () => {
      if (!(await confirmDialog(`Delete scene #${s.id}? Its image and video will be removed.`, { title: "Delete Scene", okText: "Delete" }))) return;
      await flushSave();   // commit pending edits before the delete+renumber (avoid a save race shifting scenes)
      pushUndo("delete scene");
      el.classList.add("removing");                       // fade + shrink out before the list re-renders
      await new Promise(r => setTimeout(r, 240));
      DOC = await api.deleteScene(PROJECT, s.id); renderScenes(); renderVideos();
    });
    // drag-to-reorder (handle in the scene-head)
    const handle = $(".drag-handle", el);
    if (handle) {
      handle.addEventListener("dragstart", (e) => {
        DRAG_SID = s.id; el.classList.add("dragging"); e.dataTransfer.effectAllowed = "move";
        try { e.dataTransfer.setData("text/plain", String(s.id)); e.dataTransfer.setDragImage(el, 24, 18); } catch (err) {}
      });
      handle.addEventListener("dragend", () => { el.classList.remove("dragging"); clearDrop(); DRAG_SID = null; });
    }
    el.addEventListener("dragover", (e) => {
      if (DRAG_SID == null || DRAG_SID === s.id) return;
      e.preventDefault();
      const r = el.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      el.classList.toggle("drop-after", after); el.classList.toggle("drop-before", !after);
    });
    el.addEventListener("dragleave", () => el.classList.remove("drop-before", "drop-after"));
    el.addEventListener("drop", async (e) => {
      if (DRAG_SID == null || DRAG_SID === s.id) return;
      e.preventDefault();
      const r = el.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      el.classList.remove("drop-before", "drop-after");
      await reorderScene(DRAG_SID, s.id, after);
    });
    $(".vo", el).value = s.vo || "";
    $(".prompt", el).value = s.prompt || "";
    showVoTr(el, s.vo_tr || "");                    // faint Turkish line under the sentence (if any)
    requestAnimationFrame(() => autoGrowVo($(".vo", el)));
    const trBtn = el.querySelector(".vo-tr-btn");
    if (trBtn) trBtn.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); translateSceneVo(s, el, trBtn, true); });
    const trDiv = el.querySelector(".vo-tr");       // reading/selecting the faint line shouldn't focus the textarea
    if (trDiv) { trDiv.addEventListener("mousedown", ev => ev.stopPropagation()); trDiv.addEventListener("click", ev => ev.stopPropagation()); }

    // style buttons
    $$(".style-btn", el).forEach(b => {
      b.classList.toggle("sel", s.style === b.dataset.style);
      b.addEventListener("click", () => {
        s.style = (s.style === b.dataset.style) ? null : b.dataset.style;
        $$(".style-btn", el).forEach(x => x.classList.toggle("sel", x.dataset.style === s.style));
        // style is a separate layer applied at image generation — changing it does NOT require re-generating
        // the prompt, so no "needs-regen" nudge. Just generate the image with the new style.
        queueSave();
      });
    });
    // Prompt-mode toggle — 3 states cycle: OFF (full auto) → RAW ("My prompt") → PURE (only prompt + camera).
    const castBtn = $(".cast-toggle", el);
    const applyMode = () => {
      castBtn.classList.toggle("on", !!s.no_cast && !s.pure);   // RAW
      castBtn.classList.toggle("pure", !!s.pure);               // PURE
      castBtn.title = s.pure
        ? "PURE — sends ONLY your prompt + the camera framing. No style, no cast, no audience, and NO reference images at all."
        : s.no_cast
          ? "My prompt (raw) — your exact prompt + camera + your In-scene cast + any references you attached (no style / audience / auto-translate)."
          : "Auto — the full pipeline (style, camera, cast, audience, references) is applied.";
    };
    applyMode();
    castBtn.addEventListener("click", () => {
      // write onto the LIVE scene object (a reload can swap DOC.scenes → the closure's `s` could be an orphan
      // whose flag would never persist), then save IMMEDIATELY (not debounced) so the mode can't silently revert.
      const live = ((DOC && DOC.scenes) || []).find(x => (s.uid && x.uid === s.uid) || x.id === s.id) || s;
      if (!live.no_cast && !live.pure) { live.no_cast = true; live.pure = false; }        // OFF → RAW
      else if (live.no_cast && !live.pure) { live.no_cast = false; live.pure = true; }    // RAW → PURE
      else { live.no_cast = false; live.pure = false; }                                   // PURE → OFF
      s.no_cast = live.no_cast; s.pure = live.pure;   // keep the closure copy in sync so applyMode() reads the new state
      applyMode();
      flushSave();
    });
    // split (diptych) toggle — director suggests (green pulse) → user turns on/off
    const splitBtn = $(".split-toggle", el);
    if (splitBtn) {
      splitBtn.classList.toggle("on", !!s.split);
      splitBtn.classList.toggle("suggest", !!s.split_suggested);   // director chose split here → pulse until the user decides
      splitBtn.addEventListener("click", () => {
        s.split = !s.split;
        s.split_suggested = false;                                 // user decided → stop the pulse
        s._regenDone = false;                                      // toggle changed → re-arm the "regenerate" hint
        splitBtn.classList.toggle("on", s.split);
        splitBtn.classList.remove("suggest");
        updateSplitRegenHint(el, s);                               // split toggled → prompt may now mismatch → hint (or clear)
        queueSave();
      });
    }
    // testimonial (social-proof grid) toggle + how-many selector
    const testiBtn = $(".testi-toggle", el);
    const testiN = $(".testi-n", el);
    if (testiBtn) {
      const applyTesti = () => {
        testiBtn.classList.toggle("on", !!s.testimonial);
        if (testiN) {
          testiN.hidden = !s.testimonial;
          testiN.value = String(s.testimonial_n || 8);
        }
      };
      applyTesti();
      testiBtn.addEventListener("click", () => {
        s.testimonial = !s.testimonial;
        if (s.testimonial && !s.testimonial_n) s.testimonial_n = 8;
        s._regenDone = false;
        applyTesti();
        queueSave();
      });
      if (testiN) testiN.addEventListener("change", () => {
        s.testimonial_n = parseInt(testiN.value, 10) || 8;
        queueSave();
      });
    }
    // model selector (per scene) + camera framing selector
    buildModelDropdown($(".model-dd", el), s);
    buildCameraDropdown($(".camera-dd", el), s);
    buildTransitionDropdown($(".transition-dd", el), s);

    // current image version
    const im = s.image, vs = im.versions || [];
    let cur = (im.current == null ? vs.length - 1 : im.current);
    const curFile = (vs.length && cur >= 0 && cur < vs.length) ? vs[cur] : null;
    const imgPrev = $(".img-preview", el);
    imgPrev.dataset.file = curFile || "";
    const _tcd = s.tcard_id ? (((DOC && DOC.testimonial_cards) || []).find(c => c.id === s.tcard_id)) : null;
    imgPrev.classList.toggle("is-tcard", !!s.tcard_id && (!_tcd || _tcd.type !== "video"));   // WRITTEN cards aren't 16:9 → show the WHOLE card (contain); a VIDEO testimonial's still is a normal photo → fill (no white bars)
    if (curFile) {
      imgPrev.innerHTML = "";
      const src = thumbUrl(curFile, s.image.taskId);   // light preview in the card; full 2K opens on click
      const img = document.createElement("img");
      img.src = src;
      // Only show the dark loading skeleton for an image that isn't already cached/decoded.
      // Otherwise re-rendering after approve/unapprove flashes the SAME frame black for ~0.5s
      // for no reason — the image is identical and already in the browser cache.
      if (img.complete && img.naturalWidth) {
        imgPrev.classList.remove("img-loading");
      } else {
        imgPrev.classList.add("img-loading");                       // shimmer skeleton until it loads
        img.addEventListener("load", () => imgPrev.classList.remove("img-loading"));
        img.addEventListener("error", () => imgPrev.classList.remove("img-loading"));
      }
      img.addEventListener("click", () => openImageLightbox(s));   // click = view large
      if (_flashImg === s.id) { img.classList.add("img-swap"); _flashImg = null; }   // crossfade in on a version switch
      imgPrev.appendChild(img);
      // overlay actions (top-right of the image)
      const ov = document.createElement("div");
      ov.className = "img-actions";
      const approvedThis = s.approved && im.approved_version === cur;
      const bApprove = document.createElement("button");
      bApprove.className = "ia approve" + (approvedThis ? " on" : "");
      bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
      bApprove.textContent = "✓";
      const bChange = document.createElement("button");
      bChange.className = "ia change"; bChange.title = "Change (regenerate)"; bChange.textContent = "↻";
      const bRemove = document.createElement("button");
      bRemove.className = "ia remove"; bRemove.title = "Remove"; bRemove.innerHTML = TRASH_SVG;
      bApprove.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (s._approving) return;                                    // a request is already in flight → ignore the extra clicks (kills the "20 toasts" pileup while generation holds the server lock)
        s._approving = true;
        const willApprove = !bApprove.classList.contains("on");
        // OPTIMISTIC: reflect the new state + toast INSTANTLY so it feels immediate even when a batch generation
        // is holding the server lock; a long _appLock keeps a poll from reverting it during the wait.
        bApprove.classList.toggle("on", willApprove);
        s.approved = willApprove; if (willApprove && s.image) s.image.approved_version = cur;
        s._appLock = Date.now() + 45000;
        buildSceneJump();
        if (willApprove) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
        try {
          await flushSave();                                         // commit any pending prompt/VO edit first
          adoptDocInPlace(await api.approve(PROJECT, s.id, willApprove));   // merge in place → scene-card edit closures (camera/prompt/vo) stay LIVE after approve
          s._appLock = Date.now() + 8000;
          if (hideApproved && s.approved) renderScenes();            // hide-approved on → the card should vanish
          else patchApprove(el, s, cur, bApprove);                   // otherwise patch in place — no refs/OST flicker
          buildSceneJump(); renderVideos();
        } catch (_) {
          s.approved = !willApprove; bApprove.classList.toggle("on", !willApprove); s._appLock = 0;   // revert on failure
          buildSceneJump(); toast(`Could not ${willApprove ? "approve" : "unapprove"} Scene ${s.id} - try again.`, "err");
        } finally { s._approving = false; }
      });
      bChange.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); });
      bRemove.title = "Delete this version";
      bRemove.addEventListener("click", async (e) => { e.stopPropagation(); pushUndo("delete image"); s._appLock = Date.now() + 8000; DOC = await api.deleteVersion(PROJECT, s.id, cur); const _f = DOC.scenes.find(x => x.id === s.id); if (_f) _f._appLock = Date.now() + 8000; toast(`Deleted Image: Scene ${s.id}`, "info"); renderScenes(); renderVideos(); });   // _appLock: a stale in-flight poll must not resurrect the deleted version
      ov.appendChild(bApprove); ov.appendChild(bChange); ov.appendChild(bRemove);
      imgPrev.appendChild(ov);
      // download — same design as the top-right actions, but overlaid on the bottom-right of the image
      const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";
      const bDl = document.createElement("button");
      bDl.className = "ia download"; bDl.title = "Download this image";
      bDl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
      bDl.addEventListener("click", (e) => { e.stopPropagation(); downloadMedia(curFile, `${pad2(s.id)}_${slug(s.vo)}.png`, `Scene ${s.id}`); });
      ovb.appendChild(bDl); imgPrev.appendChild(ovb);
    }
    if (im.status === "generating" || im.status === "queued") { if (!curFile) imgPrev.innerHTML = ""; addGenOverlay(imgPrev, im.status); }
    setBadge($(".img-status", el), im);
    if (s.tcard_id) {   // this scene's image comes from a Testimonial card → badge overlays the image top-LEFT and jumps to that testimonial
      const _lc = ((DOC && DOC.testimonial_cards) || []).find(c => c.id === s.tcard_id);
      const _isVid = !!(_lc && _lc.type === "video");
      const tchip = document.createElement("button"); tchip.type = "button"; tchip.className = "scene-tchip"; tchip.textContent = _isVid ? "Video Testimonial" : "Testimonial";
      tchip.title = "This scene's image comes from a Testimonial — click to open it";
      tchip.addEventListener("click", (e) => { e.stopPropagation(); openTestimonialCard(s.tcard_id); });
      imgPrev.appendChild(tchip);
      if (_isVid) {   // video testimonial → a video-player icon sits on the still (until produced it's the only thing shown)
        const vplay = document.createElement("div"); vplay.className = "scene-vplay"; vplay.title = "Video testimonial (still frame — plays in the render)";
        vplay.innerHTML = '<svg viewBox="0 0 24 24" width="30" height="30" fill="#fff" stroke="none"><path d="M8 5v14l11-7z"/></svg>';
        imgPrev.appendChild(vplay);
      }
    }

    // version nav / edit / download
    const nav = $(".img-nav", el);
    if (vs.length) {
      nav.hidden = false;
      const av = im.approved_version;
      const isApprovedVer = s.approved && av === cur;
      wireVerArrows($(".img-preview", el), s, cur, vs.length);   // arrows + version badge overlay the image
      const editBox = $(".edit-box", el);
      $(".ver-edit", el).onclick = () => { editBox.hidden = !editBox.hidden; };
      { const _fb = $(".ver-fill", el); if (_fb) _fb.onclick = () => openInpaint(el, s); }
      $(".edit-apply", el).onclick = (ev) => {
        const instr = $(".edit-instr", el).value.trim();
        if (!instr) { alert("Type what to change."); return; }
        withBusy(ev.currentTarget, () => editImage(s.id, instr));
      };
    }

    // ---- overlay icons on the image preview (drag to place, handles to size/rotate/flip/delete) ----
    renderSceneIcons(el, s);
    buildIconsPanel($(".icons-menu", el));   // build the grouped/nested panel first, so every .icon-add below is wired
    $$(".icon-add", el).forEach(b => b.onclick = () => {
      if (!(el.querySelector(".img-preview") || {}).dataset || !el.querySelector(".img-preview").dataset.file) { toastErr("Generate an image first."); return; }
      // 2D scenes: the AUTO system never adds icons here, but a MANUAL icon is allowed (user request).
      // inherit the PREVIOUS icon's look: SIZE from the last icon of any type; colour/rotation/flip only from the
      // last icon of the SAME type (so a new icon comes in at the size/colour you last used, not a bare default).
      const _list = s.icons = Array.isArray(s.icons) ? s.icons : [];
      const _same = _list.filter(i => i.type === b.dataset.icon).slice(-1)[0];
      const _last = _list.slice(-1)[0];
      pushUndo("add icon");                           // Undo/Redo can take the icon back out
      _list.push({ type: b.dataset.icon, x: 0.5, y: 0.5,
        size: (_same || _last) ? ((_same || _last).size ?? 1.0) : 1.0,
        rot: _same ? (_same.rot ?? 0) : 0, flip: _same ? !!_same.flip : false, hue: _same ? (_same.hue ?? (_DEF_HUE[b.dataset.icon] || 0)) : (_DEF_HUE[b.dataset.icon] || 0) });
      renderSceneIcons(el, s); queueSave(); pvSyncIcons();
      toast("Icon added — drag it onto the spot.", "info");
    });
    // "Icons" dropdown panel (grouped) — opens below the button; STAYS open while you add several (clicks inside
    // don't close it), closes on an outside click or on the button again.
    const iconsBtn = $(".icons-btn", el), iconsMenu = $(".icons-menu", el);
    if (iconsBtn && iconsMenu) {
      iconsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const willOpen = iconsMenu.hidden;
        $$(".model-menu").forEach(m => m.hidden = true);
        $$(".icons-menu").forEach(m => { if (m !== iconsMenu) { m.hidden = true; const b = m.parentNode.querySelector(".icons-btn"); if (b) b.classList.remove("on"); } });
        iconsMenu.hidden = !willOpen; iconsBtn.classList.toggle("on", willOpen);
      });
    }
    if (!window._iconsDdWired) {   // ONE global outside-click closer for every "Icons" panel (clicks INSIDE keep it open → add several)
      window._iconsDdWired = true;
      document.addEventListener("click", (e) => {
        document.querySelectorAll(".icons-menu:not([hidden])").forEach(m => {
          const b = m.parentNode && m.parentNode.querySelector(".icons-btn");
          if (!m.contains(e.target) && !(b && b.contains(e.target))) { m.hidden = true; if (b) b.classList.remove("on"); }
        });
      });
    }

    $(".prompt", el).addEventListener("input", e => { s.prompt = e.target.value; queueSave(); updateSplitRegenHint(el, s); });
    $(".vo", el).addEventListener("input", e => {
      s.vo = e.target.value; queueSave(); autoGrowVo(e.target);
      // Editing invalidates the old translation (ALL languages) → it clears; click the 🇹🇷 flag to redo.
      // No background auto-retranslate — FR/DE translate ONCE on split, then it's manual like English.
      if (s.vo_tr) { s.vo_tr = ""; showVoTr(el, ""); }
    });
    // ---- on-screen text overlays: section master toggle + N overlay panels ("+") ----
    const redrawOst = () => { drawSceneOst(el, s); queueSave(); };
    const ostField = el.querySelector(".ost-field"), ostOn = $(".ost-on", el),
          ostColl = ostField.querySelector(".ost-collapse"), ostAdd = $(".ost-add", el);
    const forceState = (open) => {                    // guarantees the end state even if a transition stalls
      ostColl.style.transition = "none";
      ostColl.style.height = open ? "auto" : "0px";
      ostColl.style.overflow = open ? "visible" : "hidden";
      void ostColl.offsetHeight;
      ostColl.style.transition = "";
    };
    const animateHeight = (fromH) => {                // smooth stretch to the current content height
      if (!ostOn.checked) return;
      ostColl.style.overflow = "hidden";
      ostColl.style.height = fromH + "px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = ostColl.scrollHeight + "px";
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (ostOn.checked) forceState(true); }, 340);
    };
    const openSection = (animate) => {
      ostField.classList.add("ost-open");
      if (!animate) { forceState(true); return; }
      ostColl.style.overflow = "hidden";
      const h = ostColl.scrollHeight;
      ostColl.style.height = "0px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = h + "px";
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (ostOn.checked) forceState(true); }, 340);
    };
    const closeSection = () => {
      closeAllPops();
      ostColl.style.overflow = "hidden";
      ostColl.style.height = Math.round(ostColl.getBoundingClientRect().height) + "px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = "0px";
      ostField.classList.remove("ost-open");
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (!ostOn.checked) forceState(false); }, 340);
    };
    const ostTpl = $(".ost-panel-tpl", el);   // template is nested in each scene row (scoped lookup)
    const buildPanels = () => {
      const container = $(".ost-panels", el), tpl = ostTpl;
      if (!container || !tpl) return;
      container.innerHTML = "";
      (s.overlays || []).forEach((ov, i) => {
        const panel = tpl.content.firstElementChild.cloneNode(true);
        container.appendChild(panel);
        wireOstPanel(panel, ov, redrawOst, buildPanels);
        const del = panel.querySelector(".ost-del-overlay");
        del.addEventListener("click", () => {         // "-" is always shown, even on the first/only text
          closeAllPops();
          const last = s.overlays.length <= 1;
          const h = panel.offsetHeight;               // collapse this panel to nothing; the auto-height
          panel.style.overflow = "hidden";            // section then shrinks smoothly along with it
          panel.style.height = h + "px";
          panel.style.transition = "height .3s ease, opacity .26s ease, margin .3s ease, padding .3s ease, border-width .3s ease";
          getComputedStyle(panel).height;             // reflow so the collapse animates from h
          panel.style.height = "0px";
          panel.style.opacity = "0";
          panel.style.marginTop = "0px";
          panel.style.paddingTop = "0px";
          panel.style.borderTopWidth = "0px";
          clearTimeout(ostColl._t);
          ostColl._t = setTimeout(() => {
            pushUndo("delete on-screen text");
            if (last) {                               // removing the only text closes the whole section
              s.overlays = [newOverlay()];
              s.ost_on = false; ostOn.checked = false; ostAdd.hidden = true;
              ostField.classList.remove("ost-open");
              forceState(false); buildPanels();
            } else {
              s.overlays.splice(i, 1); buildPanels(); forceState(true);
            }
            redrawOst();
          }, 320);
        });
      });
    };
    buildPanels();
    ostOn.checked = !!s.ost_on;
    ostAdd.hidden = !s.ost_on;
    if (s.ost_on) openSection(false); else ostColl.style.height = "0px";
    ostOn.addEventListener("change", () => {
      s.ost_on = ostOn.checked;
      ostAdd.hidden = !ostOn.checked;
      if (ostOn.checked) openSection(true); else closeSection();
      redrawOst();
    });
    ostAdd.addEventListener("click", () => {
      const fromH = Math.round(ostColl.getBoundingClientRect().height);
      // a NEW on-screen text inherits the LAST text's full look/size/font/values (only the words are blank), so
      // you don't have to re-style it every time.
      const _prev = (s.overlays || [])[s.overlays.length - 1];
      pushUndo("add on-screen text");
      s.overlays.push(_prev ? { ..._prev, onscreen: "" } : newOverlay());
      buildPanels(); animateHeight(fromH); queueSave();
    });
    const gp = $(".gen-prompt", el), gi = $(".gen-img", el);
    const hasPrompt = !!(s.prompt && s.prompt.trim());
    gp.textContent = hasPrompt ? "↻ Re-Generate Prompt" : "✨ Generate Prompt";
    updateSplitRegenHint(el, s);   // pulse if the prompt's split-structure doesn't match the Split toggle
    gp.addEventListener("click", () => stoppable(gp, (sig) => genPrompts([s.id], sig)));
    gi.addEventListener("click", () => withBusy(gi, () => genImages([s.id])));
    const pv = $(".preview-prompt", el);
    if (pv) pv.addEventListener("click", () => showPromptPreview(s.id));
    // keep the image button spinning while its image is still generating
    if (s.image.status === "generating") setBusy(gi, true);

    // Reference thumbnails are served from the local copy on disk — pulling every
    // full-size ref off Cloudinary on each render is what burned the bandwidth quota.
    // per-scene reference images (up to 14)
    const refsList = $(".scene-refs-list", el), refInput = $(".ref-input", el);
    const refSceneBtn = $(".ref-scene-btn", el), refSceneMenu = $(".ref-scene-menu", el);
    const castDD = $(".cast-dd", el), castPickBtn = $(".cast-btn", el), castMenu = $(".cast-menu", el);
    const ingDD = $(".ing-dd", el), ingPickBtn = $(".ing-btn", el), ingMenu = $(".ing-menu", el);
    function drawRefs() {
      refsList.innerHTML = "";
      (s.refs || []).forEach((url, i) => {
        const chip = document.createElement("div");
        chip.className = "ref-thumb";
        const im = document.createElement("img"); setRefImg(im, url);
        chip.appendChild(im);
        const m = /sceneref-(\d+)-/.exec(url);          // ref copied from another scene → badge it
        if (m) { const b = document.createElement("span"); b.className = "ref-scene-badge"; b.textContent = "Scene " + m[1]; chip.appendChild(b); }
        if (/char_/.test(url) || /sceneref-/.test(url)) {   // a character OR reference-scene image → outfit-lock toggle
          const locked = !(s.ref_free || []).includes(url);
          const lk = document.createElement("button"); lk.type = "button"; lk.className = "ref-lock" + (locked ? " on" : "");
          lk.textContent = "👕";
          const tip = on => on ? "Outfit LOCKED: same clothes & hair as the reference. Click → change the outfit to fit this scene."
                               : "Outfit FREE: different clothes for this scene (hair may stay). Click to lock the same outfit.";
          lk.title = tip(locked);
          lk.addEventListener("click", async (e) => {
            e.stopPropagation();
            s.ref_free = s.ref_free || [];
            const nowLocked = s.ref_free.includes(url);   // was free → will become locked
            s.ref_free = nowLocked ? s.ref_free.filter(x => x !== url) : [...s.ref_free, url];
            lk.classList.toggle("on"); lk.title = tip(lk.classList.contains("on"));
            const r = await api.setSceneRefLock(PROJECT, s.id, url, nowLocked);   // dedicated endpoint (ref_free isn't in the full-save whitelist)
            if (r && r.ref_free) s.ref_free = r.ref_free;
          });
          chip.appendChild(lk);
        }
        const x = document.createElement("button"); x.className = "ref-x"; x.textContent = "×"; x.title = "Remove";
        x.addEventListener("click", async () => {
          const oldH = refsList.getBoundingClientRect().height;   // height before removal
          s.refs.splice(i, 1);
          drawRefs();
          animateRefsHeight(refsList, oldH);                      // smooth downward shrink of the frame
          const r = await api.deleteSceneRef(PROJECT, s.id, i);   // dedicated endpoint (refs isn't in the full-save whitelist → can't be clobbered)
          if (r && r.refs) { s.refs = r.refs; if (r.ref_free) s.ref_free = r.ref_free; }
        });
        chip.appendChild(x); refsList.appendChild(chip);
      });
      if ((s.refs || []).length < 14) {                 // upload-from-PC placeholder tile (same size as the thumbs)
        const add = document.createElement("button");
        add.type = "button"; add.className = "ref-thumb ref-add-tile"; add.title = "Upload a reference image from your computer";
        add.innerHTML = "<span>+</span>";
        add.addEventListener("click", () => refInput.click());
        refsList.appendChild(add);
      }
      requestAnimationFrame(() => fitRefs(refsList));   // size thumbnails to fill the area (see fitRefs)
    }
    drawRefs();
    refInput.addEventListener("change", async (e) => {
      const files = [...e.target.files]; e.target.value = "";
      const oldH = refsList.getBoundingClientRect().height;   // height before the new thumbnail(s)
      for (const f of files) {
        if ((s.refs || []).length >= 14) { alert("Max 14 reference images per scene."); break; }
        setStatus("uploading reference…");
        const r = await api.uploadSceneRef(PROJECT, s.id, f);
        if (r.error) { alert(r.error); break; }
        s.refs = r.refs;
      }
      setStatus(""); drawRefs();
      animateRefsHeight(refsList, oldH);   // smooth downward stretch as the thumbnails appear
    });
    // Reference Scene dropdown — reuse ANOTHER scene's approved image as a reference (same person/place)
    if (refSceneBtn) refSceneBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !refSceneMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      refSceneMenu.innerHTML = "";
      const opts = (DOC.scenes || []).filter(o => o.id !== s.id && o.image && (o.image.approved_file || o.image.file));
      if (!opts.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No other scene has an image yet"; refSceneMenu.appendChild(d); }
      opts.forEach(o => {
        const row = document.createElement("div"); row.className = "ref-scene-opt";
        const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; th.src = refThumb(o.image.approved_file || o.image.file);   // small cached thumb (~17KB, not the 5MB full image) → menu opens instantly + scrolls smoothly even with 40 scenes
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = `Scene ${o.id}`;
        row.append(th, lbl);
        row.addEventListener("click", async () => {
          refSceneMenu.hidden = true;
          // NEW behaviour: drop Scene o.id's generated image DIRECTLY into THIS scene (not as a reference).
          const okc = await confirmDialog(
            `This replaces Scene ${s.id}'s image with the one generated in Scene ${o.id}.`,
            { title: `Use Scene ${o.id}'s Image?`, okText: "Place Image", danger: false });
          if (!okc) return;
          pushUndo(`use Scene ${o.id}'s image`);
          const r = await api.copyImage(PROJECT, s.id, o.id);
          if (r.error) { alert(r.error); return; }
          if (r.doc) { const _sc = DOC.script; DOC = r.doc; if (_sc) DOC.script = _sc; }
          renderScenes(); renderVideos();
          toast(`Placed Scene ${o.id}'s image into Scene ${s.id}`, "ok");
        });
        refSceneMenu.appendChild(row);
      });
      refSceneMenu.hidden = false;
    });
    // Cast dropdown — pick a named character (from Target Audience → Cast). Selecting one drops THAT
    // character's image straight into this scene's reference images (as a thumbnail), exactly like
    // adding a reference. The Cast button itself never changes — it always reads "🎭 Cast ▾".
    const prodDD = $(".product-dd", el), prodBtn = $(".product-btn", el), prodMenu = $(".product-menu", el);
    if (prodBtn) prodBtn.addEventListener("click", (e) => {   // pick WHICH product image (1-bottle / 3-pack / 6-pack) appears in this scene
      e.stopPropagation();
      const wasOpen = !prodMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      prodMenu.innerHTML = "";
      const urls = (DOC && DOC.product && DOC.product.urls) || [];
      const pnames = (DOC && DOC.product && DOC.product.names) || {};
      const mkRow = (label, url, thumbUrl) => {
        const row = document.createElement("div"); row.dataset.url = url || ""; row.className = "ref-scene-opt cast-opt" + ((s.product || "") === url ? " sel" : "");
        if (thumbUrl) { const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; setRefImg(th, thumbUrl); row.appendChild(th); }
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = label; row.appendChild(lbl);
        const tick = document.createElement("span"); tick.className = "cast-opt-tick"; tick.textContent = ((s.product || "") === url) ? "✓" : ""; row.appendChild(tick);   // ✓ on the selected bottle, like Cast/Ingredients
        row.addEventListener("click", (ev) => {
          ev.stopPropagation();                       // keep the menu open (close only on an outside click), like Cast/Ingredients
          pushUndo(url ? "set product" : "remove product");   // registers the change → Undo lights up + gives clear feedback
          const cs = canonScene(s);
          cs.product = url; prodBtn.classList.toggle("on", !!url); prodBtn.classList.remove("suggest");
          setStatus("saving…"); _persist().then(() => { setStatus("saved"); setTimeout(() => setStatus(""), 1000); });   // visible save (immediate) so a None can't be lost before generate
          toast(url ? "Product set for this scene" : "Product removed from this scene", "info");
          drawSceneProduct($(".scene-product", el), cs);   // reflect the choice as a chip above the sentence
          prodMenu.querySelectorAll(".ref-scene-opt").forEach(r => {   // single-select → move the ✓
            const on = (s.product || "") === (r.dataset.url || "");
            r.classList.toggle("sel", on);
            const t = r.querySelector(".cast-opt-tick"); if (t) t.textContent = on ? "✓" : "";
          });
        });
        return row;
      };
      prodMenu.appendChild(mkRow("None", "", null));
      urls.forEach((u, i) => prodMenu.appendChild(mkRow((pnames[u] || "").trim() || `Product ${i + 1}`, u, u)));
      prodMenu.hidden = false;
    });
    function updateCastBtn() {   // visibility: hide Cast when no roster, hide Product when no product image
      const chars = (DOC && DOC.characters) || [];
      if (castDD) castDD.hidden = !chars.length;
      if (ingDD) ingDD.hidden = !((DOC && DOC.ingredients || []).length);   // hide Ingredients ▾ when no ingredient roster
      const hasProduct = !!((DOC && DOC.product && (DOC.product.urls || []).length));
      if (prodDD) prodDD.hidden = !hasProduct;
      if (prodBtn) {
        prodBtn.classList.toggle("on", !!s.product);
        // director flagged this shot as a product shot AND the user hasn't chosen yet → pulse the button as a hint
        prodBtn.classList.toggle("suggest", hasProduct && !!s.product_suggested && s.product == null);
      }
    }
    updateCastBtn();
    el._updateCast = updateCastBtn;   // refreshAllSceneCast() re-checks visibility after a character/product is added/removed
    // Cast ▾ — choose WHICH roster characters appear in THIS scene (their reference face is locked to the
    // image). Toggles membership in s.cast with a ✓; the menu stays open so you can flip several, and the
    // "In scene:" chips update live. This is what lets you swap e.g. Dr Carbonell → Dr Stefan Müller for one scene.
    if (castPickBtn) castPickBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !castMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      castMenu.innerHTML = "";
      const chars = (DOC && DOC.characters) || [];
      if (!chars.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No cast — add characters in Target Audience"; castMenu.appendChild(d); }
      chars.forEach(c => {
        const inCast = (s.cast || []).includes(c.id);
        const row = document.createElement("div"); row.className = "ref-scene-opt cast-opt" + (inCast ? " sel" : "");
        const u = charUrls(c)[0];
        if (u) { const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; setRefImg(th, u); row.appendChild(th); }
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = c.name; row.appendChild(lbl);
        const tick = document.createElement("span"); tick.className = "cast-opt-tick"; tick.textContent = inCast ? "✓" : ""; row.appendChild(tick);
        row.addEventListener("click", (ev) => {
          ev.stopPropagation();
          s.cast = s.cast || [];
          const cont = $(".scene-cast", el);
          if (s.cast.includes(c.id)) sceneCastRemove(cont, s, c.id);   // smooth exit
          else sceneCastAdd(cont, s, c);                               // smooth entry
          const nowIn = s.cast.includes(c.id);
          row.classList.toggle("sel", nowIn); tick.textContent = nowIn ? "✓" : "";   // reflect without closing → flip several at once
        });
        castMenu.appendChild(row);
      });
      castMenu.hidden = false;
    });
    // Ingredients ▾ — choose which product ingredients appear in THIS scene (their reference image is used).
    if (ingPickBtn) ingPickBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !ingMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      ingMenu.innerHTML = "";
      const ings = (DOC && DOC.ingredients) || [];
      if (!ings.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No ingredients — add them in Settings → Ingredients"; ingMenu.appendChild(d); }
      ings.forEach(c => {
        const inIng = (s.ingredients || []).includes(c.id);
        const row = document.createElement("div"); row.className = "ref-scene-opt cast-opt" + (inIng ? " sel" : "");
        const u = (c.urls || [])[0];
        if (u) { const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; setRefImg(th, u); row.appendChild(th); }
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = c.name; row.appendChild(lbl);
        const tick = document.createElement("span"); tick.className = "cast-opt-tick"; tick.textContent = inIng ? "✓" : ""; row.appendChild(tick);
        row.addEventListener("click", (ev) => {
          ev.stopPropagation();
          s.ingredients = s.ingredients || [];
          const cont = $(".scene-ing", el);
          if (s.ingredients.includes(c.id)) sceneIngRemove(cont, s, c.id);
          else sceneIngAdd(cont, s, c);
          const nowIn = s.ingredients.includes(c.id);
          row.classList.toggle("sel", nowIn); tick.textContent = nowIn ? "✓" : "";
        });
        ingMenu.appendChild(row);
      });
      ingMenu.hidden = false;
    });
    drawSceneCast($(".scene-cast", el), s);   // (kept only to hide the old "In scene:" row)
    drawSceneIng($(".scene-ing", el), s);     // ingredient chips for this scene
    drawSceneProduct($(".scene-product", el), s);   // product chip (if a product is chosen for this scene)
    drawSceneCont($(".scene-cont", el), s);         // continuity chip (if this scene is linked to continue an earlier one)
    wrap.appendChild(el);
    drawSceneOst(el, s);   // draw AFTER the card is in the DOM so the preview has a REAL width → stable scale (a detached card reads width 0 and used a wrong fallback, shrinking/enlarging the text on re-render)
    renderSceneIcons(el, s);   // SAME reason: a detached card is isConnected=false, so the earlier (pre-append) call bailed with no retry and placed icons never drew — redraw now that the card is live
    insertDivider(s.id);
  }
  buildSceneJump();
  pruneSelection(); updateSelBar();   // keep multi-select in sync after any list rebuild
}

// ---------- multi-scene selection: checkbox per card → batch Generate Prompts / Images / Delete ----------
const SELECTED = new Set();     // selected scene ids (kept as strings, dataset-friendly)
let _lastSelId = null;          // anchor for Shift-click range selection
let _selFirstId = null;         // the FIRST scene picked this selection → anchor for "Select All below"
function isSelected(id) { return SELECTED.has(String(id)); }
function pruneSelection() {      // drop ids that no longer exist (after a delete/renumber)
  const live = new Set((DOC?.scenes || []).map(s => String(s.id)));
  [...SELECTED].forEach(id => { if (!live.has(id)) SELECTED.delete(id); });
}
function syncSelVisuals() {
  $$("#scenesList .scene-row").forEach(row => {
    const on = isSelected(row.dataset.id);
    row.classList.toggle("sel-on", on);
    const b = row.querySelector(".scene-sel"); if (b) b.classList.toggle("on", on);
  });
}
function _syncHdrH() {   // --hdr-h = where the sticky header ENDS in the viewport, so the selection bar sits fully below it
  const h = document.querySelector("header");
  if (!h) return;
  const tb = document.body.classList.contains("desktop") ? 34 : 0;   // desktop app has a 34px custom titlebar the header sticks under
  document.documentElement.style.setProperty("--hdr-h", Math.round(tb + h.getBoundingClientRect().height) + "px");
}
window.addEventListener("resize", _syncHdrH);
function updateSelBar() {
  const bar = $("#selBar"); if (!bar) return;
  const n = SELECTED.size;
  const c = $("#selCount"); if (c) c.textContent = n + (n === 1 ? " scene selected" : " scenes selected");
  const appr = $("#selApprove");   // label toggles: all image-bearing selected already approved -> "Unapprove All"
  if (appr) {
    const withImg = (DOC?.scenes || []).filter(s => isSelected(s.id) && s.image && (s.image.versions || []).length);
    const allAppr = withImg.length && withImg.every(s => s.approved);
    appr.textContent = allAppr ? "✓ Unapprove All" : "✓ Approve All";
    appr.classList.toggle("on", !!allAppr);
  }
  if (n) {                                   // show (slide in)
    _syncHdrH();                             // measure the visible header first so the bar sticks fully below it
    bar._closing = false; bar.classList.remove("sel-closing");
    if (bar.hidden) {
      bar.hidden = false; bar.classList.add("sel-opening");
      bar.addEventListener("animationend", () => bar.classList.remove("sel-opening"), { once: true });
    }
  } else if (!bar.hidden && !bar._closing) {  // hide (slide out, THEN remove from layout)
    bar._closing = true; bar.classList.remove("sel-opening"); bar.classList.add("sel-closing");
    bar.addEventListener("animationend", () => {
      if (bar._closing) { bar.hidden = true; bar.classList.remove("sel-closing"); bar._closing = false; }
    }, { once: true });
  }
}
function toggleSelect(id, shift) {
  if (!SELECTED.size) _selFirstId = String(id);   // starting a fresh selection → remember the first pick
  const ids = (DOC?.scenes || []).map(s => String(s.id));
  const curIdx = ids.indexOf(String(id));
  if (shift && _lastSelId != null && ids.indexOf(String(_lastSelId)) >= 0 && curIdx >= 0) {
    const a = ids.indexOf(String(_lastSelId)), lo = Math.min(a, curIdx), hi = Math.max(a, curIdx);
    const turnOn = !isSelected(id);                 // extend the range in the direction the click intends
    for (let i = lo; i <= hi; i++) { if (turnOn) SELECTED.add(ids[i]); else SELECTED.delete(ids[i]); }
  } else {
    if (isSelected(id)) SELECTED.delete(String(id)); else SELECTED.add(String(id));
  }
  _lastSelId = id;
  syncSelVisuals(); updateSelBar();
}
function clearSelection() { SELECTED.clear(); _lastSelId = null; _selFirstId = null; syncSelVisuals(); updateSelBar(); }
// Select the first-picked scene and EVERY scene below it (never the ones above).
function selectAllBelow() {
  const ids = (DOC?.scenes || []).map(s => String(s.id));
  if (!ids.length || !SELECTED.size) return;
  let anchor = ids.indexOf(String(_selFirstId));
  if (anchor < 0) anchor = Math.min(...[...SELECTED].map(id => ids.indexOf(String(id))).filter(i => i >= 0));   // fallback: topmost selected
  if (anchor < 0) return;
  for (let i = anchor; i < ids.length; i++) SELECTED.add(ids[i]);
  _lastSelId = ids[ids.length - 1];
  syncSelVisuals(); updateSelBar();
}

// ---- Videos tab multi-select (mirrors the Scenes tab; its OWN set + bar so the two tabs never clash) ----
const VSEL = new Set();
let _vLastSel = null, _vFirstId = null;
const isVSel = (id) => VSEL.has(String(id));
const _vApprovedIds = () => (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).map(s => String(s.id));
function syncVSelVisuals() {
  $$("#videosList .video-row").forEach(row => {
    const on = isVSel(row.dataset.id);
    row.classList.toggle("sel-on", on);
    const b = row.querySelector(".scene-sel"); if (b) b.classList.toggle("on", on);
  });
}
function updateVidSelBar() {
  const bar = $("#vidSelBar"); if (!bar) return;
  const n = VSEL.size;
  const c = $("#vidSelCount"); if (c) c.textContent = n + (n === 1 ? " scene selected" : " scenes selected");
  // camera-lock toggle label: if EVERY selected scene is already free -> the button will LOCK; else it will FREE
  const cf = $("#vidSelCamFree");
  if (cf && n) {
    const byId = new Map((DOC?.scenes || []).map(s => [s.id, s]));
    const sel = [...VSEL].map(Number).map(id => byId.get(id)).filter(Boolean);
    const allFree = sel.length && sel.every(s => s.video_cam_lock === false);
    cf.textContent = allFree ? "🔒 Lock Camera" : "🎥 Free Camera";
  }
  const appr = $("#vidSelApprove");   // label toggles like the Scenes bar: all ready selected videos approved -> "Unapprove All"
  if (appr && n) {
    const byId = new Map((DOC?.scenes || []).map(s => [s.id, s]));
    const ready = [...VSEL].map(Number).map(id => byId.get(id)).filter(s => s && s.video && s.video.status === "ready" && s.video.file);
    const allAppr = ready.length && ready.every(s => s.video.approved);
    appr.textContent = allAppr ? "✓ Unapprove All" : "✓ Approve All";
    appr.classList.toggle("on", !!allAppr);
  }
  if (n) {
    _syncHdrH();
    bar._closing = false; bar.classList.remove("sel-closing");
    if (bar.hidden) { bar.hidden = false; bar.classList.add("sel-opening"); bar.addEventListener("animationend", () => bar.classList.remove("sel-opening"), { once: true }); }
  } else if (!bar.hidden && !bar._closing) {
    bar._closing = true; bar.classList.remove("sel-opening"); bar.classList.add("sel-closing");
    bar.addEventListener("animationend", () => { if (bar._closing) { bar.hidden = true; bar.classList.remove("sel-closing"); bar._closing = false; } }, { once: true });
  }
}
function toggleVideoSelect(id, shift) {
  if (!VSEL.size) _vFirstId = String(id);
  const ids = _vApprovedIds();
  const curIdx = ids.indexOf(String(id));
  if (shift && _vLastSel != null && ids.indexOf(String(_vLastSel)) >= 0 && curIdx >= 0) {
    const a = ids.indexOf(String(_vLastSel)), lo = Math.min(a, curIdx), hi = Math.max(a, curIdx);
    const turnOn = !isVSel(id);
    for (let i = lo; i <= hi; i++) { if (turnOn) VSEL.add(ids[i]); else VSEL.delete(ids[i]); }
  } else {
    if (isVSel(id)) VSEL.delete(String(id)); else VSEL.add(String(id));
  }
  _vLastSel = id;
  syncVSelVisuals(); updateVidSelBar();
}
function clearVideoSelection() { VSEL.clear(); _vLastSel = null; _vFirstId = null; syncVSelVisuals(); updateVidSelBar(); }
function videoSelectAllBelow() {   // the first-picked video + every one BELOW it (never above)
  const ids = _vApprovedIds();
  if (!ids.length || !VSEL.size) return;
  let anchor = ids.indexOf(String(_vFirstId));
  if (anchor < 0) anchor = Math.min(...[...VSEL].map(id => ids.indexOf(String(id))).filter(i => i >= 0));
  if (anchor < 0) return;
  for (let i = anchor; i < ids.length; i++) VSEL.add(ids[i]);
  _vLastSel = ids[ids.length - 1];
  syncVSelVisuals(); updateVidSelBar();
}
(function wireVidSelBar() {
  const sa = $("#vidSelAll"), gp = $("#vidSelGenPrompts"), cf = $("#vidSelCamFree"), gen = $("#vidSelGen"), appr = $("#vidSelApprove"), clr = $("#vidSelClear");
  if (sa) sa.addEventListener("click", videoSelectAllBelow);
  if (clr) clr.addEventListener("click", clearVideoSelection);
  if (cf) cf.addEventListener("click", async () => {
    const byId = new Map((DOC?.scenes || []).map(s => [s.id, s]));
    const sel = [...VSEL].map(Number).map(id => byId.get(id)).filter(Boolean);
    if (!sel.length) return;
    // toggle: if ALL selected are already free -> lock them; otherwise free them all
    const lockNext = sel.every(s => s.video_cam_lock === false);   // all currently free -> next action locks
    sel.forEach(s => { s.video_cam_lock = lockNext ? true : false; });
    queueSave(); renderVideos(); updateVidSelBar();
    toast(lockNext
      ? `Camera locked on ${sel.length} scene(s). Re-run Generate Prompts to bake it in.`
      : `Camera freed on ${sel.length} scene(s) — a small move is allowed. Re-run Generate Prompts to bake it in.`, "ok");
  });
  if (gp) gp.addEventListener("click", async () => {
    const ids = [...VSEL].map(Number).filter(n => !Number.isNaN(n));
    if (!ids.length) return;
    if (!(await confirmDialog(`Generate the video (motion) prompt for ${ids.length} selected scene(s)? This overwrites their current video prompt.`, { title: "Generate Prompts", okText: "Generate", danger: false }))) return;
    runVidPromptJob(ids);   // background job + persistent progress toast (survives tab switches), scoped to the selection
  });
  if (gen) gen.addEventListener("click", async () => {
    const ids = [...VSEL].map(Number).filter(n => !Number.isNaN(n));
    if (!ids.length) return;
    if (!(await confirmDialog(`Generate video(s) for ${ids.length} selected scene(s)? This uses the current model / duration / quality set on each card.`, { title: "Generate Videos", okText: "Generate", danger: false }))) return;
    genVideos(ids);
  });
  if (appr) appr.addEventListener("click", async () => {
    const ids = [...VSEL].map(Number).filter(n => !Number.isNaN(n));
    const byId = new Map((DOC?.scenes || []).map(s => [s.id, s]));
    // scenes in the selection that HAVE a ready video
    const ready = ids.map(id => byId.get(id)).filter(s => s && s.video && s.video.status === "ready" && s.video.file);
    if (!ready.length) { toast("No ready videos in the selection.", "info"); return; }
    // toggle: every ready selected video already approved -> unapprove all; otherwise approve all
    const approveNext = !ready.every(s => s.video.approved);
    const todo = ready.filter(s => !!s.video.approved !== approveNext);
    if (!todo.length) { toast("Nothing to change in the selection.", "info"); return; }
    if (!(await confirmDialog(`${approveNext ? "Approve" : "Unapprove"} ${todo.length} selected video(s)?`, { title: approveNext ? "Approve Videos" : "Unapprove Videos", okText: approveNext ? "Approve" : "Unapprove", danger: false }))) return;
    await flushSave();
    for (const s of todo) {
      s._appLock = Date.now() + 8000;   // stale poll must not flip it back
      try { DOC = await api.videoApprove(PROJECT, s.id, approveNext); } catch (_) {}
      const _f = DOC.scenes.find(x => x.id === s.id); if (_f) _f._appLock = Date.now() + 8000;
    }
    clearVideoSelection(); renderVideos();
    toast(approveNext ? `Approved ${todo.length} video(s).` : `Unapproved ${todo.length} video(s).`, "ok");
    try { if (approveNext) playNotifChime(); } catch (_) {}
  });
})();

(function wireSelBar() {
  const sa = $("#selAll"), rd = $("#selRedirect"), gp = $("#selGenPrompts"), gi = $("#selGenImages"), appr = $("#selApprove"), del = $("#selDelete"), clr = $("#selClear");
  if (sa) sa.addEventListener("click", selectAllBelow);
  if (appr) appr.addEventListener("click", async () => {
    const sel = (DOC?.scenes || []).filter(s => isSelected(s.id));
    const withImg = sel.filter(s => s.image && (s.image.versions || []).length);
    if (!withImg.length) { toast("None of the selected scenes have a generated image to approve.", "info"); return; }
    // toggle: if EVERY image-bearing selected scene is already approved -> unapprove all; otherwise approve all
    const approveNext = !withImg.every(s => s.approved);
    const ids = withImg.map(s => s.id);
    withImg.forEach(s => s._appLock = Date.now() + 8000);
    const r = await api.approveBatch(PROJECT, ids, approveNext);
    if (r && r.doc) { const script = DOC.script; DOC = r.doc; if (script) DOC.script = script; }
    renderScenes(); renderVideos(); updateSelBar();
    toast(approveNext ? `Approved ${ids.length} scene(s).` : `Unapproved ${ids.length} scene(s).`, "ok");
    try { if (approveNext) playNotifChime(); } catch (_) {}
  });
  if (rd) rd.addEventListener("click", () => {
    const ids = [...SELECTED].map(Number);
    if (!ids.length) return;
    // FULL director redo of just these scenes — the director re-decides everything (prompt, cast, camera,
    // transition, style, split, transformation stage). Differs from Generate Prompts, which keeps your style/
    // camera and only rewrites the prompt text. One coordinated director call for the selection.
    stoppable(rd, async (sig) => {
      setStatus("re-running director…");
      const prog = _redirectProgress(ids.length);
      let r; try { r = await api.redirect(PROJECT, ids, sig); } finally { prog.done(); }
      if (r.error) { toastErr(r.error); setStatus(""); return; }
      const script = DOC.script;
      DOC = await api.get(PROJECT); if (script) DOC.script = script;
      renderScenes(); updateSplitBtn(); setStatus("");
      const msg = `Director re-run on ${r.fixed} selected scene(s)` + (r.kept ? `, ${r.kept} kept (approved/raw, untouched)` : "");
      if (r.note) toast(`${msg}. ${r.note}`, "ok"); else toast(`${msg}.`, "ok");
      if (r.failed && r.failed.length) toast(`Director could not write scene(s): ${r.failed.join(", ")} — try again.`, "err");   // error sound via the toast hook
      else playNotifChime();   // success chime only when nothing failed
    });
  });
  if (gp) gp.addEventListener("click", () => {
    const ids = [...SELECTED].map(Number);
    if (!ids.length) return;
    stoppable(gp, (sig) => genPrompts(ids, sig));   // ONE coordinated director call for just these scenes
  });
  if (gi) gi.addEventListener("click", () => {
    // Selected scenes → generate / RE-generate their images, but NEVER an APPROVED scene (so Select All → Generate
    // only fills the UNAPPROVED ones and keeps your approved images). To redo one approved scene on purpose, use
    // that scene's own regenerate button. Also skip scenes with no prompt yet.
    const selScenes = (DOC?.scenes || []).filter(s => isSelected(s.id));
    const ids = selScenes.filter(s => !s.approved && ((s.prompt || "").trim() || s.testimonial || (s.ingredients && s.ingredients.length))).map(s => s.id);
    const skippedApproved = selScenes.filter(s => s.approved).length;
    if (!ids.length) {
      toast(skippedApproved ? "All selected scenes are approved — nothing to (re)generate (approved images are kept)." : "None of the selected scenes have a prompt yet — generate a prompt first.", "info");
      return;
    }
    if (skippedApproved) toast(`Generating ${ids.length} unapproved scene(s); ${skippedApproved} approved skipped.`, "info", 4500);
    withBusy(gi, () => genImages(ids));
  });
  if (del) del.addEventListener("click", async () => {
    const ids = [...SELECTED].map(Number);
    if (!ids.length) return;
    if (!(await confirmDialog(`Delete ${ids.length} selected scene(s)? Their images and videos will be removed.`, { title: "Delete Scenes", okText: "Delete" }))) return;
    await flushSave();   // commit pending edits before the delete+renumber
    pushUndo("delete scenes");
    DOC = await api.deleteScenes(PROJECT, ids);
    clearSelection(); renderScenes(); renderVideos();
    toast(`Deleted ${ids.length} scene(s).`, "info");
  });
  if (clr) clr.addEventListener("click", clearSelection);
})();
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && SELECTED.size) clearSelection(); });
// click on EMPTY space in the Scenes tab (not a scene card, not an action/selection bar) → drop the selection
document.addEventListener("click", (e) => {
  if (!SELECTED.size) return;
  if (!e.target.closest("#tab-scenes")) return;                                   // only within the Scenes tab
  if (e.target.closest(".scene-row, #selBar, .bulk-bar, .scene-toolbar, .scene-jump")) return;   // on a card/bar → keep
  clearSelection();
});

// Smooth-scroll a scene/video row into view, offset BELOW the sticky header so the scene number isn't
// hidden under the tabs (plain scrollIntoView left the top tucked under the header).
function scrollToRow(row) {
  if (!row) return;
  const hdr = document.querySelector("header");
  const off = (hdr ? hdr.getBoundingClientRect().bottom : 0) + 14;
  const y = row.getBoundingClientRect().top + window.scrollY - off;
  window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
}
// ---------- scene jump launcher (bottom-left of the Scenes tab) ----------
// A small pill showing the CURRENT scene ("12 / 41") that pops a compact grid of every scene number;
// click a number to smooth-scroll there. Compact (no long rail), and doubles as a "where am I" marker.
// One navigator engine, two instances: Scenes (colours by image state) and Videos (colours by
// video state). Videos share the same DOC.scenes order, so a chip drag reorders scenes either way.
const JUMP_CFG = {
  scene: {
    box: "sceneJump", list: "scenesList", row: "scene-row", noun: "Scene",
    state: (s) => { const im = s.image || {}; const hasImg = ((im.versions) || []).length > 0;
      return s.approved ? "sj-approved" : (hasImg ? "sj-made" : (im.status === "error" ? "sj-failed" : "")); },
  },
  video: {
    box: "videoJump", list: "videosList", row: "video-row", noun: "Video",
    state: (s) => { const v = s.video || {}; const hasVid = !!(v.file && v.status === "ready");
      return v.approved ? "sj-approved" : (hasVid ? "sj-made" : (v.status === "error" ? "sj-failed" : "")); },
  },
};
const _jumpObs = { scene: null, video: null };
let QA_FLAGGED = new Set();   // scene ids flagged by the last Image-QA run → shown red in the scene jump nav
function buildSceneJump() { buildJump("scene"); updateSceneCounts(); }   // keep the top counter (…approved) in sync wherever the jump recolors (approve / poll)
function buildVideoJump() { buildJump("video"); }
function buildJump(kind) {
  const cfg = JUMP_CFG[kind];
  const box = document.getElementById(cfg.box);
  if (!box) return;
  const pop = box.querySelector(".scene-jump-pop");
  const grid = box.querySelector(".scene-jump-grid");
  const btn = box.querySelector(".scene-jump-btn");
  const label = box.querySelector(".sj-label");
  const wasOpen = box.classList.contains("open");   // a rebuild (poll / generate / approve) must NOT close an open grid
  grid.innerHTML = "";
  if (_jumpObs[kind]) { _jumpObs[kind].disconnect(); _jumpObs[kind] = null; }
  const rows = [...document.querySelectorAll(`#${cfg.list} .${cfg.row}`)];   // mirrors the hide-approved filter → every chip maps to a real card
  box.hidden = rows.length < 2;
  if (rows.length < 2) { pop.hidden = true; box.classList.remove("open"); return; }
  const total = rows.length;
  const closePop = () => { pop.hidden = true; box.classList.remove("open"); };
  rows.forEach(row => {
    const id = row.dataset.id;
    const s = (DOC.scenes || []).find(x => String(x.id) === String(id));   // colour the chip by scene/video state
    const st = s ? cfg.state(s) : "";
    const c = document.createElement("button");
    c.type = "button"; c.className = "sj-chip" + (st ? " " + st : ""); c.dataset.target = id; c.textContent = id;
    if (kind === "scene" && QA_FLAGGED.has(String(id))) c.classList.add("qa-flag");   // Image-QA flagged this scene → red number
    if (s && (s.note || "").trim()) c.classList.add("has-note");   // tiny red dot on chips whose scene has a note
    c.title = `${cfg.noun} #${id}` + (s && (s.note || "").trim() ? " — has a note" : "") + " — click to jump, drag to reorder";
    c.addEventListener("click", (e) => {
      e.stopPropagation();
      const r = document.querySelector(`#${cfg.list} .${cfg.row}[data-id="${id}"]`);
      scrollToRow(r);
      closePop();
    });
    // hold-and-drag a chip to reorder (scenes and videos share the same order)
    c.draggable = true;
    c.addEventListener("dragstart", (e) => { e.stopPropagation(); c.classList.add("sj-drag"); try { e.dataTransfer.setData("text/plain", String(id)); e.dataTransfer.effectAllowed = "move"; } catch (_) {} });
    c.addEventListener("dragend", () => c.classList.remove("sj-drag"));
    c.addEventListener("dragover", (e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; c.classList.add("sj-drop"); });
    c.addEventListener("dragleave", () => c.classList.remove("sj-drop"));
    c.addEventListener("drop", async (e) => {
      e.preventDefault(); e.stopPropagation(); c.classList.remove("sj-drop");
      const src = (e.dataTransfer.getData("text/plain") || "").trim();
      if (!src || src === String(id)) return;
      const rect = c.getBoundingClientRect();
      const after = (e.clientX - rect.left) > rect.width / 2;   // drop on right half → place after
      await reorderScene(+src, +id, after);                     // rebuilds scenes + videos + both chip grids
    });
    grid.appendChild(c);
  });
  btn.onclick = (e) => {
    e.stopPropagation();
    if (box.classList.contains("moving")) return;   // in move mode, clicks reposition — don't open the grid
    const willOpen = pop.hidden;
    pop.hidden = !willOpen; box.classList.toggle("open", willOpen);
    if (willOpen) { const act = grid.querySelector(".sj-chip.active"); if (act) act.scrollIntoView({ block: "nearest" }); }
  };
  if (!buildJump._wired) {   // close any open grid on click-away / Esc (wire the document listeners just once, for both pills)
    const closeAll = () => document.querySelectorAll(".scene-jump").forEach(b => { const p = b.querySelector(".scene-jump-pop"); if (p) p.hidden = true; b.classList.remove("open"); });
    document.addEventListener("click", (e) => { if (!e.target.closest(".scene-jump")) closeAll(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeAll(); });
    buildJump._wired = true;
  }
  const setActive = (id) => {
    label.textContent = `${id} / ${total}`;
    grid.querySelectorAll(".sj-chip").forEach(c => c.classList.toggle("active", c.dataset.target === id));
  };
  setActive(rows[0].dataset.id);
  // update the current row as you scroll (the pill label + the highlighted chip)
  _jumpObs[kind] = new IntersectionObserver((entries) => {
    let hit = null;
    entries.forEach(e => { if (e.isIntersecting) hit = e.target.dataset.id; });
    if (hit != null) setActive(hit);
  }, { rootMargin: "-45% 0px -45% 0px", threshold: 0 });
  rows.forEach(r => _jumpObs[kind].observe(r));
  if (wasOpen) { pop.hidden = false; box.classList.add("open"); }   // keep the grid open across rebuilds (generate/approve/poll)
}

// ---- draggable jump pill: double-click to unlock (turns red), drag anywhere, click away to lock ----
// Wired once per pill; each keeps its own drag state + saved position (scene vs video).
function applyJumpPos(box, posKey, fallbackKey) {
  if (!box) return;
  let pos = null; try { pos = JSON.parse(localStorage.getItem(posKey) || "null"); } catch (e) {}
  // no saved position of its own → mirror the sibling pill so both sit in the same spot
  if ((!pos || !Number.isFinite(pos.left)) && fallbackKey) { try { pos = JSON.parse(localStorage.getItem(fallbackKey) || "null"); } catch (e) {} }
  if (pos && Number.isFinite(pos.left) && Number.isFinite(pos.top)) {
    const w = box.offsetWidth || 130, h = box.offsetHeight || 42;   // clamp into view so a saved pos from a bigger screen can't strand it off-screen
    const left = Math.max(4, Math.min((window.innerWidth || 1280) - w - 4, pos.left));
    const top = Math.max(4, Math.min((window.innerHeight || 800) - h - 4, pos.top));
    box.style.left = left + "px"; box.style.top = top + "px"; box.style.bottom = "auto";
  }
}
function setJumpMoving(box, on) {
  if (!box) return;
  box.classList.toggle("moving", on);
  if (!on) box.classList.remove("dragging");
  else { const pop = box.querySelector(".scene-jump-pop"); if (pop) pop.hidden = true; box.classList.remove("open"); }   // hide the grid while repositioning
}
function wireJumpDrag(boxId, posKey, fallbackKey) {
  const box = document.getElementById(boxId); if (!box) return;
  applyJumpPos(box, posKey, fallbackKey);
  let drag = null;
  box.addEventListener("dblclick", (e) => { e.preventDefault(); e.stopPropagation(); setJumpMoving(box, !box.classList.contains("moving")); });
  box.addEventListener("pointerdown", (e) => {
    if (!box.classList.contains("moving") || (e.button != null && e.button !== 0)) return;
    e.preventDefault(); e.stopPropagation();
    const r = box.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    box.classList.add("dragging");
    try { box.setPointerCapture(e.pointerId); } catch (_) {}
  });
  box.addEventListener("pointermove", (e) => {
    if (!drag) return;
    e.preventDefault();
    const w = box.offsetWidth, h = box.offsetHeight;
    let left = Math.max(4, Math.min(window.innerWidth - w - 4, e.clientX - drag.dx));
    let top = Math.max(4, Math.min(window.innerHeight - h - 4, e.clientY - drag.dy));
    box.style.left = left + "px"; box.style.top = top + "px"; box.style.bottom = "auto";
  });
  const endDrag = (e) => {
    if (!drag) return;
    drag = null; box.classList.remove("dragging");
    try { box.releasePointerCapture(e.pointerId); } catch (_) {}
    const left = parseFloat(box.style.left) || 0, top = parseFloat(box.style.top) || 0;
    try { localStorage.setItem(posKey, JSON.stringify({ left, top })); } catch (_) {}
  };
  box.addEventListener("pointerup", endDrag);
  box.addEventListener("pointercancel", endDrag);
  // click/press anywhere outside this pill → lock it in place (leave move mode)
  document.addEventListener("pointerdown", (e) => { if (box.classList.contains("moving") && !e.target.closest("#" + boxId)) setJumpMoving(box, false); });
}
(function wireAllJumpDrag() {
  wireJumpDrag("sceneJump", "sceneJumpPos");
  wireJumpDrag("videoJump", "videoJumpPos", "sceneJumpPos");   // video pill defaults to the scene pill's spot
})();

// ---------- reference thumbnails (served locally, not from Cloudinary) ----------
// Size the square thumbnails to pack all N of them into the refs area (a fixed W×H box that
// fills down to the left "Generate Image" button). Pick the column count that makes the
// squares as large as possible while every row still fits the height — so a few refs are big
// and many shrink to keep fitting the same area.
function fitRefs(container) {
  // Thumbnails are now sized by CSS (fixed-size auto-fill grid), independent of column height.
  // Clear any stale inline sizing so the stylesheet wins.
  if (!container) return;
  container.style.gridTemplateColumns = "";
  container.style.gridAutoRows = "";
}

// Smoothly stretch/shrink the refs grid (and thus the scene frame) from oldH to its new height.
// Runs synchronously (the DOM is already updated by drawRefs) so it doesn't depend on rAF firing.
function animateRefsHeight(container, oldH) {
  if (!container) return;
  container.style.display = "grid";                // override :empty { display:none } so an emptied list can animate closed
  const newH = container.scrollHeight;
  if (Math.abs(newH - oldH) < 1) { container.style.display = ""; return; }
  container.style.overflow = "hidden";
  container.style.height = oldH + "px";
  getComputedStyle(container).height;              // reflow so the transition runs
  container.style.transition = "height .32s cubic-bezier(.3,.72,.3,1)";
  container.style.height = newH + "px";
  clearTimeout(container._t);
  container._t = setTimeout(() => {                // release back to natural height (CSS hides it again if now empty)
    container.style.transition = "";
    container.style.height = "";
    container.style.overflow = "";
    container.style.display = "";
  }, 360);
}
window.addEventListener("resize", () => document.querySelectorAll(".scene-refs-list").forEach(fitRefs));

function refThumb(url) {
  return `/api/ref-thumb/${encodeURIComponent(PROJECT)}?u=${encodeURIComponent(url)}`;
}
// Point an <img> at the local copy, falling back to the original URL once if it's gone.
function setRefImg(img, url) {
  if (!url) return;
  if (/^(blob|data):/.test(url)) { img.src = url; return; }   // staged upload preview
  img.onerror = () => { img.onerror = null; img.src = url; };
  img.src = refThumb(url);
}

// ---------- named characters (per-project cast) ----------
// The old "In scene:" chip row is retired — cast is now assigned via the Cast dropdown next to
// Reference Scene (see the scene render loop). This just keeps the old row hidden.
// Show the scene's FACE-LOCK cast as removable chips (this used to be hidden, which made the auto-attached
// characters invisible — you couldn't tell whose face would be used, nor remove one). Each chip = a character
// whose reference face is attached to THIS scene; the × drops them from the scene (not from the roster).
function _buildCastChip(container, s, c) {
  const chip = document.createElement("span"); chip.className = "scene-cast-chip"; chip.dataset.cid = c.id;
  const u = charUrls(c)[0];
  if (u) { const im = document.createElement("img"); im.alt = ""; setRefImg(im, u); chip.appendChild(im); }
  else { const av = document.createElement("span"); av.className = "scene-cast-av"; av.textContent = (c.name || "?").slice(0, 1).toUpperCase(); chip.appendChild(av); }
  const nm = document.createElement("span"); nm.className = "scene-cast-nm"; nm.textContent = c.name || "?";
  const x = document.createElement("button"); x.type = "button"; x.className = "scene-cast-x"; x.textContent = "×"; x.title = "Remove from this scene";
  x.addEventListener("click", () => sceneCastRemove(container, s, c.id));
  if (c.transforms) {   // transforming character (e.g. Sophie: overweight → slim) → pick which reference look this scene uses
    // With a distinct END (slim) photo, offer a simple 2-way before/slim toggle — "mid" attaches BOTH photos
    // (and the model slims the heavy one) which is not what you want; end uses the slim photo DIRECTLY.
    const STAGES = ((c.urls_end || []).length) ? ["start", "end"] : ["start", "mid", "end"];
    const LBL = { start: "◐ before", mid: "◑ mid", end: "● slim" };
    const stg = document.createElement("button"); stg.type = "button"; stg.className = "scene-cast-stage";
    stg.title = "Transformation stage — which reference to use: start (before) / mid / end (after / slim)";
    const cur = () => ((s.states && s.states[c.id]) || "start");
    const paint = () => { stg.textContent = LBL[cur()] || LBL.start; };
    paint();
    stg.addEventListener("click", (e) => {
      e.stopPropagation();
      s.states = s.states || {};
      s.states[c.id] = STAGES[(STAGES.indexOf(cur()) + 1) % STAGES.length];
      paint(); _persist();
    });
    chip.append(nm, stg, x);
  } else {
    chip.append(nm, x);
  }
  return chip;
}
function _ensureCastLabel(container) {
  if (!container.querySelector(".scene-cast-lbl")) {
    const lbl = document.createElement("span"); lbl.className = "scene-cast-lbl"; lbl.textContent = "In scene:";
    container.insertBefore(lbl, container.firstChild);
  }
}
function drawSceneCast(container, s) {
  if (!container) return;
  container.innerHTML = "";
  const byId = {}; ((DOC && DOC.characters) || []).forEach(c => byId[c.id] = c);
  const ids = (s.cast || []).filter(id => byId[id]);
  if (!ids.length) { container.hidden = true; return; }
  container.hidden = false;
  _ensureCastLabel(container);
  ids.forEach(id => container.appendChild(_buildCastChip(container, s, byId[id])));   // each chip fades/scales in (CSS)
}
// Always mutate the CANONICAL scene object that lives in DOC.scenes (a row's closure `s` can go stale after a
// DOC reassignment → edits would hit an orphan and never persist). Look it up by id every time.
function canonScene(s) { return ((DOC && DOC.scenes) || []).find(x => x.id === (s && s.id)) || s; }
// add ONE chip with a smooth entry (no full rebuild → only the new chip animates in)
function sceneCastAdd(container, s, c) {
  if (!container) return;
  s = canonScene(s);
  s.cast = s.cast || []; if (!s.cast.includes(c.id)) s.cast.push(c.id);
  s.cast_locked = (s.cast_locked || []).filter(x => x !== c.id);   // re-adding un-locks it (director may auto-bind again)
  container.hidden = false; _ensureCastLabel(container);
  container.appendChild(_buildCastChip(container, s, c));
  _persist();
}
// remove ONE chip with a smooth exit (animate out, THEN drop it + save)
function sceneCastRemove(container, s, id) {
  s = canonScene(s);
  pushUndo("remove cast");   // registers → Undo lights up + clear feedback that it took
  s.cast = (s.cast || []).filter(v => v !== id);
  s.cast_locked = s.cast_locked || []; if (!s.cast_locked.includes(id)) s.cast_locked.push(id);   // stays removed against auto-binds until you re-add it or Re-run Director
  const chip = container && container.querySelector(`.scene-cast-chip[data-cid="${id}"]`);
  const finish = () => { if (chip) chip.remove(); if (container && !container.querySelector(".scene-cast-chip")) container.hidden = true; setStatus("saving…"); _persist().then(() => { setStatus("saved"); setTimeout(() => setStatus(""), 1000); }); };
  if (chip) { chip.classList.add("leaving"); setTimeout(finish, 170); } else finish();
  toast("Removed from scene", "info");
}
function refreshAllSceneCast() {
  $$(".scene-row").forEach(el => el._updateCast && el._updateCast());   // refresh each Cast button (visibility + label) after a character is added/removed
}
// After adding/updating a cast member's photo, the backend re-binds that character into any non-approved scene
// whose prompt names it (a late-detected Narrator, etc.) and returns the fresh characters + scenes. Sync both
// so the Cast ▾ dropdown shows the new photo AND those scenes will use the face on their next image generation.
function applyCastResp(resp) {
  if (!resp || resp.error) return resp;
  if (Array.isArray(resp._characters)) DOC.characters = resp._characters;
  if (Array.isArray(resp._scenes)) {
    const byUid = {}; resp._scenes.forEach(s => { if (s && s.uid) byUid[s.uid] = s; });
    (DOC.scenes || []).forEach(s => { const ns = byUid[s.uid]; if (ns && Array.isArray(ns.cast)) s.cast = ns.cast; });
  }
  refreshAllSceneCast();
  return resp;
}
// redraw every scene's Product chip — call after the product is renamed in Settings so the chips
// (which resolve their label live from DOC.product.names[url]) pick up the new name without a reload.
function refreshAllSceneProducts() {
  const scenes = (DOC && DOC.scenes) || [];
  $$(".scene-row").forEach(el => {
    const s = scenes.find(x => String(x.id) === String(el.dataset.id));
    if (s) drawSceneProduct($(".scene-product", el), s);
  });
}
// ---------- per-scene INGREDIENT chips (reuse the cast-chip styling) ----------
function _buildIngChip(container, s, c) {
  const chip = document.createElement("span"); chip.className = "scene-cast-chip"; chip.dataset.iid = c.id;
  const u = (c.urls || [])[0];
  if (u) { const im = document.createElement("img"); im.alt = ""; setRefImg(im, u); chip.appendChild(im); }
  else { const av = document.createElement("span"); av.className = "scene-cast-av"; av.textContent = "🧪"; chip.appendChild(av); }
  const nm = document.createElement("span"); nm.className = "scene-cast-nm"; nm.textContent = c.name || "?";
  const x = document.createElement("button"); x.type = "button"; x.className = "scene-cast-x"; x.textContent = "×"; x.title = "Remove from this scene";
  x.addEventListener("click", () => sceneIngRemove(container, s, c.id));
  chip.append(nm, x);
  return chip;
}
function _ensureIngLabel(container) {
  if (!container.querySelector(".scene-cast-lbl")) {
    const lbl = document.createElement("span"); lbl.className = "scene-cast-lbl"; lbl.textContent = "Ingredients:";
    container.insertBefore(lbl, container.firstChild);
  }
}
function drawSceneIng(container, s) {
  if (!container) return;
  container.innerHTML = "";
  const byId = {}; ((DOC && DOC.ingredients) || []).forEach(c => byId[c.id] = c);
  const ids = (s.ingredients || []).filter(id => byId[id]);
  if (!ids.length) { container.hidden = true; return; }
  container.hidden = false;
  _ensureIngLabel(container);
  ids.forEach(id => container.appendChild(_buildIngChip(container, s, byId[id])));
}
function sceneIngAdd(container, s, c) {
  if (!container) return;
  s.ingredients = s.ingredients || []; if (!s.ingredients.includes(c.id)) s.ingredients.push(c.id);
  container.hidden = false; _ensureIngLabel(container);
  container.appendChild(_buildIngChip(container, s, c));
  _persist();
}
function sceneIngRemove(container, s, id) {
  s.ingredients = (s.ingredients || []).filter(v => v !== id);
  const chip = container && container.querySelector(`.scene-cast-chip[data-iid="${id}"]`);
  const finish = () => { if (chip) chip.remove(); if (container && !container.querySelector(".scene-cast-chip")) container.hidden = true; _persist(); };
  if (chip) { chip.classList.add("leaving"); setTimeout(finish, 170); } else finish();
}
// Product chip above the sentence (single value) — mirrors cast/ingredient chips so the chosen product is visible.
function drawSceneProduct(container, s) {
  if (!container) return;
  container.innerHTML = "";
  const url = s.product || "";
  const urls = (DOC && DOC.product && DOC.product.urls) || [];
  if (!url || !urls.includes(url)) { container.hidden = true; return; }
  container.hidden = false;
  const lbl = document.createElement("span"); lbl.className = "scene-cast-lbl"; lbl.textContent = "Product:";
  container.appendChild(lbl);
  const names = (DOC && DOC.product && DOC.product.names) || {};
  const chip = document.createElement("span"); chip.className = "scene-cast-chip";
  const im = document.createElement("img"); im.alt = ""; setRefImg(im, url); chip.appendChild(im);
  const nm = document.createElement("span"); nm.className = "scene-cast-nm"; nm.textContent = (names[url] || "Product").trim(); chip.appendChild(nm);
  const x = document.createElement("button"); x.type = "button"; x.className = "scene-cast-x"; x.textContent = "×"; x.title = "Remove product from this scene";
  x.addEventListener("click", (e) => {
    e.stopPropagation();
    s = canonScene(s);
    pushUndo("remove product");   // registers → Undo lights up + clear feedback
    s.product = "";
    const row = container.closest(".scene-row");
    const pb = row && row.querySelector(".product-btn"); if (pb) { pb.classList.remove("on"); pb.classList.remove("suggest"); }
    drawSceneProduct(container, s);
    setStatus("saving…"); _persist().then(() => { setStatus("saved"); setTimeout(() => setStatus(""), 1000); });
    toast("Product removed from this scene", "info");
  });
  chip.appendChild(x);
  container.appendChild(chip);
}
// Continuity chip: when the director linked this scene to continue an earlier one (cont_of), it reuses that
// scene's image as a reference → near-identical shots. Show it so the user can BREAK the link with ×.
function drawSceneCont(container, s) {
  if (!container) return;
  container.innerHTML = "";
  const uid = s.cont_of;
  const src = uid ? ((DOC && DOC.scenes) || []).find(x => x.uid === uid) : null;
  if (!src) { container.hidden = true; return; }
  container.hidden = false;
  const lbl = document.createElement("span"); lbl.className = "scene-cast-lbl"; lbl.textContent = "Continuity:";
  container.appendChild(lbl);
  const chip = document.createElement("span"); chip.className = "scene-cast-chip cont-chip";
  const nm = document.createElement("span"); nm.className = "scene-cast-nm"; nm.textContent = "↳ Scene #" + src.id; chip.appendChild(nm);
  const x = document.createElement("button"); x.type = "button"; x.className = "scene-cast-x"; x.textContent = "×";
  x.title = "Break continuity — generate this scene on its own (stop reusing the previous scene's image as a reference)";
  x.addEventListener("click", (e) => {
    e.stopPropagation();
    const cs = canonScene(s);
    pushUndo("break continuity");
    cs.cont_of = null;
    drawSceneCont(container, cs);
    setStatus("saving…"); _persist().then(() => { setStatus("saved"); setTimeout(() => setStatus(""), 1000); });
    toast("Continuity removed — this scene generates independently now", "info");
  });
  chip.appendChild(x);
  container.appendChild(chip);
}
// ---- Cast/Characters field INSIDE the Target Audience modal (a dropdown like the others) ----
let castSummaryEl = null;
let pendingCast = [];   // NEW-project mode: characters staged in the browser, uploaded after the project is created
function castCount() { return modalMode === "new" ? pendingCast.length : ((DOC && DOC.characters) || []).length; }
function updateCastSummary() {
  if (!castSummaryEl) return;
  const n = castCount();
  castSummaryEl.textContent = n ? `${n} character${n === 1 ? "" : "s"}` : "";
}
function charUrls(c) { return (c && (c.urls || (c.url ? [c.url] : []))) || []; }

function renderCastBody(inner) {
  inner.innerHTML = "";
  const isNew = modalMode === "new";
  const hint = document.createElement("div");
  hint.className = "cast-hint";
  hint.textContent = isNew
    ? "Add named characters now — they’re created with the project. Give each a name and one or more reference images; assign them per scene on the Scenes tab."
    : "Named characters keep people consistent across scenes. Rename inline, add or remove reference images (several per character is fine), or ✨ generate a portrait from the description — then assign them per scene on the Scenes tab.";
  inner.appendChild(hint);

  const list = document.createElement("div"); list.className = "cast-list";
  const items = isNew ? pendingCast : ((DOC && DOC.characters) || []);
  items.forEach((c, i) => list.appendChild(buildCastCard(c, i, isNew, inner)));

  // add-a-new-character row — rendered ABOVE the existing characters
  const form = document.createElement("div"); form.className = "cast-add";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-add-name"; nameI.placeholder = "New character name (e.g. Loretta)";
  const fileL = document.createElement("label"); fileL.className = "cast-add-file";
  const fileTxt = document.createElement("span"); fileTxt.textContent = "＋ Add images";
  const fileI = document.createElement("input"); fileI.type = "file"; fileI.accept = "image/*"; fileI.multiple = true; fileI.hidden = true;
  fileL.append(fileTxt, fileI);
  const saveB = document.createElement("button"); saveB.type = "button"; saveB.className = "cast-add-save primary"; saveB.textContent = "＋ Add Character"; saveB.disabled = true;
  form.append(nameI, fileL, saveB);
  let files = [];
  const validate = () => { saveB.disabled = !(nameI.value.trim() && files.length); };
  fileI.addEventListener("change", e => { files = [...e.target.files]; fileTxt.textContent = files.length ? `${files.length} image${files.length > 1 ? "s" : ""} selected` : "＋ Add images"; validate(); });
  nameI.addEventListener("input", validate);
  saveB.addEventListener("click", () => withBusy(saveB, async () => {
    if (!(nameI.value.trim() && files.length)) return;
    if (isNew) {
      pendingCast.push({ name: nameI.value.trim(), files: [...files], previewUrls: files.map(f => URL.createObjectURL(f)) });
      renderCastBody(inner);
    } else {
      const r = await api.addCharacter(PROJECT, nameI.value.trim(), files);
      if (r.error) { alert(r.error); return; }
      if (Array.isArray(r._characters)) applyCastResp(r);   // full fresh roster + scene re-binds
      else { DOC.characters = DOC.characters || []; DOC.characters.push(r); }
      renderCastBody(inner); refreshAllSceneCast();
    }
  }));
  inner.appendChild(form);
  inner.appendChild(list);
}

// One character card: editable name + delete, then a grid of its reference images (each removable)
// plus an "add image(s)" tile. Handles both staged (new-project) and saved (existing-project) characters.
function buildCastCard(c, i, isNew, inner) {
  const card = document.createElement("div"); card.className = "cast-card";
  const head = document.createElement("div"); head.className = "cast-card-head";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-card-name"; nameI.value = c.name || ""; nameI.spellcheck = false;
  nameI.addEventListener("change", async () => {
    const nm = nameI.value.trim(); if (!nm) { nameI.value = c.name; return; }
    if (isNew) { c.name = nm; }
    else { const r = await api.updateCharacter(PROJECT, c.id, { name: nm }); if (!r.error) { c.name = r.name; refreshAllSceneCast(); toast(`Renamed to “${nm}”`, "ok"); } }
  });
  // Generate a portrait for this character (saved characters only — needs a stored id + description).
  // The result is a candidate the user reviews (use / regenerate / upload) — never auto-applied.
  if (!isNew) {
    const gen = document.createElement("button"); gen.type = "button"; gen.className = "cast-card-gen"; gen.innerHTML = MAGIC_SVG;
    gen.title = "Generate a portrait (click a thumbnail afterwards to edit/regenerate it)";
    gen.addEventListener("click", () => withBusy(gen, async () => {   // ✨ = generate ONE portrait directly; edit via the thumbnail
      let r; try { r = await api.genCharacter(PROJECT, c.id, true); } catch (e) { r = { error: "request failed" }; }
      if (r.error || !r.url) { toast(r.error || "generation failed", "err", 7000); return; }
      let u2; try { u2 = await api.useCharCandidate(PROJECT, c.id, r.url); } catch (e) { u2 = { error: "request failed" }; }
      if (u2.error) { toast(u2.error, "err"); return; }
      applyCastResp(u2);
      const cc = DOC.characters.find(z => z.id === c.id); if (cc) { cc.urls = u2.urls; delete cc.url; }
      renderCastBody(inner); refreshAllSceneCast();
      toast(`Generated a photo for “${c.name}”.`, "ok");
    }));
    head.appendChild(gen);
  }
  const del = document.createElement("button"); del.type = "button"; del.className = "cast-card-del"; del.innerHTML = TRASH_SVG; del.title = "Delete character";
  del.addEventListener("click", async () => {
    if (isNew) { (c.previewUrls || []).forEach(u => { try { URL.revokeObjectURL(u); } catch (e) {} }); pendingCast.splice(i, 1); renderCastBody(inner); return; }
    if (!(await confirmDialog(`Delete character “${c.name}”? It will be removed from every scene.`, { title: "Delete Character", okText: "Delete", danger: true }))) return;
    const r = await api.delCharacter(PROJECT, c.id);
    DOC.characters = r.characters || [];
    (DOC.scenes || []).forEach(s => { if (s.cast) s.cast = s.cast.filter(x => x !== c.id); });
    renderCastBody(inner); refreshAllSceneCast();
  });
  head.insertBefore(nameI, head.firstChild); head.appendChild(del); card.appendChild(head);

  // START photos (for a transforming character these are their BEFORE look)
  if (!isNew && c.transforms) {
    const lab = document.createElement("div"); lab.className = "cast-bucket-label"; lab.textContent = "Start look";
    card.appendChild(lab);
  }
  card.appendChild(buildPhotoGrid(c, i, isNew, inner, "start"));

  // TRANSFORMS (saved characters only): a toggle + optional note + a second END-look photo bucket.
  // When on, the director tags each scene with the person's stage (start/mid/end) and we attach the
  // matching photo(s), so the SAME face stays while the body changes gradually across the video.
  if (!isNew) {
    const trow = document.createElement("label"); trow.className = "cast-transform-row";
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!c.transforms;
    const tspan = document.createElement("span"); tspan.textContent = "Transforms (looks change across the video)";
    trow.append(cb, tspan); card.appendChild(trow);
    cb.addEventListener("change", async () => {
      const r = await api.updateCharacter(PROJECT, c.id, { transforms: cb.checked });
      if (!r.error) { const cc = DOC.characters.find(x => x.id === c.id); if (cc) { cc.transforms = r.transforms; cc.urls_end = r.urls_end || []; } renderCastBody(inner); }
    });
    if (c.transforms) {
      const note = document.createElement("input"); note.type = "text"; note.className = "cast-transform-note";
      note.placeholder = "How they change (e.g. starts overweight, gradually slims down to fit)";
      note.value = c.transform_note || "";
      note.addEventListener("change", async () => {
        const r = await api.updateCharacter(PROJECT, c.id, { note: note.value.trim() });
        if (!r.error) { const cc = DOC.characters.find(x => x.id === c.id); if (cc) cc.transform_note = r.transform_note; }
      });
      card.appendChild(note);
      const lab = document.createElement("div"); lab.className = "cast-bucket-label"; lab.textContent = "End look (transformed)";
      card.appendChild(lab);
      card.appendChild(buildPhotoGrid(c, i, false, inner, "end"));
    }
  }
  return card;
}

// One photo bucket for a character: a removable-thumb grid + an add tile. `bucket` = "start" (c.urls,
// must keep ≥1) or "end" (c.urls_end, optional, may be empty). Handles staged (new) and saved characters.
function buildPhotoGrid(c, i, isNew, inner, bucket) {
  const isEnd = bucket === "end";
  const grid = document.createElement("div"); grid.className = "cast-img-grid";
  const urls = isNew ? (c.previewUrls || []) : (isEnd ? (c.urls_end || []) : charUrls(c));
  const minOne = !isEnd;                                            // start bucket keeps ≥1; end bucket may go empty
  urls.forEach((u, idx) => {
    const thumb = document.createElement("div"); thumb.className = "cast-thumb";
    const im = document.createElement("img"); im.alt = ""; if (isNew) im.src = u; else setRefImg(im, u);
    if (!isNew && !isEnd) { im.style.cursor = "pointer"; im.title = "Edit / regenerate this image"; im.addEventListener("click", () => openCharCandidate(c, inner, u)); }   // click the portrait → edit/regenerate window
    const x = document.createElement("button"); x.type = "button"; x.className = "cast-thumb-x"; x.textContent = "×"; x.title = "Remove image";
    x.addEventListener("click", async () => {
      if (isNew) { try { URL.revokeObjectURL(c.previewUrls[idx]); } catch (e) {} c.files.splice(idx, 1); c.previewUrls.splice(idx, 1); renderCastBody(inner); return; }
      const r = await api.removeCharacterImage(PROJECT, c.id, u, bucket);
      if (!r.error) { const cc = DOC.characters.find(x => x.id === c.id); if (cc) { cc.urls = r.urls; cc.urls_end = r.urls_end || []; delete cc.url; } renderCastBody(inner); refreshAllSceneCast(); }
    });
    thumb.append(im, x); grid.appendChild(thumb);
  });
  const add = document.createElement("label"); add.className = "cast-thumb cast-thumb-add"; add.title = "Add image(s)"; add.innerHTML = "<span>＋</span>";
  const addI = document.createElement("input"); addI.type = "file"; addI.accept = "image/*"; addI.multiple = true; addI.hidden = true;
  addI.addEventListener("change", async e => {
    const fs = [...e.target.files]; if (!fs.length) return;
    if (isNew) { fs.forEach(f => { c.files.push(f); c.previewUrls.push(URL.createObjectURL(f)); }); renderCastBody(inner); return; }
    const r = await api.updateCharacter(PROJECT, c.id, { files: fs, bucket });
    if (!r.error) { applyCastResp(r); const cc = DOC.characters.find(x => x.id === c.id); if (cc) { cc.urls = r.urls; cc.urls_end = r.urls_end || []; delete cc.url; } renderCastBody(inner); refreshAllSceneCast(); }
  });
  add.appendChild(addI); grid.appendChild(add);
  return grid;
}

// Fade a modal-bg out (matches the .closing keyframes) instead of yanking it away instantly.
// ---- Ingredients tab (Settings): the product's real ingredients + a reference image each ----
function renderIngredientsBody(inner) {
  if (!inner) return;
  inner.innerHTML = "";
  const hint = document.createElement("div"); hint.className = "cast-hint";
  hint.textContent = PROJECT
    ? "The product's ingredients (auto-detected from your script — edit freely). Give each a reference image so on-screen ingredient shots use the REAL, consistent look; the director attaches them to scenes that show ingredients."
    : "Open a project first — ingredients are stored per project.";
  inner.appendChild(hint);
  if (!PROJECT) return;
  const form = document.createElement("div"); form.className = "cast-add";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-add-name"; nameI.placeholder = "New ingredient (e.g. Green Tea)";
  const saveB = document.createElement("button"); saveB.type = "button"; saveB.className = "cast-add-save primary"; saveB.textContent = "＋ Add Ingredient"; saveB.disabled = true;
  form.append(nameI, saveB);
  nameI.addEventListener("input", () => { saveB.disabled = !nameI.value.trim(); });
  saveB.addEventListener("click", () => withBusy(saveB, async () => {
    if (!nameI.value.trim()) return;
    const r = await api.addIngredient(PROJECT, nameI.value.trim(), []);
    if (r.error) { alert(r.error); return; }
    DOC.ingredients = DOC.ingredients || []; DOC.ingredients.push(r);
    renderIngredientsBody(inner); refreshAllSceneCast();
  }));
  inner.appendChild(form);
  const list = document.createElement("div"); list.className = "cast-list";
  ((DOC && DOC.ingredients) || []).forEach((c, i) => list.appendChild(buildIngredientCard(c, i, inner)));
  inner.appendChild(list);
}
function buildIngredientCard(c, i, inner) {
  const card = document.createElement("div"); card.className = "cast-card";
  const head = document.createElement("div"); head.className = "cast-card-head";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-card-name"; nameI.value = c.name || ""; nameI.spellcheck = false;
  nameI.addEventListener("change", async () => {
    const nm = nameI.value.trim(); if (!nm) { nameI.value = c.name; return; }
    const r = await api.updateIngredient(PROJECT, c.id, { name: nm }); if (!r.error) { c.name = r.name; refreshAllSceneCast(); }
  });
  const gen = document.createElement("button"); gen.type = "button"; gen.className = "cast-card-gen"; gen.innerHTML = MAGIC_SVG; gen.title = "Generate a reference image (click a thumbnail afterwards to edit/regenerate it)";
  gen.addEventListener("click", () => withBusy(gen, async () => {   // ✨ = generate ONE image directly (no popup); edit via the thumbnail
    let r; try { r = await api.genIngredient(PROJECT, c.id, true); } catch (e) { r = { error: "request failed" }; }
    if (r.error || !r.url) { toast(r.error || "generation failed", "err", 7000); return; }
    let u2; try { u2 = await api.useIngCandidate(PROJECT, c.id, r.url); } catch (e) { u2 = { error: "request failed" }; }
    if (u2.error) { toast(u2.error, "err"); return; }
    const cc = DOC.ingredients.find(z => z.id === c.id); if (cc) cc.urls = u2.urls;
    renderIngredientsBody(inner); refreshAllSceneCast();
    toast(`Generated image for “${c.name}”.`, "ok");
  }));
  const del = document.createElement("button"); del.type = "button"; del.className = "cast-card-del"; del.innerHTML = TRASH_SVG; del.title = "Delete ingredient";
  del.addEventListener("click", async () => {
    if (!(await confirmDialog(`Delete ingredient “${c.name}”? It will be removed from every scene.`, { title: "Delete Ingredient", okText: "Delete", danger: true }))) return;
    const r = await api.delIngredient(PROJECT, c.id);
    DOC.ingredients = r.ingredients || [];
    (DOC.scenes || []).forEach(s => { if (s.ingredients) s.ingredients = s.ingredients.filter(x => x !== c.id); });
    renderIngredientsBody(inner); refreshAllSceneCast();
  });
  head.append(nameI, gen, del); card.appendChild(head);
  // per-ingredient generation options
  const opts = document.createElement("div"); opts.className = "ing-opts";
  const mkChk = (label, checked, title, onChange) => {
    const lab = document.createElement("label"); lab.className = "ing-opt" + (checked ? " on" : ""); lab.title = title;
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!checked;
    const sp = document.createElement("span"); sp.textContent = label;
    cb.addEventListener("change", async () => { lab.classList.toggle("on", cb.checked); await onChange(cb.checked); });
    lab.append(cb, sp); return lab;
  };
  opts.appendChild(mkChk("🧬 Scientific", c.scientific, "Render as a 3D molecule / scientific image instead of the natural setting (for complexes like vitamins/minerals)",
    async v => { c.scientific = v; await api.updateIngredient(PROJECT, c.id, { scientific: v }); }));
  opts.appendChild(mkChk("▎▎ Split", c.split, "Split the name by  /  into equal side-by-side panels (e.g. Chromium / Zinc / B Vitamin → 3 panels)",
    async v => { c.split = v; await api.updateIngredient(PROJECT, c.id, { split: v }); }));
  opts.appendChild(mkChk("📌 Use directly", c.use_directly, "Use THIS uploaded/generated image directly in scenes that show it — no new generation (best for a fixed combo like an All-Ingredients image). Scenes with 2+ ingredients auto-montage their reference images regardless.",
    async v => { c.use_directly = v; await api.updateIngredient(PROJECT, c.id, { use_directly: v }); }));
  card.appendChild(opts);
  const grid = document.createElement("div"); grid.className = "cast-img-grid";
  (c.urls || []).forEach((u) => {
    const thumb = document.createElement("div"); thumb.className = "cast-thumb";
    const im = document.createElement("img"); im.alt = ""; im.style.cursor = "pointer"; im.title = "Edit / regenerate this image"; setRefImg(im, u);
    im.addEventListener("click", () => openIngCandidate(c, inner, u));   // click the image → edit/regenerate window
    const x = document.createElement("button"); x.type = "button"; x.className = "cast-thumb-x"; x.textContent = "×"; x.title = "Remove image";
    x.addEventListener("click", async () => { const r = await api.removeIngredientImage(PROJECT, c.id, u); if (!r.error) { const cc = DOC.ingredients.find(z => z.id === c.id); if (cc) cc.urls = r.urls; renderIngredientsBody(inner); } });
    thumb.append(im, x); grid.appendChild(thumb);
  });
  const add = document.createElement("label"); add.className = "cast-thumb cast-thumb-add"; add.title = "Add image(s)"; add.innerHTML = "<span>＋</span>";
  const addI = document.createElement("input"); addI.type = "file"; addI.accept = "image/*"; addI.multiple = true; addI.hidden = true;
  addI.addEventListener("change", async e => {
    const fs = [...e.target.files]; if (!fs.length) return;
    const r = await api.updateIngredient(PROJECT, c.id, { files: fs });
    if (!r.error) { const cc = DOC.ingredients.find(z => z.id === c.id); if (cc) cc.urls = r.urls; renderIngredientsBody(inner); }
  });
  add.appendChild(addI); grid.appendChild(add); card.appendChild(grid);
  return card;
}
function smoothHideModal(bg) {
  if (!bg || bg.hidden) return;
  bg.classList.add("closing");
  setTimeout(() => { bg.hidden = true; bg.classList.remove("closing"); }, 175);
}
// A simple full-screen image viewer (for the candidate + anywhere a plain URL wants a big view).
function openUrlLightbox(url) {
  let lb = document.getElementById("urlLightbox");
  if (!lb) {
    lb = document.createElement("div"); lb.id = "urlLightbox"; lb.className = "url-lightbox"; lb.hidden = true;
    lb.innerHTML = `<img alt="">`;
    const shut = () => { lb.classList.remove("show"); setTimeout(() => { lb.hidden = true; }, 220); };
    lb.addEventListener("click", shut);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !lb.hidden) shut(); });
    document.body.appendChild(lb);
  }
  lb.querySelector("img").src = url;
  lb.hidden = false; requestAnimationFrame(() => lb.classList.add("show"));
}

// Generate-a-character flow — a mini image-generation studio for ONE character's portrait CANDIDATE (never
// auto-applied). Supports multiple versions (‹ ›), an edit box (image-to-image), click-to-zoom, and full-res
// preview. Accept commits the shown version; Cancel discards every candidate.
function openCharCandidate(c, inner, seed) {
  return openGenCandidate(c, {
    seed,   // if set, the modal opens ON this existing image (edit / regenerate it) instead of generating fresh
    customPrompt: true,   // show the "write your own prompt → generate" box
    gen: (fresh, prompt) => api.genCharacter(PROJECT, c.id, fresh, prompt),
    edit: (url, instr) => api.editCharCandidate(PROJECT, c.id, url, instr),
    use: (url) => api.useCharCandidate(PROJECT, c.id, url),
    discard: (opts) => api.discardCharCandidate(PROJECT, c.id, opts),
    commit: (r) => { const cc = (DOC.characters || []).find(x => x.id === c.id); if (cc) { cc.urls = r.urls; delete cc.url; } renderCastBody(inner); refreshAllSceneCast(); },
  });
}
function openIngCandidate(c, inner, seed) {
  return openGenCandidate(c, {
    seed,
    customPrompt: true,   // show the "write your own prompt → generate" box
    gen: (fresh, prompt) => api.genIngredient(PROJECT, c.id, fresh, prompt),
    edit: (url, instr) => api.editIngCandidate(PROJECT, c.id, url, instr),
    use: (url) => api.useIngCandidate(PROJECT, c.id, url),
    discard: (opts) => api.discardIngCandidate(PROJECT, c.id, opts),
    commit: (r) => { const cc = (DOC.ingredients || []).find(x => x.id === c.id); if (cc) cc.urls = r.urls; renderIngredientsBody(inner); refreshAllSceneCast(); },
  });
}
// ---------- Testimonials tab: people roster (separate pool from the VSL cast) ----------
// Mirrors the cast roster (reuses the cast-* styling for a pixel-identical look) but lives in its own
// tab, works only on a saved project, allows name-only people (portrait generated later), and keeps a
// separate DOC.testimonials list. Written cards + talking-avatar video will be added to this tab next.
function tpUrls(p) { return (p && p.urls) || []; }
function renderTestimonials() {
  const host = $("#tpRoster");
  if (!host) return;
  if (!PROJECT || !DOC) { host.innerHTML = `<div class="empty-state"><p>Open or create a project first, then build your testimonial characters here.</p></div>`; const cb = $("#tcBuilder"); if (cb) cb.innerHTML = ""; return; }
  tcLoadTL(true);   // refresh the VO timeline (scene times + word alignment) on entry, so the per-card segment players are current
  tcHost = $("#tcBuilder");
  renderTPeople(host);   // renderTPeople's tail renders the cards once (single path — no double Add bar)
}
function renderTPeople(inner) {
  // capture existing card positions so the re-centred grid animates smoothly (FLIP) instead of jumping
  const prev = {};
  inner.querySelectorAll(".tp-card[data-pid]").forEach(el => { prev[el.dataset.pid] = el.getBoundingClientRect(); });

  inner.innerHTML = "";
  // add-a-new-character row — just a centred button; all details are filled in on the new card
  const form = document.createElement("div"); form.className = "cast-add";
  const saveB = document.createElement("button"); saveB.type = "button"; saveB.className = "cast-add-save primary"; saveB.textContent = "＋ Add Character";
  form.append(saveB);
  saveB.addEventListener("click", () => withBusy(saveB, async () => {
    const r = await api.addTPerson(PROJECT, "", "", []);
    if (r.error) { toast(r.error, "err"); return; }
    DOC.testimonials = DOC.testimonials || []; DOC.testimonials.push(r);
    renderTPeople(inner);
  }));
  inner.appendChild(form);

  const list = document.createElement("div"); list.className = "cast-list";
  ((DOC && DOC.testimonials) || []).forEach((p, i) => list.appendChild(buildTPCard(p, i, inner)));
  inner.appendChild(list);
  flipTPCards(list, prev);
  if (tcHost) renderTCards();   // keep the card builder's character picker in sync with the roster
}
// Smooth re-centre: slide each surviving card from its old spot to the new one; fade/scale new cards in.
function flipTPCards(list, prev) {
  const cards = [...list.querySelectorAll(".tp-card[data-pid]")];
  cards.forEach(el => {
    const now = el.getBoundingClientRect();
    const old = prev[el.dataset.pid];
    if (old) {
      const dx = old.left - now.left, dy = old.top - now.top;
      if (dx || dy) { el.style.transition = "none"; el.style.transform = `translate(${dx}px, ${dy}px)`; }
    } else {
      el.style.transition = "none"; el.style.opacity = "0"; el.style.transform = "scale(.96)";
    }
  });
  requestAnimationFrame(() => cards.forEach(el => {
    el.style.transition = "transform .34s cubic-bezier(.45,0,.15,1), opacity .3s ease";
    el.style.transform = ""; el.style.opacity = "";
  }));
}
// One testimonial character = a compact SQUARE tile: a portrait slot on top (UPLOAD when empty, click to
// edit/regenerate when filled), then Name / Age / Location fields, then a single full-width Generate button.
// × (top-right) deletes the whole character.
const TP_UPLOAD_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V5"/><path d="M7.5 9.5 12 5l4.5 4.5"/><path d="M5 19h14"/></svg>';
const TP_ZOOM_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/><path d="M11 8v6M8 11h6"/></svg>';
function buildTPCard(p, i, inner) {
  const card = document.createElement("div"); card.className = "tp-card"; card.dataset.pid = p.id;

  // delete the whole character
  const del = document.createElement("button"); del.type = "button"; del.className = "tp-card-x"; del.textContent = "×"; del.title = "Delete character";
  del.addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!(await confirmDialog(`Delete “${p.name}”?`, { title: "Delete Character", okText: "Delete", danger: true }))) return;
    card.classList.add("tp-leaving");                 // fade + shrink out before the roster re-renders (rest slide via FLIP)
    await new Promise(res => setTimeout(res, 200));
    const r = await api.delTPerson(PROJECT, p.id);
    DOC.testimonials = r.testimonials || [];
    renderTPeople(inner);
  });
  card.appendChild(del);

  // square portrait slot — shows the most recent image, or an UPLOAD drop when empty
  const urls = tpUrls(p); const url = urls.length ? urls[urls.length - 1] : null;
  let sq;
  const genOne = async () => {
    if (sq.classList.contains("busy")) return;
    sq.classList.add("busy");
    let r; try { r = await api.genTPerson(PROJECT, p.id, true); } catch (e) { r = { error: "request failed" }; }
    if (r.error || !r.url) { sq.classList.remove("busy"); toast(r.error || "generation failed", "err", 7000); return; }
    let u2; try { u2 = await api.useTPCandidate(PROJECT, p.id, r.url); } catch (e) { u2 = { error: "request failed" }; }
    sq.classList.remove("busy");
    if (u2.error) { toast(u2.error, "err"); return; }
    const pp = DOC.testimonials.find(z => z.id === p.id); if (pp) pp.urls = u2.urls;
    renderTPeople(inner);
    toast(`Generated a photo for “${p.name}”.`, "ok");
  };
  if (url) {
    sq = document.createElement("div"); sq.className = "tp-portrait";
    const im = document.createElement("img"); im.alt = ""; setRefImg(im, url); sq.appendChild(im);
    const ov = document.createElement("div"); ov.className = "tp-ov"; ov.innerHTML = TP_ZOOM_SVG; sq.appendChild(ov);   // hover hint = zoom (click opens the enlarge/edit studio) — NOT a generate action
    sq.title = "Edit / regenerate this portrait";
    sq.addEventListener("click", () => openTPCandidate(p, inner, url));
    // × on the portrait removes just THIS image (back to the upload slot), not the character
    const imx = document.createElement("button"); imx.type = "button"; imx.className = "tp-img-x"; imx.textContent = "×"; imx.title = "Remove image";
    imx.addEventListener("click", async (e) => {
      e.stopPropagation();
      const r = await api.removeTPersonImage(PROJECT, p.id, url);
      if (!r.error) { const pp = DOC.testimonials.find(z => z.id === p.id); if (pp) pp.urls = r.urls; renderTPeople(inner); }
    });
    sq.appendChild(imx);
  } else {
    sq = document.createElement("label"); sq.className = "tp-portrait empty"; sq.title = "Upload an image";
    const z = document.createElement("div"); z.className = "tp-up-zone"; z.innerHTML = TP_UPLOAD_SVG + "<span>Upload image</span>"; sq.appendChild(z);
    const upI = document.createElement("input"); upI.type = "file"; upI.accept = "image/*"; upI.hidden = true; sq.appendChild(upI);
    upI.addEventListener("change", async e => {
      const fs = [...e.target.files]; if (!fs.length) return;
      const r = await api.updateTPerson(PROJECT, p.id, { files: fs });
      if (!r.error) { const pp = DOC.testimonials.find(z2 => z2.id === p.id); if (pp) pp.urls = r.urls; renderTPeople(inner); }
    });
  }
  card.appendChild(sq);

  // Name / Age / Location — the persistent editable fields
  const mkField = (cls, ph, val, key) => {
    const el = document.createElement("input"); el.type = "text"; el.className = "tp-field" + (cls ? " " + cls : ""); el.placeholder = ph; el.value = val || ""; el.spellcheck = false;
    el.addEventListener("change", async () => {
      if (key === "name" && !el.value.trim()) { el.value = p.name || ""; return; }
      const r = await api.updateTPerson(PROJECT, p.id, { [key]: el.value.trim() });
      if (r.error) return;
      p[key] = r[key];
      // the cards below show this person's name / age / location and list them in their character picker —
      // redraw so an edit up here is reflected straight away instead of only after a reload
      if (typeof renderTCards === "function") renderTCards();
    });
    return el;
  };
  card.appendChild(mkField("tp-name", "Name & surname", p.name, "name"));
  const row2 = document.createElement("div"); row2.className = "tp-row2";
  row2.appendChild(mkField("", "Age", p.age, "age"));
  const _gNorm = p.gender ? p.gender.charAt(0).toUpperCase() + p.gender.slice(1).toLowerCase() : "";   // backend stores lowercase "male"/"female"; the dropdown options are "Male"/"Female"
  const genderSel = tcSelect(_gNorm, [{ value: "", label: "Gender" }, { value: "Male", label: "Male" }, { value: "Female", label: "Female" }], async (val) => {
    const r = await api.updateTPerson(PROJECT, p.id, { gender: val });
    if (r.error) return;
    p.gender = r.gender;
    if (typeof renderTCards === "function") renderTCards();
  }, "Gender");
  genderSel.classList.add("tc-dd-row");
  row2.appendChild(genderSel);
  card.appendChild(row2);
  card.appendChild(mkField("", "Location", p.location, "location"));

  // appearance description — a longer, auto-growing note that feeds the portrait prompt
  const note = document.createElement("textarea"); note.className = "tp-note-area"; note.rows = 1; note.spellcheck = false;
  note.placeholder = "Appearance — describe what this character looks like (feeds the portrait)"; note.value = p.desc || "";
  const grow = () => { note.style.height = "auto"; note.style.height = Math.max(66, Math.min(note.scrollHeight, 260)) + "px"; };   // never shrink below the ~3-line baseline; stretch down smoothly (CSS transitions height)
  note.addEventListener("input", grow);
  note.addEventListener("change", async () => {
    const r = await api.updateTPerson(PROJECT, p.id, { desc: note.value.trim() });
    if (!r.error) p.desc = r.desc;
  });
  card.appendChild(note);
  requestAnimationFrame(grow);

  // single full-width Generate button (yellow ✨)
  const genB = document.createElement("button"); genB.type = "button"; genB.className = "ghost tp-gen"; genB.innerHTML = `<span class="tp-gen-lbl">${MAGIC_SVG}<span>${url ? "Regenerate" : "Generate"}</span></span>`;
  genB.addEventListener("click", genOne);
  card.appendChild(genB);

  return card;
}
// Full generate/edit studio for a person's portrait — reuses the shared candidate harness (same modal as cast).
function openTPCandidate(p, inner, seed) {
  return openGenCandidate(p, {
    seed,
    portrait: true,
    gen: (fresh) => api.genTPerson(PROJECT, p.id, fresh),
    edit: (url, instr) => api.editTPCandidate(PROJECT, p.id, url, instr),
    use: (url) => api.useTPCandidate(PROJECT, p.id, url),
    discard: (opts) => api.discardTPCandidate(PROJECT, p.id, opts),
    commit: (r) => { const pp = (DOC.testimonials || []).find(x => x.id === p.id); if (pp) pp.urls = r.urls; renderTPeople(inner); },
  });
}

// ---------- Testimonials tab: written testimonial CARDS (Facebook / Email / Star review) ----------
// The card design lives ONLY here (single source of truth = the live preview). Download re-renders the
// exact same HTML to a PNG server-side (headless Edge), so the file is pixel-identical to the preview.
// Pick a type + a character → the preview builds itself; the character's name / age / location / photo
// drop into the realistic spots for each format.
let tcHost = null;
let tcSaveTimer = null;
const tcImgCache = {};                                                      // image rel -> dataURL (embedded so the render is self-contained)
const TC_TYPES = [{ k: "facebook", label: "Facebook" }, { k: "email", label: "Email" }, { k: "star", label: "Star Review" }];
const TC_PIN_SVG = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2c-3.9 0-7 3.1-7 7 0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>';
const TC_GMAIL_SVG = '<svg viewBox="0 0 256 193" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path fill="#4285F4" d="M58.182 192.05V93.14L27.507 65.077 0 49.504v125.091c0 9.658 7.825 17.455 17.455 17.455z"/><path fill="#34A853" d="M197.818 192.05h40.727c9.659 0 17.455-7.826 17.455-17.455V49.505l-31.156 17.837-27.026 25.798z"/><path fill="#EA4335" d="M58.182 93.14l-4.174-38.647 4.174-36.989L128 69.868l69.818-52.364 4.847 39.226-4.847 36.41L128 145.504z"/><path fill="#FBBC04" d="M197.818 17.504V93.14L256 49.504V26.231c0-21.585-24.64-33.89-41.89-20.945z"/><path fill="#C5221F" d="M0 49.504l26.759 20.07L58.182 93.14V17.504L41.89 5.286C24.61-7.66 0 4.646 0 26.231z"/></svg>';
const TC_ICONS = {
  menu: "M3 6h18M3 12h18M3 18h18",
  compose: "M4 20h4L18.5 9.5a2.12 2.12 0 0 0-3-3L5 17z M13.5 6.5l3 3",
  inbox: "M4 13l2.2-7.3A2 2 0 0 1 8.1 4h7.8a2 2 0 0 1 1.9 1.7L20 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z M4 13h4l1.2 2h5.6L16 13h4",
  star: "M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17l-5.2 2.6 1-5.8L3.5 9.7l5.9-.9z",
  clock: "M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16z M12 8v4l3 2",
  sent: "M22 2L11 13 M22 2l-7 20-4-9-9-4z",
  bag: "M6.5 8h11l-1 11.5a1 1 0 0 1-1 .9H8.5a1 1 0 0 1-1-.9z M9 8a3 3 0 0 1 6 0",
  more: "M6 9l6 6 6-6",
};
function tcIcon(n) {
  const d = TC_ICONS[n] || "";
  const paths = d.split(" M").map((seg, i) => `<path d="${i ? "M" + seg : seg}"/>`).join("");
  return `<svg class="tc-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
}
const tcEsc = s => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const tcTextHtml = s => tcEsc(s).replace(/\n/g, "<br>");
function tcCharById(id) { return ((DOC && DOC.testimonials) || []).find(c => c.id === id) || null; }
function tcEx(card) { card.extra = card.extra || {}; return card.extra[card.format] || (card.extra[card.format] = {}); }

// ---- voice-over timeline (for the per-testimonial segment player + word-level karaoke) ----
// Cached preview manifest (scene start/end + full VO) + word-level alignment timings. Fetched
// lazily when the Testimonials tab is shown; refreshed after ~60s or on demand.
let tcTL = null, tcTLPromise = null;
let tcPlayer = null, tcPlayCtl = null;   // one shared <audio> + the active card's stop() so only one plays
async function tcLoadTL(force) {
  if (!PROJECT) return null;
  if (tcTL && !force && (Date.now() - tcTL.at < 60000)) return tcTL;
  if (tcTLPromise && !force) return tcTLPromise;
  tcTLPromise = (async () => {
    let model = null, words = [];
    try { const m = await api.previewModel(PROJECT); if (m && !m.error) model = m; } catch (_) {}
    try { const w = await api.words(PROJECT); words = (w && w.words) || []; } catch (_) {}
    if (model && model.words && model.words.length) words = model.words;   // after a custom-VO splice the preview returns REMAPPED word times → use those so karaoke stays synced
    tcTL = { model, words, at: Date.now() };
    tcTLPromise = null; return tcTL;
  })();
  return tcTLPromise;
}
function tcStopPlay() { if (tcPlayCtl && tcPlayCtl.stop) { try { tcPlayCtl.stop(); } catch (_) {} } }
// Trim the scene's VO words down to the ones that actually spell the card text — skips any NARRATOR intro
// (e.g. "And Helen F. adds:") that shares the scene but isn't on the card, which otherwise shifts the
// highlight ahead of the audio. Returns the timed words aligned 1:1 to the card's body words.
function tcAlignWords(allWords, text, hintStart) {
  // Sequence-align the card words to the VO word stream so edited/typo'd/extra card words (or a shared
  // narrator intro in the VO) don't shift the mapping. Returns one timed word per card word, in order.
  // Keep letters of ANY script and strip only punctuation. Stripping to [a-z0-9] threw away every umlaut,
  // accent and cedilla, so German "Größe"/"Müller" collapsed to "gre"/"mller" — words that no longer look
  // like themselves and can collide with a different word inside the lookahead window, lighting up the
  // wrong one. \p{L} keeps them whole for German, French, Turkish and the rest.
  const norm = s => (s || "").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");   // same "is a word" rule as the karaoke spans and align_clip.py: any script, punctuation dropped
  const cw = (text || "").split(/\s+/).map(norm).filter(Boolean);
  if (!cw.length || !(allWords || []).length) return [];
  const vwAll = allWords.map(w => norm(w.w));

  // Search a window around the linked scene rather than the whole VO, so an identical phrase elsewhere in
  // the script cannot capture these words.
  let lo = 0;
  if (hintStart != null) { const k = allWords.findIndex(w => w.s >= hintStart - 0.4); if (k > 0) lo = k; }
  lo = Math.max(0, lo - 25);
  const hi = Math.min(vwAll.length, lo + Math.max(400, cw.length * 6));
  const vw = vwAll.slice(lo, hi), m = vw.length, n = cw.length;

  // Longest-common-subsequence alignment — the same idea the Premiere export uses server-side. The old
  // greedy scan took the first hit within 8 words and refused to advance when it missed, so one word the
  // VO words differently (or a common word like "ich" matching too early) stalled the cursor: from there
  // words stopped lighting up until something happened to match again, then it caught up in a rush.
  const dp = new Int32Array((n + 1) * (m + 1));
  for (let i = n - 1; i >= 0; i--) {
    const row = i * (m + 1), next = (i + 1) * (m + 1);
    for (let j = m - 1; j >= 0; j--) {
      dp[row + j] = (cw[i] === vw[j]) ? dp[next + j + 1] + 1
                                      : Math.max(dp[next + j], dp[row + j + 1]);
    }
  }
  const out = new Array(n).fill(null);
  for (let i = 0, j = 0; i < n && j < m;) {
    if (cw[i] === vw[j]) { out[i] = allWords[lo + j]; i++; j++; }
    else if (dp[(i + 1) * (m + 1) + j] >= dp[i * (m + 1) + j + 1]) i++;
    else j++;
  }

  // Unmatched words (an edit, or a word the VO says differently) are spread evenly between their matched
  // neighbours instead of all inheriting one timestamp, so the highlight keeps moving through them.
  const firstIdx = out.findIndex(Boolean);
  if (firstIdx < 0) return [];
  for (let i = 0; i < firstIdx; i++) out[i] = { s: out[firstIdx].s, e: out[firstIdx].s, w: cw[i] };
  let lastIdx = firstIdx;
  for (let i = firstIdx + 1; i < n; i++) {
    if (out[i]) {
      const gap = i - lastIdx - 1;
      if (gap > 0) {
        const a = out[lastIdx].e, b = out[i].s, step = (b - a) / (gap + 1);
        for (let k = 1; k <= gap; k++) out[lastIdx + k] = { s: a + step * (k - 1), e: a + step * k, w: cw[lastIdx + k] };
      }
      lastIdx = i;
    }
  }
  for (let i = lastIdx + 1; i < n; i++) out[i] = { s: out[lastIdx].e, e: out[lastIdx].e, w: cw[i] };
  return out;
}
// This card's karaoke timing. Prefers the card's OWN custom voice-over (whole clip, 0-based, aligned by
// /align) if present; otherwise the slice of the ORIGINAL project VO for its linked scene.
function tcCardTiming(card) {
  const ex = (card && card.extra) || {};
  if (ex.vo && ex.words && ex.words.length && ex.vo_dur) {   // user's own voice-over + its clip alignment
    // Do NOT assume the aligner produced one word per card word. Whisper tokenises its own way — it splits
    // "1.000" into "1." + "000" and emits "€" separately — so a card token and ex.words[i] drift apart from
    // the first such spot and every later word inherits its neighbour's time: the highlight sticks there and
    // never recovers. Run the same sequence alignment used for the project VO so each card word gets its own.
    const w = tcAlignWords(ex.words, card.text, null);
    return { vo: mediaUrl(ex.vo), voRel: ex.vo, start: 0, end: ex.vo_dur, words: w.length ? w : ex.words, custom: true };
  }
  if (!tcTL || !tcTL.model) return null;
  const sc = ((DOC && DOC.scenes) || []).find(s => s.tcard_id === card.id);
  if (!sc) return null;
  const ps = (tcTL.model.scenes || []).find(x => x.id === sc.id);
  if (!ps || !tcTL.model.vo || ps.end <= ps.start) return null;
  // filter by word ONSET inside the scene (not overlap) so a previous scene's boundary-straddling word
  // isn't pulled in as word[0] — that off-by-one made the highlight run ahead of the audio
  // match the card text against the FULL VO word stream (anchored near the scene) so every word — including
  // the last — gets its real timing, regardless of where the scene boundary falls
  let words = tcAlignWords(tcTL.words || [], card.text, ps.start);
  if (!words.length) words = (tcTL.words || []).filter(w => w.s >= ps.start - 0.05 && w.s < ps.end + 0.5);   // fallback if the text didn't line up
  return { vo: tcTL.model.vo, voRel: null, start: ps.start, end: ps.end, words, custom: false };
}
function tcCharUrl(c) { const u = c && c.urls; return (u && u.length) ? u[u.length - 1] : ""; }

// Script + voice-over for a WRITTEN testimonial card — SAME split layout as the video editor: the text box
// on the LEFT, the voice controls on the RIGHT (Voice ID, + Save Current | Saved Voices, Generate, Upload).
// By default the audio is auto-pulled from the original project recording (the segment player + karaoke below
// the preview); generating/uploading here OVERRIDES it → card.extra.vo (shared with the video editor).
// Start a card alignment as a background job and pump its stages into `prog` until it finishes.
// Resolves to the same shape the blocking endpoint returns ({words,dur,lang} or {error}).
async function tcRunAlignJob(cid, body, prog) {
  let r;
  try { r = await api.tcardAlignJob(PROJECT, cid, body); } catch (_) { return { error: "request failed" }; }
  if (!r || !r.job) return { error: (r && r.error) || "could not start the aligner" };
  for (;;) {
    await new Promise(res => setTimeout(res, 400));
    let j;
    try { j = await api.tcardAlignJobStatus(r.job); } catch (_) { continue; }   // a dropped poll is not a failure
    if (!j) continue;
    if (j.status === "running") { if (prog) prog.update(j.step || "Aligning…", j.pct || 0); continue; }
    if (j.status === "error") return { error: j.error || "alignment failed" };
    if (prog) prog.update("Done", 100);
    return j.result || { error: "alignment returned nothing" };
  }
}
function tcBuildScriptVoiceover(card, ta) {
  const ex = card.extra = card.extra || {};
  const split = document.createElement("div"); split.className = "tv-split tc-svsplit";
  const sl = document.createElement("div"); sl.className = "tv-split-l";
  ta.classList.add("tv-script"); sl.appendChild(ta); split.appendChild(sl);
  const sr = document.createElement("div"); sr.className = "tv-split-r";

  const auto = document.createElement("div"); auto.className = "tc-vo-auto";
  const refreshAuto = () => {
    if (ex.vo) { auto.hidden = true; return; }
    auto.hidden = false;
    const t = tcCardTiming(card);
    auto.innerHTML = t
      ? '<span class="tc-vo-tick">✓</span> Auto voice-over ready — pulled from your original recording. Replace it below if you like.'
      : 'Auto voice-over comes from your original recording once the SRT is generated — or set your own below.';
  };
  sr.appendChild(auto);

  // after the user sets a custom voice-over, forced-align it (clip + text) so the karaoke syncs to THEIR voice
  const alignCustom = async () => {
    // Runs as a job so the toast can show the aligner's real stages — loading the model is most of the
    // wall time, so a plain "please wait" sits there looking hung for the bulk of it.
    const prog = progressToast("Aligning your voice-over…");
    let a = await tcRunAlignJob(card.id, { vo: ex.vo, text: card.text }, prog);
    prog.close();
    if (!a || a.error) { toast(`Karaoke alignment failed${(a && a.error) ? ": " + a.error : ""} — the audio is still saved.`, "err", 9000); return; }
    ex.words = a.words || []; ex.vo_dur = a.dur || 0; ex.words_lang = a.lang || ""; tcQueueSave();
    toast("Voice-over aligned — the preview now uses your voice.", "ok", 3500);
    if (typeof renderTCards === "function") renderTCards();   // rebuild so the segment player + karaoke pick up the clip timing
  };

  const vidField = document.createElement("label"); vidField.className = "field tv-vidfield";
  const vidSpan = document.createElement("span"); vidSpan.textContent = "Voice ID"; vidField.appendChild(vidSpan);
  const vidInput = document.createElement("input"); vidInput.type = "text"; vidInput.placeholder = "ElevenLabs voice ID"; vidInput.value = ex.voiceId || "";
  vidInput.addEventListener("input", () => { ex.voiceId = vidInput.value.trim(); tcQueueSave(); });
  vidField.appendChild(vidInput); sr.appendChild(vidField);

  const voiceOpts = [{ value: "", label: "🎧 Saved Voices" }].concat((tcVoices || []).map(v => ({ value: v.voice_id, label: v.name })));
  const voManage = document.createElement("div"); voManage.className = "tv-vomanage";
  const saveCur = document.createElement("button"); saveCur.type = "button"; saveCur.className = "ghost tv-savecur"; saveCur.textContent = "+ Save Current";
  const savedDD = tcSelect("", voiceOpts, (val) => { if (val) { ex.voiceId = val; vidInput.value = val; tcQueueSave(); } }, "🎧 Saved Voices"); savedDD.classList.add("tv-saveddd");
  voManage.append(saveCur, savedDD); sr.appendChild(voManage);
  const saveForm = document.createElement("div"); saveForm.className = "tv-saveform"; saveForm.hidden = true;
  const svName = document.createElement("input"); svName.type = "text"; svName.className = "tv-savename"; svName.placeholder = "Name (e.g. Loretta Jophlin)";
  const svOk = document.createElement("button"); svOk.type = "button"; svOk.className = "primary tv-savego"; svOk.textContent = "Save";
  saveForm.append(svName, svOk); sr.appendChild(saveForm);
  saveCur.addEventListener("click", () => { saveForm.hidden = !saveForm.hidden; if (!saveForm.hidden) svName.focus(); });
  svOk.addEventListener("click", async () => {
    const nm = svName.value.trim(); const vid = (ex.voiceId || "").trim();
    if (!nm) { toast("Enter a name", "err"); return; }
    if (!vid) { toast("Enter a Voice ID first", "err"); return; }
    let r; try { r = await api.addVoice(nm, vid); } catch (x) { r = { error: "failed" }; }
    if (r && r.error) { toast(r.error, "err"); return; }
    tcVoices = null; toast(`Saved voice “${nm}”`, "ok"); renderTCards();
  });

  const genVo = document.createElement("button"); genVo.type = "button"; genVo.className = "primary tv-genvo"; genVo.textContent = "🎙️ Generate Voiceover";
  genVo.addEventListener("click", () => withBusy(genVo, async () => {
    const vid = (ex.voiceId || "").trim();
    if (!vid) { toast("Enter or pick a Voice ID first", "err"); return; }
    if (!(card.text || "").trim()) { toast("Write the testimonial text first", "err"); return; }
    let r; try { r = await api.tvVoiceover(PROJECT, card.id, vid, card.text); } catch (x) { r = { error: "request failed" }; }
    if (r.error || !r.url) { toast(r.error || "voiceover failed", "err", 7000); return; }
    ex.vo = r.url; ex.words = null; ex.vo_dur = null; tcQueueSave(); renderVo(); refreshAuto();
    await alignCustom();
  }));
  sr.appendChild(genVo);

  const voBox = document.createElement("div"); voBox.className = "tv-vobox"; sr.appendChild(voBox);
  const drop = document.createElement("label"); drop.className = "file-drop tv-updrop";
  const fdl = document.createElement("span"); fdl.className = "fd-label"; fdl.textContent = "🎵 Upload voice-over (.mp3, .wav)";
  const fdn = document.createElement("span"); fdn.className = "fd-name"; fdn.textContent = "No file selected";
  drop.append(fdl, fdn);
  const upI = document.createElement("input"); upI.type = "file"; upI.accept = "audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus"; upI.hidden = true; drop.appendChild(upI);
  upI.addEventListener("change", async (ev) => {
    const f = ev.target.files[0]; if (!f) return; fdn.textContent = f.name;
    let r; try { r = await api.tvUploadAudio(PROJECT, card.id, f); } catch (x) { r = { error: "upload failed" }; }
    if (r.error || !r.url) { toast(r.error || "upload failed", "err"); return; }
    ex.vo = r.url; ex.words = null; ex.vo_dur = null; tcQueueSave(); renderVo(); refreshAuto();
    await alignCustom();
  });
  sr.appendChild(drop);

  const renderVo = () => {
    voBox.innerHTML = "";
    if (!ex.vo) return;
    const a = document.createElement("audio"); a.controls = true; a.src = mediaUrl(ex.vo); voBox.appendChild(a);
    const rm = document.createElement("button"); rm.type = "button"; rm.className = "ghost tc-vo-revert"; rm.textContent = "↺ Use auto voice-over";
    rm.addEventListener("click", () => { ex.vo = null; ex.words = null; ex.vo_dur = null; tcQueueSave(); renderVo(); refreshAuto(); if (typeof renderTCards === "function") renderTCards(); });   // back to the original recording's segment
    voBox.appendChild(rm);
  };
  if (tcVoices === null) api.getVoices().then(v => { tcVoices = v || []; renderTCards(); }).catch(() => { tcVoices = []; });
  split.appendChild(sr);
  renderVo(); refreshAuto();
  return split;
}
function tcProdUrl() { const u = DOC && DOC.product && DOC.product.urls; return (u && u.length) ? u[0] : ""; }
function tcToday() { try { return new Date().toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }); } catch (e) { return ""; } }
function tcGmailDate() { try { return new Date().toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }); } catch (e) { return "Aug 4, 2026, 9:41 AM"; } }
function tcEmailFor(name) { const p = (name || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").trim().split(/\s+/).filter(Boolean); return (p.length > 1 ? p[0] + "." + p[p.length - 1] : (p[0] || "user")) + "@gmail.com"; }
function loadTcRel(rel) {
  if (!rel) return Promise.resolve(null);
  if (tcImgCache[rel]) return Promise.resolve(tcImgCache[rel]);
  return fetch(mediaUrl(rel)).then(r => r.blob()).then(b => new Promise(res => {
    const fr = new FileReader(); fr.onload = () => { tcImgCache[rel] = fr.result; res(fr.result); }; fr.onerror = () => res(null); fr.readAsDataURL(b);
  })).catch(() => null);
}
function loadTcImg(c) { return loadTcRel(tcCharUrl(c)); }
function tcAvatarHtml(c) {
  const url = tcImgCache[tcCharUrl(c)];
  if (url) return `<img class="tc-av" src="${url}" alt="">`;
  const ini = tcEsc(((c && c.name) || "?").trim().charAt(0).toUpperCase() || "?");
  return `<div class="tc-av" style="display:flex;align-items:center;justify-content:center;color:#90949c;font-weight:700;font-size:44px;">${ini}</div>`;
}
function tcProdList() { return (DOC && DOC.product && DOC.product.urls) || []; }
function tcDefaultProd() { const l = tcProdList(); return l.find(u => /1\s*-?\s*(pack|bottle)/i.test(u)) || l[0] || ""; }
function tcProdLabel(u) { const m = (u || "").match(/(\d+)\s*-?\s*(pack|bottle)/i); return m ? `${m[1]}-pack` : ((u || "").split("/").pop() || "Product"); }
// How far the review text is allowed to spread across the star card. 1680 wide minus its 68px side
// padding is the hard ceiling; the default matches the old fixed max-width.
const TCW_MIN = 520, TCW_MAX = 1544, TCW_DEF = 1200;
function tcBodyWidth(ex) { return Math.max(TCW_MIN, Math.min(TCW_MAX, Math.round(+(ex || {}).textw || TCW_DEF))); }
function tcBodyWidthStyle(ex) { const w = tcBodyWidth(ex); return w === TCW_DEF ? "" : ` style="max-width:${w}px"`; }

// --- product image: measure what is actually VISIBLE in it -------------------------------------------
// The bottle rarely fills its PNG. Alpha 40 is the cut: it keeps the bottle and drops the soft drop
// shadow, which is what makes a measured box match the one your eye draws. Returns the transparent share
// above (ft) and below (fb) the bottle, as a fraction of the image height.
const tcProdInsetCache = {};
function tcProdInset(url) {
  if (tcProdInsetCache[url]) return Promise.resolve(tcProdInsetCache[url]);
  return new Promise(res => {
    const done = v => { tcProdInsetCache[url] = v; res(v); };
    const im = new Image();
    im.onerror = () => done({ ft: 0, fb: 0 });
    im.onload = () => {
      let ft = 0, fb = 0;
      try {
        const h = Math.min(240, im.naturalHeight) || 1;                 // row occupancy only — no need for full res
        const w = Math.max(1, Math.round(im.naturalWidth * h / (im.naturalHeight || 1)));
        const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
        const cx = cv.getContext("2d", { willReadFrequently: true });
        cx.drawImage(im, 0, 0, w, h);
        const d = cx.getImageData(0, 0, w, h).data;
        const solid = r => { for (let x = 0; x < w; x++) if (d[(r * w + x) * 4 + 3] > 40) return true; return false; };
        let t = 0; while (t < h - 1 && !solid(t)) t++;
        let b = h - 1; while (b > t && !solid(b)) b--;
        ft = t / h; fb = (h - 1 - b) / h;
      } catch (_) { }
      done({ ft, fb });
    };
    im.src = tcImgCache[url] || url;
  });
}
// Empty space between a text element's box and where its glyphs actually put ink. A star glyph sits well
// above the bottom of its line box — measured at 14px at this size — so lining the boxes up leaves the
// stars visibly high. Canvas reports both the font's line metrics and the glyph's own ink extents, so
// this stays right if the font or size ever changes.
function tcTextInk(el, sample) {
  try {
    const cs = getComputedStyle(el);
    const cx = document.createElement("canvas").getContext("2d");
    cx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize}/1 ${cs.fontFamily}`;
    const m = cx.measureText(sample || el.textContent || "");
    const asc = m.fontBoundingBoxAscent || 0, desc = m.fontBoundingBoxDescent || 0;
    // the element's box is usually taller than the font's own ascent+descent (line-height leaves
    // half-leading above AND below), so split that surplus between the two sides
    const half = Math.max(0, (el.getBoundingClientRect().height || (asc + desc)) - (asc + desc)) / 2;
    return { top: Math.max(0, asc - (m.actualBoundingBoxAscent || 0)) + half,
             bottom: Math.max(0, desc - (m.actualBoundingBoxDescent || 0)) + half };
  } catch (_) { return { top: 0, bottom: 0 }; }
}
// Equal breathing room between the name, the location and the stars. Equal MARGINS do not look equal:
// each line's box carries its own leading, and the star glyphs in particular sit well inside theirs. So
// the margins are derived from where the ink actually stops and starts.
const TC_ID_GAP = 16;
function tcEvenIdGaps(el) {
  const name = el.querySelector(".tc-name"), sub = el.querySelector(".tc-sub"), stars = el.querySelector(".tc-stars");
  if (!name || !stars) return;
  const iName = tcTextInk(name), iStars = tcTextInk(stars, "★");
  const gap = (aBottom, bTop) => Math.max(0, TC_ID_GAP - aBottom - bTop) + "px";
  if (sub) {
    const iSub = tcTextInk(sub);
    sub.style.marginTop = gap(iName.bottom, iSub.top);
    stars.style.marginTop = gap(iSub.bottom, iStars.top);
  } else {
    stars.style.marginTop = gap(iName.bottom, iStars.top);
  }
}
// Size the product so what you SEE of it starts level with the top of the avatar and ends level with the
// bottom of the stars. Both sides are measured, not assumed: the bottle's opaque box out of its PNG, the
// stars' ink out of the font. The negative top margin pulls the image's transparent cap above the row and
// the wrapper clips it.
async function tcFitProduct(el, url) {
  const idc = el.querySelector(".tc-star-id"), wrap = el.querySelector(".tc-prodwrap");
  if (!idc || !wrap || !url) return;
  tcEvenIdGaps(el);                       // settle the column's own spacing FIRST — it changes its height
  const H = idc.offsetHeight;
  if (!(H > 20)) return;
  const starsEl = el.querySelector(".tc-stars");
  const avEl = el.querySelector(".tc-av");
  const inkTop = (avEl && avEl.tagName === "IMG") ? 0 : (avEl ? tcTextInk(avEl).top : 0);
  const inkBot = starsEl ? tcTextInk(starsEl, "★").bottom : 0;
  const vis = Math.max(20, H - inkTop - inkBot);          // what the eye reads as the column's extent
  const { ft, fb } = await tcProdInset(url);
  const fv = Math.max(0.2, 1 - ft - fb);
  const himg = vis / fv;
  el.style.setProperty("--prod-h", himg.toFixed(2) + "px");
  el.style.setProperty("--prod-lift", (inkTop - ft * himg).toFixed(2) + "px");
  wrap.style.height = H + "px";
}
function tcProdHtml(url) {
  const d = url && tcImgCache[url];
  return d ? `<div class="tc-prodwrap"><img class="tc-prod" src="${d}" alt=""></div>` : "";
}
function tcQueueSave() {
  if (!PROJECT || !DOC) return;
  const proj = PROJECT, cards = DOC.testimonial_cards || [];   // capture now so a project switch can't misroute the save
  clearTimeout(tcSaveTimer);
  tcSaveTimer = setTimeout(() => { api.saveTCards(proj, cards).catch(() => {}); }, 600);
}
// Custom dropdown (green hover, matches the app) — used instead of native <select> whose option
// highlight is the OS blue. options = [{value,label}]. onPick(value) fires on choose.
function tcSelect(current, options, onPick, placeholder) {
  const wrap = document.createElement("div"); wrap.className = "tc-dd";
  const cur = options.find(o => o.value === current);
  const btn = document.createElement("button"); btn.type = "button"; btn.className = "model-btn tc-dd-btn";
  const lab = document.createElement("b"); lab.textContent = cur ? cur.label : (placeholder || "Select…");
  if (!cur) btn.classList.add("tc-dd-ph");
  const car = document.createElement("span"); car.className = "caret"; car.textContent = "▾";
  btn.append(lab, car);
  const menu = document.createElement("div"); menu.className = "model-menu tc-dd-menu"; menu.hidden = true;
  options.forEach(o => {
    const b = document.createElement("button"); b.type = "button"; b.className = "model-opt" + (o.value === current ? " sel" : ""); b.textContent = o.label;
    b.addEventListener("click", (e) => {
      e.stopPropagation(); menu.hidden = true;
      lab.textContent = o.label; btn.classList.toggle("tc-dd-ph", !o.value);   // reflect the choice on the button immediately
      menu.querySelectorAll(".model-opt").forEach(x => x.classList.remove("sel")); b.classList.add("sel");
      onPick(o.value);
    });
    menu.appendChild(b);
  });
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = menu.hidden;
    document.querySelectorAll(".tc-dd-menu").forEach(m => { m.hidden = true; });
    menu.hidden = !willOpen;
  });
  document.addEventListener("click", () => { menu.hidden = true; });
  wrap.append(btn, menu);
  return wrap;
}
// flush pending card edits if the app/tab closes before the debounce fires (best-effort)
window.addEventListener("beforeunload", () => {
  if (!PROJECT || !DOC || !(DOC.testimonial_cards || []).length) return;
  try { navigator.sendBeacon(`/api/testimonial-cards/${PROJECT}/save`, new Blob([JSON.stringify({ cards: DOC.testimonial_cards })], { type: "application/json" })); } catch (e) {}
});
const TCARD_CSS = `
.tcard{ box-sizing:border-box; width:1200px; background:#fff; color:#0b0b0b; font-family:"Segoe UI",Helvetica,Arial,sans-serif; -webkit-font-smoothing:antialiased; }
.tcard *{ box-sizing:border-box; }
.tcard [contenteditable]{ cursor:text; outline:none; }
.tcard [contenteditable]:focus{ outline:1px dashed rgba(0,0,0,.25); border-radius:3px; }
.tcard .tc-av{ object-fit:cover; }
.tcard .tc-loc{ display:inline-flex; align-items:center; gap:6px; }
.tcard .tc-loc svg{ width:1em; height:1em; flex:none; opacity:.85; }
/* Facebook */
.tcard-fb{ width:1420px; border:1px solid #dadde1; border-radius:16px; padding:40px 48px; }
.tcard-fb .tc-hd{ display:flex; align-items:center; gap:22px; }
.tcard-fb .tc-av{ width:122px; height:122px; border-radius:50%; }
.tcard-fb .tc-name{ font-size:37px; font-weight:700; color:#050505; line-height:1.15; }
.tcard-fb .tc-sub{ font-size:26px; color:#65676b; margin-top:5px; }
.tcard-fb .tc-body{ font-size:34px; line-height:1.45; color:#050505; margin:30px 0 28px; white-space:pre-wrap; }
.tcard-fb .tc-stats{ display:flex; align-items:center; justify-content:space-between; font-size:29px; color:#65676b; padding-bottom:24px; border-bottom:1px solid #ced0d4; }
.tcard-fb .tc-react{ display:flex; align-items:center; gap:12px; }
.tcard-fb .tc-emo{ font-size:38px; }
.tcard-fb .tc-actions{ display:flex; flex-wrap:nowrap; white-space:nowrap; justify-content:space-around; padding-top:22px; font-size:31px; font-weight:600; color:#65676b; }
.tcard-fb .tc-actions span{ display:inline-flex; align-items:center; gap:10px; white-space:nowrap; }
/* Gmail-style email (reading a received mail) — wider/rectangular */
.tcard-email{ width:1680px; border:1px solid #e6e6e6; border-radius:14px; padding:0; display:flex; align-items:stretch; overflow:hidden; background-color:#fff; background-image:linear-gradient(90deg, #f6f8fc 0px, #f6f8fc 379px, #eaecef 379px, #eaecef 380px, #fff 380px, #fff 100%); background-repeat:no-repeat; }
/* left Gmail sidebar column */
.tcard-email .tc-gmailbar{ width:380px; flex:none; background:#f6f8fc; border-right:1px solid #eaecef; padding:26px 18px; }
.tcard-email .tc-gmail-top{ display:flex; align-items:center; gap:14px; padding:0 8px 6px; }
.tcard-email .tc-gmail-top .tc-ic{ width:34px; height:34px; color:#5f6368; flex:none; }
.tcard-email .tc-gmail-logo{ display:inline-flex; }
.tcard-email .tc-gmail-logo svg{ width:42px; height:auto; display:block; }
.tcard-email .tc-gmail-word{ font-size:34px; color:#5f6368; }
.tcard-email .tc-compose{ display:inline-flex; align-items:center; gap:16px; margin:26px 6px; padding:18px 30px; background:#c2e7ff; border-radius:20px; font-size:27px; color:#001d35; font-weight:500; }
.tcard-email .tc-compose .tc-ic{ width:30px; height:30px; color:#001d35; flex:none; }
.tcard-email .tc-navlist{ display:flex; flex-direction:column; gap:2px; }
.tcard-email .tc-nav{ display:flex; align-items:center; gap:20px; padding:13px 22px; border-radius:0 22px 22px 0; font-size:25px; color:#202124; }
.tcard-email .tc-nav .tc-ic{ width:28px; height:28px; color:#5f6368; flex:none; }
.tcard-email .tc-nav .tc-nav-l{ flex:1; }
.tcard-email .tc-nav .tc-nav-c{ font-size:21px; color:#202124; }
.tcard-email .tc-nav.on{ background:#d3e3fd; font-weight:700; }
.tcard-email .tc-nav.on .tc-ic{ color:#001d35; }
.tcard-email .tc-nav.on .tc-nav-c{ font-weight:700; }
.tcard-email .tc-labels{ display:flex; align-items:center; justify-content:space-between; margin-top:24px; padding:12px 22px 0; font-size:25px; color:#202124; border-top:1px solid #e6e9ee; padding-top:22px; }
.tcard-email .tc-lab-plus{ color:#5f6368; font-size:30px; }
/* right reading pane */
.tcard-email .tc-mail{ flex:1; min-width:0; padding:44px 52px 52px; }
.tcard-email .tc-subj{ font-size:42px; font-weight:400; color:#202124; margin-bottom:30px; }
.tcard-email .tc-hdrow{ display:flex; align-items:flex-start; gap:24px; padding-bottom:28px; border-bottom:1px solid #f1f1f1; }
.tcard-email .tc-av{ width:104px; height:104px; border-radius:50%; }
.tcard-email .tc-meta{ flex:1; min-width:0; }
.tcard-email .tc-fromrow{ display:flex; align-items:baseline; gap:12px; flex-wrap:wrap; }
.tcard-email .tc-from{ font-size:30px; color:#202124; font-weight:700; }
.tcard-email .tc-email{ font-size:24px; color:#5f6368; filter:blur(4.5px); }
.tcard-email .tc-to{ font-size:24px; color:#5f6368; margin-top:6px; }
.tcard-email .tc-date{ font-size:24px; color:#5f6368; white-space:nowrap; }
.tcard-email .tc-body{ font-size:31px; line-height:1.6; color:#202124; margin-top:34px; white-space:pre-wrap; }
.tcard-email .tc-sign{ font-size:30px; color:#202124; margin-top:28px; white-space:pre-wrap; }
/* Star review — header row (avatar+name+location+stars cluster beside the product), then CENTERED text below */
.tcard-star{ width:1680px; border:1px solid #ececec; border-radius:18px; padding:26px 68px; text-align:center; }
/* The identity column and the product must line up by what you SEE: avatar top level with the top of the
   bottle, stars level with its bottom. The product PNGs make that impossible to hardcode — the 1-pack is
   portrait and fills its frame, the multi-packs are landscape with 4-6% transparent margin plus a soft
   shadow — so tcFitProduct() measures each image's opaque box and sets --prod-h / --prod-lift on the card.
   Until it has, the fallback below just shows the product at a sane size. */
.tcard-star .tc-star-head{ display:flex; align-items:flex-start; justify-content:center; gap:72px; }
.tcard-star .tc-star-id{ display:flex; flex-direction:column; align-items:center; }
.tcard-star .tc-id-main{ display:flex; flex-direction:column; align-items:center; }
.tcard-star .tc-av{ width:172px; height:172px; border-radius:50%; margin:0 0 12px; }
.tcard-star .tc-name{ font-size:40px; font-weight:700; color:#111; }
.tcard-star .tc-sub{ font-size:26px; color:#888; margin-top:6px; }
.tcard-star .tc-stars{ display:inline-flex; gap:12px; font-size:56px; margin-top:18px; }
.tcard-star .tc-star{ cursor:pointer; }
.tcard-star .tc-on{ color:#f5b301; }
.tcard-star .tc-off{ color:#dcdcdc; }
.tcard-star .tc-prodwrap{ flex:none; display:block; overflow:hidden; }
.tcard-star .tc-prod{ display:block; width:auto; height:var(--prod-h,360px); margin-top:var(--prod-lift,0px); }
.tcard-star .tc-body{ font-size:33px; line-height:1.44; color:#2b2b2b; margin:12px auto 0; max-width:1200px; text-align:center; text-wrap:balance; white-space:pre-wrap; }
`;
function ensureTCardCss() { if (!$("#tcardCss")) { const s = document.createElement("style"); s.id = "tcardCss"; s.textContent = TCARD_CSS; document.head.appendChild(s); } }
// Wrap card HTML on a WHITE 16:9 canvas (card centred, contained) so the produced PNG / karaoke clip drops
// straight into a 1920×1080 VSL with clean white fill on the sides — no black bars, no cropping.
// The 16:9 white frame a card sits in. Sized off the card's OWN width, and grown when the card is too tall
// for that box, so a fixed share of the height (TC16_PAD each side) always stays blank above and below —
// the card never runs edge-to-edge. Growing the frame beats scaling the card: the PNG is fitted to the same
// 16:9 video slot either way, so it reads as "everything got smaller", but the text is still rendered at
// native size instead of through a transform. Past TC16_MAXH (keeps W under the server's 4096 clamp) it
// does scale, via the returned k. Shared by tc16() and the Assemble preview so the two can't drift apart.
const TC16_PAD = 0.055, TC16_MAXH = 2160;
function tc16Frame(cw, ch) {
  const R = 16 / 9;
  let k = 1;
  let H = Math.max(Math.ceil(cw / R), Math.ceil(ch / (1 - 2 * TC16_PAD)));
  if (H > TC16_MAXH) { k = TC16_MAXH * (1 - 2 * TC16_PAD) / ch; H = TC16_MAXH; }
  let W = Math.round(H * R);
  if (W < cw) { W = Math.ceil(cw); H = Math.ceil(W / R); }   // rounding must never clip the card (.tc-pad16 is overflow:hidden)
  W += W & 1; H += H & 1;                                    // even dimensions — the karaoke render feeds these straight to libx264
  return { W, H, k };
}
function tc16(innerHtml, cw, ch, extraCss) {
  if (!(cw > 1) || !(ch > 1)) return null;   // card not laid out (hidden tab → offsetWidth 0) → don't bake a 0×0 canvas
  const { W, H, k } = tc16Frame(cw, ch);
  const fitCss = k < 1 ? ` .tc-pad16 > *{ transform:scale(${k.toFixed(4)}); transform-origin:center; }` : "";
  const style = `${TCARD_CSS} html,body{margin:0;padding:0;background:#fff;} .tc-pad16{width:${W}px;height:${H}px;background:#fff;display:flex;align-items:center;justify-content:center;overflow:hidden;} .tcard-fb,.tcard-email,.tcard-star{border-color:transparent;}${fitCss}${extraCss || ""}`;
  const html = `<!doctype html><html><head><meta charset="utf-8"><style>${style}</style></head><body><div class="tc-pad16">${innerHtml}</div></body></html>`;
  return { html, w: W, h: H };
}
// Build the karaoke render HTML ({html,w,h}) from a LAID-OUT card element (clone + wrap each body word in
// .kw[data-i] + a script that reports each word's box). Works from the testimonial editor OR the Assemble
// preview (both have a visible card), so a good version gets stored either way. null if not laid out.
// display:none, NOT an off-screen offset. This div holds one white-space:pre line of JSON — one entry per
// word — and on a long testimonial that line grew past the 99999px it was parked at, so its tail spilled
// back onto the canvas and got baked into the top of the rendered card. The DOM dump that reads it back
// serialises hidden elements just the same, so hiding it outright costs nothing.
const TC_KARA_MEASURE = '<div id="__rects" style="display:none;"></div><script>(function(){try{var o=[],e=document.querySelectorAll(".kw");for(var i=0;i<e.length;i++){if(e[i].getAttribute("data-i")===null)continue;var r=e[i].getBoundingClientRect();o.push({i:parseInt(e[i].getAttribute("data-i"),10),x:r.left,y:r.top,w:r.width,h:r.height});}document.getElementById("__rects").textContent=JSON.stringify(o);}catch(_){}})();<\/script>';
function tcMakeKaraHtml(cardEl) {
  if (!cardEl) return null;
  const cw = Math.max(cardEl.offsetWidth, cardEl.scrollWidth), ch = Math.max(cardEl.offsetHeight, cardEl.scrollHeight);
  if (!(cw > 1) || !(ch > 1)) return null;
  const clone = cardEl.cloneNode(true);
  clone.querySelectorAll(".kw-on").forEach(e => e.classList.remove("kw-on"));   // never bake a live highlight into the render source
  const body = clone.querySelector('[data-role="text"]');
  if (body) {
    body.setAttribute("contenteditable", "false");
    const frag = document.createDocumentFragment(); let wi = 0;
    (body.innerText || body.textContent || "").split(/(\s+)/).forEach(tok => {
      if (tok === "") return;
      if (/^\s+$/.test(tok) || !/[\p{L}\p{N}]/u.test(tok)) { frag.appendChild(document.createTextNode(tok)); return; }   // whitespace / punctuation-only ("—") is not a word → no data-i (keeps rect↔word index aligned)
      const sp = document.createElement("span"); sp.className = "kw"; sp.setAttribute("data-i", wi++); sp.textContent = tok; frag.appendChild(sp);
    });
    body.innerHTML = ""; body.appendChild(frag);
  }
  return tc16(clone.outerHTML + TC_KARA_MEASURE, cw, ch);
}
function tcBuildFB(c, text, ex) {
  const el = document.createElement("div"); el.className = "tcard tcard-fb";
  const loc = tcEsc(c.location || "");
  const locHtml = loc ? `<span class="tc-loc">${TC_PIN_SVG}${loc}</span>` : "🌐";
  el.innerHTML =
    `<div class="tc-hd">${tcAvatarHtml(c)}<div><div class="tc-name">${tcEsc(c.name || "")}</div>` +
    `<div class="tc-sub"><span contenteditable="true" data-k="date">${tcEsc(ex.date ?? "2d")}</span> · ${locHtml}</div></div></div>` +
    `<div class="tc-body" data-role="text">${tcTextHtml(text)}</div>` +
    `<div class="tc-stats"><span class="tc-react"><span class="tc-emo">👍❤️</span> <span contenteditable="true" data-k="likes">${tcEsc(ex.likes ?? "128")}</span></span>` +
    `<span><span contenteditable="true" data-k="comments">${tcEsc(ex.comments ?? "24")}</span> comments</span></div>` +
    `<div class="tc-actions"><span>👍 Like</span><span>💬 Comment</span><span>↪ Share</span></div>`;
  return el;
}
function tcBuildEmail(c, text, ex) {
  const el = document.createElement("div"); el.className = "tcard tcard-email";
  const loc = tcEsc(c.location || "");
  const nav = [
    { ic: "inbox", label: "Inbox", count: tcEsc(ex.inbox ?? "6,126"), kc: "inbox", on: true },
    { ic: "star", label: "Starred" },
    { ic: "clock", label: "Snoozed" },
    { ic: "sent", label: "Sent" },
    { ic: "bag", label: "Purchases" },
    { ic: "more", label: "More" },
  ];
  const navHtml = nav.map(n => {
    const cnt = n.kc ? `<span class="tc-nav-c" contenteditable="true" data-k="${n.kc}">${n.count}</span>` : (n.count ? `<span class="tc-nav-c">${n.count}</span>` : "");
    return `<div class="tc-nav${n.on ? " on" : ""}">${tcIcon(n.ic)}<span class="tc-nav-l">${n.label}</span>${cnt}</div>`;
  }).join("");
  el.innerHTML =
    `<div class="tc-gmailbar">` +
      `<div class="tc-gmail-top">${tcIcon("menu")}<span class="tc-gmail-logo">${TC_GMAIL_SVG}</span><span class="tc-gmail-word">Gmail</span></div>` +
      `<div class="tc-compose">${tcIcon("compose")}<span>Compose</span></div>` +
      `<div class="tc-navlist">${navHtml}</div>` +
      `<div class="tc-labels"><span>Labels</span><span class="tc-lab-plus">+</span></div>` +
    `</div>` +
    `<div class="tc-mail">` +
      `<div class="tc-subj" contenteditable="true" data-k="subject">${tcEsc(ex.subject ?? "Thank you — this changed everything")}</div>` +
      `<div class="tc-hdrow">${tcAvatarHtml(c)}` +
      `<div class="tc-meta"><div class="tc-fromrow"><span class="tc-from">${tcEsc(c.name || "")}</span>` +
      `<span class="tc-email">&lt;<span contenteditable="true" data-k="email">${tcEsc(ex.email ?? tcEmailFor(c.name))}</span>&gt;</span></div>` +
      `<div class="tc-to">to me ▾</div></div>` +
      `<div class="tc-date" contenteditable="true" data-k="date">${tcEsc(ex.date ?? tcGmailDate())}</div></div>` +
      `<div class="tc-body" data-role="text">${tcTextHtml(text)}</div>` +
      `<div class="tc-sign">— ${tcEsc(c.name || "")}${loc ? `<br>${loc}` : ""}</div>` +
    `</div>`;
  return el;
}
function tcBuildStar(c, text, ex) {
  const el = document.createElement("div"); el.className = "tcard tcard-star";
  const rating = Math.max(1, Math.min(5, parseInt(ex.rating || 5, 10) || 5));
  const sub = c.location ? `<span class="tc-loc">${TC_PIN_SVG}${tcEsc(c.location)}</span>` : "";
  let stars = ""; for (let i = 1; i <= 5; i++) stars += `<span class="tc-star ${i <= rating ? "tc-on" : "tc-off"}" data-star="${i}">★</span>`;
  const prodUrl = ex.prod || tcDefaultProd();
  el.innerHTML =
    `<div class="tc-star-head">` +
      `<div class="tc-star-id">` +
      `<div class="tc-id-main">` +
        tcAvatarHtml(c) +
        `<div class="tc-name">${tcEsc(c.name || "")}</div>` +
        (sub ? `<div class="tc-sub">${sub}</div>` : "") +
      `</div>` +
      `<div class="tc-stars">${stars}</div>` +
      `</div>` +
      tcProdHtml(prodUrl) +
    `</div>` +
    `<div class="tc-body" data-role="text"${tcBodyWidthStyle(ex)}>${tcTextHtml(text)}</div>`;
  return el;
}
function tcWireCard(el, remeasure, card, onEdit) {
  el.querySelectorAll("[contenteditable][data-k]").forEach(f => {
    // editing a field (date, subject/title, likes, comments…) saves the value AND re-syncs the linked scene
    // image via onEdit — without it, deleting the title/date persisted but the mirrored scene stayed stale.
    f.addEventListener("input", () => { tcEx(card)[f.dataset.k] = f.textContent; tcQueueSave(); if (remeasure) remeasure(); if (onEdit) onEdit(); });
  });
  el.querySelectorAll("[data-star]").forEach(st => {
    st.addEventListener("click", () => {
      const v = parseInt(st.dataset.star, 10); tcEx(card).rating = v; tcQueueSave();
      el.querySelectorAll("[data-star]").forEach(s2 => { const on = parseInt(s2.dataset.star, 10) <= v; s2.classList.toggle("tc-on", on); s2.classList.toggle("tc-off", !on); });
      if (onEdit) onEdit();
    });
  });
}
let tcJustAddedId = null;   // id of a just-added card, so it gets a smooth entrance animation on the next render
// smoothly remove a testimonial card: fade the leaving card out, then slide the remaining cards up (FLIP)
function tcAnimateRemoveCard(card, box) {
  const list = box.closest(".tc-list");
  const prev = {};
  if (list) [...list.querySelectorAll(".tc-editor")].forEach(el => { if (el !== box && el.dataset.cid) prev[el.dataset.cid] = el.getBoundingClientRect(); });
  box.style.transition = "opacity .2s ease, transform .2s ease";
  box.style.opacity = "0";
  box.style.transform = "scale(.97)";
  const sib = box.previousElementSibling && box.previousElementSibling.classList.contains("tc-divider") ? box.previousElementSibling
            : (box.nextElementSibling && box.nextElementSibling.classList.contains("tc-divider") ? box.nextElementSibling : null);
  if (sib) { sib.style.transition = "opacity .2s ease"; sib.style.opacity = "0"; }
  setTimeout(() => {
    DOC.testimonial_cards = (DOC.testimonial_cards || []).filter(c => c.id !== card.id);
    tcQueueSave(); renderTCards();
    const nlist = tcHost && tcHost.querySelector(".tc-list");
    if (!nlist) return;
    const cards2 = [...nlist.querySelectorAll(".tc-editor")].filter(el => prev[el.dataset.cid]);
    cards2.forEach(el => { const now = el.getBoundingClientRect(); const dy = prev[el.dataset.cid].top - now.top; if (dy) { el.style.transition = "none"; el.style.transform = `translateY(${dy}px)`; } });
    requestAnimationFrame(() => cards2.forEach(el => { el.style.transition = "transform .32s cubic-bezier(.45,0,.15,1)"; el.style.transform = ""; }));
  }, 200);
}
function renderTCards() {
  const host = tcHost; if (!host) return;
  ensureTCardCss();
  const chars = (DOC && DOC.testimonials) || [];
  const sec = host.closest(".tc-section");
  if (sec) sec.hidden = !chars.length;   // hide the whole Create-Testimonial area until a character exists
  host.innerHTML = "";
  if (!chars.length) return;
  DOC.testimonial_cards = DOC.testimonial_cards || [];

  const addBar = document.createElement("div"); addBar.className = "tc-addbar";
  const addWrap = document.createElement("div"); addWrap.className = "tc-dd tc-add-dd";
  const addB = document.createElement("button"); addB.type = "button"; addB.className = "primary tc-add"; addB.textContent = "＋ Add Testimonial";
  const addMenu = document.createElement("div"); addMenu.className = "model-menu tc-dd-menu tc-add-menu"; addMenu.hidden = true;
  const mkAdd = (label, type) => {
    const b = document.createElement("button"); b.type = "button"; b.className = "model-opt"; b.textContent = label;
    b.addEventListener("click", (e) => {
      e.stopPropagation(); addMenu.hidden = true;
      const nid = Math.random().toString(36).slice(2, 10);
      DOC.testimonial_cards.push({ id: nid, type, format: "facebook", charId: (chars[0] ? chars[0].id : ""), text: "", extra: {} });
      tcJustAddedId = nid;                       // mark it so the new card animates in smoothly
      tcQueueSave(); renderTCards();
    });
    return b;
  };
  addMenu.append(mkAdd("Written Testimonial", "written"), mkAdd("Video Testimonial", "video"));
  addB.addEventListener("click", (e) => { e.stopPropagation(); const open = addMenu.hidden; document.querySelectorAll(".tc-dd-menu").forEach(m => m.hidden = true); addMenu.hidden = !open; });
  document.addEventListener("click", () => { addMenu.hidden = true; });
  addWrap.append(addB, addMenu); addBar.appendChild(addWrap); host.appendChild(addBar);

  if (!DOC.testimonial_cards.length) return;   // just the Add button when empty

  const list = document.createElement("div"); list.className = "tc-list";
  DOC.testimonial_cards.forEach((card, i) => {
    if (i > 0) { const dv = document.createElement("div"); dv.className = "tc-divider"; list.appendChild(dv); }   // separator line between cards
    const ed = buildTCardEditor(card, i);
    if (card.id === tcJustAddedId) ed.classList.add("tc-enter");   // the just-added card animates in
    list.appendChild(ed);
  });
  tcJustAddedId = null;
  host.appendChild(list);
}
// ---------- Video Testimonial editor ----------
let tcVoices = null;   // cached ElevenLabs voices [{name, voice_id}]
const TV_CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-11"/></svg>';
const TV_DL_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
const TV_REFRESH_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-.9 4.5"/><path d="M20 4v6h-6"/></svg>';
function buildTVEditor(card, idx) {
  card.extra = card.extra || {};
  const e = card.extra;
  const chars = (DOC && DOC.testimonials) || [];
  const box = document.createElement("div"); box.className = "tc-editor tv-editor"; box.dataset.cid = card.id;
  const linkedScene = ((DOC && DOC.scenes) || []).find(sc => sc.tcard_id === card.id);   // this video card mirrors its still into a VSL scene

  // controls: "#N Video Testimonial" label + character picker + delete
  const controls = document.createElement("div"); controls.className = "tc-controls";
  const main = document.createElement("div"); main.className = "tc-ctrls-main";
  const clbl = document.createElement("span"); clbl.className = "tc-cardnum scene-num"; clbl.textContent = `#${(idx || 0) + 1}`; main.appendChild(clbl);
  if (linkedScene) { const lk = document.createElement("button"); lk.type = "button"; lk.className = "tc-scenelink"; lk.textContent = `Scene #${linkedScene.id}`; lk.title = "Go to this scene in Scene & Image"; lk.addEventListener("click", (e2) => { e2.stopPropagation(); activateTab("scenes"); jumpToScene(linkedScene.id); }); main.appendChild(lk); }
  const charOpts = [{ value: "", label: "— Select character —" }].concat(chars.map(c => ({ value: c.id, label: c.name || "(unnamed)" })));
  main.appendChild(tcSelect(card.charId || "", charOpts, async (val) => { card.charId = val; tcQueueSave(); const ch2 = tcCharById(card.charId); if (ch2) await loadTcImg(ch2); renderTCards(); }, "— Select character —"));
  controls.appendChild(main);
  const _typeDd = tcSelect(card.type || "video", [{ value: "written", label: "Written Testimonial" }, { value: "video", label: "Video Testimonial" }], (val) => { if (val && val !== card.type) { card.type = val; tcQueueSave(); renderTCards(); } }, "Type"); _typeDd.classList.add("tc-typedd");
  const del = document.createElement("button"); del.type = "button"; del.className = "ghost tc-del"; del.title = "Delete this testimonial"; del.innerHTML = TRASH_SVG;
  del.addEventListener("click", async () => {
    if (!(await confirmDialog("Delete this testimonial?", { title: "Delete Testimonial", okText: "Delete", danger: true }))) return;
    tcAnimateRemoveCard(card, box);
  });
  const _rightG = document.createElement("div"); _rightG.className = "tc-ctrls-right"; _rightG.append(_typeDd, del); controls.appendChild(_rightG);   // type dd + trash grouped at the right, same row
  box.appendChild(controls);

  const ch = tcCharById(card.charId);
  if (!ch) { const h = document.createElement("div"); h.className = "hint tc-hint"; h.textContent = "Pick a character to build a video testimonial."; box.appendChild(h); return box; }
  loadTcImg(ch);

  const pushToScene = async (url) => {   // reflect the generated selfie STILL into the linked scene (video-player icon is added by renderScenes)
    if (!linkedScene || !url) return;
    try {
      const s2 = await api.tcardToScene(PROJECT, card.id, url);
      if (!s2 || s2.error) { toast(`Testimonial → scene failed${(s2 && s2.error) ? ": " + s2.error : ""}`, "err", 6000); return; }
      const sc = ((DOC && DOC.scenes) || []).find(x => x.id === s2.sceneId);
      if (sc) { const im = sc.image = sc.image || {}; im.versions = im.versions || []; const ti = im.versions.findIndex(v => (v || "").includes("_tc_")); if (ti >= 0) im.versions[ti] = s2.url; else im.versions.push(s2.url); const idx = ti >= 0 ? ti : im.versions.length - 1; im.current = idx; im.approved_version = idx; im.status = "ready"; im.taskId = null; im.error = null; sc.approved = true; sc._appLock = Date.now() + 8000; }   // guard against a stale in-flight poll wiping the just-synced still
      if (typeof renderScenes === "function") { try { renderScenes(); } catch (_) {} }
      toast(`Video testimonial still synced → Scene #${s2.sceneId}`, "ok", 2500);
    } catch (e) { toast("Testimonial sync error: " + e, "err", 6000); }
  };

  // 1) IMAGE builder: photo | environment + dimension + generate | result
  const row = document.createElement("div"); row.className = "tv-row";
  const photo = document.createElement("div"); photo.className = "tv-photo";
  const pim = document.createElement("img"); pim.alt = ""; const purl = tcCharUrl(ch); if (purl) setRefImg(pim, purl);
  photo.appendChild(pim); row.appendChild(photo);
  const mid = document.createElement("div"); mid.className = "tv-mid";
  const envTa = document.createElement("textarea"); envTa.className = "tc-text tv-env"; envTa.rows = 3; envTa.spellcheck = false;
  envTa.placeholder = "Describe the background / environment for the new selfie-video image (e.g. at home on the sofa, a bright kitchen, outdoors in a park)…";
  envTa.value = e.env || ""; envTa.addEventListener("input", () => { e.env = envTa.value; tcQueueSave(); });
  mid.appendChild(envTa);
  const dimRow = document.createElement("div"); dimRow.className = "tv-dimrow";
  const dimDD = tcSelect(e.dim || "vertical", [{ value: "horizontal", label: "Horizontal (16:9)" }, { value: "square", label: "Square (1:1)" }, { value: "vertical", label: "Vertical (9:16)" }], (val) => { e.dim = val; tcQueueSave(); renderImg(); }, "Format");
  dimDD.classList.add("tv-dimdd"); dimRow.appendChild(dimDD);
  const genImgB = document.createElement("button"); genImgB.type = "button"; genImgB.className = "primary tv-genimg"; genImgB.textContent = "Generate Image";
  dimRow.appendChild(genImgB); mid.appendChild(dimRow); row.appendChild(mid);
  const imgWrap = document.createElement("div"); imgWrap.className = "tv-imgwrap"; row.appendChild(imgWrap);
  box.appendChild(row);

  const renderImg = () => {
    imgWrap.innerHTML = "";
    imgWrap.classList.remove("tv-vert", "tv-sq", "tv-horz");
    imgWrap.classList.add(e.dim === "square" ? "tv-sq" : e.dim === "horizontal" ? "tv-horz" : "tv-vert");
    if (e.image && e.image.url) {
      const full = mediaUrl(e.image.url);   // full-res, not the tiny thumb (fixes low-res preview)
      imgWrap.classList.toggle("tv-approved-frame", !!e.image.approved);
      const im = document.createElement("img"); im.alt = ""; im.src = full; im.style.cursor = "zoom-in";
      im.addEventListener("click", () => lightbox(full, "img"));
      imgWrap.appendChild(im);
      const mag = document.createElement("div"); mag.className = "tv-mag"; mag.innerHTML = TP_ZOOM_SVG;   // hover magnifier hint
      imgWrap.appendChild(mag);
      // top-right actions — identical to Scenes & Images (.img-actions + .ia)
      const ov = document.createElement("div"); ov.className = "img-actions";
      const bApprove = document.createElement("button"); bApprove.className = "ia approve" + (e.image.approved ? " on" : ""); bApprove.title = e.image.approved ? "Approved (click to unapprove)" : "Approve"; bApprove.textContent = "✓";
      bApprove.addEventListener("click", (ev) => { ev.stopPropagation(); const willApprove = !e.image.approved; e.image.approved = willApprove; tcQueueSave(); if (willApprove) approveBurst(imgWrap); renderImg(); renderVideoSection(); });
      const bChange = document.createElement("button"); bChange.className = "ia change"; bChange.title = "Change (regenerate)"; bChange.textContent = "↻";
      bChange.addEventListener("click", (ev) => { ev.stopPropagation(); doGenImage(bChange); });
      const bRemove = document.createElement("button"); bRemove.className = "ia remove"; bRemove.title = "Delete this image"; bRemove.innerHTML = TRASH_SVG;
      bRemove.addEventListener("click", (ev) => { ev.stopPropagation(); e.image = null; tcQueueSave(); renderImg(); renderVideoSection(); });
      ov.append(bApprove, bChange, bRemove); imgWrap.appendChild(ov);
      // bottom-right download — same design, overlaid bottom-right
      const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";
      const bDl = document.createElement("button"); bDl.className = "ia download"; bDl.title = "Download this image";
      bDl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
      bDl.addEventListener("click", (ev) => { ev.stopPropagation(); downloadMedia(e.image.url, `video_testimonial_${slug(ch.name || "card")}.png`, "image"); });
      ovb.appendChild(bDl); imgWrap.appendChild(ovb);
    } else {
      imgWrap.classList.remove("tv-approved-frame");
      const ph = document.createElement("div"); ph.className = "tv-imgph"; ph.textContent = "Your generated image will appear here"; imgWrap.appendChild(ph);
    }
  };
  const doGenImage = (btn) => withBusy(btn || genImgB, async () => {
    imgWrap.classList.add("tv-img-loading");   // spinner over the image placeholder too, not just on the button
    let r; try { r = await api.tvGenImage(PROJECT, card.id, card.charId, e.env || "", e.dim || "vertical"); } catch (x) { r = { error: "request failed" }; }
    imgWrap.classList.remove("tv-img-loading");
    if (r.error || !r.url) { toast(r.error || "generation failed", "err", 7000); return; }
    e.image = { url: r.url, approved: false }; tcEx(card).producedSig = "tv:" + r.url; tcQueueSave(); renderImg(); renderVideoSection();
    pushToScene(r.url);   // reflect the new still into the linked scene right away
  });
  genImgB.addEventListener("click", () => doGenImage(genImgB));

  // 2) SCRIPT + VOICEOVER (split)
  const sh = document.createElement("div"); sh.className = "tv-sec-h"; sh.textContent = "Script & Voiceover"; box.appendChild(sh);
  const split = document.createElement("div"); split.className = "tv-split";
  const sl = document.createElement("div"); sl.className = "tv-split-l";
  const scriptTa = document.createElement("textarea"); scriptTa.className = "tc-text tv-script"; scriptTa.rows = 6; scriptTa.spellcheck = false; scriptTa.placeholder = "Write the video-testimonial script (what the person says on camera)…"; scriptTa.value = card.text || "";
  scriptTa.addEventListener("input", () => { card.text = scriptTa.value; tcQueueSave(); });
  sl.appendChild(scriptTa); split.appendChild(sl);
  const sr = document.createElement("div"); sr.className = "tv-split-r";
  // Voice ID field (enter directly, like the Script & Voiceover tab)
  const vidField = document.createElement("label"); vidField.className = "field tv-vidfield";
  const vidSpan = document.createElement("span"); vidSpan.textContent = "Voice ID"; vidField.appendChild(vidSpan);
  const vidInput = document.createElement("input"); vidInput.type = "text"; vidInput.placeholder = "ElevenLabs voice ID"; vidInput.value = e.voiceId || "";
  vidInput.addEventListener("input", () => { e.voiceId = vidInput.value.trim(); tcQueueSave(); });
  vidField.appendChild(vidInput); sr.appendChild(vidField);
  // manage row: "+ Save Current" (left) + Saved Voices quick-pick (right) — like the Script & Voiceover tab
  const voiceOpts = [{ value: "", label: "🎧 Saved Voices" }].concat((tcVoices || []).map(v => ({ value: v.voice_id, label: v.name })));
  const voManage = document.createElement("div"); voManage.className = "tv-vomanage";
  const saveCur = document.createElement("button"); saveCur.type = "button"; saveCur.className = "ghost tv-savecur"; saveCur.textContent = "+ Save Current";
  const savedDD = tcSelect("", voiceOpts, (val) => { if (val) { e.voiceId = val; vidInput.value = val; tcQueueSave(); } }, "🎧 Saved Voices");
  savedDD.classList.add("tv-saveddd");
  voManage.append(saveCur, savedDD); sr.appendChild(voManage);
  const saveForm = document.createElement("div"); saveForm.className = "tv-saveform"; saveForm.hidden = true;
  const svName = document.createElement("input"); svName.type = "text"; svName.className = "tv-savename"; svName.placeholder = "Name (e.g. Loretta Jophlin)";
  const svOk = document.createElement("button"); svOk.type = "button"; svOk.className = "primary tv-savego"; svOk.textContent = "Save";
  saveForm.append(svName, svOk); sr.appendChild(saveForm);
  saveCur.addEventListener("click", () => { saveForm.hidden = !saveForm.hidden; if (!saveForm.hidden) svName.focus(); });
  svOk.addEventListener("click", async () => {
    const nm = svName.value.trim(); const vid = (e.voiceId || "").trim();
    if (!nm) { toast("Enter a name", "err"); return; }
    if (!vid) { toast("Enter a Voice ID first", "err"); return; }
    let r; try { r = await api.addVoice(nm, vid); } catch (x) { r = { error: "failed" }; }
    if (r && r.error) { toast(r.error, "err"); return; }
    tcVoices = null; toast(`Saved voice “${nm}”`, "ok"); renderTCards();
  });
  const genVo = document.createElement("button"); genVo.type = "button"; genVo.className = "primary tv-genvo"; genVo.textContent = "🎙️ Generate Voiceover";
  genVo.addEventListener("click", () => withBusy(genVo, async () => {
    const vid = (e.voiceId || "").trim();
    if (!vid) { toast("Enter or pick a Voice ID first", "err"); return; }
    if (!(card.text || "").trim()) { toast("Write the script first", "err"); return; }
    let r; try { r = await api.tvVoiceover(PROJECT, card.id, vid, card.text); } catch (x) { r = { error: "request failed" }; }
    if (r.error || !r.url) { toast(r.error || "voiceover failed", "err", 7000); return; }
    e.vo = r.url; tcQueueSave(); renderVo(); renderVideoSection();
  }));
  sr.appendChild(genVo);
  const voBox = document.createElement("div"); voBox.className = "tv-vobox"; sr.appendChild(voBox);
  // optional upload — file-drop style, like the Script & Voiceover tab
  const drop = document.createElement("label"); drop.className = "file-drop tv-updrop";
  const fdLabel = document.createElement("span"); fdLabel.className = "fd-label"; fdLabel.textContent = "🎵 Upload voice-over (.mp3, .wav)";
  const fdName = document.createElement("span"); fdName.className = "fd-name"; fdName.textContent = "No file selected";
  drop.append(fdLabel, fdName);
  const upI = document.createElement("input"); upI.type = "file"; upI.accept = "audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus"; upI.hidden = true;
  upI.addEventListener("change", async (ev) => {
    const f = ev.target.files[0]; if (!f) return;
    fdName.textContent = f.name;
    let r; try { r = await api.tvUploadAudio(PROJECT, card.id, f); } catch (x) { r = { error: "upload failed" }; }
    if (r.error || !r.url) { toast(r.error || "upload failed", "err"); return; }
    e.vo = r.url; tcQueueSave(); renderVo(); renderVideoSection();
  });
  drop.appendChild(upI); sr.appendChild(drop); split.appendChild(sr); box.appendChild(split);
  const renderVo = () => { voBox.innerHTML = ""; if (e.vo) { const a = document.createElement("audio"); a.controls = true; a.src = mediaUrl(e.vo); voBox.appendChild(a); } };
  if (tcVoices === null) api.getVoices().then(v => { tcVoices = v || []; renderTCards(); }).catch(() => { tcVoices = []; });

  // 3) VIDEO generation (prompt + model + button) — shown once image is approved AND a voiceover exists
  const vsec = document.createElement("div"); vsec.className = "tv-vsec"; box.appendChild(vsec);
  const renderVideoSection = () => {
    vsec.innerHTML = "";
    if (!(e.image && e.image.approved && e.vo)) { const h = document.createElement("div"); h.className = "hint tv-vhint"; h.textContent = "Approve the image and add a voiceover to generate the testimonial video."; vsec.appendChild(h); return; }
    const vh = document.createElement("div"); vh.className = "tv-sec-h"; vh.textContent = "Testimonial Video"; vsec.appendChild(vh);
    const vpRow = document.createElement("div"); vpRow.className = "tv-vprow";
    const vpTa = document.createElement("textarea"); vpTa.className = "tc-text tv-vprompt"; vpTa.rows = 3; vpTa.spellcheck = false; vpTa.placeholder = "Prompt for the testimonial video (motion, delivery, camera feel…)"; vpTa.value = e.videoPrompt || "";
    vpTa.addEventListener("input", () => { e.videoPrompt = vpTa.value; tcQueueSave(); });
    vpRow.appendChild(vpTa);
    const vpRight = document.createElement("div"); vpRight.className = "tv-vpright";   // model on top, Generate under it
    const vmDD = tcSelect(e.videoModel || "infinitalk/from-audio", [{ value: "infinitalk/from-audio", label: "InfiniTalk (lip-sync)" }], (val) => { e.videoModel = val; tcQueueSave(); }, "Model");
    vmDD.classList.add("tv-vmdd"); vpRight.appendChild(vmDD);
    const gvB = document.createElement("button"); gvB.type = "button"; gvB.className = "primary tv-genvid"; gvB.textContent = "Generate Testimonial Video";
    gvB.addEventListener("click", () => withBusy(gvB, async () => {
      let r; try { r = await api.tvGenVideo(PROJECT, card.id, (e.image && e.image.url) || "", e.vo || "", e.videoPrompt || "", "720p"); } catch (x) { r = { error: "request failed" }; }
      if (r.error || !r.url) { toast(r.error || "video generation failed", "err", 8000); return; }
      e.video = { url: r.url }; tcQueueSave(); renderVideoSection(); toast("Testimonial video ready.", "ok");
    }));
    vpRight.appendChild(gvB);
    vpRow.appendChild(vpRight); vsec.appendChild(vpRow);
    const note = document.createElement("div"); note.className = "hint tv-vnote"; note.textContent = "InfiniTalk lip-sync — the voiceover must be 15 seconds or less."; vsec.appendChild(note);
    if (e.video && e.video.url) {   // finished video: player + download
      const vw = document.createElement("div"); vw.className = "tv-videowrap";
      const vid = document.createElement("video"); vid.controls = true; vid.src = mediaUrl(e.video.url); vw.appendChild(vid);
      const dlv = document.createElement("button"); dlv.type = "button"; dlv.className = "ghost tv-dlvid"; dlv.textContent = "⬇ Download video";
      dlv.addEventListener("click", () => downloadMedia(e.video.url, `testimonial_video_${slug((tcCharById(card.charId) || {}).name || "card")}.mp4`, "testimonial video"));
      vsec.appendChild(vw); vsec.appendChild(dlv);
    }
  };

  renderImg(); renderVo(); renderVideoSection();
  // already have a selfie still + a linked scene (e.g. just converted written→video, or reopened) → make sure the scene shows it
  if (linkedScene && e.image && e.image.url) {
    const vsig = "tv:" + e.image.url;
    if (tcEx(card).producedSig !== vsig) { tcEx(card).producedSig = vsig; tcQueueSave(); setTimeout(() => pushToScene(e.image.url), 200); }
  }
  return box;
}
// One written-testimonial editor: type + character picker + delete, a text field, a live preview, download.
function buildTCardEditor(card, idx) {
  if (card.type === "video") return buildTVEditor(card, idx);
  const chars = (DOC && DOC.testimonials) || [];
  const box = document.createElement("div"); box.className = "tc-editor"; box.dataset.cid = card.id;

  const controls = document.createElement("div"); controls.className = "tc-controls tc-controls-w";
  let doBuild = null;   // in-place preview rebuild (assigned once the preview exists) so switching format slides smoothly instead of a full re-render
  const main = document.createElement("div"); main.className = "tc-ctrls-main";
  const clbl = document.createElement("span"); clbl.className = "tc-cardnum scene-num"; clbl.textContent = `#${(idx || 0) + 1}`; main.appendChild(clbl);
  const linkedScene = ((DOC && DOC.scenes) || []).find(sc => sc.tcard_id === card.id);   // this card mirrors into a VSL scene
  if (linkedScene) { const lk = document.createElement("button"); lk.type = "button"; lk.className = "tc-scenelink"; lk.textContent = `Scene #${linkedScene.id}`; lk.title = "Go to this scene in Scene & Image"; lk.addEventListener("click", (e) => { e.stopPropagation(); activateTab("scenes"); jumpToScene(linkedScene.id); }); main.appendChild(lk); }
  const charOpts = [{ value: "", label: "— Select character —" }].concat(chars.map(c => ({ value: c.id, label: c.name || "(unnamed)" })));
  const sel = tcSelect(card.charId || "", charOpts, async (val) => { card.charId = val; tcQueueSave(); const ch = tcCharById(card.charId); if (ch) await loadTcImg(ch); renderTCards(); }, "— Select character —");
  main.appendChild(sel);
  controls.appendChild(main);
  const types = document.createElement("div"); types.className = "tc-types";
  const tpSlider = document.createElement("span"); tpSlider.className = "tc-type-slider"; types.appendChild(tpSlider);
  // one green highlight that GLIDES to the active format tab, exactly like the main .tab-slider
  const placeTPSlider = (animate) => {
    const on = types.querySelector(".tc-type.on");
    if (!on || !on.offsetWidth) { tpSlider.classList.remove("on"); return; }   // skip while hidden (offsetWidth 0)
    if (!animate) tpSlider.style.transition = "none";
    tpSlider.style.width = on.offsetWidth + "px";
    tpSlider.style.height = on.offsetHeight + "px";
    tpSlider.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
    tpSlider.classList.add("on");
    if (!animate) { void tpSlider.offsetWidth; tpSlider.style.transition = ""; }
  };
  TC_TYPES.forEach(t => {
    const b = document.createElement("button"); b.type = "button"; b.className = "tc-type" + (card.format === t.k ? " on" : ""); b.textContent = t.label;
    b.addEventListener("click", () => {
      if (card.format === t.k) return;
      card.format = t.k; tcQueueSave();
      types.querySelectorAll(".tc-type").forEach(x => x.classList.toggle("on", x === b));
      placeTPSlider(true);                            // glide the green highlight to the clicked tab
      if (doBuild) doBuild(); else renderTCards();    // rebuild the preview in place; no character yet → normal render
      tcEx(card).producedSig = null; card._producing = false;   // user changed the format → force a fresh sync (never let a stale sig / stuck lock block it)
      clearTimeout(autoTimer); autoTimer = setTimeout(autoProduce, 550);   // format changed → re-sync the linked scene's image IN PLACE
    });
    types.appendChild(b);
  });
  controls.appendChild(types);
  requestAnimationFrame(() => placeTPSlider(false));   // first placement is instant (no glide), once laid out
  const _typeDd = tcSelect(card.type || "written", [{ value: "written", label: "Written Testimonial" }, { value: "video", label: "Video Testimonial" }], (val) => { if (val && val !== card.type) { card.type = val; tcQueueSave(); renderTCards(); } }, "Type"); _typeDd.classList.add("tc-typedd");
  const del = document.createElement("button"); del.type = "button"; del.className = "ghost tc-del"; del.title = "Delete this testimonial"; del.innerHTML = TRASH_SVG;
  del.addEventListener("click", async () => {
    if (!(await confirmDialog("Delete this testimonial?", { title: "Delete Testimonial", okText: "Delete", danger: true }))) return;
    tcAnimateRemoveCard(card, box);
  });
  const _rightG = document.createElement("div"); _rightG.className = "tc-ctrls-right"; _rightG.append(_typeDd, del); controls.appendChild(_rightG);   // type dd + trash grouped at the right, same row
  box.appendChild(controls);

  const ch = tcCharById(card.charId);
  if (!ch) { const e = document.createElement("div"); e.className = "hint tc-hint"; e.textContent = "Pick a character to preview this testimonial."; box.appendChild(e); return box; }

  const ta = document.createElement("textarea"); ta.className = "tc-text"; ta.spellcheck = false; ta.placeholder = "Write the testimonial in this person’s words…"; ta.value = card.text || ""; ta.rows = 3;
  box.appendChild(tcBuildScriptVoiceover(card, ta));   // split: text box left, voice-over controls right (like the video editor)

  const wrap = document.createElement("div"); wrap.className = "tc-preview"; const scale = document.createElement("div"); scale.className = "tc-scale"; wrap.appendChild(scale); box.appendChild(wrap);
  const frame = document.createElement("div"); frame.className = "tc-frame16"; scale.appendChild(frame);
  let cardEl = null, s = 1, suppressH = false;
  let autoProduce = () => {}, autoTimer = null;   // reassigned below (once renderPng exists); re-fired on any card change so the linked scene's image stays in sync
  // The preview IS the 16:9 frame the card ships in — same tc16Frame maths as the render — so a long
  // testimonial visibly shrinks here exactly as it will at 1920x1080, and a short one sits at the same
  // maximum size, instead of the preview always stretching the card to the panel width.
  let lastK = 1;
  const fit = () => {
    if (!cardEl) return;
    const cw = Math.max(cardEl.offsetWidth, cardEl.scrollWidth) || 1200;
    const cvh = Math.max(cardEl.offsetHeight, cardEl.scrollHeight) || 600;
    const f = tc16Frame(cw, cvh);
    lastK = f.k;
    cardEl.style.transform = f.k < 1 ? `scale(${f.k.toFixed(4)})` : "";
    frame.style.width = f.W + "px"; frame.style.height = f.H + "px";
    s = (wrap.clientWidth || 640) / f.W;
    if (!suppressH) { scale.style.transform = `scale(${s})`; wrap.style.height = (f.H * s) + "px"; }
    placeGrips();
  };
  // Drag either edge of the review text to spread it wider — both edges move by the same amount, so the
  // text stays centred. The handles live in the preview wrapper, NOT in the card, so they can never end
  // up in the HTML that gets rendered.
  const grips = document.createElement("div"); grips.className = "tc-grips"; grips.hidden = true;
  const gL = document.createElement("div"); gL.className = "tc-grip tc-grip-l"; gL.title = "Drag to widen the text";
  const gR = document.createElement("div"); gR.className = "tc-grip tc-grip-r"; gR.title = "Drag to widen the text";
  grips.append(gL, gR); wrap.appendChild(grips);
  const placeGrips = () => {
    const b = cardEl && cardEl.querySelector('[data-role="text"]');
    if (!b || card.format !== "star") { grips.hidden = true; return; }
    const wr = wrap.getBoundingClientRect(), br = b.getBoundingClientRect();
    if (!(br.height > 2)) { grips.hidden = true; return; }
    grips.hidden = false;
    const GH = 46;                                  // a short pill beside the middle of the text block
    gL.style.left = (br.left - wr.left) + "px"; gR.style.left = (br.right - wr.left) + "px";
    gL.style.top = gR.style.top = (br.top - wr.top + br.height / 2 - GH / 2) + "px";
    gL.style.height = gR.style.height = GH + "px";
  };
  const onGrip = side => e => {
    const b = cardEl && cardEl.querySelector('[data-role="text"]');
    if (!b) return;
    e.preventDefault();
    const x0 = e.clientX, start = b.offsetWidth;
    const onScreen = () => Math.max(0.05, s * (lastK || 1));   // stage scale x any shrink-to-fit on the card
    const move = ev => {
      const d = ((ev.clientX - x0) / onScreen()) * (side === "l" ? -1 : 1);
      const w = Math.max(TCW_MIN, Math.min(TCW_MAX, Math.round(start + 2 * d)));   // both sides → twice the drag
      tcEx(card).textw = w; b.style.maxWidth = w + "px"; fit();
    };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      document.body.classList.remove("tc-gripping");
      tcQueueSave(); tcEx(card).producedSig = null; card._producing = false;
      clearTimeout(autoTimer); autoTimer = setTimeout(autoProduce, 900);   // re-bake the linked scene image
    };
    document.body.classList.add("tc-gripping");
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  gL.addEventListener("pointerdown", onGrip("l")); gR.addEventListener("pointerdown", onGrip("r"));
  const remeasure = () => {
    if (!cardEl) return;
    fit();
    // the product is sized from the identity column's height, which only exists after layout — refit once
    // it is known, then re-frame because the card's height just changed
    if (card.format === "star") tcFitProduct(cardEl, tcEx(card).prod || tcDefaultProd()).then(fit).catch(() => {});
  };
  const build = () => {
    frame.innerHTML = "";
    const fn = card.format === "email" ? tcBuildEmail : card.format === "star" ? tcBuildStar : tcBuildFB;
    const _reSync = () => { tcEx(card).producedSig = null; card._producing = false; clearTimeout(autoTimer); autoTimer = setTimeout(autoProduce, 1200); };   // a field edit → re-render the linked scene image
    cardEl = fn(ch, card.text || "", tcEx(card)); cardEl.spellcheck = false; frame.appendChild(cardEl); tcWireCard(cardEl, remeasure, card, _reSync);
    const bodyEl = cardEl.querySelector('[data-role="text"]');   // the review text is editable on the preview too (two-way with the box above)
    if (bodyEl) {
      bodyEl.setAttribute("contenteditable", "true");
      bodyEl.addEventListener("input", () => { card.text = bodyEl.innerText; if (ta) ta.value = card.text; remeasure(); tcQueueSave(); tcEx(card).producedSig = null; card._producing = false; clearTimeout(autoTimer); autoTimer = setTimeout(autoProduce, 1200); });   // preview text edit → re-sync (debounced)
    }
    // the person's NAME is editable straight on the preview too (every format renders it somewhere). It
    // belongs to the roster person, not to this card, so it saves through the person and then refreshes the
    // roster field, the other cards and the character pickers.
    if (ch) {
      cardEl.querySelectorAll(".tc-name, .tc-from").forEach(nEl => {
        nEl.setAttribute("contenteditable", "true");
        nEl.addEventListener("input", () => { remeasure(); });
        nEl.addEventListener("blur", async () => {
          const v = nEl.innerText.replace(/\s+/g, " ").trim();
          if (!v || v === (ch.name || "")) { nEl.innerText = ch.name || ""; remeasure(); return; }
          const r = await api.updateTPerson(PROJECT, ch.id, { name: v });
          if (r.error) { nEl.innerText = ch.name || ""; remeasure(); return; }
          ch.name = r.name;
          const f = document.querySelector(`#tpRoster [data-pid="${ch.id}"] .tp-name`);   // keep the roster field in step
          if (f) f.value = ch.name;
          renderTCards();
        });
        nEl.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); nEl.blur(); } });
      });
    }
    requestAnimationFrame(remeasure);
  };
  build();
  // switching Facebook/Email/Star rebuilds the preview in place, then smoothly stretches the height from
  // the old size to the new one — AFTER the new card's images load, so FB/Star (avatar/product images)
  // animate exactly like Email (no images) instead of jumping once the image finally paints.
  doBuild = () => {
    const run = () => {
      if (segBox && segBox._end) segBox._end();        // drop any karaoke session before the body is rebuilt
      const oldH = wrap.offsetHeight;                 // animate FROM this height
      suppressH = true;                                // we drive scale + height ourselves for this transition
      wrap.style.transition = "none"; scale.style.transition = "none";
      build();                                          // swap in the new card (remeasure suppressed → transform/height untouched)
      const _f = tc16Frame(Math.max(cardEl.offsetWidth, cardEl.scrollWidth) || 1200,
                           Math.max(cardEl.offsetHeight, cardEl.scrollHeight) || 600);
      cardEl.style.transform = _f.k < 1 ? `scale(${_f.k.toFixed(4)})` : "";
      frame.style.width = _f.W + "px"; frame.style.height = _f.H + "px";
      const ch = _f.H, w = wrap.clientWidth || 640;
      const endS = w / _f.W;                           // the 16:9 stage always fills the panel width
      const newH = ch * endS;
      s = endS;
      const settle = () => { clearTimeout(wrap._htimer); wrap._htimer = setTimeout(() => { wrap.style.transition = ""; scale.style.transition = ""; suppressH = false; remeasure(); }, 430); };
      if (newH >= oldH) {
        // GROW: the content is already at its max (width-limited) size — just reveal it by growing the box height.
        // (Scaling it up would force a horizontal shrink-then-grow flash, since it can't get wider than the box.)
        scale.style.transform = `scale(${endS})`;
        wrap.style.height = oldH + "px";
        requestAnimationFrame(() => { wrap.style.transition = "height .38s cubic-bezier(.4,0,.2,1)"; wrap.style.height = newH + "px"; settle(); });
      } else {
        // SHRINK: content starts filling the OLD (taller) box, then the scale + the box shrink together to the fit.
        scale.style.transform = `scale(${oldH / ch})`;
        wrap.style.height = oldH + "px";
        requestAnimationFrame(() => {
          scale.style.transition = "transform .38s cubic-bezier(.4,0,.2,1)";
          wrap.style.transition = "height .38s cubic-bezier(.4,0,.2,1)";
          scale.style.transform = `scale(${endS})`;
          wrap.style.height = newH + "px";
          settle();
        });
      }
    };
    const need2 = [];
    if (card.format === "star") { const pu = tcEx(card).prod || tcDefaultProd(); if (pu && !tcImgCache[pu]) need2.push(loadTcRel(pu)); }
    if (need2.length) Promise.all(need2).then(run); else run();
  };
  const need = [];
  if (tcCharUrl(ch) && !tcImgCache[tcCharUrl(ch)]) need.push(loadTcImg(ch));
  if (card.format === "star") { const pu = tcEx(card).prod || tcDefaultProd(); if (pu && !tcImgCache[pu]) need.push(loadTcRel(pu)); }
  if (need.length) Promise.all(need).then(build);

  // ---- this testimonial's voice-over slice: an app-styled seekable bar + a cumulative GREEN word karaoke over the preview text ----
  const segBox = document.createElement("div"); segBox.className = "tc-voseg"; segBox.hidden = true; box.appendChild(segBox);
  const segBtn = document.createElement("button"); segBtn.type = "button"; segBtn.className = "tc-voseg-btn"; segBtn.textContent = "▶";
  const segBar = document.createElement("div"); segBar.className = "tc-voseg-bar pv-bar";   // reuse the main preview scrubber look
  const segTrackI = document.createElement("div"); segTrackI.className = "pv-bar-track";
  const segFill = document.createElement("div"); segFill.className = "pv-progress"; segTrackI.appendChild(segFill);
  const segHead = document.createElement("div"); segHead.className = "pv-head"; segHead.style.left = "0%";
  segBar.append(segTrackI, segHead);
  const segTime = document.createElement("span"); segTime.className = "tc-voseg-time"; segTime.textContent = "0.0 / 0.0s";
  segBox.append(segBtn, segBar, segTime);

  let segTiming = null, sess = null, playing = false, segRaf = 0;
  const audioEl = () => tcPlayer || (tcPlayer = new Audio());
  function buildSpans() {   // wrap the preview body's words in .kw spans (index-matched to the aligned words); restore the plain text later
    const bodyEl = cardEl && cardEl.querySelector('[data-role="text"]');
    if (!bodyEl) return null;
    const savedHTML = bodyEl.innerHTML, wasCE = bodyEl.getAttribute("contenteditable");
    bodyEl.setAttribute("contenteditable", "false");
    const frag = document.createDocumentFragment(); const spans = [], gaps = []; let wi = 0;
    bodyEl.innerText.split(/(\s+)/).forEach(tok => {
      if (tok === "") return;
      if (/^\s+$/.test(tok) || !/[\p{L}\p{N}]/u.test(tok)) {   // whitespace OR punctuation-only ("—") → gap span, not a word (keeps span↔word index aligned; fixes the em-dash desync); newlines never fill
        const g = document.createElement("span"); g.className = "kw kw-sp"; g.textContent = tok; frag.appendChild(g);
        gaps.push({ el: g, nextWi: /\n/.test(tok) ? -1 : wi });
        return;
      }
      const sp = document.createElement("span"); sp.className = "kw"; sp.textContent = tok; spans.push(sp); frag.appendChild(sp); wi++;
    });
    bodyEl.innerHTML = ""; bodyEl.appendChild(frag);
    return { spans, gaps, restore: () => { try { bodyEl.innerHTML = savedHTML; if (wasCE !== null) bodyEl.setAttribute("contenteditable", wasCE); } catch (_) {} } };
  }
  function endSession() {
    cancelAnimationFrame(segRaf); playing = false;
    const a = audioEl(); try { a.pause(); } catch (_) {} a.onended = null;
    if (sess && sess.restore) sess.restore(); sess = null;
    segBtn.textContent = "▶"; segFill.style.width = "0%"; segHead.style.left = "0%";
    if (tcPlayCtl && tcPlayCtl._box === segBox) tcPlayCtl = null;
  }
  segBox._end = endSession;   // tcStopPlay() / rebuilds route here
  function paintAt(t) {
    if (!segTiming) return;
    const { start, end, words } = segTiming; const dur = Math.max(0.1, end - start);
    const p = Math.min(1, Math.max(0, (t - start) / dur));
    segFill.style.width = (p * 100) + "%"; segHead.style.left = (p * 100) + "%";
    segTime.textContent = Math.max(0, t - start).toFixed(1) + " / " + dur.toFixed(1) + "s";
    if (sess && words.length) tcKaraPaint(sess.spans, sess.gaps, words, t, end);   // continuous sweep — same painter as the Assemble preview and the render
  }
  function segLoop() {
    if (!segTiming) { endSession(); return; }
    const a = audioEl();
    if (sess && sess.spans.length && !document.body.contains(sess.spans[0])) { endSession(); return; }   // card was rebuilt → bail
    if (a.currentTime >= segTiming.end - 0.012) { try { a.pause(); } catch (_) {} paintAt(segTiming.end); playing = false; segBtn.textContent = "▶"; cancelAnimationFrame(segRaf); return; }   // STOP the shared audio at the segment end (it plays a slice of the whole VO → must not run on into the next testimonials)
    paintAt(a.currentTime); segRaf = requestAnimationFrame(segLoop);
  }
  function segPlayFrom(t) {
    if (!segTiming) return;
    if (tcPlayCtl && tcPlayCtl._box !== segBox) tcStopPlay();   // only one card plays at a time
    if (!sess) sess = buildSpans();
    const a = audioEl();
    if (a.src !== new URL(segTiming.vo, location.href).href) a.src = segTiming.vo;
    playing = true; segBtn.textContent = "❚❚"; tcPlayCtl = { stop: endSession, _box: segBox };
    a.onended = () => { paintAt(segTiming.end); playing = false; segBtn.textContent = "▶"; };
    const go = () => { try { a.currentTime = t; } catch (_) {} paintAt(t); a.play().then(() => { cancelAnimationFrame(segRaf); segRaf = requestAnimationFrame(segLoop); }).catch(() => endSession()); };
    if (a.readyState >= 1) go(); else a.addEventListener("loadedmetadata", go, { once: true });   // seek is ignored before metadata loads
  }
  const refreshSeg = () => {
    segTiming = tcCardTiming(card);
    if (!segTiming) { endSession(); segBox.hidden = true; return; }
    segBox.hidden = false;
    if (!playing && !sess) { const dur = Math.max(0, segTiming.end - segTiming.start); segTime.textContent = "0.0 / " + dur.toFixed(1) + "s"; segFill.style.width = "0%"; segHead.style.left = "0%"; }
  };
  segBtn.addEventListener("click", () => {
    if (!segTiming) return;
    if (playing) { cancelAnimationFrame(segRaf); try { audioEl().pause(); } catch (_) {} playing = false; segBtn.textContent = "▶"; return; }   // pause (keeps the position + the green trail)
    const a = audioEl();
    let from = segTiming.start;
    if (sess && a.currentTime > segTiming.start && a.currentTime < segTiming.end - 0.05) from = a.currentTime;   // resume from where it was paused/scrubbed
    segPlayFrom(from);
  });
  // click / drag the bar to scrub — exactly like the main preview scrubber
  const segSeekX = (clientX) => {
    if (!segTiming) return;
    const r = segBar.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (clientX - r.left) / (r.width || 1)));
    const t = segTiming.start + p * (segTiming.end - segTiming.start);
    if (tcPlayCtl && tcPlayCtl._box !== segBox) tcStopPlay();
    if (!sess) sess = buildSpans();
    tcPlayCtl = { stop: endSession, _box: segBox };
    const a = audioEl(); if (a.src !== new URL(segTiming.vo, location.href).href) a.src = segTiming.vo;
    const seek = () => { try { a.currentTime = t; } catch (_) {} paintAt(t); };
    if (a.readyState >= 1) seek(); else a.addEventListener("loadedmetadata", seek, { once: true });
  };
  let segDragging = false, segWasPlaying = false;
  segBar.addEventListener("pointerdown", (e) => {
    if (!segTiming) return;
    segDragging = true; segWasPlaying = playing;
    if (playing) { cancelAnimationFrame(segRaf); try { audioEl().pause(); } catch (_) {} playing = false; }
    segBar.classList.add("dragging"); try { segBar.setPointerCapture(e.pointerId); } catch (_) {}
    segSeekX(e.clientX); e.preventDefault();
  });
  segBar.addEventListener("pointermove", (e) => { if (segDragging) segSeekX(e.clientX); });
  const segUp = () => {
    if (!segDragging) return; segDragging = false; segBar.classList.remove("dragging");
    const t = audioEl().currentTime;
    if (segWasPlaying && t < segTiming.end - 0.05) segPlayFrom(t); else segBtn.textContent = "▶";   // resume playing from the dropped spot
  };
  segBar.addEventListener("pointerup", segUp); segBar.addEventListener("pointercancel", segUp);
  refreshSeg();
  tcLoadTL().then(() => { try { refreshSeg(); } catch (_) {} });

  ta.addEventListener("input", () => { if (segBox && segBox._end) segBox._end(); card.text = ta.value; const tEl = cardEl && cardEl.querySelector('[data-role="text"]'); if (tEl) { tEl.innerHTML = tcTextHtml(card.text); remeasure(); } tcQueueSave(); tcEx(card).producedSig = null; card._producing = false; clearTimeout(autoTimer); autoTimer = setTimeout(autoProduce, 1200); });   // text changed → re-sync the linked scene (debounced)

  // shared: render the CURRENT preview card to a PNG under cards/ (used by download + "send to scene")
  const renderPng = async () => {
    if (!cardEl) return { error: "no card" };
    // the product fit is async (it reads the image's pixels) — settle it BEFORE baking, or a first
    // render can capture the card before the bottle has been lined up with the identity column
    if (card.format === "star") { try { await tcFitProduct(cardEl, tcEx(card).prod || tcDefaultProd()); } catch (_) {} }
    const rw = Math.max(cardEl.offsetWidth, cardEl.scrollWidth);    // capture any content that overflows the card's fixed width (e.g. the star product) instead of clipping it
    const rh = Math.max(cardEl.offsetHeight, cardEl.scrollHeight);
    const t16 = tc16(cardEl.outerHTML, rw, rh);                     // WHITE 16:9 canvas → drops straight into the 1920×1080 VSL, no black bars / crop
    if (!t16) return { error: "card not laid out yet" };            // hidden/unmeasured → skip (caller retries)
    const { html, w, h } = t16;
    try {
      // race a timeout so a hung headless-render can never leave _producing stuck forever (which silently blocks all future syncs)
      return await Promise.race([
        api.renderTCard(PROJECT, html, w, h),
        new Promise((_, rej) => setTimeout(() => rej(new Error("render timed out (45s)")), 45000)),
      ]);
    } catch (e) { return { error: (e && e.message) || "request failed" }; }
  };
  // karaoke video export: the same card, but each word wrapped in .kw[data-i] + a script that measures each
  // word's box (the server reads #__rects, paints the cumulative green per frame, muxes the VO slice).
  const renderKaraokeHtml = () => tcMakeKaraHtml(cardEl);   // shared builder (also used from the Assemble preview)
  // bottom-right download icons, overlaid on the preview — same design/size as Scenes & Images
  const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";
  const dl = document.createElement("button"); dl.type = "button"; dl.className = "ia download"; dl.title = "Download this testimonial (image)";
  dl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="M21 15l-5-5L5 21"/></svg>';
  dl.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(dl, async () => {
    const r = await renderPng();
    if (r.error || !r.url) { toast(r.error || "render failed", "err", 6000); return; }
    downloadMedia(r.url, `testimonial_${card.format}_${slug(ch.name || "card")}.png`, "testimonial card");
  }); });
  const dlv = document.createElement("button"); dlv.type = "button"; dlv.className = "ia download tc-dlvid"; dlv.title = "Download as video (voice-over + karaoke)";
  dlv.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10.5l5-3v9l-5-3z"/></svg>';
  dlv.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(dlv, async () => {
    const tm = tcCardTiming(card);
    if (!tm) { toast("Generate the SRT first — the video uses this testimonial's voice-over slice.", "err", 6500); return; }
    const kh = renderKaraokeHtml();
    if (!kh) { toast("Preview not ready", "err"); return; }
    toast("Rendering testimonial video… this can take up to a minute.", "info", 5000);
    let r; try { r = await api.tcardVideo(PROJECT, card.id, { html: kh.html, w: kh.w, h: kh.h, words: tm.words, start: tm.start, end: tm.end, audio: tm.voRel || "" }); } catch (x) { r = { error: "request failed" }; }
    if (!r || r.error || !r.url) { toast(`Video failed${(r && r.error) ? ": " + r.error : ""}`, "err", 8000); return; }
    downloadMedia(r.url, `testimonial_${card.format}_${slug(ch.name || "card")}.mp4`, "testimonial video");
  }); });
  ovb.append(dl, dlv); wrap.appendChild(ovb);

  // linked to a VSL scene → AUTO-produce the card image and drop it into that scene (no manual button).
  // A content SIGNATURE (persisted) guards it so it fires ONLY when the testimonial actually changed —
  // re-renders / tab switches never re-generate. An in-flight lock prevents concurrent runs.
  if (linkedScene) {
    let _apTries = 0;
    autoProduce = async () => {   // no button, no "✓ In Scene" label — auto-render this card into the linked scene, in place
      const sig = JSON.stringify([card.charId, card.format, card.text || "", tcCharUrl(ch)]);
      if (card._producing || tcEx(card).producedSig === sig) return;   // unchanged since last produce, or already running
      // fresh split / hidden tab → the card hasn't laid out yet (offsetWidth 0). Retry QUIETLY instead of
      // flashing a red "Card Not Laid out Yet" error; it self-heals the moment the DOM lays the card out.
      if (cardEl && cardEl.offsetWidth < 1) { if (_apTries++ < 40) setTimeout(autoProduce, 250); return; }
      card._producing = true;
      try {
        const r = await renderPng();
        if (r && r.error === "card not laid out yet") { card._producing = false; if (_apTries++ < 40) setTimeout(autoProduce, 250); return; }   // layout race → retry silently, no toast
        if (!r || r.error || !r.url) { toast(`Testimonial image failed to render${(r && r.error) ? ": " + r.error : ""}`, "err", 7000); return; }
        _apTries = 0;   // laid out & rendered → reset the retry budget for any later re-produce (text edit)
        const s2 = await api.tcardToScene(PROJECT, card.id, r.url);
        if (!s2 || s2.error) { toast(`Testimonial → scene failed${(s2 && s2.error) ? ": " + s2.error : ""}`, "err", 7000); return; }
        tcEx(card).produced = { at: Date.now() }; tcEx(card).producedSig = sig;
        try { const kh = renderKaraokeHtml(); if (kh) { card.extra = card.extra || {}; card.extra.kara = kh; } } catch (_) {}   // stash the karaoke HTML (white 16:9) so the final render can burn the green highlight into this scene
        tcQueueSave();
        // tcardToScene only saved the image SERVER-side → mirror it into the CLIENT scene too so it shows
        // in the Scene & Image placeholder immediately (no reload). Replace the existing "_tc_" version in place.
        const sc = ((DOC && DOC.scenes) || []).find(x => x.id === s2.sceneId);
        if (sc) {
          const im = sc.image = sc.image || {}; im.versions = im.versions || [];
          const ti = im.versions.findIndex(v => (v || "").includes("_tc_"));
          if (ti >= 0) im.versions[ti] = s2.url; else im.versions.push(s2.url);
          const idx = ti >= 0 ? ti : im.versions.length - 1;
          im.current = idx; im.approved_version = idx; im.status = "ready"; im.taskId = null; im.error = null;
          sc.approved = true;
          sc._appLock = Date.now() + 8000;   // a poll that STARTED before tcardToScene saved carries an image-less scene → don't let it wipe this just-synced image
        }
        if (typeof renderScenes === "function") { try { renderScenes(); } catch (_) {} }   // reflect instantly in Scene & Image
      } catch (e) { toast("Testimonial sync error: " + e, "err", 7000); }
      finally { card._producing = false; }
    };
    // fire once the preview (with its embedded images) has built
    if (need.length) Promise.all(need).then(() => setTimeout(autoProduce, 200)); else setTimeout(autoProduce, 200);
  }
  // keep each linked card's karaoke HTML fresh (even when the image is already synced) so the final render
  // can burn the green highlight in — covers testimonials produced before this existed.
  if (linkedScene) {   // store a GOOD karaoke HTML — retry until the card is actually laid out (offsetWidth>0), so a hidden-tab build never bakes a 0×0 canvas
    let _kt = 0;
    const _storeKara = () => {
      if (!cardEl) return;
      if (cardEl.offsetWidth < 1 && _kt++ < 25) { setTimeout(_storeKara, 200); return; }   // wait for layout (up to ~5s)
      try { const kh = renderKaraokeHtml(); if (kh) { card.extra = card.extra || {}; card.extra.kara = kh; tcQueueSave(); } } catch (_) {}
    };
    setTimeout(_storeKara, 400);
  }
  return box;
}
async function openGenCandidate(c, cfg) {
  const bg = $("#charCandBg"), img = $("#charCandImg"), spin = $("#charCandSpin"), msg = $("#charCandMsg");
  const useB = $("#charCandUse"), regenB = $("#charCandRegen"), cancelB = $("#charCandCancel");
  const prevB = $("#charCandPrev"), nextB = $("#charCandNext"), verEl = $("#charCandVer"), dlB = $("#charCandDl");
  const editWrap = $("#charCandEdit"), editInstr = $("#charCandEditInstr"), editApply = $("#charCandEditApply");
  const promptWrap = $("#charCandPrompt"), promptText = $("#charCandPromptText"), promptGen = $("#charCandPromptGen");
  const allowPrompt = !!cfg.customPrompt;   // free-text "generate from my own prompt" box (cast + ingredients)
  const modalEl = bg.querySelector(".char-cand-modal");
  const fitCard = () => {                    // hug the card to the SHOWN image's real size → no side bars, no crop
    const nw = img.naturalWidth, nh = img.naturalHeight;
    if (!nw || !nh || !modalEl) return;
    const maxH = Math.max(240, Math.min(window.innerHeight - 380, 560));   // cap height so the preview stays a sensible size
    const maxW = Math.min(0.88 * window.innerWidth, 1000);
    const scale = Math.min(maxH / nh, maxW / nw);
    const w = Math.round(nw * scale);
    const cs = getComputedStyle(modalEl);
    const extra = cs.boxSizing === "border-box"
      ? parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth)
      : 0;                                    // add padding+border back so the CONTENT (image) width equals w
    modalEl.style.width = (w + extra) + "px";
  };
  let versions = [], cur = -1, busy = false;
  const showCur = () => {
    if (cur >= 0) {
      img.style.opacity = "0";                                   // brief crossfade between versions (no hard pop)
      img.onload = () => { img.style.opacity = "1"; fitCard(); };
      img.src = mediaUrl(versions[cur]); img.hidden = false;     // full-res, not the tiny thumb
      if (img.complete) fitCard();                               // cached image → onload may not fire, size now
      [cur - 1, cur + 1].forEach(i => { if (i >= 0 && i < versions.length) { const p = new Image(); p.src = mediaUrl(versions[i]); } });
    }
    const many = versions.length >= 2;
    verEl.hidden = !many; if (many) verEl.textContent = `${cur + 1} / ${versions.length}`;
    prevB.hidden = !many; nextB.hidden = !many;
    prevB.disabled = busy || cur <= 0; nextB.disabled = busy || cur >= versions.length - 1;
    if (dlB) { dlB.hidden = cur < 0;                               // download the shown version (bottom-right overlay)
      if (cur >= 0) dlB.onclick = () => downloadMedia(versions[cur], `${slug(c.name || "image")}.png`, c.name || "image"); }
  };
  const setBusy = (b, label) => {
    busy = b;
    spin.hidden = !b;
    if (b) { img.hidden = cur < 0; } // keep the current image visible under the spinner while it works
    if (label != null) msg.textContent = label;
    useB.disabled = b || cur < 0;
    regenB.disabled = b;
    editApply.disabled = b || cur < 0;
    editInstr.disabled = b;
    editWrap.hidden = false;
    if (allowPrompt) { promptWrap.hidden = false; promptText.disabled = b; promptGen.disabled = b; }   // free-text generate box
    if (b) { prevB.hidden = nextB.hidden = verEl.hidden = true; if (dlB) dlB.hidden = true; } else showCur();
  };
  const generate = async (fresh, prompt) => {
    setBusy(true, `Generating “${c.name}”… this can take up to a minute.`);
    let r; try { r = await cfg.gen(fresh, prompt); } catch (e) { r = { error: "request failed" }; }
    if (r.error) { setBusy(false); toast(r.error, "err", 6000); if (cur < 0) close(true); return; }
    versions.push(r.url); cur = versions.length - 1;
    setBusy(false, "Not applied yet — use it, flip versions, edit it, or regenerate.");
  };
  const doEdit = async () => {
    const instr = (editInstr.value || "").trim();
    if (!instr || busy || cur < 0) return;
    setBusy(true, "Applying your edit…");
    let r; try { r = await cfg.edit(versions[cur], instr); } catch (e) { r = { error: "request failed" }; }
    if (r.error) { setBusy(false); toast(r.error, "err", 6000); return; }
    editInstr.value = "";
    versions.push(r.url); cur = versions.length - 1;
    setBusy(false, "Edited — that's a new version. Keep editing, flip back, or use it.");
  };
  const doPromptGen = async () => {                     // generate a brand-new image from the user's OWN prompt (text-to-image)
    const p = (promptText.value || "").trim();
    if (!p || busy) return;
    await generate(false, p);                           // adds a new version (keeps existing ones to flip between)
    promptText.value = "";
  };
  function cleanup() { useB.onclick = regenB.onclick = cancelB.onclick = prevB.onclick = nextB.onclick = editApply.onclick = editInstr.onkeydown = promptGen.onclick = promptText.onkeydown = img.onclick = bg.onclick = null; if (modalEl) modalEl.style.width = ""; document.removeEventListener("keydown", onKey); window.removeEventListener("resize", onResize); bg.classList.remove("cc-portrait"); }
  const onKey = (e) => { if (busy) return; if (e.key === "Escape") close(true); else if (e.key === "ArrowLeft") prevB.onclick && prevB.onclick(); else if (e.key === "ArrowRight") nextB.onclick && nextB.onclick(); };
  const onResize = () => { if (cur >= 0) fitCard(); };   // keep the card fitted to the image if the window is resized
  async function close(discard) {
    if (busy) return;
    smoothHideModal(bg); cleanup();
    if (discard && versions.length) { try { await cfg.discard({ all: true }); } catch (e) {} }
  }
  const commit = (r, verb) => {
    versions = []; smoothHideModal(bg); cleanup();
    cfg.commit(r);
    toast(`✓ ${verb} “${c.name}”`, "ok");
  };
  $("#charCandTitle").textContent = (cfg.seed ? `Edit “${c.name}”` : `Generate “${c.name}”`);
  bg.classList.toggle("cc-portrait", !!cfg.portrait);   // testimonial portraits → narrower modal + portrait stage
  bg.hidden = false;
  useB.onclick = async () => {
    if (busy || cur < 0) return;
    if (cfg.seed && versions[cur] === cfg.seed) { close(true); return; }   // showing the original, nothing new to add → just close (drop temp edits)
    setBusy(true, "Adding…");
    const r = await cfg.use(versions[cur]);
    if (r.error) { setBusy(false); toast(r.error, "err"); return; }
    commit(r, "Added a generated photo to");
  };
  regenB.onclick = () => { if (!busy) generate(false); };
  prevB.onclick = () => { if (!busy && cur > 0) { cur--; showCur(); } };
  nextB.onclick = () => { if (!busy && cur < versions.length - 1) { cur++; showCur(); } };
  editApply.onclick = doEdit;
  editInstr.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); doEdit(); } };
  if (allowPrompt) {
    promptGen.onclick = doPromptGen;
    promptText.onkeydown = (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doPromptGen(); } };   // Ctrl/Cmd+Enter = generate
  } else { promptWrap.hidden = true; }
  img.onclick = () => { if (cur >= 0) openUrlLightbox(mediaUrl(versions[cur])); };
  cancelB.onclick = () => close(true);
  bdClose(bg, () => close(true));
  document.addEventListener("keydown", onKey);
  window.addEventListener("resize", onResize);
  if (cfg.seed) {                                   // open ON the clicked image → edit / regenerate it
    versions = [cfg.seed]; cur = 0;
    setBusy(false, "Edit this image, or regenerate for a new one.");
  } else {
    generate(true);   // first open → fresh (drops any stale candidates), then builds version 1
  }
}

function setBadge(node, obj) {
  const map = { empty: "", queued: "🕒 queued", generating: "⏳ generating…", ready: "✓ ready",
                error: "⚠ " + trunc(obj.error || "error", 42) };
  // preserve marker classes (img-status / vid-status); only swap the status class
  const prev = node.dataset.badge;
  if (prev) node.classList.remove(prev);
  node.classList.add("status-badge");
  if (obj.status) { node.classList.add(obj.status); node.dataset.badge = obj.status; }
  node.textContent = map[obj.status] ?? obj.status;
  node.title = obj.status === "error" ? (obj.error || "error") : "";   // full reason on hover (#2)
}

// ---------- tab 3: videos ----------
// reuse <video> elements across renders so approving/re-rendering never reloads them (no black flash)
const _vidCache = new Map();   // scene id -> { src, el }
// A video is "in sync" only if it was made from the scene's CURRENT approved image. New videos record
// their source image; legacy ones (no source) fall back to matching the scene-NN in the file names.
function videoInSync(s) {
  const v = s.video, cur = (s.image.approved_file || s.image.file);
  if (!v || !v.file) return true;
  if (v.source) return v.source === cur;
  const base = p => (/scene-0*(\d+)/.exec(p || "") || [])[1];
  return base(v.file) === base(cur);
}
function renderVideos() {
  const wrap = $("#videosList");
  if (!wrap) return;
  const _sy = window.scrollY;   // preserve page scroll across the rebuild (Videos tab was jumping to top on each poll)
  wrap.innerHTML = "";
  const approved = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file));
  $("#videosEmpty").hidden = approved.length > 0;
  const vReady = approved.filter(s => s.video && s.video.status === "ready" && s.video.file).length;
  const vApproved = approved.filter(s => s.video && s.video.approved).length;
  // combined: scenes with an approved image (eligible for video), how many videos generated, how many approved
  const cc = $("#videosConvertCount"); if (cc) cc.textContent = approved.length ? `${approved.length} scenes · ${vReady} videos generated · ${vApproved} approved` : "";
  const vc = $("#videosApproveCount"); if (vc) vc.textContent = "";
  const tpl = $("#videoTpl");
  for (const s of approved) {
    if (hideApprovedVideos && s.video && s.video.approved) continue;   // toggle: hide approved videos
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = s.id;
    if (s.video && s.video.approved) el.classList.add("approved");
    if (_flashApproveVideo === s.id) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); _flashApproveVideo = null; }
    $(".scene-num", el).textContent = `#${s.id}`;
    $(".scene-caption", el).textContent = trunc(s.vo, 90);
    const vSel = $(".scene-sel", el);   // multi-select checkbox (same look/behaviour as the Scenes tab)
    if (vSel) {
      if (isVSel(s.id)) { vSel.classList.add("on"); el.classList.add("sel-on"); }
      vSel.addEventListener("click", (e) => { e.stopPropagation(); toggleVideoSelect(s.id, e.shiftKey); });
    }
    const ai = $(".approved-img", el);
    const asrc = mediaUrl(s.image.approved_file || s.image.file, s.image.taskId);
    const img = document.createElement("img"); img.src = asrc; img.style.cursor = "zoom-in";
    img.addEventListener("click", () => lightbox(asrc, "img"));
    ai.appendChild(img);
    // Delete Scene (in the header row, right edge of the left column — same as the Scenes tab)
    $(".scene-del", el).addEventListener("click", async () => {
      if (!(await confirmDialog(`Delete scene #${s.id}? Its image and video will be removed.`, { title: "Delete Scene", okText: "Delete" }))) return;
      await flushSave();   // commit pending edits before the delete+renumber
      DOC = await api.deleteScene(PROJECT, s.id); renderScenes(); renderVideos();
    });
    $(".video-desc", el).value = s.video_desc || "";
    $(".video-desc", el).addEventListener("input", e => { s.video_desc = e.target.value; queueSave(); });
    // camera-lock toggle: ON (default) → the generated video keeps a static camera; OFF → camera may move
    const camLock = $(".cam-lock", el);
    if (camLock) {
      if (s.video_cam_lock === undefined) s.video_cam_lock = true;
      const paint = () => { const on = !!s.video_cam_lock; camLock.classList.toggle("on", on); camLock.textContent = on ? "🔒 Camera locked" : "🎥 Camera free"; };
      paint();
      camLock.addEventListener("click", () => { s.video_cam_lock = !s.video_cam_lock; paint(); queueSave(); });
    }
    // duration / quality / model dropdowns (options adapt to the selected model)
    if (VIDEO_MODELS.length) {
      const cfg = VIDEO_MODELS.find(m => m.key === s.video_model) || VIDEO_MODELS[0];
      const dur = cfg.durations.includes(s.video_dur) ? s.video_dur : cfg.defaultDur;
      const res = cfg.resolutions.includes(s.video_res) ? s.video_res : cfg.defaultRes;
      s.video_model = cfg.key; s.video_dur = dur; s.video_res = res;
      vDropdown($(".dur-dd", el), "Duration", dur + "s",
        cfg.durations.map(d => ({ value: d, label: d + "s", selected: d === dur })),
        (v) => { s.video_dur = v; queueSave(); renderVideos(); });
      vDropdown($(".res-dd", el), "Quality", res,
        cfg.resolutions.map(r => ({ value: r, label: r, selected: r === res })),
        (v) => { s.video_res = v; queueSave(); renderVideos(); });
      vDropdown($(".vmodel-dd", el), "Model", cfg.label,
        VIDEO_MODELS.map(m => ({ value: m.key, label: m.label, selected: m.key === cfg.key })),
        (v) => { const c = VIDEO_MODELS.find(m => m.key === v); s.video_model = v; s.video_dur = c.defaultDur; s.video_res = c.defaultRes; queueSave(); renderVideos(); });
    }
    const vidPrev = $(".vid-preview", el);
    if (s.video.file && s.video.status === "ready") {
      vidPrev.innerHTML = "";
      const vsrc = mediaUrl(s.video.file, s.video.taskId);
      // reuse the existing <video> for this scene if its source is unchanged — moving the
      // already-loaded element into the new row keeps its frame, so approve/re-render never
      // reloads it to black. Only build a fresh one when the video itself changed.
      let cached = _vidCache.get(s.id);
      let v;
      if (cached && cached.src === vsrc) { v = cached.el; }
      else { v = document.createElement("video"); v.src = vsrc; v.controls = true; _vidCache.set(s.id, { src: vsrc, el: v }); }
      v.controlsList = "nodownload noremoteplayback";   // hide the broken native ⋮ download; we provide our own ⤓
      vidPrev.appendChild(v);
      // overlay actions (top-right of the video)
      const ov = document.createElement("div"); ov.className = "img-actions";
      const a = document.createElement("button"); a.className = "ia approve" + (s.video.approved ? " on" : ""); a.textContent = "✓"; a.title = s.video.approved ? "Approved (click to unapprove)" : "Approve video";
      const c = document.createElement("button"); c.className = "ia change"; c.textContent = "↻"; c.title = "Change (regenerate)";
      const dl = document.createElement("button"); dl.className = "ia dl"; dl.textContent = "⤓"; dl.title = "Download video";
      dl.addEventListener("click", (e) => { e.stopPropagation(); downloadUrl(vsrc, `Scene_${s.id}.mp4`, `Scene ${s.id} video`); });
      const r = document.createElement("button"); r.className = "ia remove"; r.innerHTML = TRASH_SVG; r.title = "Remove video";
      a.addEventListener("click", async (e) => { e.stopPropagation(); const willApprove = !s.video.approved; if (willApprove) _flashApproveVideo = s.id; await flushSave(); s._appLock = Date.now() + 8000; DOC = await api.videoApprove(PROJECT, s.id, willApprove); const _f = DOC.scenes.find(x => x.id === s.id); if (_f) _f._appLock = Date.now() + 8000; renderVideos(); toast(willApprove ? `Approved Video: Scene ${s.id}` : `Unapproved Video: Scene ${s.id}`, willApprove ? "ok" : "info"); });
      c.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Video: Scene ${s.id}`, "info"); genVideos([s.id]); });
      r.addEventListener("click", async (e) => { e.stopPropagation(); DOC = await api.resetVideo(PROJECT, s.id); toast(`Removed Video: Scene ${s.id}`, "info"); renderVideos(); });
      ov.appendChild(a); ov.appendChild(c); ov.appendChild(dl); ov.appendChild(r);
      vidPrev.appendChild(ov);
      if (!videoInSync(s)) {   // this video was made from an image that's no longer the approved one
        const warn = document.createElement("div"); warn.className = "vid-stale";
        const t = document.createElement("span"); t.textContent = "⚠ Made from an older image";
        const rb = document.createElement("button"); rb.type = "button"; rb.className = "vid-stale-regen"; rb.textContent = "↻ Regenerate";
        rb.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Video: Scene ${s.id}`, "info"); genVideos([s.id]); });
        warn.append(t, rb); vidPrev.appendChild(warn);
      }
    } else if (s.video.status === "generating" || s.video.status === "queued") {
      vidPrev.innerHTML = "";                        // same "Generating…" loading overlay the images use
      addGenOverlay(vidPrev, s.video.status);
    }
    setBadge($(".vid-status", el), s.video);
    const gvp = $(".gen-vid-prompt", el);
    gvp.addEventListener("click", () => stoppable(gvp, (sig) => genVideoPrompts([s.id], sig)));
    const gv = $(".gen-vid", el);
    gv.addEventListener("click", () => withBusy(gv, () => genVideos([s.id])));
    if (s.video.status === "generating") setBusy(gv, true);
    // control bar (mirrors the scenes image nav): label + arrows + Edit + Download — shown
    // only once a video exists; Download/Edit appear together after generation.
    const vEditBox = $(".video-edit-box", el), vEditInstr = $(".video-edit-instr", el);
    vEditInstr.value = s.video_desc || "";
    const vidNav = $(".vid-nav", el);
    if (s.video.file && s.video.status === "ready") {
      vidNav.hidden = false;
      $(".vver-label", el).textContent = "1 / 1";
      $(".vid-download", el).addEventListener("click", () => downloadMedia(s.video.file, `${pad2(s.id)}_${slug(s.vo)}.mp4`, `Scene ${s.id}`));
      $(".vid-edit", el).addEventListener("click", () => { vEditBox.hidden = !vEditBox.hidden; });
    }
    $(".video-edit-apply", el).addEventListener("click", (ev) => {
      const t = vEditInstr.value.trim();
      if (!t) { alert("Type what to change."); return; }
      s.video_desc = t;
      $(".video-desc", el).value = t;
      withBusy(ev.currentTarget, () => genVideos([s.id]));
    });
    wrap.appendChild(el);
  }
  // keep the video selection in sync with what's actually shown (drop ids no longer eligible)
  { const shown = new Set(_vApprovedIds()); [...VSEL].forEach(id => { if (!shown.has(id)) VSEL.delete(id); }); updateVidSelBar(); }
  buildVideoJump();
  if (_sy > 0 && document.body.classList.contains("tab-videos")) requestAnimationFrame(() => window.scrollTo(0, _sy));
}

// ---------- actions ----------
// All persistence funnels through _persist so full-DOC PUTs never overlap OUT OF ORDER. Without this, a save
// that was already in flight (serialized with the OLD state) could land AFTER a newer save and revert it —
// e.g. a cast chip you removed reappears, or an approve gets dropped. The mutex runs one PUT at a time and,
// if the DOC changed while a PUT was in flight, re-sends the LATEST DOC — so the last edit always wins.
let _saveInFlight = null, _saveDirty = false;
async function _persist() {
  if (!PROJECT || !DOC) return;
  if (_saveInFlight) { _saveDirty = true; return _saveInFlight; }   // a save is running → fold this into it
  _saveInFlight = (async () => {
    try {
      do { _saveDirty = false; await api.save(PROJECT, DOC); } while (_saveDirty);
    } finally { _saveInFlight = null; }
  })();
  return _saveInFlight;
}
function queueSave() {
  clearTimeout(saveTimer);
  setStatus("saving…");
  saveTimer = setTimeout(async () => { await _persist(); setStatus("saved"); setTimeout(() => setStatus(""), 1000); }, 600);
}
async function flushSave() { clearTimeout(saveTimer); await _persist(); }
// Safety net: if the app/window closes while a debounced edit (a note, a prompt, …) is still pending,
// push the current DOC out with keepalive so it survives the unload — otherwise that last edit is lost.
function _flushOnExit() {
  try {
    clearTimeout(saveTimer);
    if (PROJECT && DOC) fetch(`/api/scenes/${PROJECT}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(DOC), keepalive: true });
  } catch (_) {}
}
window.addEventListener("pagehide", _flushOnExit);
window.addEventListener("beforeunload", _flushOnExit);
// Jump to a scene on the Scenes tab (switch tab if needed) and flash the card — used by the "prompt
// generated" toast so the user can click straight to the scene it wrote.
// Scroll an element matching `sel` into view + flash it. The target tab may not have painted its list yet
// after activateTab(), so retry a few animation frames before giving up (fixes "clicking does nothing").
function _scrollFlashWhenReady(sel, tries = 30) {
  const el = document.querySelector(sel);
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.add("hist-flash"); setTimeout(() => el.classList.remove("hist-flash"), 1400);
    return;
  }
  if (tries > 0) requestAnimationFrame(() => _scrollFlashWhenReady(sel, tries - 1));
}
function jumpToScene(id) {
  activateTab("scenes");
  _scrollFlashWhenReady(`#scenesList .scene-row[data-id="${id}"]`);
}
// open the Testimonials tab and scroll to (and briefly flash) the specific testimonial card
function openTestimonialCard(cardId) {
  activateTab("testimonials");
  _scrollFlashWhenReady(`.tc-editor[data-cid="${cardId}"]`);
}
async function genPrompts(ids, signal) {
  setStatus("generating prompts…");
  // pull the LIVE Split + raw toggles from the DOM so the director's split override reflects what you see
  const _pw = (ids === "all" || ids == null) ? null : new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  (DOC?.scenes || []).forEach(s => {
    if (_pw && !_pw.has(String(s.id))) return;
    const row = document.querySelector(`#scenesList .scene-row[data-id="${s.id}"]`);
    if (!row) return;
    const spb = row.querySelector(".split-toggle"); if (spb) s.split = spb.classList.contains("on");
    const rb = row.querySelector(".cast-toggle"); if (rb) { s.no_cast = rb.classList.contains("on"); s.pure = rb.classList.contains("pure"); }
    const tsb = row.querySelector(".testi-toggle"); if (tsb) s.testimonial = tsb.classList.contains("on");
  });
  await flushSave();                       // ensure latest edited sentences are saved first
  pushUndo("generate prompts");            // undo restores the previous prompts
  const r = await api.genPrompt(PROJECT, ids, signal);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  // Merge ONLY the new prompt text into the existing scene objects and patch the textareas IN PLACE.
  // A full re-render here shifts the page a tick — bad when the user has scrolled away and is mid-click.
  const byId = {}; (DOC?.scenes || []).forEach(s => byId[s.id] = s);
  const _touched = (ids === "all" || ids == null) ? null : new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  (r.scenes || []).forEach(ns => { const s = byId[ns.id]; if (s) { s.prompt = ns.prompt; s.prompt_error = ns.prompt_error; s.cast = ns.cast; s.generic = ns.generic; } });
  // mark the regenerated scenes as handled so the split-regen hint stops nagging (it re-arms on the next Split toggle)
  (DOC?.scenes || []).forEach(s => { if (!_touched || _touched.has(String(s.id))) s._regenDone = true; });
  patchScenePrompts(ids);
  refreshAllSceneCast();   // the director may have auto-bound recurring characters (empty-cast scenes) → refresh Cast buttons in place
  setStatus("");
  // completion confirmation. For a SINGLE scene, name it and make the toast jump to that scene on click.
  const idList = (ids === "all" || ids == null) ? (DOC?.scenes || []).filter(s => (s.prompt || "").trim()).map(s => s.id)
                                                : (Array.isArray(ids) ? ids : [ids]);
  const _bad = (r.scenes || []).filter(ns => (ns.prompt_error || "").trim()).map(ns => ns.id);
  if (_bad.length) {
    toast(`Prompt failed for scene(s): ${_bad.join(", ")} — try again.`, "err", 8000);   // error sound via the toast hook
  } else if (idList.length === 1) {
    const sid = idList[0];
    toast(`Prompt generated: Scene ${sid}`, "ok", 3800, { onClick: () => jumpToScene(sid) });
    playNotifChime();
  } else {
    toast(`${idList.length} prompts generated.`, "ok");
    playNotifChime();
  }
}
function patchScenePrompts(ids) {   // update only the affected prompt textareas + button labels, no DOM rebuild
  const want = (ids === "all" || ids == null) ? null : new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  (DOC?.scenes || []).forEach(s => {
    if (want && !want.has(String(s.id))) return;
    const row = document.querySelector(`#scenesList .scene-row[data-id="${s.id}"]`);
    if (!row) return;
    const ta = row.querySelector(".prompt");
    if (ta && document.activeElement !== ta) ta.value = s.prompt || "";
    const gp = row.querySelector(".gen-prompt");
    if (gp) gp.textContent = (s.prompt && s.prompt.trim()) ? "↻ Re-Generate Prompt" : "✨ Generate Prompt";
    updateSplitRegenHint(row, s);
  });
}
// a "split prompt" is one the director wrote as two halves — it contains LEFT:/RIGHT: markers
function splitPromptReady(s) { const p = s.prompt || ""; return /(?:^|[^a-z])left\b[^:\n]{0,40}:/i.test(p) && /(?:^|[^a-z])right\b[^:\n]{0,40}:/i.test(p); }
// prompt's split-structure disagrees with the Split toggle (on but not split-written, OR off but still split-written).
// Suppressed once you've regenerated for the current toggle (_regenDone) — no endless nag if the director's split
// prompt just didn't contain literal LEFT:/RIGHT: markers; re-arms when you flip the Split toggle again.
function splitNeedsRegen(s) { return !s._regenDone && !!(s.prompt && s.prompt.trim()) && (!!s.split !== splitPromptReady(s)); }
// pulse the Re-Generate Prompt button green when the prompt needs to be (re)written to match the Split toggle
function updateSplitRegenHint(row, s) { const gp = row && row.querySelector(".gen-prompt"); if (gp) gp.classList.toggle("split-regen", splitNeedsRegen(s)); }
// After a user-triggered generation, surface any scene that FAILED with the real reason as a prominent
// toast — otherwise it just sits as a tiny red badge and looks like "nothing happened". Account errors
// (Kie credits/balance) get a big, explicit message.
function reportGenErrors(doc, ids, kind) {
  const scenes = (doc && doc.scenes) || [];
  const want = ids === "all" ? null : new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  const errs = [];
  scenes.forEach(s => {
    if (want && !want.has(String(s.id))) return;
    const m = kind === "video" ? s.video : s.image;
    if (m && m.status === "error" && m.error) errs.push({ id: s.id, error: String(m.error) });
  });
  if (!errs.length) return;
  const noun = kind === "video" ? "videos" : "images";
  if (errs.some(e => /credit|balance|insufficient|top ?up|quota/i.test(e.error))) {
    toast("⚠ Kie.ai balance too low to generate " + noun + " — top up your credits (make sure the key in Settings → API Keys is the account you funded).", "err", 14000);
  } else {
    const e0 = errs[0];
    toast(`⚠ ${kind === "video" ? "Video" : "Image"} failed: Scene ${e0.id} — ${e0.error}`, "err", 11000);
  }
}
async function genImages(ids) {
  setStatus("submitting…");
  // "what you see is what generates": pull the LIVE prompt text + raw (My-prompt) toggle straight from each
  // target card's DOM into the scene, so a save/DOC-replace race can never make it generate a stale prompt.
  const _want = new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  (DOC?.scenes || []).forEach(s => {
    if (!_want.has(String(s.id))) return;
    const row = document.querySelector(`#scenesList .scene-row[data-id="${s.id}"]`);
    if (!row) return;
    const ta = row.querySelector(".prompt"); if (ta) s.prompt = ta.value;
    const rb = row.querySelector(".cast-toggle"); if (rb) { s.no_cast = rb.classList.contains("on"); s.pure = rb.classList.contains("pure"); }
    const spb = row.querySelector(".split-toggle"); if (spb) s.split = spb.classList.contains("on");
    const tsb = row.querySelector(".testi-toggle"); if (tsb) s.testimonial = tsb.classList.contains("on");
  });
  { const arr = Array.isArray(ids) ? ids : [ids]; if (arr.length) _lastGenImgId = arr[arr.length - 1]; }   // "jump to latest" now targets what you just generated
  // Show "Generating…" INSTANTLY (same moment as the toast) — don't wait for the synchronous submit
  // (which uploads references and can take a couple seconds). The real result reconciles this below.
  (DOC?.scenes || []).forEach(s => { if (_want.has(String(s.id)) && s.image) { s.image.status = "generating"; s._appLock = Date.now() + 8000; } });
  patchAllSceneMedia(); renderGenProgress();
  await flushSave();                       // ensure latest edited prompts are saved first
  let fresh;
  try { fresh = await api.generate(PROJECT, ids); }
  catch (e) { toast("Couldn't start image generation (" + e + ").", "err"); setStatus(""); return; }
  if (fresh && fresh.error) { toastErr(fresh.error); setStatus(""); return; }
  // Submitting takes a few seconds. During that gap the user may add a scene or edit another card —
  // so MERGE the status in place (never replace the whole DOC) and patch the media in place (never a
  // full re-render). That keeps their new scene, their typing, focus and scroll exactly as they left them.
  mergePoll(fresh, true);                  // authoritative: the generate result must win even inside a recent _appLock window
  reportGenErrors(fresh, ids, "image");    // surface any immediate failure (credits, etc.) prominently
  patchAllSceneMedia(); buildSceneJump();
  ensurePolling(); renderGenProgress(); setStatus("");
}
async function genVideos(ids) {
  setStatus("submitting video…");
  { const arr = Array.isArray(ids) ? ids : [ids]; if (arr.length) _lastGenVidId = arr[arr.length - 1]; }   // "jump to latest" targets what you just generated
  await flushSave();
  let r;
  try { r = await api.genVideo(PROJECT, ids); }
  catch (e) { toast("Couldn't start video generation (" + e + ").", "err"); setStatus(""); return; }
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  mergePoll(r, true);                      // authoritative: the generate result must win even if the image was just approved (_appLock)
  reportGenErrors(r, ids, "video");        // surface any immediate failure (credits, etc.) prominently
  const typing = document.activeElement && /^(TEXTAREA|INPUT|SELECT)$/.test(document.activeElement.tagName);
  if (!typing) renderVideos();
  ensurePolling(); renderGenProgress(); setStatus("");
}
async function genVideoPrompts(ids, signal) {
  setStatus("generating video prompts…");
  await flushSave();                        // keep any hand-typed prompts before overwriting
  const r = await api.genVideoPrompt(PROJECT, ids, signal);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  DOC = r; renderVideos(); setStatus("");
}
async function editImage(sid, instr) {
  setStatus("editing image…");
  await flushSave();
  const r = await api.editImage(PROJECT, sid, instr);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  mergePoll(r, true);                      // authoritative: the edit result must win even inside a recent _appLock window
  reportGenErrors(r, [sid], "image");      // surface any immediate failure (credits, etc.) prominently
  const row = document.querySelector(`#scenesList .scene-row[data-id="${sid}"]`);   // edit accepted → close + clear the edit box
  if (row) {
    const eb = row.querySelector(".edit-box"); if (eb) eb.hidden = true;
    const ei = row.querySelector(".edit-instr"); if (ei) { ei.value = ""; ei.style.height = ""; }
  }
  patchAllSceneMedia(); buildSceneJump();
  ensurePolling(); setStatus("");
}

function anyGenerating() {
  const busy = s => s === "generating" || s === "queued";
  return DOC && DOC.scenes.some(s => busy(s.image.status) || busy(s.video.status));
}
// ---- batch-generation progress + retry-failed ----
function genCounts(kind) {
  const scenes = (DOC && DOC.scenes) || [];
  const c = { ready: 0, gen: 0, queued: 0, err: 0, errIds: [], busyIds: [] };
  scenes.forEach(s => {
    const im = kind === "image" ? s.image : s.video;
    const st = im && im.status;
    // a usable output already exists? (image → any version; video → a file) → it's NOT "failed" anymore,
    // even if the LAST attempt errored — the user re-generated it successfully.
    const hasOutput = kind === "image" ? ((im && im.versions) || []).length > 0 : !!(im && im.file);
    if (st === "generating") { c.gen++; c.busyIds.push(s.id); }
    else if (st === "queued") { c.queued++; c.busyIds.push(s.id); }
    else if (st === "ready" || hasOutput) c.ready++;
    else if (st === "error") { c.err++; c.errIds.push(s.id); }
  });
  c.total = c.ready + c.gen + c.queued + c.err;
  return c;
}
const _stopBatch = { image: false, video: false };   // true while a "Stop all" cancel loop runs → don't let a poll rebuild (and re-enable) the button
function renderGenProgress() {
  [["image", "#genProgress"], ["video", "#vidGenProgress"]].forEach(([kind, sel]) => {
    if (_stopBatch[kind]) return;                    // mid-cancel: leave the "Stopping…" button as-is
    const box = $(sel); if (!box) return;
    const c = genCounts(kind);
    if (c.gen === 0 && c.queued === 0 && c.err === 0) { box.hidden = true; box.innerHTML = ""; return; }
    box.hidden = false;
    const noun = kind === "image" ? "images" : "videos";
    const running = c.gen + c.queued;
    box.innerHTML =
      (c.gen ? `<span class="gp-gen gp-gen-link" title="Go to a ${kind} that's generating"><span class="sub-spin"></span> ${c.gen} ${noun} generating…</span>` : "") +
      (c.queued ? `<span class="gp-queued">🕒 ${c.queued} queued</span>` : "") +
      (c.err ? `<span class="gp-err gp-err-link" title="Go to the failed ${kind}">⚠ ${c.err} failed</span>` : "") +
      (running ? `<button class="gp-stop" title="Stop every ${noun.slice(0, -1)} still generating">⏹ Stop all</button>` : "");
    const genLink = box.querySelector(".gp-gen-link");
    if (genLink && c.busyIds.length) genLink.addEventListener("click", () => {   // jump to the generating scene nearest the viewport
      const cont = kind === "video" ? "#videosList" : "#scenesList";
      const rowcls = kind === "video" ? "video-row" : "scene-row";
      const mid = window.innerHeight / 2;
      let best = null, bestD = Infinity;
      c.busyIds.forEach(id => {
        const r = document.querySelector(`${cont} .${rowcls}[data-id="${id}"]`);
        if (!r) return;
        const rc = r.getBoundingClientRect(), d = Math.abs((rc.top + rc.bottom) / 2 - mid);
        if (d < bestD) { bestD = d; best = r; }
      });
      if (best) scrollToRow(best);
    });
    const errLink = box.querySelector(".gp-err-link");
    if (errLink && c.errIds.length) errLink.addEventListener("click", () => {
      const id = c.errIds[0];                                   // jump to the first failed scene/video
      const cont = kind === "video" ? "#videosList" : "#scenesList";
      const rowcls = kind === "video" ? "video-row" : "scene-row";
      const r = document.querySelector(`${cont} .${rowcls}[data-id="${id}"]`);
      scrollToRow(r);
    });
    const stopBtn = box.querySelector(".gp-stop");
    if (stopBtn) stopBtn.addEventListener("click", async () => {
      _stopBatch[kind] = true;                                  // freeze this progress box so a poll can't re-enable the button mid-cancel
      stopBtn.disabled = true; stopBtn.textContent = "Stopping…";
      const ids = genCounts(kind).busyIds;                      // re-read: some may have finished since render
      const cancel = kind === "image" ? api.cancelImage : api.cancelVideo;
      let last = null;
      for (const id of ids) { try { last = await cancel(PROJECT, id); } catch (_) {} }
      if (last && last.scenes) { DOC = last; }                  // adopt the server's post-cancel truth
      _stopBatch[kind] = false;
      kind === "image" ? renderScenes() : renderVideos();
      renderGenProgress();
    });
  });
}
// merge poll results into the EXISTING scene objects in place, so open edit boxes,
// unsaved text and focus in the scene list are never destroyed by a full re-render.
function mergePoll(fresh, authoritative) {   // authoritative = the direct result of a user action (generate/cancel/edit) → apply it fully, ignore _appLock
  if (!DOC || !fresh || !fresh.scenes) return { vid: false };
  let vid = false;                              // did anything the Videos tab shows actually change?
  const byId = {}; DOC.scenes.forEach(s => byId[s.id] = s);
  const busy = st => st === "generating" || st === "queued";
  fresh.scenes.forEach(fs => {
    const s = byId[fs.id];
    if (!s) return;
    // A user action (approve / cancel / version-swap) sets s._appLock for ~8s. During that window a poll
    // that started BEFORE the action's save landed still carries the OLD state — don't let it revert.
    const locked = !authoritative && s._appLock && Date.now() < s._appLock;
    // Keep the WHOLE local media object for a locked scene that is NOT mid-generation (i.e. the user just
    // approved / cancelled / swapped a settled scene). A scene still generating keeps taking fresh updates
    // so real progress always flows. This is the core "no reverting while I work fast" guard.
    const keepImgWhole = locked && s.image && !busy(s.image.status);
    const keepVidWhole = locked && s.video && !busy(s.video.status);

    if (!keepImgWhole) genTransitionToast(s.id, "Image", s.image && s.image.status, fs.image && fs.image.status, fs.image && fs.image.error);
    if (!keepVidWhole) genTransitionToast(s.id, "Video", s.video && s.video.status, fs.video && fs.video.status, fs.video && fs.video.error);
    const ov = s.video || {}, nv = fs.video || {}, oi = s.image || {}, ni = fs.image || {};
    if (!keepVidWhole && (ov.status !== nv.status || ov.file !== nv.file || ov.approved !== nv.approved)) vid = true;
    if (!keepImgWhole && s.approved && (oi.approved_file !== ni.approved_file || oi.file !== ni.file)) vid = true;

    const keepApproved = locked ? s.approved : fs.approved;
    const keepAppVer = locked && s.image ? s.image.approved_version : undefined;
    const keepCurrent = locked && s.image ? s.image.current : undefined;   // don't let a poll snap the shown version back
    const keepVidAppr = locked && s.video ? s.video.approved : undefined;
    if (!keepImgWhole) s.image = fs.image;
    if (!keepVidWhole) s.video = fs.video;
    s.approved = keepApproved;
    if (locked) {
      if (s.image && !keepImgWhole) {
        s.image.approved_version = keepAppVer;
        if (keepCurrent != null && keepCurrent < (s.image.versions || []).length) s.image.current = keepCurrent;
      }
      if (s.video && !keepVidWhole) s.video.approved = keepVidAppr;
    }
    if (s.approved !== keepApproved) vid = true;
  });
  return { vid };
}
// Adopt a server doc WITHOUT swapping scene object references — so per-scene edit closures (camera dropdown,
// prompt/vo textareas, mode toggle…) keep pointing at LIVE DOC objects. `DOC = await api.approve()` used to
// replace every scene object; the DOM cards still referenced the OLD objects, so a camera/prompt change made
// right after an approve was written to an orphan and lost (the "camera won't change after PURE" bug).
function adoptDocInPlace(doc2) {
  if (!doc2) return;
  if (doc2.scenes && DOC && DOC.scenes) {
    const byUid = {}; DOC.scenes.forEach(s => byUid[s.uid] = s);
    if (doc2.scenes.length === DOC.scenes.length && doc2.scenes.every(fs => byUid[fs.uid])) {
      doc2.scenes.forEach(fs => Object.assign(byUid[fs.uid], fs));   // same scene set → merge fields in place (keeps references)
      Object.keys(doc2).forEach(k => { if (k !== "scenes") DOC[k] = doc2[k]; });
      return;
    }
  }
  DOC = doc2;   // structure changed (scene added/removed) → full swap; a renderScenes always follows those paths
}
// ---- soft "generation done" chime (WebAudio → no asset file to ship). Off = the tray/Settings mute. ----
let NOTIF_SOUND = true;                       // mirrors the server pref (loaded in boot); tray toggles it live
let _actx = null;
window.__setNotifSound = (on) => { NOTIF_SOUND = !!on; };   // called by the desktop tray menu via evaluate_js
function playNotifChime() {
  if (!NOTIF_SOUND) return;
  try {
    _actx = _actx || new (window.AudioContext || window.webkitAudioContext)();
    if (_actx.state === "suspended") _actx.resume();
    const now = _actx.currentTime;
    // two soft ascending notes (E6 → A6), gentle bell-ish sine, low volume ("kısık")
    [[1318.5, 0.0], [1760.0, 0.12]].forEach(([f, t]) => {
      const o = _actx.createOscillator(), g = _actx.createGain();
      o.type = "sine"; o.frequency.value = f;
      const s = now + t;
      g.gain.setValueAtTime(0.0001, s);
      g.gain.exponentialRampToValueAtTime(0.09, s + 0.02);   // peak ~9% → quiet, non-jarring
      g.gain.exponentialRampToValueAtTime(0.0001, s + 0.32);
      o.connect(g).connect(_actx.destination);
      o.start(s); o.stop(s + 0.34);
    });
  } catch (e) {}
}
// ---- error chime: two soft DESCENDING notes (G4 → C4) — a gentle "uh-oh" for any failure. Same mute. ----
function playErrorChime() {
  if (!NOTIF_SOUND) return;
  try {
    _actx = _actx || new (window.AudioContext || window.webkitAudioContext)();
    if (_actx.state === "suspended") _actx.resume();
    const now = _actx.currentTime;
    [[392.0, 0.0], [261.63, 0.15]].forEach(([f, t]) => {
      const o = _actx.createOscillator(), g = _actx.createGain();
      o.type = "triangle"; o.frequency.value = f;
      const s = now + t;
      g.gain.setValueAtTime(0.0001, s);
      g.gain.exponentialRampToValueAtTime(0.07, s + 0.02);   // matched to the success chime's loudness (triangle sounds louder than sine at equal amplitude, so a touch below its 0.09)
      g.gain.exponentialRampToValueAtTime(0.0001, s + 0.32);
      o.connect(g).connect(_actx.destination);
      o.start(s); o.stop(s + 0.34);
    });
  } catch (e) {}
}
// Slide-in toast the moment an image/video finishes: pending (generating/queued) → ready or error.
// Guarding on the OLD state being pending means it never fires on load for already-done scenes.
function genTransitionToast(id, kind, oldSt, newSt, err) {
  const pending = st => st === "generating" || st === "queued";
  if (oldSt === newSt || !pending(oldSt)) return;
  const goThere = () => histGoto({ kind, id });   // click the toast → jump to that scene's image/video
  if (newSt === "ready") {
    if (kind === "Image") _lastGenImgId = id; else if (kind === "Video") _lastGenVidId = id;   // remember the most-recent generation for the "jump to latest" button
    toast(`${kind} generated: Scene ${id}`, "ok", 3800, { noHist: true, onClick: goThere }); pushHistory(kind, id, true);
    playNotifChime();   // soft confirmation sound (mute via the tray / Settings)
  }
  else if (newSt === "error") {
    if (err && /credit|balance|insufficient|top ?up|quota/i.test(err))
      toast("⚠ Kie.ai balance too low — top up your credits to keep generating.", "err", 14000, { noHist: true, onClick: goThere });
    else toast(`⚠ ${kind} failed: Scene ${id}${err ? " — " + err : ""}`, "err", 10000, { noHist: true, onClick: goThere });
    pushHistory(kind, id, false);
  }
}
// update ONLY the image preview / status / version-nav of a scene row (no DOM wipe).
function patchSceneMedia(el, s) {
  const im = s.image, vs = im.versions || [];
  let cur = (im.current == null ? vs.length - 1 : im.current);
  const curFile = (vs.length && cur >= 0 && cur < vs.length) ? vs[cur] : null;
  const imgPrev = $(".img-preview", el);
  if (imgPrev.dataset.file !== (curFile || "")) {   // only rebuild when the shown file changed
    imgPrev.dataset.file = curFile || "";
    imgPrev.innerHTML = "";
    if (curFile) {
      imgPrev.classList.add("img-loading");
      const src = thumbUrl(curFile, s.image.taskId);   // light preview in the card; full 2K opens on click
      const img = document.createElement("img");
      img.addEventListener("load", () => imgPrev.classList.remove("img-loading"));
      img.addEventListener("error", () => imgPrev.classList.remove("img-loading"));
      img.src = src;
      img.addEventListener("click", () => openImageLightbox(s));
      imgPrev.appendChild(img);
      const ov = document.createElement("div");
      ov.className = "img-actions";
      const approvedThis = s.approved && im.approved_version === cur;
      const bApprove = document.createElement("button");
      bApprove.className = "ia approve" + (approvedThis ? " on" : "");
      bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
      bApprove.textContent = "✓";
      const bChange = document.createElement("button");
      bChange.className = "ia change"; bChange.title = "Change (regenerate)"; bChange.textContent = "↻";
      const bRemove = document.createElement("button");
      bRemove.className = "ia remove"; bRemove.title = "Remove"; bRemove.innerHTML = TRASH_SVG;
      bApprove.onclick = async (e) => {
        e.stopPropagation();
        if (s._approving) return;                                    // one request at a time → no toast/request pileup while generation holds the server lock
        s._approving = true;
        const willApprove = !bApprove.classList.contains("on");
        bApprove.classList.toggle("on", willApprove);               // OPTIMISTIC: instant feedback; long _appLock stops a poll reverting it during the wait
        s.approved = willApprove; if (willApprove && s.image) s.image.approved_version = cur;
        s._appLock = Date.now() + 45000;
        buildSceneJump();
        if (willApprove) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
        try {
          await flushSave();
          adoptDocInPlace(await api.approve(PROJECT, s.id, willApprove));   // merge in place → edit closures stay LIVE after approve
          s._appLock = Date.now() + 8000;
          if (hideApproved && s.approved) renderScenes();
          else patchApprove(el, s, cur, bApprove);
          buildSceneJump(); renderVideos();
        } catch (_) {
          s.approved = !willApprove; bApprove.classList.toggle("on", !willApprove); s._appLock = 0;
          buildSceneJump(); toast(`Could not ${willApprove ? "approve" : "unapprove"} Scene ${s.id} - try again.`, "err");
        } finally { s._approving = false; }
      };
      bChange.onclick = (e) => { e.stopPropagation(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); };
      bRemove.title = "Delete this version";
      bRemove.onclick = async (e) => { e.stopPropagation(); pushUndo("delete image"); s._appLock = Date.now() + 8000; DOC = await api.deleteVersion(PROJECT, s.id, cur); const _f = DOC.scenes.find(x => x.id === s.id); if (_f) _f._appLock = Date.now() + 8000; toast(`Deleted Image: Scene ${s.id}`, "info"); renderScenes(); renderVideos(); };   // _appLock: a stale in-flight poll must not resurrect the deleted version
      ov.appendChild(bApprove); ov.appendChild(bChange); ov.appendChild(bRemove);
      imgPrev.appendChild(ov);
      const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";   // download, bottom-right
      const bDl = document.createElement("button");
      bDl.className = "ia download"; bDl.title = "Download this image";
      bDl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
      bDl.addEventListener("click", (e) => { e.stopPropagation(); downloadMedia(curFile, `${pad2(s.id)}_${slug(s.vo)}.png`, `Scene ${s.id}`); });
      ovb.appendChild(bDl); imgPrev.appendChild(ovb);
    } else if (im.status === "generating" || im.status === "queued") {
      imgPrev.innerHTML = "";   // mid-generation with no prior image → only the "Generating…" overlay shows, no "no image" text under it
    } else {
      imgPrev.innerHTML = '<div class="placeholder">no image</div>';
    }
    drawSceneOst(el, s);   // innerHTML wipe above removed the .scene-ost overlays → redraw them on the new image
    renderSceneIcons(el, s);   // and the overlay icons (X / arrow / pain-burst)
  }
  // loading overlay while (re)generating or queued; removed once it's ready/error/empty
  if (im.status === "generating" || im.status === "queued") {
    const ph = imgPrev.querySelector(".placeholder"); if (ph) ph.remove();   // no "no image" text under the "Generating…" overlay
    addGenOverlay(imgPrev, im.status);
  } else {
    const o = imgPrev.querySelector(".gen-overlay"); if (o) o.remove();
    if (!curFile && !imgPrev.querySelector("img") && !imgPrev.querySelector(".placeholder")) {
      imgPrev.innerHTML = '<div class="placeholder">no image</div>';   // generation ended with no image → restore the placeholder
      drawSceneOst(el, s);
    }
  }
  setBadge($(".img-status", el), im);
  const nav = $(".img-nav", el);
  if (vs.length) {
    nav.hidden = false;
    const av = im.approved_version;
    const isApprovedVer = s.approved && av === cur;
    wireVerArrows($(".img-preview", el), s, cur, vs.length);   // arrows + version badge overlay the image
    const editBox = $(".edit-box", el);
    $(".ver-edit", el).onclick = () => { editBox.hidden = !editBox.hidden; };
      { const _fb = $(".ver-fill", el); if (_fb) _fb.onclick = () => openInpaint(el, s); }
    $(".edit-apply", el).onclick = (ev) => {
      const instr = $(".edit-instr", el).value.trim();
      if (!instr) { alert("Type what to change."); return; }
      withBusy(ev.currentTarget, () => editImage(s.id, instr));
    };
  } else {
    nav.hidden = true;
  }
  const gi = $(".gen-img", el);
  if (gi) setBusy(gi, s.image.status === "generating");
}
function patchAllSceneMedia() {
  const list = $("#scenesList"); if (!list) return;
  const byId = {}; (DOC?.scenes || []).forEach(s => byId[s.id] = s);
  $$(".scene-row", list).forEach(el => { const s = byId[el.dataset.id]; if (s) { try { patchSceneMedia(el, s); } catch (e) { /* one scene's error must never freeze the rest (overlays stuck) */ } } });
}
// Stop an accidental / in-progress image generation for one scene.
async function cancelImage(sid) {
  const s0 = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (s0 && s0.image) {                             // OPTIMISTIC: drop the "Generating…" overlay instantly, don't wait on the server
    const vs = s0.image.versions || [];
    s0.image.status = vs.length ? "ready" : "empty";
    s0.image.taskId = null;
    s0._appLock = Date.now() + 8000;
    patchAllSceneMedia(); renderGenProgress();
  }
  let fresh;
  try { fresh = await api.cancelImage(PROJECT, sid); }
  catch (e) { toast("Couldn't reach the server to stop it — it may still finish; try again.", "err"); return; }
  mergePoll(fresh, true);                           // authoritative cancel result reconciles the optimistic state
  const _s = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (_s) _s._appLock = Date.now() + 8000;          // a late in-flight poll must not revert the cancel
  patchAllSceneMedia(); renderGenProgress();
  if (!anyGenerating() && pollTimer) { clearInterval(pollTimer); pollTimer = null; setStatus(""); }
  toast("Image generation stopped.", "info");
}
// Stop an in-progress VIDEO generation for one scene.
async function cancelVideo(sid) {
  const s0 = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (s0 && s0.video) {                             // OPTIMISTIC: drop the "Generating…" overlay instantly
    s0.video.status = s0.video.file ? "ready" : "empty";
    s0.video.taskId = null;
    s0._appLock = Date.now() + 8000;
    renderVideos();
  }
  let fresh;
  try { fresh = await api.cancelVideo(PROJECT, sid); }
  catch (e) { toast("Couldn't reach the server to stop it — it may still finish; try again.", "err"); return; }
  mergePoll(fresh, true);                          // authoritative cancel result reconciles the optimistic state
  const _s = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (_s) _s._appLock = Date.now() + 8000;         // a late in-flight poll must not revert the cancel
  renderVideos();
  if (!anyGenerating() && pollTimer) { clearInterval(pollTimer); pollTimer = null; setStatus(""); }
  toast("Video generation stopped.", "info");
}
document.addEventListener("click", (ev) => {
  const btn = ev.target.closest(".gen-stop");
  if (!btn) return;
  ev.preventDefault(); ev.stopPropagation();
  const vrow = btn.closest(".video-row");                  // Videos tab → stop the VIDEO job
  if (vrow && vrow.dataset.id) { btn.disabled = true; cancelVideo(vrow.dataset.id); return; }
  const row = btn.closest(".scene-row");                   // Scenes tab → stop the IMAGE job
  if (row && row.dataset.id) { btn.disabled = true; cancelImage(row.dataset.id); }
});
// SINGLE-FLIGHT polling: a self-scheduling setTimeout (not setInterval) so a slow poll can NEVER
// overlap the next one. The 6s gap is measured from the END of each poll, so under heavy generation
// (many images/videos, big downloads) requests never pile up — this is what keeps the UI smooth and
// stops the "reverting / lag while I work fast" behaviour. All screen updates here are in-place
// (patchAllSceneMedia only rebuilds an <img> when its file changed), so scrolling is never disturbed.
let _pollBusy = false;
let _pollStart = 0;
async function _pollTick() {
  pollTimer = null;
  _pollBusy = true; _pollStart = Date.now();
  try {
    const fresh = await api.poll(PROJECT);
    const ch = mergePoll(fresh) || {};
    patchAllSceneMedia();       // non-destructive image/status patch (keeps prompt/vo textareas intact)
    buildSceneJump();           // recolor scene chips so a finished/approved scene turns green right away
    // Only rebuild the Videos list when a video ACTUALLY changed (finished/approved) — not every tick —
    // and never while the user is typing in a field. This is what stops the periodic scroll stutter / lag.
    const _typing = document.activeElement && /^(TEXTAREA|INPUT|SELECT)$/.test(document.activeElement.tagName);
    if (ch.vid && !_typing) renderVideos();
    renderGenProgress();
  } catch (_) {
    /* transient network blip — just try again on the next tick, never surface it as an error */
  } finally {
    _pollBusy = false;
  }
  if (anyGenerating()) pollTimer = setTimeout(_pollTick, 6000);   // schedule the next only after this one finished
  else setStatus("");
}
function ensurePolling() {
  if (_pollBusy && Date.now() - _pollStart > 60000) _pollBusy = false;   // a wedged poll can't kill polling forever
  if (pollTimer || _pollBusy || !anyGenerating()) return;
  pollTimer = setTimeout(_pollTick, anyGenerating() ? 1500 : 6000);      // first check soon after a submit
}

// Dry-run: show the EXACT final image prompt (assembled server-side, same code the real generation uses)
// so the user can catch conflicts before spending a generation. Built with textContent (no innerHTML) so
// prompt text can never break the markup.
// Attach a script-style Ctrl+F finder (orange highlights + count + prev/next) to a modal textarea.
// Wraps the textarea with a highlight backdrop and a floating find box. Returns {open, close, isOpen}.
function attachFinder(ta) {
  const wrap = document.createElement("div"); wrap.className = "pf-wrap";
  ta.parentNode.insertBefore(wrap, ta);
  const bd = document.createElement("div"); bd.className = "pf-bd";
  wrap.appendChild(bd); wrap.appendChild(ta);
  const box = document.createElement("div"); box.className = "pf-box";
  const inp = document.createElement("textarea"); inp.className = "pf-input"; inp.rows = 1; inp.placeholder = "Find"; inp.spellcheck = false;
  const cnt = document.createElement("span"); cnt.className = "pf-count";
  const prev = document.createElement("button"); prev.className = "pf-btn"; prev.textContent = "▲"; prev.title = "Previous (Shift+Enter)";
  const next = document.createElement("button"); next.className = "pf-btn"; next.textContent = "▼"; next.title = "Next (Enter)";
  const cls = document.createElement("button"); cls.className = "pf-btn"; cls.textContent = "✕"; cls.title = "Close (Esc)";
  box.append(inp, cnt, prev, next, cls); wrap.appendChild(box);
  let matches = [], cur = -1;
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const render = () => { cnt.textContent = matches.length ? `${cur + 1}/${matches.length}` : (inp.value.trim() ? "0/0" : ""); };
  function syncMetrics() {
    const cs = getComputedStyle(ta);
    ["fontFamily", "fontSize", "fontWeight", "fontStyle", "lineHeight", "letterSpacing", "wordSpacing", "textIndent", "tabSize",
      "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth"].forEach(p => bd.style[p] = cs[p]);
  }
  function paint() {
    if (!box.classList.contains("show") || !matches.length) { bd.innerHTML = ""; return; }
    syncMetrics();
    const q = inp.value, text = ta.value; let html = "", last = 0;
    matches.forEach((st, idx) => { html += esc(text.slice(last, st)) + `<mark class="${idx === cur ? "cur" : ""}">` + esc(text.slice(st, st + q.length)) + "</mark>"; last = st + q.length; });
    html += esc(text.slice(last)); bd.innerHTML = html; bd.scrollTop = ta.scrollTop; bd.scrollLeft = ta.scrollLeft;
  }
  function scrollTo(pos) { const line = ta.value.slice(0, pos).split("\n").length - 1; const lh = parseFloat(getComputedStyle(ta).lineHeight) || 20; ta.scrollTop = Math.max(0, line * lh - ta.clientHeight / 2); bd.scrollTop = ta.scrollTop; }
  function select(k) { const q = inp.value, st = matches[k]; ta.setSelectionRange(st, st + q.length); scrollTo(st); render(); paint(); }
  function compute() { const q = inp.value, tl = ta.value.toLowerCase(), ql = q.toLowerCase(); matches = []; if (ql) { let i = tl.indexOf(ql); while (i !== -1) { matches.push(i); i = tl.indexOf(ql, i + ql.length); } } cur = matches.length ? 0 : -1; render(); if (cur >= 0) select(cur); else paint(); }
  function step(d) { if (!matches.length) return; cur = (cur + d + matches.length) % matches.length; select(cur); }
  function grow() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 120) + "px"; }
  inp.addEventListener("input", () => { grow(); compute(); });
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); step(e.shiftKey ? -1 : 1); } else if (e.key === "Escape") { e.preventDefault(); close(); } });
  ta.addEventListener("scroll", () => { bd.scrollTop = ta.scrollTop; bd.scrollLeft = ta.scrollLeft; });
  next.addEventListener("click", () => step(1)); prev.addEventListener("click", () => step(-1)); cls.addEventListener("click", close);
  function open() { box.classList.add("show"); inp.focus(); inp.select(); grow(); compute(); }
  function close() { box.classList.remove("show"); bd.innerHTML = ""; ta.focus(); }
  return { open, close, isOpen: () => box.classList.contains("show") };
}
async function showPromptPreview(sid) {
  let data = null;
  try { await flushSave(); } catch (_) {}   // persist any just-changed camera / prompt / split first, so the preview matches what will generate
  try { data = await api.previewPrompt(PROJECT, sid); } catch (_) {}
  if (!data) { toast("Could not load the prompt preview.", "err"); return; }
  const ov = document.createElement("div"); ov.className = "pp-overlay";
  const box = document.createElement("div"); box.className = "pp-box";
  let onKey = null, finder = null;
  const close = () => { ov.remove(); if (onKey) document.removeEventListener("keydown", onKey); };

  const head = document.createElement("div"); head.className = "pp-head";
  const title = document.createElement("b");
  title.textContent = `Final image prompt — Scene ${sid}` + (data.raw ? "  ·  RAW mode" : "");
  const x = document.createElement("button"); x.className = "pp-x"; x.textContent = "✕"; x.title = "Close";
  head.appendChild(title); head.appendChild(x);

  const info = document.createElement("div"); info.className = "pp-info";
  (data.info || []).forEach(t => { const s = document.createElement("span"); s.textContent = "• " + t; info.appendChild(s); });

  const ta = document.createElement("textarea"); ta.className = "pp-text"; ta.readOnly = true;
  ta.value = data.prompt || "(this scene has no prompt yet)";

  const actions = document.createElement("div"); actions.className = "pp-actions";
  const copy = document.createElement("button"); copy.className = "pp-copy ghost"; copy.textContent = "Copy";
  const hint = document.createElement("span"); hint.className = "pp-hint"; hint.textContent = "Exactly what Generate Image will send.";
  actions.appendChild(copy); actions.appendChild(hint);

  box.appendChild(head); if ((data.info || []).length) box.appendChild(info); box.appendChild(ta); box.appendChild(actions);
  ov.appendChild(box); document.body.appendChild(ov);

  box.addEventListener("click", e => e.stopPropagation());
  ov.addEventListener("click", close);
  x.addEventListener("click", close);
  copy.addEventListener("click", () => {
    ta.select();
    const done = () => toast("Prompt copied.", "ok");
    if (navigator.clipboard) navigator.clipboard.writeText(ta.value).then(done).catch(() => { document.execCommand("copy"); done(); });
    else { document.execCommand("copy"); done(); }
  });
  finder = attachFinder(ta);   // Ctrl+F search inside the Final-prompt window (same look as the Script find)
  onKey = (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === "f" || e.key === "F")) { e.preventDefault(); finder.open(); return; }
    if (e.key === "Escape") { if (finder.isOpen()) finder.close(); else close(); }
  };
  document.addEventListener("keydown", onKey, true);   // capture → beats the WebView's native find
}

function lightbox(src, kind) {
  const lb = document.createElement("div");
  lb.className = "lightbox";
  const stage = document.createElement("div");
  stage.className = "lb-stage";
  stage.addEventListener("click", e => e.stopPropagation());
  stage.innerHTML = kind === "img" ? `<img src="${src}">` : `<video src="${src}" controls autoplay>`;
  const ov = document.createElement("div"); ov.className = "img-actions";
  const bClose = document.createElement("button"); bClose.className = "ia lb-close"; bClose.textContent = "✕"; bClose.title = "Close";
  ov.appendChild(bClose); stage.appendChild(ov);
  lb.appendChild(stage);
  const close = () => lb.remove();
  bClose.addEventListener("click", (e) => { e.stopPropagation(); close(); });
  lb.addEventListener("click", close);
  document.body.appendChild(lb);
}

// large image view WITH the same approve/change/remove actions + version arrows
// Play the green approve check-burst inside any positioned container (used by the fullscreen
// lightbox so approving there gets the same feedback as the small card).
function approveBurst(imgEl) {
  // Size/position the burst to the IMAGE itself (not the whole stage, which can be larger than
  // the letterboxed image) so it sits exactly over the picture and never spills out the sides.
  if (!imgEl) return;
  const host = imgEl.offsetParent || imgEl.parentElement;
  if (!host) return;
  const b = document.createElement("div"); b.className = "approve-burst"; b.innerHTML = "<span>✓</span>";
  b.style.left = imgEl.offsetLeft + "px";
  b.style.top = imgEl.offsetTop + "px";
  b.style.width = imgEl.offsetWidth + "px";
  b.style.height = imgEl.offsetHeight + "px";
  host.appendChild(b);
  setTimeout(() => b.remove(), 800);
}

function openImageLightbox(s) {
  if (!(s.image.versions || []).length) return;
  let cur = (s.image.current == null ? s.image.versions.length - 1 : s.image.current);

  const lb = document.createElement("div");
  lb.className = "lightbox";
  const stage = document.createElement("div");
  stage.className = "lb-stage";
  stage.addEventListener("click", e => e.stopPropagation());   // clicks inside never close
  lb.appendChild(stage);

  const imgEl = document.createElement("img");
  stage.appendChild(imgEl);

  // on-screen text overlays on the enlarged image (same styling as the card + preview)
  function drawLbOst() {
    stage.querySelectorAll(".scene-ost").forEach(n => n.remove());
    if (!s.ost_on) return;
    const w = imgEl.getBoundingClientRect().width || imgEl.clientWidth || 800, scale = w / 1920;
    const row = document.querySelector(`.scene-row[data-id="${s.id}"]`);
    (s.overlays || []).forEach((ov, i) => {
      const txt = (ov.onscreen || "").trim(); if (!txt) return;
      const lbOst = document.createElement("div"); lbOst.innerHTML = '<span class="scene-ost-txt"></span>';
      lbOst.className = "scene-ost place-" + (ov.ost_place || "top");
      stage.appendChild(lbOst);
      ostWrapPos(lbOst, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
      const span = lbOst.querySelector(".scene-ost-txt");
      span.textContent = txt;
      ostTextStyle(span, ostOpts(ov), scale);
      const panel = row && row.querySelectorAll(".ost-panel")[i];
      const delBtn = panel && panel.querySelector(".ost-del-overlay");
      ostInteractive(lbOst, ov, scale, stage, {
        sync: (f, v) => { const inp = panel && panel.querySelector(OST_INP[f]); if (inp) inp.value = v; },
        commit: () => { queueSave(); if (row) { const s2 = (DOC.scenes || []).find(x => x.id === s.id); if (s2) drawSceneOst(row, s2); } },
        onDelete: () => { if (delBtn) delBtn.click(); setTimeout(drawLbOst, 360); },   // remove, then redraw the lightbox
      });
    });
  }
  // overlay icons on the enlarged image, editable exactly like on the card (drag/snap/resize/rotate/recolour)
  function drawLbIcons() {
    stage.querySelectorAll(".icon-layer").forEach(n => n.remove());
    const icons = Array.isArray(s.icons) ? s.icons : [];
    if (!icons.length) return;   // 2D scenes CAN show manually-placed icons (auto never adds them)
    const ib = imgEl.getBoundingClientRect(), sb = stage.getBoundingClientRect();
    if (!ib.width) return;
    const layer = document.createElement("div"); layer.className = "icon-layer";
    layer.style.left = (ib.left - sb.left) + "px"; layer.style.top = (ib.top - sb.top) + "px";
    layer.style.right = "auto"; layer.style.bottom = "auto";
    layer.style.width = ib.width + "px"; layer.style.height = ib.height + "px";
    stage.appendChild(layer);
    const row = document.querySelector(`.scene-row[data-id="${s.id}"]`);
    icons.forEach(ic => buildIconNode(ic, s, layer, {
      commit: () => { queueSave(); if (row) renderSceneIcons(row, s); },
      redraw: () => drawLbIcons(),
    }));
  }
  imgEl.addEventListener("load", () => { drawLbOst(); drawLbIcons(); });
  const onResizeOst = () => { drawLbOst(); drawLbIcons(); };
  window.addEventListener("resize", onResizeOst);

  const ov = document.createElement("div");
  ov.className = "img-actions";
  const bApprove = document.createElement("button"); bApprove.className = "ia approve"; bApprove.textContent = "✓";
  const bChange = document.createElement("button"); bChange.className = "ia change"; bChange.textContent = "↻"; bChange.title = "Change (regenerate)";
  const bClose = document.createElement("button"); bClose.className = "ia lb-close"; bClose.textContent = "✕"; bClose.title = "Close";
  ov.append(bApprove, bChange, bClose);
  stage.appendChild(ov);

  const prev = document.createElement("button"); prev.className = "lb-arrow lb-prev"; prev.innerHTML = CHEV_L; prev.title = "Previous version";
  const next = document.createElement("button"); next.className = "lb-arrow lb-next"; next.innerHTML = CHEV_R; next.title = "Next version";
  const label = document.createElement("div"); label.className = "lb-label";
  stage.append(prev, next, label);

  const startCur = cur;
  const onKey = (e) => {
    if (e.key === "Escape") close();
    else if (e.key === "ArrowLeft") go(-1);
    else if (e.key === "ArrowRight") go(1);
    else if (e.key === "a" || e.key === "A") { e.preventDefault(); bApprove.click(); }   // approve shown version
    else if (e.key === "r" || e.key === "R") { e.preventDefault(); bChange.click(); }     // regenerate
  };
  async function close() {
    document.removeEventListener("keydown", onKey);
    window.removeEventListener("resize", onResizeOst);
    lb.remove();
    // persist the last-viewed version as current (single call, nothing else in flight — no race)
    if (cur !== startCur && cur !== s.image.current) {
      await api.setCurrent(PROJECT, s.id, cur);
      DOC = await api.get(PROJECT); renderScenes(); renderVideos();
    }
  }
  lb.addEventListener("click", close);

  function refresh() {
    const im = s.image, vs = im.versions || [];
    if (!vs.length) { close(); return; }
    cur = Math.min(Math.max(cur, 0), vs.length - 1);
    imgEl.src = mediaUrl(vs[cur], im.taskId);
    const approvedThis = s.approved && im.approved_version === cur;
    bApprove.classList.toggle("on", approvedThis);
    bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
    label.textContent = `${cur + 1} / ${vs.length}`;
    prev.disabled = cur <= 0;
    next.disabled = cur >= vs.length - 1;
    drawLbOst(); drawLbIcons();                          // keep the on-screen text + icon overlays in sync
  }
  function syncLocal() { const s2 = (DOC.scenes || []).find(x => x.id === s.id); if (s2) { s.image = s2.image; s.approved = s2.approved; } }

  // arrows are LOCAL only (just change the shown version) — no server call while browsing,
  // so nothing races with approve. Current is persisted once on close.
  function go(delta) {
    const vs = s.image.versions || [];
    const n = Math.min(Math.max(cur + delta, 0), vs.length - 1);
    if (n === cur) return;
    const dir = n > cur ? 1 : -1;
    const newSrc = mediaUrl(vs[n], s.image.taskId);
    cur = n;
    slideSwap(stage, imgEl, dir, newSrc, { commit: refresh });   // slide the new version in (full-screen)
  }
  prev.onclick = e => { e.stopPropagation(); go(-1); };
  next.onclick = e => { e.stopPropagation(); go(1); };
  bApprove.onclick = async e => {
    e.stopPropagation();
    const approvedThis = s.approved && s.image.approved_version === cur;
    // pass the shown version explicitly so THIS version is approved + made current atomically —
    // the small card then shows exactly what was approved.
    if (!approvedThis) { _flashApprove = s.id; approveBurst(imgEl); }   // burst exactly over the image
    DOC = await api.approve(PROJECT, s.id, !approvedThis, cur); syncLocal();
    renderScenes(); renderVideos(); refresh();
    if (!approvedThis) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
  };
  bChange.onclick = e => { e.stopPropagation(); close(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); };
  bClose.onclick = e => { e.stopPropagation(); close(); };

  document.addEventListener("keydown", onKey);
  refresh();
  document.body.appendChild(lb);
}

// ---------- toolbar ----------
$("#homeBtn").addEventListener("click", showHome);
$("#brandHome").addEventListener("click", showHome);
// The project-name button is a project switcher, NOT a home link (Home is the 🏠 button / the logo).
$("#projName").addEventListener("click", async (e) => {
  e.stopPropagation();
  const menu = $("#projMenu");
  const wasOpen = !menu.hidden;
  $$(".model-menu").forEach(m => m.hidden = true);
  if (wasOpen) return;
  const list = await api.projects();
  // Clear AFTER the await (not before): the handler is async, so two quick opens can overlap. Clearing
  // up front let each overlapping call append its own copy → the list stacked duplicates. Clearing here
  // makes clear+append one synchronous block, so the last open wins with exactly one copy.
  menu.innerHTML = "";
  if (!list.length) { const d = document.createElement("div"); d.className = "proj-opt-empty"; d.textContent = "No other projects"; menu.appendChild(d); }
  list.forEach(p => {
    const o = document.createElement("button");
    o.type = "button"; o.className = "proj-opt" + (p.name === PROJECT ? " current" : "");
    o.innerHTML = `<span class="proj-opt-t"></span><span class="proj-opt-meta"></span>`;
    o.querySelector(".proj-opt-t").textContent = p.title;
    o.querySelector(".proj-opt-meta").textContent = `${p.scenes} scene${p.scenes === 1 ? "" : "s"}`;
    o.addEventListener("click", (ev) => { ev.stopPropagation(); menu.hidden = true; if (p.name !== PROJECT) openProject(p.name, p.title); });
    menu.appendChild(o);
  });
  menu.hidden = false;
});
// Reload button: KEEP its existing job (refresh the project data / gallery) AND, if newer app code has been
// copied in (disk version != the running process version), restart the packaged app so the backend changes
// take effect — no manual quit+reopen. When there's no new code it does NOT restart, so normal use is unchanged.
let _restartingForCode = false;
async function maybeRestartForNewCode() {
  if (_restartingForCode) return;
  const api = window.pywebview && window.pywebview.api;
  if (!(api && api.relaunch)) return;                 // only in the packaged desktop app
  let v; try { v = await fetch("/api/app/version").then(r => r.json()); } catch (_) { return; }
  if (!v || !v.running || !v.disk || v.running === v.disk) return;   // no new code on disk → nothing to do
  _restartingForCode = true;
  toast("🔄 New updates found — restarting to apply them…", "ok", 5000);
  setTimeout(() => { try { api.relaunch(); } catch (_) { _restartingForCode = false; } }, 700);
}
$("#reloadBtn").addEventListener("click", async () => { await loadDoc(); maybeRestartForNewCode(); realignStaleCards(); });

// A testimonial card keeps the word timings produced when its voice-over was aligned. Cards aligned before
// the language fix carry English timings, which is what makes the karaoke stall and then jump. Reload spots
// them (their stamped language differs from the project's) and re-aligns them in the right language.
async function realignStaleCards() {
  if (!PROJECT || !DOC) return;
  let want = "en";
  try { const r = await api.alignLang(PROJECT); want = (r && r.lang) || "en"; } catch (_) { return; }
  // vo / words / vo_dur / words_lang live at the TOP level of card.extra (card.extra[format] holds the
  // per-format trimmings like date and likes) — tcCardTiming reads them from there too.
  const stale = (DOC.testimonial_cards || []).filter(c => {
    const ex = c.extra || {};
    return ex.vo && ex.words && ex.words.length && (ex.words_lang || "en") !== want;
  });
  if (!stale.length) return;
  const prog = progressToast(`Re-aligning ${stale.length} testimonial voice-over${stale.length === 1 ? "" : "s"}…`, null);
  let done = 0;
  for (const c of stale) {
    // feed each card's own stages into the overall bar, so it advances smoothly instead of jumping
    // once per card (a card takes several seconds, most of it loading the model)
    const sub = { update: (label, pct) => { try { prog.update(`${label} (${done + 1}/${stale.length})`, (done + (pct || 0) / 100) / stale.length * 100); } catch (_) {} } };
    const a = await tcRunAlignJob(c.id, {}, sub);
    if (a && !a.error) { c.extra.words = a.words || []; c.extra.vo_dur = a.dur || 0; c.extra.words_lang = a.lang || want; }
    done++;
  }
  try { prog.update("Done", 100); setTimeout(() => prog.close(), 400); } catch (_) {}
  tcQueueSave();
  if (typeof renderTCards === "function") renderTCards();
  toast(`Re-aligned ${done} voice-over${done === 1 ? "" : "s"} in the project language — the karaoke should track now.`, "ok", 6000);
}
$("#scrollTopBtn").addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
$("#scrollBottomBtn").addEventListener("click", () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" }));
// middle button → jump to the LAST image/video you generated (approved not required)
const _scrollLatestBtn = $("#scrollLatestBtn");
if (_scrollLatestBtn) _scrollLatestBtn.addEventListener("click", () => {
  // "Continue where I left off": jump to the scene RIGHT AFTER the furthest-along scene that already has an
  // image (or video on the Videos tab) — i.e. the next scene to generate. Re-generating an EARLIER scene does
  // NOT move this: it always tracks the highest scene number that has media, + 1.
  const onVideos = document.body.classList.contains("tab-videos");
  const scenes = (DOC && DOC.scenes) || [];
  if (!scenes.length) return;
  const has = (s) => onVideos ? (s.video && s.video.file && s.video.status === "ready")
                              : (((s.image || {}).versions || []).length > 0);
  let mi = -1;
  for (let i = 0; i < scenes.length; i++) if (has(scenes[i])) mi = i;   // furthest-along scene WITH media
  // none generated yet → first scene; else the one after the furthest (clamped to the last scene)
  const target = mi < 0 ? scenes[0] : scenes[Math.min(mi + 1, scenes.length - 1)];
  if (!target) return;
  const sel = onVideos ? `#videosList .video-row[data-id="${target.id}"]` : `#scenesList .scene-row[data-id="${target.id}"]`;
  const row = document.querySelector(sel);
  if (row) { row.scrollIntoView({ behavior: "smooth", block: "center" }); row.classList.add("hist-flash"); setTimeout(() => row.classList.remove("hist-flash"), 1400); }
});

// ---------- rename project modal ----------
let renameTarget = null;
function openRenameModal(p) {
  renameTarget = p;
  $("#renameInput").value = p.title;
  $("#renameBg").hidden = false;
  const inp = $("#renameInput");
  inp.focus(); inp.select();
}
function closeRenameModal() { $("#renameBg").hidden = true; renameTarget = null; }
async function doRename() {
  if (!renameTarget) return;
  const t = $("#renameInput").value.trim();
  if (!t || t === renameTarget.title) { closeRenameModal(); return; }
  const r = await api.renameProject(renameTarget.name, t);
  if (r.error) { alert(r.error); return; }
  closeRenameModal(); showHome();
}
$("#renameSave").addEventListener("click", doRename);
$("#renameCancel").addEventListener("click", closeRenameModal);
$("#renameBg").addEventListener("click", (e) => { if (e.target === $("#renameBg")) closeRenameModal(); });
$("#renameInput").addEventListener("keydown", (e) => { if (e.key === "Enter") doRename(); else if (e.key === "Escape") closeRenameModal(); });

// ---------- scene notes modal (per-scene notes; persisted in scenes.json) ----------
let _noteScene = null;
function openNoteModal(s) {
  _noteScene = s;
  $("#noteTitle").textContent = `Scene #${s.id} — Notes`;
  $("#noteText").value = s.note || "";
  $("#noteBg").hidden = false;
  setTimeout(() => $("#noteText").focus(), 60);
}
function _applyNoteValue(v) {   // write a note value to the current scene: persist NOW + refresh card icon + jump dot
  if (!_noteScene) return;
  // ALWAYS target the LIVE scene object in the current DOC — a re-run/reload can swap DOC.scenes for a new
  // array, leaving the modal's captured reference an ORPHAN whose note would be saved onto nothing (this is
  // what silently dropped notes). Match by uid (stable across renumbering), fall back to id.
  const key = _noteScene.uid;
  const live = ((DOC && DOC.scenes) || []).find(x => (key && x.uid === key) || x.id === _noteScene.id) || _noteScene;
  _noteScene = live;
  if ((live.note || "") !== v) { live.note = v; _persist(); try { buildSceneJump(); } catch (_) {} }   // immediate save (not debounced) so closing the app can't lose it
  const row = document.querySelector(`#scenesList .scene-row[data-id="${live.id}"]`);
  const b = row && row.querySelector(".scene-note");
  if (b) b.classList.toggle("has-note", !!(v && v.trim()));
}
let _noteSaveT = 0;
function closeNoteModal() {
  if (_noteScene) _applyNoteValue($("#noteText").value);
  $("#noteBg").hidden = true; _noteScene = null;
}
{ const _t = $("#noteText"); if (_t) _t.addEventListener("input", () => { clearTimeout(_noteSaveT); _noteSaveT = setTimeout(() => _applyNoteValue(_t.value), 500); }); }   // save WHILE typing (debounced) so a note is never lost even if the modal closes unexpectedly
{ const _b = $("#noteClose"); if (_b) _b.addEventListener("click", closeNoteModal); }
{ const _b = $("#noteClear"); if (_b) _b.addEventListener("click", () => {   // wipe the note text + its red dot immediately; keep the modal open
    $("#noteText").value = "";
    _applyNoteValue("");
    $("#noteText").focus();
  }); }
// close on a REAL click on the empty backdrop only — a text-selection drag that STARTED inside the box and
// released on the backdrop must NOT close it (that click's target is the backdrop but the press wasn't).
let _noteDownOnBg = false;
$("#noteBg").addEventListener("pointerdown", (e) => { _noteDownOnBg = (e.target === $("#noteBg")); });
$("#noteBg").addEventListener("click", (e) => { if (e.target === $("#noteBg") && _noteDownOnBg) closeNoteModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#noteBg").hidden) closeNoteModal(); });

// ---------- import project modal (from the sync folder) ----------
let _importPollTimer = null, _importSig = "";   // auto-refresh so a Drive file finishing its sync appears/enables without reopening
function closeImportModal() {
  if (_importPollTimer) { clearInterval(_importPollTimer); _importPollTimer = null; }
  _importSig = "";
  $("#importBg").hidden = true;
}
function closeTrashModal() { $("#trashBg").hidden = true; }
async function openTrashModal() {
  const bg = $("#trashBg"), list = $("#trashList");
  list.innerHTML = `<div class="import-empty">Loading…</div>`;
  bg.hidden = false;
  let items;
  try { items = await api.listTrash(); } catch (e) { items = []; }
  if (!Array.isArray(items) || !items.length) {
    list.innerHTML = `<div class="import-empty">Recycle bin is empty.<br>Projects you “remove from dashboard” land here and can be restored.</div>`;
    return;
  }
  list.innerHTML = "";
  items.forEach((it, idx) => {
    const row = document.createElement("div"); row.className = "import-row";
    row.style.animationDelay = Math.min(idx * 45, 300) + "ms";
    const info = document.createElement("div"); info.className = "import-info";
    const t = document.createElement("div"); t.className = "import-title"; t.textContent = it.title || it.name;
    const meta = document.createElement("div"); meta.className = "import-meta";
    const bits = [];
    if (it.scenes != null) bits.push(`${it.scenes} scenes`);
    if (it.deleted) bits.push("removed " + String(it.deleted).replace("T", " "));
    meta.textContent = bits.join("  ·  ");
    info.append(t, meta);
    // permanently delete from disk
    const del = document.createElement("button"); del.className = "import-del"; del.title = "Delete from disk permanently"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(del, async () => {
      if (!(await confirmDialog(`Permanently delete “${it.title || it.name}” from this computer? This cannot be recovered.`, { title: "Delete From Disk", okText: "Delete Forever" }))) return;
      const r = await api.deleteTrash(it.name);
      if (r.error) { toast("Delete failed: " + r.error, "err"); return; }
      row.style.height = row.offsetHeight + "px"; void row.offsetHeight;
      row.classList.add("removing"); row.style.height = "0px"; row.style.marginBottom = "-8px";
      setTimeout(() => row.remove(), 320);
      toast("Deleted permanently", "ok");
    }); });
    // restore back to the dashboard
    const btn = document.createElement("button"); btn.className = "import-btn import-restore";
    btn.innerHTML = `<span>Restore</span>`;
    btn.addEventListener("click", () => withBusy(btn, async () => {
      const r = await api.restoreTrash(it.name);
      if (r.error) { toast("Restore failed: " + r.error, "err"); return; }
      closeTrashModal();
      toast(`✓ Restored — “${r.title}”`, "ok", 5000);
      await showHome();
    }));
    row.append(info, del, btn);
    list.appendChild(row);
  });
}
function _impSize(b) {
  if (b >= 1e9) return (b / 1e9).toFixed(1) + " GB";
  if (b >= 1e6) return Math.round(b / 1e6) + " MB";
  if (b >= 1e3) return Math.round(b / 1e3) + " KB";
  return b + " B";
}
function _renderImportList(res, existing) {
  const list = $("#importList");
  if (!res.sync_ok) {
    list.innerHTML = `<div class="import-empty">No sync folder set (or it wasn't found).<br>Pick a folder under Settings → 🔑 API Keys.</div>`;
    return;
  }
  if (!res.items.length) {
    list.innerHTML = `<div class="import-empty">No exported projects in the sync folder.<br>Export a project on another PC and it will appear here.</div>`;
    return;
  }
  list.innerHTML = "";
  res.items.forEach((it, idx) => {
    const clash = existing.has(it.name);
    const ready = it.ready !== false;   // older backends omit `ready` → treat as ready
    const row = document.createElement("div"); row.className = "import-row" + (ready ? "" : " import-syncing-row");
    row.style.animationDelay = Math.min(idx * 45, 300) + "ms";
    const info = document.createElement("div"); info.className = "import-info";
    const t = document.createElement("div"); t.className = "import-title"; t.textContent = it.title || it.name;
    if (clash) { const tag = document.createElement("span"); tag.className = "import-tag"; tag.textContent = "in this account"; t.appendChild(tag); }
    const meta = document.createElement("div"); meta.className = "import-meta";
    const bits = [];
    if (it.scenes != null) bits.push(`${it.scenes} scenes`);
    if (it.exported_by) bits.push(`by ${it.exported_by}`);
    if (it.size) bits.push(_impSize(it.size));
    if (it.exported_at) bits.push(String(it.exported_at).replace("T", " "));
    meta.textContent = bits.join("  ·  ");
    info.append(t, meta);
    if (!ready) {   // file still coming down from Google Drive → show a syncing note, block import until it lands
      const sy = document.createElement("div"); sy.className = "import-syncing-note";
      sy.innerHTML = `<span class="sc-spin"></span>Syncing from Google Drive… waiting for the file to finish downloading here`;
      info.append(sy);
    }
    // delete this export from the sync folder
    const del = document.createElement("button"); del.className = "import-del"; del.title = "Delete this export"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(del, async () => {
      if (!(await confirmDialog(`Delete the export “${it.title || it.name}” from the sync folder? This does not affect any imported project.`, { title: "Delete Export", okText: "Delete" }))) return;
      const r = await api.deleteImport(it.file);
      if (r.error) { toast("Delete failed: " + r.error, "err"); return; }
      row.style.height = row.offsetHeight + "px"; void row.offsetHeight;
      row.classList.add("removing"); row.style.height = "0px"; row.style.marginBottom = "-8px";
      setTimeout(() => row.remove(), 320);
      toast("Export deleted", "ok");
    }); });
    // import (or update, if a same-named project already exists here) — disabled while the file is still syncing
    const btn = document.createElement("button");
    if (!ready) {
      btn.className = "import-btn import-btn-syncing"; btn.disabled = true;
      btn.innerHTML = `<span class="sc-spin"></span><span>Syncing…</span>`;
    } else {
      btn.className = "import-btn" + (clash ? " import-update" : "");
      btn.innerHTML = `${IMPORT_SVG}<span>${clash ? "Update" : "Import"}</span>`;
      btn.addEventListener("click", () => withBusy(btn, async () => {
        const msg = clash
          ? `A project named “${it.title || it.name}” already exists in this account. Replace it with the imported version? Your current copy will be overwritten.`
          : `Import “${it.title || it.name}” into this account?`;
        if (!(await confirmDialog(msg, { title: clash ? "Update Project" : "Import Project", okText: clash ? "Overwrite" : "Import" }))) return;
        const r = await api.importProject(it.file, clash);
        if (r.error) { toast("Import failed: " + r.error, "err"); return; }
        closeImportModal();
        toast(clash ? `✓ Updated — “${r.title}” replaced in this account` : `✓ Import complete — “${r.title}” added to this account`, "ok", 5000);
        await showHome();   // refresh the project list so the imported project shows up right away
      }));
    }
    row.append(info, del, btn);
    list.appendChild(row);
  });
}

async function openImportModal() {
  const list = $("#importList");
  list.innerHTML = `<div class="import-empty">Loading…</div>`;
  $("#importBg").hidden = false;
  _importSig = "";
  const existing = new Set();                 // detect name clashes → offer Update (overwrite)
  try { (await api.projects()).forEach(p => existing.add(p.name)); } catch (e) {}
  const refresh = async () => {
    if ($("#importBg").hidden) { if (_importPollTimer) { clearInterval(_importPollTimer); _importPollTimer = null; } return; }   // closed → stop
    let res;
    try { res = await api.listImports(); } catch (e) { return; }   // transient error → keep the current view
    // only rebuild when the set of files / their readiness actually CHANGED (so polling never disturbs a click)
    const sig = (res.items || []).map(x => x.file + ":" + (x.ready !== false ? "1" : "0")).join("|") + "|" + (res.sync_ok ? "1" : "0");
    if (sig === _importSig) return;
    _importSig = sig;
    _renderImportList(res, existing);
  };
  await refresh();
  if (_importPollTimer) clearInterval(_importPollTimer);
  _importPollTimer = setInterval(refresh, 3000);   // a file finishing its Drive sync appears + becomes importable, no manual reopen
}
// ---------- export progress (bottom-right card, polled) ----------
function showExportProgress(title) {
  let el = document.getElementById("expProg");
  if (!el) {
    el = document.createElement("div"); el.id = "expProg"; el.className = "exp-prog";
    el.innerHTML = `<div class="exp-prog-top"><span class="exp-prog-title"></span><span class="exp-prog-pct">0%</span></div><div class="exp-prog-bar"><i></i></div>`;
    document.body.appendChild(el);
  }
  el.querySelector(".exp-prog-title").textContent = "Exporting " + title + "…";
  const bar = el.querySelector(".exp-prog-bar i"), pct = el.querySelector(".exp-prog-pct");
  requestAnimationFrame(() => el.classList.add("show"));
  return {
    set(p) { p = Math.max(0, Math.min(100, p | 0)); pct.textContent = p + "%"; bar.style.width = p + "%"; },
    close() { el.classList.remove("show"); setTimeout(() => { try { el.remove(); } catch (e) {} }, 320); },
  };
}
function pollExport(job, title) {
  const prog = showExportProgress(title);
  return new Promise(resolve => {
    const iv = setInterval(async () => {
      let s; try { s = await api.exportStatus(job); } catch (e) { return; }
      if (s.error === "not-found") { clearInterval(iv); prog.close(); toast("Export failed: job lost", "err"); resolve(); return; }
      prog.set(s.pct || 0);
      if (s.done) {
        clearInterval(iv);
        prog.close();
        if (s.error) toast("Export failed: " + s.error, "err");
        else toast(`✓ Export complete — “${title}” saved to the sync folder`, "ok", 5000);
        resolve();
      }
    }, 350);
  });
}
async function saveSyncDir(v) { try { await api.setConfig({ sync_dir: v }); } catch (e) {} }
$("#importClose").addEventListener("click", closeImportModal);
$("#importBg").addEventListener("click", (e) => { if (e.target === $("#importBg")) closeImportModal(); });
$("#trashClose").addEventListener("click", closeTrashModal);
$("#trashBg").addEventListener("click", (e) => { if (e.target === $("#trashBg")) closeTrashModal(); });

// ---------- audience modal (collapsible dropdowns) ----------
const AUD_FIELDS = [
  { key: "locations", label: "Location", multi: false, options: [{ v: "United States" }, { v: "United Kingdom" }, { v: "France" }, { v: "Germany" }] },
  { key: "currencies", label: "Currency", multi: false, options: [{ v: "Dollar", ic: "$" }, { v: "Pound", ic: "£" }, { v: "Euro", ic: "€" }] },
  { key: "ages", label: "Age Range", multi: true, options: [{ v: "25-44" }, { v: "45-65" }, { v: "50-80" }] },
  { key: "genders", label: "Gender", multi: true, options: [{ v: "Female" }, { v: "Male" }] },
  { key: "appearance", label: "Appearance to exclude", multi: true,
    hint: "Types you do NOT want to appear in the VSL. Selected looks are avoided; everything else stays unrestricted.",
    groups: [
      { name: "Ethnicity / skin", options: [{ v: "Asian" }, { v: "Black-skinned" }, { v: "White-skinned" }, { v: "Indian" }, { v: "Hispanic / Latino" }, { v: "Middle Eastern / Arab" }] },
      { name: "Hair", options: [{ v: "Blonde" }, { v: "Redhead" }, { v: "Orange hair" }, { v: "Brunette" }, { v: "Black hair" }, { v: "Gray / white hair" }] },
    ] },
];
let modalMode = "new";
let selAud = {};
function renderAudFields() {
  const box = $("#audFields");
  box.innerHTML = "";
  AUD_FIELDS.forEach(f => {
    const dd = document.createElement("div");
    dd.className = "dd";
    const head = document.createElement("button");
    head.type = "button"; head.className = "dd-head";
    head.innerHTML = `<span class="dd-title"></span><span class="dd-summary"></span><span class="dd-caret">▾</span>`;
    head.querySelector(".dd-title").textContent = f.label;
    const sumEl = head.querySelector(".dd-summary");
    const updateSum = () => { sumEl.textContent = (selAud[f.key] || []).join(", "); };
    updateSum();
    head.addEventListener("click", () => dd.classList.toggle("open"));
    const body = document.createElement("div");
    body.className = "dd-body";
    const inner = document.createElement("div");   // grid-rows wrapper animates 0fr<->1fr; inner clips
    inner.className = "dd-inner";
    body.appendChild(inner);
    if (f.hint) {
      const h = document.createElement("div");
      h.className = "dd-hint"; h.textContent = f.hint;
      inner.appendChild(h);
    }
    const makeOpt = (o, container) => {
      const opt = document.createElement("div");
      opt.className = "opt" + ((selAud[f.key] || []).includes(o.v) ? " sel" : "");
      opt.innerHTML = (o.ic ? `<span class="ic">${o.ic}</span>` : "") + `<span class="lbl"></span>`;
      opt.querySelector(".lbl").textContent = o.v;
      opt.addEventListener("click", () => {
        let cur = selAud[f.key] || [];
        if (f.multi) {
          cur = cur.includes(o.v) ? cur.filter(x => x !== o.v) : [...cur, o.v];
        } else {
          cur = cur.includes(o.v) ? [] : [o.v];
          [...body.querySelectorAll(".opt")].forEach(c => c.classList.remove("sel"));
        }
        selAud[f.key] = cur;
        opt.classList.toggle("sel", cur.includes(o.v));
        updateSum();
      });
      container.appendChild(opt);
    };
    if (f.groups) {
      f.groups.forEach(g => {
        const grp = document.createElement("div");
        grp.className = "opt-group";
        const lbl = document.createElement("div");
        lbl.className = "opt-group-label"; lbl.textContent = g.name;
        const grid = document.createElement("div");
        grid.className = "opt-grid";
        g.options.forEach(o => makeOpt(o, grid));
        grp.appendChild(lbl); grp.appendChild(grid);
        inner.appendChild(grp);
      });
    } else {
      f.options.forEach(o => makeOpt(o, inner));
    }
    dd.appendChild(head); dd.appendChild(body);
    box.appendChild(dd);
  });

  // Cast / Characters — its own modal tab now, rendered directly (no dropdown, room to breathe)
  const castBox = $("#castFields");
  castBox.innerHTML = "";
  castSummaryEl = null;
  renderCastBody(castBox);
  renderIngredientsBody($("#ingFields"));   // the product's ingredients + reference images
}

// ---- Product tab: one project-level product image, attached (i2i) to scenes you flag 📦 Product ----
function renderProductPanel() {
  const panel = $("#productPanel"); if (!panel) return;
  panel.innerHTML = "";
  const hint = document.createElement("p"); hint.className = "cast-hint";
  hint.textContent = PROJECT
    ? "Upload your product image (bottle / package). Then on any scene, turn on 📦 Product to place THIS exact product into that shot — kept label-accurate. A clean product photo on a plain background works best."
    : "Open a project first — the product image is stored per project.";
  panel.appendChild(hint);
  if (!PROJECT) return;
  // product BRAND NAME (auto-filled by Analyze Cast, e.g. "Cardio-360") — the director names product shots with it
  const nameWrap = document.createElement("label"); nameWrap.className = "product-name-field";
  const nlab = document.createElement("span"); nlab.textContent = "Product name";
  const nameIn = document.createElement("input"); nameIn.type = "text"; nameIn.className = "product-name-input";
  nameIn.placeholder = "e.g. Cardio-360"; nameIn.value = (DOC && DOC.product && DOC.product.name) || "";
  const commitName = async () => {
    const nv = nameIn.value.trim();
    if (nv === ((DOC && DOC.product && DOC.product.name) || "")) return;
    const r = await api.setProductName(PROJECT, nv);
    if (r && r.error) { alert(r.error); return; }
    if (DOC) DOC.product = { ...(DOC.product || {}), ...(r || {}) };
    refreshAllSceneProducts && refreshAllSceneProducts();
  };
  nameIn.addEventListener("blur", commitName);
  nameIn.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); nameIn.blur(); } });
  nameWrap.append(nlab, nameIn); panel.appendChild(nameWrap);
  const urls = ((DOC && DOC.product && DOC.product.urls) || []);
  const names = ((DOC && DOC.product && DOC.product.names) || {});
  // pack sizes detected from the script by Analyze Cast (1 / 3 / 6 / 12 bottle …) → tell the user which pack
  // images to upload + label. A green ✓ chip = you already have an image labelled that pack.
  const packs = ((DOC && DOC.product && DOC.product.packs) || []);
  if (packs.length) {
    const have = new Set(Object.values(names).map(v => (v || "").trim().toLowerCase()).filter(Boolean));
    const box = document.createElement("div"); box.className = "product-packs";
    const t = document.createElement("div"); t.className = "product-packs-title"; t.textContent = "📦 Offer packs found in the script — upload one product image per pack and label it to match:";
    const row = document.createElement("div"); row.className = "product-packs-chips";
    packs.forEach(p => {
      const has = have.has((p || "").trim().toLowerCase());
      const chip = document.createElement("span"); chip.className = "product-pack-chip" + (has ? " has-img" : "");
      chip.textContent = (has ? "✓ " : "") + p;
      chip.title = has ? "You already uploaded an image labelled this pack" : "Upload a product image below and set its label to exactly this";
      row.appendChild(chip);
    });
    box.append(t, row); panel.appendChild(box);
  }
  const grid = document.createElement("div"); grid.className = "cast-img-grid product-grid";
  urls.forEach((u, i) => {
    const cell = document.createElement("div"); cell.className = "product-cell";
    const thumb = document.createElement("div"); thumb.className = "cast-thumb";
    const im = document.createElement("img"); im.alt = ""; setRefImg(im, u);
    const x = document.createElement("button"); x.type = "button"; x.className = "cast-thumb-x"; x.textContent = "×"; x.title = "Remove product image";
    x.addEventListener("click", async () => {
      const r = await api.removeProduct(PROJECT, u);
      if (r.error) { alert(r.error); return; }
      DOC.product = { urls: r.urls || [], names: r.names || {} }; renderProductPanel(); refreshAllSceneCast();
    });
    thumb.append(im, x);
    // editable label — this is what the per-scene Product dropdown shows, so name it by pack ("3 bottle")
    const lab = document.createElement("input"); lab.className = "product-label"; lab.type = "text";
    lab.value = names[u] || ""; lab.placeholder = `Product ${i + 1}`; lab.title = "Name this pack (e.g. 1 bottle, 3 bottle)";
    const commit = async () => {
      const nv = lab.value.trim();
      if (nv === (names[u] || "")) return;
      const r = await api.renameProduct(PROJECT, u, nv);
      if (r.error) { alert(r.error); return; }
      DOC.product = { urls: r.urls || [], names: r.names || {} }; refreshAllSceneCast(); refreshAllSceneProducts();   // product chips resolve names live → redraw them so the rename shows on the scene cards
    };
    lab.addEventListener("blur", commit);
    lab.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); lab.blur(); } });
    cell.append(thumb, lab); grid.appendChild(cell);
  });
  const add = document.createElement("label"); add.className = "cast-thumb cast-thumb-add"; add.title = "Upload product image(s)"; add.innerHTML = "<span>＋</span>";
  const addI = document.createElement("input"); addI.type = "file"; addI.accept = "image/*"; addI.multiple = true; addI.hidden = true;
  addI.addEventListener("change", async e => {
    const fs = [...e.target.files]; if (!fs.length) return;
    const r = await api.addProduct(PROJECT, fs);
    if (r.error) { alert(r.error); return; }
    DOC.product = { urls: r.urls || [], names: r.names || {} }; renderProductPanel(); refreshAllSceneCast();
  });
  add.appendChild(addI); grid.appendChild(add);
  panel.appendChild(grid);
}

// ---- API keys tab (a new user can plug in their own Kie / Cloudinary / ElevenLabs keys) ----
// ---------- Claude account connection (Settings -> Keys, + auto warning) ----------
async function _claudeStatus() {
  try { return await fetch("/api/claude/status").then(r => r.json()); }
  catch (e) { return { installed: false, logged_in: false }; }
}
function claudeConnectBlock() {
  const box = document.createElement("div");
  box.className = "claude-conn";
  box.innerHTML =
    '<div class="cc-head"><span class="cc-dot"></span><b>Claude Account</b><span class="cc-state">Checking…</span></div>' +
    '<p class="cc-sub">Script splitting, image prompts, translate & audit run on your Claude subscription on this PC.</p>' +
    '<div class="cc-actions">' +
      '<button type="button" class="cc-connect primary" hidden>Connect Claude</button>' +
      '<button type="button" class="cc-recheck ghost">Check again</button></div>' +
    '<p class="cc-install hint" hidden>Not installed on this PC. In a terminal run <code>winget install --id Anthropic.ClaudeCode</code>, then Connect.</p>';
  const dot = $(".cc-dot", box), state = $(".cc-state", box), connect = $(".cc-connect", box),
        recheck = $(".cc-recheck", box), install = $(".cc-install", box);
  async function refresh() {
    dot.className = "cc-dot"; state.textContent = "Checking…"; connect.hidden = true; install.hidden = true;
    const s = await _claudeStatus();
    if (s.installed && s.logged_in) { dot.className = "cc-dot ok"; state.textContent = "Connected"; }
    else { dot.className = "cc-dot bad"; state.textContent = s.installed ? "Not connected" : "Not installed"; connect.hidden = false; install.hidden = !!s.installed; }
  }
  connect.addEventListener("click", async () => {
    connect.disabled = true; const old = connect.textContent; connect.textContent = "Opening…";
    let r = {}; try { r = await fetch("/api/claude/login", { method: "POST" }).then(x => x.json()); } catch (e) {}
    connect.disabled = false; connect.textContent = old;
    if (r && r.ok) toast("A terminal opened — finish the login in your browser, then click ‘Check again’.", "info", 10000);
    else if (r && r.install_cmd) { install.hidden = false; toast("⚠ Install Claude Code first, then Connect.", "err", 9000); }
    else toast("⚠ " + ((r && r.error) || "Could not start the login."), "err", 8000);
  });
  recheck.addEventListener("click", refresh);
  refresh();
  return box;
}
let _ccModalOpen = false;
function showClaudeConnect() {
  if (_ccModalOpen) return; _ccModalOpen = true;
  const bg = document.createElement("div"); bg.className = "modal-bg cc-modal-bg";
  const m = document.createElement("div"); m.className = "modal cc-modal";
  m.innerHTML = "<h3>Connect your Claude account</h3><p class='hint'>This app needs your Claude subscription for text features. Connect it once on this PC.</p>";
  m.appendChild(claudeConnectBlock());
  const act = document.createElement("div"); act.className = "modal-actions";
  const close = document.createElement("button"); close.className = "ghost"; close.textContent = "Close";
  const done = () => { bg.remove(); _ccModalOpen = false; };
  close.addEventListener("click", done); act.appendChild(close); m.appendChild(act); bg.appendChild(m);
  bg.addEventListener("mousedown", e => { if (e.target === bg) done(); });
  document.body.appendChild(bg);
}

async function renderKeysPanel() {
  const panel = $("#keysPanel");
  panel.innerHTML = "";
  panel.appendChild(claudeConnectBlock());          // Claude connection at the TOP of the Keys section
  const hint = document.createElement("p");
  hint.className = "hint keys-hint";
  hint.textContent = PROJECT
    ? "These keys belong to THIS project — they travel with it on export/import. Applied right away when you Save."
    : "Keys are per project. Copy them from a project you already use, or paste them in below — they are saved with this new project.";
  panel.appendChild(hint);
  const FIELDS = [
    { key: "cloud_name", label: "Cloudinary — Cloud name", ph: "e.g. kgcv41gb", secret: false },
    { key: "cloud_key", label: "Cloudinary — API Key", ph: "", secret: true },
    { key: "cloud_secret", label: "Cloudinary — API Secret", ph: "", secret: true },
    { key: "kie", label: "Kie.ai — API Key", ph: "", secret: true },
    { key: "elevenlabs", label: "ElevenLabs — API Key", ph: "", secret: true },
  ];
  const inputs = {};
  // The whole panel is laid out SYNCHRONOUSLY so the modal opens at its final height. Values and the project
  // list arrive afterwards and only fill what is already on screen — awaiting them here made the modal pop
  // open small and then grow.
  const keysReady = PROJECT ? api.getKeys(PROJECT).catch(() => ({})) : Promise.resolve({});
  // "Get from a project" — same helper the global Studio keys panel has. Filling a brand-new project's keys
  // by hand is pointless when an existing project already has them; pick one and the five fields below fill
  // in (nothing is saved until you press Save/Create). The choice is remembered and shown again next time.
  const gf = document.createElement("label"); gf.className = "field key-field";
  const gs = document.createElement("span"); gs.textContent = "Get from a project";
  gf.appendChild(gs);
  let ddEl = tcSelect("", [{ value: "", label: "Loading…" }], () => {}, "Copy keys from…");
  gf.appendChild(ddEl); panel.appendChild(gf);
  Promise.all([api.projects().catch(() => []), keysReady]).then(([projs, cur0]) => {
    const opts = (projs || []).filter(p => p.name !== PROJECT)          // never offer the project we're editing
                              .map(p => ({ value: p.name, label: p.title || p.name }));
    const pick = async (val) => {
      if (!val) return;
      let k; try { k = await api.projectKeys(val); } catch (_) { k = null; }
      if (!k || k.error) { toast("Couldn't read that project's keys.", "err"); return; }
      FIELDS.forEach(f => { if (inputs[f.key]) inputs[f.key].value = k[f.key] || ""; });
      panel.dataset.keysFrom = val;                                     // persisted with the keys on Save
      toast("Filled the keys from the selected project — review, then Save.", "ok", 3500);
    };
    const from = (cur0 && cur0.keys_from) || "";                        // remembered choice, if still a real project
    const known = opts.some(o => o.value === from) ? from : "";
    const fresh = tcSelect(known, opts.length ? opts : [{ value: "", label: "No other projects yet" }], pick, "Copy keys from…");
    ddEl.replaceWith(fresh); ddEl = fresh;                              // same field box → height never changes
    if (known) panel.dataset.keysFrom = known;
  });
  FIELDS.forEach(f => {
    const wrap = document.createElement("label"); wrap.className = "field key-field";
    const span = document.createElement("span"); span.textContent = f.label;
    const row = document.createElement("div"); row.className = "key-input-row";
    const inp = document.createElement("input");
    inp.type = f.secret ? "password" : "text"; inp.className = "key-input"; inp.dataset.keyField = f.key;
    inp.value = ""; inp.placeholder = f.ph; inp.autocomplete = "off"; inp.spellcheck = false;
    row.appendChild(inp);
    if (f.secret) {
      const eye = document.createElement("button"); eye.type = "button"; eye.className = "key-eye"; eye.title = "Show / hide"; eye.textContent = "👁";
      eye.addEventListener("click", () => { const s = inp.type === "password"; inp.type = s ? "text" : "password"; eye.classList.toggle("on", s); });
      row.appendChild(eye);
    }
    wrap.append(span, row); panel.appendChild(wrap);
    inputs[f.key] = inp;
  });
  // saved values land once they arrive — the boxes are already on screen, so nothing resizes
  keysReady.then(cur => { FIELDS.forEach(f => { if (inputs[f.key] && !inputs[f.key].value) inputs[f.key].value = (cur && cur[f.key]) || ""; }); });
  // --- project transfer: the sync folder (Google Drive / OneDrive / Dropbox desktop folder) ---
  const sep = document.createElement("div"); sep.className = "keys-sep"; panel.appendChild(sep);
  const sh = document.createElement("p"); sh.className = "hint keys-hint";
  sh.innerHTML = "<b>Project transfer — Sync folder.</b> To move projects to another PC, pick a cloud-synced folder (Google Drive / OneDrive / Dropbox desktop folder). Exported projects are written here as <b>.zip</b>; on the other PC they appear under <b>Import</b>.";
  panel.appendChild(sh);
  const sf = document.createElement("label"); sf.className = "field key-field";
  const sfs = document.createElement("span"); sfs.textContent = "Sync folder";
  const sfr = document.createElement("div"); sfr.className = "key-input-row";
  const sfi = document.createElement("input");
  sfi.type = "text"; sfi.id = "syncDirInput"; sfi.className = "key-input";
  sfi.placeholder = "e.g. G:\\My Drive\\VSL-Exports"; sfi.autocomplete = "off"; sfi.spellcheck = false;
  let cfg = {}; try { cfg = await api.getConfig(); } catch (e) {}
  sfi.value = cfg.sync_dir || "";
  sfr.appendChild(sfi);
  if (window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder) {
    const pick = document.createElement("button");
    pick.type = "button"; pick.className = "key-eye sync-pick"; pick.title = "Choose folder"; pick.textContent = "📁";
    pick.addEventListener("click", async () => {
      try {
        const r = await window.pywebview.api.pick_folder();
        if (r && r.ok && r.path) { sfi.value = r.path; await saveSyncDir(r.path); toast("Sync folder saved", "ok"); }
      } catch (e) {}
    });
    sfr.appendChild(pick);
  }
  sf.append(sfs, sfr); panel.appendChild(sf);
  sfi.addEventListener("change", () => saveSyncDir(sfi.value.trim()));
  // --- notification sound (also toggleable from the desktop tray menu) ---
  const nf = document.createElement("label"); nf.className = "field key-field"; nf.style.cursor = "pointer";
  const ns = document.createElement("span"); ns.textContent = "🔔 Notification sound";
  const nrow = document.createElement("div"); nrow.className = "key-input-row"; nrow.style.alignItems = "center";
  const ncb = document.createElement("input"); ncb.type = "checkbox"; ncb.style.width = "18px"; ncb.style.height = "18px"; ncb.style.cursor = "pointer";
  ncb.checked = cfg.notif_sound !== false;
  const nhint = document.createElement("span"); nhint.className = "hint"; nhint.style.margin = "0 0 0 9px";
  nhint.textContent = "A soft chime when an image, video, prompt or split finishes — and a different sound on any error.";
  ncb.addEventListener("change", async () => {
    NOTIF_SOUND = ncb.checked;
    try { await api.setConfig({ notif_sound: ncb.checked }); } catch (e) {}
    if (ncb.checked) playNotifChime();   // preview the sound when turning it on
  });
  nrow.append(ncb, nhint); nf.append(ns, nrow); panel.appendChild(nf);
}
// ---- GLOBAL (out-of-project) Studio keys modal — same design as Settings -> Keys, minus sync folder /
//      notification sound, plus a "Get from a project" dropdown that copies a project's keys into the form.
const _GKEY_FIELDS = [
  { key: "cloud_name", label: "Cloudinary — Cloud name", ph: "e.g. kgcv41gb", secret: false },
  { key: "cloud_key", label: "Cloudinary — API Key", ph: "", secret: true },
  { key: "cloud_secret", label: "Cloudinary — API Secret", ph: "", secret: true },
  { key: "kie", label: "Kie.ai — API Key", ph: "", secret: true },
  { key: "elevenlabs", label: "ElevenLabs — API Key", ph: "", secret: true },
];
function _buildKeyField(f, inputs) {
  const wrap = document.createElement("label"); wrap.className = "field key-field";
  const span = document.createElement("span"); span.textContent = f.label;
  const row = document.createElement("div"); row.className = "key-input-row";
  const inp = document.createElement("input");
  inp.type = f.secret ? "password" : "text"; inp.className = "key-input"; inp.dataset.keyField = f.key;
  inp.value = ""; inp.placeholder = f.ph; inp.autocomplete = "off"; inp.spellcheck = false;
  row.appendChild(inp);
  if (f.secret) {
    const eye = document.createElement("button"); eye.type = "button"; eye.className = "key-eye"; eye.title = "Show / hide"; eye.textContent = "👁";
    eye.addEventListener("click", () => { const s = inp.type === "password"; inp.type = s ? "text" : "password"; eye.classList.toggle("on", s); });
    row.appendChild(eye);
  }
  wrap.append(span, row); inputs[f.key] = inp; return wrap;
}
async function openGlobalKeysModal() {
  const bg = document.createElement("div"); bg.className = "modal-bg";
  const m = document.createElement("div"); m.className = "modal keys-modal gkeys-modal";
  m.innerHTML = "<h3>API Keys — Global Studio</h3>";
  const panel = document.createElement("div"); panel.className = "gkeys-panel";
  panel.appendChild(claudeConnectBlock());
  const hint = document.createElement("p"); hint.className = "hint keys-hint";
  hint.textContent = "Keys for standalone (no-project) Studio generation. You can copy them from an existing project below.";
  panel.appendChild(hint);
  const inputs = {};
  // "Get from a project" dropdown — sits ABOVE the Cloudinary cloud name; picking a project fills the fields
  const gf = document.createElement("label"); gf.className = "field key-field";
  const gfs = document.createElement("span"); gfs.textContent = "Get from a project";
  gf.appendChild(gfs);
  let projs = []; try { projs = await api.projects(); } catch (_) {}
  const opts = (projs || []).map(p => ({ value: p.name, label: p.title || p.name }));
  let keysFrom = "";                       // which project these were copied from (shown again next time)
  const pickFrom = async (val) => {
    if (!val) return;
    let k; try { k = await api.projectKeys(val); } catch (_) { k = null; }
    if (!k || k.error) { toast("Couldn't read that project's keys.", "err"); return; }
    _GKEY_FIELDS.forEach(f => { if (inputs[f.key]) inputs[f.key].value = k[f.key] || ""; });
    keysFrom = val;
    toast("Filled the keys from the selected project — review, then Save.", "ok", 3500);
  };
  let saved = {}; try { saved = await api.getGlobalKeys(); } catch (_) {}
  const remembered = opts.some(o => o.value === (saved.keys_from || "")) ? saved.keys_from : "";
  if (remembered) keysFrom = remembered;
  const dd = tcSelect(remembered, opts.length ? opts : [{ value: "", label: "No projects yet" }], pickFrom, "Copy keys from…");
  gf.appendChild(dd); panel.appendChild(gf);
  // the 5 key fields
  _GKEY_FIELDS.forEach(f => panel.appendChild(_buildKeyField(f, inputs)));
  // load the saved global keys into the fields
  _GKEY_FIELDS.forEach(f => { if (inputs[f.key]) inputs[f.key].value = saved[f.key] || ""; });
  m.appendChild(panel);
  const act = document.createElement("div"); act.className = "modal-actions";
  const save = document.createElement("button"); save.className = "primary"; save.textContent = "Save Keys";
  const close = document.createElement("button"); close.className = "ghost"; close.textContent = "Close";
  const done = () => bg.remove();
  save.addEventListener("click", async () => {
    const body = {}; _GKEY_FIELDS.forEach(f => { body[f.key] = (inputs[f.key].value || "").trim(); });
    if (keysFrom) body.keys_from = keysFrom;                 // remember the source project for next time
    let r; try { r = await api.setGlobalKeys(body); } catch (_) { r = { error: "request failed" }; }
    if (r && r.ok) { toast("Global Studio keys saved.", "ok"); done(); } else toast((r && r.error) || "Save failed", "err", 6000);
  });
  close.addEventListener("click", done);
  act.append(close, save); m.appendChild(act); bg.appendChild(m);   // Close on the left, Save Keys on the right
  bg.addEventListener("mousedown", e => { if (e.target === bg) done(); });
  document.body.appendChild(bg);
}
// Collect the API-keys tab inputs so the modal's main Save can persist them alongside the audience.
function collectKeys() {
  const body = {};
  $$("#keysPanel .key-input").forEach(inp => { if (inp.dataset.keyField) body[inp.dataset.keyField] = inp.value.trim(); });
  const p = $("#keysPanel");
  if (p && p.dataset.keysFrom) body.keys_from = p.dataset.keysFrom;   // remember the project they were copied from
  return body;
}
// modal tab switching (API Keys / Target Audience / Cast) — smoothly morph the body height so the
// modal stretches/shrinks instead of snapping between tab sizes.
function setModalTab(name, animate = true) {
  const body = document.querySelector(".mtab-body");
  const swap = () => {
    $$(".mtab").forEach(t => t.classList.toggle("active", t.dataset.mtab === name));
    $$(".mtab-panel").forEach(p => p.classList.toggle("active", p.dataset.mtabp === name));
  };
  if (!animate || !body || !body.offsetParent) { swap(); return; }   // no animation on first open (modal still hidden)
  const oldH = body.getBoundingClientRect().height;
  swap();
  // Measure the height the body will ACTUALLY settle at (CSS flex + the modal's max-height applied),
  // not a hand-computed cap. Targeting the real height means clearing the inline height at the end
  // never snaps — this is what made the tall Cast tab jump ("pat pat") while short tabs were smooth.
  body.style.transition = "none";
  body.style.height = ""; body.style.overflow = "";
  const newH = body.getBoundingClientRect().height;
  if (Math.abs(newH - oldH) < 2) { body.style.transition = ""; return; }
  body.style.height = oldH + "px"; body.style.overflow = "hidden";
  void body.offsetHeight;                                 // reflow so the transition runs from oldH
  body.style.transition = "height .3s cubic-bezier(.33,1,.68,1)";
  body.style.height = newH + "px";
  clearTimeout(body._tabAnim);
  body._tabAnim = setTimeout(() => { body.style.transition = ""; body.style.height = ""; body.style.overflow = ""; }, 320);
}
$$(".mtab").forEach(t => t.addEventListener("click", () => setModalTab(t.dataset.mtab)));
function openModal(mode) {
  modalMode = mode;
  pendingCast.forEach(c => { try { URL.revokeObjectURL(c.previewUrl); } catch (e) {} });
  pendingCast = [];                    // fresh staged-character list each time the modal opens
  const aud = (mode === "edit" && DOC) ? (DOC.audience || {}) : {};
  selAud = {
    locations: aud.locations || [], currencies: aud.currencies || [],
    ages: aud.ages || [], genders: aud.genders || [], appearance: aud.appearance || [],
    avatar: aud.avatar || "",
  };
  $("#modalTitle").textContent = mode === "edit" ? "Settings" : "New Project";
  $("#mNameField").style.display = mode === "edit" ? "none" : "block";
  $("#mName").value = "";
  $("#mBrief").value = (mode === "edit" && DOC) ? (DOC.brief || "") : "";   // project brief/context
  $("#mAvatar").value = aud.avatar || "";   // TARGET VIEWER (relatable people's look)
  $("#mSave").textContent = mode === "edit" ? "Save" : "Create Project";
  renderAudFields();
  renderKeysPanel();               // fills the API-keys tab (async; ready by the time it's opened)
  renderProductPanel();            // fills the Product tab
  // Cast + Ingredients + Product only make sense once the project EXISTS (Analyze/Settings) — hide them in New
  // Project. Audience is now AUTO-filled by Analyze Cast, so New Project is just Name + Keys (Audience stays in
  // Settings for review/editing).
  const isNew = mode === "new";
  const castTab = document.querySelector('.mtab[data-mtab="cast"]'); if (castTab) castTab.hidden = isNew;
  const ingTab = document.querySelector('.mtab[data-mtab="ingredients"]'); if (ingTab) ingTab.hidden = isNew;
  const prodTab = document.querySelector('.mtab[data-mtab="product"]'); if (prodTab) prodTab.hidden = isNew;
  const audTab = document.querySelector('.mtab[data-mtab="audience"]'); if (audTab) audTab.hidden = isNew;
  setModalTab(isNew ? "keys" : "audience", false);  // New Project lands on Keys; Settings lands on Target Audience
  $("#modalBg").hidden = false;
}
$("#audienceBtn").addEventListener("click", () => { if (!PROJECT) { alert("Open a project first."); return; } openModal("edit"); });
$("#mCancel").addEventListener("click", () => { $("#modalBg").hidden = true; });
bdClose($("#modalBg"), () => { $("#modalBg").hidden = true; });   // Settings/Cast/etc. — close only on a real backdrop click (not a drag-out)
$("#mSave").addEventListener("click", async (e) => {
  const aud = { ...selAud, avatar: ($("#mAvatar").value || "").trim() };   // TARGET VIEWER from its own field
  const btn = e.currentTarget;
  if (modalMode === "new") {
    const nameEl = $("#mName"), name = nameEl.value.trim();
    if (!name) { flagInvalid(nameEl); return; }                 // themed inline validation (no popup)
    if (!(await confirmDialog(`Create the project “${name}”?`, { title: "Create Project", okText: "Create", danger: false }))) return;
  }
  await withBusy(btn, async () => {
    const keys = collectKeys();   // API keys are now PER PROJECT — saved to the relevant project below
    if (modalMode === "new") {
      const r = await api.createProject($("#mName").value.trim(), aud, $("#mBrief").value);
      if (r.error) { toast(r.error, "err"); return; }
      if (Object.keys(keys).length) { const kr = await api.setKeys(r.name, keys); if (kr && kr.error) toast(kr.error, "err"); }
      // upload any characters staged in the browser into the freshly-created project (each may have several images)
      for (const pc of pendingCast) { try { await api.addCharacter(r.name, pc.name, pc.files); } catch (err) {} }
      pendingCast.forEach(c => (c.previewUrls || []).forEach(u => { try { URL.revokeObjectURL(u); } catch (err) {} }));
      pendingCast = [];
      $("#modalBg").hidden = true;
      await openProject(r.name);
    } else {
      if (PROJECT && Object.keys(keys).length) { const kr = await api.setKeys(PROJECT, keys); if (kr && kr.error) toast(kr.error, "err"); }
      DOC.audience = aud; DOC.brief = $("#mBrief").value; await api.save(PROJECT, DOC);
      $("#modalBg").hidden = true;
      setStatus("saved"); setTimeout(() => setStatus(""), 1200);
    }
  });
});
$("#translateAllBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (!DOC?.scenes.length) return;
  if (!(await confirmDialog("Translate ALL sentences to Turkish? This overwrites existing translations.", { title: "Translate All Sentences", okText: "Translate", danger: false }))) return;
  await withBusy(btn, async () => {
    setStatus("translating to Turkish…");
    await translateAllScenes();
    setStatus("");
    toast("All sentences translated to Turkish", "ok");
  });
});
$("#genAllPromptsBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!DOC?.scenes.length) return;
  if (!(await confirmDialog("Generate image prompts for ALL scenes? This overwrites any existing prompts.", { title: "Generate All Prompts", okText: "Generate", danger: false }))) return;
  stoppable(btn, (sig) => genPrompts("all", sig));
});
// Re-run the whole-script director: fixes scenes whose prompt is empty or just the raw voice-over line
// (the old silent-fallback damage), while leaving any prompt you wrote yourself untouched.
// The director re-run is ONE blocking call (no per-chunk server progress), so we show an estimated % that
// creeps up asymptotically while it runs and snaps to 100% when it returns. Calibrated by scene count.
function _redirectProgress(nScenes, label) {
  label = label || "Re-directing scenes…";
  const t = progressToast(label);
  const est = Math.max(6, Math.min(120, (nScenes || 1) * 0.5));   // rough expected seconds
  const t0 = Date.now();
  const iv = setInterval(() => {
    const el = (Date.now() - t0) / 1000;
    const pct = Math.min(96, Math.round((1 - Math.exp(-2.3 * el / est)) * 100));
    t.update(label, pct);
  }, 400);
  return { done() { clearInterval(iv); try { t.update(label, 100); } catch (_) {} setTimeout(() => { try { t.close(); } catch (_) {} }, 350); } };
}
const _redirectBtn = $("#redirectBtn");
if (_redirectBtn) _redirectBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!PROJECT || !DOC?.scenes.length) { toast("Split the script into scenes first.", "err"); return; }
  if (!(await confirmDialog("Re-run the director over all scenes? It rewrites prompts that are empty or just the raw voice-over line, and keeps any prompt you've written yourself.", { title: "Re-run Director", okText: "Re-run", danger: false }))) return;
  await stoppable(btn, async (sig) => {
    setStatus("re-running director…");
    const prog = _redirectProgress((DOC.scenes || []).filter(s => !s.approved).length);
    let r; try { r = await api.redirect(PROJECT, null, sig); } finally { prog.done(); }
    if (r.error) { toastErr(r.error); setStatus(""); return; }
    const script = DOC.script;
    DOC = await api.get(PROJECT); if (script) DOC.script = script;
    renderScenes(); updateSplitBtn();
    setStatus("");
    const msg = `Director re-run: ${r.fixed} prompt(s) rewritten` + (r.kept ? `, ${r.kept} kept as-is` : "");
    if (r.failed && r.failed.length) toast(`${msg}. Still empty on scene(s): ${r.failed.join(", ")} — try again, or Generate those.`, "err");
    else toast(`${msg}.`, "ok");
  });
});
// Audit & Fix — the best AI model reviews every UNAPPROVED scene: fixes weak / mismatched / duplicate prompts,
// enforces the house style, and SPLITS long multi-beat scenes into separate shots (voice-over kept word-for-word).
// Best model -> fallback -> if Kie is fully down it ERRORS and changes nothing (atomic). Replaces Re-split.
// Reusable REPORT MODAL — same look as the post-update "What's new" window (dark-green card, ✓ list).
// Used for Audit & Fix results and the Image-QA report. opts: {title, subtitle, items:[{text,kind}],
// checks:[{id,label,checked}], primaryLabel, onPrimary, secondaryLabel, note}. onPrimary(getCheckedIds).
function showReportModal(opts) {
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const old = document.getElementById("vslReport"); if (old) old.remove();
  const col = k => k === "error" ? "#e5665e" : k === "warn" ? "#e0b23a" : k === "info" ? "#6fb3e0" : "#52bd66";
  const mk = k => (k === "error" || k === "warn") ? "!" : "✓";
  const items = (opts.items || []).map(it =>
    `<li style="margin:0 0 10px;padding-left:24px;position:relative;line-height:1.5;color:#dfeae2;font-size:13.5px">`
    + `<span style="position:absolute;left:0;top:0;color:${col(it.kind)};font-weight:700">${mk(it.kind)}</span>`
    + esc(it.text) + `</li>`).join("") || `<li style="color:#8ca596;font-size:13.5px">No issues found — everything looks good. ✓</li>`;
  const checks = (opts.checks || []).map(c =>
    `<label style="display:flex;gap:9px;align-items:flex-start;margin:0 0 9px;cursor:pointer;color:#dfeae2;font-size:13px;line-height:1.45">`
    + `<input type="checkbox" data-ck="${esc(c.id)}" ${c.checked ? "checked" : ""} style="margin-top:2px;width:16px;height:16px;accent-color:#3fa554;flex:none">`
    + `<span>${esc(c.label)}</span></label>`).join("");
  if (!document.getElementById("vslReportKf")) {
    const st = document.createElement("style"); st.id = "vslReportKf";
    st.textContent = "@keyframes vslRf{from{opacity:0}to{opacity:1}}@keyframes vslRc{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}";
    document.head.appendChild(st);
  }
  const wrap = document.createElement("div"); wrap.id = "vslReport";
  wrap.style.cssText = "position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;"
    + "background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif;animation:vslRf .25s ease";
  const card = document.createElement("div");
  card.style.cssText = "max-width:560px;width:88%;max-height:82vh;overflow:auto;background:#0e1a13;border:1px solid #1f3a29;"
    + "border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:24px 24px 20px;animation:vslRc .28s ease";
  card.innerHTML =
    '<div style="display:flex;align-items:center;gap:11px;margin-bottom:4px">'
    + '<div style="width:36px;height:36px;border-radius:50%;flex:none;background:linear-gradient(180deg,#46ac5a,#237e43);'
    + 'display:flex;align-items:center;justify-content:center;box-shadow:0 0 16px rgba(82,189,102,.5)">'
    + '<span style="color:#fff;font-size:20px">✓</span></div>'
    + '<div><div style="font-size:17px;font-weight:700;color:#eaf3ec">' + esc(opts.title || "Report") + '</div>'
    + (opts.subtitle ? '<div style="font-size:12px;color:#7f9788">' + esc(opts.subtitle) + '</div>' : '') + '</div></div>'
    + (opts.note ? '<div style="font-size:12.5px;color:#8ca596;margin:14px 0 10px">' + esc(opts.note) + '</div>' : '<div style="height:8px"></div>')
    + '<ul style="list-style:none;margin:0;padding:0">' + items + '</ul>'
    + (checks ? '<div style="margin-top:16px;padding-top:14px;border-top:1px solid #1f3a29"><div style="font-size:12.5px;color:#8ca596;margin-bottom:10px">System improvements — tick to bake into the app so this doesn\'t recur:</div>' + checks + '</div>' : '')
    + '<div style="display:flex;gap:10px;margin-top:18px">'
    + (opts.tertiaryLabel ? '<button id="vslRptTer" style="flex:1;padding:11px;border:1px solid #2c4636;border-radius:10px;background:transparent;color:#cfe0d4;font-size:14px;font-weight:600;cursor:pointer">' + esc(opts.tertiaryLabel) + '</button>' : '')
    + (opts.secondaryLabel ? '<button id="vslRptSec" style="flex:1;padding:11px;border:1px solid #2c4636;border-radius:10px;background:transparent;color:#cfe0d4;font-size:14px;font-weight:600;cursor:pointer">' + esc(opts.secondaryLabel) + '</button>' : '')
    + (opts.primaryLabel ? '<button id="vslRptPri" style="flex:1;padding:11px;border:0;border-radius:10px;background:linear-gradient(180deg,#3fa554,#2b8443);color:#fff;font-size:14px;font-weight:600;cursor:pointer">' + esc(opts.primaryLabel) + '</button>' : '')
    + '</div>';
  wrap.appendChild(card); document.body.appendChild(wrap);
  const close = () => { wrap.style.animation = "vslRf .18s ease reverse"; setTimeout(() => wrap.remove(), 170); };
  const checkedIds = () => [...card.querySelectorAll("input[data-ck]:checked")].map(x => x.getAttribute("data-ck"));
  const pri = card.querySelector("#vslRptPri"), sec = card.querySelector("#vslRptSec"), ter = card.querySelector("#vslRptTer");
  if (pri) pri.onclick = () => { const ids = checkedIds(); close(); if (opts.onPrimary) opts.onPrimary(ids); };
  if (sec) sec.onclick = () => { const ids = checkedIds(); close(); if (opts.onSecondary) opts.onSecondary(ids); };
  if (ter) ter.onclick = () => { const ids = checkedIds(); close(); if (opts.onTertiary) opts.onTertiary(ids); };
  wrap.addEventListener("click", e => { if (e.target === wrap) { const ids = checkedIds(); close(); if (opts.onClose) opts.onClose(ids); } });
  return { close };
}
// ONE fixed progress card (top-right) that updates IN PLACE — no repeated toasts. Filled bar from 0→100%.
// Shared job-progress indicator (audit / image-QA / OST / auto-transitions). Renders as a toast-styled
// card in the toast host (top, with the other toasts), NOT the old grey fixed box — matches progressToast.
let _apToast = null;
function auditProgress(show, text, pct) {
  if (!show) { if (_apToast) { _apToast.close(); _apToast = null; } return; }
  if (!_apToast) _apToast = progressToast(text || "Working…");
  _apToast.update(text || "Working…", pct || 0);
}
const _auditBtn = $("#auditBtn");
if (_auditBtn) _auditBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._auditJid) { api.auditCancel(btn._auditJid).catch(() => {}); return; }   // running -> click again = stop
  if (!PROJECT || !DOC?.scenes.length) { toast("Split the script into scenes first.", "err"); return; }
  if (!(await confirmDialog("Audit & fix the director's shot prompts? The best AI model reviews every scene you haven't approved yet — it fixes weak, mismatched or duplicate prompts, applies the house style, and splits long multi-beat scenes into separate shots (the voice-over wording is never changed). Approved scenes are left untouched. If the AI can't be reached it stops and changes nothing.", { title: "Audit & Fix", okText: "Audit", danger: false }))) return;
  pushUndo("audit & fix");
  let r; try { r = await api.auditStart(PROJECT); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "audit failed to start"); return; }
  const jid = r.job; const oldTxt = btn.textContent; btn._auditJid = jid; btn.textContent = "⏹ Stop Audit";
  auditProgress(true, "Starting…", 0);
  // the audit's real % only ticks per 16-scene BATCH (coarse — it sits then jumps). Smooth it with an estimated
  // creep floored by the real batch %, so the bar always moves. Calibrated to the unapproved-scene count.
  const _nAud = (DOC.scenes || []).filter(s => !s.approved && (s.vo || "").trim()).length || 1;
  const _est = Math.max(8, Math.min(240, _nAud * 1.1)), _t0 = Date.now();
  const _creep = () => Math.min(96, Math.round((1 - Math.exp(-2.3 * (Date.now() - _t0) / 1000 / _est)) * 100));
  let _realPct = 0, _step = "Auditing…", _running = true;
  const _disp = setInterval(() => { if (_running) auditProgress(true, _step, Math.max(_creep(), _realPct)); }, 350);   // fast, smooth bar
  const finish = () => { _running = false; clearInterval(_disp); btn._auditJid = null; btn.textContent = oldTxt; auditProgress(false); };
  const iv = setInterval(async () => {
    let j; try { j = await api.auditJob(jid); } catch (_) { return; }
    if (!j) return;
    if (j.status === "running") { _realPct = j.pct || 0; _step = j.step || "Auditing…"; }   // real batch % = the floor; _disp draws it smoothly
    if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "audit failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Audit stopped — nothing changed.", "info"); return; }
    if (j.status === "done") {
      clearInterval(iv); finish();
      const script = DOC.script;
      DOC = await api.get(PROJECT); if (script) DOC.script = script;
      renderScenes(); renderVideos(); updateSplitBtn();
      const rep = j.report || {};
      const items = (rep.changes || []).map(c => ({ text: `#${c.id} — ${c.issue || "improved"}`, kind: "ok" }));
      showReportModal({
        title: "Audit & Fix — done",
        subtitle: `${rep.fixed || 0} prompt(s) fixed · ${rep.split || 0} scene(s) split → ${rep.added || 0} new · ${rep.total || (DOC.scenes || []).length} scenes total`,
        note: (rep.changes && rep.changes.length) ? "Here's what the audit changed:" : "",
        items, primaryLabel: "OK",
      });
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
});
$("#genAllImagesBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  const ids = DOC.scenes.filter(s => (s.prompt || s.testimonial || (s.ingredients && s.ingredients.length)) && s.image.status !== "ready").map(s => s.id);
  if (!ids.length) { alert("No scenes with a prompt and no image yet."); return; }
  if (!(await confirmDialog(`Generate images for ${ids.length} scene(s)?`, { title: "Generate All Images", okText: "Generate", danger: false }))) return;
  withBusy(btn, () => genImages(ids));
});
// Image QA — the AI looks at every generated image and checks it against the script; flagged scenes go red.
const _imageQaBtn = $("#imageQaBtn");
let _lastImgQaReport = null;   // cache the last Check-Images report so the button RE-OPENS it (until a fresh check / project change)
const _qaSaveReqs = (ids) => { if (ids && ids.length) { api.qaSystemRequest(PROJECT, ids).catch(() => {}); toast(`${ids.length} system improvement(s) queued for Claude Code.`, "ok", 5000); } };

function showImageQaReport(rep) {
  QA_FLAGGED = new Set((rep.flagged_ids || []).map(String));   // red numbers in the jump nav
  buildSceneJump();
  const sevRank = { high: 0, med: 1, low: 2 };
  const issues = (rep.issues || []).slice().sort((a, b) => (sevRank[a.severity] ?? 3) - (sevRank[b.severity] ?? 3));
  const items = issues.map(x => ({ text: `#${x.id} — ${x.issue}${x.regenerate ? "  (↻ regenerate)" : ""}`, kind: x.severity === "high" ? "error" : x.severity === "med" ? "warn" : "info" }));
  const regen = rep.regen_ids || [];
  const checks = (rep.system_suggestions || []).map(t => ({ id: t, label: t, checked: false }));
  const fixedTxt = rep.prompts_fixed ? ` · ${rep.prompts_fixed} prompt(s) auto-fixed` : "";
  showReportModal({
    title: "Image QA",
    subtitle: `${rep.flagged || 0} of ${rep.reviewed || 0} image(s) flagged · ${regen.length} to regenerate${fixedTxt}`,
    note: issues.length ? "Each flagged scene is RED in the jump nav, its reason is written in the scene's note, and its image prompt was auto-fixed. Regenerate the bad ones (all now, or one-by-one later):" : "All images look good — nothing flagged. ✓",
    items, checks,
    primaryLabel: regen.length ? `Apply — regenerate ${regen.length}` : "OK",
    onPrimary: (ids) => { _qaSaveReqs(ids); if (regen.length) { toast(`Regenerating ${regen.length} flagged image(s)…`, "info"); genImages(regen); } },
    secondaryLabel: "Close",
    onSecondary: (ids) => _qaSaveReqs(ids),
    tertiaryLabel: "↻ Re-Check Images",
    onTertiary: (ids) => { _qaSaveReqs(ids); runImageQa(); },
    onClose: (ids) => _qaSaveReqs(ids),
  });
}

async function runImageQa() {
  const btn = _imageQaBtn;
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.image && (s.image.approved_file || s.image.file)).length;
  if (!n) { alert("No generated images to check yet."); return; }
  if (!(await confirmDialog(`Check all ${n} generated image(s) against the script? The AI looks at each image, flags problems, writes the reason into each flagged scene's note and auto-fixes its prompt. Runs in parallel.`, { title: "Check Images", okText: "Check", danger: false }))) return;
  let r; try { r = await api.imageQaStart(PROJECT); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
  const jid = r.job, oldTxt = btn.textContent; btn._qaJid = jid; btn.textContent = "⏹ Stop";
  auditProgress(true, "Starting…", 0);
  const finish = () => { btn._qaJid = null; btn.textContent = oldTxt; auditProgress(false); };
  const iv = setInterval(async () => {
    let j; try { j = await api.imageQaJob(jid); } catch (_) { return; }
    if (!j) return;
    if (j.status === "running") auditProgress(true, j.step || "Checking images…", j.pct || 0);
    if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Stopped.", "info"); return; }
    if (j.status === "done") {
      clearInterval(iv); finish();
      const rep = j.report || {};
      _lastImgQaReport = rep;
      const script = DOC.script;   // the worker wrote flag reasons into notes + auto-fixed prompts → reload so the cards show them
      try { DOC = await api.get(PROJECT); if (script) DOC.script = script; renderScenes(); renderVideos(); } catch (_) {}
      showImageQaReport(rep);
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
}

if (_imageQaBtn) _imageQaBtn.addEventListener("click", (e) => {
  const btn = e.currentTarget;
  if (btn._qaJid) { api.imageQaCancel(btn._qaJid).catch(() => {}); return; }   // running → Stop
  if (_lastImgQaReport) { showImageQaReport(_lastImgQaReport); return; }        // already checked → RE-OPEN the last report
  runImageQa();                                                                // first time this project → run a fresh check
});
// Generate On-Screen Text — options popup, then a Claude job that adds punchy-keyword overlays with your presets.
function showOstModal(presets, onCreate) {
  const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  document.getElementById("ostModal")?.remove();
  const pick = (rx, i) => (presets.find(p => rx.test(p.name || "")) || presets[i] || presets[0]);
  const posDef = pick(/white|positive|pozitif/i, 0), negDef = pick(/red|negative|negatif/i, 1);
  const opts = (sel) => presets.map(p => `<option value="${esc(p.name)}"${p === sel ? " selected" : ""}>${esc(p.name)}</option>`).join("");
  const anims = [["popup", "Pop-up"], ["slide-left", "Slide L"], ["slide-top", "Slide top"], ["slide-bottom", "Slide bottom"]];   // never plain fade-in, never slide-right
  const animChecks = anims.map(([k, l]) => `<label style="display:inline-flex;gap:6px;align-items:center;margin:0 12px 8px 0;color:#dfeae2;font-size:13px;cursor:pointer"><input type="checkbox" data-anim="${k}" checked style="width:15px;height:15px;accent-color:#3fa554">${l}</label>`).join("");
  const fieldRow = (label, html) => `<div style="margin-bottom:12px"><div style="font-size:12px;color:#8ca596;margin-bottom:5px">${label}</div>${html}</div>`;
  const selCss = "width:100%;padding:8px 10px;background:#0b140e;color:#eaf3ec;border:1px solid #2c4636;border-radius:8px;font-size:13.5px";
  const numCss = "width:80px;padding:8px 10px;background:#0b140e;color:#eaf3ec;border:1px solid #2c4636;border-radius:8px;font-size:13.5px";
  const wrap = document.createElement("div"); wrap.id = "ostModal";
  wrap.style.cssText = "position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif";
  const card = document.createElement("div");
  card.style.cssText = "max-width:520px;width:90%;max-height:86vh;overflow:auto;background:#0e1a13;border:1px solid #1f3a29;border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:24px";
  card.innerHTML =
    '<div style="font-size:17px;font-weight:700;color:#eaf3ec;margin-bottom:4px">🅰️ Generate On-Screen Text</div>'
    + '<div style="font-size:12.5px;color:#8ca596;margin-bottom:16px">Claude reads the script and adds big on-screen text for the punchy keywords only (numbers, benefits, offers), using your presets and grouped animations.</div>'
    + fieldRow("Preset for POSITIVE lines (benefit / relief / solution)", `<select id="ostPosSel" style="${selCss}">${opts(posDef)}</select>`)
    + fieldRow("Preset for NEGATIVE lines (problem / fear / risk)", `<select id="ostNegSel" style="${selCss}">${opts(negDef)}</select>`)
    + `<div style="display:flex;gap:18px;margin-bottom:12px">`
    + `<div><div style="font-size:12px;color:#8ca596;margin-bottom:5px">Max chars / line</div><input id="ostMaxChars" type="number" value="20" min="6" max="40" style="${numCss}"></div>`
    + `<div><div style="font-size:12px;color:#8ca596;margin-bottom:5px">Max lines</div><input id="ostMaxLines" type="number" value="2" min="1" max="3" style="${numCss}"></div></div>`
    + fieldRow("Animations Claude may use (grouped for consecutive similar text)", `<div>${animChecks}</div>`)
    + '<div style="display:flex;gap:10px;margin-top:8px">'
    + '<button id="ostCancel" style="flex:1;padding:11px;border:1px solid #2c4636;border-radius:10px;background:transparent;color:#cfe0d4;font-size:14px;font-weight:600;cursor:pointer">Cancel</button>'
    + '<button id="ostCreate" style="flex:1;padding:11px;border:0;border-radius:10px;background:linear-gradient(180deg,#3fa554,#2b8443);color:#fff;font-size:14px;font-weight:600;cursor:pointer">Create OST</button></div>';
  wrap.appendChild(card); document.body.appendChild(wrap);
  const close = () => wrap.remove();
  card.querySelector("#ostCancel").onclick = close;
  wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
  card.querySelector("#ostCreate").onclick = () => {
    const params = {
      positive_preset: card.querySelector("#ostPosSel").value,
      negative_preset: card.querySelector("#ostNegSel").value,
      max_chars: +card.querySelector("#ostMaxChars").value || 20,
      max_lines: +card.querySelector("#ostMaxLines").value || 2,
      anims: [...card.querySelectorAll("input[data-anim]:checked")].map(x => x.getAttribute("data-anim")),
    };
    if (!params.anims.length) { toast("Pick at least one animation.", "err"); return; }
    close(); onCreate(params);
  };
}
const _genOstBtn = $("#genOstBtn");
if (_genOstBtn) _genOstBtn.addEventListener("click", () => {
  const btn = _genOstBtn;
  if (btn._ostJid) { api.ostCancel(btn._ostJid).catch(() => {}); return; }
  if (!PROJECT || !(DOC?.scenes || []).length) { toastErr("Split the script into scenes first."); return; }
  const presets = ((typeof ostPresets === "function" ? ostPresets() : []) || []).filter(p => p && p.name);
  if (!presets.length) { toast("Save at least one on-screen-text preset first (Scenes → an overlay's style → Save preset).", "err", 7000); return; }
  showOstModal(presets, async (params) => {
    let r; try { r = await api.genOst(PROJECT, params); } catch (_) { r = { error: "request failed" }; }
    if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
    const jid = r.job, oldTxt = btn.textContent; btn._ostJid = jid; btn.textContent = "⏹ Stop";
    auditProgress(true, "Starting…", 0);
    const finish = () => { btn._ostJid = null; btn.textContent = oldTxt; auditProgress(false); };
    const iv = setInterval(async () => {
      let j; try { j = await api.ostJob(jid); } catch (_) { return; }
      if (!j) return;
      if (j.status === "running") auditProgress(true, j.step || "Working…", j.pct || 0);
      if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
      if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Stopped.", "info"); return; }
      if (j.status === "done") {
        clearInterval(iv); finish();
        const script = DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script;
        renderScenes(); buildSceneJump();
        const rep = j.report || {};
        const items = (rep.changes || []).map(c => ({ text: `#${c.id} — ${c.text}`, kind: "ok" }));
        showReportModal({ title: "On-screen text added", subtitle: `${rep.added || 0} scene(s) got on-screen text (of ${rep.eligible || 0} eligible)`, note: items.length ? "Punchy keywords placed as overlays:" : "No punchy scenes matched.", items, primaryLabel: "OK" });
        try { playNotifChime(); } catch (_) {}
      }
    }, 1500);
  });
});
// Auto Transitions — Claude picks meaningful scene-to-scene transitions across the whole script.
const _autoTransBtn = $("#autoTransBtn");
if (_autoTransBtn) _autoTransBtn.addEventListener("click", async () => {
  const btn = _autoTransBtn;
  if (btn._trJid) { api.transCancel(btn._trJid).catch(() => {}); return; }
  if (!PROJECT || !(DOC?.scenes || []).length) { toastErr("Split the script into scenes first."); return; }
  if (!(await confirmDialog("Let Claude choose scene-to-scene transitions across the whole script? It uses them sparingly — dip-to-black for emotional beats, flash for reveals, a consistent slide for list runs, crossfade for soft changes, a plain cut for the rest. This sets each scene's transition (you can still edit them).", { title: "Auto Transitions", okText: "Run", danger: false }))) return;
  let r; try { r = await api.autoTransStart(PROJECT); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
  const jid = r.job, oldTxt = btn.textContent; btn._trJid = jid; btn.textContent = "⏹ Stop";
  auditProgress(true, "Starting…", 0);
  const finish = () => { btn._trJid = null; btn.textContent = oldTxt; auditProgress(false); };
  const iv = setInterval(async () => {
    let j; try { j = await api.transJob(jid); } catch (_) { return; }
    if (!j) return;
    if (j.status === "running") auditProgress(true, j.step || "Choosing transitions…", j.pct || 0);
    if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Stopped.", "info"); return; }
    if (j.status === "done") {
      clearInterval(iv); finish();
      const script = DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script;
      renderScenes();
      const rep = j.report || {};
      const items = (rep.changes || []).map(c => ({ text: `#${c.id} — ${c.transition}`, kind: "ok" }));
      showReportModal({ title: "Auto Transitions — done", subtitle: `${rep.applied || 0} transition(s) set across ${rep.total || 0} scenes (the rest are plain cuts).`, note: items.length ? "Transitions added:" : "No transitions needed.", items, primaryLabel: "OK" });
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
});
// Shared background video-prompt job (parallel, vision) with a PERSISTENT progress toast that survives tab
// switches and keeps the job running server-side. ids=null -> all approved scenes; ids=[...] -> just those.
let _vidPromptJid = null;                                  // the currently-running job — guards against a double start
async function runVidPromptJob(ids) {
  if (!PROJECT) return;
  if (_vidPromptJid) { toast("A video-prompt job is already running — let it finish or Stop it first.", "info"); return; }
  let r; try { r = await api.vidPromptStart(PROJECT, ids); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
  const jid = r.job; _vidPromptJid = jid;
  const prog = progressToast("Starting…", () => api.vidPromptCancel(jid).catch(() => {}));
  const done = () => { _vidPromptJid = null; prog.close(); };
  const iv = setInterval(async () => {
    let j; try { j = await api.vidPromptJob(jid); } catch (_) { return; }   // transient network error → keep polling
    if (!j) return;
    if (j.status === "running") { prog.update(j.step || "Writing motion prompts…", j.pct || 0); return; }
    clearInterval(iv);
    if (j.status === "error") { done(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { done(); toast("Stopped.", "info"); return; }
    if (j.status === "done") {
      done();
      const script = DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script;
      renderVideos();
      const rep = j.report || {};
      showReportModal({ title: "Video prompts written", subtitle: `${rep.written || 0} of ${rep.total || 0} scenes — each motion prompt written from its own image (static camera).`, items: [], primaryLabel: "OK" });
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
}
$("#genAllVideoPromptsBtn").addEventListener("click", async () => {
  if (!PROJECT) return;
  if (_vidPromptJid) { api.vidPromptCancel(_vidPromptJid).catch(() => {}); return; }   // running → Stop
  const n = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).length;
  if (!n) { alert("No approved images here yet. Approve images in the Scenes tab first."); return; }
  if (!(await confirmDialog(`Generate video (motion) prompts for ${n} approved scene(s)? The AI LOOKS AT each scene's image and writes a motion prompt that suits it (static camera). This overwrites existing video prompts and can take a few minutes.`, { title: "Generate All Video Prompts", okText: "Generate", danger: false }))) return;
  runVidPromptJob(null);
});
// mini popup: pick which overlays to (re)place — icons and/or sound effects (each is independent, only the
// picked ones are overwritten). Resolves to {icons, sfx} or null if cancelled.
function askOverlayOptions(n) {
  return new Promise(resolve => {
    document.getElementById("ovModal")?.remove();
    const wrap = document.createElement("div"); wrap.id = "ovModal";
    wrap.style.cssText = "position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif";
    const ck = (id, label, hint) => `<label style="display:flex;gap:10px;align-items:flex-start;margin-bottom:12px;color:#eaf3ec;font-size:14px;cursor:pointer"><input type="checkbox" id="${id}" checked style="width:17px;height:17px;margin-top:1px;accent-color:#3fa554"><span>${label}<br><span style="font-size:12px;color:#8ca596">${hint}</span></span></label>`;
    const card = document.createElement("div");
    card.style.cssText = "max-width:460px;width:90%;background:#0e1a13;border:1px solid #1f3a29;border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:24px";
    card.innerHTML =
      '<div style="font-size:17px;font-weight:700;color:#eaf3ec;margin-bottom:4px">✨ Generate Overlays</div>'
      + `<div style="font-size:12.5px;color:#8ca596;margin-bottom:16px">Claude looks at each of the ${n} approved image(s) and places what you tick below (only the ticked ones are overwritten):</div>`
      + ck("ovIcons", "Icons", "X / pain-burst (always red) + arrows (green when they point at something good, red when bad), on the exact spot — skipping charts/graphics.")
      + ck("ovSfx", "Sound Effects", "Ambulance / heart-monitor / hit / countdown where the image calls for it.")
      + '<div style="display:flex;gap:10px;margin-top:8px">'
      + '<button id="ovCancel" style="flex:1;padding:11px;border:1px solid #2c4636;border-radius:10px;background:transparent;color:#cfe0d4;font-size:14px;font-weight:600;cursor:pointer">Cancel</button>'
      + '<button id="ovGo" style="flex:1;padding:11px;border:0;border-radius:10px;background:linear-gradient(180deg,#3fa554,#2b8443);color:#fff;font-size:14px;font-weight:600;cursor:pointer">Generate</button></div>';
    wrap.appendChild(card); document.body.appendChild(wrap);
    const done = (v) => { wrap.remove(); resolve(v); };
    wrap.addEventListener("click", ev => { if (ev.target === wrap) done(null); });
    card.querySelector("#ovCancel").onclick = () => done(null);
    card.querySelector("#ovGo").onclick = () => {
      const icons = card.querySelector("#ovIcons").checked, sfx = card.querySelector("#ovSfx").checked;
      if (!icons && !sfx) { toast("Tick icons and/or sound effects.", "info"); return; }
      done({ icons, sfx });
    };
  });
}
const _overlayBtn = $("#overlayBtn");
if (_overlayBtn) _overlayBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._ovJid) { api.overlaysCancel(btn._ovJid).catch(() => {}); return; }   // running → click again = stop
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).length;
  if (!n) { toastErr("Approve some images first — this looks at each scene's image."); return; }
  const opts = await askOverlayOptions(n);
  if (!opts) return;
  // if icons already exist and the user is (re)generating icons, warn: this wipes + rebuilds ALL icons
  if (opts.icons && (DOC?.scenes || []).some(s => Array.isArray(s.icons) && s.icons.length)) {
    if (!(await confirmDialog("Regenerate on-screen icons? This REMOVES all current icons and re-analyses every scene from scratch, placing fresh icons that fit each image. Any manual icon tweaks will be lost. (Your images and approvals are not affected.) Are you sure?", { title: "Regenerate Icons", okText: "Yes, regenerate", danger: true }))) return;
  }
  let r; try { r = await api.overlaysStart(PROJECT, opts); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
  const jid = r.job, oldTxt = btn.textContent; btn._ovJid = jid; btn.textContent = "⏹ Stop";
  auditProgress(true, "Starting…", 0);
  const finish = () => { btn._ovJid = null; btn.textContent = oldTxt; auditProgress(false); };
  const iv = setInterval(async () => {
    let j; try { j = await api.overlaysJob(jid); } catch (_) { return; }
    if (!j) return;
    if (j.status === "running") auditProgress(true, j.step || "Analyzing…", j.pct || 0);
    if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Stopped.", "info"); return; }
    if (j.status === "done") {
      clearInterval(iv); finish();
      const script = DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script;
      renderScenes();
      const rep = j.report || {};
      showReportModal({ title: "Overlays placed", subtitle: `Looked at ${rep.scenes || 0} image(s): ${rep.icons || 0} icon(s) and ${rep.sfx || 0} sound effect(s) placed to match the picture.`, items: [], primaryLabel: "OK" });
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
});
// Check Videos — grab a frame from each generated video and vision-check it; report flagged scenes.
const _videoQaBtn = $("#videoQaBtn");
if (_videoQaBtn) _videoQaBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._vqJid) { api.videoQaCancel(btn._vqJid).catch(() => {}); return; }   // running → Stop
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => (s.video || {}).file).length;
  if (!n) { toastErr("No generated videos to check yet."); return; }
  if (!(await confirmDialog(`Check ${n} generated video(s)? The AI grabs a frame from each and flags warped faces/hands, AI artefacts, wrong subjects, gibberish text or mismatches vs the voice-over. This can take a few minutes. Nothing is changed.`, { title: "Check Videos", okText: "Check", danger: false }))) return;
  let r; try { r = await api.videoQaStart(PROJECT); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "could not start"); return; }
  const jid = r.job, oldTxt = btn.textContent; btn._vqJid = jid; btn.textContent = "⏹ Stop";
  auditProgress(true, "Starting…", 0);
  const finish = () => { btn._vqJid = null; btn.textContent = oldTxt; auditProgress(false); };
  const iv = setInterval(async () => {
    let j; try { j = await api.videoQaJob(jid); } catch (_) { return; }
    if (!j) return;
    if (j.status === "running") auditProgress(true, j.step || "Checking videos…", j.pct || 0);
    if (j.status === "error") { clearInterval(iv); finish(); toastErr(j.error || "failed"); try { playErrorChime(); } catch (_) {} return; }
    if (j.status === "cancelled") { clearInterval(iv); finish(); toast("Stopped.", "info"); return; }
    if (j.status === "done") {
      clearInterval(iv); finish();
      const rep = j.report || {};
      const sevRank = { high: 0, med: 1, low: 2 };
      const issues = (rep.issues || []).slice().sort((a, b) => (sevRank[a.severity] ?? 3) - (sevRank[b.severity] ?? 3));
      const items = issues.map(x => ({ text: `#${x.id} — ${x.issue}`, kind: x.severity === "high" ? "error" : x.severity === "med" ? "warn" : "info" }));
      showReportModal({
        title: "Video QA — done",
        subtitle: `${rep.flagged || 0} of ${rep.reviewed || 0} video(s) flagged`,
        note: issues.length ? "These videos look off — review or regenerate them:" : "All videos look good — nothing flagged. ✓",
        items, primaryLabel: "OK",
      });
      try { playNotifChime(); } catch (_) {}
    }
  }, 1500);
});
// Preflight — one-click pre-export readiness check
const _preflightBtn = $("#preflightBtn");
if (_preflightBtn) _preflightBtn.addEventListener("click", async () => {
  if (!PROJECT) return;
  let r; try { r = await api.preflight(PROJECT); } catch (_) { r = { error: "request failed" }; }
  if (!r || r.error) { toastErr((r && r.error) || "preflight failed"); return; }
  const items = r.items || [];
  const ready = (r.errors || 0) === 0;
  showReportModal({
    title: ready ? "Preflight — ready to export ✓" : "Preflight — issues found",
    subtitle: `${r.errors || 0} blocker(s) · ${r.warns || 0} warning(s) · ${r.scenes || 0} scene(s)`,
    note: items.length ? (ready ? "No blockers. Notes:" : "Fix the blockers (red) before you render:") : "Everything checks out. ✓",
    items, primaryLabel: "OK",
  });
});
$("#genAllVideosBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).length;
  if (!n) { alert("No approved images to convert. Approve images in the Scenes tab first."); return; }
  if (!(await confirmDialog(`Convert all ${n} approved image(s) to video?`, { title: "Generate All Videos", okText: "Convert", danger: false }))) return;
  withBusy(btn, () => genVideos("all"));
});
// Export tab: individual file downloads (Script / Voiceover / Subtitle / Images / Videos / Premiere).
// Each shows a spinner on its own button while the server assembles the file (Premiere .xml, the
// images/videos .zip, etc. can take a moment) and until the native Save-As dialog resolves.
// subtitle download → a small popup to choose full vs on-screen-text-aware, THEN download
function askSubtitleOptions() {
  return new Promise(resolve => {
    document.getElementById("subDlModal")?.remove();
    const wrap = document.createElement("div"); wrap.id = "subDlModal";
    wrap.style.cssText = "position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif";
    const card = document.createElement("div");
    card.style.cssText = "max-width:480px;width:90%;background:#0e1a13;border:1px solid #1f3a29;border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:24px";
    card.innerHTML =
      '<div style="font-size:17px;font-weight:700;color:#eaf3ec;margin-bottom:14px">💬 Download Subtitle</div>'
      + '<label style="display:flex;gap:10px;align-items:flex-start;margin-bottom:16px;color:#eaf3ec;font-size:14px;cursor:pointer"><input type="checkbox" id="subDlStrip" style="width:17px;height:17px;margin-top:1px;accent-color:#3fa554"><span>Trim words shown as on-screen text<br><span style="font-size:12.5px;color:#8ca596">Where an on-screen text appears, its words are removed from the subtitle and the caption is split around it (it ends before the on-screen text and resumes after) — so the subtitle never repeats the on-screen text. Leave OFF for the full subtitle.</span></span></label>'
      + '<div style="display:flex;gap:10px">'
      + '<button id="subDlCancel" style="flex:1;padding:11px;border:1px solid #2c4636;border-radius:10px;background:transparent;color:#cfe0d4;font-size:14px;font-weight:600;cursor:pointer">Cancel</button>'
      + '<button id="subDlGo" style="flex:1;padding:11px;border:0;border-radius:10px;background:linear-gradient(180deg,#3fa554,#2b8443);color:#fff;font-size:14px;font-weight:600;cursor:pointer">Download</button></div>';
    wrap.appendChild(card); document.body.appendChild(wrap);
    const done = v => { wrap.remove(); resolve(v); };
    wrap.addEventListener("click", ev => { if (ev.target === wrap) done(null); });
    card.querySelector("#subDlCancel").onclick = () => done(null);
    card.querySelector("#subDlGo").onclick = () => done({ strip: card.querySelector("#subDlStrip").checked });
  });
}
$$(".dl-btn[data-dl]").forEach(b => b.addEventListener("click", async () => {
  if (!PROJECT || b.disabled) return;
  const kind = b.dataset.dl;
  let q = "";
  if (kind === "subtitle") { const opt = await askSubtitleOptions(); if (!opt) return; q = opt.strip ? "?ost=strip" : ""; }
  withBusy(b, () => downloadUrl(`/api/download/${PROJECT}/${kind}${q}`, `${PROJECT}_${kind}`, kind));
}));
// Export tab: one ZIP with everything (with a confirm + a content summary afterwards)
function renderExportInfo(box, i, name) {
  const secs = Math.round(i.duration_sec || 0);
  const dur = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}`;
  const musicCount = (i.music || []).filter(m => m.track).length;
  const warns = (i.warnings || []).map(w => `<li class="warn-txt">⚠ ${w}</li>`).join("");
  box.className = "export-result ok";
  box.innerHTML =
    `<div class="export-ok-head">✓ Downloaded <b>${name || ""}</b></div>` +
    `<p class="hint export-summary">Duration ${dur} · ${i.scenes} scenes · ${i.dl_image ?? i.used_image ?? 0} images · ${i.dl_video ?? i.used_video ?? 0} videos</p>` +
    `<p class="hint export-summary">Includes: Premiere project, subtitle, voice-over, script, ` +
      `${musicCount} background music track${musicCount === 1 ? "" : "s"}</p>` +
    (warns ? `<ul class="export-warns">${warns}</ul>` : "");
}
$("#downloadAllBtn").addEventListener("click", async (e) => {
  if (!PROJECT) return;
  const btn = e.currentTarget;   // capture BEFORE the await — e.currentTarget is null afterwards
  if (!(await confirmDialog("Download the ENTIRE project as one .zip — Premiere .xml, subtitle, voice-over, script, all clips and the background music?", { title: "Download All Files", okText: "Download", danger: false }))) return;
  const box = $("#exportResult");
  box.hidden = false; box.className = "export-result";
  box.innerHTML = '<span class="sub-spin"></span> Assembling everything (timeline, choosing music, zipping)…';
  withBusy(btn, async () => {
    // Desktop window: stream the generated zip straight to a Save-As location (the summary comes
    // back in the X-Export-Info header, so the export card still fills in).
    if (window.pywebview && window.pywebview.api && window.pywebview.api.save_download) {
      const r = await window.pywebview.api.save_download(`/api/download/${PROJECT}/all`, document.cookie, `${PROJECT}.zip`);
      if (r && r.ok) {
        let info = {}; try { info = JSON.parse(decodeURIComponent(r.info || "")); } catch (e) {}
        renderExportInfo(box, info, (r.path || "").split(/[\\/]/).pop() || "download.zip");
        toast("Saved: " + r.path, "ok");
      } else if (r && r.cancelled) { box.hidden = true; }
      else { box.className = "export-result err"; box.textContent = "Download failed: " + ((r && r.error) || ""); }
      return;
    }
    let resp;
    try { resp = await fetch(`/api/download/${PROJECT}/all`); }
    catch (err) { box.className = "export-result err"; box.textContent = "Download failed: " + err; return; }
    if (!resp.ok) { let m = "Download failed"; try { m = (await resp.json()).error || m; } catch (e) {} box.className = "export-result err"; box.textContent = m; return; }
    const blob = await resp.blob();
    let info = {}; try { info = JSON.parse(decodeURIComponent(resp.headers.get("X-Export-Info") || "")); } catch (e) {}
    const cd = resp.headers.get("Content-Disposition") || "";
    const mm = cd.match(/filename\*?=(?:UTF-8''|")?([^";]+)/);
    const name = mm ? decodeURIComponent(mm[1].replace(/"$/, "")) : "download.zip";
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
    renderExportInfo(box, info, name);
  });
});

// ---------- rough-cut preview player (images/videos + VO + music + captions, synced) ----------
const PV = { m: null, raf: 0, scene: -1, seg: -1, cap: -1, vidSrc: "", imagesOnly: false, ostEls: [] };
const EMO_COLORS = {
  // Suno 6-mood palette — each a clearly distinct colour on the scrubber
  Hook:          "#7a6ab0",   // purple (mysterious)
  Suspense:      "#b5556a",   // dark rose (tension)
  Dramatic:      "#b5789f",   // mauve
  Scientific:    "#3fa6c0",   // teal (science)
  Corporate:     "#57b06a",   // green (trust)
  Inspirational: "#d0a24a",   // amber (hope)
  // legacy mood/genre folders (kept for older cached plans)
  Hope_Inspirational: "#d0a24a",   // amber
  Neutral_Bed:        "#7f8c99",   // grey-blue
  Problem_Emotional:  "#b5789f",   // mauve
  Suspense_Curiosity: "#7a6ab0",   // purple
  Testimonial_Warm:   "#57b06a",   // green
  Upbeat_Happy:       "#e0803a",   // orange
  // legacy emotion keys (older projects) kept for back-compat
  DOCUMENTARY:"#4a7a8c", EMOTIONAL:"#b5789f", FEAR:"#a85a5a", INSPIRING:"#d0a24a",
  SCIENTIFIC:"#5a8ac0", SUSPENSE:"#7a6ab0", TESTIMONIAL:"#57b06a" };
const pvFmt = s => { s = Math.max(0, s | 0); return `${(s/60)|0}:${String(s%60).padStart(2,"0")}`; };
const pvIdx = (arr, t) => { for (let i=0;i<arr.length;i++) if (t>=arr[i].start && t<arr[i].end) return i; return -1; };

// restore=true: a silent reload restore. Fetch the manifest and, ONLY if it's byte-identical to the
// one from the last explicit build (nothing changed → media already cached), re-show the preview
// instantly (no re-buffer). If anything changed, stay blank so the user re-builds deliberately.
async function buildPreview(e, restore) {
  if (!PROJECT) return;
  const btn = e && e.currentTarget, st = $("#previewStatus");
  const key = "pvPreview_" + PROJECT;
  if (!restore) { st.hidden = false; st.className = "pv-status"; st.innerHTML = '<span class="sub-spin"></span> Building preview (choosing music, syncing)…'; }
  const run = async () => {
    let r;
    try { r = await fetch(`/api/preview/${PROJECT}`); }
    catch (err) { if (!restore) { st.className = "pv-status err"; st.textContent = "Preview failed: " + err; } return; }
    if (!r.ok) { if (!restore) { let m = "Preview failed"; try { m = (await r.json()).error || m; } catch (e) {} st.className = "pv-status err"; st.textContent = m; } return; }
    const m = await r.json();
    if (!m.scenes || !m.scenes.length) { if (!restore) { st.className = "pv-status err"; st.textContent = "Nothing to preview yet — approve some images or videos first."; } return; }
    const sig = JSON.stringify(m);
    if (restore) {
      let cached = null; try { cached = localStorage.getItem(key); } catch (e) {}
      if (cached !== sig) return;          // content changed since the last build → require a manual re-build
      await initPreview(m, false);         // unchanged → instant restore, no media-gate (media is browser-cached)
      return;
    }
    st.innerHTML = '<span class="sub-spin"></span> Getting everything ready…';   // spinner stays up until all media is buffered
    await initPreview(m, true);
    try { localStorage.setItem(key, sig); } catch (e) {}   // remember this exact preview so a later reload can restore it
    st.hidden = true;
    maybeGenerateMusic(m);                                  // Suno-generate any missing background music (background)
  };
  if (restore) await run(); else await withBusy(btn, run);
}

// ---- Suno background music: auto-generate on Build Preview -----------------
let _musicGenBusy = false, _musicGenJob = null;
async function _pollMusicJob(job, onProgress) {
  let misses = 0;
  while (true) {
    await new Promise(r => setTimeout(r, 5000));
    let s; try { s = await api.musicJob(job); } catch (_) { s = null; }
    if (!s || (s.error && !s.status)) {                 // transient (HTML/network hiccup) — keep trying a while
      if (++misses > 6) return { status: "error", error: (s && s.error) || "lost connection to the server" };
      continue;
    }
    misses = 0;
    if (onProgress) onProgress(s);
    if (s.status === "done" || s.status === "error" || s.status === "cancelled") return s;
  }
}
// Re-fetch the preview so the freshly generated tracks get loaded into the player + panel.
async function refreshPreviewMusic() {
  try {
    const r = await fetch(`/api/preview/${PROJECT}`); if (!r.ok) return;
    const m = await r.json();
    if (!m.scenes || !m.scenes.length) return;
    const playing = !$("#pvVo").paused;
    if (playing) { if (PV && PV.m) PV.m.music = m.music; renderMusicPanel(PV.m); return; }   // don't yank a playing preview
    await initPreview(m, true);
    try { localStorage.setItem("pvPreview_" + PROJECT, JSON.stringify(m)); } catch (e) {}
  } catch (_) {}
}
// Ask the backend to generate whatever music the plan still needs (missing moods AND adjacent same-mood
// sections that would otherwise share a track), show progress + a result toast. The backend decides `need`.
async function maybeGenerateMusic(m) {
  if (_musicGenBusy) return;
  if (!(m.music || []).length) return;
  _musicGenBusy = true; _musicGenJob = null;
  let pt = null;
  try {
    const r = await api.musicGenerate(PROJECT);
    if (r.error) { toastErr(r.error); return; }
    if (!r.need) return;                              // nothing to generate — every section is already covered
    _musicGenJob = r.job;
    const total = r.need;
    pt = progressToast("Generating Background Music", () => api.musicCancel(_musicGenJob));
    const s = await _pollMusicJob(r.job, st => pt.update(`Generating Background Music… (${st.done || 0}/${total})`, total ? (st.done / total * 100) : 50));
    pt.close(); pt = null;
    if (s.status === "cancelled") { toast("Music generation stopped.", "info"); await refreshPreviewMusic(); return; }
    if (s.status === "error") { toastErr("Music generation failed: " + (s.error || "")); return; }
    await refreshPreviewMusic();
    toast(`🎵 Suno: ${s.generated || 0} · Reused: ${r.reused || 0}`, "ok", 6000);
  } catch (e) { if (pt) pt.close(); toastErr("Music generation failed: " + e); }
  finally { _musicGenBusy = false; _musicGenJob = null; }
}

// Preload + DECODE every scene image, BUFFER every video, the voice-over and the first music track,
// and RESOLVE only once they're actually playable — so revealing the player means "ready to play".
// KEEPING a ref to each decoded Image is CRITICAL: otherwise it is GC'd, its bitmap dropped, and the
// next scene swap shows the stale (un-zoomed) frame for a beat → the "snaps back then jumps" glitch.
// Each wait is capped so one slow/broken asset can't hang the preview forever.
function pvPreloadAll(m, wait) {
  if (wait === undefined) wait = true;
  PV.preloadImgs = []; PV.preloadVids = [];
  const status = $("#previewStatus");
  const cap = (p, ms) => Promise.race([p, new Promise(r => setTimeout(r, ms))]);
  const mediaReady = (el, ms) => cap(new Promise(res => {
    if (el.readyState >= 3) return res();
    el.addEventListener("canplaythrough", res, { once: true });
    el.addEventListener("error", res, { once: true });
  }), ms);
  const waits = [];
  m.scenes.forEach(sc => {
    const src = sc.img || (sc.type === "image" ? sc.url : null);
    if (src) { const im = new Image(); im.src = src; PV.preloadImgs.push(im); waits.push(cap(im.decode ? im.decode().catch(() => {}) : Promise.resolve(), 6000)); }
    if (sc.type === "video" && sc.url) { const v = document.createElement("video"); v.preload = "auto"; v.muted = true; v.src = sc.url; PV.preloadVids.push(v); v.load(); waits.push(mediaReady(v, 15000)); }
  });
  // Prime the FIRST scene's video onto the actual playback element (#pvVideo) so its opening frame is DECODED
  // before reveal — with the poster removed, a ready video paints its OWN first frame on open (no stretch, no
  // black). Later cuts are bridged by the #pvHold layer instead of a poster.
  const s0 = m.scenes[0];
  if (s0 && s0.type === "video" && s0.url && !(PV.imagesOnly && s0.img)) {
    const pv = $("#pvVideo");
    if (pv && pv._pvSrc !== s0.url) { pv.src = s0.url; pv._pvSrc = s0.url; try { pv.currentTime = 0; } catch (e) {} pv.load(); waits.push(mediaReady(pv, 15000)); }
  }
  if (m.vo) { const vo = $("#pvVo"); vo.load(); waits.push(mediaReady(vo, 15000)); }   // voice-over
  const g0 = (m.music || [])[0];                                                        // first audible music track (slot 0)
  if (g0 && g0.url) { const el = pvMusicEls()[0]; if (el) { el.src = g0.url; el.dataset.src = g0.url; el.loop = true; el.volume = 0; el.load(); waits.push(mediaReady(el, 12000)); } }
  if (!wait) return Promise.resolve();   // restore mode: refs/srcs are set + decoding/buffering in the background; don't block
  const total = waits.length; let done = 0;
  waits.forEach(w => w.then(() => { done++; if (status && !status.hidden) status.innerHTML = `<span class="sub-spin"></span> Getting everything ready… ${done}/${total}`; }));
  return Promise.all(waits);
}
async function initPreview(m, block) {
  if (block === undefined) block = true;
  PV.m = m; PV.scene = -1; PV.seg = -1; PV.cap = -1; PV.vidSrc = ""; PV.vidCur = 0; PV.kara = null;
  // refresh the VO word timeline so the testimonial karaoke has current word timings (it can go stale if the
  // SRT was generated after the timeline was first loaded); repaint the current scene once it arrives
  tcLoadTL(true).then(() => { try { PV.scene = -1; pvRender($("#pvVo").currentTime || 0); } catch (_) {} });
  [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) { v._pvSrc = ""; v.hidden = true; } });   // reset the two video buffers
  { const hh = $("#pvHold"); if (hh) hh.hidden = true; }
  $("#pvVo").src = m.vo; pvMusicEls().forEach(el => { el.removeAttribute("src"); el.removeAttribute("data-src"); el.volume = 0; });
  const segs = $("#pvSegs"), ticks = $("#pvTicks");
  segs.innerHTML = ""; ticks.innerHTML = "";
  (m.music || []).forEach((g, i) => {
    const band = document.createElement("div");
    band.className = "pv-seg"; band.dataset.seg = i;                 // index → highlighted from the music panel
    band.style.left = (g.start/m.duration*100) + "%";
    band.style.width = ((g.end-g.start)/m.duration*100) + "%";
    band.style.background = EMO_COLORS[g.emotion] || "#5a8a6a";
    band.title = `${g.emotion} — ${g.track}`;
    segs.appendChild(band);
    if (g.start > 0) { const tk = document.createElement("div"); tk.className = "pv-tick"; tk.style.left = (g.start/m.duration*100) + "%"; ticks.appendChild(tk); }
  });
  renderMusicPanel(m);
  buildSubStylePanel();                              // global subtitle-style panel (appears with the preview)
  pvBuildTextTrack();
  await pvPreloadAll(m, block);                      // block=true: wait until ALL media is buffered; false: fire-and-forget (instant restore)
  $("#pvVo").onended = () => { pvPause(); $("#pvVo").currentTime = 0; PV.seg = -1; PV.cap = -1; pvRender(0); };
  $("#pvVo").muted = false; pvMusicEls().forEach(el => el.muted = false); $("#pvMute").textContent = "🔊";
  $("#pvBig").hidden = false;                        // paused → big center play icon showing
  $("#buildPreviewBtn").textContent = "🔄 Rebuild Preview";
  $("#renderSection").hidden = false;               // there's something to render now — slide it in
  $("#pvTime").textContent = `0:00 / ${pvFmt(m.duration)}`;
  $("#previewWrap").hidden = false;                 // reveal ONLY now → pressing play starts instantly
  pvRender(0);
}

// preview a single BGM track (one shared audio; play again / another row stops it)
let pvTrackAudio = null, pvTrackBtn = null;
function pvStopTrack() {
  if (pvTrackAudio) pvTrackAudio.pause();
  if (pvTrackBtn) { pvTrackBtn.textContent = "▶"; pvTrackBtn = null; }
}
function pvPlayTrack(btn, emotion, filename) {
  if (pvTrackBtn === btn) { pvStopTrack(); return; }      // toggle off
  pvStopTrack();
  pvPause();                                              // pause the main preview so the track is clear
  if (!pvTrackAudio) { pvTrackAudio = new Audio(); pvTrackAudio.addEventListener("ended", pvStopTrack); }
  pvTrackAudio.src = `/bgm/${emotion}/${filename}`;
  pvTrackAudio.currentTime = 0; pvTrackAudio.play().catch(() => {});
  btn.textContent = "⏹"; pvTrackBtn = btn;
}

// music-override panel: one row per segment with a track dropdown + a re-pick button
function renderMusicPanel(m) {
  pvStopTrack();
  const box = $("#pvMusicPanel"); if (!box) return;
  const title = $("#pvMusicHead");
  box.innerHTML = "";
  if (!m.music || !m.music.length) { box.hidden = true; if (title) title.hidden = true; return; }
  box.hidden = false; if (title) title.hidden = false;
  m.music.forEach((g, i) => {
    const row = document.createElement("div"); row.className = "pv-music-row";
    const info = document.createElement("span"); info.className = "pv-music-info";
    const dot = document.createElement("i"); dot.className = "pv-music-dot"; dot.style.background = EMO_COLORS[g.emotion] || "#5a8a6a";
    const seg = document.createElement("span"); seg.className = "pv-music-seg";
    seg.textContent = `${g.emotion[0] + g.emotion.slice(1).toLowerCase()} · ${pvFmt(g.start)}–${pvFmt(g.end)}`;
    info.append(dot, seg);
    const hi = (on) => {                                  // hovering the emotion/time highlights that band in the scrubber
      const box2 = $("#pvSegs"); if (!box2) return;
      box2.classList.toggle("hovering", on);
      const band = box2.querySelector(`.pv-seg[data-seg="${i}"]`);
      if (band) band.classList.toggle("hi", on);
    };
    row.addEventListener("mouseenter", () => hi(true));   // anywhere on the row (label, dropdown, play)
    row.addEventListener("mouseleave", () => hi(false));
    const sel = document.createElement("select"); sel.className = "pv-music-sel";
    (g.options || []).forEach(t => { const o = document.createElement("option"); o.value = t; o.textContent = t.replace(/\.(mp3|wav)$/i, ""); if (t === g.track) o.selected = true; sel.appendChild(o); });
    const play = document.createElement("button"); play.className = "pv-music-play ghost"; play.type = "button"; play.textContent = "▶"; play.title = "Preview the selected track";
    play.addEventListener("click", () => pvPlayTrack(play, g.emotion, sel.value));
    const rer = document.createElement("button"); rer.className = "pv-music-reroll ghost"; rer.type = "button"; rer.textContent = "🎲"; rer.title = "Pick a different track from the library for this section";
    rer.addEventListener("click", async () => {
      if (_musicGenBusy) { toast("Please wait…", "info"); return; }
      _musicGenBusy = true; pvStopTrack();
      try {
        const r = await api.musicReroll(PROJECT, g.index);       // swaps to a different LIBRARY track (no generation)
        if (r.error) { toastErr(r.error); return; }
        await refreshPreviewMusic();
        toast(`🎵 ${g.emotion} changed`, "ok");
      } catch (e) { toastErr("Reroll failed: " + e); }
      finally { _musicGenBusy = false; }
    });
    sel.addEventListener("change", async () => {
      pvStopTrack();
      const r = await api.musicOverride(PROJECT, g.index, sel.value);
      if (r.error) { alert(r.error); return; }
      g.track = sel.value; g.url = r.url; if (r.level != null) g.level = r.level;
      pvMusicEls().forEach(el => { if (el.dataset.src && el.dataset.src !== g.url) { el.removeAttribute("data-src"); } });
      pvRender($("#pvVo").currentTime || 0);        // pick up the new track now (mix reloads it)
    });
    row.append(info, sel, play, rer);
    box.appendChild(row);
  });
}

// ---------- global subtitle style (Assemble: styles every SRT caption at once) ----------
const SUB_STYLE_DEFAULTS = {
  ost_font: "Arial", ost_size: 46, ost_weight: "400", ost_color: "#ffffff", ost_fill: true,
  ost_bold: false, ost_italic: false, ost_upper: false, ost_underline: false,
  ost_letter: 0, ost_leading: 1.15,
  ost_place: "bottom", ost_x: 0, ost_y: 0, ost_rotation: 0,
  ost_stroke: false, ost_stroke_w: 0, ost_stroke_color: "#000000",
  ost_bg: true, ost_bg_color: "#000000", ost_bg_opacity: 62, ost_bg_pad: 14, ost_bg_radius: 10,
  ost_shadow: false, ost_shadow_color: "#000000", ost_shadow_opacity: 80, ost_shadow_size: 6, ost_shadow_dir: 135,
  ost_anim: "fade", ost_out_anim: "none",
  sub_width: 86, sub_lines: "auto",
};
function subStyle() {
  if (!DOC) return { ...SUB_STYLE_DEFAULTS };
  if (!DOC.subtitle_style || typeof DOC.subtitle_style !== "object") DOC.subtitle_style = {};
  const st = DOC.subtitle_style;
  for (const k in SUB_STYLE_DEFAULTS) if (st[k] === undefined) st[k] = SUB_STYLE_DEFAULTS[k];
  return st;
}
// balanced, width-aware wrap — mirrors _sub_wrap_lines() in render_video.py so preview == render.
function wrapSubLines(text, st) {
  text = String(text || "").replace(/\s+/g, " ").trim();
  if (!text) return [];
  const width = Math.max(20, Math.min(100, +st.sub_width || 86));
  const size = Math.max(1, +st.ost_size || 46);
  const mode = String(st.sub_lines || "auto");
  const cpl = Math.max(6, Math.floor(1920 * width / 100 / (0.5 * size)));   // ~chars per line at this width+size
  const words = text.split(" ");
  const greedy = (cap) => {
    const lines = []; let cur = "";
    for (const w of words) {
      if (cur && cur.length + 1 + w.length > cap) { lines.push(cur); cur = w; }
      else cur = cur ? cur + " " + w : w;
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : [text];
  };
  const balance = (n) => {
    if (n <= 1 || words.length < 2) return [text];
    const target = text.length / n;
    const lines = []; let cur = [];
    words.forEach((w, idx) => {
      cur.push(w);
      const curLen = cur.join(" ").length;
      const wordsLeft = words.length - idx - 1, linesLeft = n - lines.length - 1;
      if (lines.length < n - 1 && curLen >= target && wordsLeft >= linesLeft) { lines.push(cur.join(" ")); cur = []; }
    });
    if (cur.length) lines.push(cur.join(" "));
    return lines;
  };
  if (mode === "1") return [text];                 // force ONE line — never wrap (box hugs it, grows with the font)
  if (mode === "2") return text.length <= cpl ? [text] : balance(2);
  if (text.length <= cpl) return [text];
  return greedy(cpl);                              // auto = fill each line up to the "Line" width (reaches the edges)
}
// position + paint a caption. posEl carries the placement transform; styleEl carries the look. For the
// live caption they're the same element; for the mini-preview the wrap positions and the inner paints
// (so an entrance animation's transform on the inner doesn't fight the centring transform).
function styleCaption(styleEl, posEl, w, stOverride) {
  if (!styleEl || !posEl) return;
  const st = stOverride || subStyle(), scale = (w || 640) / 1920;
  ostTextStyle(styleEl, ostOpts(st), scale);            // font / size / colour / stroke / bg / shadow
  styleEl.style.textAlign = "center";
  const oneLine = String(st.sub_lines || "auto") === "1";
  // "1 line" = never wrap: the whole caption stays on ONE line, the box hugs it and grows with the font
  // (so a big-enough font reaches both edges). Otherwise honour our \n breaks and wrap at "Line" width.
  styleEl.style.whiteSpace = oneLine ? "nowrap" : "pre-line";
  // The box HUGS the text with even padding on all sides and grows/shrinks with the font size.
  // "Line" (sub_width) only caps how wide the text may spread before it wraps — it does NOT set the box
  // width. In 1-line mode there's no wrap, so no max-width either (the single line can span the frame).
  posEl.style.textAlign = "center";
  // give the box an EXPLICIT width (= the "Line" %) so text fills edge-to-edge; width:auto + left:50%
  // was shrink-to-fit-capped at ~50% of the frame (an absolute box can only use the space right of left:50%).
  posEl.style.width = oneLine ? "auto" : ((st.sub_width || 86) + "%");
  posEl.style.maxWidth = "none";
  styleEl.style.display = "inline-block";
  // The BACKGROUND hugs each caption's own text: the inner (bg carrier) shrink-wraps to its content
  // (width:auto) and centres inside the sub_width%% wrapper, so a short line gets a short plate and a long
  // line grows up to the "Line" width. (Was width:100%, which pinned the bg to a fixed sub_width%% bar.)
  if (styleEl !== posEl) { styleEl.style.width = "auto"; styleEl.style.maxWidth = "100%"; }
  const place = st.ost_place || "bottom";
  const tx = ((st.ost_x || 0) * scale).toFixed(1), ty = ((st.ost_y || 0) * scale).toFixed(1);
  const rot = st.ost_rotation ? ` rotate(${st.ost_rotation}deg)` : "";
  posEl.style.left = "50%"; posEl.style.right = "auto";
  if (place === "top") { posEl.style.top = "14%"; posEl.style.bottom = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), ${ty}px)${rot}`; }
  else if (place === "center") { posEl.style.top = "50%"; posEl.style.bottom = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px))${rot}`; }
  else { posEl.style.bottom = "4.5%"; posEl.style.top = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), ${ty}px)${rot}`; }
}
function applyPvCaptionStyle() {
  const el = $("#pvCaption"); if (!el) return;
  const inner = el.querySelector(".pv-cap-inner") || el;   // inner carries the look; outer positions
  const stage = $("#pvStage");
  styleCaption(inner, el, (stage && stage.clientWidth) || 640);
  el.style.display = PV.capRaw ? "" : "none";              // styling must never reveal an empty box
}
// set the live caption text, wrapped per the current subtitle style (stores the raw text for re-wrap on style change)
function pvSetCaptionText(text) {
  const el = $("#pvCaption"); if (!el) return;
  const inner = el.querySelector(".pv-cap-inner") || el;
  const had = PV.capRaw;
  PV.capRaw = text || "";
  const wrapped = text ? wrapSubLines(text, subStyle()).join("\n") : "";
  inner.textContent = wrapped;
  el.style.display = wrapped ? "" : "none";             // never leave an empty styled box on-screen
  if (wrapped && text !== had) {                        // play the chosen entrance animation (matches the render)
    const anim = subStyle().ost_anim || "fade";
    [...inner.classList].filter(c => c.startsWith("pv-ost")).forEach(c => inner.classList.remove(c));
    if (anim !== "none") { void inner.offsetWidth; inner.classList.add("pv-ost-" + anim); }
  }
}
// ---- mini subtitle preview (bottom half of a fixed frame + a sample subtitle) ----
function subMiniFrameSrc() {
  const scs = (PV.m && PV.m.scenes) || [];
  const f = scs.find(s => s.img || (s.type === "image" && s.url));
  return f ? (f.img || f.url) : null;
}
function subMiniSampleText() {
  const caps = (PV.m && PV.m.captions) || [];
  if (!caps.length) return "This is a sample subtitle line to preview your style";
  // a representative, medium-length caption so wrapping/width read realistically
  const sorted = caps.map(c => c.text || "").filter(Boolean).sort((a, b) => a.length - b.length);
  return sorted[Math.floor(sorted.length / 2)] || sorted[0] || "Sample subtitle";
}
function renderSubMini() {
  const mini = $("#pvSubMini"); if (!mini || mini.hidden) return;
  const img = mini.querySelector(".psm-img"), inner = mini.querySelector(".psm-inner");
  const wrap = mini.querySelector(".psm-cap-wrap"), cap = mini.querySelector(".psm-cap");
  const src = subMiniFrameSrc();
  if (src && img.getAttribute("src") !== src) img.src = src;
  img.style.visibility = src ? "visible" : "hidden";
  cap.textContent = wrapSubLines(subMiniSampleText(), subStyle()).join("\n");
  styleCaption(cap, wrap, (inner && inner.clientWidth) || mini.clientWidth || 640);
}
// replay the chosen in/out animation once on the mini caption (so picking one shows what it does)
function playSubAnim(kind) {
  const cap = $("#pvSubMini .psm-cap"); if (!cap) return;
  const st = subStyle();
  const name = kind === "out" ? (st.ost_out_anim || "none") : (st.ost_anim || "fade");
  [...cap.classList].filter(c => c.startsWith("pv-ost")).forEach(c => cap.classList.remove(c));
  if (name === "none") return;
  const cls = kind === "out" ? ("pv-ost-out-" + name) : ("pv-ost-" + name);
  void cap.offsetWidth;                                  // reflow → restart the animation
  cap.classList.add(cls);
  cap.addEventListener("animationend", () => cap.classList.remove(cls), { once: true });
}
function buildSubStylePanel() {
  const box = $("#pvSubPanel"), head = $("#pvSubHead"), mini = $("#pvSubMini"), tpl = $("#subStyleTpl");
  if (!box || !tpl || !DOC) return;
  const hasCaps = !!(PV.m && PV.m.captions && PV.m.captions.length);
  if (head) head.hidden = !hasCaps;
  if (mini) mini.hidden = !hasCaps;
  box.hidden = !hasCaps;
  box.innerHTML = "";
  if (!hasCaps) return;
  const panel = tpl.content.firstElementChild.cloneNode(true);
  box.appendChild(panel);
  const st = subStyle();
  const redraw = () => { applyPvCaptionStyle(); pvSetCaptionText(PV.capRaw || ""); renderSubMini(); queueSave(); };
  wireOstPanel(panel, st, redraw, buildSubStylePanel, "subtitle");   // subtitle-scoped presets (kept separate from on-screen)
  // Size is a slider here (font size), Width is a numeric % (the left/right narrowing)
  const sInp = panel.querySelector(".sub-size"), sV = panel.querySelector(".sub-size-v");
  if (sInp) {
    sInp.value = st.ost_size != null ? st.ost_size : 46;
    const showS = () => { if (sV) sV.textContent = sInp.value; };
    showS();
    sInp.addEventListener("input", () => { st.ost_size = clampNum(sInp.value, 12, 400, 46); showS(); redraw(); });
  }
  const wInp = panel.querySelector(".sub-width-num");
  if (wInp) {
    wInp.value = st.sub_width != null ? st.sub_width : 86;
    wInp.addEventListener("input", () => { st.sub_width = clampNum(wInp.value, 30, 100, 86); redraw(); });
  }
  panel.querySelectorAll(".sub-line-btn").forEach(b => {
    b.classList.toggle("on", b.dataset.lines === String(st.sub_lines || "auto"));
    b.addEventListener("click", () => {
      st.sub_lines = b.dataset.lines;
      panel.querySelectorAll(".sub-line-btn").forEach(x => x.classList.toggle("on", x === b));
      redraw();
    });
  });
  // preview the animation once whenever it's picked
  const aIn = panel.querySelector(".ost-anim"), aOut = panel.querySelector(".ost-out-anim");
  if (aIn) aIn.addEventListener("change", () => playSubAnim("in"));
  if (aOut) aOut.addEventListener("change", () => playSubAnim("out"));
  // reset every subtitle setting back to the original default look
  const resetBtn = panel.querySelector(".sub-reset");
  if (resetBtn) resetBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!(await confirmDialog("Reset the subtitle style back to the default?", { title: "Reset Subtitles", okText: "Reset", danger: false }))) return;
    DOC.subtitle_style = { ...SUB_STYLE_DEFAULTS };
    buildSubStylePanel();                                  // rebuild controls from the defaults
    applyPvCaptionStyle(); pvSetCaptionText(PV.capRaw || ""); renderSubMini();
    queueSave();
    toast("Subtitle style reset to default", "ok");
  });
  applyPvCaptionStyle();
  renderSubMini();
}

// media a scene shows in the preview, resolved from the CURRENT doc (approved video else image else blank)
function pvSceneMedia(s) {
  const v = s.video || {};
  if (v.approved && v.status === "ready" && v.file) return { type: "video", url: `/media/${PROJECT}/${v.file}` };
  const f = s.approved ? (s.image.approved_file || s.image.file) : null;
  if (f) return { type: "image", url: `/media/${PROJECT}/${f}` };
  return { type: "blank", url: null };
}
// live-refresh preview media from the doc (e.g. after re-approving a scene) — no rebuild needed
function pvSyncFromDoc() {
  if (!PV.m || !DOC) return;
  let changed = false;
  PV.m.scenes.forEach(ps => {
    const s = (DOC.scenes || []).find(x => x.id === ps.id); if (!s) return;
    const md = pvSceneMedia(s);
    if (md.type !== ps.type || md.url !== ps.url) { ps.type = md.type; ps.url = md.url; changed = true; }
    const texts = sceneTL(s);   // pick up on-screen-text edits made since the preview was built
    if (JSON.stringify(texts) !== JSON.stringify(ps.texts || [])) { ps.texts = texts; changed = true; }
    if ((s.transition || "none") !== ps.transition) { ps.transition = s.transition || "none"; changed = true; }
  });
  if (changed) { PV.scene = -1; [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) v._pvSrc = ""; }); pvRender($("#pvVo").currentTime || 0); }
  pvBuildTextTrack();   // reflect text add/remove/edit in the timing track
}
// Re-draw the paused frame where we left off. A <video> decoded while its tab was hidden
// (display:none) shows BLACK until nudged, so on returning to Assemble we re-resolve the
// current scene and give the video a hair of a seek to force it to paint that frame.
// A paused <video> that was decoded while its tab was hidden stays BLACK until it paints.
// A muted play()→pause() forces it to decode & paint the current frame (the video element is
// always muted, so this needs no user gesture) — showing the exact paused frame, not black.
// At rest on a video scene, show its approved still image (sc.img) instead of the <video>.
// A <video> can show BLACK at rest — it was decoded while its tab was hidden, or a scene
// change is still (re)loading it — whereas the still image always paints. Pressing play
// switches back to the moving video (see pvPlay).
function pvStillIfPaused() {
  const sc = PV.m && PV.m.scenes[PV.scene];
  if (sc && sc.type === "video" && sc.img && !PV.imagesOnly && $("#pvVo").paused) {
    const img = $("#pvImage");
    [$("#pvVideo"), $("#pvVideo2")].forEach(v => { try { v.pause(); } catch (_) {} v.hidden = true; });
    if (img.getAttribute("src") !== sc.img) img.src = sc.img;
    img.hidden = false;
  }
}
function pvRepaint() {
  if (!PV.m) return;
  PV.scene = -1;                                   // force the current scene's media to re-resolve
  pvRender($("#pvVo").currentTime || 0);
  pvStillIfPaused();                               // show a frame, not black
}

// on-screen text overlays for the current scene: each styled + animated, scaled from 1080p to the stage
function pvSetOverlay(sc) {
  const layer = $("#pvOstWrap"); if (!layer) return;
  layer.innerHTML = ""; PV.ostEls = [];
  const withText = (((sc && sc.texts) || []).filter(o => (o.text || "").trim()));
  if (!withText.length) { layer.hidden = true; return; }
  layer.hidden = false;
  const stageW = $("#pvStage").clientWidth || 640, scale = stageW / 1920;
  const dur = Math.max(0.001, sc.end - sc.start);
  const cf = (v, d) => { const f = parseFloat(v); return isFinite(f) ? Math.min(1, Math.max(0, f)) : d; };
  withText.forEach(o => {
    const wrap = document.createElement("div"); wrap.className = "pv-ost-wrap place-" + (o.text_place || "top");
    const inner = document.createElement("div"); inner.className = "pv-ost";
    wrap.appendChild(inner); layer.appendChild(wrap);
    ostWrapPos(wrap, o.text_place || "top", o.text_x, o.text_y, scale, o.text_rotation);
    inner.textContent = (o.text || "").trim();
    ostTextStyle(inner, ostOptsTL(o), scale);
    wrap.style.display = "none";                           // shown only during its window (pvOstTick)
    PV.ostEls.push({ wrap, inner,
      start: sc.start + dur * cf(o.text_in, 0), end: sc.start + dur * cf(o.text_out, 1),
      inAnim: "pv-ost-" + (o.text_anim || "fade"),
      out: (o.text_out_anim && o.text_out_anim !== "none") ? o.text_out_anim : null, state: "idle" });
  });
}
// Draw the current scene's overlay icons over the preview video — a STATIC preview of where each icon will
// sit (and its colour) in the XML export. (Full pop/jab/ring animation lives only in the Premiere export.)
const _PV_ICON_BASE = { x: 0.24, arrow: 0.27, burst: 0.34, check: 0.27, sparkle: 0.22 };
const _PV_ICON_SRC = { x: "icon_x_t.png", arrow: "icon_arrow_t.png", burst: "icon_ring_t.png", check: "icon_check_t.png",
  sparkle: "icon_sparkle_t.png" };
Object.keys(_VFX).forEach(k => { _PV_ICON_BASE[k] = _VFX[k].art.aw / _VFX[k].art.fw; _PV_ICON_SRC[k] = "icon_" + k + "_t.png"; });
// SVG filter for a black-background video/thumbnail EFFECT: FORCE the colour to a tint and set ALPHA from LUMA.
// Forcing the colour (not just keying) means the anti-aliased edge fades tint->transparent instead of leaving a
// dark GREY halo (that was the "thin black stroke"). hue 0 / none => WHITE (the clip's native colour). Any other
// palette hue => that colour. One filter per hue, cached by id. Returns the filter id to use in `filter:url(#id)`.
function _movfxTint(hue) {
  const p = _ICON_PALETTE.find(e => e[1] === (hue || 0));       // hue 0 -> Red; 900 -> White; 901 -> Charcoal
  if (p) { const m = p[2].match(/[0-9a-f]{2}/gi); if (m) return [parseInt(m[0], 16) / 255, parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255]; }
  return [1, 1, 1];
}
function movfxFilterId(hue) {
  hue = hue || 0;
  const id = "movfxKey_" + hue;
  if (document.getElementById(id)) return id;
  const [r, g, b] = _movfxTint(hue);
  const NS = "http://www.w3.org/2000/svg";
  let host = document.getElementById("movfxFilters");
  if (!host) {
    host = document.createElementNS(NS, "svg"); host.id = "movfxFilters";
    host.setAttribute("width", "0"); host.setAttribute("height", "0");
    host.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";
    document.body.appendChild(host);
  }
  const f = document.createElementNS(NS, "filter");
  f.setAttribute("id", id); f.setAttribute("color-interpolation-filters", "sRGB");
  f.setAttribute("x", "0"); f.setAttribute("y", "0"); f.setAttribute("width", "100%"); f.setAttribute("height", "100%");
  const m = document.createElementNS(NS, "feColorMatrix"); m.setAttribute("type", "matrix");
  m.setAttribute("values", `0 0 0 0 ${r}  0 0 0 0 ${g}  0 0 0 0 ${b}  0.6 0.6 0.6 0 0`);   // RGB=tint, A=0.6*(R+G+B)
  f.appendChild(m); host.appendChild(f);
  return id;
}
// Live-refresh the Assemble preview's overlay icons when you add/move/delete an icon on a scene card — no need
// to rebuild the preview. Pulls the fresh icons from DOC into the built timeline and redraws the current scene.
function pvSyncIcons() {
  if (!PV.m || !PV.m.scenes || PV.scene < 0) return;
  PV.m.scenes.forEach(psc => { const d = (DOC.scenes || []).find(x => x.id === psc.id); if (d) psc.icons = d.icons ? JSON.parse(JSON.stringify(d.icons)) : []; });
  const cur = PV.m.scenes[PV.scene]; if (cur) pvSetIcons(cur);
}
function pvSetIcons(sc) {
  const stage = $("#pvStage"); if (!stage) return;
  let layer = $("#pvIconWrap");
  if (!layer) { layer = document.createElement("div"); layer.id = "pvIconWrap"; layer.className = "pv-icon-layer"; stage.appendChild(layer); }
  layer.innerHTML = ""; PV.iconEls = []; PV.fxVideos = [];
  const icons = ((sc && sc.icons) || []).filter(ic => ic && ic.type);
  if (!icons.length) { layer.hidden = true; return; }
  layer.hidden = false;
  const w = stage.clientWidth || 1, dur = Math.max(0.001, sc.end - sc.start);
  icons.forEach(ic => {
    const node = document.createElement("div"); node.className = "pv-ov-icon";
    node.style.left = (ic.x * 100) + "%"; node.style.top = (ic.y * 100) + "%";
    node.style.transform = `translate(-50%,-50%) rotate(${ic.rot || 0}deg)`;
    const inF = +ic.in || 0, outF = (ic.out != null ? +ic.out : 1);
    const timed = inF > 0.001 || outF < 0.999;
    const win = { timed, start: sc.start + dur * inF, end: sc.start + dur * outF };
    if (ic.type === "burst") {
      // PAIN POINT = radiating rings, matched to the Premiere ripple: the native ring is 632/1920 = 0.329 of the
      // frame (== Basic-Motion Scale 100); each CSS wave then grows scale .45 -> 1.70 (XML s0=45%, s1=170%),
      // fading, with a fresh wave every ~0.95s. Two ring elements offset by half the life = a wave every 0.95s.
      const bw = w * 0.329 * (ic.size || 1);
      node.style.width = bw + "px"; node.style.height = bw + "px";
      for (let k = 0; k < 2; k++) {
        const img = document.createElement("img"); img.draggable = false;
        img.src = "/icons/icon_ring_t.png" + (ic.hue ? "?h=" + ic.hue : "");
        img.className = "pv-ic-radiate" + (k ? " pv-ic-r2" : "");
        node.appendChild(img);
      }
      layer.appendChild(node);
      PV.iconEls.push({ node, anim: "radiate", played: false, ...win });
      return;
    }
    if (_PLAIN_PREVIEW.has(ic.type)) {   // question mark etc.: a simple recolourable glyph (the real clip runs in render/XML)
      const bw = w * (_PV_ICON_BASE[ic.type] || _ICON_BASE[ic.type] || 0.34) * (ic.size || 1);
      node.style.width = bw + "px"; node.style.height = bw + "px";
      const g = document.createElement("div"); g.className = "pv-ic-glyph"; g.textContent = _PLAIN_GLYPH[ic.type] || "?";
      g.style.color = _hueToCss(ic.hue); g.style.fontSize = (bw * 1.1) + "px";
      node.appendChild(g); layer.appendChild(node);
      PV.iconEls.push({ node, img: g, anim: "pop", played: false, ...win });
      return;
    }
    if (_MOV_FX.has(ic.type)) {
      // VIDEO effect overlay (e.g. hand-drawn arrow) on a BLACK background: an SVG luma->alpha filter keys the
      // black to TRANSPARENT + tints to the chosen colour (mix-blend-mode is unreliable on <video>). The node is
      // sized to the ART's bbox (not the whole video frame) so the selection box hugs the arrow; the video is
      // scaled up inside and centred so the (centred) art fills the node, with the overflow clipped.
      const art = _MOV_ART[ic.type] || { aw: 1, ah: 1, fw: 1, fh: 1 };
      const nodeW = w * (_PV_ICON_BASE[ic.type] || 0.28) * (ic.size || 1);   // base already = the art's frame fraction
      const nodeH = nodeW * (art.ah / art.aw);
      node.className = "pv-ov-icon pv-movfx";
      node.style.width = nodeW + "px"; node.style.height = nodeH + "px"; node.style.overflow = "hidden";
      const _mode = _MOV_MODE(ic.type);
      const vid = document.createElement("video");
      vid.src = "/icons/" + _MOV_SRC[ic.type]; vid.muted = true; vid.loop = (_mode === "loop");
      vid.autoplay = true; vid.setAttribute("playsinline", ""); vid.setAttribute("muted", "");
      const flt = _MOV_BLEND(ic.type) === "key" ? ("filter:url(#" + movfxFilterId(ic.hue) + ");") : "";   // key = luma->alpha + tint; alpha clip = real alpha, no filter
      const vw = nodeW * art.fw / art.aw, vh = nodeW * art.fh / art.aw;   // full frame scaled so the ART fills the node; shift by the art-centre offset so it's centred (not clipped)
      const oxp = -(art.acx || 0) * vw, oyp = -(art.acy || 0) * vh;
      vid.style.cssText = "position:absolute;left:50%;top:50%;width:" + vw + "px;height:" + vh +
        "px;transform:translate(calc(-50% + " + oxp + "px),calc(-50% + " + oyp + "px));" + flt + "display:block;pointer-events:none;";
      vid.addEventListener("loadedmetadata", () => {   // "once": play at native, only SPEED UP if the scene is shorter (so it completes), then FREEZE the last frame. "loop": native, repeats.
        try { vid.playbackRate = _mode === "loop" ? 1 : Math.min(4, Math.max(1, (vid.duration || 5) / dur)); } catch (e) {} });
      node.appendChild(vid); layer.appendChild(node);
      try { vid.play().catch(() => {}); } catch (e) {}
      PV.fxVideos.push(vid);
      PV.iconEls.push({ node, anim: "movfx", played: false, ...win });
      return;
    }
    if (_FX_KINDS.has(ic.type)) {
      // new EFFECTS: glow/spot/sweep = one screen-blended element; sparkle/cleanse = several staggered copies.
      const bw = w * (_PV_ICON_BASE[ic.type] || 0.3) * (ic.size || 1);
      node.style.width = bw + "px"; node.style.height = bw + "px";
      const src = "/icons/" + _PV_ICON_SRC[ic.type] + (ic.hue ? "?h=" + ic.hue : "");
      const mk = (cls, style) => {
        const img = document.createElement("img"); img.draggable = false; img.src = src;
        img.className = "pv-fx " + cls; if (style) img.setAttribute("style", style);
        node.appendChild(img);
      };
      if (ic.type === "glow") mk("pv-fx-glow");
      else if (ic.type === "spot") mk("pv-fx-spot");
      else if (ic.type === "sweep") mk("pv-fx-sweep");
      else if (ic.type === "sparkle")
        [[50, 50, 55], [22, 30, 42], [76, 28, 40], [30, 74, 38], [74, 70, 44]].forEach((o, i) =>
          mk("pv-fx-twinkle", `position:absolute;left:${o[0]}%;top:${o[1]}%;width:${o[2]}%;height:${o[2]}%;transform:translate(-50%,-50%);animation-delay:${(i * 0.32).toFixed(2)}s`));
      else if (ic.type === "cleanse")
        [18, 40, 60, 82, 50].forEach((cx, i) =>
          mk("pv-fx-rise", `position:absolute;left:${cx}%;bottom:-10%;width:40%;height:40%;transform:translateX(-50%);animation-delay:${(i * 0.5).toFixed(2)}s`));
      layer.appendChild(node);
      PV.iconEls.push({ node, anim: "fxloop", played: false, ...win });
      return;
    }
    const img = document.createElement("img"); img.draggable = false;
    const nm = ic.type === "arrow" ? (ic.flip ? "icon_arrow_flip_t.png" : "icon_arrow_t.png") : (_PV_ICON_SRC[ic.type] || _PV_ICON_SRC.x);
    img.src = "/icons/" + nm + (ic.hue ? "?h=" + ic.hue : "");
    node.appendChild(img);
    const bw = w * (_PV_ICON_BASE[ic.type] || 0.26) * (ic.size || 1);
    node.style.width = bw + "px"; node.style.height = bw + "px";
    if (ic.type === "arrow") img.classList.add(ic.flip ? "pv-ic-jabloop-l" : "pv-ic-jabloop");   // continuous jab, like the XML
    layer.appendChild(node);
    // X/check POP once on entry; arrow JABS continuously (handled by the class above, skipped in pvIconTick)
    const anim = ic.type === "arrow" ? "jabloop" : "pop";
    PV.iconEls.push({ node, img, anim, played: false, ...win });
  });
  pvHoldAnims($("#pvVo") && $("#pvVo").paused);   // if built while paused, freeze the looping rings immediately
}
// freeze / resume the continuously-looping preview icon animations (pain rings) with the video's play state
function pvHoldAnims(paused) {
  const pw = $("#previewWrap"); if (pw) pw.classList.toggle("pv-anim-hold", !!paused);
  (PV.fxVideos || []).forEach(v => { try { paused ? v.pause() : v.play().catch(() => {}); } catch (e) {} });   // video effects follow play/pause
}
// per-frame: window each TIMED icon on/off; fire the one-shot entry animation (pop/jab) the moment an icon
// appears, and re-arm it if the user scrubs back before it (untimed icons stay visible but still pop on entry).
function pvIconTick(t) {
  (PV.iconEls || []).forEach(e => {
    const vis = e.timed ? (t >= e.start && t < e.end) : true;
    e.node.style.display = vis ? "" : "none";
    if (e.anim === "radiate" || e.anim === "jabloop" || e.anim === "fxloop" || e.anim === "movfx") return;  // self-animate (no one-shot trigger)
    if (vis && !e.played) {
      e.played = true;
      e.img.classList.remove("pv-ic-pop", "pv-ic-jab", "pv-ic-jab-l"); void e.img.offsetWidth;
      e.img.classList.add(e.anim === "jab-l" ? "pv-ic-jab-l" : (e.anim === "jab" ? "pv-ic-jab" : "pv-ic-pop"));
    } else if (!vis && e.played) {                             // scrubbed out → let it replay on re-entry
      e.played = false;
      e.img.classList.remove("pv-ic-pop", "pv-ic-jab", "pv-ic-jab-l");
    }
  });
}
// per-frame: reveal each overlay only inside its [start,end] window, playing in/out at the edges
function pvOstTick(t) {
  (PV.ostEls || []).forEach(e => {
    if (t >= e.start && t < e.end) {
      if (e.state === "idle") { e.wrap.style.display = ""; void e.inner.offsetWidth; e.inner.className = "pv-ost " + e.inAnim; e.state = "in"; }
      if (e.state === "in" && e.out && (e.end - t) <= 0.42) { e.inner.className = "pv-ost pv-ost-out-" + e.out; e.state = "out"; }
    } else if (e.state !== "idle") { e.wrap.style.display = "none"; e.state = "idle"; }
  });
}
// ---------- on-screen-text timeline track (Assemble): one draggable bar per text ----------
function pvTtSetOpen(open, animate) {
  const wrap = $("#pvTextWrap"), tog = $("#pvTextToggle"), pw = $("#previewWrap");
  if (!wrap) return;
  PV.ttOpen = open;
  if (tog) tog.classList.toggle("on", open);
  clearTimeout(wrap._t);
  // measure the natural open height and publish it as --pv-tt-h → in fullscreen the play buttons +
  // progress bar are lifted by exactly this much (animated) so the text bar slides in beneath them
  // WITHOUT ever resizing the video.
  const _pt = wrap.style.transition, _ph = wrap.style.height;
  wrap.style.transition = "none"; wrap.style.height = "auto";
  const openH = wrap.offsetHeight;
  wrap.style.height = _ph; void wrap.offsetHeight; wrap.style.transition = _pt;
  if (pw) pw.style.setProperty("--pv-tt-h", (open ? openH : 0) + "px");
  if (!animate) { wrap.style.transition = "none"; wrap.style.height = open ? "auto" : "0px"; void wrap.offsetHeight; wrap.style.transition = ""; return; }
  const from = Math.round(wrap.getBoundingClientRect().height);
  const to = open ? openH : 0;                             // natural (open) height, incl. the track margin
  wrap.style.transition = "none"; wrap.style.height = from + "px"; void wrap.offsetHeight; wrap.style.transition = "";
  wrap.style.height = to + "px";
  wrap._t = setTimeout(() => {                            // force the end state (some embedded webviews stall transitions)
    wrap.style.transition = "none"; wrap.style.height = PV.ttOpen ? "auto" : "0px"; void wrap.offsetHeight; wrap.style.transition = "";
  }, 340);
}
function pvTtSetZoom(z) {
  PV.ttZoom = Math.max(1, Math.min(12, z || 1));
  pvBuildTextTrack();
}
function pvBuildTextTrack() {
  const track = $("#pvTextTrack"), tog = $("#pvTextToggle"), content = $("#pvTtContent"); if (!track || !content || !PV.m) return;
  if (PV.ttZoom == null) PV.ttZoom = 1;
  if (!content._seekBound) {                               // click/drag empty area → seek there (+ leave red edit mode)
    content.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".pv-tt-bar")) return;          // clicking a bar selects/drags it, not seek
      if (e.button != null && e.button !== 0) return;      // left button only
      content.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
      pvTtHeadDrag(e);                                      // jump the playhead here + allow drag; stays in sync with the progress bar
    });
    content._seekBound = true;
  }
  const ttScroll = $("#pvTtScroll");
  if (ttScroll && !ttScroll._syncBound) {                  // pan the progress bar in lock-step with the text track when zoomed
    ttScroll.addEventListener("scroll", () => { const row = $("#pvBarRow"); if (row && (PV.ttZoom || 1) > 1) row.scrollLeft = ttScroll.scrollLeft; });
    ttScroll._syncBound = true;
  }
  content.innerHTML = "";
  const dur = PV.m.duration || 1, bars = [];
  (PV.m.scenes || []).forEach(ps => {
    const s = (DOC.scenes || []).find(x => x.id === ps.id);
    if (!s) return;
    const sceneDur = Math.max(0.001, ps.end - ps.start);
    if (s.ost_on) (s.overlays || []).forEach(ov => {
      if (!(ov.onscreen || "").trim()) return;
      bars.push({ kind: "text", ov, sceneId: ps.id, sceneStart: ps.start, sceneEnd: ps.end, sceneDur, txt: ov.onscreen.trim() });
    });
    (s.icons || []).forEach((ic, k) => {       // each on-screen ICON gets its own timing bar on a separate row
      if (!ic || !ic.type) return;
      bars.push({ kind: "icon", ic, sceneId: ps.id, sceneStart: ps.start, sceneEnd: ps.end, sceneDur, txt: (ic.type === "burst" ? "pain" : ic.type) + " " + (k + 1) });
    });
  });
  if (PV.ttOpen == null) PV.ttOpen = true;                 // open by default when texts exist
  if (!bars.length) { track.hidden = true; if (tog) tog.style.display = "none"; pvTtSetOpen(false, false); return; }
  track.hidden = false; if (tog) tog.style.display = "";
  const rowEnds = [];                                       // pack overlapping bars onto separate rows
  bars.forEach(b => {
    const inF = b.kind === "icon" ? (+b.ic.in || 0) : (+b.ov.ost_in || 0);
    const outF = b.kind === "icon" ? (b.ic.out != null ? +b.ic.out : 1) : (b.ov.ost_out != null ? +b.ov.ost_out : 1);
    b.absStart = b.sceneStart + b.sceneDur * inF;
    b.absEnd = b.sceneStart + b.sceneDur * outF;
    let r = rowEnds.findIndex(end => b.absStart >= end - 0.01);
    if (r < 0) { r = rowEnds.length; rowEnds.push(0); }
    rowEnds[r] = b.absEnd; b.row = r;
  });
  content.style.width = (PV.ttZoom * 100) + "%";           // zoom widens the timeline; the scroll area pans
  content.style.height = (rowEnds.length * 26 + 8) + "px";
  bars.forEach(b => content.appendChild(pvTextBar(b, dur)));
  const ph = document.createElement("div"); ph.className = "pv-tt-head"; content.appendChild(ph);
  ph.addEventListener("pointerdown", pvTtHeadDrag);       // drag the orange playhead to scrub (stays in sync with the progress bar)
  const zo = $("#pvTtZoomOut"), zi = $("#pvTtZoomIn");
  if (zo) zo.disabled = PV.ttZoom <= 1; if (zi) zi.disabled = PV.ttZoom >= 12;
  pvTextTrackHead($("#pvVo") ? ($("#pvVo").currentTime || 0) : 0);
  pvTtSetOpen(PV.ttOpen, false);                           // apply the open/closed state (no animation on rebuild)
  pvSyncBar();                                             // widen + pan the progress bar to match the text-track zoom
}
// mirror the text-track's zoom width + scroll onto the progress bar so the yellow playhead and the round handle stay aligned
function pvSyncBar() {
  const bar = $("#pvBar"), row = $("#pvBarRow"), tt = $("#pvTtScroll"), content = $("#pvTtContent");
  if (!bar || !row) return;
  const z = PV.ttZoom || 1;
  if (z > 1 && content) {
    // match the progress bar to the EXACT pixel width of the zoomed text-track content (not "%") so the
    // round handle and the orange playhead sit at the identical x at every time — no zoom-amplified drift.
    bar.style.flex = "none"; bar.style.width = content.offsetWidth + "px";
    row.style.overflowX = "hidden";                        // scroll is driven programmatically, mirrored from the text track
    if (tt) row.scrollLeft = tt.scrollLeft;
  } else {
    bar.style.flex = ""; bar.style.width = ""; row.style.overflowX = ""; row.scrollLeft = 0;
  }
}
function pvTextTrackHead(t) {
  const content = $("#pvTtContent"), ph = content && content.querySelector(".pv-tt-head");
  if (!ph || !PV.m) return;
  const frac = t / (PV.m.duration || 1);
  ph.style.left = (frac * 100) + "%";
  const scroll = $("#pvTtScroll");
  if (scroll && (PV.ttZoom || 1) > 1) {                    // keep the playhead in view when zoomed in
    const cw = content.offsetWidth, vw = scroll.clientWidth, x = frac * cw, sl = scroll.scrollLeft;
    if (x < sl + vw * 0.1 || x > sl + vw * 0.9) scroll.scrollLeft = Math.max(0, Math.min(cw - vw, x - vw * 0.5));
    const row = $("#pvBarRow"); if (row) row.scrollLeft = scroll.scrollLeft;   // progress bar pans in lockstep
  }
}
// drag the text-track's orange playhead to scrub; maps the cursor onto the (possibly zoomed) timeline
function pvTtHeadDrag(e) {
  if (!PV.m) return;
  e.preventDefault(); e.stopPropagation();
  const content = $("#pvTtContent"); if (!content) return;
  const wasPlaying = !$("#pvVo").paused; if (wasPlaying) pvPause();
  const seek = (ev) => {
    const r = content.getBoundingClientRect();
    const frac = Math.min(1, Math.max(0, (ev.clientX - r.left) / (r.width || 1)));
    const t = frac * PV.m.duration;
    PV.seg = -1; PV.cap = -1;
    try { $("#pvVo").currentTime = t; } catch (_) {}
    pvRender(t);                                            // moves both the orange playhead and the progress-bar circle
    pvArmZoom();                                            // recompute the zoom for the scrubbed position
  };
  seek(e);
  const up = () => { window.removeEventListener("pointermove", seek); window.removeEventListener("pointerup", up); };   // a click/drag on the timeline stays PAUSED (no auto-resume)
  window.addEventListener("pointermove", seek); window.addEventListener("pointerup", up);
}
function pvTextBar(b, dur) {
  const bar = document.createElement("div"); bar.className = "pv-tt-bar" + (b.kind === "icon" ? " pv-tt-bar-icon" : ""); bar.style.top = (b.row * 26 + 4) + "px";
  const label = document.createElement("span"); label.className = "pv-tt-label"; label.textContent = b.txt;
  const lh = document.createElement("div"); lh.className = "pv-tt-h pv-tt-l";
  const rh = document.createElement("div"); rh.className = "pv-tt-h pv-tt-r";
  bar.append(label, lh, rh);
  // minimum bar length ~0.5s (so a text/icon can be trimmed down to a brief flash). Small fixed floor — NOT a
  // fraction of the whole video (that made a short bar impossible to shrink, and a full-scene bar impossible to
  // MOVE because there was no spare room).
  const MIN = 0.5;
  const place = () => { bar.style.left = (b.absStart / dur * 100) + "%"; bar.style.width = ((b.absEnd - b.absStart) / dur * 100) + "%"; };
  place();
  let changed = false;
  const drag = (e, mode) => {
    if (mode !== "move" && !bar.classList.contains("editing")) return;   // edges resize ONLY in red edit mode; else fall through to move
    if (e.button != null && e.button !== 0) return;        // left button only
    e.preventDefault(); e.stopPropagation();
    changed = false;
    const cap = e.currentTarget;                           // capture the pointer so the drag can't be lost
    try { cap.setPointerCapture(e.pointerId); } catch (_) {}
    const W = $("#pvTtContent").getBoundingClientRect().width || 1;   // zoomed content width → drag maps to time
    const s0 = { x: e.clientX, a: b.absStart, o: b.absEnd, w: b.absEnd - b.absStart };
    bar.classList.add("dragging");
    const move = (ev) => {
      const dt = (ev.clientX - s0.x) / W * dur;
      if (mode === "move") { b.absStart = Math.max(b.sceneStart, Math.min(s0.a + dt, b.sceneEnd - s0.w)); b.absEnd = b.absStart + s0.w; }
      else if (mode === "l") b.absStart = Math.max(b.sceneStart, Math.min(s0.a + dt, b.absEnd - MIN));
      else b.absEnd = Math.min(b.sceneEnd, Math.max(s0.o + dt, b.absStart + MIN));
      changed = true; place();
    };
    const end = () => {
      cap.removeEventListener("pointermove", move); cap.removeEventListener("pointerup", end); cap.removeEventListener("pointercancel", end);
      try { cap.releasePointerCapture(e.pointerId); } catch (_) {}
      bar.classList.remove("dragging");
      if (!changed) return;                                 // a plain click (e.g. one half of a double-click) — don't save
      const inF = +((b.absStart - b.sceneStart) / b.sceneDur).toFixed(4);
      const outF = +((b.absEnd - b.sceneStart) / b.sceneDur).toFixed(4);
      const ps = PV.m.scenes.find(x => x.id === b.sceneId), s = (DOC.scenes || []).find(x => x.id === b.sceneId);
      if (b.kind === "icon") { b.ic.in = inF; b.ic.out = outF; if (ps && s) ps.icons = s.icons; }   // icon window
      else { b.ov.ost_in = inF; b.ov.ost_out = outF; if (ps && s) ps.texts = sceneTL(s); }           // text window
      queueSave(); PV.scene = -1; pvRender($("#pvVo").currentTime || 0);
    };
    cap.addEventListener("pointermove", move); cap.addEventListener("pointerup", end); cap.addEventListener("pointercancel", end);
  };
  lh.addEventListener("pointerdown", e => drag(e, "l"));
  rh.addEventListener("pointerdown", e => drag(e, "r"));
  bar.addEventListener("pointerdown", e => drag(e, "move"));
  bar.addEventListener("dblclick", (e) => {               // double-click → toggle red "edit" (resize-the-ends) mode
    e.preventDefault(); e.stopPropagation();
    const on = !bar.classList.contains("editing");
    const track = $("#pvTextTrack");
    if (track) track.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
    bar.classList.toggle("editing", on);
  });
  return bar;
}
// two <video> elements (double-buffer): the one showing the current scene is "active"; when a video
// transitions into another video the outgoing one keeps PLAYING as it slides out while the incoming
// plays in on the other element. pvVid() = active, pvVidBack() = the spare.
function pvVidEl(i) { return i ? $("#pvVideo2") : $("#pvVideo"); }
function pvVid() { return pvVidEl(PV.vidCur || 0); }
function pvVidBack() { return pvVidEl(1 - (PV.vidCur || 0)); }
// Play the outgoing scene's transition into the incoming one (mirrors the rendered xfade):
// crossfade/slide animate the old frame out; dips flash a black/white layer. `outVidEl`, when set,
// is a LIVE outgoing <video> that slides out still playing (double-buffer); else a still/canvas snapshot.
function pvPlayTransition(oldSc, sc, outFrame, outVidEl) {
  const t = oldSc.transition, fx = $("#pvFx");
  const prevImg = $("#pvPrev"), prevCvs = $("#pvPrevCanvas");
  const usingVid = !!outVidEl;                                // outgoing is a LIVE <video> (double-buffer)
  const usingCanvas = !usingVid && (outFrame === "canvas") && !!prevCvs;   // outgoing frame drawn onto the canvas
  const prev = usingVid ? outVidEl : (usingCanvas ? prevCvs : prevImg);    // the outgoing layer that animates out
  const IN_SLIDES = ["pv-in-slide-left", "pv-in-slide-right", "pv-in-slide-up", "pv-in-slide-down"];
  const TX = ["pv-tx-crossfade", "pv-tx-slide-left", "pv-tx-slide-right", "pv-tx-slide-up", "pv-tx-slide-down", "pv-prev-dip"];
  clearTimeout(PV._txT);
  const cleanup = () => {
    clearTimeout(PV._txT);
    [prevImg, prevCvs].forEach(p => { if (!p) return; p.hidden = true; p.className = "pv-media pv-prev"; p.style.transform = ""; p.style.removeProperty("--pv-z"); p.style.animationDuration = ""; });
    if (prevImg) prevImg.removeAttribute("src");
    if (PV._txOutVid) {                                     // the PREVIOUS transition's outgoing video: stop it, drop its classes, hide it
      const el = PV._txOutVid;
      el.classList.remove(...TX, "pv-prev"); el.style.transform = ""; el.style.removeProperty("--pv-z"); el.style.animationDuration = "";
      try { el.pause(); } catch (_) {} el.hidden = true; PV._txOutVid = null;
    }
    fx.hidden = true; fx.className = "pv-fx"; fx.style.animationDuration = "";
    if (PV._txInEl) { PV._txInEl.classList.remove(...IN_SLIDES); PV._txInEl.style.animationDuration = ""; PV._txInEl = null; }
    pvArmZoom();                                        // slide finished → hand the steady Ken-Burns zoom to the settled scene
  };
  // Fire cleanup when the animation actually FINISHES (animationend) — a fixed timer can fire a frame
  // early under load and cut the last frames. Keep a longer timeout only as a fallback.
  const schedule = (el) => {
    if (el) el.addEventListener("animationend", cleanup, { once: true });
    PV._txT = setTimeout(cleanup, done + 250);
  };
  cleanup();                                          // clear anything still mid-transition
  // match the render's transition length: 0.4s, clamped to half of either scene so a short scene
  // can't leave the transition running past its own end (the old frame bleeding into the next scene).
  const D = Math.max(0.12, Math.min(0.4, 0.5 * (oldSc.end - oldSc.start), sc ? 0.5 * (sc.end - sc.start) : 0.4));
  const dur = D.toFixed(3) + "s";
  prev.style.animationDuration = dur; fx.style.animationDuration = dur;
  const zoom = 1;   // preview does NOT zoom (no shaking); the outgoing frame hands off un-zoomed, matching
  // the outgoing video frame already lives on the canvas; otherwise use the approved still (which for
  // a video is its FIRST frame — only reached when the live frame couldn't be grabbed)
  const imgSrc = (usingVid || usingCanvas) ? null : (oldSc && (oldSc.img || (oldSc.type === "image" ? oldSc.url : null)));
  const hasFrame = usingVid || usingCanvas || !!imgSrc;
  if (hasFrame) {                                     // show the outgoing frame AT the zoom it reached
    if (usingVid) {                                    // outgoing video slides out still playing; lift it above the incoming
      prev.classList.add("pv-prev"); prev.hidden = false; PV._txOutVid = prev;
      if (!$("#pvVo").paused) prev.play().catch(() => {});
    } else { if (!usingCanvas) prev.src = imgSrc; prev.hidden = false; }
    prev.style.setProperty("--pv-z", zoom.toFixed(4));
    prev.style.transform = `scale(${zoom.toFixed(4)})`;
  }
  const done = Math.round(D * 1000) + 80;             // hide once the animation has finished
  if (t === "dip-black" || t === "dip-white") {
    if (hasFrame) { void prev.offsetWidth; prev.classList.add("pv-prev-dip"); }   // old (zoomed) held under the flash, then hidden
    fx.className = "pv-fx pv-fx-" + (t === "dip-white" ? "white" : "black");
    fx.hidden = false; void fx.offsetWidth; fx.classList.add("run");
    schedule(fx);                                     // fx always animates (pv-dip)
    return;
  }
  const isSlide = t.indexOf("slide-") === 0;
  if (hasFrame) { void prev.offsetWidth; prev.classList.add("pv-tx-" + t); }      // crossfade (opacity) / slide-out (keeps --pv-z)
  // for slides the incoming scene slides in from the other side at the same time (a push)
  if (isSlide) {
    const el = (sc && sc.type === "video" && !PV.imagesOnly) ? pvVid() : $("#pvImage");   // incoming video is now the active (front) element
    el.style.transform = ""; el.style.animationDuration = dur;   // hand the transform to the animation
    void el.offsetWidth; el.classList.add("pv-in-" + t); PV._txInEl = el;
  }
  if (!hasFrame && !isSlide) return;                  // crossfade with no outgoing frame = nothing to do
  schedule(hasFrame ? prev : PV._txInEl);             // whichever element carries the animation
}
// ---- written-testimonial karaoke in the Assemble preview ----
// Build the live card (same as the testimonial preview) + tokenise its body into .kw / .kw-sp spans, and
// collect the ORIGINAL-VO word timings for this scene's window (that's the audio the preview plays).
function pvKaraokeCard(sc) {
  if (!sc || sc.type !== "image") return null;                       // a written testimonial's scene is an image
  const docSc = ((DOC && DOC.scenes) || []).find(x => x.id === sc.id);
  if (!docSc || !docSc.tcard_id) return null;
  const card = ((DOC && DOC.testimonial_cards) || []).find(c => c.id === docSc.tcard_id);
  if (!card || card.type === "video") return null;                   // video testimonials show the still, not a card
  const ch = tcCharById(card.charId);
  if (!ch) return null;
  if (typeof ensureTCardCss === "function") ensureTCardCss();
  const fn = card.format === "email" ? tcBuildEmail : card.format === "star" ? tcBuildStar : tcBuildFB;
  let cardEl; try { cardEl = fn(ch, card.text || "", tcEx(card)); } catch (_) { return null; }
  const body = cardEl.querySelector('[data-role="text"]');
  const spans = [], gaps = [];
  if (body) {
    const frag = document.createDocumentFragment(); let wi = 0;
    (body.innerText || body.textContent || "").split(/(\s+)/).forEach(tok => {   // textContent fallback: innerText can be empty on a not-yet-attached card
      if (tok === "") return;
      // whitespace OR a punctuation-only token (e.g. "—") is NOT a spoken word → treat as a gap so it doesn't consume a word index (that off-by-one was the "— no more afternoon slump" desync)
      if (/^\s+$/.test(tok) || !/[\p{L}\p{N}]/u.test(tok)) { const g = document.createElement("span"); g.className = "kw kw-sp"; g.textContent = tok; frag.appendChild(g); gaps.push({ el: g, nextWi: /\n/.test(tok) ? -1 : wi }); return; }
      const sp = document.createElement("span"); sp.className = "kw"; sp.textContent = tok; spans.push(sp); frag.appendChild(sp); wi++;
    });
    body.innerHTML = ""; body.appendChild(frag);
  }
  const cex = card.extra || {};
  const spliced = !!(PV.m && (PV.m.custom_vo || []).indexOf(sc.id) >= 0);   // server actually spliced this scene's VO
  let words;
  if (spliced && cex.words && cex.words.length && cex.vo_dur) {   // this scene plays the card's CUSTOM voice-over → use its 0-based alignment, offset to the scene start
    // match the clip alignment onto the card's own words first — the aligner tokenises differently
    // ("1.000" -> "1." + "000"), and a straight index-for-index copy drifts from there on (see tcCardTiming)
    const base = tcAlignWords(cex.words, card.text, null);
    words = (base.length ? base : cex.words).map(w => ({ s: sc.start + w.s, e: sc.start + w.e, w: w.w }));
  } else {
    words = tcAlignWords((tcTL && tcTL.words) || [], card.text, sc.start);   // full-stream match (see tcCardTiming) → correct last-word timing
    if (!words.length) words = ((tcTL && tcTL.words) || []).filter(w => w.s >= sc.start - 0.05 && w.s < sc.end + 0.5);
  }
  return { cardEl, spans, gaps, words, end: sc.end, card };
}
function pvSetKaraoke(sc) {
  const host = $("#pvKaraoke"); if (!host) return;
  const k = pvKaraokeCard(sc);
  if (!k) { host.hidden = true; host.innerHTML = ""; PV.kara = null; return; }
  host.innerHTML = "";
  const wrap = document.createElement("div"); wrap.className = "pv-kwrap"; wrap.appendChild(k.cardEl); host.appendChild(wrap);
  host.hidden = false; const im = $("#pvImage"); if (im) im.hidden = true;
  const fit = () => {
    const fw = host.clientWidth || 1, fh = host.clientHeight || 1;
    const cw = k.cardEl.offsetWidth || 1, cvh = k.cardEl.offsetHeight || 1;
    const f = tc16Frame(cw, cvh);                              // the SAME 16:9 frame the render bakes → what you watch is what gets burned in
    k.cardEl.style.transform = f.k < 1 ? `scale(${f.k.toFixed(4)})` : "";
    const s = Math.min(fw / f.W, fh / f.H);
    wrap.style.width = f.W + "px"; wrap.style.height = f.H + "px"; wrap.style.transform = `scale(${s})`;
  };
  requestAnimationFrame(fit); setTimeout(fit, 60); setTimeout(fit, 260);   // refit after the card's images paint
  if (k.card && k.card.format === "star") {   // line the bottle up with the identity column, same as the editor
    tcFitProduct(k.cardEl, tcEx(k.card).prod || tcDefaultProd()).then(fit).catch(() => {});
  }
  PV.kara = k;
  // the preview card is now VISIBLE with correct dimensions → store this card's render-karaoke HTML so a
  // final render has it WITHOUT needing to open the Testimonials tab (fixes the "no highlight / 0×0" render)
  if (k.card) setTimeout(() => {
    try {
      const kh = tcMakeKaraHtml(k.cardEl);
      if (kh && kh.w > 10) {
        const cur = (k.card.extra && k.card.extra.kara) || null;
        if (!cur || !(cur.w > 10) || cur.html !== kh.html) { k.card.extra = k.card.extra || {}; k.card.extra.kara = kh; if (typeof tcQueueSave === "function") tcQueueSave(); }
      }
    } catch (_) {}
  }, 340);
}
// Paint the karaoke highlight at time t. The green does NOT step word by word: the leading edge sweeps
// ACROSS the word being spoken, over that word's own duration, so the bar grows at reading pace. Whole
// words snapping on is what read as "pop, pop, pop". Same maths as the burn-in render, and both preview
// players call THIS, so they cannot drift apart.
// Paint the karaoke at time t. The edge's position is ONE number: distance travelled along the text in
// reading order. Word onsets are anchors on that line, so the right word lights at the right moment, and
// between anchors the edge holds a single speed. Same model and same numbers as the burn-in render.
function tcKaraBuild(spans, gaps, words) {
  const gapBefore = {};
  if (gaps) for (const g of gaps) if (g.nextWi >= 1) gapBefore[g.nextWi] = g.el;
  const n = Math.min(spans.length, words.length);
  const pieces = [], anch = [];
  let run = 0;
  for (let j = 0; j < n; j++) {
    anch.push([+words[j].s, run]);
    const w = spans[j].offsetWidth || 1;
    pieces.push({ el: spans[j], w }); run += w;
    const gEl = gapBefore[j + 1];
    if (gEl) { const gw = gEl.offsetWidth || 0; if (gw > 0) { pieces.push({ el: gEl, w: gw }); run += gw; } }
  }
  if (anch.length) {
    const last = words[n - 1];
    anch.push([Math.max(anch[anch.length - 1][0] + 0.06, +(last.e != null ? last.e : last.s + 0.2)), run]);
  }
  // Some onsets are 20ms apart — the aligner's monotonicity floor when it cannot separate two words, not
  // speech. Taken literally the edge crosses a whole word in one frame. Where an interval demands an
  // absurd speed the anchor at its START is pulled earlier, out of the slack before it; the anchor at the
  // END never moves, so the next word is still on time.
  if (anch.length > 3) {
    const sp = [];
    for (let i = 0; i < anch.length - 1; i++) sp.push((anch[i + 1][1] - anch[i][1]) / Math.max(1e-3, anch[i + 1][0] - anch[i][0]));
    sp.sort((x, y) => x - y);
    const cap = 2.5 * Math.max(1, sp[sp.length >> 1]);
    const orig = anch.map(a => a[0]);
    for (let i = anch.length - 2; i >= 0; i--) {      // BACKWARDS so it cascades: making room for one
      const need = (anch[i + 1][1] - anch[i][1]) / cap;   // interval can starve the one before it
      if (anch[i + 1][0] - anch[i][0] < need) anch[i][0] = Math.min(anch[i][0], anch[i + 1][0] - need);
    }
    for (let i = 0; i < anch.length; i++) anch[i][0] = Math.max(anch[i][0], orig[i] - 0.18);
    for (let i = 1; i < anch.length; i++) if (anch[i][0] <= anch[i - 1][0]) anch[i][0] = anch[i - 1][0] + 1e-3;
  }
  return { pieces, anch, total: run, n };
}
function tcKaraPaint(spans, gaps, words, t, endT) {
  let c = spans.__kara;
  if (!c || c.nw !== words.length || c.ns !== spans.length) {
    c = tcKaraBuild(spans, gaps, words); c.nw = words.length; c.ns = spans.length; spans.__kara = c;
  }
  const A = c.anch;
  let d = 0;
  if (A.length) {
    if (t >= A[A.length - 1][0]) d = c.total;
    else if (t > A[0][0]) {
      let k = 0; while (k + 1 < A.length && A[k + 1][0] <= t) k++;
      d = A[k][1] + (A[k + 1][1] - A[k][1]) * ((t - A[k][0]) / Math.max(1e-6, A[k + 1][0] - A[k][0]));
    }
  }
  if (endT != null && t >= endT - 0.15) d = c.total;
  const paint = (el, f) => {
    if (f <= 0) { el.classList.remove("kw-on"); el.style.background = ""; }
    else if (f >= 1) { el.classList.add("kw-on"); el.style.background = ""; }
    else {
      el.classList.add("kw-on");
      const pc = (f * 100).toFixed(1);
      el.style.background = `linear-gradient(to right, var(--kw-green) ${pc}%, rgba(0,0,0,0) ${pc}%)`;
    }
  };
  let left = d;
  for (const p of c.pieces) { paint(p.el, Math.max(0, Math.min(1, left / p.w))); left -= p.w; }
  for (let j = c.n; j < spans.length; j++) paint(spans[j], d >= c.total ? 1 : 0);
}
function pvKaraokeTick(t) {
  const k = PV.kara; if (!k || !k.words.length) return;
  tcKaraPaint(k.spans, k.gaps, k.words, t, k.end);
}

// The PREVIEW deliberately does NOT apply the Ken-Burns zoom: writing a per-frame (or even transitioned)
// transform on the live <video> caused shaking/jitter on some machines. The zoom is kept ONLY in the actual
// deliverables — the render (render_video.py) and the Premiere XML (premiere_export.py). pvArmZoom just clears
// any leftover transform so nothing ever scales in the preview.
function pvArmZoom() {
  [$("#pvImage"), $("#pvVideo"), $("#pvVideo2")].forEach(el => {
    if (el && (el.style.transform || el.style.transition)) { el.style.transition = ""; el.style.transform = ""; }
  });
}
function pvRender(t) {
  const m = PV.m; if (!m) return;
  let si = PV.m.scenes.length - 1;
  for (let i=0;i<m.scenes.length;i++) if (t>=m.scenes[i].start && t<m.scenes[i].end) { si = i; break; }
  if (si !== PV.scene && si >= 0) {
    const oldIdx = PV.scene, oldSc = oldIdx >= 0 ? m.scenes[oldIdx] : null;
    PV.scene = si; const sc = m.scenes[si];
    const img = $("#pvImage"), bl = $("#pvBlank");
    const front = pvVid();                          // element that was showing the outgoing scene (if a video)
    // Preview shows straight CUTS only — transitions were freezing the outgoing scene and looked worse than a
    // clean cut. Transitions still live in the deliverables (render_video.py + the Premiere XML); the preview
    // just cuts, and the #pvHold layer bridges each cut so there's no black flash.
    const willTx = false;
    let outFrame = null, outVidEl = null;
    const asImage = PV.imagesOnly && sc.type === "video" && sc.img;   // images-only → show the still
    if (sc.type === "video" && !asImage) {
      // DOUBLE-BUFFER CUT (no freeze): decode the new clip on the BACK buffer while the OLD video keeps PLAYING,
      // then switch the instant the new frame is ready. (The first scene reuses the already-primed front so it
      // shows immediately; no poster — its aspect differed from the clip and stretched the first frame.)
      const first = (oldSc == null);
      const incoming = first ? front : pvVidBack();
      const outgoing = first ? null : front;
      const willReload = incoming._pvSrc !== sc.url;
      incoming.removeAttribute("poster");
      if (willReload) { incoming.src = sc.url; incoming._pvSrc = sc.url; }
      const enter = Math.max(0, t - sc.start);
      const swap = () => {
        try { if (Math.abs((incoming.currentTime || 0) - enter) > 0.3) incoming.currentTime = enter; } catch (e) {}
        incoming.hidden = false;
        if (!$("#pvVo").paused) incoming.play().catch(() => {});
        if (outgoing && outgoing !== incoming) PV.vidCur = 1 - (PV.vidCur || 0);   // back buffer is now the front
        // Drop the OLD layers (previous image/blank + the outgoing video) ONLY AFTER the new clip has PAINTED a
        // frame — hiding them in the same tick left one black frame at the cut. Until then the old layers stay
        // up and bridge the gap.
        const dropOld = () => {
          img.hidden = true; bl.hidden = true;
          if (outgoing && outgoing !== incoming) { try { outgoing.pause(); } catch (_) {} outgoing.hidden = true; }
        };
        if (first) dropOld();                                // first scene: nothing meaningful was showing
        else {
          if (incoming.requestVideoFrameCallback) incoming.requestVideoFrameCallback(dropOld);
          else requestAnimationFrame(() => requestAnimationFrame(dropOld));
          setTimeout(dropOld, 200);                          // backstop so the old layer can't linger if rVFC never fires
        }
        pvArmZoom();
      };
      if (first || incoming.readyState >= 2) { swap(); }     // already decoded → switch instantly
      else {                                                 // not ready → keep the OLD clip playing until the NEW frame paints
        let done = false;
        const go = () => { if (done) return; done = true; if (PV.scene === si) swap(); };
        if (incoming.requestVideoFrameCallback) incoming.requestVideoFrameCallback(go);
        else incoming.addEventListener("loadeddata", go, { once: true });
        setTimeout(go, 300);                                 // safety net
      }
    } else if (sc.type === "image" || asImage) {
      // hide the video buffers EXCEPT a live outgoing one (it keeps playing to slide out; the transition hides it after)
      [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v !== outVidEl) { try { v.pause(); } catch (_) {} v.hidden = true; } });
      { const hh = $("#pvHold"); if (hh) hh.hidden = true; }
      bl.hidden = true; img.hidden = false; img.src = asImage ? sc.img : sc.url;
    } else {
      [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v !== outVidEl) { try { v.pause(); } catch (_) {} v.hidden = true; } });
      { const hh = $("#pvHold"); if (hh) hh.hidden = true; }
      img.hidden = true; bl.hidden = false;
      // scene number ABOVE the icons: the centered ▶ play overlay lands on the icons, not on
      // the number, so the scene number stays readable when the preview is paused
      bl.innerHTML =
        `<div class="pv-empty">
           <div class="pv-empty-title">Scene ${sc.id}</div>
           <div class="pv-empty-icons">
             <svg class="pv-empty-ic" viewBox="50 28 60 54" fill="none"><rect x="52" y="32" width="56" height="46" rx="5"/><circle cx="70" cy="49" r="6"/><path d="M56 74 l18 -20 12 12 9 -9 13 15"/></svg>
             <svg class="pv-empty-ic" viewBox="50 30 60 50" fill="none"><rect x="52" y="34" width="56" height="42" rx="7"/><path d="M74 45 l18 10 -18 10 z"/></svg>
           </div>
           <div class="pv-empty-msg">No image or video for this scene yet.<br>Generate one and approve the image or video to see it here.</div>
         </div>`;
    }
    pvSetOverlay(sc);                                // on-screen text overlay (replays its animation on scene entry)
    pvSetIcons(sc);                                  // overlay icons (X / arrow / pain-burst) for this scene
    pvSetKaraoke(sc);                                // written-testimonial scene → live card + green karaoke over this scene
    // play the transition only on natural forward playback (skip scrubs/jumps) so it mirrors the render
    if (willTx) pvPlayTransition(oldSc, m.scenes[si], outFrame, outVidEl);
    pvArmZoom();                                     // arm the CSS Ken-Burns for the NEW scene (skips if a slide owns it)
  }
  const sc = m.scenes[PV.scene];
  // Ken Burns zoom is now driven by a CSS transition (pvArmZoom), armed on scene entry / play / pause / seek —
  // NOT written per frame here (per-frame transform on a <video> shakes under load).
  // re-sync the video ONLY on a large drift (e.g. after scrubbing); during playback it runs freely = smooth
  if (sc && sc.type === "video" && !(PV.imagesOnly && sc.img) && pvVid()._pvSrc === sc.url) {
    const v = pvVid();                             // guard: during a deferred cut the front is still the OLD clip — don't seek it to the new scene's time
    // clip shorter than its scene -> slow it (playbackRate) so it fills the whole scene instead of freezing.
    const sd = Math.max(0.001, sc.end - sc.start);
    const rate = (v.duration && isFinite(v.duration) && v.duration < sd) ? Math.max(0.05, v.duration / sd) : 1;
    if (v.playbackRate !== rate) { try { v.playbackRate = rate; } catch (e) {} }
    const want = (t - sc.start) * rate;                       // scene-time -> clip-time (accounts for the slow-down)
    if (isFinite(want) && Math.abs((v.currentTime||0) - want) > 1.0) { try { v.currentTime = Math.max(0, want); } catch (e) {} }
  }
  // PREBUFFER the NEXT scene's video onto the idle back buffer while this scene plays, so the cut lands EXACTLY
  // on the scene boundary (in sync with the caption) instead of a decode beat later.
  if (sc && !$("#pvVo").paused && PV.scene >= 0 && PV.scene < m.scenes.length - 1) {
    const nx = m.scenes[PV.scene + 1];
    if (nx && nx.type === "video" && nx.url && !(PV.imagesOnly && nx.img)) {
      const back = pvVidBack();
      // only prime a HIDDEN idle buffer — never call load() on the still-visible outgoing clip during the
      // one-frame handoff (that would reset it to black while it's on screen)
      if (back && back.hidden && back._pvSrc !== nx.url) { try { back.src = nx.url; back._pvSrc = nx.url; back.load(); } catch (e) {} }
    }
  }
  pvOstTick(t);   // show each on-screen text only during its own window, in/out at the edges
  pvIconTick(t);  // show each on-screen icon only during its own window (Assemble timeline)
  pvKaraokeTick(t);   // advance the testimonial karaoke highlight (no-op off testimonial scenes)
  const ci = PV.kara ? -1 : pvIdx(m.captions, t);   // no subtitle at all over a written-testimonial card

  if (ci !== PV.cap) { PV.cap = ci; pvSetCaptionText(ci >= 0 ? m.captions[ci].text : ""); }
  pvMusicMix(t);                                   // background music with cross-fades (see below)
  const pct = m.duration ? (t/m.duration*100) : 0;
  $("#pvProgress").style.width = pct + "%"; $("#pvHead").style.left = pct + "%"; pvTextTrackHead(t);
  $("#pvTime").textContent = `${pvFmt(t)} / ${pvFmt(m.duration)}`;
}

// ---- background-music cross-fade (matches render_video.py / premiere_export.py) ----
const PV_XFADE = 3.0;   // seconds; must match XFADE_SEC
function pvMusicEls() { return [$("#pvMusic"), $("#pvMusic2")]; }
// A segment's volume at time t: fades IN over the previous scene's end (reaching full exactly at
// its boundary start) and fades OUT over its last xfade (silent exactly at the next boundary).
function pvSegVol(g, i, t, last) {
  const s = g.start, e = g.end, lvl = Math.min(1, Math.max(0, g.level));
  const pre = (i > 0) ? PV_XFADE : 0;
  const start = s - pre;
  const fin = (i > 0) ? pre : Math.min(1.5, e - s);
  const fout = (i < last) ? PV_XFADE : Math.min(2.0, e - start);
  if (t < start || t >= e) return 0;
  if (fin > 0 && t < start + fin) return lvl * (t - start) / fin;   // fade in → full at the boundary
  if (fout > 0 && t > e - fout) return lvl * (e - t) / fout;        // fade out → 0 at the boundary
  return lvl;
}
// Up to two segments are audible at once (during a cross-fade); even/odd segments use the two
// audio slots so the out-going and in-coming tracks never fight over one element.
function pvMusicMix(t) {
  const m = PV.m; if (!m) return;
  const segs = m.music || [], last = segs.length - 1, els = pvMusicEls();
  const paused = $("#pvVo").paused;
  const want = [null, null];
  segs.forEach((g, i) => { if (g.url) { const v = pvSegVol(g, i, t, last); if (v > 0) want[i % 2] = { g, i, v }; } });
  for (let slot = 0; slot < 2; slot++) {
    const el = els[slot]; if (!el) continue;
    const w = want[slot];
    if (!w) { if (!el.paused) el.pause(); el.volume = 0; continue; }
    if (el.dataset.src !== w.g.url) { el.src = w.g.url; el.dataset.src = w.g.url; el.loop = true; }
    el.volume = Math.min(1, Math.max(0, w.v));
    const off = t - (w.g.start - ((w.i > 0) ? PV_XFADE : 0));
    if (Math.abs((el.currentTime || 0) - off) > 0.35) { try { el.currentTime = Math.max(0, off); } catch (e) {} }
    if (paused) { if (!el.paused) el.pause(); }
    else if (el.paused) el.play().catch(() => {});
  }
}
function pvLoop() { const vo = $("#pvVo"); pvRender(vo.currentTime || 0); if (!vo.paused) PV.raf = requestAnimationFrame(pvLoop); }
function pvPlay() {
  const vo = $("#pvVo"); vo.play().catch(()=>{});
  const sc = PV.m.scenes[PV.scene];
  if (sc && sc.type === "video" && !(PV.imagesOnly && sc.img)) {
    PV.scene = -1;                                 // let pvRender re-confirm the scene next frame
    const v = pvVid();
    $("#pvImage").hidden = true; v.hidden = false;   // swap the at-rest still out for the moving video
    const sd = Math.max(0.001, sc.end - sc.start);
    const rate = (v.duration && isFinite(v.duration) && v.duration < sd) ? Math.max(0.05, v.duration / sd) : 1;   // short clip -> slow to fill
    try { v.playbackRate = rate; } catch (e) {}
    try { v.currentTime = Math.max(0, (vo.currentTime - sc.start) * rate); } catch (e) {}   // re-sync on resume (rate-mapped)
    v.play().catch(()=>{});
  }
  pvMusicMix(vo.currentTime || 0);                 // start/resume the audible music segment(s)
  $("#pvPlay").textContent = "❚❚"; $("#pvBig").hidden = true;
  cancelAnimationFrame(PV.raf); PV.raf = requestAnimationFrame(pvLoop);
  pvArmZoom(true);                                  // resume the smooth zoom tween toward the scene's end scale
  pvHoldAnims(false);                               // let the looping pain rings run again
  pvShowControls();
}
function pvPause() { $("#pvVo").pause(); pvMusicEls().forEach(el => el.pause()); $("#pvVideo").pause(); $("#pvVideo2").pause(); $("#pvPlay").textContent = "▶"; $("#pvBig").hidden = false; cancelAnimationFrame(PV.raf); pvArmZoom(false); pvHoldAnims(true); pvShowControls(); }
function pvToggle() { if (!PV.m) return; $("#pvVo").paused ? pvPlay() : pvPause(); }
function pvRestart() {                          // jump to the very beginning
  if (!PV.m) return;
  const wasPlaying = !$("#pvVo").paused;
  PV.seg = -1; PV.cap = -1; PV.scene = -1; PV.vidSrc = ""; [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) v._pvSrc = ""; });
  $("#pvVo").currentTime = 0;
  pvMusicEls().forEach(el => { try { el.currentTime = 0; } catch (e) {} });
  pvRender(0);
  if (wasPlaying) pvPlay(); else { pvPause(); pvStillIfPaused(); }   // at rest, show the still not a black video
}
// seek to a given horizontal cursor position on the bar
function pvSeekTo(clientX) {
  if (!PV.m) return;
  const r = $("#pvBar").getBoundingClientRect();
  const t = Math.min(1, Math.max(0, (clientX - r.left) / r.width)) * PV.m.duration;
  PV.seg = -1; PV.cap = -1;                    // force music re-seek + caption refresh
  $("#pvVo").currentTime = t; pvRender(t); pvArmZoom();
}
// click OR drag the handle to scrub; pause while dragging so seeking is stable, then resume
let pvDragging = false, pvResumeAfterDrag = false;
function pvDragStart(ev) {
  if (!PV.m) return;
  pvDragging = true; pvResumeAfterDrag = !$("#pvVo").paused;
  if (pvResumeAfterDrag) pvPause();
  $("#pvBar").classList.add("dragging");
  pvSeekTo(ev.clientX); pvThumbAt(ev);
  ev.preventDefault();
}
function pvDragMove(ev) { if (pvDragging) { pvSeekTo(ev.clientX); pvThumbAt(ev); } }
function pvDragEnd() {
  if (!pvDragging) return;
  pvDragging = false;
  $("#pvBar").classList.remove("dragging");
  $("#pvThumb").hidden = true;
  // a click/drag on the progress bar PAUSES and stays paused (don't auto-resume)
}
function pvMute() {
  if (!PV.m) return;
  const on = !$("#pvVo").muted;
  $("#pvVo").muted = on; pvMusicEls().forEach(el => el.muted = on);
  $("#pvMute").textContent = on ? "🔇" : "🔊";
}
function pvFull() {
  const w = $("#previewWrap");   // fullscreen the WHOLE player so the controls come along
  if (document.fullscreenElement) document.exitFullscreen();
  else if (w.requestFullscreen) w.requestFullscreen();
}
function pvImagesOnly() {
  if (!PV.m) return;
  PV.imagesOnly = !PV.imagesOnly;
  $("#pvImgOnly").classList.toggle("on", PV.imagesOnly);
  [$("#pvVideo"), $("#pvVideo2")].forEach(v => { try { v.pause(); } catch (_) {} v._pvSrc = ""; });
  PV.scene = -1;                                 // force the current scene's media to re-resolve
  pvRender($("#pvVo").currentTime || 0);
}
let pvHideTimer = null;
function pvShowControls() {                        // reveal the overlaid buttons; auto-hide again a few sec into playback (windowed + fullscreen)
  const w = $("#previewWrap"); if (!w) return;
  w.classList.remove("pv-hide-ui");
  clearTimeout(pvHideTimer);
  if (PV.m && !$("#pvVo").paused) {
    pvHideTimer = setTimeout(() => w.classList.add("pv-hide-ui"), 2500);
  }
}
document.addEventListener("fullscreenchange", () => {
  const full = !!document.fullscreenElement;
  $("#pvFull").textContent = full ? "🡼" : "⛶";
  if (full) {                          // fullscreen starts with the text bar HIDDEN; T reveals it (smoothly)
    PV._ttWas = PV.ttOpen;
    pvTtSetOpen(false, false);
  } else if (PV._ttWas != null) {      // leaving fullscreen → restore the windowed text-bar state
    pvTtSetOpen(PV._ttWas, false);
    PV._ttWas = null;
  }
  pvShowControls();
});
$("#buildPreviewBtn").addEventListener("click", buildPreview);

// ---------- server-side MP4 render (the preview, baked into one downloadable file) ----------
let rndPoll = null, rndStartMs = 0, rndClock = null, rndLastSt = null;

// switching projects: hide the section (Build Preview brings it back), then re-show it if
// this project already has a render — finished or still running
async function rndReset() {
  clearInterval(rndPoll); rndPoll = null;
  $("#renderSection").hidden = true;
  $("#renderStatus").hidden = $("#renderTrack").hidden = $("#renderDl").hidden = true;
  $("#renderCancelBtn").hidden = true;
  $("#renderBtn").disabled = false;
  $("#renderBtn").textContent = "🎥 Render Video";
  const st = await rndTick();
  if (st && (st.status === "running" || st.status === "done")) $("#renderSection").hidden = false;
  if (st && st.status === "running") rndPoll = setInterval(rndTick, 1500);
  loadRenderHistory();     // show past renders whenever the render section is available
}

function rndShow(st) {
  const _rprev = rndLastSt;   // previous status — chime only on a real transition (running → done/error), not on load
  const box = $("#renderStatus"), track = $("#renderTrack"), fill = $("#renderFill"), dl = $("#renderDl");
  const cancelBtn = $("#renderCancelBtn");
  const running = st.status === "running";
  box.hidden = false;
  box.className = "pv-status" + (st.status === "error" ? " err" : "");
  track.hidden = !running;
  fill.style.width = `${st.pct || 0}%`;
  $("#renderBtn").disabled = running;
  $("#renderTestBtn").disabled = running;      // can't run a test render while a render is going
  cancelBtn.hidden = !running;                 // Stop button shows only while a render is running
  if (!running) { cancelBtn.disabled = false; if (rndClock) { clearInterval(rndClock); rndClock = null; } rndStartMs = 0; }
  rndLastSt = st;
  if (running) {
    if (!rndStartMs) rndStartMs = Date.now();   // a running render restored on reload starts its clock now
    const el = pvFmt((Date.now() - rndStartMs) / 1000);   // real elapsed time — always counts up correctly
    // keep the spinner element ALIVE across ticks (only update the text) so its spin loops seamlessly
    // instead of restarting every second when innerHTML is rebuilt
    let label = box.querySelector(".rnd-label");
    if (!label) { box.innerHTML = `<span class="sub-spin"></span> <span class="rnd-label"></span>`; label = box.querySelector(".rnd-label"); }
    label.textContent = `${st.step || "Rendering…"} · ${el} (${st.pct || 0}%)`;
    if (!rndClock) rndClock = setInterval(() => { if (rndLastSt && rndLastSt.status === "running") rndShow(rndLastSt); }, 1000);   // tick the counter every second
    dl.hidden = true;
  } else if (st.status === "error") {
    if (_rprev && _rprev.status === "running") playErrorChime();   // render failed → error chime
    box.textContent = "Render failed: " + (st.error || "unknown error");
    dl.hidden = true;
  } else if (st.status === "cancelled") {
    box.hidden = true;                          // no lingering "Render cancelled." text
    dl.hidden = true;
    $("#renderBtn").textContent = "🎥 Render Video";
  } else if (st.status === "done") {
    if (_rprev && _rprev.status === "running") playNotifChime();   // render finished → success chime
    const mb = st.size ? ` · ${(st.size / 1048576).toFixed(0)} MB` : "";
    // plain green tick, NOT the ✅ emoji — that reads as a checkbox next to the
    // cross-fade / zoom / subtitle checkboxes sitting right above this line
    const subs = st.subs === false ? "no subtitles" : "subtitles burned in";
    const res = st.fast ? "1280×720 @ 30fps (test)" : "1920×1080 @ 60fps";
    box.innerHTML = `<span class="rnd-ok">✔</span> Rendered ${pvFmt(st.duration || 0)}${mb} — ${res}, ${subs}.`;
    dl.hidden = false;
    dl.href = `/media/${PROJECT}/${st.file}?dl=${encodeURIComponent(st.name)}`;
    dl.setAttribute("download", st.name);
    dl.onclick = (e) => { e.preventDefault(); downloadMedia(st.file, st.name); };   // works in the desktop window too
    $("#renderBtn").textContent = "🔄 Re-render Video";
    loadRenderHistory();                            // a new render just landed → refresh the history list
  } else {
    box.hidden = true;
  }
}
function rndAgo(mtimeSec) {
  const s = Math.max(0, Date.now() / 1000 - mtimeSec);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
async function loadRenderHistory() {
  const box = $("#renderHistory"); if (!box || !PROJECT) return;
  let list = [];
  try { list = (await (await fetch(`/api/renders/${PROJECT}`)).json()).renders || []; } catch (e) {}
  if (!list.length) { box.hidden = true; box.innerHTML = ""; return; }
  box.hidden = false; box.innerHTML = "";
  const title = document.createElement("div"); title.className = "rnd-hist-title"; title.textContent = "Recent renders"; box.appendChild(title);
  list.forEach(r => {
    const row = document.createElement("div"); row.className = "rnd-hist-row";
    const mb = r.size ? `${(r.size / 1048576).toFixed(0)} MB` : "";
    const meta = document.createElement("span"); meta.className = "rnd-hist-meta";
    meta.innerHTML = `<b>${r.test ? "720p test" : "1080p"}</b> · ${mb} · ${rndAgo(r.mtime)}`;
    const dl = document.createElement("a"); dl.className = "ghost rnd-hist-dl"; dl.textContent = "⬇"; dl.title = "Download";
    dl.href = `/media/${PROJECT}/${r.file}?dl=${encodeURIComponent(r.name)}`; dl.setAttribute("download", r.name);
    dl.onclick = (e) => { e.preventDefault(); downloadMedia(r.file, r.name); };   // desktop-window friendly
    const open = document.createElement("button"); open.className = "ghost rnd-hist-open"; open.textContent = "📂"; open.title = "Open the folder";
    open.addEventListener("click", () => revealMedia(r.file));
    const del = document.createElement("button"); del.className = "ghost rnd-hist-del"; del.textContent = "×"; del.title = "Delete this render";
    del.addEventListener("click", async () => { try { await fetch(`/api/renders/${PROJECT}/${encodeURIComponent(r.name)}/delete`, { method: "POST" }); } catch (e) {} loadRenderHistory(); });
    row.append(meta, dl, open, del); box.appendChild(row);
  });
}

async function rndTick() {
  if (!PROJECT) return;
  let st;
  try { st = await (await fetch(`/api/render/${PROJECT}`)).json(); }
  catch (e) { return null; }
  rndShow(st);
  if (st.status !== "running") { clearInterval(rndPoll); rndPoll = null; }
  return st;
}

async function startRender(fast) {
  if (!PROJECT) return;
  const total = (PV.m && PV.m.duration) || 0;
  const range = await rangeDialog(fast, total);          // pick full video or a [start,end] slice + confirm (Render button)
  if (!range) return;                                    // cancelled
  const body = { kenburns: $("#rndKenburns").checked, music: $("#rndMusic").checked, burnsubs: $("#rndBurnSubs").checked, onscreentext: $("#rndOnscreen").checked, transitions: $("#rndTransitions").checked, fast: !!fast, gpu: !!range.gpu, low_priority: !!range.cpu };
  if (!range.full) { body.range_start = range.start; body.range_end = range.end; }
  rndStartMs = Date.now();   // start the elapsed-time counter from the click
  rndShow({ status: "running", pct: 0, step: fast ? "Starting test render…" : "Starting…" });
  let r;
  try { r = await fetch(`/api/render/${PROJECT}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); }
  catch (err) { rndShow({ status: "error", error: String(err) }); return; }
  if (!r.ok) {
    let m = "could not start"; try { m = (await r.json()).error || m; } catch (e2) {}
    rndShow({ status: "error", error: m });
    return;
  }
  clearInterval(rndPoll);
  rndPoll = setInterval(rndTick, 1500);
}
$("#renderBtn").addEventListener("click", () => startRender(false));
$("#renderTestBtn").addEventListener("click", () => startRender(true));
$("#renderCancelBtn").addEventListener("click", async () => {
  if (!PROJECT) return;
  const btn = $("#renderCancelBtn");
  btn.disabled = true;                          // immediate abort — no confirm (that's the point)
  $("#renderStatus").innerHTML = `<span class="sub-spin"></span> Cancelling…`;
  try { await fetch(`/api/render/${PROJECT}/cancel`, { method: "POST" }); } catch (e) {}
  rndTick();                                     // reflect the cancelled state right away
});
$("#pvPlay").addEventListener("click", pvToggle);
$("#pvStage").addEventListener("click", pvToggle);   // click anywhere on the video toggles play/pause
function pvThumbAt(ev) {
  if (!PV.m) return;
  const bar = $("#pvBar"), r = bar.getBoundingClientRect();
  const pct = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
  const t = pct * PV.m.duration;
  let sc = PV.m.scenes[PV.m.scenes.length - 1];
  for (const s of PV.m.scenes) if (t >= s.start && t < s.end) { sc = s; break; }
  const thumb = $("#pvThumb"), img = thumb.querySelector("img"), lbl = thumb.querySelector("span");
  const src = sc && (sc.img || (sc.type === "image" ? sc.url : null));
  if (src) { if (img.dataset.src !== src) { img.src = src; img.dataset.src = src; } img.style.display = ""; }
  else { img.style.display = "none"; }
  lbl.textContent = `${sc ? "Scene " + sc.id : ""} · ${pvFmt(t)}`;
  // fixed-positioned at the cursor (clamped to the viewport so the 150px thumb stays visible)
  thumb.style.left = Math.min(Math.max(ev.clientX, 85), window.innerWidth - 85) + "px";
  thumb.style.top = r.top + "px";
  thumb.hidden = false;
}
$("#pvBar").addEventListener("mousemove", (ev) => { if (!pvDragging) pvThumbAt(ev); });
$("#pvBar").addEventListener("mouseleave", () => { if (!pvDragging) { const t = $("#pvThumb"); if (t) t.hidden = true; } });
$("#pvBar").addEventListener("mousedown", pvDragStart);      // click OR drag the handle to scrub
window.addEventListener("mousemove", pvDragMove);
window.addEventListener("mouseup", pvDragEnd);
$("#pvRestart").addEventListener("click", pvRestart);
$("#pvMute").addEventListener("click", pvMute);
$("#pvFull").addEventListener("click", pvFull);
$("#pvImgOnly").addEventListener("click", pvImagesOnly);
$("#pvTextToggle").addEventListener("click", () => pvTtSetOpen(!PV.ttOpen, true));   // T = show/hide the text track
$("#pvTtZoomIn").addEventListener("click", () => pvTtSetZoom((PV.ttZoom || 1) * 1.6));
$("#pvTtZoomOut").addEventListener("click", () => pvTtSetZoom((PV.ttZoom || 1) / 1.6));
// hold ALT + mouse-wheel over the text track to zoom the timeline in/out
$("#pvTextTrack").addEventListener("wheel", (e) => {
  if (!e.altKey) return;
  e.preventDefault();
  pvTtSetZoom((PV.ttZoom || 1) * (e.deltaY < 0 ? 1.18 : 1 / 1.18));
}, { passive: false });
// ALT + wheel over the progress bar zooms too — the bar and the text track scale together
$("#pvBarRow").addEventListener("wheel", (e) => {
  if (!e.altKey) return;
  e.preventDefault();
  pvTtSetZoom((PV.ttZoom || 1) * (e.deltaY < 0 ? 1.18 : 1 / 1.18));
}, { passive: false });
// clicks on the overlaid controls must not bubble to the stage (which toggles play/pause)
$("#pvCtrlOverlay").addEventListener("click", (e) => e.stopPropagation());
// clicking anywhere that ISN'T a text-track bar leaves the red "edit" mode (capture so inner
// stopPropagation can't swallow it)
document.addEventListener("pointerdown", (e) => {
  if (e.target.closest(".pv-tt-bar")) return;
  document.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
}, true);
$("#previewWrap").addEventListener("mousemove", pvShowControls);

// ---------- keyboard shortcuts + help panel ----------
const SHORTCUTS = [
  ["1  2  3  4", "Switch tabs — Script · Scenes · Videos · Assemble"],
  ["A", "Approve the image (in the large image view)"],
  ["R", "Regenerate the image (in the large image view)"],
  ["← / →", "Large image: previous / next version"],
  ["Space / K", "Preview: play / pause"],
  ["← / →", "Preview: seek −5s / +5s"],
  ["F", "Preview: fullscreen"],
  ["M", "Preview: mute / unmute"],
  ["I", "Preview: images-only on/off"],
  ["Ctrl/⌘ + Z", "Undo the last change (delete, reorder, prompts…)"],
  ["Ctrl/⌘ + Shift + Z  ·  Ctrl + Y", "Redo"],
  ["?", "Show this shortcuts list"],
  ["Esc", "Close dialogs"],
];
(function buildShortcutHelp() {
  const bg = document.createElement("div");
  bg.className = "modal-bg"; bg.id = "shortcutHelp"; bg.hidden = true;
  const rows = SHORTCUTS.map(([k, d]) => `<div class="sc-row"><kbd>${k}</kbd><span>${d}</span></div>`).join("");
  bg.innerHTML = `<div class="modal confirm-modal"><h3>⌨ Keyboard Shortcuts</h3><div class="sc-list">${rows}</div><div class="modal-actions"><button class="primary" id="scClose">Got it</button></div></div>`;
  document.body.appendChild(bg);
  bdClose(bg, closeShortcutHelp);
  bg.querySelector("#scClose").addEventListener("click", closeShortcutHelp);
  const host = $(".tb-btns") || $(".tb-right"), reload = $("#reloadBtn"), left = $(".tb-left");
  let cdd = null;   // Credits dropdown — built inside if(host) below, but appended in the if(left) block, so it must live in this outer scope
  if (host) {   // Undo + Redo sit next to Reload on the right
    const ub = document.createElement("button"); ub.className = "ghost"; ub.id = "undoBtn"; ub.textContent = "↩ Undo"; ub.disabled = true;
    ub.addEventListener("click", doUndo); host.insertBefore(ub, reload || null);
    const rb = document.createElement("button"); rb.className = "ghost"; rb.id = "redoBtn"; rb.textContent = "↪ Redo"; rb.disabled = true;
    rb.addEventListener("click", doRedo); host.insertBefore(rb, reload || null);
    // History dropdown — recent image/video generation results; sits after Reload, opens a panel below it
    const dd = document.createElement("div"); dd.className = "hist-dd"; dd.id = "histDD";
    const hb = document.createElement("button"); hb.className = "ghost"; hb.id = "historyBtn"; hb.title = "Recent activity — generation results and notifications"; hb.textContent = "🕘 History";
    hb.addEventListener("click", (e) => { e.stopPropagation(); toggleHistory(); });
    const menu = document.createElement("div"); menu.className = "hist-menu"; menu.id = "histMenu";
    dd.appendChild(hb); dd.appendChild(menu);
    // Credits dropdown — live Kie.ai balance + spend history for the OPEN project's key; sits to History's right
    cdd = document.createElement("div"); cdd.className = "hist-dd credit-dd"; cdd.id = "creditDD";
    const cb = document.createElement("button"); cb.className = "ghost"; cb.id = "creditBtn"; cb.innerHTML = '<span class="ce-ic">💳</span>Credits';   // span lets us vertically nudge the low-sitting 💳; gap matches the other buttons' spacing
    cb.addEventListener("click", (e) => { e.stopPropagation(); toggleCredits(); });
    const cmenu = document.createElement("div"); cmenu.className = "hist-menu credit-menu"; cmenu.id = "creditMenu";
    cdd.appendChild(cb); cdd.appendChild(cmenu);
    // Wrap the Undo/Redo/Reload row + a History|Credits row into a column so they span EXACTLY the trio's
    // width (CSS align-items:stretch — zoom-proof, no pixel measuring that Ctrl-zoom would skew).
    const tbBtns = document.querySelector(".tb-btns");
    if (tbBtns && tbBtns.parentNode) {
      const stack = document.createElement("div"); stack.className = "tb-stack";
      tbBtns.parentNode.insertBefore(stack, tbBtns);
      stack.appendChild(tbBtns); stack.appendChild(dd);   // History spans the full trio width below it
    } else if (reload && reload.parentNode) reload.after(dd);
    else host.appendChild(dd);
  }
  if (left) {   // far-left block: a 3-col x 2-row grid — row1 = Sign Out / Shortcuts / Credits, row2 = Home / project / Settings
    const b = document.createElement("button"); b.className = "ghost"; b.id = "shortcutBtn"; b.title = "Keyboard shortcuts (?)"; b.textContent = "⌨ Shortcuts"; b.addEventListener("click", toggleShortcutHelp);
    left.appendChild(b);
    if (cdd) left.appendChild(cdd);   // Credits dropdown sits next to Shortcuts (its panel anchors to the left)
    // move Home + project + Settings DOWN from the centre into the far-left block's second row
    const home = $("#homeBtn"), proj = $(".proj-dd"), settings = $("#audienceBtn");
    [home, proj, settings].forEach(el => { if (el) left.appendChild(el); });
    const oldStudio = $("#studioBtnHeader"); if (oldStudio) oldStudio.remove();   // Studio is now a tab, not a header button
    left.classList.add("tb-left-grid");
  }
  // The centre column is now JUST the tab bar (Home/project/Settings moved left; Studio became a tab); pull it in
  // and vertically centre it between the header's two rows.
  const center = $("header .tb-center") || $(".tb-center");
  const tabsNav = $("header nav.tabs") || $("nav.tabs");
  if (center && tabsNav && !center.classList.contains("tb-center-tabs")) {
    center.appendChild(tabsNav);
    center.classList.add("tb-center-tabs");
  }
})();
function toggleShortcutHelp() { const h = $("#shortcutHelp"); if (h) h.hidden = !h.hidden; }
function closeShortcutHelp() { const h = $("#shortcutHelp"); if (h) h.hidden = true; }

// ---------- History dropdown: recent image/video generation results; click to jump to that scene ----------
let HISTORY = [], HIST_UNREAD = 0;
const HIST_MAX = 10, HIST_TTL = 10 * 60 * 1000;   // keep the last 10 items; drop any older than 10 minutes
function purgeHistory() {
  const now = Date.now(), before = HISTORY.length;
  HISTORY = HISTORY.filter(ev => now - ev.t < HIST_TTL);
  if (HISTORY.length > HIST_MAX) HISTORY.length = HIST_MAX;
  if (HISTORY.length !== before) {
    HIST_UNREAD = Math.min(HIST_UNREAD, HISTORY.length);
    const menu = document.getElementById("histMenu");
    if (menu && menu.classList.contains("open")) renderHistory();
    updateHistBadge();
  }
}
setInterval(purgeHistory, 30000);   // periodic expiry sweep
function _histBump() {
  if (HISTORY.length > HIST_MAX) HISTORY.length = HIST_MAX;
  const menu = document.getElementById("histMenu");
  if (menu && menu.classList.contains("open")) renderHistory();   // live-update while open
  else { HIST_UNREAD++; updateHistBadge(); }                      // else flag an unread dot
}
function pushHistory(kind, id, ok) {
  HISTORY.unshift({ type: "scene", kind, id, ok, t: Date.now() });
  _histBump();
}
// mirror any toast message into the History panel as a plain (non-navigable) entry
function histLog(msg, kind) {
  const m = String(msg || "").trim();
  if (!m) return;
  HISTORY.unshift({ type: "msg", msg: m, kind, ok: kind !== "err" && kind !== "warn", t: Date.now() });
  _histBump();
}
function resetHistory() {
  HISTORY = []; HIST_UNREAD = 0; updateHistBadge();
  const m = document.getElementById("histMenu"); if (m && m.classList.contains("open")) renderHistory();
}
function updateHistBadge() { const b = document.getElementById("historyBtn"); if (b) b.classList.toggle("has-unread", HIST_UNREAD > 0); }
// copy a history entry's full text to the clipboard (with a plain-textarea fallback for older WebView2)
function histCopyText(s) {
  const t = String(s == null ? "" : s);
  const fb = () => { try { const ta = document.createElement("textarea"); ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); document.body.removeChild(ta); } catch (_) {} };
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).catch(fb);
    else fb();
  } catch (_) { fb(); }
  try { toast("Copied to clipboard", "ok", 1400, { noHist: true }); } catch (_) {}
}
function histAgo(t) {
  const s = Math.max(0, (Date.now() - t) / 1000);
  const m = Math.floor(s / 60); if (m < 1) return "just now";
  if (m < 60) return m + "m ago";
  const h = Math.floor(m / 60); if (h < 24) return h + "h ago";
  return Math.floor(h / 24) + "d ago";
}
function renderHistory() {
  const menu = document.getElementById("histMenu"); if (!menu) return;
  const now = Date.now();
  HISTORY = HISTORY.filter(ev => now - ev.t < HIST_TTL);   // drop items older than 10 min when shown
  menu.innerHTML = "";
  const head = document.createElement("div"); head.className = "hist-head"; head.textContent = "Recent activity"; menu.appendChild(head);
  if (!HISTORY.length) {
    const e = document.createElement("div"); e.className = "hist-empty"; e.textContent = "No activity yet — results and messages will show up here."; menu.appendChild(e); return;
  }
  HISTORY.slice(0, HIST_MAX).forEach(ev => {
    const scene = ev.type === "scene";
    let navId = scene ? ev.id : null, navKind = scene ? ev.kind : null;
    if (!scene && ev.msg) {                        // a plain message that names a scene → let it jump too
      const m = ev.msg.match(/Scene\s+(\d+)/i);
      if (m) { navId = +m[1]; navKind = /video/i.test(ev.msg) ? "Video" : "Image"; }
    }
    const clickable = navId != null;
    const fullText = scene ? `${ev.kind} ${ev.ok ? "generated" : "failed"}: Scene ${ev.id}` : (ev.msg || "");
    const it = document.createElement(clickable ? "button" : "div");
    if (clickable) it.type = "button";
    it.className = "hist-item" + (scene ? "" : " hist-msg" + (clickable ? " hist-nav" : ""));
    const dot = document.createElement("span"); dot.className = "hist-dot " + (ev.ok ? "ok" : "err");
    const tx = document.createElement("span"); tx.className = "hist-txt";
    tx.textContent = fullText;
    const tm = document.createElement("span"); tm.className = "hist-time"; tm.textContent = histAgo(ev.t);
    // copy the FULL text of this entry so an error can be pasted straight into a chat
    const cp = document.createElement("button"); cp.type = "button"; cp.className = "hist-copy"; cp.title = "Copy this message";
    cp.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
    cp.addEventListener("click", (e) => {
      e.stopPropagation(); histCopyText(fullText);
      cp.classList.add("copied"); cp.title = "Copied"; setTimeout(() => { cp.classList.remove("copied"); cp.title = "Copy this message"; }, 1400);
    });
    it.appendChild(dot); it.appendChild(tx); it.appendChild(tm); it.appendChild(cp);
    if (clickable) {
      it.title = "Go to Scene " + navId + " in " + (navKind === "Video" ? "Videos" : "Scenes & Images");
      it.addEventListener("click", (e) => { e.stopPropagation(); histGoto({ kind: navKind, id: navId }); });
    } else {
      it.classList.add("hist-expandable");
      it.title = "Click to see the full message";
      it.addEventListener("click", (e) => { e.stopPropagation(); it.classList.toggle("hist-full"); });   // expand/collapse the full text
    }
    menu.appendChild(it);
  });
  const foot = document.createElement("div"); foot.className = "hist-foot";   // centered Clear at the very bottom
  const clr = document.createElement("button"); clr.type = "button"; clr.className = "hist-clear"; clr.textContent = "Clear";
  clr.title = "Clear activity history";
  clr.addEventListener("click", (e) => { e.stopPropagation(); resetHistory(); });
  foot.appendChild(clr); menu.appendChild(foot);
}
function openHistory() { const m = document.getElementById("histMenu"); if (!m) return; HIST_UNREAD = 0; updateHistBadge(); renderHistory(); m.classList.add("open"); document.body.classList.add("hist-open"); }
function closeHistory() { const m = document.getElementById("histMenu"); if (m) m.classList.remove("open"); document.body.classList.remove("hist-open"); }
function toggleHistory() { const m = document.getElementById("histMenu"); if (!m) return; m.classList.contains("open") ? closeHistory() : openHistory(); }
function histGoto(ev) {
  closeHistory();
  const tab = ev.kind === "Video" ? "videos" : "scenes";
  activateTab(tab);
  const sel = tab === "videos" ? `#videosList .video-row[data-id="${ev.id}"]` : `#scenesList .scene-row[data-id="${ev.id}"]`;
  setTimeout(() => {   // let the tab panel swap + render first
    const row = document.querySelector(sel);
    if (row) { row.scrollIntoView({ behavior: "smooth", block: "center" }); row.classList.add("hist-flash"); setTimeout(() => row.classList.remove("hist-flash"), 1400); }
  }, 90);
}
document.addEventListener("click", (e) => { if (!e.target.closest("#histDD")) closeHistory(); });   // click-away closes
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeHistory(); });

// ---------- Credits dropdown: live Kie.ai balance + real spend history + local generation counts ----------
function toggleCredits() { const m = document.getElementById("creditMenu"); if (!m) return; m.classList.contains("open") ? closeCredits() : openCredits(); }
function closeCredits() { const m = document.getElementById("creditMenu"); if (m) m.classList.remove("open"); document.body.classList.remove("hist-open"); }
function openCredits() {
  const m = document.getElementById("creditMenu"); if (!m) return;
  m.classList.add("open"); document.body.classList.add("hist-open");
  renderCredits();
}
function creditAgo(t) { return histAgo(t * 1000); }   // ledger stamps are epoch SECONDS
function localGenCounts() {
  let imgs = 0, vids = 0;
  (DOC && DOC.scenes || []).forEach(s => {
    imgs += ((s.image && s.image.versions) || []).length;
    if (s.video && (s.video.file || s.video.status === "ready")) vids += 1;   // one file per scene (overwritten on regen)
  });
  return { imgs, vids };
}
async function renderCredits() {
  const menu = document.getElementById("creditMenu"); if (!menu) return;
  menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Loading…</div>`;
  if (!PROJECT) { menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Open a project first.</div>`; return; }
  let r; try { r = await api.credits(PROJECT); } catch (e) { r = { error: "request failed" }; }
  const g = localGenCounts();
  const localBlock =
    `<div class="cr-sec-t">This project (generated)</div>
     <div class="cr-local"><span>${g.imgs} image${g.imgs === 1 ? "" : "s"}</span><span>${g.vids} video${g.vids === 1 ? "" : "s"}</span></div>
     <div class="cr-note">Local count of what this project has generated.</div>`;
  if (r && r.keyPresent === false) {
    menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">This project has no Kie API key.<br>Add it under Settings → API Keys.</div>`;
    return;
  }
  if (!r || r.error) {
    menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Couldn't reach Kie.ai${r && r.error ? " (" + r.error + ")" : ""}.<br>Try again shortly.</div>` +
      `<div class="cr-refresh-wrap"><button class="cr-refresh">↻ Refresh</button></div>`;
    menu.querySelector(".cr-refresh").addEventListener("click", (e) => { e.stopPropagation(); renderCredits(); });
    return;
  }
  const bal = (r.balance != null) ? r.balance.toLocaleString(undefined, { maximumFractionDigits: 2 }) : "—";
  let spendRows;
  if (r.history && r.history.length) {
    spendRows = r.history.map(h =>
      `<div class="cr-spend"><span class="cr-dot"></span><span class="cr-amt">−${h.spent.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span><span class="cr-bal">→ ${h.balance.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span><span class="cr-time">${creditAgo(h.t)}</span></div>`
    ).join("");
  } else {
    spendRows = `<div class="cr-empty">No spend recorded yet. It builds up as your balance changes while the app is open.</div>`;
  }
  const tracked = (r.tracked_spend || 0).toLocaleString(undefined, { maximumFractionDigits: 2 });
  menu.innerHTML =
    `<div class="hist-head">Credits</div>
     <div class="cr-balance"><span class="cr-bal-num">${bal}</span><span class="cr-bal-lbl">credits left · Kie.ai</span></div>
     ${localBlock}
     <div class="cr-sec-t">Spending history <span class="cr-tracked">${tracked} tracked</span></div>
     <div class="cr-spend-list">${spendRows}</div>
     <div class="cr-refresh-wrap"><button class="cr-refresh">↻ Refresh</button></div>`;
  menu.querySelector(".cr-refresh").addEventListener("click", (e) => { e.stopPropagation(); renderCredits(); });
}
document.addEventListener("click", (e) => { if (!e.target.closest("#creditDD")) closeCredits(); });   // click-away closes
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeCredits(); });
function pvSeekBy(delta) {
  if (!PV.m) return;
  const vo = $("#pvVo");
  const t = Math.min(PV.m.duration, Math.max(0, (vo.currentTime || 0) + delta));
  PV.seg = -1; PV.cap = -1;
  vo.currentTime = t; pvRender(t);
  if (!vo.paused) pvPlay();
}
function _typing(e) { const t = e.target; return t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable); }
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !_typing(e)) { e.preventDefault(); if (e.shiftKey) { if (!(window._tabRedo && window._tabRedo())) doRedo(); } else { if (!(window._tabUndo && window._tabUndo())) doUndo(); } return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y" && !_typing(e)) { e.preventDefault(); doRedo(); return; }
  if (_typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
  const help = $("#shortcutHelp");
  if (e.key === "Escape") { if (help && !help.hidden) closeShortcutHelp(); return; }
  if (e.key === "?") { e.preventDefault(); toggleShortcutHelp(); return; }
  // don't hijack keys while a dialog/lightbox is open, or on the home screen
  const dialogOpen = (help && !help.hidden) || [...document.querySelectorAll(".modal-bg")].some(m => !m.hidden) || $$(".lightbox").length > 0;
  if (dialogOpen || document.body.classList.contains("on-home") || !PROJECT) return;
  if (["1", "2", "3", "4", "5", "6"].includes(e.key)) {
    e.preventDefault();
    activateTab(["script", "scenes", "videos", "testimonials", "studio", "export"][+e.key - 1]);   // 5 = Studio, 6 = Assemble
    return;
  }
  // preview controls (only when the Assemble tab with a built preview is active)
  if (PV.m && $("#tab-export").classList.contains("active")) {
    const k = e.key.toLowerCase();
    if (e.key === " " || k === "k") { e.preventDefault(); pvToggle(); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); pvSeekBy(-5); }
    else if (e.key === "ArrowRight") { e.preventDefault(); pvSeekBy(5); }
    else if (k === "f") { e.preventDefault(); pvFull(); }
    else if (k === "m") { e.preventDefault(); pvMute(); }
    else if (k === "i") { e.preventDefault(); pvImagesOnly(); }
  }
});

// Single-page login: the form lives inside the home. On success the form fades out, the project
// list + app chrome appear IN PLACE, and boot() fills the list — the pipeline animation + title
// never restart (same elements throughout), so it feels like one continuous page, not two.
function wireLoginGate() {
  const form = document.getElementById("homeLogin");
  if (!form) { boot(); return; }                         // safety: no form rendered → just boot
  // remember the last username/password (desktop app asks to sign in every launch, so pre-fill it)
  try {
    const su = localStorage.getItem("savedUser"), sp = localStorage.getItem("savedPass");
    if (su && form.username) form.username.value = su;
    if (sp && form.password) form.password.value = sp;
    if (su && sp) { const b = form.querySelector("button[type=submit]"); if (b) setTimeout(() => b.focus(), 50); }
  } catch (_) {}
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]");
    const err = document.getElementById("loginErr");
    if (err) err.hidden = true;
    // native validation is off (no OS-language "fill this field" popups) → check here, in English
    if (!(form.username.value || "").trim() || !(form.password.value || "")) {
      if (err) { err.textContent = "Enter your username and password."; err.hidden = false; }
      return;
    }
    btn.disabled = true;
    try {
      const r = await fetch("/login", { method: "POST", body: new FormData(form) });
      if (r.ok) {
        window.AUTHED = true;
        try { localStorage.setItem("savedUser", form.username.value || ""); localStorage.setItem("savedPass", form.password.value || ""); } catch (_) {}
        // Sign-in is a fresh start → land on the project picker (home), not the last-opened project.
        try { localStorage.removeItem("lastProject"); localStorage.removeItem("lastTab"); localStorage.removeItem("lastTitle"); } catch (_) {}
        document.body.classList.remove("pre-auth");      // reveal header/tabs + the project list
        const sub = document.querySelector(".home-sub"); // cross-fade the subtitle text
        if (sub) { sub.style.opacity = "0"; setTimeout(() => { sub.textContent = "Open a project or create a new one"; sub.style.opacity = "1"; }, 220); }
        form.classList.add("login-hide");                // fade the form out FIRST, then load the
        setTimeout(() => { form.remove(); boot(); }, 300); // projects so they glide into the recentered space (no jump)
        return;
      }
      const d = await r.json().catch(() => ({}));
      if (err) { err.textContent = ((d && d.error) || "Wrong username or password.") + " [" + r.status + "]"; err.hidden = false; }
    } catch (ex) {
      if (err) { err.textContent = "Couldn't reach the server (" + (ex && ex.message ? ex.message : ex) + ")."; err.hidden = false; }
    }
    btn.disabled = false;
  });
}

// ================= STUDIO (standalone + per-project image workshop) =================
(function studioInit() {
  const $s = (id) => document.getElementById(id);
  let SCOPE = "_global";       // "_global" (no project) or the project name; data isolated per scope
  let genRefs = [];            // uploaded input refs for the CURRENT sub-mode
  // each sub-mode remembers its own prompt + refs AND its own result / in-progress job (job, item, poll, kind)
  // so switching modes mid-generation never loses it — you return to exactly where you left off.
  const _blankMode = () => ({ prompt: "", refs: [], job: null, item: null, poll: null, kind: null });
  let modeState = { text: _blankMode(), i2i: _blankMode(), i2v: _blankMode(), edit: _blankMode() };
  let mkRef = null;            // product ref for Mockup
  let curView = "gen";         // "gen" (Image & Mockup) | "faq" — drives what header Undo/Redo act on
  let poll = null;
  const imgUrl = (rel) => `/api/studio/img/${SCOPE}/${rel}`;
  // shared inline icons (proper SVGs, not emoji)
  const SVG_DL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
  const SVG_REFRESH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>';
  const SVG_REUSE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9 9 0 0 1 6.4 2.6L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-6.4-2.6L3 16"/><path d="M3 21v-5h5"/></svg>';
  const SVG_SEND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3"/><path d="M8 7l4-4 4 4"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/></svg>';

  // right-side result placeholders (Image Generation + Product Mockups) — same look/actions as Scene & Image
  const phFor = (kind) => kind === "mockup" ? "Your mockups will appear here" : (kind === "i2v" ? "Your video will appear here" : "Your generated image will appear here");
  function clearResult(el, ph) {
    if (!el) return;
    const o = el.querySelector(".gen-overlay"); if (o) o.remove();
    el.innerHTML = "";
    const d = document.createElement("div"); d.className = "placeholder"; d.textContent = ph; el.appendChild(d);
  }
  function showResult(el, it, kind) {
    if (!el || !it) return;
    const isVid = it.kind === "video";
    if (isVid) kind = "i2v";
    el.innerHTML = "";
    if (isVid) {
      const v = document.createElement("video"); v.src = imgUrl(it.file); v.controls = true; v.playsInline = true; v.loop = true; v.muted = false;
      v.controlsList = "nodownload noremoteplayback";   // hide the broken native ⋮ download; the ⤓ button below downloads
      el.appendChild(v);
    } else {
      const img = document.createElement("img"); img.src = imgUrl(it.file);
      img.addEventListener("click", () => { try { studioLightbox(it); } catch (_) {} });
      el.appendChild(img);
    }
    // top-right actions — identical to Scene & Image (approve ✓ = favourite, ↻ regenerate, remove)
    const ov = document.createElement("div"); ov.className = "img-actions";
    const bApprove = document.createElement("button"); bApprove.className = "ia approve" + (it.fav ? " on" : "");
    bApprove.textContent = "✓"; bApprove.title = it.fav ? "Favourited (click to remove)" : "Approve — mark as favourite";
    bApprove.addEventListener("click", async (e) => {
      e.stopPropagation();
      const willFav = !bApprove.classList.contains("on");
      bApprove.classList.toggle("on", willFav); it.fav = willFav;
      const gi = stItems.find(x => x.id === it.id); if (gi) gi.fav = willFav;
      try { await api.studioFav(SCOPE, it.id, willFav); } catch (_) {}
      renderGallery();
      toast(willFav ? "Added to favourites ★" : "Removed from favourites", willFav ? "ok" : "info", 1800);
    });
    const bChange = document.createElement("button"); bChange.className = "ia change"; bChange.innerHTML = SVG_REFRESH; bChange.title = "Regenerate";
    bChange.addEventListener("click", (e) => { e.stopPropagation(); regenerate(kind); });
    const bRemove = document.createElement("button"); bRemove.className = "ia remove"; bRemove.title = "Remove this image";
    bRemove.innerHTML = (typeof TRASH_SVG !== "undefined" ? TRASH_SVG : "🗑");
    bRemove.addEventListener("click", (e) => { e.stopPropagation(); studioDeleteItem(it); clearResult(el, phFor(kind)); });
    ov.appendChild(bApprove); ov.appendChild(bChange); ov.appendChild(bRemove); el.appendChild(ov);
    // download — bottom-right (same design as the top-right actions)
    const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";
    const bDl = document.createElement("button"); bDl.className = "ia download"; bDl.title = "Download this image";
    bDl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
    bDl.addEventListener("click", (e) => { e.stopPropagation(); downloadUrl(imgUrl(it.file), `studio_${it.id}.${isVid ? "mp4" : "png"}`, isVid ? "studio video" : "studio image"); });
    ovb.appendChild(bDl); el.appendChild(ovb);
  }

  let _studioScope = null;
  function openStudio() {
    const scope = PROJECT || "_global";
    // Returning to the SAME Studio while it still has a running generation or a result → KEEP everything and
    // just re-show the current mode, so leaving to Scene & Image / Video and coming back resumes seamlessly.
    const resume = (scope === _studioScope) && Object.values(modeState).some(ms => ms && (ms.job || ms.item));
    SCOPE = scope; _studioScope = scope;
    // The FAQ's voice-over language is its own control, but it used to open on English every single time
    // — nothing remembered it — so a German FAQ was one forgotten dropdown away from being aligned as
    // English. Start it on the project's subtitle language instead, and never stomp a manual choice.
    const _fl = $s("faqLang");
    if (_fl) {
      if (!_fl._wired) { _fl._wired = 1; _fl.addEventListener("change", () => { _fl._touched = 1; }); }
      if (!_fl._touched) {
        const want = (PROJECT && typeof subLangCode === "function") ? subLangCode() : "en";
        if ([..._fl.options].some(o => o.value === want)) _fl.value = want;
      }
    }
    document.body.classList.add("studio-open");
    const hint = $s("studioScopeHint");
    if (hint) hint.textContent = PROJECT
      ? `This project — “${(DOC && DOC.title) || PROJECT}”. Kept separate from your global Studio.`
      : "Global — not tied to any project. Project work stays inside its own project.";
    if (resume) {
      restoreModeResult(stMode);                                   // bring back the in-progress / finished result (its poll kept running in the background)
    } else {
      genRefs = []; mkRef = null;
      resetStModes();   // fresh per-mode prompt/refs, back to Text to Image
      clearResult($s("stResult"), phFor("gen"));
    }
    renderMkIdle();   // product upload drop lives inside the mockup grid area
    $s("stGenStatus").hidden = true; $s("stMkStatus").hidden = true;
    loadGallery();
    window.scrollTo(0, 0);
  }
  function closeStudio() {
    document.body.classList.remove("studio-open");
    if (poll) { clearInterval(poll); poll = null; }
    // NOTE: do NOT stop the per-mode generation polls here — leaving to another tab should let the Studio
    // job keep running and updating, so returning resumes exactly where it left off.
  }
  window.openStudio = openStudio; window.closeStudio = closeStudio;

  const scrollTo = (sel) => { const e = document.querySelector(sel); if (e) e.scrollIntoView({ behavior: "smooth", block: "start" }); };

  async function uploadFile(file) {
    const r = await api.studioUpload(SCOPE, file);
    if (r.error) { toast(r.error, "err"); return null; }
    return r.ref;
  }
  function thumb(ref, onRemove) {
    const c = document.createElement("div"); c.className = "studio-up";
    const im = document.createElement("img"); im.src = imgUrl(ref); c.appendChild(im);
    const x = document.createElement("button"); x.type = "button"; x.className = "ref-x"; x.title = "Remove"; x.textContent = "×";
    x.addEventListener("click", onRemove); c.appendChild(x);
    return c;
  }
  function renderGenUploads() {
    const el = $s("stUpList"); if (!el) return; el.innerHTML = "";
    genRefs.forEach((ref, i) => el.appendChild(thumb(ref, () => { genRefs.splice(i, 1); renderGenUploads(); })));
  }
  // Product Mockups: the upload + the product preview + the generated candidates all live in the SAME wide grid area
  function renderMkIdle() {
    const grid = $s("stMkResult"); if (!grid) return;
    grid.classList.remove("has-cands"); grid.innerHTML = "";
    if (mkRef) {
      const c = document.createElement("div"); c.className = "preview img-preview studio-cand";
      const im = document.createElement("img"); im.src = imgUrl(mkRef); c.appendChild(im);
      const ov = document.createElement("div"); ov.className = "img-actions";
      const x = document.createElement("button"); x.className = "ia remove"; x.title = "Remove the product image"; x.innerHTML = (typeof TRASH_SVG !== "undefined" ? TRASH_SVG : "×");
      x.addEventListener("click", (e) => { e.stopPropagation(); mkRef = null; renderMkIdle(); });
      ov.appendChild(x); c.appendChild(ov); grid.appendChild(c);
    } else {
      const drop = document.createElement("button"); drop.type = "button"; drop.className = "mkgrid-drop"; drop.title = "Upload your product image";
      drop.innerHTML = '<span class="mkgrid-plus">＋</span><span class="mkgrid-hint">Upload your product image</span>';
      drop.addEventListener("click", () => $s("stMkInput").click());
      grid.appendChild(drop);
    }
  }
  $s("stUpInput").addEventListener("change", async (e) => {
    const files = [...e.target.files]; e.target.value = "";
    // up to 4 reference images for every mode incl. Image to Video (models that accept multiple refs — Grok /
    // Veo / Kling 2.6 / Seedance 1.5 — use them all; single-frame models just use the first).
    for (const f of files) { if (genRefs.length >= 4) { toast("Up to 4 images.", "info"); break; } const ref = await uploadFile(f); if (ref) { genRefs.push(ref); renderGenUploads(); } }
  });
  $s("stMkInput").addEventListener("change", async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    const ref = await uploadFile(f); if (ref) { mkRef = ref; renderMkIdle(); }
  });

  // --- generate helpers so the ↻ Regenerate button can replay the exact last request ---
  let lastGenPayload = null, lastMkPayload = null, lastVidPayload = null, curJobId = null, mkPoll = null;
  let mkApproved = new Set(), mkHidden = new Set(), mkSel = new Map();   // mkSel: id -> file (multi-select for bulk download)
  function mkUpdateSelBar() {
    let bar = $s("mkSelBar");
    const grid = $s("stMkResult");
    if (!bar) {
      if (!grid || !grid.parentNode) return;
      bar = document.createElement("div"); bar.id = "mkSelBar"; bar.className = "mk-sel-bar"; bar.hidden = true;
      bar.innerHTML = '<span class="mk-sel-count"></span>'
        + '<button type="button" class="ghost" id="mkSelDl">⤓ Download Selected</button>'
        + '<button type="button" class="ghost" id="mkSelAll">Select All</button>'
        + '<button type="button" class="ghost sel-clear" id="mkSelClear">Clear</button>';
      grid.parentNode.insertBefore(bar, grid);
      $s("mkSelDl").addEventListener("click", mkDownloadSelected);
      $s("mkSelAll").addEventListener("click", () => {
        document.querySelectorAll("#stMkResult .studio-cand[data-mkid]").forEach(c => {
          const id = c.dataset.mkid, file = c.dataset.mkfile;
          if (id && file && !mkSel.has(id)) { mkSel.set(id, file); c.classList.add("mk-picked"); const cb = c.querySelector(".mk-pick"); if (cb) cb.checked = true; }
        });
        mkUpdateSelBar();
      });
      $s("mkSelClear").addEventListener("click", () => {
        mkSel.clear();
        document.querySelectorAll("#stMkResult .studio-cand.mk-picked").forEach(c => { c.classList.remove("mk-picked"); const cb = c.querySelector(".mk-pick"); if (cb) cb.checked = false; });
        mkUpdateSelBar();
      });
    }
    const n = mkSel.size;
    bar.hidden = n === 0;
    const c = bar.querySelector(".mk-sel-count"); if (c) c.textContent = n + (n === 1 ? " selected" : " selected");
    const dl = $s("mkSelDl"); if (dl) dl.textContent = `⤓ Download Selected (${n})`;
  }
  async function mkDownloadSelected() {
    const files = [...mkSel.values()];
    if (!files.length) return;
    const dl = $s("mkSelDl"); if (dl) { dl.disabled = true; dl.textContent = "⏳ Zipping…"; }
    let r; try { r = await api.studioDownloadZip(SCOPE, files); } catch (_) { r = { error: "request failed" }; }
    if (dl) dl.disabled = false;
    if (!r || r.error) { toast((r && r.error) || "Download failed", "err", 5000); mkUpdateSelBar(); return; }
    downloadUrl(imgUrl(r.file) + "?dl=" + encodeURIComponent("mockups.zip") + "&t=" + Date.now(), "mockups.zip", "mockups");
    toast(`Downloading ${r.count} mockups as a zip ✓`, "ok", 3000);
    mkUpdateSelBar();
  }
  function startGen(payload) { lastGenPayload = payload; runJob(api.studioGenerate(payload), $s("stGenStatus"), $s("stResult"), "gen"); }
  function startMk(payload) { lastMkPayload = payload; runMockup(payload); }
  function startVideo(payload) { lastVidPayload = payload; runVideo(payload); }
  function regenerate(kind) {
    if (kind === "mockup") { if (lastMkPayload) startMk(lastMkPayload); else toast("Nothing to regenerate yet.", "info"); }
    else if (kind === "i2v") { if (lastVidPayload) startVideo(lastVidPayload); else toast("Nothing to regenerate yet.", "info"); }
    else { if (lastGenPayload) startGen(lastGenPayload); else toast("Nothing to regenerate yet.", "info"); }
  }
  function runVideo(payload) {
    const genMode = "i2v", ms = modeState[genMode];
    const live = () => (stMode === genMode) ? $s("stResult") : null;   // only paint the shared result area while THIS mode is on screen
    const statusEl = $s("stGenStatus"); if (statusEl) statusEl.hidden = true;
    ms.item = null; ms.kind = "i2v";
    { const el = live(); if (el) { el.innerHTML = ""; addGenOverlay(el, "generating"); wireStopBtn(el); } }
    api.studioVideo(payload).then(r => {
      if (!r || r.error) { ms.job = null; const el = live(); if (el) clearResult(el, phFor("i2v")); toast((r && r.error) || "request failed", "err", 6000); try { playErrorChime(); } catch (_) {} return; }
      ms.job = r.job; if (stMode === genMode) curJobId = r.job;
      if (ms.poll) clearInterval(ms.poll);
      ms.poll = setInterval(async () => {
        let j; try { j = await api.studioJob(r.job); } catch (_) { return; }
        if (j.error) { clearInterval(ms.poll); ms.poll = null; ms.job = null; const el = live(); if (el) clearResult(el, phFor("i2v")); return; }
        await loadGallery();
        if (j.items && j.items.length) { ms.item = j.items[j.items.length - 1]; const el = live(); if (el) showResult(el, ms.item, "i2v"); }
        if (j.status === "done" || j.status === "cancelled") {
          clearInterval(ms.poll); ms.poll = null; ms.job = null; if (stMode === genMode) curJobId = null;
          const el = live(); if (el) { const o = el.querySelector(".gen-overlay"); if (o) o.remove(); if (!(j.items && j.items.length)) clearResult(el, phFor("i2v")); }
          if (j.status === "cancelled") toast("Stopped.", "info", 2500);
          else { const ok = j.items && j.items.length; toast(ok ? "Video ready." : ((j.errors && j.errors[0]) || "Video failed"), ok ? "ok" : "err", 6000); try { ok ? playNotifChime() : playErrorChime(); } catch (_) {} }
        }
      }, 2500);
    }).catch(() => { ms.job = null; const el = live(); if (el) clearResult(el, phFor("i2v")); toast("request failed", "err", 6000); });
  }
  function wireStopBtn(resultEl) {
    const sb = resultEl && resultEl.querySelector(".gen-stop"); if (!sb) return;
    sb.onclick = async (e) => { e.preventDefault(); e.stopPropagation(); sb.disabled = true; sb.textContent = "Stopping…";
      const jid = (modeState[stMode] && modeState[stMode].job) || curJobId;   // cancel the CURRENTLY-visible mode's job
      if (jid) { try { await api.studioCancel(jid); } catch (_) {} } };
  }

  async function runJob(startPromise, statusEl, _resultEl, kind) {
    const genMode = stMode, ms = modeState[genMode] || (modeState[genMode] = _blankMode());
    const live = () => (stMode === genMode) ? $s("stResult") : null;   // paint the shared result area only while THIS mode is on screen
    if (statusEl) statusEl.hidden = true;
    ms.item = null; ms.kind = kind;
    { const el = live(); if (el) { el.innerHTML = ""; addGenOverlay(el, "generating"); wireStopBtn(el); } }
    let r; try { r = await startPromise; } catch (_) { r = { error: "request failed" }; }
    if (r.error) { ms.job = null; const el = live(); if (el) clearResult(el, phFor(kind)); toast(r.error, "err", 6000); try { playErrorChime(); } catch (_) {} return; }
    ms.job = r.job; if (stMode === genMode) curJobId = r.job;
    if (ms.poll) clearInterval(ms.poll);
    ms.poll = setInterval(async () => {
      let j; try { j = await api.studioJob(r.job); } catch (_) { return; }
      if (j.error) { clearInterval(ms.poll); ms.poll = null; ms.job = null; const el = live(); if (el) clearResult(el, phFor(kind)); return; }
      await loadGallery();
      if (j.items && j.items.length) { ms.item = j.items[j.items.length - 1]; const el = live(); if (el) showResult(el, ms.item, kind); }
      if (j.status === "done" || j.status === "cancelled") {
        clearInterval(ms.poll); ms.poll = null; ms.job = null; if (stMode === genMode) curJobId = null;
        const el = live(); if (el) { const o = el.querySelector(".gen-overlay"); if (o) o.remove(); if (!(j.items && j.items.length)) clearResult(el, phFor(kind)); }
        if (j.status === "cancelled") toast("Stopped.", "info", 2500);
        else { const ok = j.items && j.items.length; toast(`Studio done — ${j.items.length}/${j.total} image(s)` + (j.errors && j.errors.length ? `, ${j.errors.length} failed` : ""), ok ? "ok" : "err", 5000); try { ok ? playNotifChime() : playErrorChime(); } catch (_) {} }
      }
    }, 2500);
  }

  // ---- Product Mockups: generate N CANDIDATES into a wide grid; only the ones the user Approves go to the gallery ----
  function clearMkGrid(text) {
    const grid = $s("stMkResult"); if (!grid) return;
    grid.classList.remove("has-cands");
    grid.innerHTML = ""; const d = document.createElement("div"); d.className = "placeholder"; d.textContent = text; grid.appendChild(d);
  }
  function mkCandCard(it) {
    const c = document.createElement("div"); c.className = "preview img-preview studio-cand";
    c.dataset.mkid = it.id; c.dataset.mkfile = it.file;
    if (mkSel.has(it.id)) c.classList.add("mk-picked");
    const img = document.createElement("img"); img.src = imgUrl(it.file);
    img.addEventListener("click", () => { try { studioLightbox(it); } catch (_) {} });
    c.appendChild(img);
    // multi-select checkbox (top-left) → bulk download
    const pick = document.createElement("label"); pick.className = "mk-pick-wrap"; pick.title = "Select for bulk download";
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.className = "mk-pick"; cb.checked = mkSel.has(it.id);
    cb.addEventListener("click", (e) => e.stopPropagation());
    cb.addEventListener("change", () => {
      if (cb.checked) { mkSel.set(it.id, it.file); c.classList.add("mk-picked"); }
      else { mkSel.delete(it.id); c.classList.remove("mk-picked"); }
      mkUpdateSelBar();
    });
    pick.appendChild(cb); c.appendChild(pick);
    const approved = mkApproved.has(it.id);
    const ov = document.createElement("div"); ov.className = "img-actions";
    const bA = document.createElement("button"); bA.className = "ia approve" + (approved ? " on" : ""); bA.textContent = "✓";
    bA.title = approved ? "Approved — saved to the gallery" : "Approve — save to the gallery";
    bA.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (mkApproved.has(it.id)) return;
      mkApproved.add(it.id); bA.classList.add("on"); bA.title = "Approved — saved to the gallery";
      try { await api.studioSave(SCOPE, it); } catch (_) {}
      loadGallery(); toast("Saved to the gallery ✓", "ok", 1800);
    });
    const bR = document.createElement("button"); bR.className = "ia remove"; bR.title = "Delete this mockup"; bR.innerHTML = (typeof TRASH_SVG !== "undefined" ? TRASH_SVG : "🗑");
    bR.addEventListener("click", async (e) => { e.stopPropagation(); mkHidden.add(it.id); mkSel.delete(it.id); c.remove(); mkUpdateSelBar(); try { await api.studioDelete(SCOPE, it.id); await loadGallery(); } catch (_) {} });   // auto-saved -> also drop from the gallery
    ov.appendChild(bA); ov.appendChild(bR); c.appendChild(ov);
    const ovb = document.createElement("div"); ovb.className = "img-actions img-actions-bl";
    const bDl = document.createElement("button"); bDl.className = "ia download"; bDl.title = "Download this mockup";
    bDl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 20h14"/></svg>';
    bDl.addEventListener("click", (e) => { e.stopPropagation(); downloadUrl(imgUrl(it.file), `mockup_${it.id}.png`, "mockup"); });
    ovb.appendChild(bDl); c.appendChild(ovb);
    return c;
  }
  function mkStatusTile(status) {   // status = "generating" | "queued"
    const t = document.createElement("div"); t.className = "preview img-preview studio-cand studio-cand-gen";
    addGenOverlay(t, status);
    if (status === "generating") wireStopBtn(t);
    else { const sb = t.querySelector(".gen-stop"); if (sb) sb.remove(); }   // only the active one shows Stop
    return t;
  }
  function renderMkQueue(grid, total) {   // initial view: 1 generating + the rest queued
    grid.classList.add("has-cands"); grid.innerHTML = "";
    for (let i = 0; i < total; i++) grid.appendChild(mkStatusTile(i === 0 ? "generating" : "queued"));
  }
  function renderMkCandidates(items, j) {
    const grid = $s("stMkResult"); if (!grid) return;
    grid.classList.add("has-cands"); grid.innerHTML = "";
    const shown = (items || []).filter(it => !mkHidden.has(it.id));
    shown.forEach(it => grid.appendChild(mkCandCard(it)));
    mkUpdateSelBar();
    const running = j && j.status !== "done" && j.status !== "cancelled";
    if (running) {
      const total = (j && j.total) || shown.length;
      const done = (j && typeof j.done === "number") ? j.done : shown.length;
      const remaining = Math.max(0, total - done);         // the one generating + the ones still queued
      for (let i = 0; i < remaining; i++) grid.appendChild(mkStatusTile(i === 0 ? "generating" : "queued"));
    }
  }
  function runMockup(payload) {
    mkApproved = new Set(); mkHidden = new Set(); mkSel = new Map(); mkUpdateSelBar();
    const grid = $s("stMkResult"); if (grid) renderMkQueue(grid, Math.max(1, payload.count || 1));
    api.studioMockup(payload).then(r => {
      if (!r || r.error) { toast((r && r.error) || "request failed", "err", 6000); try { playErrorChime(); } catch (_) {} renderMkIdle(); return; }
      curJobId = r.job;
      if (mkPoll) clearInterval(mkPoll);
      mkPoll = setInterval(async () => {
        let j; try { j = await api.studioJob(r.job); } catch (_) { return; }
        if (j.error) { clearInterval(mkPoll); mkPoll = null; curJobId = null; renderMkIdle(); return; }
        renderMkCandidates(j.items || [], j);
        if (j.status === "done" || j.status === "cancelled") {
          clearInterval(mkPoll); mkPoll = null; curJobId = null;
          const items = j.items || [];
          if (j.status === "done" && items.length) {
            // AUTO-PERSIST: save every generated mockup to the gallery so they're NEVER lost when you navigate
            // away (you delete the ones you don't want instead of approving the ones you do).
            for (const it of items) { try { await api.studioSave(SCOPE, it); mkApproved.add(it.id); } catch (_) {} }
            try { await loadGallery(); } catch (_) {}
          }
          renderMkCandidates(items, j);
          if (!items.length) renderMkIdle();
          if (j.status === "cancelled") toast("Stopped.", "info", 2500);
          else { const ok = items.length; toast(`Mockups ready — ${items.length} saved to the gallery. Tick the ones to download, or delete any you don't want.`, ok ? "ok" : "err", 5500); try { ok ? playNotifChime() : playErrorChime(); } catch (_) {} }
        }
      }, 2500);
    }).catch(() => { toast("request failed", "err", 6000); try { playErrorChime(); } catch (_) {} renderMkIdle(); });
  }
  // populate the Quantity (1..20) dropdown
  (function fillQty() { const sel = $s("stMkCount"); if (!sel) return; for (let i = 1; i <= 20; i++) sel.appendChild(new Option(i, i, false, i === 5)); })();
  // Image Generation sub-modes: Text to Image | Image to Image | Edit Image — each keeps its OWN prompt + refs
  let stMode = "text";
  function applyStModeUI(m) {
    $$(".stmode").forEach(b => b.classList.toggle("active", b.dataset.mode === m));
    const up = $s("stUpBlock"); if (up) up.classList.toggle("collapsed", m === "text");   // upload area for i2i / i2v / edit (animated collapse)
    const pr = $s("stPrompt"); if (pr) pr.style.display = "";                        // i2v mirrors i2i: prompt box on top, upload below
    const mw = $s("stModelWrap"), en = $s("stEditNote");
    if (mw) mw.hidden = (m === "edit");
    if (en) en.hidden = (m !== "edit");
    const img = $s("stImgControls"), vid = $s("stVidControls");
    if (img) img.hidden = (m === "i2v");
    if (vid) vid.hidden = (m !== "i2v");
    const btn = $s("stGenBtn"); if (btn) btn.textContent = m === "i2v" ? "Generate Video" : (m === "edit" ? "Edit Image" : "Generate Image");
    if (pr) pr.placeholder = m === "text" ? "Describe The Image To Create…" : (m === "edit" ? "Describe The Edit To Make To The Reference Image…" : (m === "i2v" ? "Describe The Motion / Camera For The Video (optional)…" : "Describe How To Combine / Use The Reference Image(s)…"));
    if (up) { const add = $s("stUpAdd"); if (add) add.title = (m === "i2v") ? "Upload the image to animate" : "Add reference image(s) from your computer"; }
  }
  function placeStModeSlider(anim) {
    const nav = document.querySelector(".studio-submodes"), sl = $s("stmodeSlider"), act = nav && nav.querySelector(".stmode.active");
    if (!nav || !sl || !act) return;
    sl.style.transition = anim ? "" : "none";
    sl.style.width = act.offsetWidth + "px";
    sl.style.transform = `translateX(${act.offsetLeft}px)`;
    if (!anim) { void sl.offsetWidth; sl.style.transition = ""; }
  }
  // render a mode's SAVED result (or its still-running generation) into the shared #stResult area
  function restoreModeResult(m) {
    const resultEl = $s("stResult"); if (!resultEl) return;
    const ms = modeState[m] || {};
    curJobId = ms.job || null;
    if (ms.job) { resultEl.innerHTML = ""; addGenOverlay(resultEl, "generating"); wireStopBtn(resultEl); }   // still generating → show the overlay; its poll keeps updating
    else if (ms.item) { showResult(resultEl, ms.item, ms.kind || (m === "i2v" ? "i2v" : "gen")); }            // finished → show what it produced
    else { clearResult(resultEl, phFor(m === "i2v" ? "i2v" : "gen")); }                                       // nothing yet → placeholder
  }
  function setStMode(m) {
    const pr = $s("stPrompt");
    if (pr) { modeState[stMode] = Object.assign(modeState[stMode] || _blankMode(), { prompt: pr.value, refs: genRefs.slice() }); }   // keep job/item/poll for the mode we leave
    stMode = m;
    const st = modeState[m] || _blankMode();                                   // restore the mode we're entering
    if (pr) pr.value = st.prompt;
    genRefs = (st.refs || []).slice();
    renderGenUploads();
    applyStModeUI(m);
    placeStModeSlider(true);
    restoreModeResult(m);                                                      // bring back that mode's result / in-progress generation
  }
  function resetStModes() {
    Object.values(modeState).forEach(ms => { if (ms && ms.poll) clearInterval(ms.poll); });
    modeState = { text: _blankMode(), i2i: _blankMode(), i2v: _blankMode(), edit: _blankMode() };
    stMode = "text"; genRefs = [];
    if ($s("stPrompt")) $s("stPrompt").value = "";
    renderGenUploads(); applyStModeUI("text"); placeStModeSlider(false);
  }
  // ---- Image to Video controls (Duration / Quality / Model), fed from the Videos-tab model list ----
  const VID_FALLBACK = [
    { key: "grok-video-1-5", label: "Grok Imagine Video 1.5", durations: [4,6,8,10,12,15], resolutions: ["480p","720p","1080p"], defaultDur: 6, defaultRes: "1080p" },
    { key: "seedance-2-fast", label: "Seedance 2.0 Fast", durations: [4,5,6,7,8,9,10,11,12], resolutions: ["480p","720p"], defaultDur: 6, defaultRes: "720p" },
    { key: "seedance-2", label: "Seedance 2.0", durations: [4,5,6,7,8,9,10,11,12], resolutions: ["480p","720p","1080p","4k"], defaultDur: 5, defaultRes: "1080p" },
    { key: "veo-3-1", label: "Veo 3.1", durations: [4,6,8], resolutions: ["720p","1080p","4k"], defaultDur: 8, defaultRes: "1080p" },
    { key: "grok-imagine", label: "Grok Imagine", durations: [6,8,10,12,15,20,25,30], resolutions: ["480p","720p"], defaultDur: 6, defaultRes: "720p" },
  ];
  const vidModels = () => (typeof VIDEO_MODELS !== "undefined" && VIDEO_MODELS.length) ? VIDEO_MODELS : VID_FALLBACK;
  function fillVidDurRes() {
    const sel = $s("stVidModel"), dur = $s("stVidDur"), res = $s("stVidRes"); if (!sel || !dur || !res) return;
    const cfg = vidModels().find(m => m.key === sel.value) || vidModels()[0]; if (!cfg) return;
    dur.innerHTML = ""; cfg.durations.forEach(d => dur.appendChild(new Option(d + "s", d, false, d === cfg.defaultDur)));
    res.innerHTML = ""; cfg.resolutions.forEach(r => res.appendChild(new Option(r, r, false, r === cfg.defaultRes)));
  }
  function fillVidModel() {
    const sel = $s("stVidModel"); if (!sel) return;
    const cur = sel.value; sel.innerHTML = "";
    vidModels().forEach(m => sel.appendChild(new Option(m.label, m.key)));
    // default to Grok Imagine Video 1.5 (6s / 1080p come from its model config), like the Videos tab
    const def = "grok-video-1-5";
    if (cur && [...sel.options].some(o => o.value === cur)) sel.value = cur;
    else if ([...sel.options].some(o => o.value === def)) sel.value = def;
    fillVidDurRes();
  }
  { const vm = $s("stVidModel"); if (vm) vm.addEventListener("change", fillVidDurRes); }
  fillVidModel();
  // Studio camera lock (default ON) — mirrors the Videos-tab button: locked = completely still camera.
  let stVidCamLock = true;
  { const cb = $s("stVidCam");
    if (cb) { const paint = () => { cb.classList.toggle("on", stVidCamLock); cb.textContent = stVidCamLock ? "🔒 Camera locked" : "🎥 Camera free"; };
      cb.addEventListener("click", () => { stVidCamLock = !stVidCamLock; paint(); }); paint(); } }
  $$(".stmode").forEach(b => b.addEventListener("click", () => setStMode(b.dataset.mode)));
  applyStModeUI("text");

  $s("stGenBtn").addEventListener("click", () => {
    if (stMode === "i2v") {
      if (!genRefs.length) { toast("Upload an image first.", "info"); return; }
      startVideo({ scope: SCOPE, input: genRefs[0], inputs: genRefs.slice(), prompt: $s("stPrompt").value.trim(), model: $s("stVidModel").value, duration: +$s("stVidDur").value, quality: $s("stVidRes").value, cam_lock: stVidCamLock });
      return;
    }
    const p = $s("stPrompt").value.trim();
    if (stMode === "text" && !p) { toast("Write a prompt.", "info"); return; }
    if (stMode !== "text" && !genRefs.length) { toast("Add a reference image.", "info"); return; }
    startGen({ scope: SCOPE, prompt: p, inputs: (stMode === "text" ? [] : genRefs.slice()), mode: stMode,
      model: $s("stModel").value, aspect: $s("stAspect").value, quality: $s("stQuality").value });
  });
  $s("stMkBtn").addEventListener("click", () => {
    if (!mkRef) { toast("Upload a product image first.", "info"); return; }
    startMk({ scope: SCOPE, product: mkRef, aspect: $s("stMkAspect").value, model: $s("stMkModel").value,
      quality: $s("stMkQuality").value, count: Math.max(1, Math.min(+$s("stMkCount").value || 5, 20)) });
  });

  let stItems = [], filter = "all", galPage = 1;
  const GAL_PER = 10;   // 5 across x 2 rows per page
  async function loadGallery() {
    let r; try { r = await api.studioGallery(SCOPE); } catch (_) { return; }
    stItems = (r && r.items) || [];
    renderGallery();
  }
  function filteredItems() { return stItems.filter(it => filter === "all" ? true : (filter === "mockup" ? it.kind === "mockup" : it.kind !== "mockup")); }
  function renderGallery() {
    const grid = $s("stGallery"), empty = $s("stGalleryEmpty"), pager = $s("stGalPager");
    const live = new Set(stItems.map(it => it.id)); [...galSel].forEach(id => { if (!live.has(id)) galSel.delete(id); });   // drop deleted from selection
    const items = filteredItems();
    empty.hidden = items.length > 0;
    empty.textContent = !stItems.length ? "Nothing here yet — create something above." : "No images in this filter yet.";
    const pages = Math.max(1, Math.ceil(items.length / GAL_PER));
    if (galPage > pages) galPage = pages;
    if (galPage < 1) galPage = 1;
    const start = (galPage - 1) * GAL_PER;
    grid.innerHTML = "";
    items.slice(start, start + GAL_PER).forEach(it => grid.appendChild(galleryCard(it)));
    if (pager) {
      pager.innerHTML = "";
      if (pages > 1) {
        const mk = (label, pg, extra) => {
          const b = document.createElement("button"); b.type = "button"; b.className = "gal-pg" + (extra || ""); b.textContent = label;
          if (pg == null) b.disabled = true;
          else b.addEventListener("click", () => { galPage = pg; renderGallery(); const g = $s("stGallery"); if (g) g.scrollIntoView({ behavior: "smooth", block: "nearest" }); });
          return b;
        };
        pager.appendChild(mk("‹", galPage > 1 ? galPage - 1 : null));
        for (let p = 1; p <= pages; p++) pager.appendChild(mk(String(p), p, p === galPage ? " on" : ""));
        pager.appendChild(mk("›", galPage < pages ? galPage + 1 : null));
        pager.hidden = false;
      } else pager.hidden = true;
    }
    renderSelBar();
  }
  $$(".stf").forEach(b => b.addEventListener("click", () => { filter = b.dataset.f; galPage = 1; $$(".stf").forEach(x => x.classList.toggle("active", x === b)); renderGallery(); }));

  // ---- gallery multi-select (checkbox per card → bulk delete / send-to-project), like Scenes & Images ----
  const galSel = new Set();
  function toggleGalSel(id, on) { if (on) galSel.add(id); else galSel.delete(id); renderSelBar(); }
  function renderSelBar() {
    const bar = $s("stGalBar"); if (!bar) return;
    const n = galSel.size;
    if (!n) { bar.hidden = true; bar.innerHTML = ""; return; }
    const wasHidden = bar.hidden;
    bar.hidden = false; bar.innerHTML = "";
    if (wasHidden) { bar.style.animation = "none"; void bar.offsetWidth; bar.style.animation = ""; }   // replay the slide-in on show
    const cnt = document.createElement("span"); cnt.className = "sel-count"; cnt.textContent = `${n} selected`; bar.appendChild(cnt);
    const mkb = (label, cls, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = cls; b.textContent = label; b.addEventListener("click", fn); return b; };
    bar.appendChild(mkb("Select All", "sel-all", () => { filteredItems().forEach(it => galSel.add(it.id)); renderGallery(); }));
    bar.appendChild(mkb("📤 Send to a Project", "sel-send", (e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); openSelSendMenu(r.left, r.bottom + 4); }));
    if (PROJECT) bar.appendChild(mkb("💬 Send to FAQ", "sel-send", async () => {   // in-project only: push the selected images into the FAQ caption-background gallery
      const files = [...galSel].map(id => (stItems.find(x => x.id === id) || {}).file).filter(Boolean);
      if (!files.length) return;
      const r = await api.faqGalleryAdd(SCOPE, files);
      if (r && r.gallery) { faqGallery = r.gallery; if (typeof faqRenderGallery === "function") faqRenderGallery(); galSel.clear(); renderGallery(); toast(`Sent ${r.added} image(s) to the FAQ gallery.`, "ok", 3200); }
      else toast((r && r.error) || "Send failed", "err");
    }));
    bar.appendChild(mkb("⤓ Download All", "sel-dl", galBulkDownload));   // zip every selected image (left of Delete)
    bar.appendChild(mkb("🗑 Delete", "sel-del", bulkDelete));
    bar.appendChild(mkb("Clear", "sel-clear", () => { galSel.clear(); renderGallery(); }));
  }
  async function galBulkDownload() {
    const files = [...galSel].map(id => (stItems.find(x => x.id === id) || {}).file).filter(Boolean);
    if (!files.length) return;
    let r; try { r = await api.studioDownloadZip(SCOPE, files); } catch (_) { r = { error: "request failed" }; }
    if (!r || r.error) { toast((r && r.error) || "Download failed", "err", 5000); return; }
    downloadUrl(imgUrl(r.file) + "?dl=" + encodeURIComponent("mockups.zip") + "&t=" + Date.now(), "mockups.zip", "mockups");
    toast(`Downloading ${r.count} image(s) as a zip ✓`, "ok", 3000);
  }
  async function bulkDelete() {
    const ids = [...galSel]; if (!ids.length) return;
    for (const id of ids) { const it = stItems.find(x => x.id === id); if (!it) continue; const at = stItems.findIndex(x => x.id === id); const r = await api.studioDelete(SCOPE, id); if (r && !r.error) stUndo.push({ item: it, at: at < 0 ? 0 : at, scope: SCOPE }); }
    stRedo = []; studioUpdateUndoBtns(); galSel.clear(); await loadGallery(); toast(`Deleted ${ids.length} item(s)`, "info", 2500);
  }
  function openSelSendMenu(x, y) {
    closeStCtx();
    const m = document.createElement("div"); m.className = "ctx-menu"; m.id = "stCtx";
    const head = document.createElement("div"); head.className = "ctx-item ctx-head"; head.textContent = `Send ${galSel.size} to which project?`; m.appendChild(head);
    api.projects().then(list => {
      if (!list || !list.length) { const e = document.createElement("div"); e.className = "ctx-item ctx-disabled"; e.textContent = "No projects yet"; m.appendChild(e); return; }
      const ordered = PROJECT ? [...list].sort((a, b) => (a.name === PROJECT ? -1 : b.name === PROJECT ? 1 : 0)) : list;
      ordered.forEach(p => {
        const isCur = PROJECT && p.name === PROJECT;
        const b = document.createElement("button"); b.type = "button"; b.className = "ctx-item" + (isCur ? " ctx-cur" : "");
        b.textContent = isCur ? `This project — ${p.title || p.name}` : (p.title || p.name);
        b.addEventListener("click", async (ev) => {
          ev.stopPropagation(); closeStCtx();
          const ids = [...galSel]; let ok = 0, lastSid = null;
          for (const id of ids) { const it = stItems.find(x => x.id === id); if (!it) continue; const r = await api.studioToNewScene(SCOPE, it.file, p.name); if (r && !r.error) { ok++; lastSid = r.sceneId; } }
          galSel.clear(); renderGallery();
          if (isCur) {   // sent into the project we're inside → refresh it silently, but stay in the Studio
            try { const script = DOC && DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script; } catch (_) {}
            toast(`Added ${ok} scene(s) to this project.`, "ok", 4000);
          } else {
            toast(`Added ${ok} scene(s) at the end of “${p.title || p.name}”.`, "ok", 4500);
          }
        });
        m.appendChild(b);
      });
    }).catch(() => {});
    placeCtx(m, x, y);
  }

  // ---- global-Studio undo/redo of gallery deletes (the file is kept server-side; restore re-inserts it) ----
  let stUndo = [], stRedo = [];
  function studioGlobal() { return document.body.classList.contains("studio-open") && !PROJECT; }
  function studioUpdateUndoBtns() {
    if (PROJECT) return;   // in-project Studio uses the project's own undo/redo
    const u = document.getElementById("undoBtn"), r = document.getElementById("redoBtn");
    if (u) u.disabled = !stUndo.length;
    if (r) r.disabled = !stRedo.length;
  }
  async function studioDeleteItem(it) {
    const at = stItems.findIndex(x => x.id === it.id);
    const r = await api.studioDelete(SCOPE, it.id);
    if (r && !r.error) { stUndo.push({ item: it, at: at < 0 ? 0 : at, scope: SCOPE }); stRedo = []; studioUpdateUndoBtns(); loadGallery(); }
  }
  async function studioUndo() {
    const e = stUndo.pop(); if (!e) { studioUpdateUndoBtns(); return; }
    const r = await api.studioRestore(e.scope, e.item, e.at);
    if (r && !r.error) { stRedo.push(e); if (e.scope === SCOPE) loadGallery(); } else stUndo.push(e);
    studioUpdateUndoBtns();
  }
  async function studioRedo() {
    const e = stRedo.pop(); if (!e) { studioUpdateUndoBtns(); return; }
    const r = await api.studioDelete(e.scope, e.item.id);
    if (r && !r.error) { stUndo.push(e); if (e.scope === SCOPE) loadGallery(); } else stRedo.push(e);
    studioUpdateUndoBtns();
  }
  // in the GLOBAL studio, the header Undo/Redo/Reload act on the current view: FAQ view → subtitle-style
  // history; Image & Mockup view → the gallery. (capture phase → runs before the scene handlers)
  document.addEventListener("click", (e) => {
    if (!document.body.classList.contains("studio-open")) return;   // route in BOTH global AND in-project Studio
    const inFaq = curView === "faq";
    if (e.target.closest("#undoBtn")) { e.stopImmediatePropagation(); inFaq ? faqUndoStyle() : studioUndo(); }
    else if (e.target.closest("#redoBtn")) { e.stopImmediatePropagation(); inFaq ? faqRedoStyle() : studioRedo(); }
    else if (e.target.closest("#reloadBtn")) { e.stopImmediatePropagation(); if (!inFaq) { loadGallery(); toast("Gallery refreshed", "ok", 1500, { noHist: true }); } try { maybeRestartForNewCode(); } catch (_) {} }
  }, true);
  window._studioUpdateUndoBtns = studioUpdateUndoBtns;
  // let the global Ctrl+Z / Ctrl+Shift+Z route to the active Studio view's history instead of the project doc
  window._tabUndo = function () { if (!document.body.classList.contains("studio-open")) return false; (curView === "faq") ? faqUndoStyle() : studioUndo(); return true; };
  window._tabRedo = function () { if (!document.body.classList.contains("studio-open")) return false; (curView === "faq") ? faqRedoStyle() : studioRedo(); return true; };
  function galleryCard(it) {
    const isVid = it.kind === "video";
    const c = document.createElement("div"); c.className = "studio-card" + (galSel.has(it.id) ? " selected" : "");
    let media;
    if (isVid) { media = document.createElement("video"); media.src = imgUrl(it.file); media.muted = true; media.loop = true; media.playsInline = true; media.addEventListener("mouseenter", () => media.play().catch(() => {})); media.addEventListener("mouseleave", () => media.pause()); }
    else { media = document.createElement("img"); media.loading = "lazy"; media.src = imgUrl(it.file); }
    media.addEventListener("click", () => { try { isVid ? lightbox(imgUrl(it.file), "video") : studioLightbox(it); } catch (_) {} });
    c.appendChild(media);
    // multi-select checkbox (top-left)
    const chk = document.createElement("button"); chk.type = "button"; chk.className = "gal-check" + (galSel.has(it.id) ? " on" : ""); chk.title = "Select";
    chk.addEventListener("click", (e) => { e.stopPropagation(); const on = !chk.classList.contains("on"); chk.classList.toggle("on", on); c.classList.toggle("selected", on); toggleGalSel(it.id, on); });
    c.appendChild(chk);
    if (it.fav) { const st = document.createElement("div"); st.className = "studio-fav"; st.textContent = "★"; st.title = "Favourite"; c.appendChild(st); }
    if (it.prompt) { const cap = document.createElement("div"); cap.className = "studio-cap"; cap.textContent = it.prompt; cap.title = it.prompt; c.appendChild(cap); }
    const bar = document.createElement("div"); bar.className = "studio-cardbar";
    const mk = (svg, title, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = "ghost studio-mini"; b.innerHTML = svg; b.title = title; b.addEventListener("click", fn); return b; };
    bar.appendChild(mk(SVG_DL, "Download", () => downloadUrl(imgUrl(it.file), `studio_${it.id}.${isVid ? "mp4" : "png"}`, "studio " + (isVid ? "video" : "image"))));
    if (!isVid) bar.appendChild(mk(SVG_REUSE, "Use as an input in Generate", () => useAsInput(it)));
    bar.appendChild(mk(SVG_SEND, "Send to a Project", (e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); openStCtx(r.left, r.bottom + 4, it); }));
    bar.appendChild(mk(TRASH_SVG, "Delete", () => studioDeleteItem(it)));
    c.appendChild(bar);
    c.addEventListener("contextmenu", (e) => { e.preventDefault(); openStCtx(e.clientX, e.clientY, it); });
    return c;
  }
  function useAsInput(it) {
    // send the gallery image as a reference to the CURRENTLY-OPEN sub-mode (Image to Image / Image to Video /
    // Edit Image). From Text to Image (no reference) fall back to Image to Image.
    const target = ["i2i", "i2v", "edit"].includes(stMode) ? stMode : "i2i";
    if (target !== stMode) setStMode(target);
    if (genRefs.length < 4) genRefs.push(it.file); else genRefs = [it.file];   // add as a reference (up to 4; replace when full)
    renderGenUploads(); closeStCtx(); scrollTo("#studio .studio-sec");
    const names = { i2i: "Image to Image", i2v: "Image to Video", edit: "Edit Image" };
    toast(`Added as a reference to ${names[target]}.`, "ok", 3000);
  }

  // big view of a studio image with an inline EDIT box (NanoBanana 2), like the Settings ingredient editor
  function studioLightbox(it) {
    let cur = Object.assign({}, it);
    const lb = document.createElement("div"); lb.className = "lightbox st-lb";
    const stage = document.createElement("div"); stage.className = "lb-stage st-lb-stage";
    stage.addEventListener("click", e => e.stopPropagation());
    const img = document.createElement("img"); img.className = "st-lb-img"; img.src = imgUrl(cur.file); stage.appendChild(img);
    const ovc = document.createElement("div"); ovc.className = "img-actions";
    const bClose = document.createElement("button"); bClose.className = "ia lb-close"; bClose.textContent = "✕"; bClose.title = "Close";
    bClose.addEventListener("click", (e) => { e.stopPropagation(); lb.remove(); });
    ovc.appendChild(bClose); stage.appendChild(ovc);
    const panel = document.createElement("div"); panel.className = "st-lb-edit";
    const ta = document.createElement("textarea"); ta.className = "st-lb-input script-area"; ta.rows = 2; ta.placeholder = "Describe an edit to make to this image (uses NanoBanana 2)…";
    const row = document.createElement("div"); row.className = "st-lb-btns";
    const bEdit = document.createElement("button"); bEdit.type = "button"; bEdit.className = "primary"; bEdit.textContent = "✨ Edit";
    const bUse = document.createElement("button"); bUse.type = "button"; bUse.className = "ghost"; bUse.textContent = "♻ Use as input";
    const bDl = document.createElement("button"); bDl.type = "button"; bDl.className = "ghost"; bDl.textContent = "⬇ Download";
    row.appendChild(bEdit); row.appendChild(bUse); row.appendChild(bDl);
    panel.appendChild(ta); panel.appendChild(row); stage.appendChild(panel);
    lb.appendChild(stage);
    lb.addEventListener("click", () => lb.remove());
    document.body.appendChild(lb);
    bUse.addEventListener("click", (e) => { e.stopPropagation(); useAsInput(cur); lb.remove(); });
    bDl.addEventListener("click", (e) => { e.stopPropagation(); downloadUrl(imgUrl(cur.file), `studio_${cur.id}.png`, "studio image"); });
    bEdit.addEventListener("click", async (e) => {
      e.stopPropagation();
      const instr = ta.value.trim(); if (!instr) { toast("Describe the edit first.", "info"); ta.focus(); return; }
      bEdit.disabled = true; const old = bEdit.textContent; bEdit.textContent = "Editing…"; img.classList.add("st-lb-busy");
      let r; try { r = await api.studioEdit({ scope: SCOPE, ref: cur.file, instruction: instr, aspect: cur.aspect || "16:9" }); } catch (_) { r = { error: "request failed" }; }
      if (r.error) { bEdit.disabled = false; bEdit.textContent = old; img.classList.remove("st-lb-busy"); toast(r.error, "err", 6000); try { playErrorChime(); } catch (_) {} return; }
      const jid = r.job;
      const iv = setInterval(async () => {
        let j; try { j = await api.studioJob(jid); } catch (_) { return; }
        if (j.error || j.status === "cancelled") { clearInterval(iv); bEdit.disabled = false; bEdit.textContent = old; img.classList.remove("st-lb-busy"); return; }
        if (j.status === "done") {
          clearInterval(iv); bEdit.disabled = false; bEdit.textContent = old; img.classList.remove("st-lb-busy");
          const ni = j.items && j.items[j.items.length - 1];
          if (ni) { cur = ni; img.src = imgUrl(ni.file); ta.value = ""; loadGallery(); toast("Edited ✓ — saved to the gallery", "ok", 2800); try { playNotifChime(); } catch (_) {} }
          else { toast((j.errors && j.errors[0]) || "Edit failed", "err", 5000); try { playErrorChime(); } catch (_) {} }
        }
      }, 2500);
    });
  }

  // right-click / send-to-project menu (reuses the app's ctx-menu look)
  function closeStCtx() { const m = document.getElementById("stCtx"); if (m) m.remove(); }
  function placeCtx(m, x, y) {
    document.body.appendChild(m);
    const w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = Math.min(x, window.innerWidth - w - 8) + "px";
    m.style.top = Math.min(y, window.innerHeight - h - 8) + "px";
  }
  function openStCtx(x, y, it) {
    closeStCtx();
    const m = document.createElement("div"); m.className = "ctx-menu"; m.id = "stCtx";
    const item = (label, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = "ctx-item"; b.textContent = label; b.addEventListener("click", (ev) => { ev.stopPropagation(); fn(); }); m.appendChild(b); return b; };
    item("📤  Send to a project…", () => projectPicker(m, it));
    if (PROJECT) item("💬  Send to FAQ", async () => { closeStCtx(); const r = await api.faqGalleryAdd(SCOPE, [it.file]); if (r && r.gallery) { faqGallery = r.gallery; if (typeof faqRenderGallery === "function") faqRenderGallery(); toast("Sent to the FAQ gallery.", "ok", 3000); } else toast((r && r.error) || "Send failed", "err"); });
    item("♻  Use as an input", () => useAsInput(it));
    item("⬇  Download", () => { downloadUrl(imgUrl(it.file), `studio_${it.id}.png`, "studio image"); closeStCtx(); });
    const sep = document.createElement("div"); sep.className = "ctx-sep"; m.appendChild(sep);
    item("🗑  Delete", () => { closeStCtx(); studioDeleteItem(it); });
    placeCtx(m, x, y);
  }
  // Send a studio image to a project's scenes. When the target IS the project we're currently inside, reload the
  // doc, close Studio and jump straight to the new (last) scene in Scene & Image — no leave-and-reopen needed.
  async function studioSendToProject(it, projName, projTitle) {
    const r = await api.studioToNewScene(SCOPE, it.file, projName);
    if (r.error) { toast(r.error, "err", 5000); return; }
    if (PROJECT && projName === PROJECT) {
      // sent into the project we're inside: refresh it in the background so the scene is really there — but
      // DON'T navigate away from the Studio (the user asked for the image to just be sent).
      try { const script = DOC && DOC.script; DOC = await api.get(PROJECT); if (script) DOC.script = script; } catch (_) {}
      toast(`Added as a new scene (#${r.sceneId}) to this project.`, "ok", 4000);
    } else {
      toast(`Added as a new scene (#${r.sceneId}) at the end of “${r.title || projTitle || projName}”.`, "ok", 4500);
    }
  }
  async function projectPicker(m, it) {
    m.innerHTML = "";
    const head = document.createElement("div"); head.className = "ctx-item ctx-head"; head.textContent = "Send to which project?"; m.appendChild(head);
    let list = []; try { list = await api.projects(); } catch (_) {}
    if (!list.length) { const e = document.createElement("div"); e.className = "ctx-item ctx-disabled"; e.textContent = "No projects yet"; m.appendChild(e); return; }
    // in-project Studio: put THIS project first as the obvious target ("This project — …")
    const ordered = PROJECT ? [...list].sort((a, b) => (a.name === PROJECT ? -1 : b.name === PROJECT ? 1 : 0)) : list;
    ordered.forEach(p => {
      const isCur = PROJECT && p.name === PROJECT;
      const b = document.createElement("button"); b.type = "button"; b.className = "ctx-item" + (isCur ? " ctx-cur" : "");
      b.textContent = isCur ? `This project — ${p.title || p.name}` : (p.title || p.name);
      b.addEventListener("click", async (ev) => { ev.stopPropagation(); closeStCtx(); await studioSendToProject(it, p.name, p.title); });
      m.appendChild(b);
    });
    // re-clamp position now that the menu grew
    const x = parseFloat(m.style.left) || 0, y = parseFloat(m.style.top) || 0;
    m.style.top = Math.min(y, window.innerHeight - m.offsetHeight - 8) + "px";
  }
  document.addEventListener("click", closeStCtx);
  window.addEventListener("resize", closeStCtx);

  // ---- Studio top menu (slide animation like the top tabs) ----
  function placeSmenuSlider(anim) {
    const nav = document.querySelector(".studio-menu"), sl = $s("smenuSlider"), act = nav && nav.querySelector(".smenu.active");
    if (!nav || !sl || !act) return;
    sl.style.transition = anim ? "" : "none";
    // animate transform ONLY (position + width via scaleX off the 100px base) so both run on the compositor in
    // lockstep — no overshoot-then-return from width (layout) lagging translateX (composite).
    sl.style.transform = `translateX(${act.offsetLeft}px) scaleX(${act.offsetWidth / 100})`;
    if (!anim) { void sl.offsetWidth; sl.style.transition = ""; }
  }
  function setView(v) {
    curView = v;
    $$(".smenu").forEach(b => b.classList.toggle("active", b.dataset.view === v));
    $$(".studio-view").forEach(p => p.classList.toggle("active", p.dataset.viewp === v));
    placeSmenuSlider(true);
    if (!PROJECT) { if (v === "faq") faqUpdateBtns(); else studioUpdateUndoBtns(); }   // header undo/redo reflect the active view's history
  }
  $$(".smenu").forEach(b => b.addEventListener("click", () => setView(b.dataset.view)));

  // when Studio opens, make the header Studio button look active + drop the nav-tab green highlight
  function studioNavActive() {
    // Studio is a real tab now — light it + glide the slider onto it
    $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === "studio"));
    try { placeTabSlider(true); } catch (_) {}
  }
  function restoreNav() {
    // Mark the tab we're returning to active, but DON'T reposition the slider here — the caller (activateTab)
    // places it right after, letting it GLIDE straight from the Studio tab to the destination (no teleport jump).
    if (currentTab) $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === currentTab));
  }

  // global Studio: lift the title + description + Back up into the header (level with undo/redo/reload/history);
  // in-project Studio keeps them in the page body
  function placeStudioHead() {
    const head = document.querySelector(".studio-head"), sec = document.getElementById("studio");
    if (!head) return;
    const back = head.querySelector(".studio-back");
    const keys = document.getElementById("studioKeysBtn");
    if (!PROJECT) {
      const tbc = document.querySelector("header .tb-center"), tbl = document.querySelector("header .tb-left");
      if (tbc) { head.classList.add("in-header"); tbc.appendChild(head); }                 // title + desc → grid-centred middle zone
      if (back && tbl) {                                                                    // Back (+ Keys to its right) → far-left zone
        back.classList.add("back-in-header"); tbl.appendChild(back);
        if (keys) { keys.classList.add("keys-in-header"); tbl.appendChild(keys); }
      }
    } else { restoreStudioHead(); }
  }
  function restoreStudioHead() {
    const head = document.querySelector(".studio-head"), sec = document.getElementById("studio"), back = document.querySelector(".studio-back");
    const keys = document.getElementById("studioKeysBtn");
    if (head && head.classList.contains("in-header")) {
      head.classList.remove("in-header");
      if (back) { back.classList.remove("back-in-header"); head.insertBefore(back, head.firstChild); }   // put Back back inside the head
      if (keys) { keys.classList.remove("keys-in-header"); if (back) back.after(keys); else head.insertBefore(keys, head.firstChild); }
      if (sec) sec.insertBefore(head, sec.firstChild);
    }
  }

  const _openStudio0 = openStudio;
  openStudio = function () {
    _openStudio0();
    faqReset();
    try { faqRestore(); } catch (_) {}   // panel visible from the start + restore any saved FAQ work for this scope
    setView("gen"); placeSmenuSlider(false); placeStModeSlider(false);
    placeStudioHead();
    const bk = $s("studioBack"); if (bk) bk.style.display = PROJECT ? "none" : "";   // in-project → no Back (use the header)
    const ver = $s("studioVersion"); if (ver) ver.style.display = PROJECT ? "none" : "";   // show the version at the bottom only in the global (no-project) studio
    const desc = $s("studioScopeHint");
    if (desc) desc.innerHTML = PROJECT
      ? "Generate standalone images, product mockups and FAQ caption videos for this project.<br>Kept separate from the main scene pipeline; everything here is saved with the project."
      : "Generate standalone images, product mockups and FAQ caption videos — no project needed.<br>This global workspace is kept fully separate from your projects.";
    const kbtn = $s("studioKeysBtn");   // the 🔑 Keys button (next to Back) — global studio only
    if (kbtn) { kbtn.hidden = !!PROJECT; if (!kbtn._wired) { kbtn._wired = true; kbtn.addEventListener("click", () => { try { openGlobalKeysModal(); } catch (_) {} }); } }
    studioNavActive();
    if (!PROJECT && typeof studioUpdateUndoBtns === "function") studioUpdateUndoBtns();   // global studio: header undo/redo reflect the gallery-delete stacks
  };
  window.openStudio = openStudio;
  const _closeStudio0 = closeStudio;
  closeStudio = function () { const was = document.body.classList.contains("studio-open"); _closeStudio0(); restoreStudioHead(); if (was) restoreNav(); };
  window.closeStudio = closeStudio;

  // ================= FAQ (white-bg, VO-synced centred captions, red keywords) =================
  let faqRun = 0, faqKwRun = -1;   // which build the current keywords belong to (see the done handler)
  let faqVoFile = null, faqDocxFile = null, faqCues = [], faqKw = [], faqAudio = null, faqPoll = null, faqRaf = 0, faqPanelBuilt = false, faqLastCue = null, faqToggle = null, faqJobId = null;
  let faqProg = null, faqProgIv = 0, faqProgLabel = "", faqProgT0 = 0, _faqBuilding = false, _faqCancelReq = false;
  // manual per-word overrides: click a word in the preview to force it RED, click a red word to force it BLACK.
  // (lowercased word "cores" — mirror of the server _faq_word_core). Persisted per scope, honoured in the render.
  let faqManualRed = new Set(), faqManualBlack = new Set();
  let faqGallery = [];   // mockup images sent to the FAQ from the Studio gallery: [{file}] — rotating caption background
  let faqGalSel = new Set();   // selected gallery items (multi-select for the orange bar)
  document.addEventListener("keydown", (e) => {   // Space = play/pause in the FAQ preview (not while typing)
    if (e.code !== "Space" && e.key !== " ") return;
    if (!document.body.classList.contains("studio-open") || curView !== "faq") return;
    const tag = (e.target.tagName || "").toLowerCase();
    if (tag === "textarea" || tag === "input" || tag === "select" || e.target.isContentEditable) return;
    if (faqToggle) { e.preventDefault(); faqToggle(); }
  });
  // permanent delegated click on the preview: a WORD click toggles its red/black (works even before audio);
  // any other click = play/pause. Registered once here so it runs BEFORE faqSetupAudio's play/pause onclick.
  { const fp = $s("faqPreview"); if (fp) {
      fp.addEventListener("click", (e) => {
        const inner = $s("faqCaption") && $s("faqCaption").querySelector(".pv-cap-inner");
        if (inner && inner.isContentEditable) return;              // editing → let the click place the text caret
        const w = e.target.closest(".faq-word");
        if (w) { e.stopImmediatePropagation(); e.preventDefault(); faqWordToggle(w); }
      });
      // DOUBLE-CLICK the caption to EDIT its words (fix a typo etc.); Enter/blur saves, Esc cancels
      fp.addEventListener("dblclick", (e) => {
        const cap = $s("faqCaption"); const inner = cap && cap.querySelector(".pv-cap-inner");
        if (!inner || !faqCues.length) return;
        e.preventDefault(); e.stopImmediatePropagation();
        if (faqAudio && !faqAudio.paused) { try { faqAudio.pause(); } catch (_) {} }
        const t = faqAudio ? faqAudio.currentTime : (faqCues[0] ? faqCues[0].start : 0);
        const cue = faqCues.find(c => t >= c.start && t < c.end) || faqCues.find(c => c.start === faqLastCue) || faqCues[0];
        if (!cue) return;
        inner.contentEditable = "true"; inner.classList.add("faq-editing"); inner.textContent = cue.text || "";
        inner.focus();
        const r = document.createRange(); r.selectNodeContents(inner); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
        const commit = () => {
          inner.contentEditable = "false"; inner.classList.remove("faq-editing");
          const nt = inner.textContent.replace(/\s+/g, " ").trim();
          if (nt && nt !== cue.text) { cue.text = nt; faqSaveState(); faqSnap(); }   // update THIS caption's words + persist + undoable
          faqLastCue = null; faqRenderCaption();
        };
        inner.addEventListener("blur", commit, { once: true });
        inner.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter") { ev.preventDefault(); inner.blur(); }
          else if (ev.key === "Escape") { ev.preventDefault(); inner.textContent = cue.text || ""; inner.blur(); }
        });
      });
  } }
  const faqStyle = Object.assign({}, (typeof SUB_STYLE_DEFAULTS !== "undefined" ? SUB_STYLE_DEFAULTS : {}), { ost_color: "#111111", ost_placement: "center" });
  // ---- FAQ subtitle-style undo/redo (font, size, colour… every style tweak) ----
  let faqHist = [], faqHistIdx = -1, faqSnapT = null;
  function faqUpdateBtns() {
    if (curView !== "faq") return;   // FAQ history drives the header buttons whenever the FAQ view is active (in-project too)
    const u = document.getElementById("undoBtn"), r = document.getElementById("redoBtn");
    if (u) u.disabled = faqHistIdx <= 0;
    if (r) r.disabled = faqHistIdx >= faqHist.length - 1;
  }
  // snapshot the WHOLE FAQ workspace (style + captions + manual red/black + background/highlight/opacity) so
  // EVERY FAQ action is undoable, not just the caption-style sliders.
  function faqStateSnap() {
    return JSON.stringify({ style: faqStyle, cues: faqCues, red: [...faqManualRed], black: [...faqManualBlack],
      bg_color: (($s("faqBgColor") || {}).value) || "#ffffff", hl_color: (($s("faqHlColor") || {}).value) || "#e5322d",
      hl_on: faqHlOn(), bg_opacity: (($s("faqBgOpacity") || {}).value) || "100" });
  }
  function faqSnapNow() {
    const s = faqStateSnap();
    if (faqHistIdx >= 0 && faqHist[faqHistIdx] === s) return;      // nothing changed
    faqHist = faqHist.slice(0, faqHistIdx + 1); faqHist.push(s); faqHistIdx = faqHist.length - 1;
    if (faqHist.length > 80) { faqHist.shift(); faqHistIdx--; }
    faqUpdateBtns(); faqSaveState();
  }
  function faqSnap() { clearTimeout(faqSnapT); faqSnapT = setTimeout(faqSnapNow, 350); }   // debounce drags into one step
  function faqResetHist() { faqHist = [faqStateSnap()]; faqHistIdx = 0; faqUpdateBtns(); }
  function faqApplySnap() {
    const s = faqHist[faqHistIdx]; if (!s) return;
    const o = JSON.parse(s);
    Object.keys(faqStyle).forEach(k => delete faqStyle[k]); Object.assign(faqStyle, o.style || {});
    if (Array.isArray(o.cues)) faqCues = o.cues;
    faqManualRed = new Set(o.red || []); faqManualBlack = new Set(o.black || []);
    if (o.bg_color && $s("faqBgColor")) $s("faqBgColor").value = o.bg_color;
    if (o.hl_color && $s("faqHlColor")) $s("faqHlColor").value = o.hl_color;
    if ($s("faqHlOn")) $s("faqHlOn").checked = !!o.hl_on;
    if (o.bg_opacity != null && $s("faqBgOpacity")) $s("faqBgOpacity").value = o.bg_opacity;
    buildFaqSubPanel(); faqApplyBg(); faqApplyHl(); faqRenderCaption(); faqUpdateBtns(); faqSaveState();
  }
  function faqUndoStyle() { if (faqHistIdx > 0) { faqHistIdx--; faqApplySnap(); } }
  function faqRedoStyle() { if (faqHistIdx < faqHist.length - 1) { faqHistIdx++; faqApplySnap(); } }
  // persist the whole FAQ workspace per scope so it survives leaving/re-entering Studio
  function faqBgOpacityVal() { const r = $s("faqBgOpacity"); return r ? (parseInt(r.value, 10) || 0) / 100 : 1; }
  function faqApplyBg() { faqApplyGalleryBg(); }
  // ---- FAQ caption-background gallery (rotating mockup images + colour matte) ----
  function faqGalUrl(file) { return `/api/studio/img/${SCOPE}/${file}`; }
  function faqActiveGallery() { return (faqGallery || []).filter(g => g && g.active !== false).map(g => g.file); }
  let faqBgPlan = [];
  function faqBuildBgPlan() {   // one image per ~12s, switching only on a sentence (cue) START, cycling + looping
    faqBgPlan = []; const imgs = faqActiveGallery();
    if (!imgs.length || !faqCues.length) return;
    const TARGET = 12; let idx = 0, last = -1e9;
    faqCues.forEach((c, i) => {
      if (i === 0 || (c.start - last) >= TARGET) { faqBgPlan.push({ start: c.start, file: imgs[idx % imgs.length] }); idx++; last = c.start; }
    });
  }
  function faqUpdateBg(t) {
    const layer = $s("faqBgLayer"); if (!layer) return;
    if (!faqBgPlan.length) { if (layer.childElementCount) layer.innerHTML = ""; layer._seg = -1; return; }
    let si = 0; for (let i = 0; i < faqBgPlan.length; i++) { if (t >= faqBgPlan[i].start - 0.001) si = i; else break; }
    if (layer._seg === si) return;                       // same image → nothing to do
    layer._seg = si;
    const img = document.createElement("img"); img.className = "faq-bg-img"; img.src = faqGalUrl(faqBgPlan[si].file);
    layer.appendChild(img);
    requestAnimationFrame(() => img.classList.add("show"));   // 2s opacity crossfade + slow zoom (CSS)
    setTimeout(() => { while (layer.children.length > 1 && layer.firstChild !== img) layer.removeChild(layer.firstChild); }, 2100);
  }
  function faqApplyGalleryBg() {
    const pv = $s("faqPreview"), matte = $s("faqBgMatte"); if (!pv) return;
    pv.classList.toggle("faq-anim-paused", !(faqAudio && !faqAudio.paused));   // freeze the zoom unless the preview is playing
    { const bo = $s("faqBgOpacity"), bov = $s("faqBgOpacityVal"); if (bo && bov) bov.textContent = (bo.value || 0) + "%"; }
    const col = (($s("faqBgColor") || {}).value) || "#ffffff";
    const hasImgs = faqActiveGallery().length > 0;
    if (matte) matte.style.background = hasImgs ? hexToRgba(col, faqBgOpacityVal()) : col;   // tint over images / solid colour otherwise
    pv.style.background = hasImgs ? "#000" : col;
    faqBuildBgPlan();
    faqUpdateBg(faqAudio ? (faqAudio.currentTime || 0) : (faqCues[0] ? faqCues[0].start : 0));
  }
  function faqRenderGallery() {
    const grid = $s("faqGalleryGrid"), empty = $s("faqGalEmpty"); if (!grid) return;
    grid.innerHTML = "";
    const items = faqGallery || [];
    if (empty) empty.hidden = items.length > 0;
    items.forEach(g => {
      const cell = document.createElement("div"); cell.className = "faq-gal-cell" + (faqGalSel.has(g.file) ? " sel" : "") + (g.active === false ? " off" : " on");
      const im = document.createElement("img"); im.src = faqGalUrl(g.file); im.loading = "lazy"; cell.appendChild(im);
      const chk = document.createElement("span"); chk.className = "faq-gal-check" + (faqGalSel.has(g.file) ? " on" : ""); chk.textContent = faqGalSel.has(g.file) ? "✓" : ""; cell.appendChild(chk);   // multi-select box, top-left (like the scene cards)
      if (g.active !== false) { const b = document.createElement("span"); b.className = "faq-gal-badge"; b.textContent = "In FAQ"; cell.appendChild(b); }
      cell.addEventListener("click", () => { if (faqGalSel.has(g.file)) faqGalSel.delete(g.file); else faqGalSel.add(g.file); faqRenderGallery(); });
      grid.appendChild(cell);
    });
    faqRenderGalBar();
    faqApplyGalleryBg();
  }
  function faqRenderGalBar() {
    const bar = $s("faqGalBar"); if (!bar) return;
    const n = faqGalSel.size;
    if (!n) { bar.hidden = true; bar.innerHTML = ""; return; }
    const wasHidden = bar.hidden;
    bar.hidden = false; bar.innerHTML = "";
    if (wasHidden) { bar.style.animation = "none"; void bar.offsetWidth; bar.style.animation = ""; }   // replay the slide-in on show
    const cnt = document.createElement("span"); cnt.className = "sel-count"; cnt.textContent = `${n} selected`; bar.appendChild(cnt);
    const mkb = (label, cls, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = cls; b.textContent = label; b.addEventListener("click", fn); bar.appendChild(b); };
    mkb("Select All", "sel-all", () => { (faqGallery || []).forEach(g => faqGalSel.add(g.file)); faqRenderGallery(); });
    mkb("Add To FAQ", "sel-send", async () => { const files = [...faqGalSel]; const r = await api.faqGalleryUpdate(SCOPE, "active", files); if (r && r.gallery) { faqGallery = r.gallery; faqGalSel.clear(); faqRenderGallery(); toast(`Added ${files.length} image(s) to the FAQ background.`, "ok", 3000); } });
    mkb("⤓ Download All", "sel-dl", async () => { for (const f of faqGalSel) downloadUrl(faqGalUrl(f), f.split("/").pop() || "image.png", "FAQ image"); });
    mkb("🗑 Delete", "sel-del", async () => { const files = [...faqGalSel]; const r = await api.faqGalleryUpdate(SCOPE, "remove", files); if (r && r.gallery) { faqGallery = r.gallery; faqGalSel.clear(); faqRenderGallery(); toast(`Removed ${files.length} image(s).`, "info", 2500); } });
    mkb("Clear", "sel-clear", async () => { const r = await api.faqGalleryUpdate(SCOPE, "clear", []); if (r && r.gallery != null) { faqGallery = r.gallery; faqGalSel.clear(); faqRenderGallery(); } });
  }
  function faqApplyHl() { const pv = $s("faqPreview"); if (pv) pv.style.setProperty("--faq-kw", (($s("faqHlColor") || {}).value) || "#e5322d"); }   // highlighted keywords take this colour live
  function faqSaveState() { try { api.faqStateSave(SCOPE, { script: ($s("faqScript") || {}).value || "", keywords: faqKw, style: faqStyle, cues: faqCues, red_words: [...faqManualRed], black_words: [...faqManualBlack], bg_color: (($s("faqBgColor") || {}).value) || "#ffffff", hl_color: (($s("faqHlColor") || {}).value) || "#e5322d", hl_on: faqHlOn(), bg_opacity: Math.round(faqBgOpacityVal() * 100) }); } catch (_) {} }
  async function faqRestore() {
    let st = null; try { st = await api.faqState(SCOPE); } catch (_) {}
    if (st) {
      if (st.script && $s("faqScript")) $s("faqScript").value = st.script;
      if (st.style && typeof st.style === "object") { Object.keys(faqStyle).forEach(k => delete faqStyle[k]); Object.assign(faqStyle, st.style); }
      if (Array.isArray(st.keywords)) faqKw = st.keywords;
      if (Array.isArray(st.red_words)) faqManualRed = new Set(st.red_words);
      if (Array.isArray(st.black_words)) faqManualBlack = new Set(st.black_words);
      if (st.bg_color && $s("faqBgColor")) $s("faqBgColor").value = st.bg_color;
      if (st.hl_color && $s("faqHlColor")) $s("faqHlColor").value = st.hl_color;
      if (typeof st.hl_on === "boolean" && $s("faqHlOn")) $s("faqHlOn").checked = st.hl_on;
      if (st.bg_opacity != null && $s("faqBgOpacity")) $s("faqBgOpacity").value = st.bg_opacity;
      faqGallery = Array.isArray(st.gallery) ? st.gallery : [];
    }
    try { faqApplyBg(); faqApplyHl(); if (typeof faqRenderGallery === "function") faqRenderGallery(); } catch (_) {}
    buildFaqSubPanel(); faqResetHist();
    // Remember an uploaded voice-over / script for this scope even before Analyze & Sync has been run,
    // so re-opening the project's FAQ shows they're already there (the files live server-side).
    if (st && st.hasAudio) { const vn = $s("faqVoName"); if (vn) vn.textContent = "Saved voice-over ✓"; }
    if (st && st.hasScript && !((st.script || "").trim())) { const dn = $s("faqDocxName"); if (dn) dn.textContent = "Saved script ✓"; }
    if (st && Array.isArray(st.cues) && st.cues.length) {
      faqCues = st.cues;
      if (st.hasAudio) faqSetupAudio();
      faqRenderCaption();
    }
  }

  function faqReset() {
    if (faqAudio) { try { faqAudio.pause(); } catch (_) {} }
    cancelAnimationFrame(faqRaf); if (faqPoll) { clearInterval(faqPoll); faqPoll = null; }
    faqCues = []; faqKw = []; faqLastCue = null; faqManualRed = new Set(); faqManualBlack = new Set();
    const cap = $s("faqCaption"); if (cap) { const inner = cap.querySelector(".pv-cap-inner"); if (inner) inner.innerHTML = ""; cap.style.display = "none"; }
    faqSetEmpty(true);
    const big = $s("faqBig"); if (big) big.style.display = "";
    const pr = $s("faqProgress"); if (pr) pr.style.width = "0%";
    const hd = $s("faqHead"); if (hd) hd.style.left = "0%";
    const tm = $s("faqTime"); if (tm) tm.textContent = "0:00 / 0:00";
  }
  const faqVo = $s("faqVo"); if (faqVo) faqVo.addEventListener("change", (e) => { faqVoFile = e.target.files[0] || null; $s("faqVoName").textContent = faqVoFile ? faqVoFile.name : "No File Selected"; });
  const faqDx = $s("faqDocx"); if (faqDx) faqDx.addEventListener("change", (e) => { faqDocxFile = e.target.files[0] || null; $s("faqDocxName").textContent = faqDocxFile ? faqDocxFile.name : "No File Selected"; });
  { const bc = $s("faqBgColor"); if (bc) { attachThemedPicker(bc); bc.addEventListener("input", () => { faqApplyBg(); faqSaveState(); faqSnap(); }); faqApplyBg(); } }
  { const hc = $s("faqHlColor"); if (hc) { attachThemedPicker(hc); hc.addEventListener("input", () => { faqApplyHl(); faqRenderCaption(); faqSaveState(); faqSnap(); }); faqApplyHl(); } }
  { const bo = $s("faqBgOpacity"); const bov = $s("faqBgOpacityVal"); const paintOp = () => { if (bov && bo) bov.textContent = (bo.value || 0) + "%"; };
    if (bo) bo.addEventListener("input", () => { paintOp(); faqApplyBg(); faqSaveState(); faqSnap(); }); paintOp(); }
  { const ho = $s("faqHlOn"); if (ho) ho.addEventListener("change", () => { faqRenderCaption(); faqSaveState(); faqSnap(); }); }
  // FAQ render → MP4 (white bg + synced captions with red keywords), with live progress, then auto-download
  let faqRenderJobId = null;
  function faqRenderShow(show, text, pct) {
    const ov = $s("faqRenderOv"); if (!ov) return;
    ov.hidden = !show;
    if (show) { const s = ov.querySelector(".faq-render-step"); if (s) s.textContent = (text || "Rendering…") + (pct != null ? ` ${pct}%` : ""); }
  }
  { const rs = $s("faqRenderStop"); if (rs) rs.onclick = async () => { rs.disabled = true; const id = faqRenderJobId; if (id) { try { await api.faqRenderCancel(id); } catch (_) {} } faqRenderJobId = null; faqRenderShow(false); rs.disabled = false; toast("Render stopped.", "info", 2000); }; }
  const faqDl = $s("faqDownload");
  if (faqDl) faqDl.addEventListener("click", async () => {
    if (!faqCues.length) { toast("Generate the captions first (Analyze & Sync).", "info"); return; }
    faqSaveState();   // persist hl_on / bg_opacity / caption edits so the render reads the current settings
    const faqBg = ($s("faqBg") || { checked: true }).checked;   // off -> transparent ProRes .mov for Premiere
    const faqBgCol = (($s("faqBgColor") || {}).value) || "#ffffff";
    const faqHlCol = (($s("faqHlColor") || {}).value) || "#e5322d";
    faqRenderShow(true, faqBg ? "Starting…" : "Rendering transparent (.mov)…", 0);
    let r; try { await new Promise(res => setTimeout(res, 120)); r = await api.faqRender(SCOPE, faqBg, faqBgCol, faqHlCol); } catch (_) { r = { error: "request failed" }; }
    if (r.error) { faqRenderShow(false); toast(r.error, "err", 6000); try { playErrorChime(); } catch (_) {} return; }
    faqRenderJobId = r.job;
    const iv = setInterval(async () => {
      let j; try { j = await api.faqRenderJob(faqRenderJobId); } catch (_) { return; }
      if (!j || j.error || j.status === "error") { clearInterval(iv); faqRenderShow(false); faqRenderJobId = null; toast((j && j.error) || "Render failed", "err", 6000); try { playErrorChime(); } catch (_) {} return; }
      if (j.status === "cancelled") { clearInterval(iv); faqRenderShow(false); faqRenderJobId = null; return; }
      faqRenderShow(true, j.step || "Rendering…", j.pct || 0);
      if (j.status === "done") {
        clearInterval(iv); faqRenderShow(false); faqRenderJobId = null;
        downloadUrl(`/api/faq/video/${SCOPE}?t=${Date.now()}`, faqBg ? "faq.mp4" : "faq.mov", "FAQ video");
        toast(faqBg ? "FAQ video ready ✓" : "Transparent FAQ video (.mov) ready ✓", "ok", 3500); try { playNotifChime(); } catch (_) {}
      }
    }, 1200);
  });

  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  // fallback keywords when the AI keyword pass returns nothing — bold the product name(s) + numbers/prices so
  // there's always some red emphasis
  function faqFallbackKw(text) {
    const out = new Set();
    const rxs = [
      /\b\d+\s*-\s*day(?:\s+money[- ]back\s+guarantee)?\b/gi,       // 180-day (money-back guarantee)
      /\b(?:\d+|three|six|twelve)\s*-\s*month(?:\s+(?:packs?|packages?))?\b/gi,   // six-month package
      /\b(?:three|six|twelve)\s+or\s+\d*\s*-?\s*month\s+(?:packs?|packages?)\b/gi,   // three or six-month packs
      /\brisk[- ]free\b/gi,
      /\bmoney[- ]back(?:\s+guarantee)?\b/gi,
      /\b100%\s+satisfaction\s+guarantee\b/gi,
      /\b(?:satisfaction|lifetime)\s+guarantee\b/gi,
      /\bcompletely free\b/gi,
      /\babsolutely\s+(?:yes|not)\b/gi,
      /\b(?:order now|try it today|get started(?:\s+today)?|claim your[a-z ]*|don'?t wait|buy now|act now)\b/gi,
      /\bbeta-?\d+\s+receptors?\b/gi,                                // beta-3 receptors
      /\bFDA[- ]approved\b/gi,
      /\b100%\s+[a-z]+(?:\s+formula)?\b/gi,                          // 100% natural formula
      /\bnon[- ]?GMO\b/gi, /\bplant[- ]based\b/gi, /\bdairy[- ]free\b/gi, /\bgluten[- ]free\b/gi, /\bvegan\b/gi,
      /\bclinically proven\b/gi, /\bFDA[- ]approved\b/gi,
      /\bISO\s?\d{3,}\b/gi, /\bEcocert(?:\s+standards)?\b/gi,
      /[£$€]\s?\d[\d.,]*/g,                                          // prices (money numbers OK; bare question numbers are not)
    ];
    rxs.forEach(rx => { let m; while ((m = rx.exec(text)) !== null) { out.add(m[0].trim()); if (rx.lastIndex === m.index) rx.lastIndex++; } });
    (text.split(/\s+/) || []).forEach(w => { const c = w.replace(/[^A-Za-z0-9]/g, ""); if (/[a-z][A-Z]/.test(c) || /^[A-Z]{3,}$/.test(c)) out.add(c); });   // CamelCase / ALLCAPS brand (CitruSlim, ISO)
    return [...out].slice(0, 40);
  }
  // the click-key for a word: lowercased, edge punctuation stripped (keep % $ £ € and internal - so
  // 'non-GMO' / '180-day' / '100%' stay one unit). MUST mirror the server _faq_word_core exactly.
  function faqWordCore(seg) {
    return String(seg).toLowerCase().replace(/^[^a-z0-9%$£€]+/, "").replace(/[^a-z0-9%$£€]+$/, "");
  }
  // char-coverage from the auto keywords — each keyword marked INDEPENDENTLY so overlapping phrases
  // (e.g. "96,400 men and women" vs "over 96,400 men") both fully colour (mirrors the server).
  function faqCoverage(text) {
    const cov = new Array(text.length).fill(false);
    faqKw.forEach(k => {
      if (!k) return;
      const rx = new RegExp(String(k).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
      let m; while ((m = rx.exec(text)) !== null) { for (let i = m.index; i < m.index + m[0].length; i++) cov[i] = true; if (rx.lastIndex === m.index) rx.lastIndex++; }
    });
    return cov;
  }
  // WORD-LEVEL highlight: every word is a clickable <span.faq-word>; red if manual-red, or auto-covered and
  // not manual-black. Click toggles (handled by the delegated listener on #faqPreview).
  function faqHlOn() { const c = $s("faqHlOn"); return c ? !!c.checked : true; }
  function faqHighlight(text) {
    text = (text || "").replace(/(\d)\s+([%‰°€$£])/g, "$1\u00A0$2");   // keep "100 %" (number + unit) on ONE line (nbsp)
    const hlOn = faqHlOn();                      // Highlight OFF -> every word plain (no bold/colour)
    const cov = hlOn ? faqCoverage(text) : null;
    let out = "", idx = 0; const rx = /\s+|\S+/g; let t;
    while ((t = rx.exec(text)) !== null) {
      const seg = t[0];
      if (!seg.trim()) { out += esc(seg); idx += seg.length; continue; }
      const core = faqWordCore(seg);
      let red;
      if (!hlOn || !core) red = false;
      else if (faqManualBlack.has(core)) red = false;
      else if (faqManualRed.has(core)) red = true;
      else { red = false; for (let i = idx; i < idx + seg.length; i++) if (cov[i]) { red = true; break; } }
      out += `<span class="faq-word${red ? " faq-kw" : ""}" data-w="${esc(core)}">${esc(seg)}</span>`;
      idx += seg.length;
    }
    return out;
  }
  function faqWordToggle(el) {
    const core = el.getAttribute("data-w"); if (!core) return;
    if (el.classList.contains("faq-kw")) { faqManualBlack.add(core); faqManualRed.delete(core); }
    else { faqManualRed.add(core); faqManualBlack.delete(core); }
    faqRenderCaption(); faqSaveState(); faqSnap();
  }
  // clone the SAME subtitle-style panel Assemble uses, wired to faqStyle
  function buildFaqSubPanel() {
    const host = $s("faqSubPanel"), tpl = $("#subStyleTpl"); if (!host || !tpl) return;
    host.innerHTML = "";
    const panel = tpl.content.firstElementChild.cloneNode(true);
    host.appendChild(panel);
    const redraw = () => { faqSnap(); faqRenderCaption(); };
    try { wireOstPanel(panel, faqStyle, redraw, buildFaqSubPanel, "subtitle"); } catch (e) { /* never let a control wiring error break the page */ }
    // the subtitle-specific controls (Size slider, Width %, Lines) live OUTSIDE wireOstPanel — wire them too
    const sInp = panel.querySelector(".sub-size"), sV = panel.querySelector(".sub-size-v");
    if (sInp) { sInp.value = faqStyle.ost_size != null ? faqStyle.ost_size : 46; const showS = () => { if (sV) sV.textContent = sInp.value; }; showS(); sInp.addEventListener("input", () => { faqStyle.ost_size = clampNum(sInp.value, 12, 400, 46); showS(); redraw(); }); }
    const wInp = panel.querySelector(".sub-width-num");
    if (wInp) { wInp.value = faqStyle.sub_width != null ? faqStyle.sub_width : 86; wInp.addEventListener("input", () => { faqStyle.sub_width = clampNum(wInp.value, 30, 100, 86); redraw(); }); }
    panel.querySelectorAll(".sub-line-btn").forEach(b => {
      b.classList.toggle("on", b.dataset.lines === String(faqStyle.sub_lines || "auto"));
      b.addEventListener("click", () => { faqStyle.sub_lines = b.dataset.lines; panel.querySelectorAll(".sub-line-btn").forEach(x => x.classList.toggle("on", x === b)); redraw(); });
    });
    const resetBtn = panel.querySelector(".sub-reset");
    if (resetBtn) resetBtn.addEventListener("click", (e) => { e.stopPropagation(); Object.keys(faqStyle).forEach(k => delete faqStyle[k]); Object.assign(faqStyle, SUB_STYLE_DEFAULTS, { ost_color: "#111111", ost_placement: "center" }); faqSnap(); buildFaqSubPanel(); faqRenderCaption(); });
    // preview the chosen in/out animation on the caption the moment it's picked (like Assemble)
    const aIn = panel.querySelector(".ost-anim"), aOut = panel.querySelector(".ost-out-anim");
    if (aIn) aIn.addEventListener("change", () => faqPlayAnim("in"));
    if (aOut) aOut.addEventListener("change", () => faqPlayAnim("out"));
    faqPanelBuilt = true;
    faqRenderCaption();
  }
  function faqRenderCaption() {
    const el = $s("faqCaption"); if (!el) return;
    const inner = el.querySelector(".pv-cap-inner") || el;
    if (inner.isContentEditable) return;   // the user is editing this caption's text — don't clobber it
    const t = faqAudio ? faqAudio.currentTime : (faqCues[0] ? faqCues[0].start : 0);
    try { faqUpdateBg(t); } catch (_) {}   // rotate the mockup background in sync with the sentences
    const cue = faqCues.find(c => t >= c.start && t < c.end) || (!faqAudio && faqCues[0]);
    faqSetEmpty(!faqCues.length);           // no captions yet → show the placeholder icon, not a blank white frame
    if (!cue) { el.style.display = "none"; faqLastCue = null; return; }
    try {
      const mode = String(faqStyle.sub_lines || "auto");
      // "auto" = fill each line to the chosen Line width (greedy → text reaches the left/right edges);
      // "2" = two balanced lines; "1" = one line (styleCaption forces nowrap)
      if (mode === "2") inner.innerHTML = wrapSubLines(cue.text, faqStyle).map(l => faqHighlight(l)).join("<br>");
      else inner.innerHTML = faqHighlight(cue.text);
      el.style.display = "";
      styleCaption(inner, el, ($s("faqPreview").clientWidth) || 640, faqStyle);
      // styleCaption centres with left:50% + auto width, which caps an absolute box at ~50% of the frame.
      // Give the FAQ caption an EXPLICIT width (= the Line %) so greedy text can fill edge-to-edge.
      if (mode !== "1") { el.style.width = (faqStyle.sub_width || 86) + "%"; el.style.maxWidth = "none"; inner.style.width = "100%"; }
      // play the chosen entrance animation whenever the cue changes (fade / pop / slide) — matches Assemble
      const key = cue.start;
      if (key !== faqLastCue) {
        faqLastCue = key;
        const anim = faqStyle.ost_anim || "fade";
        [...inner.classList].filter(c => c.startsWith("pv-ost")).forEach(c => inner.classList.remove(c));
        if (anim !== "none") { void inner.offsetWidth; inner.classList.add("pv-ost-" + anim); }
      }
    } catch (_) { inner.innerHTML = faqHighlight(cue.text); el.style.display = ""; }
  }
  function faqPlayAnim(kind) {
    const inner = $s("faqCaption") && $s("faqCaption").querySelector(".pv-cap-inner"); if (!inner) return;
    const name = kind === "out" ? (faqStyle.ost_out_anim || "none") : (faqStyle.ost_anim || "fade");
    [...inner.classList].filter(c => c.startsWith("pv-ost")).forEach(c => inner.classList.remove(c));
    if (name === "none") return;
    const cls = kind === "out" ? ("pv-ost-out-" + name) : ("pv-ost-" + name);
    void inner.offsetWidth; inner.classList.add(cls);
    inner.addEventListener("animationend", () => inner.classList.remove(cls), { once: true });
  }
  function faqSetEmpty(show) {
    const e = $s("faqEmpty"); if (e) e.hidden = !show;
  }
  function fmt(s) { s = Math.max(0, s || 0); const m = Math.floor(s / 60), ss = Math.floor(s % 60); return m + ":" + String(ss).padStart(2, "0"); }
  function faqTick() {
    if (!faqAudio) return;
    const d = faqAudio.duration || 0, t = faqAudio.currentTime || 0;
    faqRenderCaption();
    const p = d ? (t / d) : 0;
    $s("faqProgress").style.width = (p * 100) + "%"; $s("faqHead").style.left = (p * 100) + "%";
    $s("faqTime").textContent = fmt(t) + " / " + fmt(d);
    if (!faqAudio.paused) faqRaf = requestAnimationFrame(faqTick);
  }
  function faqSetupAudio() {
    if (faqAudio) { try { faqAudio.pause(); } catch (_) {} }
    faqAudio = new Audio(`/api/faq/audio/${SCOPE}?t=${Date.now()}`);
    const big = $s("faqBig"), play = $s("faqPlay");
    faqAudio.addEventListener("play", () => { play.textContent = "❚❚"; if (big) big.style.display = "none"; const pv = $s("faqPreview"); if (pv) pv.classList.remove("faq-anim-paused"); faqRaf = requestAnimationFrame(faqTick); });
    faqAudio.addEventListener("pause", () => { play.textContent = "▶"; if (big) big.style.display = ""; const pv = $s("faqPreview"); if (pv) pv.classList.add("faq-anim-paused"); cancelAnimationFrame(faqRaf); });
    faqAudio.addEventListener("ended", () => { play.textContent = "▶"; if (big) big.style.display = ""; });
    const toggle = () => { if (faqAudio.paused) faqAudio.play().catch(() => {}); else faqAudio.pause(); };
    play.onclick = toggle; if (big) big.onclick = toggle;
    faqToggle = toggle;                                   // for the Space shortcut
    const prev = $s("faqPreview");
    if (prev) prev.onclick = (e) => { if (e.target.closest("button")) return; toggle(); };   // click the preview = play/pause
    // scrub the timeline: click anywhere OR grab the round head and DRAG (mouse + touch) to seek the video
    const bar = $s("faqBar"), head = $s("faqHead");
    const seekX = (cx) => { const r = bar.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (cx - r.left) / (r.width || 1))); faqAudio.currentTime = p * (faqAudio.duration || 0); faqTick(); };
    let faqDrag = false;
    const onMove = (ev) => { if (!faqDrag) return; const cx = (ev.touches && ev.touches[0]) ? ev.touches[0].clientX : ev.clientX; ev.preventDefault(); seekX(cx); };
    const onUp = () => { faqDrag = false; bar.classList.remove("dragging"); document.removeEventListener("mousemove", onMove); document.removeEventListener("mouseup", onUp); document.removeEventListener("touchmove", onMove); document.removeEventListener("touchend", onUp); };
    const start = (ev) => { faqDrag = true; bar.classList.add("dragging"); const cx = (ev.touches && ev.touches[0]) ? ev.touches[0].clientX : ev.clientX; seekX(cx); document.addEventListener("mousemove", onMove); document.addEventListener("mouseup", onUp); document.addEventListener("touchmove", onMove, { passive: false }); document.addEventListener("touchend", onUp); ev.preventDefault(); };
    bar.onmousedown = start;              // click OR grab-and-drag anywhere on the bar (the round head is visual;
    bar.ontouchstart = start;            // .pv-head is pointer-events:none so the bar captures the whole width)
  }

  // progress shows in a top-right toast (with %); the Analyze button itself turns into a Stop button.
  function faqBusy(text) {
    // strip the internal model name ("Syncing captions (small.en)…" -> "Syncing captions…") for a clean toast
    faqProgLabel = String(text || "Working…").replace(/\s*\([^)]*\)\s*(?=…|$)/, "").trim() || "Working…";
    _faqBuilding = true;
    const b = $s("faqGenBtn"), stop = $s("faqStop"), st = $s("faqStatus");
    if (b) { b.disabled = false; b.classList.add("faq-stop-mode"); b.innerHTML = "⛔ Stop"; }
    if (stop) stop.hidden = true;   // the main button is the Stop button now
    if (st) st.hidden = true;
    if (!faqProg) {
      faqProgT0 = Date.now();
      faqProg = progressToast(faqProgLabel, () => faqStopNow());   // toast has its own ⏹ too
      faqProgIv = setInterval(() => {   // no true % from the aligner -> ease 0->96 while it runs
        const el = (Date.now() - faqProgT0) / 1000;
        const pct = Math.min(96, Math.round((1 - Math.exp(-el / 22)) * 100));
        try { faqProg.update(faqProgLabel, pct); } catch (_) {}
      }, 350);
    } else {
      // a re-call (every poll) must NOT pass null — progressToast treats null as 0% and the bar would flicker to
      // zero between the interval ticks. Re-use the SAME eased value so the bar only ever climbs.
      const el = (Date.now() - faqProgT0) / 1000;
      const pct = Math.min(96, Math.round((1 - Math.exp(-el / 22)) * 100));
      try { faqProg.update(faqProgLabel, pct); } catch (_) {}
    }
  }
  function faqIdle(msg) {
    _faqBuilding = false;
    const b = $s("faqGenBtn"), stop = $s("faqStop"), st = $s("faqStatus");
    if (b) { b.disabled = false; b.classList.remove("faq-stop-mode"); b.innerHTML = "✨ Analyze &amp; Sync Captions"; }
    if (stop) { stop.hidden = true; stop.disabled = false; stop.textContent = "⛔ Stop"; }
    if (faqProgIv) { clearInterval(faqProgIv); faqProgIv = 0; }
    if (faqProg) { try { faqProg.update(faqProgLabel, 100); } catch (_) {} const p = faqProg; faqProg = null; setTimeout(() => { try { p.close(); } catch (_) {} }, 300); }
    if (st) { if (msg) { st.hidden = false; st.textContent = msg; setTimeout(() => { st.hidden = true; }, 4000); } else st.hidden = true; }
  }
  async function faqStopNow() {
    _faqCancelReq = true;                       // aborts a job that hasn't started yet (still in the keyword phase)
    if (faqPoll) { clearInterval(faqPoll); faqPoll = null; }
    const id = faqJobId; faqJobId = null;
    if (id) { try { await api.faqCancel(id); } catch (_) {} }
    faqIdle(); toast("Stopped.", "info", 2000);
  }
  { const stop = $s("faqStop"); if (stop) stop.onclick = () => faqStopNow(); }
  $s("faqGenBtn").addEventListener("click", async () => {
    if (_faqBuilding) { faqStopNow(); return; }   // button is in Stop mode -> cancel the run
    _faqCancelReq = false;
    const script = $s("faqScript").value.trim();
    if (!faqVoFile) { const has = await fetch(`/api/faq/audio/${SCOPE}`, { method: "HEAD" }).then(r => r.ok).catch(() => false); if (!has) { toast("Upload a voice-over first.", "info"); return; } }
    if (!script && !faqDocxFile) { toast("Type a script or upload a script file.", "info"); return; }
    faqRun++;                       // a new build: any keywords from an earlier one are stale
    faqBusy("Analyzing keywords…");
    // AI keyword detection is REQUIRED (the user does not want a degraded rules-only result). If Kie is
    // down, abort with a clear error and change NOTHING — no half-baked captions, no overwriting good work.
    if (script) {
      let kwr;
      try { kwr = await api.faqKeywords(SCOPE, script, ($s("faqLang") || {}).value || "en"); } catch (_) { kwr = { error: "network" }; }
      if (!kwr || kwr.error || !(kwr.keywords && kwr.keywords.length)) {
        faqIdle();
        toast("Couldn't reach Kie — word detection failed and the job was stopped. Nothing was changed, to avoid a partial/wrong result. Please press 'Analyze & Sync' again in a moment.", "err", 9000);
        try { playErrorChime(); } catch (_) {}
        return;
      }
      faqKw = kwr.keywords; faqKwRun = faqRun;
    }
    if (_faqCancelReq) { faqIdle(); return; }   // user hit Stop during the keyword phase -> abort before syncing
    faqBusy("Syncing captions…");
    const faqLang = ($s("faqLang") || {}).value || "en";   // voice-over language -> the aligner uses the matching Whisper model
    let r; try { r = await api.faqBuild(SCOPE, faqVoFile, faqDocxFile, script, faqLang); } catch (_) { r = { error: "request failed" }; }
    if (_faqCancelReq) { try { if (r && r.job) await api.faqCancel(r.job); } catch (_) {} faqIdle(); return; }
    if (r.error) { faqIdle(); toast(r.error, "err", 6000); try { playErrorChime(); } catch (_) {} return; }
    faqJobId = r.job;
    if (faqPoll) clearInterval(faqPoll);
    faqPoll = setInterval(async () => {
      let j; try { j = await api.faqJob(r.job); } catch (_) { return; }
      if (j.error) { clearInterval(faqPoll); faqPoll = null; faqJobId = null; faqIdle(); toast("⚠ " + j.error, "err", 6000); try { playErrorChime(); } catch (_) {} return; }
      if (j.status === "cancelled") { clearInterval(faqPoll); faqPoll = null; faqJobId = null; faqIdle(); return; }
      faqBusy(j.step || "Working…");
      if (j.status === "done") {
        clearInterval(faqPoll); faqPoll = null; faqJobId = null;
        faqCues = j.cues || [];
        // the reconcile guard refused to rewrite the script — captions were made from what you wrote
        if (j.note) toast(j.note, "warn", 11000);
        // If the script was UPLOADED (not typed), the keyword pass was skipped -> no red/bold. Detect keywords
        // now from the synced caption text (works for any language, e.g. French) so highlighting always applies.
        // Keywords belong to the script that produced THESE cues. The old test was "do we have any at
        // all", so a saved list from an earlier build survived a new one — a German FAQ ended up painted
        // with the English keywords of the script before it, which is most of what looked like bad picks.
        if (faqCues.length && (faqKwRun !== faqRun || !(faqKw && faqKw.length))) {
          faqBusy("Analyzing keywords…");
          const cueText = faqCues.map(c => (c.text || "")).join(" ").trim();
          const lg = ($s("faqLang") || {}).value || "en";
          try { const kwr = await api.faqKeywords(SCOPE, cueText, lg); if (kwr && kwr.keywords && kwr.keywords.length) { faqKw = kwr.keywords; faqKwRun = faqRun; } } catch (_) {}
        }
        buildFaqSubPanel(); faqSetupAudio(); faqRenderCaption(); faqSaveState();
        faqIdle(`Ready — ${faqCues.length} caption cues. Press ▶ to preview.`);
        try { playNotifChime(); } catch (_) {}
      }
    }, 2500);
  });

  const hb = $s("studioBtnHeader"); if (hb) hb.addEventListener("click", openStudio);
  const bk = $s("studioBack"); if (bk) bk.addEventListener("click", closeStudio);
})();

// ---- Login-screen "Run System Check": full self-test with NO project + NO login needed ----
function wireSysCheck() {
  const btn = document.getElementById("sysCheckBtn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const label = btn.innerHTML;
    btn.disabled = true;
    btn.classList.add("testing");
    btn.innerHTML = '<span class="sc-spin" aria-hidden="true"></span>Running system check…';
    let d = null;
    try {
      const r = await fetch("/self-test", { method: "POST" });
      d = await r.json();
    } catch (ex) {
      d = { ok: false, error: (ex && ex.message) || String(ex), summary: { pass: 0, warn: 0, fail: 1 }, results: [] };
    }
    btn.disabled = false;
    btn.classList.remove("testing");
    btn.innerHTML = label;
    showSysCheckModal(d);
  });
}

function showSysCheckModal(d) {
  document.querySelectorAll(".sc-overlay").forEach((n) => n.remove());
  const s = (d && d.summary) || { pass: 0, warn: 0, fail: 0 };
  const results = (d && d.results) || [];
  const fail = s.fail || 0, warn = s.warn || 0, pass = s.pass || 0;
  let head, headClass;
  if (d && d.error) { head = "⚠ Could not run the test"; headClass = "sc-bad"; }
  else if (fail > 0) { head = "❌ CRITICAL FAILURE — system won't fully work"; headClass = "sc-bad"; }
  else if (warn > 0) { head = "✅ System healthy — warnings for some optional features"; headClass = "sc-warn"; }
  else { head = "✅ SYSTEM HEALTHY — everything works"; headClass = "sc-ok"; }

  const esc = (t) => (t || "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  const dot = { PASS: "sc-d-ok", WARN: "sc-d-warn", FAIL: "sc-d-fail" };
  const rows = results.map((r) =>
    `<div class="sc-row"><span class="sc-dot ${dot[r.level] || ""}"></span>` +
    `<span class="sc-name">${esc(r.name)}</span>` +
    (r.detail ? `<span class="sc-detail">${esc(r.detail)}</span>` : "") + `</div>`
  ).join("");

  const ov = document.createElement("div");
  ov.className = "sc-overlay";
  ov.innerHTML =
    `<div class="sc-card">
       <div class="sc-head ${headClass}">${head}</div>
       <div class="sc-chips">
         <span class="sc-chip sc-c-ok">${pass} PASS</span>
         <span class="sc-chip sc-c-warn">${warn} WARN</span>
         <span class="sc-chip sc-c-fail">${fail} FAIL</span>
       </div>
       ${d && d.error ? `<div class="sc-err">${esc(d.error)}</div>` : ""}
       <div class="sc-list">${rows || '<div class="sc-detail">No results.</div>'}</div>
       <details class="sc-raw"><summary>Raw output (console)</summary><pre>${esc((d && d.text) || "")}</pre></details>
       <div class="sc-actions">
         <button class="sc-btn sc-copy">Copy</button>
         <button class="sc-btn sc-close">Close</button>
       </div>
     </div>`;
  document.body.appendChild(ov);
  const close = () => ov.remove();
  ov.addEventListener("click", (e) => { if (e.target === ov) close(); });
  ov.querySelector(".sc-close").addEventListener("click", close);
  ov.querySelector(".sc-copy").addEventListener("click", () => {
    const txt = (d && d.text) || results.map((r) => `[${r.level}] ${r.name}${r.detail ? "  -> " + r.detail : ""}`).join("\n");
    try { navigator.clipboard.writeText(txt); toast("Report copied", "info", 2000); } catch (_) {}
  });
  document.addEventListener("keydown", function onEsc(e) { if (e.key === "Escape") { close(); document.removeEventListener("keydown", onEsc); } });
}

wireSysCheck();
if (window.AUTHED === false) wireLoginGate();
else boot();
