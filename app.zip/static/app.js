const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
// clean line-art trash icon (clearer than the OS emoji) for all delete buttons
const TRASH_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/><path d="M10 11v6M14 11v6"/></svg>';
// sparkle / magic-wand — "generate this character's portrait"
const MAGIC_SVG = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M10.5 2.2l1.9 5.4 5.4 1.9-5.4 1.9-1.9 5.4-1.9-5.4L3.2 9.5l5.4-1.9z"/><path d="M18.2 13.5l.85 2.45 2.45.85-2.45.85-.85 2.45-.85-2.45-2.45-.85 2.45-.85z"/></svg>';
// mirror line-art icons for project transfer: export = arrow up out of a tray, import = arrow down into a tray
const EXPORT_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M12 15V3"/><path d="M7 8l5-5 5 5"/></svg>';
const IMPORT_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/></svg>';
let PROJECT = null;
let DOC = null;
let pollTimer = null;
let saveTimer = null;
let hideApproved = false;   // Scenes tab: hide approved scenes toggle
// in-dashboard confirm popup (replaces the browser's native confirm)
function confirmDialog(message, { title = "Are you sure?", okText = "Delete", danger = true } = {}) {
  return new Promise((resolve) => {
    const bg = $("#confirmBg"), ok = $("#confirmOk"), cancel = $("#confirmCancel");
    $("#confirmTitle").textContent = title;
    $("#confirmMsg").textContent = message;
    ok.textContent = okText;
    ok.classList.toggle("danger", !!danger);
    bg.hidden = false;
    const onKey = (e) => { if (e.key === "Escape") done(false); else if (e.key === "Enter") done(true); };
    function done(v) {
      bg.hidden = true;
      ok.onclick = null; cancel.onclick = null; bg.onclick = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    ok.onclick = () => done(true);
    cancel.onclick = () => done(false);
    bg.onclick = (e) => { if (e.target === bg) done(false); };
    document.addEventListener("keydown", onKey);
  });
}
// Two-way delete picker for a project. Resolves "dashboard" (soft, keep files) | "disk" (hard) | null.
function deleteProjectDialog(title) {
  return new Promise((resolve) => {
    const bg = $("#delChoiceBg");
    $("#delChoiceTitle").textContent = `Delete “${title}”?`;
    bg.hidden = false;
    const dash = $("#delFromDash"), disk = $("#delFromDisk"), cancel = $("#delChoiceCancel");
    const onKey = (e) => { if (e.key === "Escape") done(null); };
    function done(v) {
      bg.hidden = true;
      dash.onclick = disk.onclick = cancel.onclick = bg.onclick = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    dash.onclick = () => done("dashboard");
    disk.onclick = () => done("disk");
    cancel.onclick = () => done(null);
    bg.onclick = (e) => { if (e.target === bg) done(null); };
    document.addEventListener("keydown", onKey);
  });
}
// parse "m:ss" / "h:mm:ss" / plain seconds → seconds (NaN if unparseable)
function parseTime(str) {
  str = String(str || "").trim(); if (!str) return NaN;
  if (str.includes(":")) {
    const p = str.split(":").map(x => parseFloat(x));
    if (p.some(n => isNaN(n))) return NaN;
    return p.reduce((s, n) => s * 60 + n, 0);
  }
  const n = parseFloat(str); return isFinite(n) ? n : NaN;
}
// Render-range picker: choose Full video or a Custom [start,end] slice. Resolves {start,end,full} or null.
function rangeDialog(fast, total) {
  return new Promise((resolve) => {
    const bg = $("#rndRangeBg"), ok = $("#rrOk"), cancel = $("#rrCancel");
    const fieldsWrap = $("#rrFieldsWrap"), startI = $("#rrStart"), endI = $("#rrEnd"), info = $("#rrInfo");
    const modes = bg.querySelectorAll(".rr-mode");
    $("#rrTitle").textContent = fast ? "Test Render" : "Render Video";
    const fmtTotal = pvFmt(total || 0);
    let mode = "full";
    const clampR = () => {
      let s = parseTime(startI.value), e = parseTime(endI.value);
      if (!isFinite(s)) s = 0;
      if (!isFinite(e)) e = total || 0;
      s = Math.max(0, Math.min(s, total || 0));
      e = Math.max(0, Math.min(e, total || 0));
      if (e <= s) e = Math.min(total || 0, s + 1);
      return { start: s, end: e };
    };
    const updateInfo = () => {
      if (mode !== "range") { info.textContent = `Whole video · ${fmtTotal}`; return; }
      const { start, end } = clampR();
      info.textContent = `${pvFmt(start)}–${pvFmt(end)} · ${pvFmt(end - start)} of ${fmtTotal}`;
    };
    const setMode = (m) => {
      mode = m; modes.forEach(b => b.classList.toggle("on", b.dataset.mode === m));
      fieldsWrap.classList.toggle("open", m === "range");   // smooth grid-rows expand / collapse
      if (m === "range" && !endI.value) endI.value = pvFmt(Math.min(30, total || 30));
      updateInfo();
    };
    startI.oninput = updateInfo; endI.oninput = updateInfo;
    modes.forEach(b => b.onclick = () => setMode(b.dataset.mode));
    bg.querySelectorAll(".rr-chip").forEach(c => c.onclick = () => { startI.value = "0:00"; endI.value = pvFmt(Math.min(+c.dataset.secs, total || +c.dataset.secs)); updateInfo(); });
    setMode("full");
    try { $("#rrGpu").checked = localStorage.getItem("rndGpu") === "1"; $("#rrCpu").checked = localStorage.getItem("rndCpu") === "1"; } catch (e) {}
    bg.hidden = false;
    const onKey = (e) => { if (e.key === "Escape") done(null); else if (e.key === "Enter") submit(); };
    const renderOpts = () => { const gpu = $("#rrGpu").checked, cpu = $("#rrCpu").checked; try { localStorage.setItem("rndGpu", gpu ? "1" : ""); localStorage.setItem("rndCpu", cpu ? "1" : ""); } catch (e) {} return { gpu, cpu }; };
    function submit() { if (mode === "full") return done(Object.assign({ start: 0, end: total || 0, full: true }, renderOpts())); done(Object.assign({ ...clampR(), full: false }, renderOpts())); }
    function done(v) {
      ok.onclick = cancel.onclick = bg.onclick = null;
      document.removeEventListener("keydown", onKey);
      bg.classList.add("closing");                          // smooth fade-out on Cancel / Render / Escape
      setTimeout(() => { bg.hidden = true; bg.classList.remove("closing"); resolve(v); }, 175);
    }
    ok.onclick = submit; cancel.onclick = () => done(null);
    bg.onclick = (e) => { if (e.target === bg) done(null); };
    document.addEventListener("keydown", onKey);
  });
}
// Styled replacement for window.prompt — same look as confirmDialog. Resolves the trimmed input,
// or null on cancel/Escape/empty.
function promptDialog(message, { title = "Name", okText = "Save", placeholder = "", value = "" } = {}) {
  return new Promise((resolve) => {
    const bg = $("#promptBg"), ok = $("#promptOk"), cancel = $("#promptCancel"), input = $("#promptInput");
    $("#promptTitle").textContent = title;
    const msg = $("#promptMsg"); msg.textContent = message || ""; msg.hidden = !message;
    ok.textContent = okText;
    input.placeholder = placeholder; input.value = value;
    bg.hidden = false;
    input.focus(); input.select();
    const onKey = (e) => { if (e.key === "Escape") done(null); else if (e.key === "Enter") submit(); };
    function submit() { const v = input.value.trim(); done(v || null); }
    function done(v) {
      bg.hidden = true;
      ok.onclick = null; cancel.onclick = null; bg.onclick = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    }
    ok.onclick = submit;
    cancel.onclick = () => done(null);
    bg.onclick = (e) => { if (e.target === bg) done(null); };
    document.addEventListener("keydown", onKey);
  });
}
let hideApprovedVideos = false;   // Videos tab: hide approved videos toggle

const api = {
  projects: () => fetch("/api/projects").then(r => r.json()),
  createProject: (name, audience, brief) => fetch("/api/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, audience, brief }) }).then(r => r.json()),
  deleteProject: (p, mode = "disk") => fetch(`/api/projects/${p}?mode=${mode}`, { method: "DELETE" }).then(r => r.json()),
  listTrash: () => fetch(`/api/trash`).then(r => r.json()),
  restoreTrash: (t) => fetch(`/api/trash/${t}/restore`, { method: "POST" }).then(r => r.json()),
  deleteTrash: (t) => fetch(`/api/trash/${t}`, { method: "DELETE" }).then(r => r.json()),
  duplicate: (p) => fetch(`/api/projects/${p}/duplicate`, { method: "POST" }).then(r => r.json()),
  renameProject: (p, title) => fetch(`/api/projects/${p}/rename`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) }).then(r => r.json()),
  get: (p) => fetch(`/api/scenes/${p}`).then(r => r.json()),
  save: (p, doc) => fetch(`/api/scenes/${p}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(doc) }).then(r => r.json()),
  split: (p, script, signal) => fetch(`/api/scenes/${p}/split`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ script }), signal }).then(r => r.json()),
  redirect: (p, signal) => fetch(`/api/scenes/${p}/redirect`, { method: "POST", signal }).then(r => r.json()),
  analyze: (p, script, signal) => fetch(`/api/scenes/${p}/analyze`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ script }), signal }).then(r => r.json()),
  translate: (texts, source) => fetch("/api/translate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ texts, source }) }).then(r => r.json()),
  genPrompt: (p, ids, signal) => fetch(`/api/scenes/${p}/genprompt`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }), signal }).then(r => r.json()),
  generate: (p, ids) => fetch(`/api/scenes/${p}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  genVideo: (p, ids) => fetch(`/api/scenes/${p}/generate-video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  genVideoPrompt: (p, ids, signal) => fetch(`/api/scenes/${p}/gen-video-prompt`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }), signal }).then(r => r.json()),
  poll: (p) => fetch(`/api/scenes/${p}/poll`, { method: "POST" }).then(r => r.json()),
  uploadSceneRef: (p, sid, file) => { const fd = new FormData(); fd.append("file", file); return fetch(`/api/scenes/${p}/${sid}/ref`, { method: "POST", body: fd }).then(r => r.json()); },
  refScene: (p, sid, from) => fetch(`/api/scenes/${p}/${sid}/ref-scene`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ from }) }).then(r => r.json()),
  getKeys: (p) => fetch(`/api/keys/${p}`).then(r => r.json()),
  setKeys: (p, body) => fetch(`/api/keys/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  getConfig: () => fetch("/api/config").then(r => r.json()),
  setConfig: (body) => fetch("/api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json()),
  exportProject: (p) => fetch(`/api/projects/${p}/export`, { method: "POST" }).then(r => r.json()),
  exportStatus: (job) => fetch(`/api/export-status/${job}`).then(r => r.json()),
  listImports: () => fetch("/api/imports").then(r => r.json()),
  importProject: (file, overwrite) => fetch("/api/import", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file, overwrite: !!overwrite }) }).then(r => r.json()),
  deleteImport: (file) => fetch("/api/imports/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file }) }).then(r => r.json()),
  addCharacter: (p, name, files) => { const fd = new FormData(); fd.append("name", name); (Array.isArray(files) ? files : [files]).forEach(f => fd.append("file", f)); return fetch(`/api/characters/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  updateCharacter: (p, cid, { name, files } = {}) => { const fd = new FormData(); if (name) fd.append("name", name); (files || []).forEach(f => fd.append("file", f)); return fetch(`/api/characters/${p}/${cid}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeCharacterImage: (p, cid, url) => fetch(`/api/characters/${p}/${cid}/remove-image`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  delCharacter: (p, cid) => fetch(`/api/characters/${p}/${cid}`, { method: "DELETE" }).then(r => r.json()),
  addProduct: (p, files) => { const fd = new FormData(); (Array.isArray(files) ? files : [files]).forEach(f => fd.append("file", f)); return fetch(`/api/product/${p}`, { method: "POST", body: fd }).then(r => r.json()); },
  removeProduct: (p, url) => fetch(`/api/product/${p}/remove`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  renameProduct: (p, url, name) => fetch(`/api/product/${p}/rename`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, name }) }).then(r => r.json()),
  genCharacter: (p, cid, fresh) => fetch(`/api/characters/${p}/${cid}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fresh: !!fresh }) }).then(r => r.json()),
  editCharCandidate: (p, cid, url, instructions) => fetch(`/api/characters/${p}/${cid}/edit-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url, instructions }) }).then(r => r.json()),
  useCharCandidate: (p, cid, url) => fetch(`/api/characters/${p}/${cid}/use-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) }).then(r => r.json()),
  discardCharCandidate: (p, cid, opts) => fetch(`/api/characters/${p}/${cid}/discard-candidate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(opts || {}) }).then(r => r.json()),
  reorder: (p, order) => fetch(`/api/scenes/${p}/reorder`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ order }) }).then(r => r.json()),
  musicOverride: (p, index, track) => fetch(`/api/music-override/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index, track }) }).then(r => r.json()),
  musicResegment: (p) => fetch(`/api/music-resegment/${p}`, { method: "POST" }).then(r => r.json()),
  restore: (p, doc) => fetch(`/api/scenes/${p}/restore`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(doc) }).then(r => r.json()),
  editImage: (p, sid, instructions) => fetch(`/api/scenes/${p}/${sid}/edit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ instructions }) }).then(r => r.json()),
  previewPrompt: (p, sid) => fetch(`/api/scenes/${p}/${sid}/preview-prompt`).then(r => r.json()),
  setCurrent: (p, sid, index) => fetch(`/api/scenes/${p}/${sid}/current`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(r => r.json()),
  syncApprovedCurrent: (p) => fetch(`/api/scenes/${p}/sync-approved-current`, { method: "POST" }).then(r => r.json()),
  credits: (p) => fetch(`/api/credits/${p}`).then(r => r.json()),
  resetImage: (p, sid) => fetch(`/api/scenes/${p}/${sid}/reset-image`, { method: "POST" }).then(r => r.json()),
  cancelImage: (p, sid) => fetch(`/api/scenes/${p}/${sid}/cancel-image`, { method: "POST" }).then(r => r.json()),
  cancelVideo: (p, sid) => fetch(`/api/scenes/${p}/${sid}/cancel-video`, { method: "POST" }).then(r => r.json()),
  deleteVersion: (p, sid, index) => fetch(`/api/scenes/${p}/${sid}/delete-version`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index }) }).then(r => r.json()),
  resetVideo: (p, sid) => fetch(`/api/scenes/${p}/${sid}/reset-video`, { method: "POST" }).then(r => r.json()),
  videoApprove: (p, sid, approved) => fetch(`/api/scenes/${p}/${sid}/video-approve`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ approved }) }).then(r => r.json()),
  approve: (p, sid, approved, version) => fetch(`/api/scenes/${p}/${sid}/approve`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ approved, version }) }).then(r => r.json()),
  insertScene: (p, after) => fetch(`/api/scenes/${p}/insert`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ after }) }).then(r => r.json()),
  deleteScene: (p, sid) => fetch(`/api/scenes/${p}/${sid}/delete-scene`, { method: "POST" }).then(r => r.json()),
  deleteScenes: (p, ids) => fetch(`/api/scenes/${p}/delete-scenes`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).then(r => r.json()),
  duplicateScene: (p, sid) => fetch(`/api/scenes/${p}/${sid}/duplicate`, { method: "POST" }).then(r => r.json()),
  subStatus: (p) => fetch(`/api/subtitle/${p}`).then(r => r.json()),
  subCancel: (p) => fetch(`/api/subtitle/${p}/cancel`, { method: "POST" }).then(r => r.json()),
  subRun: (p, o) => {
    const fd = new FormData();
    fd.append("use_generated_vo", o.useGenVo ? "1" : "0");
    fd.append("use_script", o.useScript ? "1" : "0");
    fd.append("trim", o.trim ? "1" : "0");
    fd.append("trim_mode", o.trimMode || "natural");
    if (!o.useGenVo && o.audio) fd.append("audio", o.audio);
    if (o.useScript) fd.append("script_text", o.scriptText || "");
    else if (o.docx) fd.append("docx", o.docx);
    return fetch(`/api/subtitle/${p}`, { method: "POST", body: fd }).then(r => r.json());
  },
  getOstPresets: () => fetch(`/api/ost-presets`).then(r => r.json()),
  saveOstPresets: (presets) => fetch(`/api/ost-presets`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(presets) }).then(r => r.json()).catch(() => {}),
  getVoices: () => fetch(`/api/voices`).then(r => r.json()),
  addVoice: (name, voice_id) => fetch(`/api/voices`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, voice_id }) }).then(r => r.json()),
  delVoice: (name) => fetch(`/api/voices/${encodeURIComponent(name)}`, { method: "DELETE" }).then(r => r.json()),
  genVoiceover: (p, voice_id, text, trim, trim_mode) => fetch(`/api/voiceover/${p}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ voice_id, text, trim, trim_mode }) }).then(r => r.json()),
  videoModels: () => fetch(`/api/video-models`).then(r => r.json()),
  exportPremiere: (p) => fetch(`/api/export-premiere/${p}`, { method: "POST" }).then(r => r.json()),
};

function setStatus(t) {
  // Quiet autosave ticks ("saving…/saved") stay as the small inline indicator (typing must not spam toasts).
  if (t && /^(saving|saved)/i.test(t)) { $("#statusLine").textContent = t; return; }
  // Every other action status (submitting, generating, splitting, …) comes ONLY as a top-right toast,
  // not as text below History.
  $("#statusLine").textContent = "";
  if (t) toast(t, "info", 3800, { noHist: true });   // transient action status (submitting/splitting/…) → toast only, never clutters History
}
// stable URL so the browser CACHES the image (no reload/flicker on scroll or re-render).
// `key` (the generation taskId) changes only when the file content changes, forcing a fresh
// fetch exactly when needed (regenerate / reset-and-regenerate reuse the same filename).
function mediaUrl(rel, key) { return `/media/${PROJECT}/${rel}` + (key ? `?v=${encodeURIComponent(key)}` : ""); }
function pad2(n) { return String(n).padStart(2, "0"); }
function slug(t) { return ((t || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40)) || "scene"; }
// Download ANY server URL. Desktop app (pywebview/WebView2): <a download> / window.location don't
// trigger a save, so stream it through the native Save-As bridge in desktop.py (works for generated
// .zip exports too). Normal browser: the anchor download works as before.
function downloadUrl(url, fallbackName, label) {
  const what = label || fallbackName || "file";
  if (window.pywebview && window.pywebview.api && window.pywebview.api.save_download) {
    window.pywebview.api.save_download(url, document.cookie, fallbackName || "download").then(r => {
      if (r && r.ok) toast("Saved " + what + " — click here to open the folder", "ok", 6000,
        { onClick: () => { try { window.pywebview.api.reveal && window.pywebview.api.reveal(r.path); } catch (e) {} } });
      else if (r && !r.cancelled) toast("Save failed: " + (r.error || ""), "err");
    }).catch(() => toast("Save failed", "err"));
    return;
  }
  const a = document.createElement("a"); a.href = url; a.download = fallbackName || ""; document.body.appendChild(a); a.click(); a.remove();
  toast("Downloaded " + what, "ok");
}
function downloadMedia(rel, filename, label) { downloadUrl(`/media/${PROJECT}/${rel}?dl=${encodeURIComponent(filename)}`, filename, label); }
// open the folder that holds a render (Explorer, file selected) — desktop/local only
async function revealMedia(rel) {
  try {
    const r = await (await fetch(`/api/reveal/${PROJECT}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ file: rel }) })).json();
    if (!r || !r.ok) toast("Couldn't open the folder", "err");
  } catch (e) { toast("Couldn't open the folder", "err"); }
}
function trunc(t, n) { t = t || ""; return t.length > n ? t.slice(0, n) + "…" : t; }

// Ctrl+Scroll (and Ctrl +/-/0) page zoom for the DESKTOP window only — WebView2 has no built-in
// browser zoom, so small screens can clip. In a real browser we leave native zoom alone. On each
// change a small "100%" pill flashes top-center (like a browser) and fades after ~1.2s.
(function () {
  let DESKTOP = false, z = 1, zoomTimer = null;
  try { z = parseFloat(localStorage.getItem("uiZoom")) || 1; } catch (e) {}
  const clamp = (v) => Math.min(2.5, Math.max(0.4, Math.round(v * 100) / 100));
  const apply = () => { if (DESKTOP) document.documentElement.style.zoom = z; };
  const save = () => { try { localStorage.setItem("uiZoom", String(z)); } catch (e) {} };
  const enable = () => { DESKTOP = true; apply(); };
  if (window.pywebview) enable();
  window.addEventListener("pywebviewready", enable);
  const showZoom = () => {                    // ephemeral zoom-level pill under the History button
    let el = document.getElementById("zoomInd");
    if (!el) { el = document.createElement("div"); el.id = "zoomInd"; (document.querySelector(".tb-stack") || document.querySelector(".tb-right") || document.body).appendChild(el); }
    el.textContent = Math.round(z * 100) + "%";
    el.classList.add("show");
    clearTimeout(zoomTimer);
    zoomTimer = setTimeout(() => el.classList.remove("show"), 1200);
  };
  window.addEventListener("wheel", (e) => {
    if (!DESKTOP || !e.ctrlKey) return;
    e.preventDefault();
    z = clamp(z + (e.deltaY < 0 ? 0.1 : -0.1)); apply(); save(); showZoom();
  }, { passive: false });
  window.addEventListener("keydown", (e) => {
    if (!DESKTOP || !(e.ctrlKey || e.metaKey)) return;
    if (e.key === "=" || e.key === "+") z = clamp(z + 0.1);
    else if (e.key === "-") z = clamp(z - 0.1);
    else if (e.key === "0") z = 1;
    else return;
    e.preventDefault(); apply(); save(); showZoom();
  });
})();

// remember + restore scroll position across refreshes
try { history.scrollRestoration = "manual"; } catch (e) {}
let _scrollT;
window.addEventListener("scroll", () => {
  clearTimeout(_scrollT);
  _scrollT = setTimeout(() => { try { localStorage.setItem("scrollY", String(window.scrollY)); } catch (e) {} }, 150);
}, { passive: true });
// Scrollbars: (1) inner containers get a thin themed scrollbar shown only while scrolling;
// (2) the PAGE gets a custom overlay thumb that floats OVER the content (the native viewport
// scrollbar is hidden in CSS, so there's no reserved gutter / dark strip on the right).
(function () {
  let t;
  document.addEventListener("scroll", () => {
    document.documentElement.classList.add("scrolling");
    clearTimeout(t);
    t = setTimeout(() => document.documentElement.classList.remove("scrolling"), 900);
  }, { passive: true, capture: true });

  const bar = document.createElement("div");
  bar.id = "ovScroll";
  document.body.appendChild(bar);
  const INSET = 80;                        // top/bottom gap (px) — scrollbar starts/ends this far in
  let hideT;
  function place() {
    const dh = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
    const vh = window.innerHeight;
    if (dh <= vh + 4) { bar.style.height = "0"; return; }        // nothing to scroll
    const trackH = vh - INSET * 2;
    const thumbH = Math.max(40, trackH * (vh / dh));
    const maxScroll = dh - vh;
    const ratio = maxScroll > 0 ? window.scrollY / maxScroll : 0;
    bar.style.height = thumbH + "px";
    bar.style.top = (INSET + ratio * (trackH - thumbH)) + "px";
  }
  function show() { place(); bar.classList.add("on"); clearTimeout(hideT); hideT = setTimeout(() => bar.classList.remove("on"), 900); }
  window.addEventListener("scroll", show, { passive: true });
  window.addEventListener("resize", place, { passive: true });
  try { new ResizeObserver(place).observe(document.body); } catch (e) {}
})();

// Desktop app: mark <body> so the custom (frameless) title bar shows, and wire its window buttons.
(function () {
  function setMaxIcon(isMax) {
    document.body.classList.toggle("win-maximized", !!isMax);   // hide resize handles while maximized
    const m = document.getElementById("winMax"); if (!m) return;
    m.innerHTML = isMax
      ? '<svg viewBox="0 0 12 12"><rect x="2.2" y="3.7" width="6.1" height="6.1" rx="1"/><path d="M4.4 3.7 V2.2 H10.3 V8.1 H8.6"/></svg>'
      : '<svg viewBox="0 0 12 12"><rect x="2.7" y="2.7" width="6.6" height="6.6" rx="1"/></svg>';
    m.title = isMax ? "Restore" : "Maximize";
  }
  // edge/corner drag-resize for the frameless window (physical px via the win_set_bounds bridge)
  function wireResize(api) {
    if (!api || !api.win_bounds) return;
    let edge = null, sx = 0, sy = 0, sb = null, pending = null, raf = 0;
    const flush = () => { raf = 0; if (pending) { api.win_set_bounds(pending.x, pending.y, pending.w, pending.h); pending = null; } };
    document.querySelectorAll(".win-rz").forEach(hd => {
      hd.addEventListener("pointerdown", async (e) => {
        e.preventDefault();
        const b = await api.win_bounds(); if (!b) return;
        edge = hd.dataset.edge; sx = e.screenX; sy = e.screenY; sb = b;
        try { hd.setPointerCapture(e.pointerId); } catch (_) {}
      });
      hd.addEventListener("pointermove", (e) => {
        if (edge !== hd.dataset.edge || !sb) return;
        const dpr = window.devicePixelRatio || 1;
        const dx = Math.round((e.screenX - sx) * dpr), dy = Math.round((e.screenY - sy) * dpr);
        let x = sb.x, y = sb.y, w = sb.w, h = sb.h;
        if (edge.includes("e")) w = sb.w + dx;
        if (edge.includes("s")) h = sb.h + dy;
        if (edge.includes("w")) { x = sb.x + dx; w = sb.w - dx; }
        if (edge.includes("n")) { y = sb.y + dy; h = sb.h - dy; }
        const MINW = Math.round(900 * dpr), MINH = Math.round(600 * dpr);
        if (w < MINW) { if (edge.includes("w")) x -= (MINW - w); w = MINW; }
        if (h < MINH) { if (edge.includes("n")) y -= (MINH - h); h = MINH; }
        pending = { x, y, w, h };
        if (!raf) raf = requestAnimationFrame(flush);
        document.body.classList.remove("win-maximized");
      });
      const end = (e) => { edge = null; try { hd.releasePointerCapture(e.pointerId); } catch (_) {} };
      hd.addEventListener("pointerup", end);
      hd.addEventListener("pointercancel", end);
    });
  }
  function enable() {
    document.body.classList.add("desktop");
    const api = window.pywebview && window.pywebview.api;
    const min = document.getElementById("winMin"), max = document.getElementById("winMax"), close = document.getElementById("winClose");
    if (min) min.onclick = () => { if (api && api.win_minimize) api.win_minimize(); };
    if (max) max.onclick = () => { if (api && api.win_maximize) api.win_maximize().then(setMaxIcon); };
    if (close) close.onclick = async () => {
      const ok = await confirmDialog("Are you sure you want to close VSL Dashboard?", { title: "Close", okText: "Close", danger: true });
      if (ok && api && api.win_close) api.win_close();
    };
    const bar = document.getElementById("titlebar");
    if (bar) bar.addEventListener("dblclick", (e) => {          // double-click the bar to maximize/restore
      if (e.target.closest(".tb-win-btn")) return;
      if (api && api.win_maximize) api.win_maximize().then(setMaxIcon);
    });
    wireResize(api);
    setMaxIcon(true);   // opens maximized
  }
  if (window.pywebview) enable();
  window.addEventListener("pywebviewready", enable);
})();
function restoreScroll() {
  let y = 0; try { y = parseInt(localStorage.getItem("scrollY") || "0", 10); } catch (e) {}
  if (!y) return;
  const go = () => window.scrollTo(0, y);
  requestAnimationFrame(go);
  setTimeout(go, 250);
  setTimeout(go, 700);   // re-apply after images/layout settle
}
function setBusy(btn, on) { if (!btn) return; btn.classList.toggle("busy", on); btn.disabled = on; }
// run an async action with a spinner on the clicked button
async function withBusy(btn, fn) { setBusy(btn, true); try { await fn(); } finally { setBusy(btn, false); } }
// Like withBusy, but the button turns into a red "⏹ Stop" while running; a second click aborts the
// in-flight request. fn(signal) must forward the AbortSignal into its fetch — on abort the whole op is
// abandoned client-side (nothing is applied), so DOC stays exactly as it was before the click.
// Call sites with their own pre-checks should first run: if (btn._stopCtl) { btn._stopCtl.abort(); return; }
async function stoppable(btn, fn) {
  if (!btn) return fn(undefined);
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }        // a 2nd click while running = Stop
  const ctl = new AbortController(); btn._stopCtl = ctl;
  const keepHTML = btn.innerHTML;
  btn.classList.add("stopmode"); btn.disabled = false; btn.innerHTML = "⏹ Stop";
  try {
    await fn(ctl.signal);
  } catch (err) {
    const aborted = err && (err.name === "AbortError" || /abort/i.test(String(err.message || err)));
    if (!aborted) throw err;
    setStatus("");                                            // user cancelled — quietly stop
  } finally {
    btn._stopCtl = null; btn.classList.remove("stopmode");
    btn.innerHTML = keepHTML; btn.disabled = false;
  }
}
// Themed inline field validation — red border + shake + focus, cleared on next input (no popup).
function flagInvalid(el) {
  if (!el) return;
  el.classList.remove("invalid"); void el.offsetWidth;      // restart the shake if already flagged
  el.classList.add("invalid"); el.focus();
  el.addEventListener("input", () => el.classList.remove("invalid"), { once: true });
}

// ---------- themed right-click menu for text fields (Cut / Copy / Paste / Select All / Delete) ----------
(function () {
  let menu = null, field = null, selStart = 0, selEnd = 0;
  const replaceSel = (f, text) => {
    const a = f.selectionStart, b = f.selectionEnd;
    f.value = f.value.slice(0, a) + text + f.value.slice(b);
    const p = a + text.length; f.selectionStart = f.selectionEnd = p;
    f.dispatchEvent(new Event("input", { bubbles: true }));    // so autosave / auto-grow / translate fire
  };
  const copyText = async (s) => { try { await navigator.clipboard.writeText(s); } catch (e) { try { document.execCommand("copy"); } catch (_) {} } };
  const ACTIONS = [
    { label: "Cut", key: "Ctrl+X", needSel: true, run: async (f) => { const s = f.value.slice(f.selectionStart, f.selectionEnd); if (s) { await copyText(s); replaceSel(f, ""); } } },
    { label: "Copy", key: "Ctrl+C", needSel: true, run: async (f) => { const s = f.value.slice(f.selectionStart, f.selectionEnd); if (s) await copyText(s); } },
    { label: "Paste", key: "Ctrl+V", needSel: false, run: async (f) => { try { const t = await navigator.clipboard.readText(); if (t) replaceSel(f, t); } catch (e) {} } },
    { sep: true },
    { label: "Select All", key: "Ctrl+A", needSel: false, run: (f) => f.select() },
    { label: "Delete", key: "Del", needSel: true, run: (f) => { if (f.selectionStart !== f.selectionEnd) replaceSel(f, ""); } },
  ];
  function build() {
    menu = document.createElement("div"); menu.className = "ctx-menu"; menu.hidden = true;
    ACTIONS.forEach(a => {
      if (a.sep) { const s = document.createElement("div"); s.className = "ctx-sep"; menu.appendChild(s); return; }
      const b = document.createElement("button"); b.type = "button"; b.className = "ctx-item";
      b.innerHTML = `<span>${a.label}</span><span class="ctx-key">${a.key}</span>`;
      b.dataset.needSel = a.needSel ? "1" : "";
      b.addEventListener("mousedown", e => e.preventDefault());   // keep the field's focus + selection
      b.addEventListener("click", async () => {
        if (b.classList.contains("ctx-disabled")) return;
        const f = field; hide();
        if (f) { f.focus(); try { f.selectionStart = selStart; f.selectionEnd = selEnd; } catch (e) {} await a.run(f); }
      });
      menu.appendChild(b);
    });
    document.body.appendChild(menu);
  }
  function hide() { if (menu) menu.hidden = true; field = null; }
  function isEditable(t) {
    if (!t || t.disabled || t.readOnly) return false;
    if (t.tagName === "TEXTAREA") return true;
    if (t.tagName === "INPUT") return /^(text|search|url|email|tel|password|number|)$/i.test(t.type || "");
    return false;
  }
  document.addEventListener("contextmenu", (e) => {
    if (!isEditable(e.target)) { hide(); return; }               // only our text fields get the themed menu
    e.preventDefault();
    if (!menu) build();
    field = e.target; selStart = field.selectionStart; selEnd = field.selectionEnd;
    const hasSel = selStart !== selEnd;
    menu.querySelectorAll(".ctx-item").forEach(b => b.classList.toggle("ctx-disabled", b.dataset.needSel === "1" && !hasSel));
    menu.hidden = false;
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    let x = e.clientX, y = e.clientY;
    if (x + mw > innerWidth) x = Math.max(6, innerWidth - mw - 6);
    if (y + mh > innerHeight) y = Math.max(6, innerHeight - mh - 6);
    menu.style.left = x + "px"; menu.style.top = y + "px";
  });
  document.addEventListener("mousedown", (e) => { if (menu && !menu.hidden && !menu.contains(e.target)) hide(); });
  document.addEventListener("scroll", () => { if (menu && !menu.hidden) hide(); }, true);
  window.addEventListener("blur", hide);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") hide(); });
})();

// ---------- toast notifications (non-blocking, replace the jarring native alert) ----------
const TITLE_SMALL = new Set(["a","an","the","and","but","or","nor","for","so","yet","at","by","in",
  "of","on","to","up","as","if","per","via","off","out","with","from","into","onto","over","than"]);
function titleCase(s) {
  const parts = String(s).split(" ");
  const n = parts.length;
  return parts.map((w, i) => {
    if (!w) return w;
    const m = w.match(/^([^\p{L}]*)(\p{L}[\s\S]*)?$/u);      // split leading punctuation ("(or) → ( + or)
    const lead = m[1] || "", rest = m[2] || "";
    if (!rest) return w;
    const bare = rest.toLowerCase().replace(/[^\p{L}][\s\S]*$/u, "");   // word without trailing punctuation
    if (i > 0 && i < n - 1 && TITLE_SMALL.has(bare)) return lead + rest.toLowerCase();   // keep small words lowercase
    return lead + rest.charAt(0).toUpperCase() + rest.slice(1);
  }).join(" ");
}
function toast(msg, kind = "info", ms = 3800, opts = {}) {
  let host = $("#toastHost");
  if (!host) { host = document.createElement("div"); host.id = "toastHost"; host.className = "toast-host"; document.body.appendChild(host); }
  // Sit BELOW whatever occupies the top: the frameless title bar (34px on desktop) and, on the
  // project view, the header. On the home/login screen the header is hidden, so without the title-bar
  // baseline the toast slid up under the title bar and got clipped ("half hidden").
  let topPx = document.body.classList.contains("desktop") ? 34 : 0;
  const hdr = document.querySelector("header");
  if (hdr) { const r = hdr.getBoundingClientRect(); if (r.height > 0) topPx = Math.max(topPx, r.bottom); }
  host.style.top = (topPx + 12) + "px";
  const t = document.createElement("div");
  t.className = "toast toast-" + kind;
  t.textContent = titleCase(msg);
  host.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  const close = () => { if (t._dismissCleanup) t._dismissCleanup(); t.classList.remove("show"); setTimeout(() => t.remove(), 320); };
  t.addEventListener("click", () => { if (opts.onClick) { try { opts.onClick(); } catch (e) {} } close(); });
  if (ms > 0) armToastDismiss(t, close, ms);
  if (!opts.noHist) { try { histLog(msg, kind); } catch (e) {} }   // mirror every toast into the History panel
  return t;
}
// A toast counts down toward auto-dismiss ONLY while the user is actually looking (window focused AND
// visible). If they're away doing something else on the PC, it waits; when they return it lingers a few
// seconds so they can read it, then goes. Works in the desktop WebView (Page Visibility + window focus).
function pageSeen() { return document.visibilityState !== "hidden" && document.hasFocus(); }
function armToastDismiss(el, close, ms) {
  const linger = Math.min(Math.max(ms, 2600), 4000);   // how long it stays AFTER the user comes back
  let timer = null;
  const clear = () => { if (timer) { clearTimeout(timer); timer = null; } };
  const cleanup = () => { clear(); document.removeEventListener("visibilitychange", onChange); window.removeEventListener("focus", onChange); window.removeEventListener("blur", onChange); };
  const onChange = () => {
    if (!el.isConnected) { cleanup(); return; }
    if (pageSeen()) { clear(); timer = setTimeout(close, linger); }   // came back → linger, then dismiss
    else clear();                                                     // away → hold indefinitely
  };
  el._dismissCleanup = cleanup;
  document.addEventListener("visibilitychange", onChange);
  window.addEventListener("focus", onChange);
  window.addEventListener("blur", onChange);
  if (pageSeen()) timer = setTimeout(close, ms);   // looking right now → normal countdown
  // else: stay until they return, then onChange arms the linger timer
}
window.alert = (m) => toast(String(m), "err");   // route every validation/error alert to an error toast
// Suppress ALL native hover tooltips program-wide. The browser only shows a `title` tooltip after a short
// hover delay, so stripping `title` the instant the pointer enters an element (mouseover) prevents it from
// ever appearing — for static AND dynamically-created elements, however the title was set. The value is
// parked in data-title so nothing that might read it later breaks.
document.addEventListener("mouseover", (e) => {
  let el = e.target;
  while (el && el.nodeType === 1) {
    if (el.hasAttribute && el.hasAttribute("title")) {
      const t = el.getAttribute("title");
      if (t) el.setAttribute("data-title", t);
      el.removeAttribute("title");
    }
    el = el.parentElement;
  }
}, true);
// Error surfacing that ALWAYS uses our toast (never a native popup) and detects the Kie credit/balance
// case so it reads clearly instead of dumping a raw provider string. Also lands in the History panel.
function toastErr(msg) {
  const m = String(msg || "").trim() || "Something went wrong.";
  if (/credit|balance|insufficient|top ?up|quota/i.test(m))
    return toast("⚠ Kie.ai balance too low — top up your credits (and check Settings → API Keys is the funded account).", "err", 14000);
  return toast("⚠ " + m, "err", 9000);
}

// ---------- tabs ----------
// one green highlight that GLIDES to the active tab instead of jumping
const tabsNav = $(".tabs");
const tabSlider = document.createElement("span");
tabSlider.className = "tab-slider";
if (tabsNav) tabsNav.appendChild(tabSlider);
let tabSliderPlaced = false;
function placeTabSlider(animate) {
  const active = $(".tab.active");
  if (!active || !tabsNav || !active.offsetWidth) return;   // skip while hidden (offsetWidth 0)
  if (!animate) tabSlider.style.transition = "none";         // no slide for the first placement
  tabSlider.style.width = active.offsetWidth + "px";
  tabSlider.style.height = active.offsetHeight + "px";
  tabSlider.style.transform = `translate(${active.offsetLeft}px, ${active.offsetTop}px)`;
  tabSlider.classList.add("on");
  if (!animate) { void tabSlider.offsetWidth; tabSlider.style.transition = ""; }   // reflow, then restore CSS transition
}
const tabScroll = {};          // remember each tab's scroll position so switching back lands where you left
let currentTab = null;
function activateTab(name) {
  if (currentTab && currentTab !== name) tabScroll[currentTab] = window.scrollY;   // save where we were
  $$(".tab").forEach(x => x.classList.toggle("active", x.dataset.tab === name));
  document.body.classList.toggle("tab-scenes", name === "scenes");   // shows the scene navigation rail
  document.body.classList.toggle("tab-videos", name === "videos");   // shows the video navigation rail
  $$(".tab-panel").forEach(x => x.classList.remove("active"));
  $(`#tab-${name}`).classList.add("active");
  try { localStorage.setItem("lastTab", name); } catch (e) {}
  placeTabSlider(tabSliderPlaced);   // first placement instant, later ones glide
  tabSliderPlaced = true;
  if (name === "videos") renderVideos();
  if (name === "export") { pvSyncFromDoc(); setTimeout(pvRepaint, 50); }   // reflect re-approved scenes + repaint the paused frame (not black)
  // refs thumbnails are sized from the container's laid-out height, which is 0 while the tab is
  // hidden — (re)fit them once Scenes is visible
  if (name === "scenes") [0, 120].forEach(d => setTimeout(() => { document.querySelectorAll(".scene-refs-list").forEach(fitRefs); redrawAllOst(); autoGrowAllVo(); }, d));
  // restore this tab's previous scroll position (0 the first time we open it).
  // setTimeout(0), not rAF: runs after the panel-swap reflow so the page is already tall
  // enough to scroll to y (and it fires reliably even when rAF is throttled).
  const y = tabScroll[name] || 0;
  const wasTab = currentTab;
  currentTab = name;
  if (wasTab !== name) setTimeout(() => window.scrollTo(0, y), 0);
  if (typeof sizeHistoryBar === "function") requestAnimationFrame(sizeHistoryBar);   // header visible now → size History to the trio
}
$$(".tab").forEach(t => t.addEventListener("click", () => activateTab(t.dataset.tab)));
window.addEventListener("resize", () => placeTabSlider(false));
// the first placement can be off before layout/fonts settle (e.g. refreshing on a restored
// non-first tab, where the slider lands mid-tab) — re-measure once everything has loaded
window.addEventListener("load", () => placeTabSlider(false));
if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => placeTabSlider(false));

// ---------- fake loading overlay (shown briefly when opening a project) ----------
const loadOverlay = document.createElement("div");
loadOverlay.className = "load-overlay";
loadOverlay.innerHTML = '<div class="load-anim"><span></span><span></span><span></span></div><div class="load-text"></div>';
document.body.appendChild(loadOverlay);
function showLoading(name) {
  loadOverlay.querySelector(".load-text").textContent = name ? `Opening ${name}…` : "Loading…";
  loadOverlay.classList.add("show");
}
function hideLoading() { loadOverlay.classList.remove("show"); }

// ---------- home ----------
// smooth collapse-out of a single home row (no full re-render pop); the -10px margin eats the flex
// gap so the rows below slide up cleanly.
function collapseRow(row) {
  row.style.height = row.offsetHeight + "px";
  void row.offsetHeight;
  row.classList.add("removing");
  row.style.height = "0px";
  row.style.marginBottom = "-10px";
  setTimeout(() => row.remove(), 340);
}
async function showHome() {
  tabSliderPlaced = false;   // re-open a project → place the highlight instantly, no stale glide
  document.body.classList.add("on-home");
  PROJECT = null; DOC = null;
  try { localStorage.removeItem("lastProject"); } catch (e) {}
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  const list = await api.projects();
  const box = $("#homeList");
  box.innerHTML = "";
  list.forEach(p => {
    const row = document.createElement("div");
    row.className = "proj-row";
    const b = document.createElement("button");
    b.className = "proj-item";
    b.innerHTML = `<span class="t"></span><span class="meta"></span>`;
    b.querySelector(".t").textContent = p.title;
    b.querySelector(".meta").textContent = `${p.scenes} scenes`;
    b.addEventListener("click", () => openProject(p.name, p.title));   // loader shows the display title
    const edit = document.createElement("button");
    edit.className = "proj-edit"; edit.title = "Rename Project"; edit.textContent = "✏️";
    edit.addEventListener("click", (e) => { e.stopPropagation(); openRenameModal(p); });
    const dup = document.createElement("button");
    dup.className = "proj-dup"; dup.title = "Duplicate Project"; dup.textContent = "⧉";
    dup.addEventListener("click", (e) => { e.stopPropagation(); withBusy(dup, async () => {
      const r = await api.duplicate(p.name);
      if (r.error) { alert(r.error); return; }
      toast(`Duplicated → “${r.title}”`, "ok");
      showHome();
    }); });
    const exp = document.createElement("button");
    exp.className = "proj-exp"; exp.title = "Export — write a .zip to the sync folder"; exp.innerHTML = EXPORT_SVG;
    exp.addEventListener("click", (e) => { e.stopPropagation(); withBusy(exp, async () => {
      const start = await api.exportProject(p.name);
      if (start.error) {
        if (start.error === "no-sync-dir") toast("First set a sync folder under Settings → API Keys", "err");
        else if (start.error === "sync-dir-missing") toast("Sync folder not found — check the path", "err");
        else toast("Export failed: " + start.error, "err");
        return;
      }
      await pollExport(start.job, p.title || start.title || p.name);
    }); });
    const del = document.createElement("button");
    del.className = "proj-del"; del.title = "Delete Project"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", async () => {
      const choice = await deleteProjectDialog(p.title);
      if (!choice) return;
      if (choice === "disk") {
        // second, explicit warning before an irreversible disk wipe
        if (!(await confirmDialog(`Permanently delete “${p.title}” from this computer? Its scenes, images and videos will be erased and cannot be recovered.`, { title: "Delete From Disk", okText: "Delete Forever" }))) return;
        const r = await api.deleteProject(p.name, "disk");
        if (r.error) { alert(r.error); return; }
        collapseRow(row);
        return;
      }
      // soft: move to trash (no warning), then offer an immediate Undo
      const r = await api.deleteProject(p.name, "dashboard");
      if (r.error) { alert(r.error); return; }
      collapseRow(row);
      toast(`Removed “${p.title}” — tap to undo`, "ok", 6000, { onClick: async () => {
        const rr = await api.restoreTrash(r.trash);
        if (rr.error) { toast("Restore failed: " + rr.error, "err"); return; }
        toast(`Restored “${rr.title}”`, "ok");
        showHome();
      } });
    });
    row.appendChild(b); row.appendChild(edit); row.appendChild(dup); row.appendChild(exp); row.appendChild(del);
    box.appendChild(row);
  });
  const nw = document.createElement("button");
  nw.className = "proj-new";
  nw.textContent = "+ New Project";
  nw.addEventListener("click", () => openModal("new"));
  box.appendChild(nw);
  const utilRow = document.createElement("div");
  utilRow.className = "proj-util-row";
  const imp = document.createElement("button");
  imp.className = "proj-import";
  imp.innerHTML = `${IMPORT_SVG}<span>Import a Project</span>`;
  imp.addEventListener("click", openImportModal);
  utilRow.appendChild(imp);
  const trash = document.createElement("button");
  trash.className = "proj-import proj-trash-btn";
  trash.innerHTML = `${TRASH_SVG}<span>Removed Projects</span>`;
  trash.addEventListener("click", openTrashModal);
  utilRow.appendChild(trash);
  box.appendChild(utilRow);
  box.classList.remove("home-enter"); void box.offsetWidth; box.classList.add("home-enter");   // glide the items in
}
async function openProject(name, loadLabel, tab) {
  if (typeof resetHistory === "function") resetHistory();   // clear the activity log when switching projects
  PROJECT = name;
  try { localStorage.setItem("lastProject", name); } catch (e) {}
  if (loadLabel) {
    showLoading(loadLabel);                // loadLabel = the display TITLE, not the folder name
    await new Promise(r => setTimeout(r, 340));   // let the loader FADE IN over the home first
  }
  document.body.classList.remove("on-home");   // then swap to the project view BEHIND the opaque loader
  activateTab(tab || "script");            // land on the requested tab (from a reload) instead of always resetting to script
  // keep the loader up a moment longer so the transition feels deliberate, then reveal
  const minWait = loadLabel ? new Promise(r => setTimeout(r, 1150)) : Promise.resolve();
  try {
    await loadDoc();
    rndReset();               // pick up a render this project already has (or one still running)
    await minWait;
  } catch (e) {
    toast("Could not open the project — please try again.", "err");   // never leave the loader stuck
  } finally {
    if (loadLabel) hideLoading();
  }
  // On load, silently restore the preview ONLY if it's byte-for-byte unchanged since the last build
  // (restore mode): instant, no re-buffer, no spinner. If anything changed — or it was never built —
  // the preview stays blank until the user clicks Build / Re-build Preview themselves.
  if (DOC && DOC.preview_built) buildPreview(null, true);
}
async function boot() {
  renderVoices();       // load the saved ElevenLabs voices now that we're authenticated (was failing pre-auth)
  loadVideoModels();    // same: video model / duration / quality dropdowns need the authed fetch
  loadOstPresets();     // load saved on-screen-text style presets from the server (+ migrate localStorage)
  let last = null, t = null, title = null;
  try { last = localStorage.getItem("lastProject"); t = localStorage.getItem("lastTab"); title = localStorage.getItem("lastTitle"); } catch (e) {}
  const tab = ["script", "scenes", "videos", "export"].includes(t) ? t : "script";
  if (last) {
    // Paint the saved tab + project name SYNCHRONOUSLY (before the first paint / the async load) so a
    // reload lands exactly where you were — no script-tab flash, no tiny-empty-name flash.
    document.body.classList.remove("on-home");
    const pn = document.getElementById("projName"); if (pn && title) pn.textContent = title;
    document.body.classList.toggle("tab-scenes", tab === "scenes");
    document.body.classList.toggle("tab-videos", tab === "videos");
    $$(".tab").forEach(x => x.classList.toggle("active", x.dataset.tab === tab));
    $$(".tab-panel").forEach(x => x.classList.toggle("active", x.id === `tab-${tab}`));
    const list = await api.projects();
    if (list.find(p => p.name === last)) {
      await openProject(last, null, tab);   // load onto the saved tab (no reset to script)
      // re-place after layout AND any glide transition settle — a single early rAF can measure
      // the tab before the grid sizes it, leaving the slider stuck mid-bar until the next click
      [120, 400, 800].forEach(d => setTimeout(() => placeTabSlider(false), d));
      restoreScroll();
      return;
    }
  }
  showHome();
}
// Set the project-name button text and smoothly animate its width old→new, so the Home / Settings
// buttons beside it slide out/in instead of jumping when you switch projects.
function setProjName(text) {
  const btn = document.getElementById("projName");
  if (!btn) return;
  text = text || "";
  if (!btn.textContent) { btn.textContent = text; return; }   // first set: no animation
  if (btn.textContent === text) return;
  const startW = btn.getBoundingClientRect().width;
  btn.textContent = text;
  btn.style.width = "auto";
  const endW = btn.getBoundingClientRect().width;
  btn.style.width = startW + "px";
  void btn.offsetWidth;                                        // reflow at the start width
  btn.style.transition = "width .32s cubic-bezier(.33,1,.68,1)";
  btn.style.width = endW + "px";
  clearTimeout(btn._nameAnim);
  btn._nameAnim = setTimeout(() => { btn.style.transition = ""; btn.style.width = ""; }, 340);
}
async function loadDoc() {
  if (!PROJECT) return;
  DOC = await api.get(PROJECT);
  // On (re)open, an APPROVED scene must show its APPROVED image version — not whatever version was last
  // flipped-to before leaving (version-flipping persists `current`). Snap approved scenes back to their
  // approved version in memory for an immediate correct render, and persist it so a later poll can't undo it.
  const needFix = (DOC.scenes || []).filter(s => {
    const im = s.image; if (!(s.approved && im)) return false;
    const av = im.approved_version, n = (im.versions || []).length;
    return Number.isInteger(av) && av >= 0 && av < n && im.current !== av;
  });
  if (needFix.length) {
    needFix.forEach(s => { s.image.current = s.image.approved_version; s.image.file = s.image.versions[s.image.approved_version]; });
    try { await api.syncApprovedCurrent(PROJECT); } catch (e) {}
  }
  setProjName(DOC.title || PROJECT);
  try { localStorage.setItem("lastTitle", DOC.title || PROJECT); } catch (e) {}   // for an instant, flicker-free reload
  $("#scriptText").value = DOC.script || "";
  undoStack = []; redoStack = []; _textBase = null; updateUndoBtn();   // fresh undo/redo history per project
  renderScenes(); renderVideos(); updateSplitBtn();
  ensurePolling(); renderGenProgress();
  if (subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
  $("#subAudioName").textContent = "No file selected";
  $("#subDocxName").textContent = "No file selected";
  $("#subAudio").value = ""; $("#subDocx").value = "";
  // only restore a RUNNING job on open; never surface a stale "ready/done" from a past run
  api.subStatus(PROJECT).then(st => {
    updateSrtBtn(st);                                       // reflect an existing SRT in the button label
    if (st && st.status === "running") renderSubStatus(st);
    else { $("#subStatus").hidden = true; $("#subResult").hidden = true; }
  });
}

// ---------- tab 1: script ----------
$("#splitBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop (don't re-run the pre-checks)
  if (!PROJECT) { alert("Create a project first."); return; }
  const script = $("#scriptText").value.trim();
  if (!script) return;
  if (DOC.scenes.length && !(await confirmDialog("This rebuilds all scenes from the script. Continue?", { title: "Rebuild Scenes", okText: "Continue", danger: false }))) return;
  if (DOC.scenes.length) pushUndo("split into scenes");
  await stoppable(btn, async (signal) => {
    setStatus("splitting into scenes…");
    const res = await api.split(PROJECT, script, signal);
    if (res.error) { toastErr(res.error); setStatus(""); return; }
    const warn = res.director_warning, note = res.director_note;
    DOC = res; DOC.script = script; delete DOC.director_warning; delete DOC.director_note; await api.save(PROJECT, DOC);
    $("#splitInfo").textContent = `${DOC.scenes.length} scenes created →`;
    renderScenes(); updateSplitBtn();
    activateTab("scenes");
    if (note) toast(note, "info");   // which model actually ran the director (Fable 5 / Opus 4.8)
    if (warn) toast(warn, "err");    // director couldn't write some prompts — surfaced, never silently raw-VO'd
    else toast(`${DOC.scenes.length} scenes ready.`, "ok");
    if (autoTr()) { setStatus("translating to Turkish…"); await translateAllScenes(); }   // FR/DE only
    setStatus("");
  });
});
// Analyze Cast: read the whole script, detect the recurring people, add them to the project's Cast so
// the user can give each a reference photo BEFORE splitting → same face across every scene.
const _analyzeBtn = $("#analyzeBtn");
if (_analyzeBtn) _analyzeBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!PROJECT) { alert("Create a project first."); return; }
  const script = $("#scriptText").value.trim();
  if (!script) { alert("Paste your script first."); return; }
  await stoppable(btn, async (signal) => {
    setStatus("analyzing cast…");
    let res;
    try { res = await api.analyze(PROJECT, script, signal); }
    catch (err) { if (err && (err.name === "AbortError" || /abort/i.test(String(err)))) throw err; setStatus(""); alert("Analyze failed: " + err); return; }
    setStatus("");
    if (res.error) { toastErr(res.error); return; }
    DOC = res.doc; DOC.script = script;
    const det = res.detected || [];
    openModal("edit"); setModalTab("cast", false);           // land on the Cast tab so photos can be added
    toast(det.length
      ? `Detected ${det.length} character${det.length > 1 ? "s" : ""} — give each a reference photo (upload one, or ✨ generate one) for a consistent face, then Split.`
      : "No recurring characters found — you can Split; ordinary people stay generic.",
      det.length ? "ok" : "info");
  });
});
// editing the script re-opens the Split / SRT buttons (→ "Re-Split Into Scenes" / "Re-Generate SRT")
$("#scriptText").addEventListener("input", updateGenBtns);

// ---------- tab 1: subtitles (SRT) ----------
let subPollTimer = null;
function bindFileDrop(inputSel, nameSel) {
  const inp = $(inputSel), nm = $(nameSel);
  inp.addEventListener("change", () => { nm.textContent = inp.files[0] ? inp.files[0].name : "No file selected"; });
}
bindFileDrop("#subAudio", "#subAudioName");
bindFileDrop("#subDocx", "#subDocxName");
// auto-source toggles: when checked, hide the matching upload (default: both on)
function syncSubSources() {
  const upload = !$("#subUseGenVo").checked;              // manual audio upload mode
  const hasAudio = $("#subAudio").files.length > 0;      // a file has actually been picked
  $("#subAudioDrop").hidden = !upload;
  $("#subDocxDrop").hidden = $("#subUseScript").checked;
  // trim option shows only after a voice-over file is uploaded (between the two upload boxes)
  const showTrim = upload && hasAudio;
  $("#subTrimWrap").hidden = !showTrim;
  if (!showTrim) $("#subTrim").checked = false;
  $("#subTrimModeWrap").hidden = !(showTrim && $("#subTrim").checked);
}
$("#subUseGenVo").addEventListener("change", syncSubSources);
$("#subUseScript").addEventListener("change", syncSubSources);
$("#subTrim").addEventListener("change", syncSubSources);
$("#subAudio").addEventListener("change", syncSubSources);
syncSubSources();

function renderSubStatus(st) {
  const box = $("#subStatus"), res = $("#subResult");
  const running = st && st.status === "running";
  box.hidden = !(running || (st && st.status === "error"));
  $(".sub-spin", box).hidden = !running;
  if (st && st.status === "error") { $(".sub-step", box).textContent = "⚠ " + (st.error || "failed"); }
  else if (running) { $(".sub-step", box).textContent = st.step || "Working…"; }
  res.hidden = !(st && st.status === "done" && st.srt);
  $("#subDownloadMp3Btn").hidden = !(st && st.status === "done" && st.trimmed);
  // while the SRT job runs, the Generate button becomes a red "⏹ Stop" (subtitle jobs are long — the
  // user must be able to abort). setGenBtn() skips relabelling any button in stopmode, so the label sticks.
  const rb = $("#subRunBtn");
  if (rb) {
    rb.classList.toggle("stopmode", !!running);
    if (running) { rb.textContent = "⏹ Stop"; rb.disabled = false; }
  }
  if (running && !subPollTimer) startSubPolling();
  if (!running && subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
  updateSrtBtn(st);
}
// Reflect completion on the Script page: once a project has scenes / an SRT, the button switches to a
// darker-green "…Generated" label (still clickable to redo).
let _hasSrt = false;
function scriptChanged() {   // has the script been edited since the last split / SRT?
  return !!(DOC && ($("#scriptText").value || "").trim() !== (DOC.script || "").trim());
}
function setGenBtn(b, label, done) {
  if (!b) return;
  if (b.classList.contains("stopmode") || b._stopCtl) return;   // mid-generation: keep the red "⏹ Stop" label
  const apply = () => { b.textContent = label; b.classList.toggle("gen-done", done); b.disabled = done || b.classList.contains("busy"); };
  if (b.textContent && b.textContent !== label) {   // smooth: quick fade-out → swap → fade-in on state change
    b.style.transition = "opacity .16s ease"; b.style.opacity = "0";
    clearTimeout(b._genAnim);
    b._genAnim = setTimeout(() => { apply(); b.style.opacity = "1"; }, 160);
  } else { apply(); }
}
function updateGenBtns() {
  const changed = scriptChanged();
  const hasScenes = !!(DOC && DOC.scenes && DOC.scenes.length);
  setGenBtn($("#splitBtn"), !hasScenes ? "Split Into Scenes →" : changed ? "Re-Split Into Scenes" : "✓ Scenes Generated", hasScenes && !changed);
  setGenBtn($("#subRunBtn"), !_hasSrt ? "Generate SRT →" : changed ? "Re-Generate SRT" : "✓ SRT Generated", _hasSrt && !changed);
}
function updateSplitBtn() { updateGenBtns(); }                              // kept for existing call sites
function updateSrtBtn(st) { if (st !== undefined) _hasSrt = !!(st && st.srt); updateGenBtns(); }
function startSubPolling() {
  subPollTimer = setInterval(async () => {
    if (!PROJECT) return;
    const st = await api.subStatus(PROJECT);
    renderSubStatus(st);
  }, 3000);
}
$("#subRunBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn.classList.contains("stopmode")) {                 // a job is running → Stop it
    btn.disabled = true;
    try { await api.subCancel(PROJECT); } catch (_) {}
    btn.disabled = false; btn.classList.remove("stopmode");
    if (subPollTimer) { clearInterval(subPollTimer); subPollTimer = null; }
    $("#subStatus").hidden = true;
    updateGenBtns(); setStatus("");
    toast("Subtitle generation stopped.", "info");
    return;
  }
  if (!PROJECT) { alert("Create or open a project first."); return; }
  const useGenVo = $("#subUseGenVo").checked, useScript = $("#subUseScript").checked;
  const audio = $("#subAudio").files[0], docx = $("#subDocx").files[0];
  const scriptText = $("#scriptText").value.trim();
  if (!useGenVo && !audio) { alert("Select the voice-over .mp3 (or tick “use the voice-over generated above”)."); return; }
  if (useScript && !scriptText) { alert("The script box on the left is empty."); return; }
  if (!useScript && !docx) { alert("Select the script .docx (or tick “use the script from the left”)."); return; }
  const trim = useGenVo ? false : $("#subTrim").checked;
  const trimMode = $("#subTrimMode").value;
  await withBusy(e.currentTarget, async () => {
    const r = await api.subRun(PROJECT, { audio, docx, useGenVo, useScript, scriptText, trim, trimMode });
    if (r.error) { alert(r.error); return; }
    renderSubStatus({ status: "running", step: "Starting…" });
  });
});
$("#subDownloadBtn").addEventListener("click", async () => {
  const st = await api.subStatus(PROJECT);
  if (st && st.srt) downloadMedia(st.srt, st.srt_name || "subtitles.srt");
});
$("#subDownloadMp3Btn").addEventListener("click", async () => {
  const st = await api.subStatus(PROJECT);
  if (st && st.trimmed) downloadMedia(st.trimmed, st.trimmed_name || "voiceover_trimmed.mp3");
});

// ---------- tab 1: voice-over (ElevenLabs) ----------
async function renderVoices() {
  const menu = $("#voVoicesMenu");
  if (!menu) return;
  const voices = await api.getVoices();
  menu.innerHTML = "";
  if (!voices.length) {
    const empty = document.createElement("div"); empty.className = "vo-empty"; empty.textContent = "No saved voices yet";
    menu.appendChild(empty);
    return;
  }
  voices.forEach(v => {
    const row = document.createElement("div"); row.className = "vo-opt-row";
    const pick = document.createElement("button");
    pick.className = "model-opt"; pick.textContent = v.name;
    pick.title = v.voice_id || "no voice ID saved";
    pick.addEventListener("click", (e) => { e.stopPropagation(); $("#voVoiceId").value = v.voice_id || ""; menu.hidden = true; });
    const del = document.createElement("button");
    del.className = "vo-opt-x"; del.textContent = "×"; del.title = "Remove";
    del.addEventListener("click", async (e) => { e.stopPropagation(); await api.delVoice(v.name); renderVoices(); });
    row.appendChild(pick); row.appendChild(del);
    menu.appendChild(row);
  });
}
$("#voVoicesBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  const menu = $("#voVoicesMenu");
  const willOpen = menu.hidden;
  $$(".model-menu").forEach(m => m.hidden = true);
  menu.hidden = !willOpen;
});
$("#voTrim").addEventListener("change", () => { $("#voTrimModeWrap").hidden = !$("#voTrim").checked; });
$("#voSaveToggle").addEventListener("click", () => {
  const f = $("#voSaveForm");
  f.hidden = !f.hidden;
  if (!f.hidden) $("#voSaveName").focus();
});
$("#voSaveConfirm").addEventListener("click", async () => {
  const name = $("#voSaveName").value.trim();
  const vid = $("#voVoiceId").value.trim();
  if (!name) { alert("Type a name for this voice."); return; }
  if (!vid) { alert("Enter a Voice ID in the box above first."); return; }
  const r = await api.addVoice(name, vid);
  if (r.error) { alert(r.error); return; }
  $("#voSaveName").value = ""; $("#voSaveForm").hidden = true;
  renderVoices();
});
$("#voGenBtn").addEventListener("click", async (e) => {
  if (!PROJECT) { alert("Create or open a project first."); return; }
  const voiceId = $("#voVoiceId").value.trim();
  const text = $("#scriptText").value.trim();
  if (!voiceId) { alert("Enter a Voice ID (or click a saved voice)."); return; }
  if (!text) { alert("The script box on the left is empty."); return; }
  const status = $("#voStatus"), step = $(".vo-step", status), spin = $(".sub-spin", status);
  status.hidden = false; spin.hidden = false; step.textContent = "Generating voice-over…";
  $("#voResult").hidden = true;
  await withBusy(e.currentTarget, async () => {
    const r = await api.genVoiceover(PROJECT, voiceId, text, $("#voTrim").checked, $("#voTrimMode").value);
    if (r.error) { step.textContent = "⚠ " + r.error; spin.hidden = true; return; }
    status.hidden = true;
    $("#voAudio").src = mediaUrl(r.file, Date.now());   // fresh per generation
    $("#voResult").hidden = false;
    $("#voDownloadBtn").onclick = () => downloadMedia(r.file, r.name || "voiceover.mp3");
  });
});
// NOTE: voices are loaded inside boot() (which runs AFTER sign-in). Calling it here at module load
// would hit /api/voices while still on the login gate → 401 → an empty dropdown that never refills.

// ---------- image model selector (per scene) ----------
const MODEL_OPTIONS = [
  { key: "nano-banana-2", label: "NanoBanana 2" },
  { key: "gpt-image-2", label: "GPT Image 2" },
  { key: "seedream-5-pro", label: "Seedream 5.0 Pro" },
];
function modelLabel(key) { return (MODEL_OPTIONS.find(m => m.key === key) || MODEL_OPTIONS[0]).label; }
function buildModelDropdown(container, s) {
  if (!container) return;
  const cur = s.model || "nano-banana-2";
  container.innerHTML = "";
  const btn = document.createElement("button");
  btn.className = "model-btn";
  btn.innerHTML = `Model: <b></b> <span class="caret">▾</span>`;
  btn.querySelector("b").textContent = modelLabel(cur);
  const menu = document.createElement("div");
  menu.className = "model-menu"; menu.hidden = true;
  MODEL_OPTIONS.forEach(m => {
    const o = document.createElement("button");
    o.className = "model-opt" + (m.key === (s.model || "nano-banana-2") ? " sel" : "");
    o.textContent = m.label;
    o.addEventListener("click", (e) => {
      e.stopPropagation();
      s.model = m.key;
      btn.querySelector("b").textContent = m.label;
      [...menu.children].forEach(c => c.classList.toggle("sel", c === o));
      menu.hidden = true;
      queueSave();
    });
    menu.appendChild(o);
  });
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = menu.hidden;
    $$(".model-menu").forEach(mm => mm.hidden = true);   // close others
    menu.hidden = !willOpen;
  });
  container.appendChild(btn); container.appendChild(menu);
}
// click anywhere else closes any open model menu
document.addEventListener("click", () => { $$(".model-menu").forEach(m => m.hidden = true); });

// video model capability matrix (durations/resolutions per model) — fetched once
let VIDEO_MODELS = [];
// Loaded inside boot() (AFTER sign-in). At module load we're still on the login gate, so
// /api/video-models would 401 → VIDEO_MODELS stays empty → the Videos tab shows no model/
// duration/quality dropdowns. (Same pre-auth pitfall as the voices list.)
function loadVideoModels() {
  return api.videoModels().then(m => { VIDEO_MODELS = m || []; if (PROJECT && DOC) renderVideos(); }).catch(() => {});
}
// generic labeled dropdown (reuses the model dropdown styling)
function vDropdown(container, prefix, curLabel, items, onPick) {
  if (!container) return;
  container.innerHTML = "";
  const btn = document.createElement("button");
  btn.className = "model-btn";
  btn.innerHTML = `${prefix}: <b></b> <span class="caret">▾</span>`;
  btn.querySelector("b").textContent = curLabel;
  const menu = document.createElement("div");
  menu.className = "model-menu"; menu.hidden = true;
  items.forEach(it => {
    const o = document.createElement("button");
    o.className = "model-opt" + (it.selected ? " sel" : "");
    o.textContent = it.label;
    o.addEventListener("click", (e) => { e.stopPropagation(); menu.hidden = true; onPick(it.value); });
    menu.appendChild(o);
  });
  btn.addEventListener("click", (e) => { e.stopPropagation(); const open = menu.hidden; $$(".model-menu").forEach(m => m.hidden = true); menu.hidden = !open; });
  container.appendChild(btn); container.appendChild(menu);
}

// camera framing/angle options (keys must match app.py CAMERA_ANGLES)
// on-screen text overlay — fonts (must exist on the render machine too) and animations.
// EVERY animation also fades in (see the CSS keyframes / the render ass tags).
const OST_FONTS = ["Arial", "Montserrat", "Poppins", "Open Sans", "Roboto", "Geomini", "Inter", "Google Sans", "Noto Serif", "Flatshoes"];
const OST_ANIMS = [
  { key: "none",         label: "None" },
  { key: "fade",         label: "Fade in" },
  { key: "popup",        label: "Pop-up" },
  { key: "slide-left",   label: "Slide from left" },
  { key: "slide-right",  label: "Slide from right" },
  { key: "slide-top",    label: "Slide from top" },
  { key: "slide-bottom", label: "Slide from bottom" },
];
const OST_OUT_ANIMS = [
  { key: "none",         label: "None" },
  { key: "fade",         label: "Fade out" },
  { key: "pop",          label: "Pop out" },
  { key: "slide-left",   label: "Slide out left" },
  { key: "slide-right",  label: "Slide out right" },
  { key: "slide-top",    label: "Slide out top" },
  { key: "slide-bottom", label: "Slide out bottom" },
];
const OST_WEIGHTS = [
  { v: "300", l: "Light" }, { v: "400", l: "Regular" }, { v: "500", l: "Medium" },
  { v: "600", l: "Semibold" }, { v: "700", l: "Bold" }, { v: "800", l: "Extrabold" }, { v: "900", l: "Black" },
];
// hex (#RRGGBB) + alpha (0..1) -> rgba() for the background box
function hexToRgba(hex, a) {
  const h = (hex || "#000000").replace("#", "");
  const n = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
  const r = parseInt(n.slice(0, 2), 16) || 0, g = parseInt(n.slice(2, 4), 16) || 0, b = parseInt(n.slice(4, 6), 16) || 0;
  return `rgba(${r},${g},${b},${a})`;
}
// map a scene's ost_* fields (or a timeline scene's text_* fields) to the shared style object
function ostOpts(s) {
  return { fill: s.ost_fill !== false, color: s.ost_color, font: s.ost_font, size: s.ost_size, weight: s.ost_weight,
    bold: s.ost_bold, italic: s.ost_italic, upper: s.ost_upper, underline: s.ost_underline,
    letter: s.ost_letter, leading: s.ost_leading, shadow: s.ost_shadow !== false,
    shadow_color: s.ost_shadow_color, shadow_opacity: s.ost_shadow_opacity, shadow_size: s.ost_shadow_size, shadow_dir: s.ost_shadow_dir,
    stroke: s.ost_stroke !== false, stroke_w: s.ost_stroke_w, stroke_color: s.ost_stroke_color,
    bg: !!s.ost_bg, bg_color: s.ost_bg_color, bg_opacity: s.ost_bg_opacity, bg_pad: s.ost_bg_pad, bg_radius: s.ost_bg_radius };
}
// Map a raw overlay (ov.onscreen + ov.ost_*) to the timeline shape the preview player consumes
// (mirror of _overlay_timeline in app.py) so the preview can refresh OST without a server rebuild.
function ovToTL(ov) {
  return {
    text: (ov.onscreen || "").trim(),
    text_fill: ov.ost_fill !== false, text_color: ov.ost_color || "#ffffff", text_font: ov.ost_font || "Arial",
    text_size: parseInt(ov.ost_size) || 56, text_weight: String(ov.ost_weight || "400"),
    text_bold: !!ov.ost_bold, text_italic: !!ov.ost_italic, text_upper: !!ov.ost_upper, text_underline: !!ov.ost_underline,
    text_letter: parseInt(ov.ost_letter) || 0, text_leading: parseFloat(ov.ost_leading) || 1.15,
    text_place: ov.ost_place || "top", text_x: parseInt(ov.ost_x) || 0, text_y: parseInt(ov.ost_y) || 0,
    text_rotation: parseInt(ov.ost_rotation) || 0,
    text_stroke: ov.ost_stroke !== false, text_stroke_w: parseInt(ov.ost_stroke_w) || 0,
    text_stroke_color: ov.ost_stroke_color || "#000000", text_stroke_pos: ov.ost_stroke_pos || "outer",
    text_bg: !!ov.ost_bg, text_bg_color: ov.ost_bg_color || "#000000", text_bg_opacity: parseInt(ov.ost_bg_opacity) || 0,
    text_bg_pad: parseInt(ov.ost_bg_pad) || 0, text_bg_radius: parseInt(ov.ost_bg_radius) || 0,
    text_shadow: ov.ost_shadow !== false, text_shadow_color: ov.ost_shadow_color || "#000000",
    text_shadow_opacity: parseInt(ov.ost_shadow_opacity) || 0, text_shadow_size: parseInt(ov.ost_shadow_size) || 0,
    text_shadow_dir: parseInt(ov.ost_shadow_dir) || 0,
    text_anim: ov.ost_anim || "fade", text_out_anim: ov.ost_out_anim || "none",
    text_in: ov.ost_in != null ? +ov.ost_in : 0, text_out: ov.ost_out != null ? +ov.ost_out : 1,
  };
}
function sceneTL(s) {   // timeline texts for a scene (mirror of _scene_overlays)
  if (!s || !s.ost_on) return [];
  return (s.overlays || []).filter(ov => (ov.onscreen || "").trim()).map(ovToTL);
}
function ostOptsTL(sc) {
  return { fill: sc.text_fill !== false, color: sc.text_color, font: sc.text_font, size: sc.text_size, weight: sc.text_weight,
    bold: sc.text_bold, italic: sc.text_italic, upper: sc.text_upper, underline: sc.text_underline,
    letter: sc.text_letter, leading: sc.text_leading, shadow: sc.text_shadow !== false,
    shadow_color: sc.text_shadow_color, shadow_opacity: sc.text_shadow_opacity, shadow_size: sc.text_shadow_size, shadow_dir: sc.text_shadow_dir,
    stroke: sc.text_stroke !== false, stroke_w: sc.text_stroke_w, stroke_color: sc.text_stroke_color,
    bg: !!sc.text_bg, bg_color: sc.text_bg_color, bg_opacity: sc.text_bg_opacity, bg_pad: sc.text_bg_pad, bg_radius: sc.text_bg_radius };
}
// on-screen-text slider popovers (Stroke/Background/Drop shadow): close on click-outside
function closeAllPops() { document.querySelectorAll(".ost-pop:not([hidden])").forEach(p => { p.hidden = true; }); }
document.addEventListener("click", (e) => { if (!e.target.closest(".ost-feat")) closeAllPops(); });

// ---- custom colour picker (singleton; replaces the native OS swatch dialog) ----
const CPICK = (() => {
  const clamp = (v) => Math.min(1, Math.max(0, v));
  function hsvToRgb(h, s, v) {
    h /= 360; const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    const m = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6];
    return { r: Math.round(m[0] * 255), g: Math.round(m[1] * 255), b: Math.round(m[2] * 255) };
  }
  function hexToRgb(hex) { const h = (hex || "").replace("#", ""); if (!/^[0-9a-f]{6}$/i.test(h)) return null; return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) }; }
  const toHex = (r, g, b) => "#" + [r, g, b].map(x => x.toString(16).padStart(2, "0")).join("");
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0; if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return { h, s: mx ? d / mx : 0, v: mx };
  }
  let el, sv, svThumb, hue, hex, prev, H = 0, S = 0, V = 0, onChange = null, anchor = null;
  function ensure() {
    if (el) return;
    el = document.getElementById("colorPicker"); if (!el) return;
    sv = el.querySelector(".cpick-sv"); svThumb = el.querySelector(".cpick-sv-thumb");
    hue = el.querySelector(".cpick-hue"); hex = el.querySelector(".cpick-hex"); prev = el.querySelector(".cpick-preview");
    const svPick = (e) => { const r = sv.getBoundingClientRect(); S = clamp((e.clientX - r.left) / r.width); V = clamp(1 - (e.clientY - r.top) / r.height); emit(true); };
    sv.addEventListener("pointerdown", (e) => { try { sv.setPointerCapture(e.pointerId); } catch (x) {} svPick(e); const mv = (ev) => svPick(ev); const up = () => { sv.removeEventListener("pointermove", mv); sv.removeEventListener("pointerup", up); }; sv.addEventListener("pointermove", mv); sv.addEventListener("pointerup", up); });
    hue.addEventListener("input", () => { H = +hue.value; emit(true); });
    hex.addEventListener("input", () => { const rgb = hexToRgb(hex.value.trim()); if (rgb) { const c = rgbToHsv(rgb.r, rgb.g, rgb.b); H = c.h; S = c.s; V = c.v; render(); if (onChange) onChange(hex.value.trim()); } });
    document.addEventListener("click", (e) => { if (el && !el.hidden && !el.contains(e.target) && e.target !== anchor && !(anchor && anchor.contains && anchor.contains(e.target))) el.hidden = true; });
  }
  function render() {
    sv.style.backgroundColor = "hsl(" + H + ",100%,50%)";
    svThumb.style.left = (S * 100) + "%"; svThumb.style.top = ((1 - V) * 100) + "%";
    const { r, g, b } = hsvToRgb(H, S, V), hx = toHex(r, g, b);
    prev.style.background = hx; if (document.activeElement !== hex) hex.value = hx; hue.value = Math.round(H);
    return hx;
  }
  function emit(cb) { const hx = render(); if (cb && onChange) onChange(hx); }
  return {
    open(anchorEl, hexColor, cb) {
      ensure(); if (!el) return;
      if (!el.hidden && anchor === anchorEl) { el.hidden = true; return; }   // click same swatch again → close
      anchor = anchorEl; onChange = cb;
      const rgb = hexToRgb(hexColor) || { r: 255, g: 255, b: 255 }, c = rgbToHsv(rgb.r, rgb.g, rgb.b);
      H = c.h; S = c.s; V = c.v; el.hidden = false; render();
      const r = anchorEl.getBoundingClientRect(), W = 216, Ht = 190;
      let left = r.left + window.scrollX, top = r.bottom + 6 + window.scrollY;
      left = Math.max(8, Math.min(left, window.scrollX + window.innerWidth - W));
      if (r.bottom + Ht > window.innerHeight) top = r.top + window.scrollY - Ht - 6;
      el.style.left = left + "px"; el.style.top = top + "px";
    }
  };
})();
function clampNum(val, min, max, def, float) {
  let v = float ? parseFloat(val) : parseInt(val);
  if (isNaN(v)) return def;
  return Math.min(max, Math.max(min, v));
}
// press + drag left/right on a number input to scrub its value (a click still focuses to type)
function makeScrubbable(inp) {
  inp.classList.add("scrubbable");
  inp.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const startX = e.clientX, startVal = parseFloat(inp.value) || 0;
    const step = parseFloat(inp.step) || 1, dec = String(inp.step).includes(".") ? 2 : 0;
    const min = inp.min !== "" ? parseFloat(inp.min) : -1e9, max = inp.max !== "" ? parseFloat(inp.max) : 1e9;
    let active = false;
    const move = (ev) => {
      const dx = ev.clientX - startX;
      if (!active) { if (Math.abs(dx) < 4) return; active = true; try { inp.setPointerCapture(e.pointerId); } catch (x) {} }
      ev.preventDefault();
      let v = Math.min(max, Math.max(min, startVal + (dx / 5) * step));
      inp.value = dec ? v.toFixed(dec) : String(Math.round(v));
      inp.dispatchEvent(new Event("input", { bubbles: true }));
    };
    const up = () => { inp.removeEventListener("pointermove", move); inp.removeEventListener("pointerup", up); };
    inp.addEventListener("pointermove", move);
    inp.addEventListener("pointerup", up);
  });
}
// shared text styling for the overlay in preview + scene card (color/font/weight/style flags/
// leading/letter-spacing/shadow/stroke/background box)
function ostTextStyle(el, o, scale) {
  el.style.color = o.color || "#ffffff";
  el.style.webkitTextFillColor = (o.fill === false) ? "transparent" : (o.color || "#ffffff");   // Fill off = stroke only
  el.style.fontFamily = `"${o.font || "Arial"}", sans-serif`;
  el.style.fontSize = ((o.size || 56) * scale).toFixed(1) + "px";
  el.style.lineHeight = String(o.leading || 1.15);
  el.style.fontWeight = String(o.bold ? 800 : (parseInt(o.weight) || 400));
  el.style.fontStyle = o.italic ? "italic" : "normal";
  el.style.textDecoration = o.underline ? "underline" : "none";
  el.style.textTransform = o.upper ? "uppercase" : "none";
  el.style.letterSpacing = ((o.letter || 0) * scale).toFixed(2) + "px";
  if (o.shadow) {                                 // drop shadow: colour / opacity / size / direction
    const sz = (o.shadow_size != null ? o.shadow_size : 6) * scale;
    const rad = (o.shadow_dir != null ? o.shadow_dir : 135) * Math.PI / 180;
    const ox = (sz * Math.cos(rad)).toFixed(1), oy = (sz * Math.sin(rad)).toFixed(1);
    const col = hexToRgba(o.shadow_color || "#000000", (o.shadow_opacity != null ? o.shadow_opacity : 80) / 100);
    el.style.textShadow = `${ox}px ${oy}px ${(sz).toFixed(1)}px ${col}`;
  } else { el.style.textShadow = "none"; }
  const sw = (o.stroke && o.stroke_w > 0) ? o.stroke_w * scale : 0;
  el.style.webkitTextStroke = sw > 0 ? `${sw.toFixed(2)}px ${o.stroke_color || "#000000"}` : "0px";
  el.style.paintOrder = "stroke fill";
  if (o.bg) {                                     // background box hugs the text (padding = "Size")
    el.style.background = hexToRgba(o.bg_color || "#000000", (o.bg_opacity != null ? o.bg_opacity : 60) / 100);
    el.style.padding = ((o.bg_pad || 0) * scale).toFixed(1) + "px";
    el.style.borderRadius = ((o.bg_radius || 0) * scale).toFixed(1) + "px";
  } else {
    el.style.background = "none"; el.style.padding = "0"; el.style.borderRadius = "0";
  }
}
// position the placement wrapper (centre horizontally + placement anchor + X/Y offset + rotation)
function ostWrapPos(wrap, place, x, y, scale, rotation) {
  const tx = (x || 0) * scale, ty = (y || 0) * scale;
  const rot = rotation ? ` rotate(${rotation}deg)` : "";
  wrap.style.transform = (place === "center")
    ? `translate(calc(-50% + ${tx.toFixed(1)}px), calc(-50% + ${ty.toFixed(1)}px))${rot}`
    : `translate(calc(-50% + ${tx.toFixed(1)}px), ${ty.toFixed(1)}px)${rot}`;
}
// Make an on-screen-text overlay directly draggable / resizable / rotatable on the image.
// It mutates ov.* live and mirrors the values into the panel inputs via sync(); commit() saves.
// scale = preview px per 1920 unit, so screen deltas convert straight to ost_x/ost_y units.
const OST_INP = { ost_x: ".ost-x", ost_y: ".ost-y", ost_rotation: ".ost-rot", ost_size: ".ost-size" };
// snap the dragged overlay's edges/centre to the image centre and to other overlays (Figma-style guides).
// returns pixel nudges (dx/dy) to apply and the guide-line positions (gx/gy, screen px) or null.
function ostSnap(ostEl, container, th) {
  const R = ostEl.getBoundingClientRect(), IR = container.getBoundingClientRect();
  const others = [...container.querySelectorAll(".scene-ost")].filter(e => e !== ostEl).map(e => e.getBoundingClientRect());
  const pick = (pts, targets) => {
    let best = null;
    pts.forEach(p => targets.forEach(t => { const d = t - p; if (Math.abs(d) < th && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, g: t }; }));
    return best;
  };
  const txX = [IR.left + IR.width / 2]; others.forEach(o => txX.push(o.left + o.width / 2, o.left, o.right));
  const txY = [IR.top + IR.height / 2]; others.forEach(o => txY.push(o.top + o.height / 2, o.top, o.bottom));
  const bx = pick([R.left + R.width / 2, R.left, R.right], txX);
  const by = pick([R.top + R.height / 2, R.top, R.bottom], txY);
  return { dx: bx ? bx.d : 0, dy: by ? by.d : 0, gx: bx ? bx.g : null, gy: by ? by.g : null };
}
function ostGuides(container, gx, gy) {
  const IR = container.getBoundingClientRect();
  const put = (cls, on, pos, prop) => {
    let g = container.querySelector("." + cls);
    if (on == null) { if (g) g.remove(); return; }
    if (!g) { g = document.createElement("div"); g.className = "ost-guide " + cls; container.appendChild(g); }
    g.style[prop] = (pos - (prop === "left" ? IR.left : IR.top)) + "px";
  };
  put("ost-guide-v", gx, gx, "left"); put("ost-guide-h", gy, gy, "top");
}
function ostClearGuides(container) { container.querySelectorAll(".ost-guide").forEach(n => n.remove()); }
function ostInteractive(ostEl, ov, scale, container, cb) {
  ostEl.classList.add("ost-editable");
  const rotH = document.createElement("div"); rotH.className = "ost-h ost-h-rot"; rotH.title = "Rotate";
  const sizeH = document.createElement("div"); sizeH.className = "ost-h ost-h-size"; sizeH.title = "Resize";
  const delB = document.createElement("button"); delB.className = "ost-del-btn"; delB.textContent = "×"; delB.title = "Delete this text";
  ostEl.append(rotH, sizeH, delB);
  const span = ostEl.querySelector("span");
  delB.addEventListener("pointerdown", e => e.stopPropagation());
  delB.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); if (cb.onDelete) cb.onDelete(); });
  const start = (e, mode) => {
    e.preventDefault(); e.stopPropagation();
    container.querySelectorAll(".scene-ost.ost-selected").forEach(n => n.classList.remove("ost-selected"));
    ostEl.classList.add("ost-selected");                 // highlight the one you grabbed
    const r = ostEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const s0 = { x: e.clientX, y: e.clientY, ox: +ov.ost_x || 0, oy: +ov.ost_y || 0, rot: +ov.ost_rotation || 0,
      size: +ov.ost_size || 56, ang: Math.atan2(e.clientY - cy, e.clientX - cx), dist: Math.hypot(e.clientX - cx, e.clientY - cy) || 1 };
    ostEl.classList.add("ost-dragging");
    const move = (ev) => {
      if (mode === "move") {
        ov.ost_x = Math.round(s0.ox + (ev.clientX - s0.x) / scale);
        ov.ost_y = Math.round(s0.oy + (ev.clientY - s0.y) / scale);
        ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
        const snap = ostSnap(ostEl, container, 6);        // pull to centre / other overlays
        if (snap.dx || snap.dy) {
          ov.ost_x = Math.round(ov.ost_x + snap.dx / scale);
          ov.ost_y = Math.round(ov.ost_y + snap.dy / scale);
          ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
        }
        ostGuides(container, snap.gx, snap.gy);
        cb.sync("ost_x", ov.ost_x); cb.sync("ost_y", ov.ost_y);
      } else if (mode === "rot") {
        let d = s0.rot + (Math.atan2(ev.clientY - cy, ev.clientX - cx) - s0.ang) * 180 / Math.PI;
        d = Math.max(-180, Math.min(180, Math.round(d)));
        if (Math.abs(d) < 4) d = 0;                       // snap to upright
        ov.ost_rotation = d;
        ostWrapPos(ostEl, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, d);
        cb.sync("ost_rotation", d);
      } else {   // resize -> font size, scaled by how far the corner is dragged from the centre
        let sz = Math.max(12, Math.min(1000, Math.round(s0.size * Math.hypot(ev.clientX - cx, ev.clientY - cy) / s0.dist)));
        ov.ost_size = sz;
        if (span) ostTextStyle(span, ostOpts(ov), scale);
        cb.sync("ost_size", sz);
      }
    };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      ostEl.classList.remove("ost-dragging"); ostClearGuides(container); cb.commit();
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  ostEl.addEventListener("pointerdown", e => start(e, "move"));
  rotH.addEventListener("pointerdown", e => start(e, "rot"));
  sizeH.addEventListener("pointerdown", e => start(e, "size"));
}
// live on-screen-text overlay drawn on a scene card's image preview, so you SEE the styling/placement
function drawSceneOst(el, s) {
  const prev = el.querySelector(".img-preview"); if (!prev) return;
  prev.querySelectorAll(".scene-ost").forEach(n => n.remove());      // redraw all overlays
  if (!s.ost_on) return;                                             // section off = no overlay
  // scale = preview px per 1920 unit. NEVER use a guessed fallback width — a wrong scale makes the text
  // jump size between renders. If the preview isn't laid out yet (0 width), retry next frame when visible,
  // else bail (redrawAllOst() on tab-activation / resize will draw it once it has a real width).
  const w = prev.clientWidth || Math.round(prev.getBoundingClientRect().width);
  if (!w) { if (prev.offsetParent) requestAnimationFrame(() => drawSceneOst(el, s)); return; }
  const scale = w / 1920;
  (s.overlays || []).forEach((ov, i) => {
    const txt = (ov.onscreen || "").trim(); if (!txt) return;
    const ost = document.createElement("div"); ost.innerHTML = '<span class="scene-ost-txt"></span>';
    ost.className = "scene-ost place-" + (ov.ost_place || "top");
    prev.appendChild(ost);
    ostWrapPos(ost, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
    const span = ost.querySelector(".scene-ost-txt");
    span.textContent = txt;
    ostTextStyle(span, ostOpts(ov), scale);
    const panel = el.querySelectorAll(".ost-panel")[i];   // mirror drags into this overlay's inputs
    const delBtn = panel && panel.querySelector(".ost-del-overlay");
    ostInteractive(ost, ov, scale, prev, {
      sync: (f, v) => { const inp = panel && panel.querySelector(OST_INP[f]); if (inp) inp.value = v; },
      commit: () => queueSave(),
      onDelete: () => { if (delBtn) delBtn.click(); },   // reuse the panel's remove (animation + rebuild)
    });
  });
}
function redrawAllOst() {
  document.querySelectorAll(".scene-row").forEach(el => {
    const s = (DOC.scenes || []).find(x => x.id === +el.dataset.id);
    if (s) drawSceneOst(el, s);
  });
}
function newOverlay() {   // default look = the saved "Montserrat White" style (matches OST_OVERLAY_DEFAULTS in app.py)
  return { onscreen: "", ost_fill: true, ost_color: "#ffffff", ost_font: "Montserrat", ost_size: 115, ost_weight: "800",
    ost_bold: false, ost_italic: false, ost_upper: true, ost_underline: false, ost_letter: 0, ost_leading: 0.85,
    ost_place: "center", ost_x: 0, ost_y: 0, ost_rotation: 0,
    ost_stroke: false, ost_stroke_w: 4, ost_stroke_color: "#000000", ost_stroke_pos: "outer",
    ost_bg: false, ost_bg_color: "#000000", ost_bg_opacity: 60, ost_bg_pad: 12, ost_bg_radius: 8,
    ost_shadow: false, ost_shadow_color: "#000000", ost_shadow_opacity: 80, ost_shadow_size: 6, ost_shadow_dir: 135,
    ost_anim: "slide-bottom", ost_out_anim: "fade" };
}
// on-screen-text STYLE preset keys (look only — not the text, fine offset, rotation or timing)
const OST_STYLE_KEYS = ["ost_fill", "ost_color", "ost_font", "ost_size", "ost_weight", "ost_bold", "ost_italic",
  "ost_upper", "ost_underline", "ost_letter", "ost_leading", "ost_place",
  "ost_stroke", "ost_stroke_w", "ost_stroke_color", "ost_stroke_pos",
  "ost_bg", "ost_bg_color", "ost_bg_opacity", "ost_bg_pad", "ost_bg_radius",
  "ost_shadow", "ost_shadow_color", "ost_shadow_opacity", "ost_shadow_size", "ost_shadow_dir",
  "ost_anim", "ost_out_anim"];
// OST style presets — now SERVER-SIDE (data/ost_presets.json) so they persist across app restarts
// and travel with the data folder to another PC. Backed by an in-memory cache so the callers stay
// synchronous; localStorage is kept only as an offline mirror + migration source.
let OST_PRESETS = null;
function ostPresets(set) {
  if (set !== undefined) {
    OST_PRESETS = set;
    try { localStorage.setItem("ostStylePresets", JSON.stringify(set)); } catch (e) {}
    api.saveOstPresets(set);   // persist server-side (fire-and-forget)
    return set;
  }
  if (OST_PRESETS) return OST_PRESETS;
  try { return JSON.parse(localStorage.getItem("ostStylePresets") || "[]"); } catch (e) { return []; }
}
async function loadOstPresets() {
  try {
    const server = await api.getOstPresets();
    let local = [];
    try { local = JSON.parse(localStorage.getItem("ostStylePresets") || "[]"); } catch (e) {}
    if ((!Array.isArray(server) || !server.length) && local.length) {
      OST_PRESETS = local; api.saveOstPresets(local);   // one-time migration of browser-saved presets
    } else {
      OST_PRESETS = Array.isArray(server) ? server : [];
      try { localStorage.setItem("ostStylePresets", JSON.stringify(OST_PRESETS)); } catch (e) {}
    }
  } catch (e) { /* server unreachable → stay on the localStorage value */ }
}
// wire one overlay panel's controls to an overlay object; redraw() re-renders the scene-card overlays,
// rebuild() re-builds all overlay panels from the overlays (used after applying a style preset)
function wireOstPanel(panel, ov, redraw, rebuild, presetKind) {
  const q = (sel) => panel.querySelector(sel);
  const qa = (sel) => panel.querySelectorAll(sel);
  const changed = () => redraw();
  const kind = presetKind || "ost";   // "ost" = on-screen text presets, "subtitle" = subtitle presets (kept separate)
  const ofKind = (list) => list.filter(p => (p.kind || "ost") === kind);
  // --- style presets (save this look, apply it to another) — scoped to this panel's kind ---
  const psSave = q(".ost-preset-save"), psApply = q(".ost-preset-apply"), psMenu = q(".ost-preset-menu");
  if (psSave) psSave.addEventListener("click", async (e) => {
    e.stopPropagation();
    const name = await promptDialog("Give this style a name so you can re-apply it later.", { title: kind === "subtitle" ? "Save Subtitle Style" : "Save Style Preset", okText: "Save", placeholder: "e.g. Big yellow headline" });
    if (!name) return;
    const presets = ostPresets(), style = {};
    OST_STYLE_KEYS.forEach(k => style[k] = ov[k]);
    const ex = presets.findIndex(p => p.name === name && (p.kind || "ost") === kind);
    if (ex >= 0) { presets[ex].style = style; presets[ex].kind = kind; } else presets.push({ name, style, kind });
    ostPresets(presets);
    toast(`Style preset saved: ${name}`, "ok");
  });
  if (psApply) psApply.addEventListener("click", (e) => {
    e.stopPropagation();
    const wasOpen = !psMenu.hidden;
    $$(".model-menu").forEach(m => m.hidden = true);
    if (wasOpen) return;
    const presets = ofKind(ostPresets());   // only this kind's presets show here
    psMenu.innerHTML = "";
    if (!presets.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No presets yet — save one first"; psMenu.appendChild(d); }
    presets.forEach(p => {
      const row = document.createElement("div"); row.className = "ost-preset-opt";
      const nm = document.createElement("span"); nm.className = "ost-preset-name"; nm.textContent = p.name;
      nm.addEventListener("click", () => {
        OST_STYLE_KEYS.forEach(k => { if (p.style[k] !== undefined) ov[k] = p.style[k]; });
        psMenu.hidden = true; if (rebuild) rebuild(); redraw(); queueSave();
        toast(`Applied style: ${p.name}`, "ok");
      });
      const del = document.createElement("button"); del.className = "ost-preset-del ghost"; del.textContent = "×"; del.title = "Delete this preset";
      del.addEventListener("click", (ev) => { ev.stopPropagation(); ostPresets(ostPresets().filter(x => !(x.name === p.name && (x.kind || "ost") === kind))); row.remove(); if (!psMenu.querySelector(".ost-preset-opt")) psMenu.hidden = true; });
      row.append(nm, del); psMenu.appendChild(row);
    });
    psMenu.hidden = false;
  });
  const ta = q(".onscreen"); if (ta) { ta.value = ov.onscreen || ""; ta.addEventListener("input", e => { ov.onscreen = e.target.value; changed(); }); }   // absent on the global subtitle panel (no text box)
  // --- selects ---
  const ostFont = q(".ost-font"), ostWeight = q(".ost-weight"), ostAnim = q(".ost-anim"), ostOut = q(".ost-out-anim");
  OST_FONTS.forEach(f => ostFont.appendChild(new Option(f, f, false, f === (ov.ost_font || "Arial"))));
  OST_WEIGHTS.forEach(w => ostWeight.appendChild(new Option(w.l, w.v, false, w.v === String(ov.ost_weight || "400"))));
  OST_ANIMS.forEach(a => ostAnim.appendChild(new Option(a.label, a.key, false, a.key === (ov.ost_anim || "fade"))));
  OST_OUT_ANIMS.forEach(a => ostOut.appendChild(new Option(a.label, a.key, false, a.key === (ov.ost_out_anim || "none"))));
  ostFont.addEventListener("change", e => { ov.ost_font = e.target.value; changed(); });
  ostWeight.addEventListener("change", e => { ov.ost_weight = e.target.value; changed(); });
  ostAnim.addEventListener("change", e => { ov.ost_anim = e.target.value; changed(); });
  ostOut.addEventListener("change", e => { ov.ost_out_anim = e.target.value; changed(); });
  // --- numeric inputs ---
  const numWire = (sel, key, min, max, def, float) => {
    const inp = q(sel); if (!inp) return;
    inp.value = (ov[key] != null ? ov[key] : def);
    inp.addEventListener("input", e => { ov[key] = clampNum(e.target.value, min, max, def, float); changed(); });
  };
  numWire(".ost-size", "ost_size", 12, 1000, 56);
  numWire(".ost-leading", "ost_leading", 0.8, 3, 1.15, true);
  numWire(".ost-letter", "ost_letter", -20, 60, 0);
  numWire(".ost-x", "ost_x", -2000, 2000, 0);
  numWire(".ost-y", "ost_y", -2000, 2000, 0);
  numWire(".ost-rot", "ost_rotation", -180, 180, 0);
  // --- colours + eyedroppers ---
  const colWire = (sel, key, def) => {
    const inp = q(sel); inp.value = ov[key] || def;
    inp.addEventListener("input", e => { ov[key] = e.target.value; changed(); });
    inp.addEventListener("click", (e) => { e.preventDefault(); CPICK.open(inp, inp.value, (hx) => { inp.value = hx; inp.dispatchEvent(new Event("input", { bubbles: true })); }); });
  };
  colWire(".ost-color", "ost_color", "#ffffff");
  colWire(".ost-stroke-color", "ost_stroke_color", "#000000");
  colWire(".ost-bg-color", "ost_bg_color", "#000000");
  colWire(".ost-shadow-color", "ost_shadow_color", "#000000");
  const eyeMap = { color: [".ost-color", "ost_color"], stroke: [".ost-stroke-color", "ost_stroke_color"], bg: [".ost-bg-color", "ost_bg_color"], shadow: [".ost-shadow-color", "ost_shadow_color"] };
  qa(".ost-eyedrop").forEach(btn => {
    if (!window.EyeDropper) { btn.hidden = true; return; }
    btn.addEventListener("click", async () => {
      const [csel, ckey] = eyeMap[btn.dataset.eye] || [];
      try { const r = await new EyeDropper().open(); const inp = q(csel); inp.value = r.sRGBHex; ov[ckey] = r.sRGBHex; changed(); } catch (x) {}
    });
  });
  // --- checkboxes: fill / stroke / background / shadow ---
  const chkWire = (sel, key, def, after) => {
    const inp = q(sel); inp.checked = (ov[key] != null ? !!ov[key] : def);
    inp.addEventListener("change", e => { ov[key] = e.target.checked; if (after) after(e.target.checked); changed(); });
  };
  const showCw = (cwSel, on) => { const cw = q(cwSel); if (cw) cw.hidden = !on; };
  chkWire(".ost-fill", "ost_fill", true, (on) => showCw(".ost-cw-fill", on));
  showCw(".ost-cw-fill", ov.ost_fill !== false);
  const featWire = (chkSel, key, def, cwSel) => {
    const chk = q(chkSel), feat = chk.closest(".ost-feat"), pop = feat.querySelector(".ost-pop");
    const title = feat.querySelector(".ost-feat-title");
    chk.checked = (ov[key] != null ? !!ov[key] : def);
    showCw(cwSel, chk.checked);
    if (pop) pop.hidden = true;
    // checkbox = enable / disable only (no longer opens the values popover)
    chk.addEventListener("change", () => { ov[key] = chk.checked; showCw(cwSel, chk.checked); changed(); });
    // clicking the heading text opens/closes the values popover (Opacity / Size / Radius …), without toggling
    if (title && pop) title.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const willOpen = pop.hidden; closeAllPops(); pop.hidden = !willOpen;
    });
  };
  featWire(".ost-stroke", "ost_stroke", true, ".ost-cw-stroke");
  featWire(".ost-bg", "ost_bg", false, ".ost-cw-bg");
  featWire(".ost-shadow", "ost_shadow", true, ".ost-cw-shadow");
  // --- sliders with live read-outs ---
  const rngWire = (sel, key, def, vsel, suffix) => {
    const inp = q(sel); if (!inp) return;
    const vEl = q(vsel);
    inp.value = (ov[key] != null ? ov[key] : def);
    const show = () => { if (vEl) vEl.textContent = inp.value + (suffix || ""); };
    show();
    inp.addEventListener("input", e => { ov[key] = clampNum(e.target.value, +inp.min, +inp.max, def); show(); changed(); });
  };
  rngWire(".ost-stroke-w", "ost_stroke_w", 4, ".ost-stroke-w-v", "");
  rngWire(".ost-bg-opacity", "ost_bg_opacity", 60, ".ost-bg-opacity-v", "%");
  rngWire(".ost-bg-pad", "ost_bg_pad", 12, ".ost-bg-pad-v", "");
  rngWire(".ost-bg-radius", "ost_bg_radius", 8, ".ost-bg-radius-v", "");
  rngWire(".ost-shadow-opacity", "ost_shadow_opacity", 80, ".ost-shadow-opacity-v", "%");
  rngWire(".ost-shadow-size", "ost_shadow_size", 6, ".ost-shadow-size-v", "");
  rngWire(".ost-shadow-dir", "ost_shadow_dir", 135, ".ost-shadow-dir-v", "°");
  // --- placement icon buttons ---
  qa(".ost-place-btn").forEach(b => {
    b.classList.toggle("on", b.dataset.place === (ov.ost_place || "top"));
    b.addEventListener("click", () => {
      ov.ost_place = b.dataset.place;
      ov.ost_x = 0; ov.ost_y = 0;                       // placement snaps to its clean anchor, independent of the X/Y position
      const xi = q(".ost-x"), yi = q(".ost-y"); if (xi) xi.value = 0; if (yi) yi.value = 0;
      qa(".ost-place-btn").forEach(x => x.classList.toggle("on", x === b));
      changed();
    });
  });
  // --- Bold / Italic / UPPERCASE / Underline toggles ---
  const sbKey = { bold: "ost_bold", italic: "ost_italic", upper: "ost_upper", underline: "ost_underline" };
  qa(".ost-sb").forEach(b => {
    const key = sbKey[b.dataset.sb];
    b.classList.toggle("on", !!ov[key]);
    b.addEventListener("click", () => { ov[key] = !ov[key]; b.classList.toggle("on", !!ov[key]); changed(); });
  });
  qa(".scrub").forEach(makeScrubbable);
}

const CAMERA_OPTIONS = [
  { key: "none",    label: "None" },
  { key: "closeup", label: "Close-up" },
  { key: "extreme", label: "Extreme Close-up" },
  { key: "medium",  label: "Medium Shot" },
  { key: "wide",    label: "Wide Shot" },
  { key: "ots",     label: "Over the Shoulder" },
  { key: "top",     label: "Top View" },
  { key: "side",    label: "Side View" },
];
const cameraLabel = k => (CAMERA_OPTIONS.find(c => c.key === k) || CAMERA_OPTIONS.find(c => c.key === "medium")).label;
function buildCameraDropdown(container, s) {
  if (!container) return;
  const cur = s.camera || "medium";
  vDropdown(container, "Camera", cameraLabel(cur),
    CAMERA_OPTIONS.map(c => ({ value: c.key, label: c.label, selected: c.key === cur })),
    (v) => { s.camera = v; buildCameraDropdown(container, s); queueSave(); });   // rebuild to refresh the label
  // reflect the chosen camera as a badge next to the Image-prompt label so it's clear it's baked into
  // the image at generation (empty when camera = none)
  const row = container.closest(".scene-row");
  const badge = row && row.querySelector(".cam-badge");
  if (badge) badge.textContent = (cur && cur !== "none") ? "🎥 " + cameraLabel(cur) : "";
}

// scene transition = how this scene hands off to the NEXT one (keys must match app.py TRANSITIONS).
const TRANSITION_OPTIONS = [
  { key: "none",        label: "No Transition" },
  { key: "crossfade",   label: "Crossfade" },
  { key: "dip-black",   label: "Dip to Black" },
  { key: "dip-white",   label: "Flash (White)" },
  { key: "slide-left",  label: "Slide Left" },
  { key: "slide-right", label: "Slide Right" },
  { key: "slide-up",    label: "Slide Up" },
  { key: "slide-down",  label: "Slide Down" },
];
const transitionLabel = k => (TRANSITION_OPTIONS.find(t => t.key === k) || TRANSITION_OPTIONS[0]).label;
function buildTransitionDropdown(container, s) {
  if (!container) return;
  const cur = s.transition || "none";
  vDropdown(container, "Transition", transitionLabel(cur),
    TRANSITION_OPTIONS.map(t => ({ value: t.key, label: t.label, selected: t.key === cur })),
    (v) => { s.transition = v; buildTransitionDropdown(container, s); queueSave(); });
}

// ---------- tab 2: scenes ----------
function updateSceneCounts() {
  const scenes = DOC?.scenes || [];
  const total = scenes.length;
  const withImg = scenes.filter(s => (s.image?.versions || []).length || s.image?.file).length;
  const approved = scenes.filter(s => s.approved).length;
  const el = $("#scenesApproveCount");
  // combined: how many scenes total, how many have an image generated, how many approved
  if (el) el.textContent = total ? `${total} scenes · ${withImg} images generated · ${approved} approved` : "";
}
$("#hideApprovedBtn").addEventListener("click", () => {
  hideApproved = !hideApproved;
  const b = $("#hideApprovedBtn");
  b.classList.toggle("on", hideApproved);
  b.textContent = hideApproved ? "🙉 Show Approved" : "🙈 Hide Approved";
  renderScenes();
});
$("#hideApprovedVidBtn").addEventListener("click", () => {
  hideApprovedVideos = !hideApprovedVideos;
  const b = $("#hideApprovedVidBtn");
  b.classList.toggle("on", hideApprovedVideos);
  b.textContent = hideApprovedVideos ? "🙉 Show Approved" : "🙈 Hide Approved";
  renderVideos();
});
let _flashApprove = null;   // scene id to play the approve check-burst on after the next render (#7)
let _flashImg = null;       // scene id to crossfade the image on after the next render (version switch)
let _flashApproveVideo = null;   // same, but for the Videos tab
// Update a scene card's approved state in place (approved class + ✓ button) instead of a full
// renderScenes — so the reference thumbnails and on-screen-text swatches don't flash away and rebuild.
function patchApprove(el, s, cur, bA) {
  const approvedThis = s.approved && (s.image || {}).approved_version === cur;
  el.classList.toggle("approved", !!s.approved);
  bA.classList.toggle("on", approvedThis);
  bA.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
  if (approvedThis) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); }
}

// loading overlay over a scene's image preview WHILE it's generating/queued (spinner/clock + shimmer)
function addGenOverlay(imgPrev, status) {
  if (!imgPrev) return;
  let o = imgPrev.querySelector(".gen-overlay");
  if (!o) { o = document.createElement("div"); o.className = "gen-overlay"; imgPrev.appendChild(o); }
  if (o.dataset.st === status) return;
  o.dataset.st = status;
  o.innerHTML = (status === "queued"
    ? '<span class="gen-clock">🕒</span><span>Queued…</span>'
    : '<span class="sub-spin"></span><span>Generating…</span>')
    + '<button type="button" class="gen-stop" title="Stop this generation">⛔ Stop</button>';
}

// Stroked chevrons matching the app's icon language (same style as the Download icon).
const CHEV_L = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5.5 8.5 12 15 18.5"/></svg>';
const CHEV_R = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5.5 15.5 12 9 18.5"/></svg>';

// Carousel-style slide between image versions inside a positioned, clipped container.
// dir > 0 = next (new frame enters from the right); dir < 0 = prev (enters from the left).
// Animates a temporary overlay of the old + new frames, then commits the real swap so the
// underlying element already shows the new image before the overlay is removed (no flash).
function slideSwap(container, refImg, dir, newSrc, opts) {
  opts = opts || {};
  const commit = opts.commit || (() => {});
  if (!container || !refImg || !dir || !newSrc || container._sliding) { commit(); return; }
  const oldSrc = refImg.currentSrc || refImg.src;
  if (!oldSrc) { commit(); return; }
  container._sliding = true;
  const D = 340, ease = `transform ${D}ms cubic-bezier(.22,.61,.36,1)`;
  const fit = getComputedStyle(refImg).objectFit || "contain";
  const lay = document.createElement("div");
  lay.className = "slide-layer";
  // z-index 1: above the base <img> (static) so it covers it, but BELOW the fixed overlays —
  // the approve/change/delete icons (.img-actions, z2) and the version arrows (z2) — so those
  // stay put while the frames slide underneath (no disappear/reappear blink).
  lay.style.cssText = "position:absolute;inset:0;overflow:hidden;z-index:1;pointer-events:none;";
  const mk = (src, x) => {
    const i = document.createElement("img");
    i.src = src;
    i.style.cssText = `position:absolute;top:0;left:0;width:100%;height:100%;object-fit:${fit};transform:translateX(${x});will-change:transform;`;
    return i;
  };
  const outI = mk(oldSrc, "0"), inI = mk(newSrc, (dir * 100) + "%");
  lay.append(outI, inI);
  container.appendChild(lay);
  let launched = false;
  const start = () => {
    if (launched) return; launched = true;
    requestAnimationFrame(() => {
      outI.style.transition = ease; inI.style.transition = ease;
      requestAnimationFrame(() => {
        outI.style.transform = `translateX(${-dir * 100}%)`;
        inI.style.transform = "translateX(0)";
      });
    });
    setTimeout(commit, Math.round(D * 0.5));                         // swap the real src UNDER the layer (no old-image flash when it lifts)
    setTimeout(() => {
      lay.remove(); container._sliding = false;
      if (opts.onDone) opts.onDone();                               // heavier reconcile AFTER the layer is gone
    }, D + 40);
  };
  // Start the animation only once the INCOMING frame is decoded — the first slide to a not-yet-
  // loaded version would otherwise pop in blank mid-slide (that's the "first transition" stutter).
  // Cached versions decode instantly, so already-seen slides start with no perceptible delay.
  if (inI.decode) inI.decode().then(start, start);
  else if (inI.complete && inI.naturalWidth) start();
  else { inI.addEventListener("load", start, { once: true }); inI.addEventListener("error", start, { once: true }); }
  setTimeout(start, 500);                                            // hard fallback so a slow load never stalls the slide
}

// Version arrows OVER the image (left/right, fullscreen-preview style). Created lazily inside the
// image preview so they survive its innerHTML rebuilds; only shown when there's >1 version.
function wireVerArrows(imgPrev, s, cur, vsLen) {
  if (!imgPrev) return;
  let prevA = imgPrev.querySelector(".img-arrow.prev");
  let nextA = imgPrev.querySelector(".img-arrow.next");
  let badge = imgPrev.querySelector(".ver-badge");
  if (vsLen <= 1) { if (prevA) prevA.remove(); if (nextA) nextA.remove(); if (badge) badge.remove(); return; }
  if (!prevA) {
    prevA = document.createElement("button");
    prevA.type = "button"; prevA.className = "img-arrow prev"; prevA.title = "Previous version"; prevA.innerHTML = CHEV_L;
    imgPrev.appendChild(prevA);
  }
  if (!nextA) {
    nextA = document.createElement("button");
    nextA.type = "button"; nextA.className = "img-arrow next"; nextA.title = "Next version"; nextA.innerHTML = CHEV_R;
    imgPrev.appendChild(nextA);
  }
  if (!badge) { badge = document.createElement("span"); badge.className = "ver-badge"; imgPrev.appendChild(badge); }
  badge.textContent = `${cur + 1} / ${vsLen}`;   // version indicator overlaid on the image (bottom-centre)
  prevA.disabled = cur <= 0;
  nextA.disabled = cur >= vsLen - 1;
  // warm the neighbouring versions so their slide has the frame already decoded (instant, no stutter)
  [cur - 1, cur + 1].forEach(i => {
    if (i >= 0 && i < vsLen) { const im = new Image(); im.src = mediaUrl(s.image.versions[i], s.image.taskId); }
  });
  const go = (to, dir) => async (e) => {
    e.stopPropagation(); e.preventDefault();
    await flushSave();
    const under = imgPrev.querySelector("img");                          // the currently-shown image
    const newSrc = mediaUrl(s.image.versions[to], s.image.taskId);
    const commit = () => { if (under) under.src = newSrc; };             // show the new one underneath BEFORE the layer lifts (no old-image flash)
    const onDone = () => {
      // reconcile only THIS card (label, arrows, approve/download) — NOT renderScenes(), which
      // wipes #scenesList innerHTML and rebuilds every card mid-animation (that was the first-slide jank).
      s.image.current = to;
      s._appLock = Date.now() + 8000;                                     // guard the shown version against a poll snap-back
      const el = imgPrev.closest(".scene-row");
      if (el) patchSceneMedia(el, s);
      // patchSceneMedia rebuilds the <img> with an .img-loading opacity fade; but the pixels are
      // already the slid-in frame, so kill that fade — show it instantly (no post-slide fade-in).
      const nimg = imgPrev.querySelector("img");
      if (nimg) {
        imgPrev.classList.remove("img-loading");
        nimg.style.transition = "none"; nimg.style.opacity = "1";
        requestAnimationFrame(() => { nimg.style.transition = ""; });
      }
      api.setCurrent(PROJECT, s.id, to);                                 // persist in the background — no full re-render
    };
    slideSwap(imgPrev, under, dir, newSrc, { commit, onDone });          // slide the new version in
  };
  prevA.onclick = go(cur - 1, -1);
  nextA.onclick = go(cur + 1, +1);
}

// ---- drag-to-reorder + undo ----
let DRAG_SID = null;
function clearDrop() { $$(".scene-row").forEach(r => r.classList.remove("drop-before", "drop-after")); }
function _sceneRowTops() {   // viewport tops keyed by the CURRENT (old) scene id — for FLIP
  const map = {};
  $$(".scene-row").forEach(r => { map[r.dataset.id] = r.getBoundingClientRect().top; });
  return map;
}
function _flipScenes(firstTops, newOrderOfOldIds) {
  const rows = $$(".scene-row");
  rows.forEach((row, i) => {
    const from = firstTops[newOrderOfOldIds[i]];          // where this scene's row USED to be
    if (from == null) return;
    const dy = from - row.getBoundingClientRect().top;
    if (Math.abs(dy) < 1) return;
    row.style.transition = "none";
    row.style.transform = `translateY(${dy}px)`;          // start at the old position
    requestAnimationFrame(() => {
      row.style.transition = "transform .34s cubic-bezier(.2,.8,.2,1)";
      row.style.transform = "";                           // glide to the new position
    });
    setTimeout(() => { row.style.transition = ""; }, 380);
  });
}
async function reorderScene(srcId, targetId, after) {
  await flushSave();
  pushUndo("reorder scenes");
  const ids = DOC.scenes.map(s => s.id).filter(i => i !== srcId);
  let idx = ids.indexOf(targetId);
  if (after) idx += 1;
  ids.splice(idx, 0, srcId);                              // ids = new order, in terms of the OLD ids
  const firstTops = _sceneRowTops();                      // FIRST (before) positions
  DOC = await api.reorder(PROJECT, ids);
  renderScenes(); renderVideos();
  _flipScenes(firstTops, ids);                            // LAST/INVERT/PLAY → rows glide into place
}
let undoStack = [], redoStack = [];
// ---- text-edit undo/redo ----
// Typing in the script or a scene's text fields (voice-over, image prompt, video prompt, notes) is grouped
// into undo steps that revert ONLY the text — never a generated image/video. A step is captured when you
// leave a field or pause typing. Ctrl+Z reverts it; Ctrl+Y (Redo) brings it back.
const TEXT_FIELDS = ["vo", "vo_tr", "prompt", "note", "video_desc", "video_prompt"];
const TEXT_SEL = "#scriptText, .prompt, .vo, .video-desc, .video-prompt";
let _textBase = null, _textTimer = null;
function textState() {
  const st = $("#scriptText");
  return {
    script: st ? st.value : ((DOC && DOC.script) || ""),
    scenes: ((DOC && DOC.scenes) || []).map(s => { const o = { id: s.id }; TEXT_FIELDS.forEach(f => o[f] = s[f]); return o; })
  };
}
function applyTextState(ts) {
  const st = $("#scriptText"); if (st && ts.script != null) st.value = ts.script;
  const byId = {}; (ts.scenes || []).forEach(s => byId[s.id] = s);
  ((DOC && DOC.scenes) || []).forEach(s => { const o = byId[s.id]; if (o) TEXT_FIELDS.forEach(f => { if (f in o) s[f] = o[f]; }); });
}
function commitTextUndo() {                     // push the pending text edit (if any) as one undo step
  clearTimeout(_textTimer); _textTimer = null;
  if (_textBase == null || !DOC) return;
  const now = textState();
  if (JSON.stringify(now) === JSON.stringify(_textBase)) { return; }
  undoStack.push({ label: "edit text", textSafe: true, text: _textBase });
  if (undoStack.length > 40) undoStack.shift();
  redoStack = []; _textBase = now; updateUndoBtn();
}
document.addEventListener("focusin", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL) && _textBase == null) _textBase = textState(); });
document.addEventListener("focusout", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL)) commitTextUndo(); });
document.addEventListener("input", (e) => { if (e.target && e.target.matches && e.target.matches(TEXT_SEL)) { if (_textBase == null) _textBase = textState(); clearTimeout(_textTimer); _textTimer = setTimeout(commitTextUndo, 1500); } });

function pushUndo(label) {
  if (!DOC) return;
  commitTextUndo();                            // record any pending text edit as its own step first
  undoStack.push({ label, doc: JSON.parse(JSON.stringify(DOC)) });   // snapshot BEFORE the action
  if (undoStack.length > 25) undoStack.shift();
  redoStack = [];                              // a fresh action invalidates the redo history
  updateUndoBtn();
}
async function _restoreTextStep(snap, intoStack) {
  intoStack.push({ label: snap.label, textSafe: true, text: textState() });   // current text → the other stack
  if (intoStack.length > 40) intoStack.shift();
  applyTextState(snap.text);
  try { await api.save(PROJECT, DOC); } catch (e) {}
  renderScenes(); if (typeof updateGenBtns === "function") updateGenBtns();
  _textBase = textState(); updateUndoBtn();
}
async function doUndo() {
  commitTextUndo();                            // flush any in-progress text edit as its own step first
  if (!undoStack.length || !PROJECT) return;
  const snap = undoStack.pop();
  if (snap.textSafe) { await _restoreTextStep(snap, redoStack); toast(`Undone: ${snap.label}`, "ok"); return; }
  redoStack.push({ label: snap.label, doc: JSON.parse(JSON.stringify(DOC)) });   // current state → redo
  if (redoStack.length > 25) redoStack.shift();
  DOC = await api.restore(PROJECT, snap.doc);
  renderScenes(); renderVideos(); renderGenProgress(); _textBase = textState(); updateUndoBtn();
  toast(`Undone: ${snap.label}`, "ok");
}
async function doRedo() {
  commitTextUndo();
  if (!redoStack.length || !PROJECT) return;
  const snap = redoStack.pop();
  if (snap.textSafe) { await _restoreTextStep(snap, undoStack); toast(`Redone: ${snap.label}`, "ok"); return; }
  undoStack.push({ label: snap.label, doc: JSON.parse(JSON.stringify(DOC)) });   // current state → undo
  if (undoStack.length > 25) undoStack.shift();
  DOC = await api.restore(PROJECT, snap.doc);
  renderScenes(); renderVideos(); renderGenProgress(); _textBase = textState(); updateUndoBtn();
  toast(`Redone: ${snap.label}`, "ok");
}
function updateUndoBtn() {
  const b = $("#undoBtn");
  if (b) { b.disabled = !undoStack.length; b.title = undoStack.length ? `Undo: ${undoStack[undoStack.length - 1].label}` : "Nothing to undo"; }
  const r = $("#redoBtn");
  if (r) { r.disabled = !redoStack.length; r.title = redoStack.length ? `Redo: ${redoStack[redoStack.length - 1].label}` : "Nothing to redo"; }
}

// ---- bilingual VO: a faint, read-only Turkish translation under each scene's sentence ----
// French/German projects auto-translate on split (and keep in sync as you edit); English projects are
// manual (a ⇄ TR button per scene). Prompts are always English and untouched.
const LANG_BY_LOC = { "France": "French", "Germany": "German", "United States": "English", "United Kingdom": "English" };
function projectLang() {
  const locs = (DOC && DOC.audience && DOC.audience.locations) || [];
  return LANG_BY_LOC[locs[0]] || "English";
}
function autoTr() { const l = projectLang(); return l === "French" || l === "German"; }
function showVoTr(el, text) {
  const d = el && el.querySelector(".vo-tr");
  if (!d) return;
  if (text && String(text).trim()) { d.textContent = text; d.hidden = false; }
  else { d.textContent = ""; d.hidden = true; }
}
function autoGrowVo(ta) {                        // hug the sentence's height so there's no empty row before the translation
  if (!ta) return;
  ta.style.height = "auto";                     // rows=1 fallback (1 line) when the field is hidden
  const h = ta.scrollHeight;
  if (h > 0) ta.style.height = h + "px";        // only size when laid out — a HIDDEN field reports 0; never collapse it
}
function autoGrowAllVo() { $$(".sc-vo-box textarea.vo").forEach(autoGrowVo); }   // re-fit when the Scenes tab becomes visible
// Kept OUTSIDE the scene object (never serialized into scenes.json): which source text we last
// translated per scene + an in-flight guard. Together they make translation idempotent — translating
// the SAME text again is a no-op — which breaks any accidental repeat-trigger loop.
const _trBusy = {}, _trLastSrc = {};
async function translateSceneVo(s, el, btn, manual) {
  const src = (s.vo || "").trim();
  if (!src) { s.vo_tr = ""; _trLastSrc[s.id] = ""; showVoTr(el, ""); queueSave(); return; }
  if (_trBusy[s.id]) return;                              // one translation at a time per scene
  if (_trLastSrc[s.id] === src && s.vo_tr) {              // already translated this EXACT text → skip
    if (manual) toast(`Scene #${s.id} already translated`, "info");
    return;
  }
  _trBusy[s.id] = true;
  if (btn) btn.classList.add("busy-tr");     // small spinner over the flag while it generates
  try {
    const r = await api.translate([src], projectLang());
    if (r && r.error) { toast("Translation failed: " + r.error, "err"); return; }
    const tr = (r && r.translations && r.translations[0]) || "";
    s.vo_tr = tr; _trLastSrc[s.id] = src; showVoTr(el, tr); queueSave();
    if (manual) toast(`Scene #${s.id} translated to Turkish`, "ok");   // only on a manual flag click
  } catch (e) { toast("Translation failed", "err"); }
  finally { _trBusy[s.id] = false; if (btn) btn.classList.remove("busy-tr"); }
}
async function translateAllScenes() {           // batch-translate every scene's VO (used right after split)
  if (!DOC || !DOC.scenes || !DOC.scenes.length) return;
  const src = DOC.scenes.map(s => (s.vo || ""));
  if (!src.some(t => t.trim())) return;
  try {
    const r = await api.translate(src, projectLang());
    if (r && r.error) { toast("Translation failed: " + r.error, "err"); return; }
    const trs = (r && r.translations) || [];
    DOC.scenes.forEach((s, i) => { s.vo_tr = trs[i] || ""; _trLastSrc[s.id] = (s.vo || "").trim(); });
    await api.save(PROJECT, DOC);
    renderScenes();
  } catch (e) { toast("Translation failed", "err"); }
}

function renderScenes() {
  const wrap = $("#scenesList");
  // Full rebuild momentarily collapses the list → the browser clamps scroll to the top. Preserve the
  // scroll position (only on the Scenes tab) so a background generate/poll re-render doesn't yank the
  // page to the top mid-work. rAF fires after this synchronous rebuild finishes.
  const _sy = window.scrollY;
  if (_sy > 0 && document.body.classList.contains("tab-scenes")) requestAnimationFrame(() => window.scrollTo(0, _sy));
  wrap.innerHTML = "";
  const empty = !DOC || !DOC.scenes.length;
  $("#scenesEmpty").hidden = !empty;
  updateSceneCounts();
  if (empty) return;
  const tpl = $("#sceneTpl");
  const insertDivider = (afterId) => {
    const d = document.createElement("div");
    d.className = "insert-divider";
    const b = document.createElement("button");
    b.className = "insert-btn ghost"; b.textContent = "+ Add scene here";
    b.addEventListener("click", async () => { pushUndo("insert scene"); DOC = await api.insertScene(PROJECT, afterId); renderScenes(); });
    d.appendChild(b); wrap.appendChild(d);
  };
  insertDivider(0);
  for (const s of DOC.scenes) {
    if (hideApproved && s.approved) continue;   // toggle: hide approved scenes
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = s.id;
    if (s.approved) el.classList.add("approved");
    if (_flashApprove === s.id) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); _flashApprove = null; }
    $(".scene-num", el).textContent = `#${s.id}`;
    $(".scene-caption", el).textContent = trunc(s.vo, 90);
    const noteBtn = $(".scene-note", el);
    if (noteBtn) {
      noteBtn.classList.toggle("has-note", !!(s.note && s.note.trim()));   // filled dot when a note exists
      noteBtn.addEventListener("click", () => openNoteModal(s));
    }
    const selBtn = $(".scene-sel", el);
    if (selBtn) {
      if (isSelected(s.id)) { selBtn.classList.add("on"); el.classList.add("sel-on"); }
      selBtn.addEventListener("click", (e) => { e.stopPropagation(); toggleSelect(s.id, e.shiftKey); });
    }
    $(".scene-del", el).addEventListener("click", async () => {
      if (!(await confirmDialog(`Delete scene #${s.id}? Its image and video will be removed.`, { title: "Delete Scene", okText: "Delete" }))) return;
      pushUndo("delete scene");
      el.classList.add("removing");                       // fade + shrink out before the list re-renders
      await new Promise(r => setTimeout(r, 240));
      DOC = await api.deleteScene(PROJECT, s.id); renderScenes(); renderVideos();
    });
    // drag-to-reorder (handle in the scene-head)
    const handle = $(".drag-handle", el);
    if (handle) {
      handle.addEventListener("dragstart", (e) => {
        DRAG_SID = s.id; el.classList.add("dragging"); e.dataTransfer.effectAllowed = "move";
        try { e.dataTransfer.setData("text/plain", String(s.id)); e.dataTransfer.setDragImage(el, 24, 18); } catch (err) {}
      });
      handle.addEventListener("dragend", () => { el.classList.remove("dragging"); clearDrop(); DRAG_SID = null; });
    }
    el.addEventListener("dragover", (e) => {
      if (DRAG_SID == null || DRAG_SID === s.id) return;
      e.preventDefault();
      const r = el.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      el.classList.toggle("drop-after", after); el.classList.toggle("drop-before", !after);
    });
    el.addEventListener("dragleave", () => el.classList.remove("drop-before", "drop-after"));
    el.addEventListener("drop", async (e) => {
      if (DRAG_SID == null || DRAG_SID === s.id) return;
      e.preventDefault();
      const r = el.getBoundingClientRect(), after = (e.clientY - r.top) > r.height / 2;
      el.classList.remove("drop-before", "drop-after");
      await reorderScene(DRAG_SID, s.id, after);
    });
    $(".vo", el).value = s.vo || "";
    $(".prompt", el).value = s.prompt || "";
    showVoTr(el, s.vo_tr || "");                    // faint Turkish line under the sentence (if any)
    requestAnimationFrame(() => autoGrowVo($(".vo", el)));
    const trBtn = el.querySelector(".vo-tr-btn");
    if (trBtn) trBtn.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); translateSceneVo(s, el, trBtn, true); });
    const trDiv = el.querySelector(".vo-tr");       // reading/selecting the faint line shouldn't focus the textarea
    if (trDiv) { trDiv.addEventListener("mousedown", ev => ev.stopPropagation()); trDiv.addEventListener("click", ev => ev.stopPropagation()); }

    // style buttons
    $$(".style-btn", el).forEach(b => {
      b.classList.toggle("sel", s.style === b.dataset.style);
      b.addEventListener("click", () => {
        s.style = (s.style === b.dataset.style) ? null : b.dataset.style;
        $$(".style-btn", el).forEach(x => x.classList.toggle("sel", x.dataset.style === s.style));
        if (s.prompt && s.prompt.trim()) {   // the prompt was written for the previous style → remind to re-generate before the image
          s._promptStale = true;
          const gpb = $(".gen-prompt", el); if (gpb) gpb.classList.add("needs-regen");
        }
        queueSave();
      });
    });
    // "Ignore audience casting" toggle
    const castBtn = $(".cast-toggle", el);
    castBtn.classList.toggle("on", !!s.no_cast);
    castBtn.addEventListener("click", () => {
      s.no_cast = !s.no_cast;
      castBtn.classList.toggle("on", s.no_cast);
      queueSave();
    });
    // model selector (per scene) + camera framing selector
    buildModelDropdown($(".model-dd", el), s);
    buildCameraDropdown($(".camera-dd", el), s);
    buildTransitionDropdown($(".transition-dd", el), s);

    // current image version
    const im = s.image, vs = im.versions || [];
    let cur = (im.current == null ? vs.length - 1 : im.current);
    const curFile = (vs.length && cur >= 0 && cur < vs.length) ? vs[cur] : null;
    const imgPrev = $(".img-preview", el);
    imgPrev.dataset.file = curFile || "";
    if (curFile) {
      imgPrev.innerHTML = "";
      const src = mediaUrl(curFile, s.image.taskId);
      const img = document.createElement("img");
      img.src = src;
      // Only show the dark loading skeleton for an image that isn't already cached/decoded.
      // Otherwise re-rendering after approve/unapprove flashes the SAME frame black for ~0.5s
      // for no reason — the image is identical and already in the browser cache.
      if (img.complete && img.naturalWidth) {
        imgPrev.classList.remove("img-loading");
      } else {
        imgPrev.classList.add("img-loading");                       // shimmer skeleton until it loads
        img.addEventListener("load", () => imgPrev.classList.remove("img-loading"));
        img.addEventListener("error", () => imgPrev.classList.remove("img-loading"));
      }
      img.addEventListener("click", () => openImageLightbox(s));   // click = view large
      if (_flashImg === s.id) { img.classList.add("img-swap"); _flashImg = null; }   // crossfade in on a version switch
      imgPrev.appendChild(img);
      // overlay actions (top-right of the image)
      const ov = document.createElement("div");
      ov.className = "img-actions";
      const approvedThis = s.approved && im.approved_version === cur;
      const bApprove = document.createElement("button");
      bApprove.className = "ia approve" + (approvedThis ? " on" : "");
      bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
      bApprove.textContent = "✓";
      const bChange = document.createElement("button");
      bChange.className = "ia change"; bChange.title = "Change (regenerate)"; bChange.textContent = "↻";
      const bRemove = document.createElement("button");
      bRemove.className = "ia remove"; bRemove.title = "Remove"; bRemove.innerHTML = TRASH_SVG;
      bApprove.addEventListener("click", async (e) => {
        e.stopPropagation();
        const willApprove = !bApprove.classList.contains("on");
        await flushSave();                                           // commit any pending prompt/VO edit BEFORE the DOC is replaced
        s._appLock = Date.now() + 8000;                              // guard: a stale in-flight poll must not revert this approve
        DOC = await api.approve(PROJECT, s.id, willApprove);
        const fresh = DOC.scenes.find(x => x.id === s.id); if (fresh) { fresh._appLock = Date.now() + 8000; Object.assign(s, fresh); }
        if (hideApproved && s.approved) renderScenes();              // hide-approved on → the card should vanish
        else patchApprove(el, s, cur, bApprove);                     // otherwise patch in place — no refs/OST flicker
        buildSceneJump();                                            // recolor the scene chip to green immediately (was lagging minutes)
        if (willApprove) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
        renderVideos();
      });
      bChange.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); });
      bRemove.title = "Delete this version";
      bRemove.addEventListener("click", async (e) => { e.stopPropagation(); pushUndo("delete image"); DOC = await api.deleteVersion(PROJECT, s.id, cur); toast(`Deleted Image: Scene ${s.id}`, "info"); renderScenes(); renderVideos(); });
      ov.appendChild(bApprove); ov.appendChild(bChange); ov.appendChild(bRemove);
      imgPrev.appendChild(ov);
    }
    if (im.status === "generating" || im.status === "queued") { if (!curFile) imgPrev.innerHTML = ""; addGenOverlay(imgPrev, im.status); }
    setBadge($(".img-status", el), im);

    // version nav / edit / download
    const nav = $(".img-nav", el);
    if (vs.length) {
      nav.hidden = false;
      const av = im.approved_version;
      const isApprovedVer = s.approved && av === cur;
      wireVerArrows($(".img-preview", el), s, cur, vs.length);   // arrows + version badge overlay the image
      $(".ver-download", el).onclick = () => downloadMedia(curFile, `${pad2(s.id)}_${slug(s.vo)}.png`, `Scene ${s.id}`);
      const editBox = $(".edit-box", el);
      $(".ver-edit", el).onclick = () => { editBox.hidden = !editBox.hidden; };
      $(".edit-apply", el).onclick = (ev) => {
        const instr = $(".edit-instr", el).value.trim();
        if (!instr) { alert("Type what to change."); return; }
        withBusy(ev.currentTarget, () => editImage(s.id, instr));
      };
    }

    $(".prompt", el).addEventListener("input", e => { s.prompt = e.target.value; queueSave(); });
    $(".vo", el).addEventListener("input", e => {
      s.vo = e.target.value; queueSave(); autoGrowVo(e.target);
      // Editing invalidates the old translation (ALL languages) → it clears; click the 🇹🇷 flag to redo.
      // No background auto-retranslate — FR/DE translate ONCE on split, then it's manual like English.
      if (s.vo_tr) { s.vo_tr = ""; showVoTr(el, ""); }
    });
    // ---- on-screen text overlays: section master toggle + N overlay panels ("+") ----
    const redrawOst = () => { drawSceneOst(el, s); queueSave(); };
    const ostField = el.querySelector(".ost-field"), ostOn = $(".ost-on", el),
          ostColl = ostField.querySelector(".ost-collapse"), ostAdd = $(".ost-add", el);
    const forceState = (open) => {                    // guarantees the end state even if a transition stalls
      ostColl.style.transition = "none";
      ostColl.style.height = open ? "auto" : "0px";
      ostColl.style.overflow = open ? "visible" : "hidden";
      void ostColl.offsetHeight;
      ostColl.style.transition = "";
    };
    const animateHeight = (fromH) => {                // smooth stretch to the current content height
      if (!ostOn.checked) return;
      ostColl.style.overflow = "hidden";
      ostColl.style.height = fromH + "px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = ostColl.scrollHeight + "px";
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (ostOn.checked) forceState(true); }, 340);
    };
    const openSection = (animate) => {
      ostField.classList.add("ost-open");
      if (!animate) { forceState(true); return; }
      ostColl.style.overflow = "hidden";
      const h = ostColl.scrollHeight;
      ostColl.style.height = "0px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = h + "px";
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (ostOn.checked) forceState(true); }, 340);
    };
    const closeSection = () => {
      closeAllPops();
      ostColl.style.overflow = "hidden";
      ostColl.style.height = Math.round(ostColl.getBoundingClientRect().height) + "px";
      getComputedStyle(ostColl).height;
      ostColl.style.height = "0px";
      ostField.classList.remove("ost-open");
      clearTimeout(ostColl._t);
      ostColl._t = setTimeout(() => { if (!ostOn.checked) forceState(false); }, 340);
    };
    const ostTpl = $(".ost-panel-tpl", el);   // template is nested in each scene row (scoped lookup)
    const buildPanels = () => {
      const container = $(".ost-panels", el), tpl = ostTpl;
      if (!container || !tpl) return;
      container.innerHTML = "";
      (s.overlays || []).forEach((ov, i) => {
        const panel = tpl.content.firstElementChild.cloneNode(true);
        container.appendChild(panel);
        wireOstPanel(panel, ov, redrawOst, buildPanels);
        const del = panel.querySelector(".ost-del-overlay");
        del.addEventListener("click", () => {         // "-" is always shown, even on the first/only text
          closeAllPops();
          const last = s.overlays.length <= 1;
          const h = panel.offsetHeight;               // collapse this panel to nothing; the auto-height
          panel.style.overflow = "hidden";            // section then shrinks smoothly along with it
          panel.style.height = h + "px";
          panel.style.transition = "height .3s ease, opacity .26s ease, margin .3s ease, padding .3s ease, border-width .3s ease";
          getComputedStyle(panel).height;             // reflow so the collapse animates from h
          panel.style.height = "0px";
          panel.style.opacity = "0";
          panel.style.marginTop = "0px";
          panel.style.paddingTop = "0px";
          panel.style.borderTopWidth = "0px";
          clearTimeout(ostColl._t);
          ostColl._t = setTimeout(() => {
            if (last) {                               // removing the only text closes the whole section
              s.overlays = [newOverlay()];
              s.ost_on = false; ostOn.checked = false; ostAdd.hidden = true;
              ostField.classList.remove("ost-open");
              forceState(false); buildPanels();
            } else {
              s.overlays.splice(i, 1); buildPanels(); forceState(true);
            }
            redrawOst();
          }, 320);
        });
      });
    };
    buildPanels();
    ostOn.checked = !!s.ost_on;
    ostAdd.hidden = !s.ost_on;
    if (s.ost_on) openSection(false); else ostColl.style.height = "0px";
    ostOn.addEventListener("change", () => {
      s.ost_on = ostOn.checked;
      ostAdd.hidden = !ostOn.checked;
      if (ostOn.checked) openSection(true); else closeSection();
      redrawOst();
    });
    ostAdd.addEventListener("click", () => {
      const fromH = Math.round(ostColl.getBoundingClientRect().height);
      s.overlays.push(newOverlay()); buildPanels(); animateHeight(fromH); queueSave();
    });
    const gp = $(".gen-prompt", el), gi = $(".gen-img", el);
    const hasPrompt = !!(s.prompt && s.prompt.trim());
    gp.textContent = hasPrompt ? "↻ Re-Generate Prompt" : "✨ Generate Prompt";
    if (hasPrompt && s._promptStale) gp.classList.add("needs-regen");   // style changed after the prompt was written → nudge a re-generate
    gp.addEventListener("click", () => stoppable(gp, (sig) => genPrompts([s.id], sig)));
    gi.addEventListener("click", () => withBusy(gi, () => genImages([s.id])));
    const pv = $(".preview-prompt", el);
    if (pv) pv.addEventListener("click", () => showPromptPreview(s.id));
    // keep the image button spinning while its image is still generating
    if (s.image.status === "generating") setBusy(gi, true);

    // Reference thumbnails are served from the local copy on disk — pulling every
    // full-size ref off Cloudinary on each render is what burned the bandwidth quota.
    // per-scene reference images (up to 14)
    const refsList = $(".scene-refs-list", el), refInput = $(".ref-input", el);
    const refSceneBtn = $(".ref-scene-btn", el), refSceneMenu = $(".ref-scene-menu", el);
    const castDD = $(".cast-dd", el), castPickBtn = $(".cast-btn", el), castMenu = $(".cast-menu", el);
    function drawRefs() {
      refsList.innerHTML = "";
      (s.refs || []).forEach((url, i) => {
        const chip = document.createElement("div");
        chip.className = "ref-thumb";
        const im = document.createElement("img"); setRefImg(im, url);
        chip.appendChild(im);
        const m = /sceneref-(\d+)-/.exec(url);          // ref copied from another scene → badge it
        if (m) { const b = document.createElement("span"); b.className = "ref-scene-badge"; b.textContent = "Scene " + m[1]; chip.appendChild(b); }
        if (/char_/.test(url) || /sceneref-/.test(url)) {   // a character OR reference-scene image → outfit-lock toggle
          const locked = !(s.ref_free || []).includes(url);
          const lk = document.createElement("button"); lk.type = "button"; lk.className = "ref-lock" + (locked ? " on" : "");
          lk.textContent = "👕";
          const tip = on => on ? "Outfit LOCKED: same clothes & hair as the reference. Click → change the outfit to fit this scene."
                               : "Outfit FREE: different clothes for this scene (hair may stay). Click to lock the same outfit.";
          lk.title = tip(locked);
          lk.addEventListener("click", async (e) => {
            e.stopPropagation();
            s.ref_free = s.ref_free || [];
            const nowLocked = s.ref_free.includes(url);   // was free → will become locked
            s.ref_free = nowLocked ? s.ref_free.filter(x => x !== url) : [...s.ref_free, url];
            lk.classList.toggle("on"); lk.title = tip(lk.classList.contains("on"));
            await api.save(PROJECT, DOC);
          });
          chip.appendChild(lk);
        }
        const x = document.createElement("button"); x.className = "ref-x"; x.textContent = "×"; x.title = "Remove";
        x.addEventListener("click", async () => {
          const oldH = refsList.getBoundingClientRect().height;   // height before removal
          s.refs.splice(i, 1);
          drawRefs();
          animateRefsHeight(refsList, oldH);                      // smooth downward shrink of the frame
          await api.save(PROJECT, DOC);
        });
        chip.appendChild(x); refsList.appendChild(chip);
      });
      if ((s.refs || []).length < 14) {                 // upload-from-PC placeholder tile (same size as the thumbs)
        const add = document.createElement("button");
        add.type = "button"; add.className = "ref-thumb ref-add-tile"; add.title = "Upload a reference image from your computer";
        add.innerHTML = "<span>+</span>";
        add.addEventListener("click", () => refInput.click());
        refsList.appendChild(add);
      }
      requestAnimationFrame(() => fitRefs(refsList));   // size thumbnails to fill the area (see fitRefs)
    }
    drawRefs();
    refInput.addEventListener("change", async (e) => {
      const files = [...e.target.files]; e.target.value = "";
      const oldH = refsList.getBoundingClientRect().height;   // height before the new thumbnail(s)
      for (const f of files) {
        if ((s.refs || []).length >= 14) { alert("Max 14 reference images per scene."); break; }
        setStatus("uploading reference…");
        const r = await api.uploadSceneRef(PROJECT, s.id, f);
        if (r.error) { alert(r.error); break; }
        s.refs = r.refs;
      }
      setStatus(""); drawRefs();
      animateRefsHeight(refsList, oldH);   // smooth downward stretch as the thumbnails appear
    });
    // Reference Scene dropdown — reuse ANOTHER scene's approved image as a reference (same person/place)
    if (refSceneBtn) refSceneBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !refSceneMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      refSceneMenu.innerHTML = "";
      const opts = (DOC.scenes || []).filter(o => o.id !== s.id && o.image && (o.image.approved_file || o.image.file));
      if (!opts.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No other scene has an image yet"; refSceneMenu.appendChild(d); }
      opts.forEach(o => {
        const row = document.createElement("div"); row.className = "ref-scene-opt";
        const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; th.src = refThumb(o.image.approved_file || o.image.file);   // small cached thumb (~17KB, not the 5MB full image) → menu opens instantly + scrolls smoothly even with 40 scenes
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = `Scene ${o.id}`;
        row.append(th, lbl);
        row.addEventListener("click", async () => {
          refSceneMenu.hidden = true;
          if ((s.refs || []).length >= 14) { alert("Max 14 reference images per scene."); return; }
          const oldH = refsList.getBoundingClientRect().height;
          const r = await api.refScene(PROJECT, s.id, o.id);
          if (r.error) { alert(r.error); return; }
          s.refs = r.refs; drawRefs(); animateRefsHeight(refsList, oldH);   // backend already saved
          toast(`Referenced Scene ${o.id}`, "ok");
        });
        refSceneMenu.appendChild(row);
      });
      refSceneMenu.hidden = false;
    });
    // Cast dropdown — pick a named character (from Target Audience → Cast). Selecting one drops THAT
    // character's image straight into this scene's reference images (as a thumbnail), exactly like
    // adding a reference. The Cast button itself never changes — it always reads "🎭 Cast ▾".
    const prodDD = $(".product-dd", el), prodBtn = $(".product-btn", el), prodMenu = $(".product-menu", el);
    if (prodBtn) prodBtn.addEventListener("click", (e) => {   // pick WHICH product image (1-bottle / 3-pack / 6-pack) appears in this scene
      e.stopPropagation();
      const wasOpen = !prodMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      prodMenu.innerHTML = "";
      const urls = (DOC && DOC.product && DOC.product.urls) || [];
      const pnames = (DOC && DOC.product && DOC.product.names) || {};
      const mkRow = (label, url, thumbUrl) => {
        const row = document.createElement("div"); row.className = "ref-scene-opt cast-opt" + ((s.product || "") === url ? " sel" : "");
        if (thumbUrl) { const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; setRefImg(th, thumbUrl); row.appendChild(th); }
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = label; row.appendChild(lbl);
        row.addEventListener("click", (ev) => { ev.stopPropagation(); prodMenu.hidden = true; s.product = url; prodBtn.classList.toggle("on", !!url); prodBtn.classList.remove("suggest"); queueSave(); });
        return row;
      };
      prodMenu.appendChild(mkRow("None", "", null));
      urls.forEach((u, i) => prodMenu.appendChild(mkRow((pnames[u] || "").trim() || `Product ${i + 1}`, u, u)));
      prodMenu.hidden = false;
    });
    function updateCastBtn() {   // visibility: hide Cast when no roster, hide Product when no product image
      const chars = (DOC && DOC.characters) || [];
      if (castDD) castDD.hidden = !chars.length;
      const hasProduct = !!((DOC && DOC.product && (DOC.product.urls || []).length));
      if (prodDD) prodDD.hidden = !hasProduct;
      if (prodBtn) {
        prodBtn.classList.toggle("on", !!s.product);
        // director flagged this shot as a product shot AND the user hasn't chosen yet → pulse the button as a hint
        prodBtn.classList.toggle("suggest", hasProduct && !!s.product_suggested && s.product == null);
      }
    }
    updateCastBtn();
    el._updateCast = updateCastBtn;   // refreshAllSceneCast() re-checks visibility after a character/product is added/removed
    if (castPickBtn) castPickBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !castMenu.hidden;
      $$(".model-menu").forEach(m => m.hidden = true);
      if (wasOpen) return;
      castMenu.innerHTML = "";
      const chars = (DOC && DOC.characters) || [];
      if (!chars.length) { const d = document.createElement("div"); d.className = "model-opt"; d.style.opacity = ".55"; d.textContent = "No cast — add characters in Target Audience"; castMenu.appendChild(d); }
      chars.forEach(c => {
        const row = document.createElement("div"); row.className = "ref-scene-opt cast-opt";
        const th = document.createElement("img"); th.className = "ref-scene-th"; th.decoding = "async"; setRefImg(th, charUrls(c)[0]);   // small cached thumb, like Reference Scene
        const lbl = document.createElement("span"); lbl.className = "ref-scene-lbl"; lbl.textContent = c.name;
        row.append(th, lbl);
        row.addEventListener("click", async () => {
          castMenu.hidden = true;
          s.refs = s.refs || [];
          const oldH = refsList.getBoundingClientRect().height;
          let added = 0;
          for (const u of charUrls(c)) { if (s.refs.length >= 14) break; s.refs.push(u); added++; }   // add ALL of the character's images (up to the 14-ref limit)
          if (!added) { alert("Max 14 reference images per scene."); return; }
          drawRefs(); animateRefsHeight(refsList, oldH);
          await api.save(PROJECT, DOC);
          toast(`${c.name} added as reference${added > 1 ? ` (${added} images)` : ""}`, "ok");
        });
        castMenu.appendChild(row);
      });
      castMenu.hidden = false;
    });
    drawSceneCast($(".scene-cast", el), s);   // (kept only to hide the old "In scene:" row)
    wrap.appendChild(el);
    drawSceneOst(el, s);   // draw AFTER the card is in the DOM so the preview has a REAL width → stable scale (a detached card reads width 0 and used a wrong fallback, shrinking/enlarging the text on re-render)
    insertDivider(s.id);
  }
  buildSceneJump();
  pruneSelection(); updateSelBar();   // keep multi-select in sync after any list rebuild
}

// ---------- multi-scene selection: checkbox per card → batch Generate Prompts / Images / Delete ----------
const SELECTED = new Set();     // selected scene ids (kept as strings, dataset-friendly)
let _lastSelId = null;          // anchor for Shift-click range selection
function isSelected(id) { return SELECTED.has(String(id)); }
function pruneSelection() {      // drop ids that no longer exist (after a delete/renumber)
  const live = new Set((DOC?.scenes || []).map(s => String(s.id)));
  [...SELECTED].forEach(id => { if (!live.has(id)) SELECTED.delete(id); });
}
function syncSelVisuals() {
  $$("#scenesList .scene-row").forEach(row => {
    const on = isSelected(row.dataset.id);
    row.classList.toggle("sel-on", on);
    const b = row.querySelector(".scene-sel"); if (b) b.classList.toggle("on", on);
  });
}
function _syncHdrH() {   // keep --hdr-h = sticky header height so the selection bar sticks right below it
  const h = document.querySelector("header");
  if (h && h.offsetParent !== null) document.documentElement.style.setProperty("--hdr-h", Math.round(h.getBoundingClientRect().height) + "px");
}
window.addEventListener("resize", _syncHdrH);
function updateSelBar() {
  const bar = $("#selBar"); if (!bar) return;
  const n = SELECTED.size;
  if (n) _syncHdrH();            // measure the (now-visible) header before the bar sticks under it
  bar.hidden = n === 0;
  const c = $("#selCount"); if (c) c.textContent = n + (n === 1 ? " scene selected" : " scenes selected");
}
function toggleSelect(id, shift) {
  const ids = (DOC?.scenes || []).map(s => String(s.id));
  const curIdx = ids.indexOf(String(id));
  if (shift && _lastSelId != null && ids.indexOf(String(_lastSelId)) >= 0 && curIdx >= 0) {
    const a = ids.indexOf(String(_lastSelId)), lo = Math.min(a, curIdx), hi = Math.max(a, curIdx);
    const turnOn = !isSelected(id);                 // extend the range in the direction the click intends
    for (let i = lo; i <= hi; i++) { if (turnOn) SELECTED.add(ids[i]); else SELECTED.delete(ids[i]); }
  } else {
    if (isSelected(id)) SELECTED.delete(String(id)); else SELECTED.add(String(id));
  }
  _lastSelId = id;
  syncSelVisuals(); updateSelBar();
}
function clearSelection() { SELECTED.clear(); _lastSelId = null; syncSelVisuals(); updateSelBar(); }
(function wireSelBar() {
  const gp = $("#selGenPrompts"), gi = $("#selGenImages"), del = $("#selDelete"), clr = $("#selClear");
  if (gp) gp.addEventListener("click", () => {
    const ids = [...SELECTED].map(Number);
    if (!ids.length) return;
    stoppable(gp, (sig) => genPrompts(ids, sig));   // ONE coordinated director call for just these scenes
  });
  if (gi) gi.addEventListener("click", () => {
    const ids = (DOC?.scenes || []).filter(s => isSelected(s.id) && (s.prompt || "").trim() && s.image.status !== "ready").map(s => s.id);
    if (!ids.length) { alert("No selected scenes that have a prompt and still need an image."); return; }
    withBusy(gi, () => genImages(ids));
  });
  if (del) del.addEventListener("click", async () => {
    const ids = [...SELECTED].map(Number);
    if (!ids.length) return;
    if (!(await confirmDialog(`Delete ${ids.length} selected scene(s)? Their images and videos will be removed.`, { title: "Delete Scenes", okText: "Delete" }))) return;
    pushUndo("delete scenes");
    DOC = await api.deleteScenes(PROJECT, ids);
    clearSelection(); renderScenes(); renderVideos();
    toast(`Deleted ${ids.length} scene(s).`, "info");
  });
  if (clr) clr.addEventListener("click", clearSelection);
})();
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && SELECTED.size) clearSelection(); });

// Smooth-scroll a scene/video row into view, offset BELOW the sticky header so the scene number isn't
// hidden under the tabs (plain scrollIntoView left the top tucked under the header).
function scrollToRow(row) {
  if (!row) return;
  const hdr = document.querySelector("header");
  const off = (hdr ? hdr.getBoundingClientRect().bottom : 0) + 14;
  const y = row.getBoundingClientRect().top + window.scrollY - off;
  window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
}
// ---------- scene jump launcher (bottom-left of the Scenes tab) ----------
// A small pill showing the CURRENT scene ("12 / 41") that pops a compact grid of every scene number;
// click a number to smooth-scroll there. Compact (no long rail), and doubles as a "where am I" marker.
// One navigator engine, two instances: Scenes (colours by image state) and Videos (colours by
// video state). Videos share the same DOC.scenes order, so a chip drag reorders scenes either way.
const JUMP_CFG = {
  scene: {
    box: "sceneJump", list: "scenesList", row: "scene-row", noun: "Scene",
    state: (s) => { const im = s.image || {}; const hasImg = ((im.versions) || []).length > 0;
      return s.approved ? "sj-approved" : (hasImg ? "sj-made" : (im.status === "error" ? "sj-failed" : "")); },
  },
  video: {
    box: "videoJump", list: "videosList", row: "video-row", noun: "Video",
    state: (s) => { const v = s.video || {}; const hasVid = !!(v.file && v.status === "ready");
      return v.approved ? "sj-approved" : (hasVid ? "sj-made" : (v.status === "error" ? "sj-failed" : "")); },
  },
};
const _jumpObs = { scene: null, video: null };
function buildSceneJump() { buildJump("scene"); }
function buildVideoJump() { buildJump("video"); }
function buildJump(kind) {
  const cfg = JUMP_CFG[kind];
  const box = document.getElementById(cfg.box);
  if (!box) return;
  const pop = box.querySelector(".scene-jump-pop");
  const grid = box.querySelector(".scene-jump-grid");
  const btn = box.querySelector(".scene-jump-btn");
  const label = box.querySelector(".sj-label");
  grid.innerHTML = "";
  if (_jumpObs[kind]) { _jumpObs[kind].disconnect(); _jumpObs[kind] = null; }
  const rows = [...document.querySelectorAll(`#${cfg.list} .${cfg.row}`)];   // mirrors the hide-approved filter → every chip maps to a real card
  box.hidden = rows.length < 2;
  pop.hidden = true; box.classList.remove("open");
  if (rows.length < 2) return;
  const total = rows.length;
  const closePop = () => { pop.hidden = true; box.classList.remove("open"); };
  rows.forEach(row => {
    const id = row.dataset.id;
    const s = (DOC.scenes || []).find(x => String(x.id) === String(id));   // colour the chip by scene/video state
    const st = s ? cfg.state(s) : "";
    const c = document.createElement("button");
    c.type = "button"; c.className = "sj-chip" + (st ? " " + st : ""); c.dataset.target = id; c.textContent = id;
    c.title = `${cfg.noun} #${id} — click to jump, drag to reorder`;
    c.addEventListener("click", (e) => {
      e.stopPropagation();
      const r = document.querySelector(`#${cfg.list} .${cfg.row}[data-id="${id}"]`);
      scrollToRow(r);
      closePop();
    });
    // hold-and-drag a chip to reorder (scenes and videos share the same order)
    c.draggable = true;
    c.addEventListener("dragstart", (e) => { e.stopPropagation(); c.classList.add("sj-drag"); try { e.dataTransfer.setData("text/plain", String(id)); e.dataTransfer.effectAllowed = "move"; } catch (_) {} });
    c.addEventListener("dragend", () => c.classList.remove("sj-drag"));
    c.addEventListener("dragover", (e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; c.classList.add("sj-drop"); });
    c.addEventListener("dragleave", () => c.classList.remove("sj-drop"));
    c.addEventListener("drop", async (e) => {
      e.preventDefault(); e.stopPropagation(); c.classList.remove("sj-drop");
      const src = (e.dataTransfer.getData("text/plain") || "").trim();
      if (!src || src === String(id)) return;
      const rect = c.getBoundingClientRect();
      const after = (e.clientX - rect.left) > rect.width / 2;   // drop on right half → place after
      await reorderScene(+src, +id, after);                     // rebuilds scenes + videos + both chip grids
    });
    grid.appendChild(c);
  });
  btn.onclick = (e) => {
    e.stopPropagation();
    if (box.classList.contains("moving")) return;   // in move mode, clicks reposition — don't open the grid
    const willOpen = pop.hidden;
    pop.hidden = !willOpen; box.classList.toggle("open", willOpen);
    if (willOpen) { const act = grid.querySelector(".sj-chip.active"); if (act) act.scrollIntoView({ block: "nearest" }); }
  };
  if (!buildJump._wired) {   // close any open grid on click-away / Esc (wire the document listeners just once, for both pills)
    const closeAll = () => document.querySelectorAll(".scene-jump").forEach(b => { const p = b.querySelector(".scene-jump-pop"); if (p) p.hidden = true; b.classList.remove("open"); });
    document.addEventListener("click", (e) => { if (!e.target.closest(".scene-jump")) closeAll(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeAll(); });
    buildJump._wired = true;
  }
  const setActive = (id) => {
    label.textContent = `${id} / ${total}`;
    grid.querySelectorAll(".sj-chip").forEach(c => c.classList.toggle("active", c.dataset.target === id));
  };
  setActive(rows[0].dataset.id);
  // update the current row as you scroll (the pill label + the highlighted chip)
  _jumpObs[kind] = new IntersectionObserver((entries) => {
    let hit = null;
    entries.forEach(e => { if (e.isIntersecting) hit = e.target.dataset.id; });
    if (hit != null) setActive(hit);
  }, { rootMargin: "-45% 0px -45% 0px", threshold: 0 });
  rows.forEach(r => _jumpObs[kind].observe(r));
}

// ---- draggable jump pill: double-click to unlock (turns red), drag anywhere, click away to lock ----
// Wired once per pill; each keeps its own drag state + saved position (scene vs video).
function applyJumpPos(box, posKey, fallbackKey) {
  if (!box) return;
  let pos = null; try { pos = JSON.parse(localStorage.getItem(posKey) || "null"); } catch (e) {}
  // no saved position of its own → mirror the sibling pill so both sit in the same spot
  if ((!pos || !Number.isFinite(pos.left)) && fallbackKey) { try { pos = JSON.parse(localStorage.getItem(fallbackKey) || "null"); } catch (e) {} }
  if (pos && Number.isFinite(pos.left) && Number.isFinite(pos.top)) {
    const w = box.offsetWidth || 130, h = box.offsetHeight || 42;   // clamp into view so a saved pos from a bigger screen can't strand it off-screen
    const left = Math.max(4, Math.min((window.innerWidth || 1280) - w - 4, pos.left));
    const top = Math.max(4, Math.min((window.innerHeight || 800) - h - 4, pos.top));
    box.style.left = left + "px"; box.style.top = top + "px"; box.style.bottom = "auto";
  }
}
function setJumpMoving(box, on) {
  if (!box) return;
  box.classList.toggle("moving", on);
  if (!on) box.classList.remove("dragging");
  else { const pop = box.querySelector(".scene-jump-pop"); if (pop) pop.hidden = true; box.classList.remove("open"); }   // hide the grid while repositioning
}
function wireJumpDrag(boxId, posKey, fallbackKey) {
  const box = document.getElementById(boxId); if (!box) return;
  applyJumpPos(box, posKey, fallbackKey);
  let drag = null;
  box.addEventListener("dblclick", (e) => { e.preventDefault(); e.stopPropagation(); setJumpMoving(box, !box.classList.contains("moving")); });
  box.addEventListener("pointerdown", (e) => {
    if (!box.classList.contains("moving") || (e.button != null && e.button !== 0)) return;
    e.preventDefault(); e.stopPropagation();
    const r = box.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    box.classList.add("dragging");
    try { box.setPointerCapture(e.pointerId); } catch (_) {}
  });
  box.addEventListener("pointermove", (e) => {
    if (!drag) return;
    e.preventDefault();
    const w = box.offsetWidth, h = box.offsetHeight;
    let left = Math.max(4, Math.min(window.innerWidth - w - 4, e.clientX - drag.dx));
    let top = Math.max(4, Math.min(window.innerHeight - h - 4, e.clientY - drag.dy));
    box.style.left = left + "px"; box.style.top = top + "px"; box.style.bottom = "auto";
  });
  const endDrag = (e) => {
    if (!drag) return;
    drag = null; box.classList.remove("dragging");
    try { box.releasePointerCapture(e.pointerId); } catch (_) {}
    const left = parseFloat(box.style.left) || 0, top = parseFloat(box.style.top) || 0;
    try { localStorage.setItem(posKey, JSON.stringify({ left, top })); } catch (_) {}
  };
  box.addEventListener("pointerup", endDrag);
  box.addEventListener("pointercancel", endDrag);
  // click/press anywhere outside this pill → lock it in place (leave move mode)
  document.addEventListener("pointerdown", (e) => { if (box.classList.contains("moving") && !e.target.closest("#" + boxId)) setJumpMoving(box, false); });
}
(function wireAllJumpDrag() {
  wireJumpDrag("sceneJump", "sceneJumpPos");
  wireJumpDrag("videoJump", "videoJumpPos", "sceneJumpPos");   // video pill defaults to the scene pill's spot
})();

// ---------- reference thumbnails (served locally, not from Cloudinary) ----------
// Size the square thumbnails to pack all N of them into the refs area (a fixed W×H box that
// fills down to the left "Generate Image" button). Pick the column count that makes the
// squares as large as possible while every row still fits the height — so a few refs are big
// and many shrink to keep fitting the same area.
function fitRefs(container) {
  // Thumbnails are now sized by CSS (fixed-size auto-fill grid), independent of column height.
  // Clear any stale inline sizing so the stylesheet wins.
  if (!container) return;
  container.style.gridTemplateColumns = "";
  container.style.gridAutoRows = "";
}

// Smoothly stretch/shrink the refs grid (and thus the scene frame) from oldH to its new height.
// Runs synchronously (the DOM is already updated by drawRefs) so it doesn't depend on rAF firing.
function animateRefsHeight(container, oldH) {
  if (!container) return;
  container.style.display = "grid";                // override :empty { display:none } so an emptied list can animate closed
  const newH = container.scrollHeight;
  if (Math.abs(newH - oldH) < 1) { container.style.display = ""; return; }
  container.style.overflow = "hidden";
  container.style.height = oldH + "px";
  getComputedStyle(container).height;              // reflow so the transition runs
  container.style.transition = "height .32s cubic-bezier(.3,.72,.3,1)";
  container.style.height = newH + "px";
  clearTimeout(container._t);
  container._t = setTimeout(() => {                // release back to natural height (CSS hides it again if now empty)
    container.style.transition = "";
    container.style.height = "";
    container.style.overflow = "";
    container.style.display = "";
  }, 360);
}
window.addEventListener("resize", () => document.querySelectorAll(".scene-refs-list").forEach(fitRefs));

function refThumb(url) {
  return `/api/ref-thumb/${encodeURIComponent(PROJECT)}?u=${encodeURIComponent(url)}`;
}
// Point an <img> at the local copy, falling back to the original URL once if it's gone.
function setRefImg(img, url) {
  if (!url) return;
  if (/^(blob|data):/.test(url)) { img.src = url; return; }   // staged upload preview
  img.onerror = () => { img.onerror = null; img.src = url; };
  img.src = refThumb(url);
}

// ---------- named characters (per-project cast) ----------
// The old "In scene:" chip row is retired — cast is now assigned via the Cast dropdown next to
// Reference Scene (see the scene render loop). This just keeps the old row hidden.
function drawSceneCast(container, s) {
  if (!container) return;
  container.innerHTML = "";
  container.hidden = true;
}
function refreshAllSceneCast() {
  $$(".scene-row").forEach(el => el._updateCast && el._updateCast());   // refresh each Cast button (visibility + label) after a character is added/removed
}
// ---- Cast/Characters field INSIDE the Target Audience modal (a dropdown like the others) ----
let castSummaryEl = null;
let pendingCast = [];   // NEW-project mode: characters staged in the browser, uploaded after the project is created
function castCount() { return modalMode === "new" ? pendingCast.length : ((DOC && DOC.characters) || []).length; }
function updateCastSummary() {
  if (!castSummaryEl) return;
  const n = castCount();
  castSummaryEl.textContent = n ? `${n} character${n === 1 ? "" : "s"}` : "";
}
function charUrls(c) { return (c && (c.urls || (c.url ? [c.url] : []))) || []; }

function renderCastBody(inner) {
  inner.innerHTML = "";
  const isNew = modalMode === "new";
  const hint = document.createElement("div");
  hint.className = "cast-hint";
  hint.textContent = isNew
    ? "Add named characters now — they’re created with the project. Give each a name and one or more reference images; assign them per scene on the Scenes tab."
    : "Named characters keep people consistent across scenes. Rename inline, add or remove reference images (several per character is fine), or ✨ generate a portrait from the description — then assign them per scene on the Scenes tab.";
  inner.appendChild(hint);

  const list = document.createElement("div"); list.className = "cast-list";
  const items = isNew ? pendingCast : ((DOC && DOC.characters) || []);
  items.forEach((c, i) => list.appendChild(buildCastCard(c, i, isNew, inner)));

  // add-a-new-character row — rendered ABOVE the existing characters
  const form = document.createElement("div"); form.className = "cast-add";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-add-name"; nameI.placeholder = "New character name (e.g. Loretta)";
  const fileL = document.createElement("label"); fileL.className = "cast-add-file";
  const fileTxt = document.createElement("span"); fileTxt.textContent = "＋ Add images";
  const fileI = document.createElement("input"); fileI.type = "file"; fileI.accept = "image/*"; fileI.multiple = true; fileI.hidden = true;
  fileL.append(fileTxt, fileI);
  const saveB = document.createElement("button"); saveB.type = "button"; saveB.className = "cast-add-save primary"; saveB.textContent = "＋ Add Character"; saveB.disabled = true;
  form.append(nameI, fileL, saveB);
  let files = [];
  const validate = () => { saveB.disabled = !(nameI.value.trim() && files.length); };
  fileI.addEventListener("change", e => { files = [...e.target.files]; fileTxt.textContent = files.length ? `${files.length} image${files.length > 1 ? "s" : ""} selected` : "＋ Add images"; validate(); });
  nameI.addEventListener("input", validate);
  saveB.addEventListener("click", () => withBusy(saveB, async () => {
    if (!(nameI.value.trim() && files.length)) return;
    if (isNew) {
      pendingCast.push({ name: nameI.value.trim(), files: [...files], previewUrls: files.map(f => URL.createObjectURL(f)) });
      renderCastBody(inner);
    } else {
      const r = await api.addCharacter(PROJECT, nameI.value.trim(), files);
      if (r.error) { alert(r.error); return; }
      DOC.characters = DOC.characters || []; DOC.characters.push(r);
      renderCastBody(inner); refreshAllSceneCast();
    }
  }));
  inner.appendChild(form);
  inner.appendChild(list);
}

// One character card: editable name + delete, then a grid of its reference images (each removable)
// plus an "add image(s)" tile. Handles both staged (new-project) and saved (existing-project) characters.
function buildCastCard(c, i, isNew, inner) {
  const card = document.createElement("div"); card.className = "cast-card";
  const head = document.createElement("div"); head.className = "cast-card-head";
  const nameI = document.createElement("input"); nameI.type = "text"; nameI.className = "cast-card-name"; nameI.value = c.name || ""; nameI.spellcheck = false;
  nameI.addEventListener("change", async () => {
    const nm = nameI.value.trim(); if (!nm) { nameI.value = c.name; return; }
    if (isNew) { c.name = nm; }
    else { const r = await api.updateCharacter(PROJECT, c.id, { name: nm }); if (!r.error) { c.name = r.name; refreshAllSceneCast(); toast(`Renamed to “${nm}”`, "ok"); } }
  });
  // Generate a portrait for this character (saved characters only — needs a stored id + description).
  // The result is a candidate the user reviews (use / regenerate / upload) — never auto-applied.
  if (!isNew) {
    const gen = document.createElement("button"); gen.type = "button"; gen.className = "cast-card-gen"; gen.innerHTML = MAGIC_SVG;
    gen.title = "Generate a portrait for this character";
    gen.addEventListener("click", () => openCharCandidate(c, inner, gen));
    head.appendChild(gen);
  }
  const del = document.createElement("button"); del.type = "button"; del.className = "cast-card-del"; del.innerHTML = TRASH_SVG; del.title = "Delete character";
  del.addEventListener("click", async () => {
    if (isNew) { (c.previewUrls || []).forEach(u => { try { URL.revokeObjectURL(u); } catch (e) {} }); pendingCast.splice(i, 1); renderCastBody(inner); return; }
    if (!(await confirmDialog(`Delete character “${c.name}”? It will be removed from every scene.`, { title: "Delete Character", okText: "Delete", danger: true }))) return;
    const r = await api.delCharacter(PROJECT, c.id);
    DOC.characters = r.characters || [];
    (DOC.scenes || []).forEach(s => { if (s.cast) s.cast = s.cast.filter(x => x !== c.id); });
    renderCastBody(inner); refreshAllSceneCast();
  });
  head.insertBefore(nameI, head.firstChild); head.appendChild(del); card.appendChild(head);

  const grid = document.createElement("div"); grid.className = "cast-img-grid";
  const urls = isNew ? (c.previewUrls || []) : charUrls(c);
  urls.forEach((u, idx) => {
    const thumb = document.createElement("div"); thumb.className = "cast-thumb";
    const im = document.createElement("img"); im.alt = ""; if (isNew) im.src = u; else setRefImg(im, u);
    const x = document.createElement("button"); x.type = "button"; x.className = "cast-thumb-x"; x.textContent = "×"; x.title = "Remove image";
    if (urls.length <= 1) x.disabled = true;                       // always keep at least one image
    x.addEventListener("click", async () => {
      if (urls.length <= 1) return;
      if (isNew) { try { URL.revokeObjectURL(c.previewUrls[idx]); } catch (e) {} c.files.splice(idx, 1); c.previewUrls.splice(idx, 1); renderCastBody(inner); return; }
      const r = await api.removeCharacterImage(PROJECT, c.id, u);
      if (!r.error) { const cc = DOC.characters.find(x => x.id === c.id); if (cc) { cc.urls = r.urls; delete cc.url; } renderCastBody(inner); refreshAllSceneCast(); }
    });
    thumb.append(im, x); grid.appendChild(thumb);
  });
  const add = document.createElement("label"); add.className = "cast-thumb cast-thumb-add"; add.title = "Add image(s)"; add.innerHTML = "<span>＋</span>";
  const addI = document.createElement("input"); addI.type = "file"; addI.accept = "image/*"; addI.multiple = true; addI.hidden = true;
  addI.addEventListener("change", async e => {
    const fs = [...e.target.files]; if (!fs.length) return;
    if (isNew) { fs.forEach(f => { c.files.push(f); c.previewUrls.push(URL.createObjectURL(f)); }); renderCastBody(inner); return; }
    const r = await api.updateCharacter(PROJECT, c.id, { files: fs });
    if (!r.error) { const cc = DOC.characters.find(x => x.id === c.id); if (cc) { cc.urls = r.urls; delete cc.url; } renderCastBody(inner); refreshAllSceneCast(); }
  });
  add.appendChild(addI); grid.appendChild(add);
  card.appendChild(grid);
  return card;
}

// Fade a modal-bg out (matches the .closing keyframes) instead of yanking it away instantly.
function smoothHideModal(bg) {
  if (!bg || bg.hidden) return;
  bg.classList.add("closing");
  setTimeout(() => { bg.hidden = true; bg.classList.remove("closing"); }, 175);
}
// A simple full-screen image viewer (for the candidate + anywhere a plain URL wants a big view).
function openUrlLightbox(url) {
  let lb = document.getElementById("urlLightbox");
  if (!lb) {
    lb = document.createElement("div"); lb.id = "urlLightbox"; lb.className = "url-lightbox"; lb.hidden = true;
    lb.innerHTML = `<img alt="">`;
    const shut = () => { lb.classList.remove("show"); setTimeout(() => { lb.hidden = true; }, 220); };
    lb.addEventListener("click", shut);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !lb.hidden) shut(); });
    document.body.appendChild(lb);
  }
  lb.querySelector("img").src = url;
  lb.hidden = false; requestAnimationFrame(() => lb.classList.add("show"));
}

// Generate-a-character flow — a mini image-generation studio for ONE character's portrait CANDIDATE (never
// auto-applied). Supports multiple versions (‹ ›), an edit box (image-to-image), click-to-zoom, and full-res
// preview. Accept commits the shown version; Cancel discards every candidate.
async function openCharCandidate(c, inner) {
  const bg = $("#charCandBg"), img = $("#charCandImg"), spin = $("#charCandSpin"), msg = $("#charCandMsg");
  const useB = $("#charCandUse"), regenB = $("#charCandRegen"), cancelB = $("#charCandCancel");
  const prevB = $("#charCandPrev"), nextB = $("#charCandNext"), verEl = $("#charCandVer");
  const editWrap = $("#charCandEdit"), editInstr = $("#charCandEditInstr"), editApply = $("#charCandEditApply");
  let versions = [], cur = -1, busy = false;
  const showCur = () => {
    if (cur >= 0) {
      img.style.opacity = "0";                                   // brief crossfade between versions (no hard pop)
      img.onload = () => { img.style.opacity = "1"; };
      img.src = mediaUrl(versions[cur]); img.hidden = false;     // full-res, not the tiny thumb
      [cur - 1, cur + 1].forEach(i => { if (i >= 0 && i < versions.length) { const p = new Image(); p.src = mediaUrl(versions[i]); } });
    }
    const many = versions.length >= 2;
    verEl.hidden = !many; if (many) verEl.textContent = `${cur + 1} / ${versions.length}`;
    prevB.hidden = !many; nextB.hidden = !many;
    prevB.disabled = busy || cur <= 0; nextB.disabled = busy || cur >= versions.length - 1;
  };
  const setBusy = (b, label) => {
    busy = b;
    spin.hidden = !b;
    if (b) { img.hidden = cur < 0; } // keep the current image visible under the spinner while it works
    if (label != null) msg.textContent = label;
    useB.disabled = b || cur < 0;
    regenB.disabled = b;
    editApply.disabled = b || cur < 0;
    editInstr.disabled = b;
    editWrap.hidden = false;
    if (b) { prevB.hidden = nextB.hidden = verEl.hidden = true; } else showCur();
  };
  const generate = async (fresh) => {
    setBusy(true, `Generating “${c.name}”… this can take up to a minute.`);
    let r; try { r = await api.genCharacter(PROJECT, c.id, fresh); } catch (e) { r = { error: "request failed" }; }
    if (r.error) { setBusy(false); toast(r.error, "err", 6000); if (cur < 0) close(true); return; }
    versions.push(r.url); cur = versions.length - 1;
    setBusy(false, "Not applied yet — use it, flip versions, edit it, or regenerate.");
  };
  const doEdit = async () => {
    const instr = (editInstr.value || "").trim();
    if (!instr || busy || cur < 0) return;
    setBusy(true, "Applying your edit…");
    let r; try { r = await api.editCharCandidate(PROJECT, c.id, versions[cur], instr); } catch (e) { r = { error: "request failed" }; }
    if (r.error) { setBusy(false); toast(r.error, "err", 6000); return; }
    editInstr.value = "";
    versions.push(r.url); cur = versions.length - 1;
    setBusy(false, "Edited — that's a new version. Keep editing, flip back, or use it.");
  };
  function cleanup() { useB.onclick = regenB.onclick = cancelB.onclick = prevB.onclick = nextB.onclick = editApply.onclick = editInstr.onkeydown = img.onclick = bg.onclick = null; document.removeEventListener("keydown", onKey); }
  const onKey = (e) => { if (busy) return; if (e.key === "Escape") close(true); else if (e.key === "ArrowLeft") prevB.onclick && prevB.onclick(); else if (e.key === "ArrowRight") nextB.onclick && nextB.onclick(); };
  async function close(discard) {
    if (busy) return;
    smoothHideModal(bg); cleanup();
    if (discard && versions.length) { try { await api.discardCharCandidate(PROJECT, c.id, { all: true }); } catch (e) {} }
  }
  const commit = (r, verb) => {
    const cc = (DOC.characters || []).find(x => x.id === c.id); if (cc) { cc.urls = r.urls; delete cc.url; }
    versions = []; smoothHideModal(bg); cleanup();
    renderCastBody(inner); refreshAllSceneCast();
    toast(`✓ ${verb} “${c.name}”`, "ok");
  };
  $("#charCandTitle").textContent = `Generate “${c.name}”`;
  bg.hidden = false;
  useB.onclick = async () => {
    if (busy || cur < 0) return;
    setBusy(true, "Adding…");
    const r = await api.useCharCandidate(PROJECT, c.id, versions[cur]);
    if (r.error) { setBusy(false); toast(r.error, "err"); return; }
    commit(r, "Added a generated photo to");
  };
  regenB.onclick = () => { if (!busy) generate(false); };
  prevB.onclick = () => { if (!busy && cur > 0) { cur--; showCur(); } };
  nextB.onclick = () => { if (!busy && cur < versions.length - 1) { cur++; showCur(); } };
  editApply.onclick = doEdit;
  editInstr.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); doEdit(); } };
  img.onclick = () => { if (cur >= 0) openUrlLightbox(mediaUrl(versions[cur])); };
  cancelB.onclick = () => close(true);
  bg.onclick = (e) => { if (e.target === bg) close(true); };
  document.addEventListener("keydown", onKey);
  generate(true);   // first open → fresh (drops any stale candidates), then builds version 1
}

function setBadge(node, obj) {
  const map = { empty: "", queued: "🕒 queued", generating: "⏳ generating…", ready: "✓ ready",
                error: "⚠ " + trunc(obj.error || "error", 42) };
  // preserve marker classes (img-status / vid-status); only swap the status class
  const prev = node.dataset.badge;
  if (prev) node.classList.remove(prev);
  node.classList.add("status-badge");
  if (obj.status) { node.classList.add(obj.status); node.dataset.badge = obj.status; }
  node.textContent = map[obj.status] ?? obj.status;
  node.title = obj.status === "error" ? (obj.error || "error") : "";   // full reason on hover (#2)
}

// ---------- tab 3: videos ----------
// reuse <video> elements across renders so approving/re-rendering never reloads them (no black flash)
const _vidCache = new Map();   // scene id -> { src, el }
// A video is "in sync" only if it was made from the scene's CURRENT approved image. New videos record
// their source image; legacy ones (no source) fall back to matching the scene-NN in the file names.
function videoInSync(s) {
  const v = s.video, cur = (s.image.approved_file || s.image.file);
  if (!v || !v.file) return true;
  if (v.source) return v.source === cur;
  const base = p => (/scene-0*(\d+)/.exec(p || "") || [])[1];
  return base(v.file) === base(cur);
}
function renderVideos() {
  const wrap = $("#videosList");
  if (!wrap) return;
  const _sy = window.scrollY;   // preserve page scroll across the rebuild (Videos tab was jumping to top on each poll)
  wrap.innerHTML = "";
  const approved = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file));
  $("#videosEmpty").hidden = approved.length > 0;
  const vReady = approved.filter(s => s.video && s.video.status === "ready" && s.video.file).length;
  const vApproved = approved.filter(s => s.video && s.video.approved).length;
  // combined: scenes with an approved image (eligible for video), how many videos generated, how many approved
  const cc = $("#videosConvertCount"); if (cc) cc.textContent = approved.length ? `${approved.length} scenes · ${vReady} videos generated · ${vApproved} approved` : "";
  const vc = $("#videosApproveCount"); if (vc) vc.textContent = "";
  const tpl = $("#videoTpl");
  for (const s of approved) {
    if (hideApprovedVideos && s.video && s.video.approved) continue;   // toggle: hide approved videos
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = s.id;
    if (s.video && s.video.approved) el.classList.add("approved");
    if (_flashApproveVideo === s.id) { el.classList.add("just-approved"); setTimeout(() => el.classList.remove("just-approved"), 900); _flashApproveVideo = null; }
    $(".scene-num", el).textContent = `#${s.id}`;
    $(".scene-caption", el).textContent = trunc(s.vo, 90);
    const ai = $(".approved-img", el);
    const asrc = mediaUrl(s.image.approved_file || s.image.file, s.image.taskId);
    const img = document.createElement("img"); img.src = asrc; img.style.cursor = "zoom-in";
    img.addEventListener("click", () => lightbox(asrc, "img"));
    ai.appendChild(img);
    // Delete Scene (in the header row, right edge of the left column — same as the Scenes tab)
    $(".scene-del", el).addEventListener("click", async () => {
      if (!(await confirmDialog(`Delete scene #${s.id}? Its image and video will be removed.`, { title: "Delete Scene", okText: "Delete" }))) return;
      DOC = await api.deleteScene(PROJECT, s.id); renderScenes(); renderVideos();
    });
    $(".video-desc", el).value = s.video_desc || "";
    $(".video-desc", el).addEventListener("input", e => { s.video_desc = e.target.value; queueSave(); });
    // camera-lock toggle: ON (default) → the generated video keeps a static camera; OFF → camera may move
    const camLock = $(".cam-lock", el);
    if (camLock) {
      if (s.video_cam_lock === undefined) s.video_cam_lock = true;
      const paint = () => { const on = !!s.video_cam_lock; camLock.classList.toggle("on", on); camLock.textContent = on ? "🔒 Camera locked" : "🎥 Camera free"; };
      paint();
      camLock.addEventListener("click", () => { s.video_cam_lock = !s.video_cam_lock; paint(); queueSave(); });
    }
    // duration / quality / model dropdowns (options adapt to the selected model)
    if (VIDEO_MODELS.length) {
      const cfg = VIDEO_MODELS.find(m => m.key === s.video_model) || VIDEO_MODELS[0];
      const dur = cfg.durations.includes(s.video_dur) ? s.video_dur : cfg.defaultDur;
      const res = cfg.resolutions.includes(s.video_res) ? s.video_res : cfg.defaultRes;
      s.video_model = cfg.key; s.video_dur = dur; s.video_res = res;
      vDropdown($(".dur-dd", el), "Duration", dur + "s",
        cfg.durations.map(d => ({ value: d, label: d + "s", selected: d === dur })),
        (v) => { s.video_dur = v; queueSave(); renderVideos(); });
      vDropdown($(".res-dd", el), "Quality", res,
        cfg.resolutions.map(r => ({ value: r, label: r, selected: r === res })),
        (v) => { s.video_res = v; queueSave(); renderVideos(); });
      vDropdown($(".vmodel-dd", el), "Model", cfg.label,
        VIDEO_MODELS.map(m => ({ value: m.key, label: m.label, selected: m.key === cfg.key })),
        (v) => { const c = VIDEO_MODELS.find(m => m.key === v); s.video_model = v; s.video_dur = c.defaultDur; s.video_res = c.defaultRes; queueSave(); renderVideos(); });
    }
    const vidPrev = $(".vid-preview", el);
    if (s.video.file && s.video.status === "ready") {
      vidPrev.innerHTML = "";
      const vsrc = mediaUrl(s.video.file, s.video.taskId);
      // reuse the existing <video> for this scene if its source is unchanged — moving the
      // already-loaded element into the new row keeps its frame, so approve/re-render never
      // reloads it to black. Only build a fresh one when the video itself changed.
      let cached = _vidCache.get(s.id);
      let v;
      if (cached && cached.src === vsrc) { v = cached.el; }
      else { v = document.createElement("video"); v.src = vsrc; v.controls = true; _vidCache.set(s.id, { src: vsrc, el: v }); }
      vidPrev.appendChild(v);
      // overlay actions (top-right of the video)
      const ov = document.createElement("div"); ov.className = "img-actions";
      const a = document.createElement("button"); a.className = "ia approve" + (s.video.approved ? " on" : ""); a.textContent = "✓"; a.title = s.video.approved ? "Approved (click to unapprove)" : "Approve video";
      const c = document.createElement("button"); c.className = "ia change"; c.textContent = "↻"; c.title = "Change (regenerate)";
      const r = document.createElement("button"); r.className = "ia remove"; r.innerHTML = TRASH_SVG; r.title = "Remove video";
      a.addEventListener("click", async (e) => { e.stopPropagation(); const willApprove = !s.video.approved; if (willApprove) _flashApproveVideo = s.id; await flushSave(); s._appLock = Date.now() + 8000; DOC = await api.videoApprove(PROJECT, s.id, willApprove); const _f = DOC.scenes.find(x => x.id === s.id); if (_f) _f._appLock = Date.now() + 8000; renderVideos(); toast(willApprove ? `Approved Video: Scene ${s.id}` : `Unapproved Video: Scene ${s.id}`, willApprove ? "ok" : "info"); });
      c.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Video: Scene ${s.id}`, "info"); genVideos([s.id]); });
      r.addEventListener("click", async (e) => { e.stopPropagation(); DOC = await api.resetVideo(PROJECT, s.id); toast(`Removed Video: Scene ${s.id}`, "info"); renderVideos(); });
      ov.appendChild(a); ov.appendChild(c); ov.appendChild(r);
      vidPrev.appendChild(ov);
      if (!videoInSync(s)) {   // this video was made from an image that's no longer the approved one
        const warn = document.createElement("div"); warn.className = "vid-stale";
        const t = document.createElement("span"); t.textContent = "⚠ Made from an older image";
        const rb = document.createElement("button"); rb.type = "button"; rb.className = "vid-stale-regen"; rb.textContent = "↻ Regenerate";
        rb.addEventListener("click", (e) => { e.stopPropagation(); toast(`Regenerating Video: Scene ${s.id}`, "info"); genVideos([s.id]); });
        warn.append(t, rb); vidPrev.appendChild(warn);
      }
    } else if (s.video.status === "generating" || s.video.status === "queued") {
      vidPrev.innerHTML = "";                        // same "Generating…" loading overlay the images use
      addGenOverlay(vidPrev, s.video.status);
    }
    setBadge($(".vid-status", el), s.video);
    const gvp = $(".gen-vid-prompt", el);
    gvp.addEventListener("click", () => stoppable(gvp, (sig) => genVideoPrompts([s.id], sig)));
    const gv = $(".gen-vid", el);
    gv.addEventListener("click", () => withBusy(gv, () => genVideos([s.id])));
    if (s.video.status === "generating") setBusy(gv, true);
    // control bar (mirrors the scenes image nav): label + arrows + Edit + Download — shown
    // only once a video exists; Download/Edit appear together after generation.
    const vEditBox = $(".video-edit-box", el), vEditInstr = $(".video-edit-instr", el);
    vEditInstr.value = s.video_desc || "";
    const vidNav = $(".vid-nav", el);
    if (s.video.file && s.video.status === "ready") {
      vidNav.hidden = false;
      $(".vver-label", el).textContent = "1 / 1";
      $(".vid-download", el).addEventListener("click", () => downloadMedia(s.video.file, `${pad2(s.id)}_${slug(s.vo)}.mp4`, `Scene ${s.id}`));
      $(".vid-edit", el).addEventListener("click", () => { vEditBox.hidden = !vEditBox.hidden; });
    }
    $(".video-edit-apply", el).addEventListener("click", (ev) => {
      const t = vEditInstr.value.trim();
      if (!t) { alert("Type what to change."); return; }
      s.video_desc = t;
      $(".video-desc", el).value = t;
      withBusy(ev.currentTarget, () => genVideos([s.id]));
    });
    wrap.appendChild(el);
  }
  buildVideoJump();
  if (_sy > 0 && document.body.classList.contains("tab-videos")) requestAnimationFrame(() => window.scrollTo(0, _sy));
}

// ---------- actions ----------
function queueSave() {
  clearTimeout(saveTimer);
  setStatus("saving…");
  saveTimer = setTimeout(async () => { await api.save(PROJECT, DOC); setStatus("saved"); setTimeout(() => setStatus(""), 1000); }, 600);
}
async function flushSave() { clearTimeout(saveTimer); if (PROJECT && DOC) await api.save(PROJECT, DOC); }
async function genPrompts(ids, signal) {
  setStatus("generating prompts…");
  await flushSave();                       // ensure latest edited sentences are saved first
  pushUndo("generate prompts");            // undo restores the previous prompts
  const r = await api.genPrompt(PROJECT, ids, signal);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  const note = r.director_note; delete r.director_note;
  DOC = r; renderScenes(); setStatus("");
  if (note) toast(note, "info");   // which model actually ran (Fable 5 / Opus 4.8)
}
// After a user-triggered generation, surface any scene that FAILED with the real reason as a prominent
// toast — otherwise it just sits as a tiny red badge and looks like "nothing happened". Account errors
// (Kie credits/balance) get a big, explicit message.
function reportGenErrors(doc, ids, kind) {
  const scenes = (doc && doc.scenes) || [];
  const want = ids === "all" ? null : new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  const errs = [];
  scenes.forEach(s => {
    if (want && !want.has(String(s.id))) return;
    const m = kind === "video" ? s.video : s.image;
    if (m && m.status === "error" && m.error) errs.push({ id: s.id, error: String(m.error) });
  });
  if (!errs.length) return;
  const noun = kind === "video" ? "videos" : "images";
  if (errs.some(e => /credit|balance|insufficient|top ?up|quota/i.test(e.error))) {
    toast("⚠ Kie.ai balance too low to generate " + noun + " — top up your credits (make sure the key in Settings → API Keys is the account you funded).", "err", 14000);
  } else {
    const e0 = errs[0];
    toast(`⚠ ${kind === "video" ? "Video" : "Image"} failed — Scene ${e0.id}: ${e0.error}`, "err", 11000);
  }
}
async function genImages(ids) {
  setStatus("submitting…");
  await flushSave();                       // ensure latest edited prompts are saved first
  let fresh;
  try { fresh = await api.generate(PROJECT, ids); }
  catch (e) { toast("Couldn't start image generation (" + e + ").", "err"); setStatus(""); return; }
  if (fresh && fresh.error) { toastErr(fresh.error); setStatus(""); return; }
  // Submitting takes a few seconds. During that gap the user may add a scene or edit another card —
  // so MERGE the status in place (never replace the whole DOC) and patch the media in place (never a
  // full re-render). That keeps their new scene, their typing, focus and scroll exactly as they left them.
  mergePoll(fresh, true);                  // authoritative: the generate result must win even inside a recent _appLock window
  reportGenErrors(fresh, ids, "image");    // surface any immediate failure (credits, etc.) prominently
  patchAllSceneMedia(); buildSceneJump();
  ensurePolling(); renderGenProgress(); setStatus("");
}
async function genVideos(ids) {
  setStatus("submitting video…");
  await flushSave();
  let r;
  try { r = await api.genVideo(PROJECT, ids); }
  catch (e) { toast("Couldn't start video generation (" + e + ").", "err"); setStatus(""); return; }
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  mergePoll(r, true);                      // authoritative: the generate result must win even if the image was just approved (_appLock)
  reportGenErrors(r, ids, "video");        // surface any immediate failure (credits, etc.) prominently
  const typing = document.activeElement && /^(TEXTAREA|INPUT|SELECT)$/.test(document.activeElement.tagName);
  if (!typing) renderVideos();
  ensurePolling(); renderGenProgress(); setStatus("");
}
async function genVideoPrompts(ids, signal) {
  setStatus("generating video prompts…");
  await flushSave();                        // keep any hand-typed prompts before overwriting
  const r = await api.genVideoPrompt(PROJECT, ids, signal);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  DOC = r; renderVideos(); setStatus("");
}
async function editImage(sid, instr) {
  setStatus("editing image…");
  await flushSave();
  const r = await api.editImage(PROJECT, sid, instr);
  if (r.error) { toastErr(r.error); setStatus(""); return; }
  mergePoll(r, true);                      // authoritative: the edit result must win even inside a recent _appLock window
  reportGenErrors(r, [sid], "image");      // surface any immediate failure (credits, etc.) prominently
  patchAllSceneMedia(); buildSceneJump();
  ensurePolling(); setStatus("");
}

function anyGenerating() {
  const busy = s => s === "generating" || s === "queued";
  return DOC && DOC.scenes.some(s => busy(s.image.status) || busy(s.video.status));
}
// ---- batch-generation progress + retry-failed ----
function genCounts(kind) {
  const scenes = (DOC && DOC.scenes) || [];
  const c = { ready: 0, gen: 0, queued: 0, err: 0, errIds: [], busyIds: [] };
  scenes.forEach(s => {
    const im = kind === "image" ? s.image : s.video;
    const st = im && im.status;
    // a usable output already exists? (image → any version; video → a file) → it's NOT "failed" anymore,
    // even if the LAST attempt errored — the user re-generated it successfully.
    const hasOutput = kind === "image" ? ((im && im.versions) || []).length > 0 : !!(im && im.file);
    if (st === "generating") { c.gen++; c.busyIds.push(s.id); }
    else if (st === "queued") { c.queued++; c.busyIds.push(s.id); }
    else if (st === "ready" || hasOutput) c.ready++;
    else if (st === "error") { c.err++; c.errIds.push(s.id); }
  });
  c.total = c.ready + c.gen + c.queued + c.err;
  return c;
}
const _stopBatch = { image: false, video: false };   // true while a "Stop all" cancel loop runs → don't let a poll rebuild (and re-enable) the button
function renderGenProgress() {
  [["image", "#genProgress"], ["video", "#vidGenProgress"]].forEach(([kind, sel]) => {
    if (_stopBatch[kind]) return;                    // mid-cancel: leave the "Stopping…" button as-is
    const box = $(sel); if (!box) return;
    const c = genCounts(kind);
    if (c.gen === 0 && c.queued === 0 && c.err === 0) { box.hidden = true; box.innerHTML = ""; return; }
    box.hidden = false;
    const noun = kind === "image" ? "images" : "videos";
    const running = c.gen + c.queued;
    box.innerHTML =
      (c.gen ? `<span class="gp-gen"><span class="sub-spin"></span> ${c.gen} ${noun} generating…</span>` : "") +
      (c.queued ? `<span class="gp-queued">🕒 ${c.queued} queued</span>` : "") +
      (c.err ? `<span class="gp-err gp-err-link" title="Go to the failed ${kind}">⚠ ${c.err} failed</span>` : "") +
      (running ? `<button class="gp-stop" title="Stop every ${noun.slice(0, -1)} still generating">⏹ Stop all</button>` : "");
    const errLink = box.querySelector(".gp-err-link");
    if (errLink && c.errIds.length) errLink.addEventListener("click", () => {
      const id = c.errIds[0];                                   // jump to the first failed scene/video
      const cont = kind === "video" ? "#videosList" : "#scenesList";
      const rowcls = kind === "video" ? "video-row" : "scene-row";
      const r = document.querySelector(`${cont} .${rowcls}[data-id="${id}"]`);
      scrollToRow(r);
    });
    const stopBtn = box.querySelector(".gp-stop");
    if (stopBtn) stopBtn.addEventListener("click", async () => {
      _stopBatch[kind] = true;                                  // freeze this progress box so a poll can't re-enable the button mid-cancel
      stopBtn.disabled = true; stopBtn.textContent = "Stopping…";
      const ids = genCounts(kind).busyIds;                      // re-read: some may have finished since render
      const cancel = kind === "image" ? api.cancelImage : api.cancelVideo;
      let last = null;
      for (const id of ids) { try { last = await cancel(PROJECT, id); } catch (_) {} }
      if (last && last.scenes) { DOC = last; }                  // adopt the server's post-cancel truth
      _stopBatch[kind] = false;
      kind === "image" ? renderScenes() : renderVideos();
      renderGenProgress();
    });
  });
}
// merge poll results into the EXISTING scene objects in place, so open edit boxes,
// unsaved text and focus in the scene list are never destroyed by a full re-render.
function mergePoll(fresh, authoritative) {   // authoritative = the direct result of a user action (generate/cancel/edit) → apply it fully, ignore _appLock
  if (!DOC || !fresh || !fresh.scenes) return { vid: false };
  let vid = false;                              // did anything the Videos tab shows actually change?
  const byId = {}; DOC.scenes.forEach(s => byId[s.id] = s);
  const busy = st => st === "generating" || st === "queued";
  fresh.scenes.forEach(fs => {
    const s = byId[fs.id];
    if (!s) return;
    // A user action (approve / cancel / version-swap) sets s._appLock for ~8s. During that window a poll
    // that started BEFORE the action's save landed still carries the OLD state — don't let it revert.
    const locked = !authoritative && s._appLock && Date.now() < s._appLock;
    // Keep the WHOLE local media object for a locked scene that is NOT mid-generation (i.e. the user just
    // approved / cancelled / swapped a settled scene). A scene still generating keeps taking fresh updates
    // so real progress always flows. This is the core "no reverting while I work fast" guard.
    const keepImgWhole = locked && s.image && !busy(s.image.status);
    const keepVidWhole = locked && s.video && !busy(s.video.status);

    if (!keepImgWhole) genTransitionToast(s.id, "Image", s.image && s.image.status, fs.image && fs.image.status, fs.image && fs.image.error);
    if (!keepVidWhole) genTransitionToast(s.id, "Video", s.video && s.video.status, fs.video && fs.video.status, fs.video && fs.video.error);
    const ov = s.video || {}, nv = fs.video || {}, oi = s.image || {}, ni = fs.image || {};
    if (!keepVidWhole && (ov.status !== nv.status || ov.file !== nv.file || ov.approved !== nv.approved)) vid = true;
    if (!keepImgWhole && s.approved && (oi.approved_file !== ni.approved_file || oi.file !== ni.file)) vid = true;

    const keepApproved = locked ? s.approved : fs.approved;
    const keepAppVer = locked && s.image ? s.image.approved_version : undefined;
    const keepCurrent = locked && s.image ? s.image.current : undefined;   // don't let a poll snap the shown version back
    const keepVidAppr = locked && s.video ? s.video.approved : undefined;
    if (!keepImgWhole) s.image = fs.image;
    if (!keepVidWhole) s.video = fs.video;
    s.approved = keepApproved;
    if (locked) {
      if (s.image && !keepImgWhole) {
        s.image.approved_version = keepAppVer;
        if (keepCurrent != null && keepCurrent < (s.image.versions || []).length) s.image.current = keepCurrent;
      }
      if (s.video && !keepVidWhole) s.video.approved = keepVidAppr;
    }
    if (s.approved !== keepApproved) vid = true;
  });
  return { vid };
}
// Slide-in toast the moment an image/video finishes: pending (generating/queued) → ready or error.
// Guarding on the OLD state being pending means it never fires on load for already-done scenes.
function genTransitionToast(id, kind, oldSt, newSt, err) {
  const pending = st => st === "generating" || st === "queued";
  if (oldSt === newSt || !pending(oldSt)) return;
  const goThere = () => histGoto({ kind, id });   // click the toast → jump to that scene's image/video
  if (newSt === "ready") { toast(`${kind} generated: Scene ${id}`, "ok", 3800, { noHist: true, onClick: goThere }); pushHistory(kind, id, true); }
  else if (newSt === "error") {
    if (err && /credit|balance|insufficient|top ?up|quota/i.test(err))
      toast("⚠ Kie.ai balance too low — top up your credits to keep generating.", "err", 14000, { noHist: true, onClick: goThere });
    else toast(`⚠ ${kind} failed — Scene ${id}${err ? ": " + err : ""}`, "err", 10000, { noHist: true, onClick: goThere });
    pushHistory(kind, id, false);
  }
}
// update ONLY the image preview / status / version-nav of a scene row (no DOM wipe).
function patchSceneMedia(el, s) {
  const im = s.image, vs = im.versions || [];
  let cur = (im.current == null ? vs.length - 1 : im.current);
  const curFile = (vs.length && cur >= 0 && cur < vs.length) ? vs[cur] : null;
  const imgPrev = $(".img-preview", el);
  if (imgPrev.dataset.file !== (curFile || "")) {   // only rebuild when the shown file changed
    imgPrev.dataset.file = curFile || "";
    imgPrev.innerHTML = "";
    if (curFile) {
      imgPrev.classList.add("img-loading");
      const src = mediaUrl(curFile, s.image.taskId);
      const img = document.createElement("img");
      img.addEventListener("load", () => imgPrev.classList.remove("img-loading"));
      img.addEventListener("error", () => imgPrev.classList.remove("img-loading"));
      img.src = src;
      img.addEventListener("click", () => openImageLightbox(s));
      imgPrev.appendChild(img);
      const ov = document.createElement("div");
      ov.className = "img-actions";
      const approvedThis = s.approved && im.approved_version === cur;
      const bApprove = document.createElement("button");
      bApprove.className = "ia approve" + (approvedThis ? " on" : "");
      bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
      bApprove.textContent = "✓";
      const bChange = document.createElement("button");
      bChange.className = "ia change"; bChange.title = "Change (regenerate)"; bChange.textContent = "↻";
      const bRemove = document.createElement("button");
      bRemove.className = "ia remove"; bRemove.title = "Remove"; bRemove.innerHTML = TRASH_SVG;
      bApprove.onclick = async (e) => {
        e.stopPropagation();
        const willApprove = !bApprove.classList.contains("on");
        await flushSave();
        s._appLock = Date.now() + 8000;
        DOC = await api.approve(PROJECT, s.id, willApprove);
        const fresh = DOC.scenes.find(x => x.id === s.id); if (fresh) { fresh._appLock = Date.now() + 8000; Object.assign(s, fresh); }
        if (hideApproved && s.approved) renderScenes();
        else patchApprove(el, s, cur, bApprove);
        buildSceneJump();
        if (willApprove) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
        renderVideos();
      };
      bChange.onclick = (e) => { e.stopPropagation(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); };
      bRemove.title = "Delete this version";
      bRemove.onclick = async (e) => { e.stopPropagation(); pushUndo("delete image"); DOC = await api.deleteVersion(PROJECT, s.id, cur); toast(`Deleted Image: Scene ${s.id}`, "info"); renderScenes(); renderVideos(); };
      ov.appendChild(bApprove); ov.appendChild(bChange); ov.appendChild(bRemove);
      imgPrev.appendChild(ov);
    } else if (im.status === "generating" || im.status === "queued") {
      imgPrev.innerHTML = "";   // mid-generation with no prior image → only the "Generating…" overlay shows, no "no image" text under it
    } else {
      imgPrev.innerHTML = '<div class="placeholder">no image</div>';
    }
    drawSceneOst(el, s);   // innerHTML wipe above removed the .scene-ost overlays → redraw them on the new image
  }
  // loading overlay while (re)generating or queued; removed once it's ready/error/empty
  if (im.status === "generating" || im.status === "queued") {
    const ph = imgPrev.querySelector(".placeholder"); if (ph) ph.remove();   // no "no image" text under the "Generating…" overlay
    addGenOverlay(imgPrev, im.status);
  } else {
    const o = imgPrev.querySelector(".gen-overlay"); if (o) o.remove();
    if (!curFile && !imgPrev.querySelector("img") && !imgPrev.querySelector(".placeholder")) {
      imgPrev.innerHTML = '<div class="placeholder">no image</div>';   // generation ended with no image → restore the placeholder
      drawSceneOst(el, s);
    }
  }
  setBadge($(".img-status", el), im);
  const nav = $(".img-nav", el);
  if (vs.length) {
    nav.hidden = false;
    const av = im.approved_version;
    const isApprovedVer = s.approved && av === cur;
    wireVerArrows($(".img-preview", el), s, cur, vs.length);   // arrows + version badge overlay the image
    $(".ver-download", el).onclick = () => downloadMedia(curFile, `${pad2(s.id)}_${slug(s.vo)}.png`, `Scene ${s.id}`);
    const editBox = $(".edit-box", el);
    $(".ver-edit", el).onclick = () => { editBox.hidden = !editBox.hidden; };
    $(".edit-apply", el).onclick = (ev) => {
      const instr = $(".edit-instr", el).value.trim();
      if (!instr) { alert("Type what to change."); return; }
      withBusy(ev.currentTarget, () => editImage(s.id, instr));
    };
  } else {
    nav.hidden = true;
  }
  const gi = $(".gen-img", el);
  if (gi) setBusy(gi, s.image.status === "generating");
}
function patchAllSceneMedia() {
  const list = $("#scenesList"); if (!list) return;
  const byId = {}; (DOC?.scenes || []).forEach(s => byId[s.id] = s);
  $$(".scene-row", list).forEach(el => { const s = byId[el.dataset.id]; if (s) patchSceneMedia(el, s); });
}
// Stop an accidental / in-progress image generation for one scene.
async function cancelImage(sid) {
  const fresh = await api.cancelImage(PROJECT, sid);
  mergePoll(fresh, true);                          // authoritative cancel result
  const _s = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (_s) _s._appLock = Date.now() + 8000;         // a late in-flight poll must not revert the cancel
  patchAllSceneMedia(); renderGenProgress();
  if (!anyGenerating() && pollTimer) { clearInterval(pollTimer); pollTimer = null; setStatus(""); }
  toast("Image generation stopped.", "info");
}
// Stop an in-progress VIDEO generation for one scene.
async function cancelVideo(sid) {
  const fresh = await api.cancelVideo(PROJECT, sid);
  mergePoll(fresh, true);                          // authoritative cancel result
  const _s = DOC && DOC.scenes.find(x => String(x.id) === String(sid));
  if (_s) _s._appLock = Date.now() + 8000;         // a late in-flight poll must not revert the cancel
  renderVideos();
  if (!anyGenerating() && pollTimer) { clearInterval(pollTimer); pollTimer = null; setStatus(""); }
  toast("Video generation stopped.", "info");
}
document.addEventListener("click", (ev) => {
  const btn = ev.target.closest(".gen-stop");
  if (!btn) return;
  ev.preventDefault(); ev.stopPropagation();
  const vrow = btn.closest(".video-row");                  // Videos tab → stop the VIDEO job
  if (vrow && vrow.dataset.id) { btn.disabled = true; cancelVideo(vrow.dataset.id); return; }
  const row = btn.closest(".scene-row");                   // Scenes tab → stop the IMAGE job
  if (row && row.dataset.id) { btn.disabled = true; cancelImage(row.dataset.id); }
});
// SINGLE-FLIGHT polling: a self-scheduling setTimeout (not setInterval) so a slow poll can NEVER
// overlap the next one. The 6s gap is measured from the END of each poll, so under heavy generation
// (many images/videos, big downloads) requests never pile up — this is what keeps the UI smooth and
// stops the "reverting / lag while I work fast" behaviour. All screen updates here are in-place
// (patchAllSceneMedia only rebuilds an <img> when its file changed), so scrolling is never disturbed.
let _pollBusy = false;
async function _pollTick() {
  pollTimer = null;
  _pollBusy = true;
  try {
    const fresh = await api.poll(PROJECT);
    const ch = mergePoll(fresh) || {};
    patchAllSceneMedia();       // non-destructive image/status patch (keeps prompt/vo textareas intact)
    buildSceneJump();           // recolor scene chips so a finished/approved scene turns green right away
    // Only rebuild the Videos list when a video ACTUALLY changed (finished/approved) — not every tick —
    // and never while the user is typing in a field. This is what stops the periodic scroll stutter / lag.
    const _typing = document.activeElement && /^(TEXTAREA|INPUT|SELECT)$/.test(document.activeElement.tagName);
    if (ch.vid && !_typing) renderVideos();
    renderGenProgress();
  } catch (_) {
    /* transient network blip — just try again on the next tick, never surface it as an error */
  } finally {
    _pollBusy = false;
  }
  if (anyGenerating()) pollTimer = setTimeout(_pollTick, 6000);   // schedule the next only after this one finished
  else setStatus("");
}
function ensurePolling() {
  if (pollTimer || _pollBusy || !anyGenerating()) return;
  pollTimer = setTimeout(_pollTick, 6000);
}

// Dry-run: show the EXACT final image prompt (assembled server-side, same code the real generation uses)
// so the user can catch conflicts before spending a generation. Built with textContent (no innerHTML) so
// prompt text can never break the markup.
async function showPromptPreview(sid) {
  let data = null;
  try { data = await api.previewPrompt(PROJECT, sid); } catch (_) {}
  if (!data) { toast("Could not load the prompt preview.", "err"); return; }
  const ov = document.createElement("div"); ov.className = "pp-overlay";
  const box = document.createElement("div"); box.className = "pp-box";
  const close = () => { ov.remove(); document.removeEventListener("keydown", onEsc); };
  const onEsc = (e) => { if (e.key === "Escape") close(); };

  const head = document.createElement("div"); head.className = "pp-head";
  const title = document.createElement("b");
  title.textContent = `Final image prompt — Scene ${sid}` + (data.raw ? "  ·  RAW mode" : "");
  const x = document.createElement("button"); x.className = "pp-x"; x.textContent = "✕"; x.title = "Close";
  head.appendChild(title); head.appendChild(x);

  const info = document.createElement("div"); info.className = "pp-info";
  (data.info || []).forEach(t => { const s = document.createElement("span"); s.textContent = "• " + t; info.appendChild(s); });

  const ta = document.createElement("textarea"); ta.className = "pp-text"; ta.readOnly = true;
  ta.value = data.prompt || "(this scene has no prompt yet)";

  const actions = document.createElement("div"); actions.className = "pp-actions";
  const copy = document.createElement("button"); copy.className = "pp-copy ghost"; copy.textContent = "Copy";
  const hint = document.createElement("span"); hint.className = "pp-hint"; hint.textContent = "Exactly what Generate Image will send.";
  actions.appendChild(copy); actions.appendChild(hint);

  box.appendChild(head); if ((data.info || []).length) box.appendChild(info); box.appendChild(ta); box.appendChild(actions);
  ov.appendChild(box); document.body.appendChild(ov);

  box.addEventListener("click", e => e.stopPropagation());
  ov.addEventListener("click", close);
  x.addEventListener("click", close);
  copy.addEventListener("click", () => {
    ta.select();
    const done = () => toast("Prompt copied.", "ok");
    if (navigator.clipboard) navigator.clipboard.writeText(ta.value).then(done).catch(() => { document.execCommand("copy"); done(); });
    else { document.execCommand("copy"); done(); }
  });
  document.addEventListener("keydown", onEsc);
}

function lightbox(src, kind) {
  const lb = document.createElement("div");
  lb.className = "lightbox";
  const stage = document.createElement("div");
  stage.className = "lb-stage";
  stage.addEventListener("click", e => e.stopPropagation());
  stage.innerHTML = kind === "img" ? `<img src="${src}">` : `<video src="${src}" controls autoplay>`;
  const ov = document.createElement("div"); ov.className = "img-actions";
  const bClose = document.createElement("button"); bClose.className = "ia lb-close"; bClose.textContent = "✕"; bClose.title = "Close";
  ov.appendChild(bClose); stage.appendChild(ov);
  lb.appendChild(stage);
  const close = () => lb.remove();
  bClose.addEventListener("click", (e) => { e.stopPropagation(); close(); });
  lb.addEventListener("click", close);
  document.body.appendChild(lb);
}

// large image view WITH the same approve/change/remove actions + version arrows
// Play the green approve check-burst inside any positioned container (used by the fullscreen
// lightbox so approving there gets the same feedback as the small card).
function approveBurst(imgEl) {
  // Size/position the burst to the IMAGE itself (not the whole stage, which can be larger than
  // the letterboxed image) so it sits exactly over the picture and never spills out the sides.
  if (!imgEl) return;
  const host = imgEl.offsetParent || imgEl.parentElement;
  if (!host) return;
  const b = document.createElement("div"); b.className = "approve-burst"; b.innerHTML = "<span>✓</span>";
  b.style.left = imgEl.offsetLeft + "px";
  b.style.top = imgEl.offsetTop + "px";
  b.style.width = imgEl.offsetWidth + "px";
  b.style.height = imgEl.offsetHeight + "px";
  host.appendChild(b);
  setTimeout(() => b.remove(), 800);
}

function openImageLightbox(s) {
  if (!(s.image.versions || []).length) return;
  let cur = (s.image.current == null ? s.image.versions.length - 1 : s.image.current);

  const lb = document.createElement("div");
  lb.className = "lightbox";
  const stage = document.createElement("div");
  stage.className = "lb-stage";
  stage.addEventListener("click", e => e.stopPropagation());   // clicks inside never close
  lb.appendChild(stage);

  const imgEl = document.createElement("img");
  stage.appendChild(imgEl);

  // on-screen text overlays on the enlarged image (same styling as the card + preview)
  function drawLbOst() {
    stage.querySelectorAll(".scene-ost").forEach(n => n.remove());
    if (!s.ost_on) return;
    const w = imgEl.getBoundingClientRect().width || imgEl.clientWidth || 800, scale = w / 1920;
    const row = document.querySelector(`.scene-row[data-id="${s.id}"]`);
    (s.overlays || []).forEach((ov, i) => {
      const txt = (ov.onscreen || "").trim(); if (!txt) return;
      const lbOst = document.createElement("div"); lbOst.innerHTML = '<span class="scene-ost-txt"></span>';
      lbOst.className = "scene-ost place-" + (ov.ost_place || "top");
      stage.appendChild(lbOst);
      ostWrapPos(lbOst, ov.ost_place || "top", ov.ost_x, ov.ost_y, scale, ov.ost_rotation);
      const span = lbOst.querySelector(".scene-ost-txt");
      span.textContent = txt;
      ostTextStyle(span, ostOpts(ov), scale);
      const panel = row && row.querySelectorAll(".ost-panel")[i];
      const delBtn = panel && panel.querySelector(".ost-del-overlay");
      ostInteractive(lbOst, ov, scale, stage, {
        sync: (f, v) => { const inp = panel && panel.querySelector(OST_INP[f]); if (inp) inp.value = v; },
        commit: () => { queueSave(); if (row) { const s2 = (DOC.scenes || []).find(x => x.id === s.id); if (s2) drawSceneOst(row, s2); } },
        onDelete: () => { if (delBtn) delBtn.click(); setTimeout(drawLbOst, 360); },   // remove, then redraw the lightbox
      });
    });
  }
  imgEl.addEventListener("load", drawLbOst);
  const onResizeOst = () => drawLbOst();
  window.addEventListener("resize", onResizeOst);

  const ov = document.createElement("div");
  ov.className = "img-actions";
  const bApprove = document.createElement("button"); bApprove.className = "ia approve"; bApprove.textContent = "✓";
  const bChange = document.createElement("button"); bChange.className = "ia change"; bChange.textContent = "↻"; bChange.title = "Change (regenerate)";
  const bClose = document.createElement("button"); bClose.className = "ia lb-close"; bClose.textContent = "✕"; bClose.title = "Close";
  ov.append(bApprove, bChange, bClose);
  stage.appendChild(ov);

  const prev = document.createElement("button"); prev.className = "lb-arrow lb-prev"; prev.innerHTML = CHEV_L; prev.title = "Previous version";
  const next = document.createElement("button"); next.className = "lb-arrow lb-next"; next.innerHTML = CHEV_R; next.title = "Next version";
  const label = document.createElement("div"); label.className = "lb-label";
  stage.append(prev, next, label);

  const startCur = cur;
  const onKey = (e) => {
    if (e.key === "Escape") close();
    else if (e.key === "ArrowLeft") go(-1);
    else if (e.key === "ArrowRight") go(1);
    else if (e.key === "a" || e.key === "A") { e.preventDefault(); bApprove.click(); }   // approve shown version
    else if (e.key === "r" || e.key === "R") { e.preventDefault(); bChange.click(); }     // regenerate
  };
  async function close() {
    document.removeEventListener("keydown", onKey);
    window.removeEventListener("resize", onResizeOst);
    lb.remove();
    // persist the last-viewed version as current (single call, nothing else in flight — no race)
    if (cur !== startCur && cur !== s.image.current) {
      await api.setCurrent(PROJECT, s.id, cur);
      DOC = await api.get(PROJECT); renderScenes(); renderVideos();
    }
  }
  lb.addEventListener("click", close);

  function refresh() {
    const im = s.image, vs = im.versions || [];
    if (!vs.length) { close(); return; }
    cur = Math.min(Math.max(cur, 0), vs.length - 1);
    imgEl.src = mediaUrl(vs[cur], im.taskId);
    const approvedThis = s.approved && im.approved_version === cur;
    bApprove.classList.toggle("on", approvedThis);
    bApprove.title = approvedThis ? "Approved (click to unapprove)" : "Approve this version → Videos";
    label.textContent = `${cur + 1} / ${vs.length}`;
    prev.disabled = cur <= 0;
    next.disabled = cur >= vs.length - 1;
    drawLbOst();                                         // keep the on-screen text overlay in sync
  }
  function syncLocal() { const s2 = (DOC.scenes || []).find(x => x.id === s.id); if (s2) { s.image = s2.image; s.approved = s2.approved; } }

  // arrows are LOCAL only (just change the shown version) — no server call while browsing,
  // so nothing races with approve. Current is persisted once on close.
  function go(delta) {
    const vs = s.image.versions || [];
    const n = Math.min(Math.max(cur + delta, 0), vs.length - 1);
    if (n === cur) return;
    const dir = n > cur ? 1 : -1;
    const newSrc = mediaUrl(vs[n], s.image.taskId);
    cur = n;
    slideSwap(stage, imgEl, dir, newSrc, { commit: refresh });   // slide the new version in (full-screen)
  }
  prev.onclick = e => { e.stopPropagation(); go(-1); };
  next.onclick = e => { e.stopPropagation(); go(1); };
  bApprove.onclick = async e => {
    e.stopPropagation();
    const approvedThis = s.approved && s.image.approved_version === cur;
    // pass the shown version explicitly so THIS version is approved + made current atomically —
    // the small card then shows exactly what was approved.
    if (!approvedThis) { _flashApprove = s.id; approveBurst(imgEl); }   // burst exactly over the image
    DOC = await api.approve(PROJECT, s.id, !approvedThis, cur); syncLocal();
    renderScenes(); renderVideos(); refresh();
    if (!approvedThis) toast(`Approved Image: Scene ${s.id}`, "ok"); else toast(`Unapproved Image: Scene ${s.id}`, "info");
  };
  bChange.onclick = e => { e.stopPropagation(); close(); toast(`Regenerating Image: Scene ${s.id}`, "info"); genImages([s.id]); };
  bClose.onclick = e => { e.stopPropagation(); close(); };

  document.addEventListener("keydown", onKey);
  refresh();
  document.body.appendChild(lb);
}

// ---------- toolbar ----------
$("#homeBtn").addEventListener("click", showHome);
$("#brandHome").addEventListener("click", showHome);
// The project-name button is a project switcher, NOT a home link (Home is the 🏠 button / the logo).
$("#projName").addEventListener("click", async (e) => {
  e.stopPropagation();
  const menu = $("#projMenu");
  const wasOpen = !menu.hidden;
  $$(".model-menu").forEach(m => m.hidden = true);
  if (wasOpen) return;
  const list = await api.projects();
  // Clear AFTER the await (not before): the handler is async, so two quick opens can overlap. Clearing
  // up front let each overlapping call append its own copy → the list stacked duplicates. Clearing here
  // makes clear+append one synchronous block, so the last open wins with exactly one copy.
  menu.innerHTML = "";
  if (!list.length) { const d = document.createElement("div"); d.className = "proj-opt-empty"; d.textContent = "No other projects"; menu.appendChild(d); }
  list.forEach(p => {
    const o = document.createElement("button");
    o.type = "button"; o.className = "proj-opt" + (p.name === PROJECT ? " current" : "");
    o.innerHTML = `<span class="proj-opt-t"></span><span class="proj-opt-meta"></span>`;
    o.querySelector(".proj-opt-t").textContent = p.title;
    o.querySelector(".proj-opt-meta").textContent = `${p.scenes} scene${p.scenes === 1 ? "" : "s"}`;
    o.addEventListener("click", (ev) => { ev.stopPropagation(); menu.hidden = true; if (p.name !== PROJECT) openProject(p.name, p.title); });
    menu.appendChild(o);
  });
  menu.hidden = false;
});
$("#reloadBtn").addEventListener("click", loadDoc);
$("#scrollTopBtn").addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
$("#scrollBottomBtn").addEventListener("click", () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" }));

// ---------- rename project modal ----------
let renameTarget = null;
function openRenameModal(p) {
  renameTarget = p;
  $("#renameInput").value = p.title;
  $("#renameBg").hidden = false;
  const inp = $("#renameInput");
  inp.focus(); inp.select();
}
function closeRenameModal() { $("#renameBg").hidden = true; renameTarget = null; }
async function doRename() {
  if (!renameTarget) return;
  const t = $("#renameInput").value.trim();
  if (!t || t === renameTarget.title) { closeRenameModal(); return; }
  const r = await api.renameProject(renameTarget.name, t);
  if (r.error) { alert(r.error); return; }
  closeRenameModal(); showHome();
}
$("#renameSave").addEventListener("click", doRename);
$("#renameCancel").addEventListener("click", closeRenameModal);
$("#renameBg").addEventListener("click", (e) => { if (e.target === $("#renameBg")) closeRenameModal(); });
$("#renameInput").addEventListener("keydown", (e) => { if (e.key === "Enter") doRename(); else if (e.key === "Escape") closeRenameModal(); });

// ---------- scene notes modal (per-scene notes; persisted in scenes.json) ----------
let _noteScene = null;
function openNoteModal(s) {
  _noteScene = s;
  $("#noteTitle").textContent = `Scene #${s.id} — Notes`;
  $("#noteText").value = s.note || "";
  $("#noteBg").hidden = false;
  setTimeout(() => $("#noteText").focus(), 60);
}
function closeNoteModal() {
  if (_noteScene) {
    const v = $("#noteText").value;
    if ((_noteScene.note || "") !== v) { _noteScene.note = v; queueSave(); }   // save only if changed
    const row = document.querySelector(`#scenesList .scene-row[data-id="${_noteScene.id}"]`);
    const b = row && row.querySelector(".scene-note");
    if (b) b.classList.toggle("has-note", !!(v && v.trim()));
  }
  $("#noteBg").hidden = true; _noteScene = null;
}
$("#noteClose").addEventListener("click", closeNoteModal);
$("#noteBg").addEventListener("click", (e) => { if (e.target === $("#noteBg")) closeNoteModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#noteBg").hidden) closeNoteModal(); });

// ---------- import project modal (from the sync folder) ----------
function closeImportModal() { $("#importBg").hidden = true; }
function closeTrashModal() { $("#trashBg").hidden = true; }
async function openTrashModal() {
  const bg = $("#trashBg"), list = $("#trashList");
  list.innerHTML = `<div class="import-empty">Loading…</div>`;
  bg.hidden = false;
  let items;
  try { items = await api.listTrash(); } catch (e) { items = []; }
  if (!Array.isArray(items) || !items.length) {
    list.innerHTML = `<div class="import-empty">Recycle bin is empty.<br>Projects you “remove from dashboard” land here and can be restored.</div>`;
    return;
  }
  list.innerHTML = "";
  items.forEach((it, idx) => {
    const row = document.createElement("div"); row.className = "import-row";
    row.style.animationDelay = Math.min(idx * 45, 300) + "ms";
    const info = document.createElement("div"); info.className = "import-info";
    const t = document.createElement("div"); t.className = "import-title"; t.textContent = it.title || it.name;
    const meta = document.createElement("div"); meta.className = "import-meta";
    const bits = [];
    if (it.scenes != null) bits.push(`${it.scenes} scenes`);
    if (it.deleted) bits.push("removed " + String(it.deleted).replace("T", " "));
    meta.textContent = bits.join("  ·  ");
    info.append(t, meta);
    // permanently delete from disk
    const del = document.createElement("button"); del.className = "import-del"; del.title = "Delete from disk permanently"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(del, async () => {
      if (!(await confirmDialog(`Permanently delete “${it.title || it.name}” from this computer? This cannot be recovered.`, { title: "Delete From Disk", okText: "Delete Forever" }))) return;
      const r = await api.deleteTrash(it.name);
      if (r.error) { toast("Delete failed: " + r.error, "err"); return; }
      row.style.height = row.offsetHeight + "px"; void row.offsetHeight;
      row.classList.add("removing"); row.style.height = "0px"; row.style.marginBottom = "-8px";
      setTimeout(() => row.remove(), 320);
      toast("Deleted permanently", "ok");
    }); });
    // restore back to the dashboard
    const btn = document.createElement("button"); btn.className = "import-btn import-restore";
    btn.innerHTML = `<span>Restore</span>`;
    btn.addEventListener("click", () => withBusy(btn, async () => {
      const r = await api.restoreTrash(it.name);
      if (r.error) { toast("Restore failed: " + r.error, "err"); return; }
      closeTrashModal();
      toast(`✓ Restored — “${r.title}”`, "ok", 5000);
      await showHome();
    }));
    row.append(info, del, btn);
    list.appendChild(row);
  });
}
function _impSize(b) {
  if (b >= 1e9) return (b / 1e9).toFixed(1) + " GB";
  if (b >= 1e6) return Math.round(b / 1e6) + " MB";
  if (b >= 1e3) return Math.round(b / 1e3) + " KB";
  return b + " B";
}
async function openImportModal() {
  const bg = $("#importBg"), list = $("#importList");
  list.innerHTML = `<div class="import-empty">Loading…</div>`;
  bg.hidden = false;
  let res;
  try { res = await api.listImports(); } catch (e) { res = { sync_ok: false, items: [] }; }
  if (!res.sync_ok) {
    list.innerHTML = `<div class="import-empty">No sync folder set (or it wasn't found).<br>Pick a folder under Settings → 🔑 API Keys.</div>`;
    return;
  }
  if (!res.items.length) {
    list.innerHTML = `<div class="import-empty">No exported projects in the sync folder.<br>Export a project on another PC and it will appear here.</div>`;
    return;
  }
  const existing = new Set();                 // detect name clashes → offer Update (overwrite)
  try { (await api.projects()).forEach(p => existing.add(p.name)); } catch (e) {}
  list.innerHTML = "";
  res.items.forEach((it, idx) => {
    const clash = existing.has(it.name);
    const row = document.createElement("div"); row.className = "import-row";
    row.style.animationDelay = Math.min(idx * 45, 300) + "ms";
    const info = document.createElement("div"); info.className = "import-info";
    const t = document.createElement("div"); t.className = "import-title"; t.textContent = it.title || it.name;
    if (clash) { const tag = document.createElement("span"); tag.className = "import-tag"; tag.textContent = "in this account"; t.appendChild(tag); }
    const meta = document.createElement("div"); meta.className = "import-meta";
    const bits = [];
    if (it.scenes != null) bits.push(`${it.scenes} scenes`);
    if (it.exported_by) bits.push(`by ${it.exported_by}`);
    if (it.size) bits.push(_impSize(it.size));
    if (it.exported_at) bits.push(String(it.exported_at).replace("T", " "));
    meta.textContent = bits.join("  ·  ");
    info.append(t, meta);
    // delete this export from the sync folder
    const del = document.createElement("button"); del.className = "import-del"; del.title = "Delete this export"; del.innerHTML = TRASH_SVG;
    del.addEventListener("click", (ev) => { ev.stopPropagation(); withBusy(del, async () => {
      if (!(await confirmDialog(`Delete the export “${it.title || it.name}” from the sync folder? This does not affect any imported project.`, { title: "Delete Export", okText: "Delete" }))) return;
      const r = await api.deleteImport(it.file);
      if (r.error) { toast("Delete failed: " + r.error, "err"); return; }
      row.style.height = row.offsetHeight + "px"; void row.offsetHeight;
      row.classList.add("removing"); row.style.height = "0px"; row.style.marginBottom = "-8px";
      setTimeout(() => row.remove(), 320);
      toast("Export deleted", "ok");
    }); });
    // import (or update, if a same-named project already exists here)
    const btn = document.createElement("button"); btn.className = "import-btn" + (clash ? " import-update" : "");
    btn.innerHTML = `${IMPORT_SVG}<span>${clash ? "Update" : "Import"}</span>`;
    btn.addEventListener("click", () => withBusy(btn, async () => {
      const msg = clash
        ? `A project named “${it.title || it.name}” already exists in this account. Replace it with the imported version? Your current copy will be overwritten.`
        : `Import “${it.title || it.name}” into this account?`;
      if (!(await confirmDialog(msg, { title: clash ? "Update Project" : "Import Project", okText: clash ? "Overwrite" : "Import" }))) return;
      const r = await api.importProject(it.file, clash);
      if (r.error) { toast("Import failed: " + r.error, "err"); return; }
      closeImportModal();
      toast(clash ? `✓ Updated — “${r.title}” replaced in this account` : `✓ Import complete — “${r.title}” added to this account`, "ok", 5000);
      await showHome();   // refresh the project list so the imported project shows up right away
    }));
    row.append(info, del, btn);
    list.appendChild(row);
  });
}
// ---------- export progress (bottom-right card, polled) ----------
function showExportProgress(title) {
  let el = document.getElementById("expProg");
  if (!el) {
    el = document.createElement("div"); el.id = "expProg"; el.className = "exp-prog";
    el.innerHTML = `<div class="exp-prog-top"><span class="exp-prog-title"></span><span class="exp-prog-pct">0%</span></div><div class="exp-prog-bar"><i></i></div>`;
    document.body.appendChild(el);
  }
  el.querySelector(".exp-prog-title").textContent = "Exporting " + title + "…";
  const bar = el.querySelector(".exp-prog-bar i"), pct = el.querySelector(".exp-prog-pct");
  requestAnimationFrame(() => el.classList.add("show"));
  return {
    set(p) { p = Math.max(0, Math.min(100, p | 0)); pct.textContent = p + "%"; bar.style.width = p + "%"; },
    close() { el.classList.remove("show"); setTimeout(() => { try { el.remove(); } catch (e) {} }, 320); },
  };
}
function pollExport(job, title) {
  const prog = showExportProgress(title);
  return new Promise(resolve => {
    const iv = setInterval(async () => {
      let s; try { s = await api.exportStatus(job); } catch (e) { return; }
      if (s.error === "not-found") { clearInterval(iv); prog.close(); toast("Export failed: job lost", "err"); resolve(); return; }
      prog.set(s.pct || 0);
      if (s.done) {
        clearInterval(iv);
        prog.close();
        if (s.error) toast("Export failed: " + s.error, "err");
        else toast(`✓ Export complete — “${title}” saved to the sync folder`, "ok", 5000);
        resolve();
      }
    }, 350);
  });
}
async function saveSyncDir(v) { try { await api.setConfig({ sync_dir: v }); } catch (e) {} }
$("#importClose").addEventListener("click", closeImportModal);
$("#importBg").addEventListener("click", (e) => { if (e.target === $("#importBg")) closeImportModal(); });
$("#trashClose").addEventListener("click", closeTrashModal);
$("#trashBg").addEventListener("click", (e) => { if (e.target === $("#trashBg")) closeTrashModal(); });

// ---------- audience modal (collapsible dropdowns) ----------
const AUD_FIELDS = [
  { key: "locations", label: "Location", multi: false, options: [{ v: "United States" }, { v: "United Kingdom" }, { v: "France" }, { v: "Germany" }] },
  { key: "currencies", label: "Currency", multi: false, options: [{ v: "Dollar", ic: "$" }, { v: "Pound", ic: "£" }, { v: "Euro", ic: "€" }] },
  { key: "ages", label: "Age Range", multi: true, options: [{ v: "25-44" }, { v: "45-65" }, { v: "50-80" }] },
  { key: "genders", label: "Gender", multi: true, options: [{ v: "Female" }, { v: "Male" }] },
  { key: "appearance", label: "Appearance to exclude", multi: true,
    hint: "Types you do NOT want to appear in the VSL. Selected looks are avoided; everything else stays unrestricted.",
    groups: [
      { name: "Ethnicity / skin", options: [{ v: "Asian" }, { v: "Black-skinned" }, { v: "White-skinned" }, { v: "Indian" }, { v: "Hispanic / Latino" }, { v: "Middle Eastern / Arab" }] },
      { name: "Hair", options: [{ v: "Blonde" }, { v: "Redhead" }, { v: "Orange hair" }, { v: "Brunette" }, { v: "Black hair" }, { v: "Gray / white hair" }] },
    ] },
];
let modalMode = "new";
let selAud = {};
function renderAudFields() {
  const box = $("#audFields");
  box.innerHTML = "";
  AUD_FIELDS.forEach(f => {
    const dd = document.createElement("div");
    dd.className = "dd";
    const head = document.createElement("button");
    head.type = "button"; head.className = "dd-head";
    head.innerHTML = `<span class="dd-title"></span><span class="dd-summary"></span><span class="dd-caret">▾</span>`;
    head.querySelector(".dd-title").textContent = f.label;
    const sumEl = head.querySelector(".dd-summary");
    const updateSum = () => { sumEl.textContent = (selAud[f.key] || []).join(", "); };
    updateSum();
    head.addEventListener("click", () => dd.classList.toggle("open"));
    const body = document.createElement("div");
    body.className = "dd-body";
    const inner = document.createElement("div");   // grid-rows wrapper animates 0fr<->1fr; inner clips
    inner.className = "dd-inner";
    body.appendChild(inner);
    if (f.hint) {
      const h = document.createElement("div");
      h.className = "dd-hint"; h.textContent = f.hint;
      inner.appendChild(h);
    }
    const makeOpt = (o, container) => {
      const opt = document.createElement("div");
      opt.className = "opt" + ((selAud[f.key] || []).includes(o.v) ? " sel" : "");
      opt.innerHTML = (o.ic ? `<span class="ic">${o.ic}</span>` : "") + `<span class="lbl"></span>`;
      opt.querySelector(".lbl").textContent = o.v;
      opt.addEventListener("click", () => {
        let cur = selAud[f.key] || [];
        if (f.multi) {
          cur = cur.includes(o.v) ? cur.filter(x => x !== o.v) : [...cur, o.v];
        } else {
          cur = cur.includes(o.v) ? [] : [o.v];
          [...body.querySelectorAll(".opt")].forEach(c => c.classList.remove("sel"));
        }
        selAud[f.key] = cur;
        opt.classList.toggle("sel", cur.includes(o.v));
        updateSum();
      });
      container.appendChild(opt);
    };
    if (f.groups) {
      f.groups.forEach(g => {
        const grp = document.createElement("div");
        grp.className = "opt-group";
        const lbl = document.createElement("div");
        lbl.className = "opt-group-label"; lbl.textContent = g.name;
        const grid = document.createElement("div");
        grid.className = "opt-grid";
        g.options.forEach(o => makeOpt(o, grid));
        grp.appendChild(lbl); grp.appendChild(grid);
        inner.appendChild(grp);
      });
    } else {
      f.options.forEach(o => makeOpt(o, inner));
    }
    dd.appendChild(head); dd.appendChild(body);
    box.appendChild(dd);
  });

  // Cast / Characters — its own modal tab now, rendered directly (no dropdown, room to breathe)
  const castBox = $("#castFields");
  castBox.innerHTML = "";
  castSummaryEl = null;
  renderCastBody(castBox);
}

// ---- Product tab: one project-level product image, attached (i2i) to scenes you flag 📦 Product ----
function renderProductPanel() {
  const panel = $("#productPanel"); if (!panel) return;
  panel.innerHTML = "";
  const hint = document.createElement("p"); hint.className = "cast-hint";
  hint.textContent = PROJECT
    ? "Upload your product image (bottle / package). Then on any scene, turn on 📦 Product to place THIS exact product into that shot — kept label-accurate. A clean product photo on a plain background works best."
    : "Open a project first — the product image is stored per project.";
  panel.appendChild(hint);
  if (!PROJECT) return;
  const urls = ((DOC && DOC.product && DOC.product.urls) || []);
  const names = ((DOC && DOC.product && DOC.product.names) || {});
  const grid = document.createElement("div"); grid.className = "cast-img-grid product-grid";
  urls.forEach((u, i) => {
    const cell = document.createElement("div"); cell.className = "product-cell";
    const thumb = document.createElement("div"); thumb.className = "cast-thumb";
    const im = document.createElement("img"); im.alt = ""; setRefImg(im, u);
    const x = document.createElement("button"); x.type = "button"; x.className = "cast-thumb-x"; x.textContent = "×"; x.title = "Remove product image";
    x.addEventListener("click", async () => {
      const r = await api.removeProduct(PROJECT, u);
      if (r.error) { alert(r.error); return; }
      DOC.product = { urls: r.urls || [], names: r.names || {} }; renderProductPanel(); refreshAllSceneCast();
    });
    thumb.append(im, x);
    // editable label — this is what the per-scene Product dropdown shows, so name it by pack ("3 bottle")
    const lab = document.createElement("input"); lab.className = "product-label"; lab.type = "text";
    lab.value = names[u] || ""; lab.placeholder = `Product ${i + 1}`; lab.title = "Name this pack (e.g. 1 bottle, 3 bottle)";
    const commit = async () => {
      const nv = lab.value.trim();
      if (nv === (names[u] || "")) return;
      const r = await api.renameProduct(PROJECT, u, nv);
      if (r.error) { alert(r.error); return; }
      DOC.product = { urls: r.urls || [], names: r.names || {} }; refreshAllSceneCast();
    };
    lab.addEventListener("blur", commit);
    lab.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); lab.blur(); } });
    cell.append(thumb, lab); grid.appendChild(cell);
  });
  const add = document.createElement("label"); add.className = "product-add"; add.title = "Upload your product image";
  add.innerHTML = "<span class='pa-plus'>＋</span><span class='pa-txt'>Upload product</span>";
  const addI = document.createElement("input"); addI.type = "file"; addI.accept = "image/*"; addI.multiple = true; addI.hidden = true;
  addI.addEventListener("change", async e => {
    const fs = [...e.target.files]; if (!fs.length) return;
    const r = await api.addProduct(PROJECT, fs);
    if (r.error) { alert(r.error); return; }
    DOC.product = { urls: r.urls || [], names: r.names || {} }; renderProductPanel(); refreshAllSceneCast();
  });
  add.appendChild(addI); grid.appendChild(add);
  panel.appendChild(grid);
}

// ---- API keys tab (a new user can plug in their own Kie / Cloudinary / ElevenLabs keys) ----
async function renderKeysPanel() {
  const panel = $("#keysPanel");
  panel.innerHTML = "";
  const hint = document.createElement("p");
  hint.className = "hint keys-hint";
  hint.textContent = PROJECT
    ? "These keys belong to THIS project — they travel with it on export/import. Applied right away when you Save."
    : "Open a project first — API keys are set per project now.";
  panel.appendChild(hint);
  const FIELDS = [
    { key: "cloud_name", label: "Cloudinary — Cloud name", ph: "e.g. kgcv41gb", secret: false },
    { key: "cloud_key", label: "Cloudinary — API Key", ph: "", secret: true },
    { key: "cloud_secret", label: "Cloudinary — API Secret", ph: "", secret: true },
    { key: "kie", label: "Kie.ai — API Key", ph: "", secret: true },
    { key: "elevenlabs", label: "ElevenLabs — API Key", ph: "", secret: true },
  ];
  let cur = {};
  if (PROJECT) { try { cur = await api.getKeys(PROJECT); } catch (e) {} }
  const inputs = {};
  FIELDS.forEach(f => {
    const wrap = document.createElement("label"); wrap.className = "field key-field";
    const span = document.createElement("span"); span.textContent = f.label;
    const row = document.createElement("div"); row.className = "key-input-row";
    const inp = document.createElement("input");
    inp.type = f.secret ? "password" : "text"; inp.className = "key-input"; inp.dataset.keyField = f.key;
    inp.value = cur[f.key] || ""; inp.placeholder = f.ph; inp.autocomplete = "off"; inp.spellcheck = false;
    row.appendChild(inp);
    if (f.secret) {
      const eye = document.createElement("button"); eye.type = "button"; eye.className = "key-eye"; eye.title = "Show / hide"; eye.textContent = "👁";
      eye.addEventListener("click", () => { const s = inp.type === "password"; inp.type = s ? "text" : "password"; eye.classList.toggle("on", s); });
      row.appendChild(eye);
    }
    wrap.append(span, row); panel.appendChild(wrap);
    inputs[f.key] = inp;
  });
  // --- project transfer: the sync folder (Google Drive / OneDrive / Dropbox desktop folder) ---
  const sep = document.createElement("div"); sep.className = "keys-sep"; panel.appendChild(sep);
  const sh = document.createElement("p"); sh.className = "hint keys-hint";
  sh.innerHTML = "<b>Project transfer — Sync folder.</b> To move projects to another PC, pick a cloud-synced folder (Google Drive / OneDrive / Dropbox desktop folder). Exported projects are written here as <b>.zip</b>; on the other PC they appear under <b>Import</b>.";
  panel.appendChild(sh);
  const sf = document.createElement("label"); sf.className = "field key-field";
  const sfs = document.createElement("span"); sfs.textContent = "Sync folder";
  const sfr = document.createElement("div"); sfr.className = "key-input-row";
  const sfi = document.createElement("input");
  sfi.type = "text"; sfi.id = "syncDirInput"; sfi.className = "key-input";
  sfi.placeholder = "e.g. G:\\My Drive\\VSL-Exports"; sfi.autocomplete = "off"; sfi.spellcheck = false;
  let cfg = {}; try { cfg = await api.getConfig(); } catch (e) {}
  sfi.value = cfg.sync_dir || "";
  sfr.appendChild(sfi);
  if (window.pywebview && window.pywebview.api && window.pywebview.api.pick_folder) {
    const pick = document.createElement("button");
    pick.type = "button"; pick.className = "key-eye sync-pick"; pick.title = "Choose folder"; pick.textContent = "📁";
    pick.addEventListener("click", async () => {
      try {
        const r = await window.pywebview.api.pick_folder();
        if (r && r.ok && r.path) { sfi.value = r.path; await saveSyncDir(r.path); toast("Sync folder saved", "ok"); }
      } catch (e) {}
    });
    sfr.appendChild(pick);
  }
  sf.append(sfs, sfr); panel.appendChild(sf);
  sfi.addEventListener("change", () => saveSyncDir(sfi.value.trim()));
}
// Collect the API-keys tab inputs so the modal's main Save can persist them alongside the audience.
function collectKeys() {
  const body = {};
  $$("#keysPanel .key-input").forEach(inp => { if (inp.dataset.keyField) body[inp.dataset.keyField] = inp.value.trim(); });
  return body;
}
// modal tab switching (API Keys / Target Audience / Cast) — smoothly morph the body height so the
// modal stretches/shrinks instead of snapping between tab sizes.
function setModalTab(name, animate = true) {
  const body = document.querySelector(".mtab-body");
  const swap = () => {
    $$(".mtab").forEach(t => t.classList.toggle("active", t.dataset.mtab === name));
    $$(".mtab-panel").forEach(p => p.classList.toggle("active", p.dataset.mtabp === name));
  };
  if (!animate || !body || !body.offsetParent) { swap(); return; }   // no animation on first open (modal still hidden)
  const oldH = body.getBoundingClientRect().height;
  swap();
  body.style.height = "auto";
  const cap = Math.max(120, window.innerHeight - 220);   // never exceed the modal's scroll cap
  const newH = Math.min(body.scrollHeight, cap);
  if (Math.abs(newH - oldH) < 2) { body.style.height = ""; return; }
  body.style.height = oldH + "px"; body.style.overflow = "hidden";
  void body.offsetHeight;                                 // reflow so the transition runs
  body.style.transition = "height .3s cubic-bezier(.33,1,.68,1)";
  body.style.height = newH + "px";
  clearTimeout(body._tabAnim);
  body._tabAnim = setTimeout(() => { body.style.transition = ""; body.style.height = ""; body.style.overflow = ""; }, 320);
}
$$(".mtab").forEach(t => t.addEventListener("click", () => setModalTab(t.dataset.mtab)));
function openModal(mode) {
  modalMode = mode;
  pendingCast.forEach(c => { try { URL.revokeObjectURL(c.previewUrl); } catch (e) {} });
  pendingCast = [];                    // fresh staged-character list each time the modal opens
  const aud = (mode === "edit" && DOC) ? (DOC.audience || {}) : {};
  selAud = {
    locations: aud.locations || [], currencies: aud.currencies || [],
    ages: aud.ages || [], genders: aud.genders || [], appearance: aud.appearance || [],
  };
  $("#modalTitle").textContent = mode === "edit" ? "Settings" : "New Project";
  $("#mNameField").style.display = mode === "edit" ? "none" : "block";
  $("#mName").value = "";
  $("#mBrief").value = (mode === "edit" && DOC) ? (DOC.brief || "") : "";   // project brief/context
  $("#mSave").textContent = mode === "edit" ? "Save" : "Create Project";
  renderAudFields();
  renderKeysPanel();               // fills the API-keys tab (async; ready by the time it's opened)
  renderProductPanel();            // fills the Product tab
  // Cast + Product only make sense once the project EXISTS (Analyze/Settings) — hide them in New Project.
  const isNew = mode === "new";
  const castTab = document.querySelector('.mtab[data-mtab="cast"]'); if (castTab) castTab.hidden = isNew;
  const prodTab = document.querySelector('.mtab[data-mtab="product"]'); if (prodTab) prodTab.hidden = isNew;
  setModalTab("audience", false);  // always land on Target Audience (no morph on open); Keys tab is one click away
  $("#modalBg").hidden = false;
}
$("#audienceBtn").addEventListener("click", () => { if (!PROJECT) { alert("Open a project first."); return; } openModal("edit"); });
$("#mCancel").addEventListener("click", () => { $("#modalBg").hidden = true; });
$("#modalBg").addEventListener("click", (e) => { if (e.target === $("#modalBg")) $("#modalBg").hidden = true; });
$("#mSave").addEventListener("click", async (e) => {
  const aud = { ...selAud };
  const btn = e.currentTarget;
  if (modalMode === "new") {
    const nameEl = $("#mName"), name = nameEl.value.trim();
    if (!name) { flagInvalid(nameEl); return; }                 // themed inline validation (no popup)
    if (!(await confirmDialog(`Create the project “${name}”?`, { title: "Create Project", okText: "Create", danger: false }))) return;
  }
  await withBusy(btn, async () => {
    const keys = collectKeys();   // API keys are now PER PROJECT — saved to the relevant project below
    if (modalMode === "new") {
      const r = await api.createProject($("#mName").value.trim(), aud, $("#mBrief").value);
      if (r.error) { toast(r.error, "err"); return; }
      if (Object.keys(keys).length) { const kr = await api.setKeys(r.name, keys); if (kr && kr.error) toast(kr.error, "err"); }
      // upload any characters staged in the browser into the freshly-created project (each may have several images)
      for (const pc of pendingCast) { try { await api.addCharacter(r.name, pc.name, pc.files); } catch (err) {} }
      pendingCast.forEach(c => (c.previewUrls || []).forEach(u => { try { URL.revokeObjectURL(u); } catch (err) {} }));
      pendingCast = [];
      $("#modalBg").hidden = true;
      await openProject(r.name);
    } else {
      if (PROJECT && Object.keys(keys).length) { const kr = await api.setKeys(PROJECT, keys); if (kr && kr.error) toast(kr.error, "err"); }
      DOC.audience = aud; DOC.brief = $("#mBrief").value; await api.save(PROJECT, DOC);
      $("#modalBg").hidden = true;
      setStatus("saved"); setTimeout(() => setStatus(""), 1200);
    }
  });
});
$("#translateAllBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (!DOC?.scenes.length) return;
  if (!(await confirmDialog("Translate ALL sentences to Turkish? This overwrites existing translations.", { title: "Translate All Sentences", okText: "Translate", danger: false }))) return;
  await withBusy(btn, async () => {
    setStatus("translating to Turkish…");
    await translateAllScenes();
    setStatus("");
    toast("All sentences translated to Turkish", "ok");
  });
});
$("#genAllPromptsBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!DOC?.scenes.length) return;
  if (!(await confirmDialog("Generate image prompts for ALL scenes? This overwrites any existing prompts.", { title: "Generate All Prompts", okText: "Generate", danger: false }))) return;
  stoppable(btn, (sig) => genPrompts("all", sig));
});
// Re-run the whole-script director: fixes scenes whose prompt is empty or just the raw voice-over line
// (the old silent-fallback damage), while leaving any prompt you wrote yourself untouched.
const _redirectBtn = $("#redirectBtn");
if (_redirectBtn) _redirectBtn.addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!PROJECT || !DOC?.scenes.length) { alert("Split the script into scenes first."); return; }
  if (!(await confirmDialog("Re-run the director over all scenes? It rewrites prompts that are empty or just the raw voice-over line, and keeps any prompt you've written yourself.", { title: "Re-run Director", okText: "Re-run", danger: false }))) return;
  await stoppable(btn, async (sig) => {
    setStatus("re-running director…");
    const r = await api.redirect(PROJECT, sig);
    if (r.error) { toastErr(r.error); setStatus(""); return; }
    const script = DOC.script;
    DOC = await api.get(PROJECT); if (script) DOC.script = script;
    renderScenes(); updateSplitBtn();
    setStatus("");
    if (r.note) toast(r.note, "info");   // which model actually ran (Fable 5 / Opus 4.8)
    const msg = `Director re-run: ${r.fixed} prompt(s) rewritten` + (r.kept ? `, ${r.kept} kept as-is` : "");
    if (r.failed && r.failed.length) toast(`${msg}. Still empty on scene(s): ${r.failed.join(", ")} — try again, or Generate those.`, "err");
    else toast(`${msg}.`, "ok");
  });
});
$("#genAllImagesBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  const ids = DOC.scenes.filter(s => s.prompt && s.image.status !== "ready").map(s => s.id);
  if (!ids.length) { alert("No scenes with a prompt and no image yet."); return; }
  if (!(await confirmDialog(`Generate images for ${ids.length} scene(s)?`, { title: "Generate All Images", okText: "Generate", danger: false }))) return;
  withBusy(btn, () => genImages(ids));
});
$("#dlAllImagesBtn").addEventListener("click", async () => {
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.approved && s.image.file).length;
  if (!n) { alert("No approved images to download. Approve images first."); return; }
  if (!(await confirmDialog(`Download all ${n} approved image(s) as a zip?`, { title: "Download All Images", okText: "Download", danger: false }))) return;
  downloadUrl(`/api/download/${PROJECT}/images`, `${PROJECT}_images.zip`);
});
$("#genAllVideoPromptsBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (btn._stopCtl) { btn._stopCtl.abort(); return; }   // running → Stop
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).length;
  if (!n) { alert("No approved images here yet. Approve images in the Scenes tab first."); return; }
  if (!(await confirmDialog("Generate video prompts for ALL scenes? This overwrites any existing video prompts.", { title: "Generate All Prompts", okText: "Generate", danger: false }))) return;
  stoppable(btn, (sig) => genVideoPrompts("all", sig));
});
$("#genAllVideosBtn").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.approved && (s.image.approved_file || s.image.file)).length;
  if (!n) { alert("No approved images to convert. Approve images in the Scenes tab first."); return; }
  if (!(await confirmDialog(`Convert all ${n} approved image(s) to video?`, { title: "Generate All Videos", okText: "Convert", danger: false }))) return;
  withBusy(btn, () => genVideos("all"));
});
$("#dlAllVideosBtn").addEventListener("click", async () => {
  if (!PROJECT) return;
  const n = (DOC?.scenes || []).filter(s => s.video.approved && s.video.status === "ready" && s.video.file).length;
  if (!n) { alert("No approved videos to download. Approve videos first (✓ on the video)."); return; }
  if (!(await confirmDialog(`Download all ${n} approved video(s) as a zip?`, { title: "Download All Videos", okText: "Download", danger: false }))) return;
  downloadUrl(`/api/download/${PROJECT}/videos`, `${PROJECT}_videos.zip`);
});
// Export tab: individual file downloads (Script / Voiceover / Subtitle / Images / Videos) — the
// Premiere button also has .dl-btn but no data-dl, so exclude it here (it has its own handler).
$$(".dl-btn[data-dl]").forEach(b => b.addEventListener("click", () => {
  if (!PROJECT) return;
  downloadUrl(`/api/download/${PROJECT}/${b.dataset.dl}`, `${PROJECT}_${b.dataset.dl}`);
}));
// Export tab: one ZIP with everything (with a confirm + a content summary afterwards)
function renderExportInfo(box, i, name) {
  const secs = Math.round(i.duration_sec || 0);
  const dur = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}`;
  const musicCount = (i.music || []).filter(m => m.track).length;
  const warns = (i.warnings || []).map(w => `<li class="warn-txt">⚠ ${w}</li>`).join("");
  box.className = "export-result ok";
  box.innerHTML =
    `<div class="export-ok-head">✓ Downloaded <b>${name || ""}</b></div>` +
    `<p class="hint export-summary">Duration ${dur} · ${i.scenes} scenes · ${i.dl_image ?? i.used_image ?? 0} images · ${i.dl_video ?? i.used_video ?? 0} videos</p>` +
    `<p class="hint export-summary">Includes: Premiere project, subtitle, voice-over, script, ` +
      `${musicCount} background music track${musicCount === 1 ? "" : "s"}</p>` +
    (warns ? `<ul class="export-warns">${warns}</ul>` : "");
}
$("#downloadAllBtn").addEventListener("click", async (e) => {
  if (!PROJECT) return;
  const btn = e.currentTarget;   // capture BEFORE the await — e.currentTarget is null afterwards
  if (!(await confirmDialog("Download the ENTIRE project as one .zip — Premiere .xml, subtitle, voice-over, script, all clips and the background music?", { title: "Download All Files", okText: "Download", danger: false }))) return;
  const box = $("#exportResult");
  box.hidden = false; box.className = "export-result";
  box.innerHTML = '<span class="sub-spin"></span> Assembling everything (timeline, choosing music, zipping)…';
  withBusy(btn, async () => {
    // Desktop window: stream the generated zip straight to a Save-As location (the summary comes
    // back in the X-Export-Info header, so the export card still fills in).
    if (window.pywebview && window.pywebview.api && window.pywebview.api.save_download) {
      const r = await window.pywebview.api.save_download(`/api/download/${PROJECT}/all`, document.cookie, `${PROJECT}.zip`);
      if (r && r.ok) {
        let info = {}; try { info = JSON.parse(decodeURIComponent(r.info || "")); } catch (e) {}
        renderExportInfo(box, info, (r.path || "").split(/[\\/]/).pop() || "download.zip");
        toast("Saved: " + r.path, "ok");
      } else if (r && r.cancelled) { box.hidden = true; }
      else { box.className = "export-result err"; box.textContent = "Download failed: " + ((r && r.error) || ""); }
      return;
    }
    let resp;
    try { resp = await fetch(`/api/download/${PROJECT}/all`); }
    catch (err) { box.className = "export-result err"; box.textContent = "Download failed: " + err; return; }
    if (!resp.ok) { let m = "Download failed"; try { m = (await resp.json()).error || m; } catch (e) {} box.className = "export-result err"; box.textContent = m; return; }
    const blob = await resp.blob();
    let info = {}; try { info = JSON.parse(decodeURIComponent(resp.headers.get("X-Export-Info") || "")); } catch (e) {}
    const cd = resp.headers.get("Content-Disposition") || "";
    const mm = cd.match(/filename\*?=(?:UTF-8''|")?([^";]+)/);
    const name = mm ? decodeURIComponent(mm[1].replace(/"$/, "")) : "download.zip";
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
    renderExportInfo(box, info, name);
  });
});

// ---------- rough-cut preview player (images/videos + VO + music + captions, synced) ----------
const PV = { m: null, raf: 0, scene: -1, seg: -1, cap: -1, vidSrc: "", imagesOnly: false, ostEls: [] };
const EMO_COLORS = { DOCUMENTARY:"#4a7a8c", EMOTIONAL:"#b5789f", FEAR:"#a85a5a", INSPIRING:"#d0a24a",
                     SCIENTIFIC:"#5a8ac0", SUSPENSE:"#7a6ab0", TESTIMONIAL:"#57b06a" };
const pvFmt = s => { s = Math.max(0, s | 0); return `${(s/60)|0}:${String(s%60).padStart(2,"0")}`; };
const pvIdx = (arr, t) => { for (let i=0;i<arr.length;i++) if (t>=arr[i].start && t<arr[i].end) return i; return -1; };

// restore=true: a silent reload restore. Fetch the manifest and, ONLY if it's byte-identical to the
// one from the last explicit build (nothing changed → media already cached), re-show the preview
// instantly (no re-buffer). If anything changed, stay blank so the user re-builds deliberately.
async function buildPreview(e, restore) {
  if (!PROJECT) return;
  const btn = e && e.currentTarget, st = $("#previewStatus");
  const key = "pvPreview_" + PROJECT;
  if (!restore) { st.hidden = false; st.className = "pv-status"; st.innerHTML = '<span class="sub-spin"></span> Building preview (choosing music, syncing)…'; }
  const run = async () => {
    let r;
    try { r = await fetch(`/api/preview/${PROJECT}`); }
    catch (err) { if (!restore) { st.className = "pv-status err"; st.textContent = "Preview failed: " + err; } return; }
    if (!r.ok) { if (!restore) { let m = "Preview failed"; try { m = (await r.json()).error || m; } catch (e) {} st.className = "pv-status err"; st.textContent = m; } return; }
    const m = await r.json();
    if (!m.scenes || !m.scenes.length) { if (!restore) { st.className = "pv-status err"; st.textContent = "Nothing to preview yet — approve some images or videos first."; } return; }
    const sig = JSON.stringify(m);
    if (restore) {
      let cached = null; try { cached = localStorage.getItem(key); } catch (e) {}
      if (cached !== sig) return;          // content changed since the last build → require a manual re-build
      await initPreview(m, false);         // unchanged → instant restore, no media-gate (media is browser-cached)
      return;
    }
    st.innerHTML = '<span class="sub-spin"></span> Getting everything ready…';   // spinner stays up until all media is buffered
    await initPreview(m, true);
    try { localStorage.setItem(key, sig); } catch (e) {}   // remember this exact preview so a later reload can restore it
    st.hidden = true;
  };
  if (restore) await run(); else await withBusy(btn, run);
}

// Preload + DECODE every scene image, BUFFER every video, the voice-over and the first music track,
// and RESOLVE only once they're actually playable — so revealing the player means "ready to play".
// KEEPING a ref to each decoded Image is CRITICAL: otherwise it is GC'd, its bitmap dropped, and the
// next scene swap shows the stale (un-zoomed) frame for a beat → the "snaps back then jumps" glitch.
// Each wait is capped so one slow/broken asset can't hang the preview forever.
function pvPreloadAll(m, wait) {
  if (wait === undefined) wait = true;
  PV.preloadImgs = []; PV.preloadVids = [];
  const status = $("#previewStatus");
  const cap = (p, ms) => Promise.race([p, new Promise(r => setTimeout(r, ms))]);
  const mediaReady = (el, ms) => cap(new Promise(res => {
    if (el.readyState >= 3) return res();
    el.addEventListener("canplaythrough", res, { once: true });
    el.addEventListener("error", res, { once: true });
  }), ms);
  const waits = [];
  m.scenes.forEach(sc => {
    const src = sc.img || (sc.type === "image" ? sc.url : null);
    if (src) { const im = new Image(); im.src = src; PV.preloadImgs.push(im); waits.push(cap(im.decode ? im.decode().catch(() => {}) : Promise.resolve(), 6000)); }
    if (sc.type === "video" && sc.url) { const v = document.createElement("video"); v.preload = "auto"; v.muted = true; v.src = sc.url; PV.preloadVids.push(v); v.load(); waits.push(mediaReady(v, 15000)); }
  });
  if (m.vo) { const vo = $("#pvVo"); vo.load(); waits.push(mediaReady(vo, 15000)); }   // voice-over
  const g0 = (m.music || [])[0];                                                        // first audible music track (slot 0)
  if (g0 && g0.url) { const el = pvMusicEls()[0]; if (el) { el.src = g0.url; el.dataset.src = g0.url; el.loop = true; el.volume = 0; el.load(); waits.push(mediaReady(el, 12000)); } }
  if (!wait) return Promise.resolve();   // restore mode: refs/srcs are set + decoding/buffering in the background; don't block
  const total = waits.length; let done = 0;
  waits.forEach(w => w.then(() => { done++; if (status && !status.hidden) status.innerHTML = `<span class="sub-spin"></span> Getting everything ready… ${done}/${total}`; }));
  return Promise.all(waits);
}
async function initPreview(m, block) {
  if (block === undefined) block = true;
  PV.m = m; PV.scene = -1; PV.seg = -1; PV.cap = -1; PV.vidSrc = ""; PV.vidCur = 0;
  [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) { v._pvSrc = ""; v.hidden = true; } });   // reset the two video buffers
  $("#pvVo").src = m.vo; pvMusicEls().forEach(el => { el.removeAttribute("src"); el.removeAttribute("data-src"); el.volume = 0; });
  const segs = $("#pvSegs"), ticks = $("#pvTicks");
  segs.innerHTML = ""; ticks.innerHTML = "";
  (m.music || []).forEach((g, i) => {
    const band = document.createElement("div");
    band.className = "pv-seg"; band.dataset.seg = i;                 // index → highlighted from the music panel
    band.style.left = (g.start/m.duration*100) + "%";
    band.style.width = ((g.end-g.start)/m.duration*100) + "%";
    band.style.background = EMO_COLORS[g.emotion] || "#5a8a6a";
    band.title = `${g.emotion} — ${g.track}`;
    segs.appendChild(band);
    if (g.start > 0) { const tk = document.createElement("div"); tk.className = "pv-tick"; tk.style.left = (g.start/m.duration*100) + "%"; ticks.appendChild(tk); }
  });
  renderMusicPanel(m);
  buildSubStylePanel();                              // global subtitle-style panel (appears with the preview)
  pvBuildTextTrack();
  await pvPreloadAll(m, block);                      // block=true: wait until ALL media is buffered; false: fire-and-forget (instant restore)
  $("#pvVo").onended = () => { pvPause(); $("#pvVo").currentTime = 0; PV.seg = -1; PV.cap = -1; pvRender(0); };
  $("#pvVo").muted = false; pvMusicEls().forEach(el => el.muted = false); $("#pvMute").textContent = "🔊";
  $("#pvBig").hidden = false;                        // paused → big center play icon showing
  $("#buildPreviewBtn").textContent = "🔄 Rebuild Preview";
  $("#renderSection").hidden = false;               // there's something to render now — slide it in
  $("#pvTime").textContent = `0:00 / ${pvFmt(m.duration)}`;
  $("#previewWrap").hidden = false;                 // reveal ONLY now → pressing play starts instantly
  pvRender(0);
}

// preview a single BGM track (one shared audio; play again / another row stops it)
let pvTrackAudio = null, pvTrackBtn = null;
function pvStopTrack() {
  if (pvTrackAudio) pvTrackAudio.pause();
  if (pvTrackBtn) { pvTrackBtn.textContent = "▶"; pvTrackBtn = null; }
}
function pvPlayTrack(btn, emotion, filename) {
  if (pvTrackBtn === btn) { pvStopTrack(); return; }      // toggle off
  pvStopTrack();
  pvPause();                                              // pause the main preview so the track is clear
  if (!pvTrackAudio) { pvTrackAudio = new Audio(); pvTrackAudio.addEventListener("ended", pvStopTrack); }
  pvTrackAudio.src = `/bgm/${emotion}/${filename}`;
  pvTrackAudio.currentTime = 0; pvTrackAudio.play().catch(() => {});
  btn.textContent = "⏹"; pvTrackBtn = btn;
}

// music-override panel: one row per segment with a track dropdown + a re-pick button
function renderMusicPanel(m) {
  pvStopTrack();
  const box = $("#pvMusicPanel"); if (!box) return;
  const title = $("#pvMusicHead");
  box.innerHTML = "";
  if (!m.music || !m.music.length) { box.hidden = true; if (title) title.hidden = true; return; }
  box.hidden = false; if (title) title.hidden = false;
  m.music.forEach((g, i) => {
    const row = document.createElement("div"); row.className = "pv-music-row";
    const info = document.createElement("span"); info.className = "pv-music-info";
    const dot = document.createElement("i"); dot.className = "pv-music-dot"; dot.style.background = EMO_COLORS[g.emotion] || "#5a8a6a";
    const seg = document.createElement("span"); seg.className = "pv-music-seg";
    seg.textContent = `${g.emotion[0] + g.emotion.slice(1).toLowerCase()} · ${pvFmt(g.start)}–${pvFmt(g.end)}`;
    info.append(dot, seg);
    const hi = (on) => {                                  // hovering the emotion/time highlights that band in the scrubber
      const box2 = $("#pvSegs"); if (!box2) return;
      box2.classList.toggle("hovering", on);
      const band = box2.querySelector(`.pv-seg[data-seg="${i}"]`);
      if (band) band.classList.toggle("hi", on);
    };
    row.addEventListener("mouseenter", () => hi(true));   // anywhere on the row (label, dropdown, play)
    row.addEventListener("mouseleave", () => hi(false));
    const sel = document.createElement("select"); sel.className = "pv-music-sel";
    (g.options || []).forEach(t => { const o = document.createElement("option"); o.value = t; o.textContent = t.replace(/\.(mp3|wav)$/i, ""); if (t === g.track) o.selected = true; sel.appendChild(o); });
    const play = document.createElement("button"); play.className = "pv-music-play ghost"; play.type = "button"; play.textContent = "▶"; play.title = "Preview the selected track";
    play.addEventListener("click", () => pvPlayTrack(play, g.emotion, sel.value));
    sel.addEventListener("change", async () => {
      pvStopTrack();
      const r = await api.musicOverride(PROJECT, g.index, sel.value);
      if (r.error) { alert(r.error); return; }
      g.track = sel.value; g.url = r.url; if (r.level != null) g.level = r.level;
      pvMusicEls().forEach(el => { if (el.dataset.src && el.dataset.src !== g.url) { el.removeAttribute("data-src"); } });
      pvRender($("#pvVo").currentTime || 0);        // pick up the new track now (mix reloads it)
    });
    row.append(info, sel, play);
    box.appendChild(row);
  });
}

// ---------- global subtitle style (Assemble: styles every SRT caption at once) ----------
const SUB_STYLE_DEFAULTS = {
  ost_font: "Arial", ost_size: 46, ost_weight: "400", ost_color: "#ffffff", ost_fill: true,
  ost_bold: false, ost_italic: false, ost_upper: false, ost_underline: false,
  ost_letter: 0, ost_leading: 1.15,
  ost_place: "bottom", ost_x: 0, ost_y: 0, ost_rotation: 0,
  ost_stroke: false, ost_stroke_w: 0, ost_stroke_color: "#000000",
  ost_bg: true, ost_bg_color: "#000000", ost_bg_opacity: 62, ost_bg_pad: 14, ost_bg_radius: 10,
  ost_shadow: false, ost_shadow_color: "#000000", ost_shadow_opacity: 80, ost_shadow_size: 6, ost_shadow_dir: 135,
  ost_anim: "fade", ost_out_anim: "none",
  sub_width: 86, sub_lines: "auto",
};
function subStyle() {
  if (!DOC) return { ...SUB_STYLE_DEFAULTS };
  if (!DOC.subtitle_style || typeof DOC.subtitle_style !== "object") DOC.subtitle_style = {};
  const st = DOC.subtitle_style;
  for (const k in SUB_STYLE_DEFAULTS) if (st[k] === undefined) st[k] = SUB_STYLE_DEFAULTS[k];
  return st;
}
// balanced, width-aware wrap — mirrors _sub_wrap_lines() in render_video.py so preview == render.
function wrapSubLines(text, st) {
  text = String(text || "").replace(/\s+/g, " ").trim();
  if (!text) return [];
  const width = Math.max(20, Math.min(100, +st.sub_width || 86));
  const size = Math.max(1, +st.ost_size || 46);
  const mode = String(st.sub_lines || "auto");
  const cpl = Math.max(6, Math.floor(1920 * width / 100 / (0.5 * size)));   // ~chars per line at this width+size
  const words = text.split(" ");
  const greedy = (cap) => {
    const lines = []; let cur = "";
    for (const w of words) {
      if (cur && cur.length + 1 + w.length > cap) { lines.push(cur); cur = w; }
      else cur = cur ? cur + " " + w : w;
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : [text];
  };
  const balance = (n) => {
    if (n <= 1 || words.length < 2) return [text];
    const target = text.length / n;
    const lines = []; let cur = [];
    words.forEach((w, idx) => {
      cur.push(w);
      const curLen = cur.join(" ").length;
      const wordsLeft = words.length - idx - 1, linesLeft = n - lines.length - 1;
      if (lines.length < n - 1 && curLen >= target && wordsLeft >= linesLeft) { lines.push(cur.join(" ")); cur = []; }
    });
    if (cur.length) lines.push(cur.join(" "));
    return lines;
  };
  if (mode === "1") return [text];                 // force ONE line — never wrap (box hugs it, grows with the font)
  if (mode === "2") return text.length <= cpl ? [text] : balance(2);
  if (text.length <= cpl) return [text];
  const n = Math.max(2, Math.ceil(text.length / cpl));
  return balance(n);
}
// position + paint a caption. posEl carries the placement transform; styleEl carries the look. For the
// live caption they're the same element; for the mini-preview the wrap positions and the inner paints
// (so an entrance animation's transform on the inner doesn't fight the centring transform).
function styleCaption(styleEl, posEl, w) {
  if (!styleEl || !posEl) return;
  const st = subStyle(), scale = (w || 640) / 1920;
  ostTextStyle(styleEl, ostOpts(st), scale);            // font / size / colour / stroke / bg / shadow
  styleEl.style.textAlign = "center";
  const oneLine = String(st.sub_lines || "auto") === "1";
  // "1 line" = never wrap: the whole caption stays on ONE line, the box hugs it and grows with the font
  // (so a big-enough font reaches both edges). Otherwise honour our \n breaks and wrap at "Line" width.
  styleEl.style.whiteSpace = oneLine ? "nowrap" : "pre-line";
  // The box HUGS the text with even padding on all sides and grows/shrinks with the font size.
  // "Line" (sub_width) only caps how wide the text may spread before it wraps — it does NOT set the box
  // width. In 1-line mode there's no wrap, so no max-width either (the single line can span the frame).
  posEl.style.textAlign = "center";
  posEl.style.width = "auto";
  posEl.style.maxWidth = oneLine ? "none" : ((st.sub_width || 86) + "%");
  styleEl.style.display = "inline-block";
  if (styleEl !== posEl) styleEl.style.width = "auto";
  const place = st.ost_place || "bottom";
  const tx = ((st.ost_x || 0) * scale).toFixed(1), ty = ((st.ost_y || 0) * scale).toFixed(1);
  const rot = st.ost_rotation ? ` rotate(${st.ost_rotation}deg)` : "";
  posEl.style.left = "50%"; posEl.style.right = "auto";
  if (place === "top") { posEl.style.top = "14%"; posEl.style.bottom = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), ${ty}px)${rot}`; }
  else if (place === "center") { posEl.style.top = "50%"; posEl.style.bottom = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px))${rot}`; }
  else { posEl.style.bottom = "4.5%"; posEl.style.top = "auto"; posEl.style.transform = `translate(calc(-50% + ${tx}px), ${ty}px)${rot}`; }
}
function applyPvCaptionStyle() {
  const el = $("#pvCaption"); if (!el) return;
  const inner = el.querySelector(".pv-cap-inner") || el;   // inner carries the look; outer positions
  const stage = $("#pvStage");
  styleCaption(inner, el, (stage && stage.clientWidth) || 640);
  el.style.display = PV.capRaw ? "" : "none";              // styling must never reveal an empty box
}
// set the live caption text, wrapped per the current subtitle style (stores the raw text for re-wrap on style change)
function pvSetCaptionText(text) {
  const el = $("#pvCaption"); if (!el) return;
  const inner = el.querySelector(".pv-cap-inner") || el;
  const had = PV.capRaw;
  PV.capRaw = text || "";
  const wrapped = text ? wrapSubLines(text, subStyle()).join("\n") : "";
  inner.textContent = wrapped;
  el.style.display = wrapped ? "" : "none";             // never leave an empty styled box on-screen
  if (wrapped && text !== had) {                        // play the chosen entrance animation (matches the render)
    const anim = subStyle().ost_anim || "fade";
    [...inner.classList].filter(c => c.startsWith("pv-ost")).forEach(c => inner.classList.remove(c));
    if (anim !== "none") { void inner.offsetWidth; inner.classList.add("pv-ost-" + anim); }
  }
}
// ---- mini subtitle preview (bottom half of a fixed frame + a sample subtitle) ----
function subMiniFrameSrc() {
  const scs = (PV.m && PV.m.scenes) || [];
  const f = scs.find(s => s.img || (s.type === "image" && s.url));
  return f ? (f.img || f.url) : null;
}
function subMiniSampleText() {
  const caps = (PV.m && PV.m.captions) || [];
  if (!caps.length) return "This is a sample subtitle line to preview your style";
  // a representative, medium-length caption so wrapping/width read realistically
  const sorted = caps.map(c => c.text || "").filter(Boolean).sort((a, b) => a.length - b.length);
  return sorted[Math.floor(sorted.length / 2)] || sorted[0] || "Sample subtitle";
}
function renderSubMini() {
  const mini = $("#pvSubMini"); if (!mini || mini.hidden) return;
  const img = mini.querySelector(".psm-img"), inner = mini.querySelector(".psm-inner");
  const wrap = mini.querySelector(".psm-cap-wrap"), cap = mini.querySelector(".psm-cap");
  const src = subMiniFrameSrc();
  if (src && img.getAttribute("src") !== src) img.src = src;
  img.style.visibility = src ? "visible" : "hidden";
  cap.textContent = wrapSubLines(subMiniSampleText(), subStyle()).join("\n");
  styleCaption(cap, wrap, (inner && inner.clientWidth) || mini.clientWidth || 640);
}
// replay the chosen in/out animation once on the mini caption (so picking one shows what it does)
function playSubAnim(kind) {
  const cap = $("#pvSubMini .psm-cap"); if (!cap) return;
  const st = subStyle();
  const name = kind === "out" ? (st.ost_out_anim || "none") : (st.ost_anim || "fade");
  [...cap.classList].filter(c => c.startsWith("pv-ost")).forEach(c => cap.classList.remove(c));
  if (name === "none") return;
  const cls = kind === "out" ? ("pv-ost-out-" + name) : ("pv-ost-" + name);
  void cap.offsetWidth;                                  // reflow → restart the animation
  cap.classList.add(cls);
  cap.addEventListener("animationend", () => cap.classList.remove(cls), { once: true });
}
function buildSubStylePanel() {
  const box = $("#pvSubPanel"), head = $("#pvSubHead"), mini = $("#pvSubMini"), tpl = $("#subStyleTpl");
  if (!box || !tpl || !DOC) return;
  const hasCaps = !!(PV.m && PV.m.captions && PV.m.captions.length);
  if (head) head.hidden = !hasCaps;
  if (mini) mini.hidden = !hasCaps;
  box.hidden = !hasCaps;
  box.innerHTML = "";
  if (!hasCaps) return;
  const panel = tpl.content.firstElementChild.cloneNode(true);
  box.appendChild(panel);
  const st = subStyle();
  const redraw = () => { applyPvCaptionStyle(); pvSetCaptionText(PV.capRaw || ""); renderSubMini(); queueSave(); };
  wireOstPanel(panel, st, redraw, buildSubStylePanel, "subtitle");   // subtitle-scoped presets (kept separate from on-screen)
  // Size is a slider here (font size), Width is a numeric % (the left/right narrowing)
  const sInp = panel.querySelector(".sub-size"), sV = panel.querySelector(".sub-size-v");
  if (sInp) {
    sInp.value = st.ost_size != null ? st.ost_size : 46;
    const showS = () => { if (sV) sV.textContent = sInp.value; };
    showS();
    sInp.addEventListener("input", () => { st.ost_size = clampNum(sInp.value, 12, 400, 46); showS(); redraw(); });
  }
  const wInp = panel.querySelector(".sub-width-num");
  if (wInp) {
    wInp.value = st.sub_width != null ? st.sub_width : 86;
    wInp.addEventListener("input", () => { st.sub_width = clampNum(wInp.value, 30, 100, 86); redraw(); });
  }
  panel.querySelectorAll(".sub-line-btn").forEach(b => {
    b.classList.toggle("on", b.dataset.lines === String(st.sub_lines || "auto"));
    b.addEventListener("click", () => {
      st.sub_lines = b.dataset.lines;
      panel.querySelectorAll(".sub-line-btn").forEach(x => x.classList.toggle("on", x === b));
      redraw();
    });
  });
  // preview the animation once whenever it's picked
  const aIn = panel.querySelector(".ost-anim"), aOut = panel.querySelector(".ost-out-anim");
  if (aIn) aIn.addEventListener("change", () => playSubAnim("in"));
  if (aOut) aOut.addEventListener("change", () => playSubAnim("out"));
  // reset every subtitle setting back to the original default look
  const resetBtn = panel.querySelector(".sub-reset");
  if (resetBtn) resetBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!(await confirmDialog("Reset the subtitle style back to the default?", { title: "Reset Subtitles", okText: "Reset", danger: false }))) return;
    DOC.subtitle_style = { ...SUB_STYLE_DEFAULTS };
    buildSubStylePanel();                                  // rebuild controls from the defaults
    applyPvCaptionStyle(); pvSetCaptionText(PV.capRaw || ""); renderSubMini();
    queueSave();
    toast("Subtitle style reset to default", "ok");
  });
  applyPvCaptionStyle();
  renderSubMini();
}

// media a scene shows in the preview, resolved from the CURRENT doc (approved video else image else blank)
function pvSceneMedia(s) {
  const v = s.video || {};
  if (v.approved && v.status === "ready" && v.file) return { type: "video", url: `/media/${PROJECT}/${v.file}` };
  const f = s.approved ? (s.image.approved_file || s.image.file) : null;
  if (f) return { type: "image", url: `/media/${PROJECT}/${f}` };
  return { type: "blank", url: null };
}
// live-refresh preview media from the doc (e.g. after re-approving a scene) — no rebuild needed
function pvSyncFromDoc() {
  if (!PV.m || !DOC) return;
  let changed = false;
  PV.m.scenes.forEach(ps => {
    const s = (DOC.scenes || []).find(x => x.id === ps.id); if (!s) return;
    const md = pvSceneMedia(s);
    if (md.type !== ps.type || md.url !== ps.url) { ps.type = md.type; ps.url = md.url; changed = true; }
    const texts = sceneTL(s);   // pick up on-screen-text edits made since the preview was built
    if (JSON.stringify(texts) !== JSON.stringify(ps.texts || [])) { ps.texts = texts; changed = true; }
    if ((s.transition || "none") !== ps.transition) { ps.transition = s.transition || "none"; changed = true; }
  });
  if (changed) { PV.scene = -1; [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) v._pvSrc = ""; }); pvRender($("#pvVo").currentTime || 0); }
  pvBuildTextTrack();   // reflect text add/remove/edit in the timing track
}
// Re-draw the paused frame where we left off. A <video> decoded while its tab was hidden
// (display:none) shows BLACK until nudged, so on returning to Assemble we re-resolve the
// current scene and give the video a hair of a seek to force it to paint that frame.
// A paused <video> that was decoded while its tab was hidden stays BLACK until it paints.
// A muted play()→pause() forces it to decode & paint the current frame (the video element is
// always muted, so this needs no user gesture) — showing the exact paused frame, not black.
// At rest on a video scene, show its approved still image (sc.img) instead of the <video>.
// A <video> can show BLACK at rest — it was decoded while its tab was hidden, or a scene
// change is still (re)loading it — whereas the still image always paints. Pressing play
// switches back to the moving video (see pvPlay).
function pvStillIfPaused() {
  const sc = PV.m && PV.m.scenes[PV.scene];
  if (sc && sc.type === "video" && sc.img && !PV.imagesOnly && $("#pvVo").paused) {
    const img = $("#pvImage");
    [$("#pvVideo"), $("#pvVideo2")].forEach(v => { try { v.pause(); } catch (_) {} v.hidden = true; });
    if (img.getAttribute("src") !== sc.img) img.src = sc.img;
    img.hidden = false;
  }
}
function pvRepaint() {
  if (!PV.m) return;
  PV.scene = -1;                                   // force the current scene's media to re-resolve
  pvRender($("#pvVo").currentTime || 0);
  pvStillIfPaused();                               // show a frame, not black
}

// on-screen text overlays for the current scene: each styled + animated, scaled from 1080p to the stage
function pvSetOverlay(sc) {
  const layer = $("#pvOstWrap"); if (!layer) return;
  layer.innerHTML = ""; PV.ostEls = [];
  const withText = (((sc && sc.texts) || []).filter(o => (o.text || "").trim()));
  if (!withText.length) { layer.hidden = true; return; }
  layer.hidden = false;
  const stageW = $("#pvStage").clientWidth || 640, scale = stageW / 1920;
  const dur = Math.max(0.001, sc.end - sc.start);
  const cf = (v, d) => { const f = parseFloat(v); return isFinite(f) ? Math.min(1, Math.max(0, f)) : d; };
  withText.forEach(o => {
    const wrap = document.createElement("div"); wrap.className = "pv-ost-wrap place-" + (o.text_place || "top");
    const inner = document.createElement("div"); inner.className = "pv-ost";
    wrap.appendChild(inner); layer.appendChild(wrap);
    ostWrapPos(wrap, o.text_place || "top", o.text_x, o.text_y, scale, o.text_rotation);
    inner.textContent = (o.text || "").trim();
    ostTextStyle(inner, ostOptsTL(o), scale);
    wrap.style.display = "none";                           // shown only during its window (pvOstTick)
    PV.ostEls.push({ wrap, inner,
      start: sc.start + dur * cf(o.text_in, 0), end: sc.start + dur * cf(o.text_out, 1),
      inAnim: "pv-ost-" + (o.text_anim || "fade"),
      out: (o.text_out_anim && o.text_out_anim !== "none") ? o.text_out_anim : null, state: "idle" });
  });
}
// per-frame: reveal each overlay only inside its [start,end] window, playing in/out at the edges
function pvOstTick(t) {
  (PV.ostEls || []).forEach(e => {
    if (t >= e.start && t < e.end) {
      if (e.state === "idle") { e.wrap.style.display = ""; void e.inner.offsetWidth; e.inner.className = "pv-ost " + e.inAnim; e.state = "in"; }
      if (e.state === "in" && e.out && (e.end - t) <= 0.42) { e.inner.className = "pv-ost pv-ost-out-" + e.out; e.state = "out"; }
    } else if (e.state !== "idle") { e.wrap.style.display = "none"; e.state = "idle"; }
  });
}
// ---------- on-screen-text timeline track (Assemble): one draggable bar per text ----------
function pvTtSetOpen(open, animate) {
  const wrap = $("#pvTextWrap"), tog = $("#pvTextToggle"), pw = $("#previewWrap");
  if (!wrap) return;
  PV.ttOpen = open;
  if (tog) tog.classList.toggle("on", open);
  clearTimeout(wrap._t);
  // measure the natural open height and publish it as --pv-tt-h → in fullscreen the play buttons +
  // progress bar are lifted by exactly this much (animated) so the text bar slides in beneath them
  // WITHOUT ever resizing the video.
  const _pt = wrap.style.transition, _ph = wrap.style.height;
  wrap.style.transition = "none"; wrap.style.height = "auto";
  const openH = wrap.offsetHeight;
  wrap.style.height = _ph; void wrap.offsetHeight; wrap.style.transition = _pt;
  if (pw) pw.style.setProperty("--pv-tt-h", (open ? openH : 0) + "px");
  if (!animate) { wrap.style.transition = "none"; wrap.style.height = open ? "auto" : "0px"; void wrap.offsetHeight; wrap.style.transition = ""; return; }
  const from = Math.round(wrap.getBoundingClientRect().height);
  const to = open ? openH : 0;                             // natural (open) height, incl. the track margin
  wrap.style.transition = "none"; wrap.style.height = from + "px"; void wrap.offsetHeight; wrap.style.transition = "";
  wrap.style.height = to + "px";
  wrap._t = setTimeout(() => {                            // force the end state (some embedded webviews stall transitions)
    wrap.style.transition = "none"; wrap.style.height = PV.ttOpen ? "auto" : "0px"; void wrap.offsetHeight; wrap.style.transition = "";
  }, 340);
}
function pvTtSetZoom(z) {
  PV.ttZoom = Math.max(1, Math.min(12, z || 1));
  pvBuildTextTrack();
}
function pvBuildTextTrack() {
  const track = $("#pvTextTrack"), tog = $("#pvTextToggle"), content = $("#pvTtContent"); if (!track || !content || !PV.m) return;
  if (PV.ttZoom == null) PV.ttZoom = 1;
  if (!content._seekBound) {                               // click/drag empty area → seek there (+ leave red edit mode)
    content.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".pv-tt-bar")) return;          // clicking a bar selects/drags it, not seek
      if (e.button != null && e.button !== 0) return;      // left button only
      content.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
      pvTtHeadDrag(e);                                      // jump the playhead here + allow drag; stays in sync with the progress bar
    });
    content._seekBound = true;
  }
  const ttScroll = $("#pvTtScroll");
  if (ttScroll && !ttScroll._syncBound) {                  // pan the progress bar in lock-step with the text track when zoomed
    ttScroll.addEventListener("scroll", () => { const row = $("#pvBarRow"); if (row && (PV.ttZoom || 1) > 1) row.scrollLeft = ttScroll.scrollLeft; });
    ttScroll._syncBound = true;
  }
  content.innerHTML = "";
  const dur = PV.m.duration || 1, bars = [];
  (PV.m.scenes || []).forEach(ps => {
    const s = (DOC.scenes || []).find(x => x.id === ps.id);
    if (!s || !s.ost_on) return;
    const sceneDur = Math.max(0.001, ps.end - ps.start);
    (s.overlays || []).forEach(ov => {
      if (!(ov.onscreen || "").trim()) return;
      bars.push({ ov, sceneId: ps.id, sceneStart: ps.start, sceneEnd: ps.end, sceneDur, txt: ov.onscreen.trim() });
    });
  });
  if (PV.ttOpen == null) PV.ttOpen = true;                 // open by default when texts exist
  if (!bars.length) { track.hidden = true; if (tog) tog.style.display = "none"; pvTtSetOpen(false, false); return; }
  track.hidden = false; if (tog) tog.style.display = "";
  const rowEnds = [];                                       // pack overlapping bars onto separate rows
  bars.forEach(b => {
    b.absStart = b.sceneStart + b.sceneDur * (+b.ov.ost_in || 0);
    b.absEnd = b.sceneStart + b.sceneDur * (b.ov.ost_out != null ? +b.ov.ost_out : 1);
    let r = rowEnds.findIndex(end => b.absStart >= end - 0.01);
    if (r < 0) { r = rowEnds.length; rowEnds.push(0); }
    rowEnds[r] = b.absEnd; b.row = r;
  });
  content.style.width = (PV.ttZoom * 100) + "%";           // zoom widens the timeline; the scroll area pans
  content.style.height = (rowEnds.length * 26 + 8) + "px";
  bars.forEach(b => content.appendChild(pvTextBar(b, dur)));
  const ph = document.createElement("div"); ph.className = "pv-tt-head"; content.appendChild(ph);
  ph.addEventListener("pointerdown", pvTtHeadDrag);       // drag the orange playhead to scrub (stays in sync with the progress bar)
  const zo = $("#pvTtZoomOut"), zi = $("#pvTtZoomIn");
  if (zo) zo.disabled = PV.ttZoom <= 1; if (zi) zi.disabled = PV.ttZoom >= 12;
  pvTextTrackHead($("#pvVo") ? ($("#pvVo").currentTime || 0) : 0);
  pvTtSetOpen(PV.ttOpen, false);                           // apply the open/closed state (no animation on rebuild)
  pvSyncBar();                                             // widen + pan the progress bar to match the text-track zoom
}
// mirror the text-track's zoom width + scroll onto the progress bar so the yellow playhead and the round handle stay aligned
function pvSyncBar() {
  const bar = $("#pvBar"), row = $("#pvBarRow"), tt = $("#pvTtScroll"), content = $("#pvTtContent");
  if (!bar || !row) return;
  const z = PV.ttZoom || 1;
  if (z > 1 && content) {
    // match the progress bar to the EXACT pixel width of the zoomed text-track content (not "%") so the
    // round handle and the orange playhead sit at the identical x at every time — no zoom-amplified drift.
    bar.style.flex = "none"; bar.style.width = content.offsetWidth + "px";
    row.style.overflowX = "hidden";                        // scroll is driven programmatically, mirrored from the text track
    if (tt) row.scrollLeft = tt.scrollLeft;
  } else {
    bar.style.flex = ""; bar.style.width = ""; row.style.overflowX = ""; row.scrollLeft = 0;
  }
}
function pvTextTrackHead(t) {
  const content = $("#pvTtContent"), ph = content && content.querySelector(".pv-tt-head");
  if (!ph || !PV.m) return;
  const frac = t / (PV.m.duration || 1);
  ph.style.left = (frac * 100) + "%";
  const scroll = $("#pvTtScroll");
  if (scroll && (PV.ttZoom || 1) > 1) {                    // keep the playhead in view when zoomed in
    const cw = content.offsetWidth, vw = scroll.clientWidth, x = frac * cw, sl = scroll.scrollLeft;
    if (x < sl + vw * 0.1 || x > sl + vw * 0.9) scroll.scrollLeft = Math.max(0, Math.min(cw - vw, x - vw * 0.5));
    const row = $("#pvBarRow"); if (row) row.scrollLeft = scroll.scrollLeft;   // progress bar pans in lockstep
  }
}
// drag the text-track's orange playhead to scrub; maps the cursor onto the (possibly zoomed) timeline
function pvTtHeadDrag(e) {
  if (!PV.m) return;
  e.preventDefault(); e.stopPropagation();
  const content = $("#pvTtContent"); if (!content) return;
  const wasPlaying = !$("#pvVo").paused; if (wasPlaying) pvPause();
  const seek = (ev) => {
    const r = content.getBoundingClientRect();
    const frac = Math.min(1, Math.max(0, (ev.clientX - r.left) / (r.width || 1)));
    const t = frac * PV.m.duration;
    PV.seg = -1; PV.cap = -1;
    try { $("#pvVo").currentTime = t; } catch (_) {}
    pvRender(t);                                            // moves both the orange playhead and the progress-bar circle
  };
  seek(e);
  const up = () => { window.removeEventListener("pointermove", seek); window.removeEventListener("pointerup", up); if (wasPlaying) pvPlay(); };
  window.addEventListener("pointermove", seek); window.addEventListener("pointerup", up);
}
function pvTextBar(b, dur) {
  const bar = document.createElement("div"); bar.className = "pv-tt-bar"; bar.style.top = (b.row * 26 + 4) + "px";
  const label = document.createElement("span"); label.className = "pv-tt-label"; label.textContent = b.txt;
  const lh = document.createElement("div"); lh.className = "pv-tt-h pv-tt-l";
  const rh = document.createElement("div"); rh.className = "pv-tt-h pv-tt-r";
  bar.append(label, lh, rh);
  // minimum bar length: keep the actual duration ≥ the 0.5% display floor so a short bar's VISUAL
  // width never spills past its scene (the drag clamps the data, but a min-width floor could overshoot).
  const MIN = Math.max(0.35, 0.005 * dur);
  const place = () => { bar.style.left = (b.absStart / dur * 100) + "%"; bar.style.width = ((b.absEnd - b.absStart) / dur * 100) + "%"; };
  place();
  let changed = false;
  const drag = (e, mode) => {
    if (mode !== "move" && !bar.classList.contains("editing")) return;   // edges resize ONLY in red edit mode; else fall through to move
    if (e.button != null && e.button !== 0) return;        // left button only
    e.preventDefault(); e.stopPropagation();
    changed = false;
    const cap = e.currentTarget;                           // capture the pointer so the drag can't be lost
    try { cap.setPointerCapture(e.pointerId); } catch (_) {}
    const W = $("#pvTtContent").getBoundingClientRect().width || 1;   // zoomed content width → drag maps to time
    const s0 = { x: e.clientX, a: b.absStart, o: b.absEnd, w: b.absEnd - b.absStart };
    bar.classList.add("dragging");
    const move = (ev) => {
      const dt = (ev.clientX - s0.x) / W * dur;
      if (mode === "move") { b.absStart = Math.max(b.sceneStart, Math.min(s0.a + dt, b.sceneEnd - s0.w)); b.absEnd = b.absStart + s0.w; }
      else if (mode === "l") b.absStart = Math.max(b.sceneStart, Math.min(s0.a + dt, b.absEnd - MIN));
      else b.absEnd = Math.min(b.sceneEnd, Math.max(s0.o + dt, b.absStart + MIN));
      changed = true; place();
    };
    const end = () => {
      cap.removeEventListener("pointermove", move); cap.removeEventListener("pointerup", end); cap.removeEventListener("pointercancel", end);
      try { cap.releasePointerCapture(e.pointerId); } catch (_) {}
      bar.classList.remove("dragging");
      if (!changed) return;                                 // a plain click (e.g. one half of a double-click) — don't save
      b.ov.ost_in = +((b.absStart - b.sceneStart) / b.sceneDur).toFixed(4);
      b.ov.ost_out = +((b.absEnd - b.sceneStart) / b.sceneDur).toFixed(4);
      const ps = PV.m.scenes.find(x => x.id === b.sceneId), s = (DOC.scenes || []).find(x => x.id === b.sceneId);
      if (ps && s) ps.texts = sceneTL(s);                   // refresh preview timing
      queueSave(); PV.scene = -1; pvRender($("#pvVo").currentTime || 0);
    };
    cap.addEventListener("pointermove", move); cap.addEventListener("pointerup", end); cap.addEventListener("pointercancel", end);
  };
  lh.addEventListener("pointerdown", e => drag(e, "l"));
  rh.addEventListener("pointerdown", e => drag(e, "r"));
  bar.addEventListener("pointerdown", e => drag(e, "move"));
  bar.addEventListener("dblclick", (e) => {               // double-click → toggle red "edit" (resize-the-ends) mode
    e.preventDefault(); e.stopPropagation();
    const on = !bar.classList.contains("editing");
    const track = $("#pvTextTrack");
    if (track) track.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
    bar.classList.toggle("editing", on);
  });
  return bar;
}
// two <video> elements (double-buffer): the one showing the current scene is "active"; when a video
// transitions into another video the outgoing one keeps PLAYING as it slides out while the incoming
// plays in on the other element. pvVid() = active, pvVidBack() = the spare.
function pvVidEl(i) { return i ? $("#pvVideo2") : $("#pvVideo"); }
function pvVid() { return pvVidEl(PV.vidCur || 0); }
function pvVidBack() { return pvVidEl(1 - (PV.vidCur || 0)); }
// Play the outgoing scene's transition into the incoming one (mirrors the rendered xfade):
// crossfade/slide animate the old frame out; dips flash a black/white layer. `outVidEl`, when set,
// is a LIVE outgoing <video> that slides out still playing (double-buffer); else a still/canvas snapshot.
function pvPlayTransition(oldSc, sc, outFrame, outVidEl) {
  const t = oldSc.transition, fx = $("#pvFx");
  const prevImg = $("#pvPrev"), prevCvs = $("#pvPrevCanvas");
  const usingVid = !!outVidEl;                                // outgoing is a LIVE <video> (double-buffer)
  const usingCanvas = !usingVid && (outFrame === "canvas") && !!prevCvs;   // outgoing frame drawn onto the canvas
  const prev = usingVid ? outVidEl : (usingCanvas ? prevCvs : prevImg);    // the outgoing layer that animates out
  const IN_SLIDES = ["pv-in-slide-left", "pv-in-slide-right", "pv-in-slide-up", "pv-in-slide-down"];
  const TX = ["pv-tx-crossfade", "pv-tx-slide-left", "pv-tx-slide-right", "pv-tx-slide-up", "pv-tx-slide-down", "pv-prev-dip"];
  clearTimeout(PV._txT);
  const cleanup = () => {
    clearTimeout(PV._txT);
    [prevImg, prevCvs].forEach(p => { if (!p) return; p.hidden = true; p.className = "pv-media pv-prev"; p.style.transform = ""; p.style.removeProperty("--pv-z"); p.style.animationDuration = ""; });
    if (prevImg) prevImg.removeAttribute("src");
    if (PV._txOutVid) {                                     // the PREVIOUS transition's outgoing video: stop it, drop its classes, hide it
      const el = PV._txOutVid;
      el.classList.remove(...TX, "pv-prev"); el.style.transform = ""; el.style.removeProperty("--pv-z"); el.style.animationDuration = "";
      try { el.pause(); } catch (_) {} el.hidden = true; PV._txOutVid = null;
    }
    fx.hidden = true; fx.className = "pv-fx"; fx.style.animationDuration = "";
    if (PV._txInEl) { PV._txInEl.classList.remove(...IN_SLIDES); PV._txInEl.style.animationDuration = ""; PV._txInEl = null; }
  };
  // Fire cleanup when the animation actually FINISHES (animationend) — a fixed timer can fire a frame
  // early under load and cut the last frames. Keep a longer timeout only as a fallback.
  const schedule = (el) => {
    if (el) el.addEventListener("animationend", cleanup, { once: true });
    PV._txT = setTimeout(cleanup, done + 250);
  };
  cleanup();                                          // clear anything still mid-transition
  // match the render's transition length: 0.4s, clamped to half of either scene so a short scene
  // can't leave the transition running past its own end (the old frame bleeding into the next scene).
  const D = Math.max(0.12, Math.min(0.4, 0.5 * (oldSc.end - oldSc.start), sc ? 0.5 * (sc.end - sc.start) : 0.4));
  const dur = D.toFixed(3) + "s";
  prev.style.animationDuration = dur; fx.style.animationDuration = dur;
  // outgoing scene's Ken Burns zoom at the hand-off, so its frame doesn't snap back to un-zoomed
  const kbOn = (() => { const c = $("#rndKenburns"); return !c || c.checked; })();
  const oldStill = oldSc && (oldSc.type === "image" || (PV.imagesOnly && oldSc.img));
  const zoom = (kbOn && oldStill) ? (1 + 0.014 * Math.max(0, oldSc.end - oldSc.start)) : 1;
  // the outgoing video frame already lives on the canvas; otherwise use the approved still (which for
  // a video is its FIRST frame — only reached when the live frame couldn't be grabbed)
  const imgSrc = (usingVid || usingCanvas) ? null : (oldSc && (oldSc.img || (oldSc.type === "image" ? oldSc.url : null)));
  const hasFrame = usingVid || usingCanvas || !!imgSrc;
  if (hasFrame) {                                     // show the outgoing frame AT the zoom it reached
    if (usingVid) {                                    // outgoing video slides out still playing; lift it above the incoming
      prev.classList.add("pv-prev"); prev.hidden = false; PV._txOutVid = prev;
      if (!$("#pvVo").paused) prev.play().catch(() => {});
    } else { if (!usingCanvas) prev.src = imgSrc; prev.hidden = false; }
    prev.style.setProperty("--pv-z", zoom.toFixed(4));
    prev.style.transform = `scale(${zoom.toFixed(4)})`;
  }
  const done = Math.round(D * 1000) + 80;             // hide once the animation has finished
  if (t === "dip-black" || t === "dip-white") {
    if (hasFrame) { void prev.offsetWidth; prev.classList.add("pv-prev-dip"); }   // old (zoomed) held under the flash, then hidden
    fx.className = "pv-fx pv-fx-" + (t === "dip-white" ? "white" : "black");
    fx.hidden = false; void fx.offsetWidth; fx.classList.add("run");
    schedule(fx);                                     // fx always animates (pv-dip)
    return;
  }
  const isSlide = t.indexOf("slide-") === 0;
  if (hasFrame) { void prev.offsetWidth; prev.classList.add("pv-tx-" + t); }      // crossfade (opacity) / slide-out (keeps --pv-z)
  // for slides the incoming scene slides in from the other side at the same time (a push)
  if (isSlide) {
    const el = (sc && sc.type === "video" && !PV.imagesOnly) ? pvVid() : $("#pvImage");   // incoming video is now the active (front) element
    el.style.transform = ""; el.style.animationDuration = dur;   // hand the transform to the animation
    void el.offsetWidth; el.classList.add("pv-in-" + t); PV._txInEl = el;
  }
  if (!hasFrame && !isSlide) return;                  // crossfade with no outgoing frame = nothing to do
  schedule(hasFrame ? prev : PV._txInEl);             // whichever element carries the animation
}
function pvRender(t) {
  const m = PV.m; if (!m) return;
  let si = PV.m.scenes.length - 1;
  for (let i=0;i<m.scenes.length;i++) if (t>=m.scenes[i].start && t<m.scenes[i].end) { si = i; break; }
  if (si !== PV.scene && si >= 0) {
    const oldIdx = PV.scene, oldSc = oldIdx >= 0 ? m.scenes[oldIdx] : null;
    PV.scene = si; const sc = m.scenes[si];
    const img = $("#pvImage"), bl = $("#pvBlank");
    const front = pvVid();                          // element that was showing the outgoing scene (if a video)
    const willTx = oldSc && si === oldIdx + 1 && !$("#pvVo").paused && oldSc.transition && oldSc.transition !== "none";
    const oldWasVideo = oldSc && oldSc.type === "video" && !(PV.imagesOnly && oldSc.img) && !front.hidden;
    // outgoing layer for the transition: a LIVE video slides out (double-buffer) when it was playing and
    // we're transitioning; otherwise snapshot its current frame to the canvas (no slow toDataURL).
    let outFrame = null, outVidEl = null;
    if (oldWasVideo && willTx) {
      outVidEl = front;                             // keep the outgoing video PLAYING; it slides out live
    } else if (oldSc && oldSc.type === "video" && !front.hidden && front.videoWidth) {
      try { const cvs = $("#pvPrevCanvas"); cvs.width = front.videoWidth; cvs.height = front.videoHeight; cvs.getContext("2d").drawImage(front, 0, 0); outFrame = "canvas"; } catch (e) {}
    }
    const asImage = PV.imagesOnly && sc.type === "video" && sc.img;   // images-only → show the still
    if (sc.type === "video" && !asImage) {
      // incoming video plays on the BACK element when the front is sliding out live; else reuse the front
      const target = outVidEl ? pvVidBack() : front;
      img.hidden = true; bl.hidden = true; target.hidden = false;
      // poster = the scene's still, shown while the video buffers/decodes so entering it isn't a black flash
      if (sc.img) target.poster = sc.img; else target.removeAttribute("poster");
      if (target._pvSrc !== sc.url) { target.src = sc.url; target._pvSrc = sc.url; }
      try { target.currentTime = Math.max(0, t - sc.start); } catch (e) {}   // sync ONCE on entry, then let it play freely
      if (!$("#pvVo").paused) target.play().catch(()=>{});
      if (outVidEl) { PV.vidCur = 1 - (PV.vidCur || 0); }   // back is now the active/front; the old front slides out (cleaned up by the transition)
      else { const b = pvVidBack(); if (b !== target) { try { b.pause(); } catch (_) {} b.hidden = true; } }
    } else if (sc.type === "image" || asImage) {
      // hide the video buffers EXCEPT a live outgoing one (it keeps playing to slide out; the transition hides it after)
      [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v !== outVidEl) { try { v.pause(); } catch (_) {} v.hidden = true; } });
      bl.hidden = true; img.hidden = false; img.src = asImage ? sc.img : sc.url;
    } else {
      [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v !== outVidEl) { try { v.pause(); } catch (_) {} v.hidden = true; } });
      img.hidden = true; bl.hidden = false;
      // scene number ABOVE the icons: the centered ▶ play overlay lands on the icons, not on
      // the number, so the scene number stays readable when the preview is paused
      bl.innerHTML =
        `<div class="pv-empty">
           <div class="pv-empty-title">Scene ${sc.id}</div>
           <div class="pv-empty-icons">
             <svg class="pv-empty-ic" viewBox="50 28 60 54" fill="none"><rect x="52" y="32" width="56" height="46" rx="5"/><circle cx="70" cy="49" r="6"/><path d="M56 74 l18 -20 12 12 9 -9 13 15"/></svg>
             <svg class="pv-empty-ic" viewBox="50 30 60 50" fill="none"><rect x="52" y="34" width="56" height="42" rx="7"/><path d="M74 45 l18 10 -18 10 z"/></svg>
           </div>
           <div class="pv-empty-msg">No image or video for this scene yet.<br>Generate one and approve the image or video to see it here.</div>
         </div>`;
    }
    pvSetOverlay(sc);                                // on-screen text overlay (replays its animation on scene entry)
    // play the transition only on natural forward playback (skip scrubs/jumps) so it mirrors the render
    if (willTx) pvPlayTransition(oldSc, m.scenes[si], outFrame, outVidEl);
  }
  const sc = m.scenes[PV.scene];
  // Ken Burns: slow zoom on stills, synced to playback time (matches the render's 1.4%/sec).
  // Tied to the "Zoom-in effect" render checkbox; a running slide-in owns the transform, so we
  // skip the zoom while #pvImage is mid-transition (PV._txInEl) to avoid fighting that animation.
  {
    const kb = $("#rndKenburns"), img = $("#pvImage");
    const kbScene = sc && (sc.type === "image" || (PV.imagesOnly && sc.img)) && !img.hidden;
    if ((!kb || kb.checked) && kbScene && PV._txInEl !== img) {
      img.style.transform = `scale(${(1 + 0.014 * Math.max(0, t - sc.start)).toFixed(4)})`;
    } else if (img.style.transform && PV._txInEl !== img) {
      img.style.transform = "";
    }
  }
  // re-sync the video ONLY on a large drift (e.g. after scrubbing); during playback it runs freely = smooth
  if (sc && sc.type === "video" && !(PV.imagesOnly && sc.img)) {
    const v = pvVid(), want = t - sc.start;
    if (isFinite(want) && Math.abs((v.currentTime||0) - want) > 1.0) { try { v.currentTime = Math.max(0, want); } catch (e) {} }
  }
  pvOstTick(t);   // show each on-screen text only during its own window, in/out at the edges
  const ci = pvIdx(m.captions, t);
  if (ci !== PV.cap) { PV.cap = ci; pvSetCaptionText(ci >= 0 ? m.captions[ci].text : ""); }
  pvMusicMix(t);                                   // background music with cross-fades (see below)
  const pct = m.duration ? (t/m.duration*100) : 0;
  $("#pvProgress").style.width = pct + "%"; $("#pvHead").style.left = pct + "%"; pvTextTrackHead(t);
  $("#pvTime").textContent = `${pvFmt(t)} / ${pvFmt(m.duration)}`;
}

// ---- background-music cross-fade (matches render_video.py / premiere_export.py) ----
const PV_XFADE = 3.0;   // seconds; must match XFADE_SEC
function pvMusicEls() { return [$("#pvMusic"), $("#pvMusic2")]; }
// A segment's volume at time t: fades IN over the previous scene's end (reaching full exactly at
// its boundary start) and fades OUT over its last xfade (silent exactly at the next boundary).
function pvSegVol(g, i, t, last) {
  const s = g.start, e = g.end, lvl = Math.min(1, Math.max(0, g.level));
  const pre = (i > 0) ? PV_XFADE : 0;
  const start = s - pre;
  const fin = (i > 0) ? pre : Math.min(1.5, e - s);
  const fout = (i < last) ? PV_XFADE : Math.min(2.0, e - start);
  if (t < start || t >= e) return 0;
  if (fin > 0 && t < start + fin) return lvl * (t - start) / fin;   // fade in → full at the boundary
  if (fout > 0 && t > e - fout) return lvl * (e - t) / fout;        // fade out → 0 at the boundary
  return lvl;
}
// Up to two segments are audible at once (during a cross-fade); even/odd segments use the two
// audio slots so the out-going and in-coming tracks never fight over one element.
function pvMusicMix(t) {
  const m = PV.m; if (!m) return;
  const segs = m.music || [], last = segs.length - 1, els = pvMusicEls();
  const paused = $("#pvVo").paused;
  const want = [null, null];
  segs.forEach((g, i) => { if (g.url) { const v = pvSegVol(g, i, t, last); if (v > 0) want[i % 2] = { g, i, v }; } });
  for (let slot = 0; slot < 2; slot++) {
    const el = els[slot]; if (!el) continue;
    const w = want[slot];
    if (!w) { if (!el.paused) el.pause(); el.volume = 0; continue; }
    if (el.dataset.src !== w.g.url) { el.src = w.g.url; el.dataset.src = w.g.url; el.loop = true; }
    el.volume = Math.min(1, Math.max(0, w.v));
    const off = t - (w.g.start - ((w.i > 0) ? PV_XFADE : 0));
    if (Math.abs((el.currentTime || 0) - off) > 0.35) { try { el.currentTime = Math.max(0, off); } catch (e) {} }
    if (paused) { if (!el.paused) el.pause(); }
    else if (el.paused) el.play().catch(() => {});
  }
}
function pvLoop() { const vo = $("#pvVo"); pvRender(vo.currentTime || 0); if (!vo.paused) PV.raf = requestAnimationFrame(pvLoop); }
function pvPlay() {
  const vo = $("#pvVo"); vo.play().catch(()=>{});
  const sc = PV.m.scenes[PV.scene];
  if (sc && sc.type === "video" && !(PV.imagesOnly && sc.img)) {
    PV.scene = -1;                                 // let pvRender re-confirm the scene next frame
    const v = pvVid();
    $("#pvImage").hidden = true; v.hidden = false;   // swap the at-rest still out for the moving video
    try { v.currentTime = Math.max(0, vo.currentTime - sc.start); } catch (e) {}   // re-sync on resume
    v.play().catch(()=>{});
  }
  pvMusicMix(vo.currentTime || 0);                 // start/resume the audible music segment(s)
  $("#pvPlay").textContent = "❚❚"; $("#pvBig").hidden = true;
  cancelAnimationFrame(PV.raf); PV.raf = requestAnimationFrame(pvLoop);
  pvShowControls();
}
function pvPause() { $("#pvVo").pause(); pvMusicEls().forEach(el => el.pause()); $("#pvVideo").pause(); $("#pvVideo2").pause(); $("#pvPlay").textContent = "▶"; $("#pvBig").hidden = false; cancelAnimationFrame(PV.raf); pvShowControls(); }
function pvToggle() { if (!PV.m) return; $("#pvVo").paused ? pvPlay() : pvPause(); }
function pvRestart() {                          // jump to the very beginning
  if (!PV.m) return;
  const wasPlaying = !$("#pvVo").paused;
  PV.seg = -1; PV.cap = -1; PV.scene = -1; PV.vidSrc = ""; [$("#pvVideo"), $("#pvVideo2")].forEach(v => { if (v) v._pvSrc = ""; });
  $("#pvVo").currentTime = 0;
  pvMusicEls().forEach(el => { try { el.currentTime = 0; } catch (e) {} });
  pvRender(0);
  if (wasPlaying) pvPlay(); else { pvPause(); pvStillIfPaused(); }   // at rest, show the still not a black video
}
// seek to a given horizontal cursor position on the bar
function pvSeekTo(clientX) {
  if (!PV.m) return;
  const r = $("#pvBar").getBoundingClientRect();
  const t = Math.min(1, Math.max(0, (clientX - r.left) / r.width)) * PV.m.duration;
  PV.seg = -1; PV.cap = -1;                    // force music re-seek + caption refresh
  $("#pvVo").currentTime = t; pvRender(t);
}
// click OR drag the handle to scrub; pause while dragging so seeking is stable, then resume
let pvDragging = false, pvResumeAfterDrag = false;
function pvDragStart(ev) {
  if (!PV.m) return;
  pvDragging = true; pvResumeAfterDrag = !$("#pvVo").paused;
  if (pvResumeAfterDrag) pvPause();
  $("#pvBar").classList.add("dragging");
  pvSeekTo(ev.clientX); pvThumbAt(ev);
  ev.preventDefault();
}
function pvDragMove(ev) { if (pvDragging) { pvSeekTo(ev.clientX); pvThumbAt(ev); } }
function pvDragEnd() {
  if (!pvDragging) return;
  pvDragging = false;
  $("#pvBar").classList.remove("dragging");
  $("#pvThumb").hidden = true;
  if (pvResumeAfterDrag) pvPlay();
}
function pvMute() {
  if (!PV.m) return;
  const on = !$("#pvVo").muted;
  $("#pvVo").muted = on; pvMusicEls().forEach(el => el.muted = on);
  $("#pvMute").textContent = on ? "🔇" : "🔊";
}
function pvFull() {
  const w = $("#previewWrap");   // fullscreen the WHOLE player so the controls come along
  if (document.fullscreenElement) document.exitFullscreen();
  else if (w.requestFullscreen) w.requestFullscreen();
}
function pvImagesOnly() {
  if (!PV.m) return;
  PV.imagesOnly = !PV.imagesOnly;
  $("#pvImgOnly").classList.toggle("on", PV.imagesOnly);
  [$("#pvVideo"), $("#pvVideo2")].forEach(v => { try { v.pause(); } catch (_) {} v._pvSrc = ""; });
  PV.scene = -1;                                 // force the current scene's media to re-resolve
  pvRender($("#pvVo").currentTime || 0);
}
let pvHideTimer = null;
function pvShowControls() {                        // reveal the overlaid buttons; auto-hide again a few sec into playback (windowed + fullscreen)
  const w = $("#previewWrap"); if (!w) return;
  w.classList.remove("pv-hide-ui");
  clearTimeout(pvHideTimer);
  if (PV.m && !$("#pvVo").paused) {
    pvHideTimer = setTimeout(() => w.classList.add("pv-hide-ui"), 2500);
  }
}
document.addEventListener("fullscreenchange", () => {
  const full = !!document.fullscreenElement;
  $("#pvFull").textContent = full ? "🡼" : "⛶";
  if (full) {                          // fullscreen starts with the text bar HIDDEN; T reveals it (smoothly)
    PV._ttWas = PV.ttOpen;
    pvTtSetOpen(false, false);
  } else if (PV._ttWas != null) {      // leaving fullscreen → restore the windowed text-bar state
    pvTtSetOpen(PV._ttWas, false);
    PV._ttWas = null;
  }
  pvShowControls();
});
$("#buildPreviewBtn").addEventListener("click", buildPreview);

// ---------- server-side MP4 render (the preview, baked into one downloadable file) ----------
let rndPoll = null, rndStartMs = 0, rndClock = null, rndLastSt = null;

// switching projects: hide the section (Build Preview brings it back), then re-show it if
// this project already has a render — finished or still running
async function rndReset() {
  clearInterval(rndPoll); rndPoll = null;
  $("#renderSection").hidden = true;
  $("#renderStatus").hidden = $("#renderTrack").hidden = $("#renderDl").hidden = true;
  $("#renderCancelBtn").hidden = true;
  $("#renderBtn").disabled = false;
  $("#renderBtn").textContent = "🎥 Render Video";
  const st = await rndTick();
  if (st && (st.status === "running" || st.status === "done")) $("#renderSection").hidden = false;
  if (st && st.status === "running") rndPoll = setInterval(rndTick, 1500);
  loadRenderHistory();     // show past renders whenever the render section is available
}

function rndShow(st) {
  const box = $("#renderStatus"), track = $("#renderTrack"), fill = $("#renderFill"), dl = $("#renderDl");
  const cancelBtn = $("#renderCancelBtn");
  const running = st.status === "running";
  box.hidden = false;
  box.className = "pv-status" + (st.status === "error" ? " err" : "");
  track.hidden = !running;
  fill.style.width = `${st.pct || 0}%`;
  $("#renderBtn").disabled = running;
  $("#renderTestBtn").disabled = running;      // can't run a test render while a render is going
  cancelBtn.hidden = !running;                 // Stop button shows only while a render is running
  if (!running) { cancelBtn.disabled = false; if (rndClock) { clearInterval(rndClock); rndClock = null; } rndStartMs = 0; }
  rndLastSt = st;
  if (running) {
    if (!rndStartMs) rndStartMs = Date.now();   // a running render restored on reload starts its clock now
    const el = pvFmt((Date.now() - rndStartMs) / 1000);   // real elapsed time — always counts up correctly
    // keep the spinner element ALIVE across ticks (only update the text) so its spin loops seamlessly
    // instead of restarting every second when innerHTML is rebuilt
    let label = box.querySelector(".rnd-label");
    if (!label) { box.innerHTML = `<span class="sub-spin"></span> <span class="rnd-label"></span>`; label = box.querySelector(".rnd-label"); }
    label.textContent = `${st.step || "Rendering…"} · ${el} (${st.pct || 0}%)`;
    if (!rndClock) rndClock = setInterval(() => { if (rndLastSt && rndLastSt.status === "running") rndShow(rndLastSt); }, 1000);   // tick the counter every second
    dl.hidden = true;
  } else if (st.status === "error") {
    box.textContent = "Render failed: " + (st.error || "unknown error");
    dl.hidden = true;
  } else if (st.status === "cancelled") {
    box.hidden = true;                          // no lingering "Render cancelled." text
    dl.hidden = true;
    $("#renderBtn").textContent = "🎥 Render Video";
  } else if (st.status === "done") {
    const mb = st.size ? ` · ${(st.size / 1048576).toFixed(0)} MB` : "";
    // plain green tick, NOT the ✅ emoji — that reads as a checkbox next to the
    // cross-fade / zoom / subtitle checkboxes sitting right above this line
    const subs = st.subs === false ? "no subtitles" : "subtitles burned in";
    const res = st.fast ? "1280×720 @ 30fps (test)" : "1920×1080 @ 60fps";
    box.innerHTML = `<span class="rnd-ok">✔</span> Rendered ${pvFmt(st.duration || 0)}${mb} — ${res}, ${subs}.`;
    dl.hidden = false;
    dl.href = `/media/${PROJECT}/${st.file}?dl=${encodeURIComponent(st.name)}`;
    dl.setAttribute("download", st.name);
    dl.onclick = (e) => { e.preventDefault(); downloadMedia(st.file, st.name); };   // works in the desktop window too
    $("#renderBtn").textContent = "🔄 Re-render Video";
    loadRenderHistory();                            // a new render just landed → refresh the history list
  } else {
    box.hidden = true;
  }
}
function rndAgo(mtimeSec) {
  const s = Math.max(0, Date.now() / 1000 - mtimeSec);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
async function loadRenderHistory() {
  const box = $("#renderHistory"); if (!box || !PROJECT) return;
  let list = [];
  try { list = (await (await fetch(`/api/renders/${PROJECT}`)).json()).renders || []; } catch (e) {}
  if (!list.length) { box.hidden = true; box.innerHTML = ""; return; }
  box.hidden = false; box.innerHTML = "";
  const title = document.createElement("div"); title.className = "rnd-hist-title"; title.textContent = "Recent renders"; box.appendChild(title);
  list.forEach(r => {
    const row = document.createElement("div"); row.className = "rnd-hist-row";
    const mb = r.size ? `${(r.size / 1048576).toFixed(0)} MB` : "";
    const meta = document.createElement("span"); meta.className = "rnd-hist-meta";
    meta.innerHTML = `<b>${r.test ? "720p test" : "1080p"}</b> · ${mb} · ${rndAgo(r.mtime)}`;
    const dl = document.createElement("a"); dl.className = "ghost rnd-hist-dl"; dl.textContent = "⬇"; dl.title = "Download";
    dl.href = `/media/${PROJECT}/${r.file}?dl=${encodeURIComponent(r.name)}`; dl.setAttribute("download", r.name);
    dl.onclick = (e) => { e.preventDefault(); downloadMedia(r.file, r.name); };   // desktop-window friendly
    const open = document.createElement("button"); open.className = "ghost rnd-hist-open"; open.textContent = "📂"; open.title = "Open the folder";
    open.addEventListener("click", () => revealMedia(r.file));
    const del = document.createElement("button"); del.className = "ghost rnd-hist-del"; del.textContent = "×"; del.title = "Delete this render";
    del.addEventListener("click", async () => { try { await fetch(`/api/renders/${PROJECT}/${encodeURIComponent(r.name)}/delete`, { method: "POST" }); } catch (e) {} loadRenderHistory(); });
    row.append(meta, dl, open, del); box.appendChild(row);
  });
}

async function rndTick() {
  if (!PROJECT) return;
  let st;
  try { st = await (await fetch(`/api/render/${PROJECT}`)).json(); }
  catch (e) { return null; }
  rndShow(st);
  if (st.status !== "running") { clearInterval(rndPoll); rndPoll = null; }
  return st;
}

async function startRender(fast) {
  if (!PROJECT) return;
  const total = (PV.m && PV.m.duration) || 0;
  const range = await rangeDialog(fast, total);          // pick full video or a [start,end] slice + confirm (Render button)
  if (!range) return;                                    // cancelled
  const body = { kenburns: $("#rndKenburns").checked, music: $("#rndMusic").checked, burnsubs: $("#rndBurnSubs").checked, onscreentext: $("#rndOnscreen").checked, transitions: $("#rndTransitions").checked, fast: !!fast, gpu: !!range.gpu, low_priority: !!range.cpu };
  if (!range.full) { body.range_start = range.start; body.range_end = range.end; }
  rndStartMs = Date.now();   // start the elapsed-time counter from the click
  rndShow({ status: "running", pct: 0, step: fast ? "Starting test render…" : "Starting…" });
  let r;
  try { r = await fetch(`/api/render/${PROJECT}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); }
  catch (err) { rndShow({ status: "error", error: String(err) }); return; }
  if (!r.ok) {
    let m = "could not start"; try { m = (await r.json()).error || m; } catch (e2) {}
    rndShow({ status: "error", error: m });
    return;
  }
  clearInterval(rndPoll);
  rndPoll = setInterval(rndTick, 1500);
}
$("#renderBtn").addEventListener("click", () => startRender(false));
$("#renderTestBtn").addEventListener("click", () => startRender(true));
$("#renderCancelBtn").addEventListener("click", async () => {
  if (!PROJECT) return;
  const btn = $("#renderCancelBtn");
  btn.disabled = true;                          // immediate abort — no confirm (that's the point)
  $("#renderStatus").innerHTML = `<span class="sub-spin"></span> Cancelling…`;
  try { await fetch(`/api/render/${PROJECT}/cancel`, { method: "POST" }); } catch (e) {}
  rndTick();                                     // reflect the cancelled state right away
});
$("#pvPlay").addEventListener("click", pvToggle);
$("#pvStage").addEventListener("click", pvToggle);   // click anywhere on the video toggles play/pause
function pvThumbAt(ev) {
  if (!PV.m) return;
  const bar = $("#pvBar"), r = bar.getBoundingClientRect();
  const pct = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
  const t = pct * PV.m.duration;
  let sc = PV.m.scenes[PV.m.scenes.length - 1];
  for (const s of PV.m.scenes) if (t >= s.start && t < s.end) { sc = s; break; }
  const thumb = $("#pvThumb"), img = thumb.querySelector("img"), lbl = thumb.querySelector("span");
  const src = sc && (sc.img || (sc.type === "image" ? sc.url : null));
  if (src) { if (img.dataset.src !== src) { img.src = src; img.dataset.src = src; } img.style.display = ""; }
  else { img.style.display = "none"; }
  lbl.textContent = `${sc ? "Scene " + sc.id : ""} · ${pvFmt(t)}`;
  // fixed-positioned at the cursor (clamped to the viewport so the 150px thumb stays visible)
  thumb.style.left = Math.min(Math.max(ev.clientX, 85), window.innerWidth - 85) + "px";
  thumb.style.top = r.top + "px";
  thumb.hidden = false;
}
$("#pvBar").addEventListener("mousemove", (ev) => { if (!pvDragging) pvThumbAt(ev); });
$("#pvBar").addEventListener("mouseleave", () => { if (!pvDragging) { const t = $("#pvThumb"); if (t) t.hidden = true; } });
$("#pvBar").addEventListener("mousedown", pvDragStart);      // click OR drag the handle to scrub
window.addEventListener("mousemove", pvDragMove);
window.addEventListener("mouseup", pvDragEnd);
$("#pvRestart").addEventListener("click", pvRestart);
$("#pvMute").addEventListener("click", pvMute);
$("#pvFull").addEventListener("click", pvFull);
$("#pvImgOnly").addEventListener("click", pvImagesOnly);
$("#pvTextToggle").addEventListener("click", () => pvTtSetOpen(!PV.ttOpen, true));   // T = show/hide the text track
$("#pvTtZoomIn").addEventListener("click", () => pvTtSetZoom((PV.ttZoom || 1) * 1.6));
$("#pvTtZoomOut").addEventListener("click", () => pvTtSetZoom((PV.ttZoom || 1) / 1.6));
// hold ALT + mouse-wheel over the text track to zoom the timeline in/out
$("#pvTextTrack").addEventListener("wheel", (e) => {
  if (!e.altKey) return;
  e.preventDefault();
  pvTtSetZoom((PV.ttZoom || 1) * (e.deltaY < 0 ? 1.18 : 1 / 1.18));
}, { passive: false });
// ALT + wheel over the progress bar zooms too — the bar and the text track scale together
$("#pvBarRow").addEventListener("wheel", (e) => {
  if (!e.altKey) return;
  e.preventDefault();
  pvTtSetZoom((PV.ttZoom || 1) * (e.deltaY < 0 ? 1.18 : 1 / 1.18));
}, { passive: false });
// clicks on the overlaid controls must not bubble to the stage (which toggles play/pause)
$("#pvCtrlOverlay").addEventListener("click", (e) => e.stopPropagation());
// clicking anywhere that ISN'T a text-track bar leaves the red "edit" mode (capture so inner
// stopPropagation can't swallow it)
document.addEventListener("pointerdown", (e) => {
  if (e.target.closest(".pv-tt-bar")) return;
  document.querySelectorAll(".pv-tt-bar.editing").forEach(n => n.classList.remove("editing"));
}, true);
$("#previewWrap").addEventListener("mousemove", pvShowControls);

// ---------- keyboard shortcuts + help panel ----------
const SHORTCUTS = [
  ["1  2  3  4", "Switch tabs — Script · Scenes · Videos · Assemble"],
  ["A", "Approve the image (in the large image view)"],
  ["R", "Regenerate the image (in the large image view)"],
  ["← / →", "Large image: previous / next version"],
  ["Space / K", "Preview: play / pause"],
  ["← / →", "Preview: seek −5s / +5s"],
  ["F", "Preview: fullscreen"],
  ["M", "Preview: mute / unmute"],
  ["I", "Preview: images-only on/off"],
  ["Ctrl/⌘ + Z", "Undo the last change (delete, reorder, prompts…)"],
  ["Ctrl/⌘ + Shift + Z  ·  Ctrl + Y", "Redo"],
  ["?", "Show this shortcuts list"],
  ["Esc", "Close dialogs"],
];
(function buildShortcutHelp() {
  const bg = document.createElement("div");
  bg.className = "modal-bg"; bg.id = "shortcutHelp"; bg.hidden = true;
  const rows = SHORTCUTS.map(([k, d]) => `<div class="sc-row"><kbd>${k}</kbd><span>${d}</span></div>`).join("");
  bg.innerHTML = `<div class="modal confirm-modal"><h3>⌨ Keyboard Shortcuts</h3><div class="sc-list">${rows}</div><div class="modal-actions"><button class="primary" id="scClose">Got it</button></div></div>`;
  document.body.appendChild(bg);
  bg.addEventListener("click", (e) => { if (e.target === bg) closeShortcutHelp(); });
  bg.querySelector("#scClose").addEventListener("click", closeShortcutHelp);
  const host = $(".tb-btns") || $(".tb-right"), reload = $("#reloadBtn"), left = $(".tb-left");
  let cdd = null;   // Credits dropdown — built inside if(host) below, but appended in the if(left) block, so it must live in this outer scope
  if (host) {   // Undo + Redo sit next to Reload on the right
    const ub = document.createElement("button"); ub.className = "ghost"; ub.id = "undoBtn"; ub.textContent = "↩ Undo"; ub.disabled = true;
    ub.addEventListener("click", doUndo); host.insertBefore(ub, reload || null);
    const rb = document.createElement("button"); rb.className = "ghost"; rb.id = "redoBtn"; rb.textContent = "↪ Redo"; rb.disabled = true;
    rb.addEventListener("click", doRedo); host.insertBefore(rb, reload || null);
    // History dropdown — recent image/video generation results; sits after Reload, opens a panel below it
    const dd = document.createElement("div"); dd.className = "hist-dd"; dd.id = "histDD";
    const hb = document.createElement("button"); hb.className = "ghost"; hb.id = "historyBtn"; hb.title = "Recent activity — generation results and notifications"; hb.textContent = "🕘 History";
    hb.addEventListener("click", (e) => { e.stopPropagation(); toggleHistory(); });
    const menu = document.createElement("div"); menu.className = "hist-menu"; menu.id = "histMenu";
    dd.appendChild(hb); dd.appendChild(menu);
    // Credits dropdown — live Kie.ai balance + spend history for the OPEN project's key; sits to History's right
    cdd = document.createElement("div"); cdd.className = "hist-dd credit-dd"; cdd.id = "creditDD";
    const cb = document.createElement("button"); cb.className = "ghost"; cb.id = "creditBtn"; cb.innerHTML = '<span class="tb-emoji">💳</span>Credits';
    cb.addEventListener("click", (e) => { e.stopPropagation(); toggleCredits(); });
    const cmenu = document.createElement("div"); cmenu.className = "hist-menu credit-menu"; cmenu.id = "creditMenu";
    cdd.appendChild(cb); cdd.appendChild(cmenu);
    // Wrap the Undo/Redo/Reload row + a History|Credits row into a column so they span EXACTLY the trio's
    // width (CSS align-items:stretch — zoom-proof, no pixel measuring that Ctrl-zoom would skew).
    const tbBtns = document.querySelector(".tb-btns");
    if (tbBtns && tbBtns.parentNode) {
      const stack = document.createElement("div"); stack.className = "tb-stack";
      tbBtns.parentNode.insertBefore(stack, tbBtns);
      stack.appendChild(tbBtns); stack.appendChild(dd);   // History spans the full trio width below it
    } else if (reload && reload.parentNode) reload.after(dd);
    else host.appendChild(dd);
  }
  if (left) {   // Shortcuts + Credits at the FAR LEFT of the header
    const b = document.createElement("button"); b.className = "ghost"; b.id = "shortcutBtn"; b.title = "Keyboard shortcuts (?)"; b.textContent = "⌨ Shortcuts"; b.addEventListener("click", toggleShortcutHelp);
    left.appendChild(b);
    if (cdd) left.appendChild(cdd);   // Credits dropdown sits next to Shortcuts (its panel anchors to the left)
  }
})();
function toggleShortcutHelp() { const h = $("#shortcutHelp"); if (h) h.hidden = !h.hidden; }
function closeShortcutHelp() { const h = $("#shortcutHelp"); if (h) h.hidden = true; }

// ---------- History dropdown: recent image/video generation results; click to jump to that scene ----------
let HISTORY = [], HIST_UNREAD = 0;
const HIST_MAX = 10, HIST_TTL = 10 * 60 * 1000;   // keep the last 10 items; drop any older than 10 minutes
function purgeHistory() {
  const now = Date.now(), before = HISTORY.length;
  HISTORY = HISTORY.filter(ev => now - ev.t < HIST_TTL);
  if (HISTORY.length > HIST_MAX) HISTORY.length = HIST_MAX;
  if (HISTORY.length !== before) {
    HIST_UNREAD = Math.min(HIST_UNREAD, HISTORY.length);
    const menu = document.getElementById("histMenu");
    if (menu && menu.classList.contains("open")) renderHistory();
    updateHistBadge();
  }
}
setInterval(purgeHistory, 30000);   // periodic expiry sweep
function _histBump() {
  if (HISTORY.length > HIST_MAX) HISTORY.length = HIST_MAX;
  const menu = document.getElementById("histMenu");
  if (menu && menu.classList.contains("open")) renderHistory();   // live-update while open
  else { HIST_UNREAD++; updateHistBadge(); }                      // else flag an unread dot
}
function pushHistory(kind, id, ok) {
  HISTORY.unshift({ type: "scene", kind, id, ok, t: Date.now() });
  _histBump();
}
// mirror any toast message into the History panel as a plain (non-navigable) entry
function histLog(msg, kind) {
  const m = String(msg || "").trim();
  if (!m) return;
  HISTORY.unshift({ type: "msg", msg: m, kind, ok: kind !== "err" && kind !== "warn", t: Date.now() });
  _histBump();
}
function resetHistory() {
  HISTORY = []; HIST_UNREAD = 0; updateHistBadge();
  const m = document.getElementById("histMenu"); if (m && m.classList.contains("open")) renderHistory();
}
function updateHistBadge() { const b = document.getElementById("historyBtn"); if (b) b.classList.toggle("has-unread", HIST_UNREAD > 0); }
function histAgo(t) {
  const s = Math.max(0, (Date.now() - t) / 1000);
  const m = Math.floor(s / 60); if (m < 1) return "just now";
  if (m < 60) return m + "m ago";
  const h = Math.floor(m / 60); if (h < 24) return h + "h ago";
  return Math.floor(h / 24) + "d ago";
}
function renderHistory() {
  const menu = document.getElementById("histMenu"); if (!menu) return;
  const now = Date.now();
  HISTORY = HISTORY.filter(ev => now - ev.t < HIST_TTL);   // drop items older than 10 min when shown
  menu.innerHTML = "";
  const head = document.createElement("div"); head.className = "hist-head"; head.textContent = "Recent activity"; menu.appendChild(head);
  if (!HISTORY.length) {
    const e = document.createElement("div"); e.className = "hist-empty"; e.textContent = "No activity yet — results and messages will show up here."; menu.appendChild(e); return;
  }
  HISTORY.slice(0, HIST_MAX).forEach(ev => {
    const scene = ev.type === "scene";
    const it = document.createElement(scene ? "button" : "div");
    if (scene) it.type = "button";
    it.className = "hist-item" + (scene ? "" : " hist-msg");
    const dot = document.createElement("span"); dot.className = "hist-dot " + (ev.ok ? "ok" : "err");
    const tx = document.createElement("span"); tx.className = "hist-txt";
    tx.textContent = scene ? `${ev.kind} ${ev.ok ? "generated" : "failed"} — Scene ${ev.id}` : ev.msg;
    const tm = document.createElement("span"); tm.className = "hist-time"; tm.textContent = histAgo(ev.t);
    it.appendChild(dot); it.appendChild(tx); it.appendChild(tm);
    if (scene) {
      it.title = "Go to Scene " + ev.id + " in " + (ev.kind === "Video" ? "Videos" : "Scenes & Images");
      it.addEventListener("click", (e) => { e.stopPropagation(); histGoto(ev); });
    } else {
      it.title = ev.msg;
    }
    menu.appendChild(it);
  });
  const foot = document.createElement("div"); foot.className = "hist-foot";   // centered Clear at the very bottom
  const clr = document.createElement("button"); clr.type = "button"; clr.className = "hist-clear"; clr.textContent = "Clear";
  clr.title = "Clear activity history";
  clr.addEventListener("click", (e) => { e.stopPropagation(); resetHistory(); });
  foot.appendChild(clr); menu.appendChild(foot);
}
function openHistory() { const m = document.getElementById("histMenu"); if (!m) return; HIST_UNREAD = 0; updateHistBadge(); renderHistory(); m.classList.add("open"); document.body.classList.add("hist-open"); }
function closeHistory() { const m = document.getElementById("histMenu"); if (m) m.classList.remove("open"); document.body.classList.remove("hist-open"); }
function toggleHistory() { const m = document.getElementById("histMenu"); if (!m) return; m.classList.contains("open") ? closeHistory() : openHistory(); }
function histGoto(ev) {
  closeHistory();
  const tab = ev.kind === "Video" ? "videos" : "scenes";
  activateTab(tab);
  const sel = tab === "videos" ? `#videosList .video-row[data-id="${ev.id}"]` : `#scenesList .scene-row[data-id="${ev.id}"]`;
  setTimeout(() => {   // let the tab panel swap + render first
    const row = document.querySelector(sel);
    if (row) { row.scrollIntoView({ behavior: "smooth", block: "center" }); row.classList.add("hist-flash"); setTimeout(() => row.classList.remove("hist-flash"), 1400); }
  }, 90);
}
document.addEventListener("click", (e) => { if (!e.target.closest("#histDD")) closeHistory(); });   // click-away closes
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeHistory(); });

// ---------- Credits dropdown: live Kie.ai balance + real spend history + local generation counts ----------
function toggleCredits() { const m = document.getElementById("creditMenu"); if (!m) return; m.classList.contains("open") ? closeCredits() : openCredits(); }
function closeCredits() { const m = document.getElementById("creditMenu"); if (m) m.classList.remove("open"); document.body.classList.remove("hist-open"); }
function openCredits() {
  const m = document.getElementById("creditMenu"); if (!m) return;
  m.classList.add("open"); document.body.classList.add("hist-open");
  renderCredits();
}
function creditAgo(t) { return histAgo(t * 1000); }   // ledger stamps are epoch SECONDS
function localGenCounts() {
  let imgs = 0, vids = 0;
  (DOC && DOC.scenes || []).forEach(s => {
    imgs += ((s.image && s.image.versions) || []).length;
    if (s.video && (s.video.file || s.video.status === "ready")) vids += 1;   // one file per scene (overwritten on regen)
  });
  return { imgs, vids };
}
async function renderCredits() {
  const menu = document.getElementById("creditMenu"); if (!menu) return;
  menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Loading…</div>`;
  if (!PROJECT) { menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Open a project first.</div>`; return; }
  let r; try { r = await api.credits(PROJECT); } catch (e) { r = { error: "request failed" }; }
  const g = localGenCounts();
  const localBlock =
    `<div class="cr-sec-t">This project (generated)</div>
     <div class="cr-local"><span>${g.imgs} image${g.imgs === 1 ? "" : "s"}</span><span>${g.vids} video${g.vids === 1 ? "" : "s"}</span></div>
     <div class="cr-note">Local count of what this project has generated.</div>`;
  if (r && r.keyPresent === false) {
    menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">This project has no Kie API key.<br>Add it under Settings → API Keys.</div>`;
    return;
  }
  if (!r || r.error) {
    menu.innerHTML = `<div class="hist-head">Credits</div><div class="hist-empty">Couldn't reach Kie.ai${r && r.error ? " (" + r.error + ")" : ""}.<br>Try again shortly.</div>` +
      `<div class="cr-refresh-wrap"><button class="cr-refresh">↻ Refresh</button></div>`;
    menu.querySelector(".cr-refresh").addEventListener("click", (e) => { e.stopPropagation(); renderCredits(); });
    return;
  }
  const bal = (r.balance != null) ? r.balance.toLocaleString(undefined, { maximumFractionDigits: 2 }) : "—";
  let spendRows;
  if (r.history && r.history.length) {
    spendRows = r.history.map(h =>
      `<div class="cr-spend"><span class="cr-dot"></span><span class="cr-amt">−${h.spent.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span><span class="cr-bal">→ ${h.balance.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span><span class="cr-time">${creditAgo(h.t)}</span></div>`
    ).join("");
  } else {
    spendRows = `<div class="cr-empty">No spend recorded yet. It builds up as your balance changes while the app is open.</div>`;
  }
  const tracked = (r.tracked_spend || 0).toLocaleString(undefined, { maximumFractionDigits: 2 });
  menu.innerHTML =
    `<div class="hist-head">Credits</div>
     <div class="cr-balance"><span class="cr-bal-num">${bal}</span><span class="cr-bal-lbl">credits left · Kie.ai</span></div>
     ${localBlock}
     <div class="cr-sec-t">Spending history <span class="cr-tracked">${tracked} tracked</span></div>
     <div class="cr-spend-list">${spendRows}</div>
     <div class="cr-refresh-wrap"><button class="cr-refresh">↻ Refresh</button></div>`;
  menu.querySelector(".cr-refresh").addEventListener("click", (e) => { e.stopPropagation(); renderCredits(); });
}
document.addEventListener("click", (e) => { if (!e.target.closest("#creditDD")) closeCredits(); });   // click-away closes
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeCredits(); });
function pvSeekBy(delta) {
  if (!PV.m) return;
  const vo = $("#pvVo");
  const t = Math.min(PV.m.duration, Math.max(0, (vo.currentTime || 0) + delta));
  PV.seg = -1; PV.cap = -1;
  vo.currentTime = t; pvRender(t);
  if (!vo.paused) pvPlay();
}
function _typing(e) { const t = e.target; return t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable); }
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !_typing(e)) { e.preventDefault(); if (e.shiftKey) doRedo(); else doUndo(); return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y" && !_typing(e)) { e.preventDefault(); doRedo(); return; }
  if (_typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
  const help = $("#shortcutHelp");
  if (e.key === "Escape") { if (help && !help.hidden) closeShortcutHelp(); return; }
  if (e.key === "?") { e.preventDefault(); toggleShortcutHelp(); return; }
  // don't hijack keys while a dialog/lightbox is open, or on the home screen
  const dialogOpen = (help && !help.hidden) || [...document.querySelectorAll(".modal-bg")].some(m => !m.hidden) || $$(".lightbox").length > 0;
  if (dialogOpen || document.body.classList.contains("on-home") || !PROJECT) return;
  if (["1", "2", "3", "4"].includes(e.key)) {
    e.preventDefault();
    activateTab(["script", "scenes", "videos", "export"][+e.key - 1]);
    return;
  }
  // preview controls (only when the Assemble tab with a built preview is active)
  if (PV.m && $("#tab-export").classList.contains("active")) {
    const k = e.key.toLowerCase();
    if (e.key === " " || k === "k") { e.preventDefault(); pvToggle(); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); pvSeekBy(-5); }
    else if (e.key === "ArrowRight") { e.preventDefault(); pvSeekBy(5); }
    else if (k === "f") { e.preventDefault(); pvFull(); }
    else if (k === "m") { e.preventDefault(); pvMute(); }
    else if (k === "i") { e.preventDefault(); pvImagesOnly(); }
  }
});

// Single-page login: the form lives inside the home. On success the form fades out, the project
// list + app chrome appear IN PLACE, and boot() fills the list — the pipeline animation + title
// never restart (same elements throughout), so it feels like one continuous page, not two.
function wireLoginGate() {
  const form = document.getElementById("homeLogin");
  if (!form) { boot(); return; }                         // safety: no form rendered → just boot
  // remember the last username/password (desktop app asks to sign in every launch, so pre-fill it)
  try {
    const su = localStorage.getItem("savedUser"), sp = localStorage.getItem("savedPass");
    if (su && form.username) form.username.value = su;
    if (sp && form.password) form.password.value = sp;
    if (su && sp) { const b = form.querySelector("button[type=submit]"); if (b) setTimeout(() => b.focus(), 50); }
  } catch (_) {}
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]");
    const err = document.getElementById("loginErr");
    if (err) err.hidden = true;
    // native validation is off (no OS-language "fill this field" popups) → check here, in English
    if (!(form.username.value || "").trim() || !(form.password.value || "")) {
      if (err) { err.textContent = "Enter your username and password."; err.hidden = false; }
      return;
    }
    btn.disabled = true;
    try {
      const r = await fetch("/login", { method: "POST", body: new FormData(form) });
      if (r.ok) {
        window.AUTHED = true;
        try { localStorage.setItem("savedUser", form.username.value || ""); localStorage.setItem("savedPass", form.password.value || ""); } catch (_) {}
        // Sign-in is a fresh start → land on the project picker (home), not the last-opened project.
        try { localStorage.removeItem("lastProject"); localStorage.removeItem("lastTab"); localStorage.removeItem("lastTitle"); } catch (_) {}
        document.body.classList.remove("pre-auth");      // reveal header/tabs + the project list
        const sub = document.querySelector(".home-sub"); // cross-fade the subtitle text
        if (sub) { sub.style.opacity = "0"; setTimeout(() => { sub.textContent = "Open a project or create a new one"; sub.style.opacity = "1"; }, 220); }
        form.classList.add("login-hide");                // fade the form out FIRST, then load the
        setTimeout(() => { form.remove(); boot(); }, 300); // projects so they glide into the recentered space (no jump)
        return;
      }
      const d = await r.json().catch(() => ({}));
      if (err) { err.textContent = ((d && d.error) || "Wrong username or password.") + " [" + r.status + "]"; err.hidden = false; }
    } catch (ex) {
      if (err) { err.textContent = "Couldn't reach the server (" + (ex && ex.message ? ex.message : ex) + ")."; err.hidden = false; }
    }
    btn.disabled = false;
  });
}

if (window.AUTHED === false) wireLoginGate();
else boot();
