/* Background is drawn from the foreground decoder: no second video can drift. */
window.PortraitVideo = (()=>{
  function clear(v){
    const p=v._portrait;if(!p)return;p.abort.abort();if(p.frame&&v.cancelVideoFrameCallback)v.cancelVideoFrameCallback(p.frame);
    if(p.mountFrame)cancelAnimationFrame(p.mountFrame);p.resize?.disconnect();
    if(p.poster){p.poster.onload=null;p.poster.onerror=null;}p.poster=null;
    p.canvas.remove();p.matte.remove();v._portrait=null;v.classList.remove('portrait-foreground');
    for(const k of ['position','width','height','left','top','right','bottom','transform','object-fit','max-width','max-height','z-index'])v.style.removeProperty(k);
  }
  function apply(v,f,c){
    const w=v.videoWidth,h=v.videoHeight;
    const on=v.tagName==='VIDEO'&&v._portraitVideoAllowed&&h>w&&w/h<c.width/c.height-.01&&
      Math.abs(Number(f?.zoom??1)-1)<1e-6&&Math.abs(Number(f?.x??0))<1e-6&&Math.abs(Number(f?.y??0))<1e-6;
    if(!on){clear(v);return false;}
    if(!v._portrait){
      const canvas=document.createElement('canvas'),matte=document.createElement('div'),abort=new AbortController();
      canvas.className='portrait-backdrop';matte.className='portrait-matte';canvas.setAttribute('aria-hidden','true');matte.setAttribute('aria-hidden','true');
      v.before(canvas,matte);const p=v._portrait={canvas,matte,abort,frame:0,mountFrame:0,box:null,resize:null,poster:null,posterUrl:null,frameSeen:false,posterDismissed:!v.paused||v.currentTime>0||v.played.length>0};
      const defer=()=>{if(!p.mountFrame)p.mountFrame=requestAnimationFrame(()=>{p.mountFrame=0;if(v._portrait===p&&v.isConnected)draw();});};
      const watchFrame=()=>{
        // A paused metadata-only card can show its poster without decoding a
        // video frame. Subscribe to the first real frame without starting play.
        if(v.readyState>=1&&!p.frame&&v.requestVideoFrameCallback&&(!v.paused||!p.frameSeen))p.frame=v.requestVideoFrameCallback(next);
      };
      const syncPoster=()=>{
        const url=v.poster||'';if(url===p.posterUrl)return;
        if(p.poster){p.poster.onload=null;p.poster.onerror=null;}
        p.posterUrl=url;p.poster=null;
        if(url){const poster=p.poster=new Image();poster.decoding='async';poster.onload=()=>{if(v._portrait===p&&p.poster===poster)draw();};poster.src=url;}
      };
      const draw=()=>{
        if(v._portrait!==p)return;
        // Cached videos move through detached card rows during renderVideos.
        // Keep their layers/listeners and paint after the row is attached.
        const box=v.parentElement;
        if(box&&p.box!==box){
          v.before(canvas,matte);p.resize?.disconnect();p.box=box;p.resize?.observe(box);
        }
        if(!v.isConnected){if(p.frame&&v.cancelVideoFrameCallback)v.cancelVideoFrameCallback(p.frame);p.frame=0;defer();return;}
        syncPoster();watchFrame();
        // Keep the lightweight metadata preload. Until decoding starts, use the
        // exact poster already displayed by the foreground, not a second video.
        const poster=p.poster?.complete&&p.poster.naturalWidth?p.poster:null;
        // Chromium may report HAVE_ENOUGH_DATA while still displaying a poster;
        // drawImage(video) can then be transparent until its first presentation.
        const source=v.readyState>=2&&((p.frameSeen&&p.posterDismissed)||!poster)?v:poster;if(!source)return;
        const sw=source.videoWidth||source.naturalWidth,sh=source.videoHeight||source.naturalHeight;
        if(!sw||!sh||!box.clientWidth||!box.clientHeight)return;
        const cw=Math.max(2,Math.min(1200,Math.round(box.clientWidth))),ch=Math.max(2,Math.round(box.clientHeight));
        if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch;}
        const ctx=canvas.getContext('2d');
        // Overscan the blur at the image edges, leaving no transparent rim.
        const pad=24*ch/1080*3,k=Math.max((cw+2*pad)/sw,(ch+2*pad)/sh);
        ctx.clearRect(0,0,cw,ch);ctx.filter=`blur(${24*ch/1080}px)`;
        try{ctx.drawImage(source,(cw-sw*k)/2,(ch-sh*k)/2,sw*k,sh*k);}
        catch(error){
          if(error.name!=='InvalidStateError')throw error;
          if(poster){const pw=poster.naturalWidth,ph=poster.naturalHeight,pk=Math.max((cw+2*pad)/pw,(ch+2*pad)/ph);ctx.drawImage(poster,(cw-pw*pk)/2,(ch-ph*pk)/2,pw*pk,ph*pk);}
        }finally{ctx.filter='none';}
      };
      const next=()=>{p.frame=0;p.frameSeen=true;draw();};
      if(typeof ResizeObserver==='function')p.resize=new ResizeObserver(()=>{if(v._portrait===p)draw();});
      v.addEventListener('seeked',()=>{p.frameSeen=true;p.posterDismissed=true;draw();defer();},{signal:abort.signal});
      for(const e of ['timeupdate','pause'])v.addEventListener(e,draw,{signal:abort.signal});
      v.addEventListener('playing',()=>{p.posterDismissed=true;if(!v.requestVideoFrameCallback)p.frameSeen=true;draw();},{signal:abort.signal});
      for(const e of ['loadeddata','canplay'])v.addEventListener(e,()=>{draw();defer();},{signal:abort.signal});
      v.addEventListener('emptied',()=>{if(p.frame&&v.cancelVideoFrameCallback)v.cancelVideoFrameCallback(p.frame);p.frame=0;p.frameSeen=false;p.posterDismissed=false;draw();},{signal:abort.signal});
      v.addEventListener('play',draw,{signal:abort.signal});p.draw=draw;
    }
    v.classList.remove('media-framed');v.classList.add('portrait-foreground');
    Object.assign(v.style,{position:'absolute',width:'100%',height:'100%',left:'0',top:'0',right:'auto',bottom:'auto',maxWidth:'none',maxHeight:'none',objectFit:'contain',transform:'none',zIndex:'2'});
    v._portrait.draw();return true;
  }
  return {apply,clear};
})();
