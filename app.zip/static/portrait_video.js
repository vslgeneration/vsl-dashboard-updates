/* Background is drawn from the foreground decoder: no second video can drift. */
window.PortraitVideo = (()=>{
  function clear(v){
    const p=v._portrait;if(!p)return;p.abort.abort();if(p.frame&&v.cancelVideoFrameCallback)v.cancelVideoFrameCallback(p.frame);
    p.canvas.remove();p.matte.remove();v._portrait=null;v.classList.remove('portrait-foreground');
    for(const k of ['position','width','height','left','top','right','bottom','transform','object-fit','max-width','max-height','z-index'])v.style.removeProperty(k);
  }
  function apply(v,f,c){
    const w=v.videoWidth,h=v.videoHeight;
    const on=v.tagName==='VIDEO'&&v._portraitVideoAllowed&&h>w&&w/h<c.width/c.height-.01&&
      Math.abs(Number(f?.zoom??1)-1)<1e-6&&Math.abs(Number(f?.x??0))<1e-6&&Math.abs(Number(f?.y??0))<1e-6;
    if(!on){clear(v);return false;}
    if(!v._portrait){
      const canvas=document.createElement('canvas'),matte=document.createElement('div'),abort=new AbortController();
      canvas.className='portrait-backdrop';matte.className='portrait-matte';canvas.setAttribute('aria-hidden','true');matte.setAttribute('aria-hidden','true');
      v.before(canvas,matte);const p=v._portrait={canvas,matte,abort,frame:0};
      const draw=()=>{
        if(!v.isConnected){clear(v);return;}
        if(v.readyState<2)return;
        const box=v.parentElement, cw=Math.max(2,Math.min(1200,Math.round(box.clientWidth))),ch=Math.max(2,Math.round(box.clientHeight));
        if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch;}
        const ctx=canvas.getContext('2d'),scale=Math.max(cw/v.videoWidth,ch/v.videoHeight);
        // Overscan the blur at the image edges, leaving no transparent rim.
        const pad=24*ch/1080*3,k=Math.max((cw+2*pad)/v.videoWidth,(ch+2*pad)/v.videoHeight);
        ctx.clearRect(0,0,cw,ch);ctx.filter=`blur(${24*ch/1080}px)`;
        ctx.drawImage(v,(cw-v.videoWidth*k)/2,(ch-v.videoHeight*k)/2,v.videoWidth*k,v.videoHeight*k);ctx.filter='none';
      };
      const next=()=>{p.frame=0;draw();if(v._portrait===p&&!v.paused&&v.requestVideoFrameCallback)p.frame=v.requestVideoFrameCallback(next);};
      for(const e of ['loadeddata','seeked','timeupdate','pause'])v.addEventListener(e,draw,{signal:abort.signal});
      v.addEventListener('play',()=>{if(!p.frame)next();},{signal:abort.signal});p.draw=draw;
    }
    v.classList.remove('media-framed');v.classList.add('portrait-foreground');
    Object.assign(v.style,{position:'absolute',width:'100%',height:'100%',left:'0',top:'0',right:'auto',bottom:'auto',maxWidth:'none',maxHeight:'none',objectFit:'contain',transform:'none',zIndex:'2'});
    v._portrait.draw();return true;
  }
  return {apply,clear};
})();
