/* Production overlay specs, painted independently of the cached picture/audio movie. */
window.LiveOverlays = (() => {
  'use strict';
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,Number(v)||0));
  const finite=(n,d=0)=>Number.isFinite(Number(n))?Number(n):d;
  const layers={plates:11,icons:12,transitions:13,outro:14,texts:15,dips:17};
  let stage=null,video=null,host=null,model=null,entries=new Map(),resize=null,vfc=null,raf=null;
  let generation=0,lastFrame=-1,ready=Promise.resolve(),listeners=[],ownerCurrent=()=>true,geometry={x:0,y:0,scale:1};
  const pictures=new Map(),fontLoads=new Map();
  const fps=()=>model?.fps||60;
  // Chromium's currentTime rounds native 1/60 boundaries to microseconds.
  const frame=t=>Math.max(0,Math.floor(finite(t)*fps()+1e-4));
  const bound=(s,k)=>Number.isInteger(s[k+'_frame'])?s[k+'_frame']:Math.round(finite(s[k])*fps());
  const visible=(s,f)=>f>=bound(s,'start')&&f<bound(s,'end');
  const time=()=>video?.currentTime||0;
  const current=(entry)=>host&&entries.get(entry.key)===entry;
  function signal(error,spec){
    if(stage)stage.dispatchEvent(new CustomEvent('liveoverlayerror',{detail:{error:String(error?.message||error),spec}}));
  }
  function curve(points,n,def=0){
    if(!points?.length)return def;
    if(n<=points[0][0])return points[0][1];
    for(let i=1;i<points.length;i++)if(n<=points[i][0]){
      const [a,x]=points[i-1],[b,y]=points[i],u=clamp((n-a)/Math.max(1,b-a));
      return Array.isArray(x)?x.map((v,j)=>v+(y[j]-v)*u):x+(y-x)*u;
    }
    return points.at(-1)[1];
  }
  function bezier(u,c=[.25,.1,.25,1]){
    if(u<=0)return 0;if(u>=1)return 1;
    const at=(t,a,b)=>3*(1-t)*(1-t)*t*a+3*(1-t)*t*t*b+t*t*t;
    let a=0,b=1;for(let i=0;i<40;i++){const m=(a+b)/2;if(at(m,c[0],c[2])<u)a=m;else b=m;}
    return at((a+b)/2,c[1],c[3]);
  }
  function textState(spec,f){
    const a=spec.animation||{},n=f-bound(spec,'start'),count=a.frames??(bound(spec,'end')-bound(spec,'start'));
    const ni=a.in_frames||0,no=a.out_frames||0;
    let anim,u,enter=false;
    if(ni&&n<ni){anim=a.in;u=(n+.5)/ni;enter=true;}
    else if(no&&n>=count-no){anim=a.out;u=(n-(count-no)+.5)/no;}
    else return {opacity:1,x:0,y:0,scale:1};
    if(!anim)return {opacity:1,x:0,y:0,scale:1};
    const kind=anim.kind,e=bezier(u,anim.curve),state={opacity:clamp(enter?e:1-e),x:0,y:0,scale:1};
    if(kind==='pop'||kind==='popup'){
      if(enter){const p=u<=.7?bezier(u/.7,anim.curve):bezier((u-.7)/.3,anim.curve);state.scale=u<=.7?.5+.58*p:1.08-.08*p;state.opacity=u<=.7?clamp(p):1;}
      else state.scale=1-.4*e;
    }else if(kind==='slide'||String(kind).startsWith('slide-')){
      state.x=finite(anim.x)*(enter?1-e:e);state.y=finite(anim.y)*(enter?1-e:e);
    }
    return state;
  }
  function imageReady(url){
    if(pictures.has(url)){const v=pictures.get(url);pictures.delete(url);pictures.set(url,v);return v;}
    const image=new Image();const promise=new Promise((resolve,reject)=>{image.onload=()=>resolve(image);image.onerror=()=>reject(Error('Overlay artwork could not be loaded.'));});
    image.src=url;const item={image,promise};pictures.set(url,item);
    while(pictures.size>64)pictures.delete(pictures.keys().next().value);
    promise.catch(()=>{if(pictures.get(url)===item)pictures.delete(url);});return item;
  }
  function fontReady(spec){
    if(!document.fonts)return Promise.resolve();const s=spec.style||{};
    const styles=[s,...(window.OSTRich?.normalize(spec.text||'',s.ost_runs)||[]).map(run=>({...s,...run.style}))];
    return Promise.all(styles.map(st=>{
      const font=`${st.ost_italic?'italic ':''}${st.ost_bold?800:(st.ost_weight||400)} ${st.ost_size||46}px "${String(st.ost_font||'Arial').replace(/["\\]/g,'')}"`;
      if(!fontLoads.has(font))fontLoads.set(font,document.fonts.load(font));return fontLoads.get(font);
    }));
  }
  function resizePlanes(){
    if(!host||!model)return;
    const w=stage.clientWidth,h=stage.clientHeight,s=Math.min(w/model.width,h/model.height)||1;
    geometry={x:(w-model.width*s)/2,y:(h-model.height*s)/2,scale:s};
    for(const e of entries.values())positionPlane(e.plane);
  }
  function positionPlane(p){
    p.style.width=model.width+'px';p.style.height=model.height+'px';
    p.style.transform=`translate(${geometry.x}px,${geometry.y}px) scale(${geometry.scale})`;
  }
  function release(e){
    if(e.media?.tagName==='VIDEO'){e.media.pause();e.media.removeAttribute('src');e.media.load();}
    e.dispose?.();e.plane.remove();entries.delete(e.key);
  }
  function textLayout(e){
    if(!current(e))return;const s=e.spec;
    if(e.canvas){e.layout=SubtitleMotion.layout(s,s.style||{},model.width,model.height);return;}
    e.inner.style.cssText=s.inner_css||'';
    if(s.signed_layout&&window.OSTRich)OSTRich.render(e.inner,s.text||'',s.style||{});
    else if(s.html!=null)e.inner.innerHTML=s.html;
    else e.inner.textContent=s.text||'';
    if((s.style||{}).ost_runs){e.inner.style.textDecoration='none';e.inner.style.textTransform='none';}
    if(s.canonical||s._caption_policy==='speech-v998')SubtitleMotion.fitClassic(e.inner,parseFloat(getComputedStyle(e.outer).width),finite(s.style?.ost_size,46));
    else if(s.fit_narrow&&s.kind!=='caption'&&getComputedStyle(e.inner).whiteSpace==='nowrap'){
      const limit=model.width*.96,width=e.inner.scrollWidth;
      if(width>limit)e.inner.style.fontSize=(parseFloat(getComputedStyle(e.inner).fontSize)*limit/width)+'px';
    }
  }
  function make(key,type,spec){
    const plane=document.createElement('div');plane.className='lo-plane';plane.dataset.layer=type;
    plane.style.zIndex=String(layers[type]+(type==='texts'&&spec.kind==='caption'?1:0));
    if(spec.blend==='screen'||spec.motion?.blend==='screen')plane.style.mixBlendMode='screen';
    positionPlane(plane);host.append(plane);
    const e={key,type,spec,plane,promise:Promise.resolve()};entries.set(key,e);
    if(type==='texts'){
      if(spec.kind==='caption'&&window.SubtitleMotion?.enabled(spec.style||{})){
        e.canvas=document.createElement('canvas');plane.append(e.canvas);textLayout(e);
      }else{
        e.outer=document.createElement('div');e.outer.className='lo-text-outer';e.outer.style.cssText=spec.outer_css||'';
        e.inner=document.createElement('span');e.inner.className='lo-text-inner';e.outer.append(e.inner);plane.append(e.outer);textLayout(e);
      }
      e.promise=fontReady(spec).then(()=>{if(current(e)&&ownerCurrent()){textLayout(e);paintFrame(lastFrame);}});
    }else if(type==='icons'||type==='transitions'){
      if(spec.video||type==='transitions'){
        const v=document.createElement('video');v.className='lo-art';v.muted=true;v.defaultMuted=true;v.playsInline=true;v.preload='auto';v.loop=!!spec.loop;v.setAttribute('muted','');
        e.media=v;plane.append(v);
        let settled=false,resolveReady,rejectReady;
        e.promise=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject;});
        const loaded=()=>{if(!current(e))return;paintMedia(e,lastFrame);if(v.readyState>=2&&!v.seeking&&!settled){settled=true;clearTimeout(timer);resolveReady();}};
        const fail=()=>{if(!settled){settled=true;clearTimeout(timer);rejectReady(Error('Overlay video could not be decoded.'));}};
        const timer=setTimeout(fail,20000);
        for(const event of ['loadedmetadata','loadeddata','canplay','seeked'])v.addEventListener(event,loaded);
        v.addEventListener('error',fail);
        e.dispose=()=>{clearTimeout(timer);for(const event of ['loadedmetadata','loadeddata','canplay','seeked'])v.removeEventListener(event,loaded);v.removeEventListener('error',fail);if(!settled){settled=true;resolveReady();}};
        v.src=spec.url;v.load();
      }else{
        const resource=imageReady(spec.url),img=resource.image.cloneNode();img.className='lo-art';e.media=img;plane.append(img);
        e.promise=resource.promise.then(()=>{if(current(e))paintFrame(lastFrame);});
      }
    }else{e.fill=document.createElement('div');e.fill.className='lo-fill';e.fill.style.background=spec.color||'#000';plane.append(e.fill);}
    e.promise.catch(error=>{if(current(e))signal(error,spec);});return e;
  }
  function paintMedia(e,f){
    const s=e.spec,v=e.media,t=f/fps(),local=Math.max(0,t-s.start),on=visible(s,f);
    if(e.type==='transitions'){
      const ratio=Math.max(model.width/finite(s.width,model.width),model.height/finite(s.height,model.height));
      v.style.width=finite(s.width,model.width)*ratio+'px';v.style.height=finite(s.height,model.height)*ratio+'px';
      v.style.left='50%';v.style.top='50%';v.style.transform='translate(-50%,-50%)';
    }else if(s.motion){
      const m=s.motion,n=local*(m.fps||fps()),center=curve(m.center,n,[0,0]),scale=curve(m.scale,n,100)/100*finite(m.pixel_scale,1);
      v.style.width=Math.max(1,Math.round(m.source_w*scale))+'px';v.style.height=Math.max(1,Math.round(m.source_h*scale))+'px';
      v.style.left=model.width*(.5+center[0])+'px';v.style.top=model.height*(.5+center[1])+'px';
      v.style.transform=`translate(-50%,-50%) rotate(${curve(m.rotation,n,0)}deg)`;
      let alpha=curve(m.opacity,n,100)/100*(scale>0?1:0);
      if(m.exit_duration)alpha*=clamp((m.exit_start+m.exit_duration-local)/m.exit_duration);
      v.style.opacity=clamp(alpha);return;
    }else{
      v.style.width=finite(s.w,model.width)+'px';v.style.height=finite(s.h,model.height)+'px';
      v.style.left=(finite(s.x)+finite(s.rotated_w,s.w)/2)+'px';v.style.top=(finite(s.y)+finite(s.rotated_h,s.h)/2)+'px';
      v.style.transform=`translate(-50%,-50%) rotate(${finite(s.rotate)}deg) scaleX(${s.flip?-1:1})`;
    }
    if(v.tagName!=='VIDEO')return;
    const speed=finite(s.speed,1),duration=finite(s.source_duration,Number.isFinite(v.duration)?v.duration:0);
    const elapsed=local*speed,last=Math.max(0,(Number.isFinite(v.duration)?v.duration:duration)-1/fps());
    const want=s.loop&&duration>0?elapsed%duration:Math.min(elapsed,last,s.hold_at==null?Infinity:finite(s.hold_at));
    const holding=!on||video.paused||(!s.loop&&elapsed>=Math.min(last,s.hold_at??Infinity));
    if(v.readyState>=1&&!v.seeking&&Math.abs(v.currentTime-want)>(holding?.49/fps():.05))try{v.currentTime=Math.max(0,want);}catch(_){}
    v.playbackRate=speed;
    if(holding)v.pause();else if(v.paused&&!e.playing){e.playing=true;v.play().catch(error=>{if(current(e))signal(error,s);}).finally(()=>e.playing=false);}
    v.style.visibility=v.readyState>=2&&!v.seeking?'visible':'hidden';
    let alpha=1;
    if(s.fade_in)alpha*=clamp((s.loop&&duration?local%duration:local)/s.fade_in);
    if(s.fade_out)alpha*=clamp(((s.window_end??s.end)-t)/s.fade_out);
    v.style.opacity=alpha;
  }
  function paintFrame(f){
    // A pending edit invalidates async preparation, not the last accepted clock.
    // Keep that composition moving until its replacement manifest is available.
    if(!model||!host||f<0)return;
    const max=model.total_frames??Infinity;lastFrame=Math.min(f,Math.max(0,max-1));f=lastFrame;
    const desired=[],now=f/fps();let upcomingVideos=0;
    for(const type of ['plates','icons','transitions','outro','texts','dips']){
      const specs=type==='outro'?(model.outro?[model.outro]:[]):model[type]||[];
      specs.forEach((s,i)=>{
        const on=visible(s,f),movie=s.video||type==='transitions';
        const nearby=!on&&(type==='icons'||type==='transitions')&&bound(s,'start')>f&&bound(s,'start')<=f+fps();
        if(!on&&(!nearby||(movie&&upcomingVideos>=4)))return;if(nearby&&movie)upcomingVideos++;
        // Position/timing edits keep the same native decoder and decoded frame.
        const key=movie?'movie:'+JSON.stringify([type,s.scene_uid??s.scene_id??'',s.icon_index??i,s.kind??s.key??'',s.url]):type+':'+i+':'+JSON.stringify(s);
        let e=entries.get(key);if(!e)e=make(key,type,s);else{e.spec=s;e.plane.style.mixBlendMode=s.blend==='screen'||s.motion?.blend==='screen'?'screen':'normal';}
        desired.push(e);e.plane.hidden=!on;
        if(type==='icons'||type==='transitions'){
          if(type==='transitions'&&(s.speaker_windows||[]).some(w=>visible(w,f)))e.plane.hidden=true;
          paintMedia(e,f);
        }else if(type==='texts'){
          if(e.canvas){if(e.layout)SubtitleMotion.paint(e.canvas,e.layout,s.start+(f-bound(s,'start')+.5)/fps());}
          else{const q=textState(s,f);e.inner.style.opacity=q.opacity;e.inner.style.transform=`translate(${q.x}px,${q.y}px) scale(${q.scale})`;}
        }else if(type==='dips'){
          const peak=finite(s.peak),hold=finite(s.hold_until,peak);
          e.fill.style.opacity=clamp(now<peak?(now-s.start)/Math.max(1/fps(),peak-s.start):now<hold?1:1-(now-hold)/Math.max(1/fps(),s.end-hold));
        }else if(type==='outro')e.fill.style.opacity=clamp((now-s.start)/Math.max(1/fps(),s.end-s.start));
        else e.fill.style.opacity=finite(s.level,.7)*clamp(Math.min(s.fade_in?(now-s.start)/s.fade_in:1,s.fade_out?(s.end-now)/s.fade_out:1));
      });
    }
    const keep=new Set(desired.map(e=>e.key));for(const e of [...entries.values()])if(!keep.has(e.key))release(e);
    // Native movie elements must not be detached/reinserted each frame.
    desired.forEach((e,i)=>{if(host.children[i]!==e.plane)host.insertBefore(e.plane,host.children[i]||null);});
  }
  function cancelClock(){if(vfc!=null&&video?.cancelVideoFrameCallback)video.cancelVideoFrameCallback(vfc);vfc=null;if(raf!=null)cancelAnimationFrame(raf);raf=null;}
  function armClock(){
    if(!video||video.paused||!host||vfc!=null||raf!=null)return;
    const epoch=generation;
    if(video.requestVideoFrameCallback)vfc=video.requestVideoFrameCallback((_,meta)=>{vfc=null;if(epoch!==generation)return;paintFrame(frame(meta.mediaTime));armClock();});
    else raf=requestAnimationFrame(()=>{raf=null;if(epoch!==generation)return;paintFrame(frame(time()));armClock();});
  }
  function tick(t){
    if(!model)return;
    if(video&&!video.paused&&!video.seeking&&video.requestVideoFrameCallback&&lastFrame>=0){armClock();return;}
    paintFrame(frame(t));armClock();
  }
  function prepare(){
    const epoch=generation,active=[...entries.values()].filter(e=>!e.plane.hidden);
    ready=Promise.all(active.map(e=>e.promise)).then(()=>{if(epoch===generation&&host&&ownerCurrent())paintFrame(video.paused?frame(time()):lastFrame);});return ready;
  }
  function update(manifest,stillCurrent=()=>true){
    if(!host||!stillCurrent())return Promise.resolve(false);
    if(!manifest||manifest.schema!==1||!(manifest.width>0&&manifest.height>0))throw Error('Invalid live overlay manifest.');
    ownerCurrent=stillCurrent;model=manifest;resizePlanes();paintFrame(!video.paused&&lastFrame>=0?lastFrame:frame(time()));armClock();return prepare();
  }
  function mount(target,base,manifest,stillCurrent=()=>true){
    clear();stage=target;video=base;host=document.createElement('div');host.className='live-overlays';host.style.setProperty('display','block','important');stage.append(host);
    const on=(name,fn)=>{video.addEventListener(name,fn);listeners.push([name,fn]);};
    on('playing',()=>{paintFrame(frame(time()));armClock();});
    on('pause',()=>{cancelClock();paintFrame(frame(time()));});
    on('seeking',()=>{cancelClock();for(const e of entries.values())if(e.media?.tagName==='VIDEO')e.media.pause();});
    on('seeked',()=>{paintFrame(frame(time()));armClock();});
    on('loadeddata',()=>{paintFrame(frame(time()));armClock();});
    on('ended',()=>{cancelClock();paintFrame(frame(time()));});
    if(window.ResizeObserver){resize=new ResizeObserver(()=>{resizePlanes();paintFrame(lastFrame);});resize.observe(stage);}
    return update(manifest,stillCurrent);
  }
  function hitTestCaption(x,y){
    for(const e of [...entries.values()].reverse()){
      if(e.type!=='texts'||e.spec.kind!=='caption'||e.plane.hidden)continue;
      let r;if(e.inner){if(Number(e.inner.style.opacity)<=0)continue;r=e.inner.getBoundingClientRect();}
      else if(e.layout){const b=e.layout.bounds,p=stage.getBoundingClientRect();r={left:p.left+geometry.x+b.x*geometry.scale,top:p.top+geometry.y+b.y*geometry.scale,right:p.left+geometry.x+(b.x+b.width)*geometry.scale,bottom:p.top+geometry.y+(b.y+b.height)*geometry.scale};}
      if(r&&x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return e.spec;
    }return null;
  }
  function clear(){
    generation++;cancelClock();for(const [name,fn] of listeners)video?.removeEventListener(name,fn);listeners=[];
    resize?.disconnect();resize=null;for(const e of [...entries.values()])release(e);host?.remove();
    host=null;stage=null;video=null;model=null;lastFrame=-1;ownerCurrent=()=>true;ready=Promise.resolve();
  }
  return {mount,update,tick,clear,hitTestCaption,get ready(){return ready;}};
})();
