/* Stock discovery lives in VSL scenes. Account sessions are shared across this local user's projects. */
(() => {
  'use strict';
  let view = null;
  const names = {envato: 'Envato', storyblocks: 'Storyblocks', library:'Library'};
  const q = (sel, root=document) => root.querySelector(sel);
  function node(tag, cls, text) { const e=document.createElement(tag); if(cls)e.className=cls; if(text!=null)e.textContent=text; return e; }
  function button(text, fn, cls='ghost') { const e=node('button',cls,text);e.type='button';e.onclick=fn;return e; }
  async function call(url, body, signal) {
    const r=await fetch(url,body===undefined?{signal}:{method:'POST',signal,headers:body instanceof FormData?{}:{'Content-Type':'application/json'},body:body instanceof FormData?body:JSON.stringify(body)});
    let data; try {data=await r.json();} catch (_) {throw Error('The stock service could not respond. Please try again.');}
    if(!r.ok||data.error)throw Error(data.error||'Stock request failed.');return data;
  }
  function current(w) {return view===w && PROJECT===w.project && PROJECT_EPOCH===w.epoch && (DOC?.scenes||[]).some(s=>s.uid===w.uid);}
  function scene(w) {return (DOC?.scenes||[]).find(s=>s.uid===w.uid);}
  async function saveFirst() {const r=await flushSave();if(!r||r.error)throw Error('Save your scene changes before placing stock. Use Retry if saving failed.');}
  function status(w,text,bad=false) {if(!current(w))return;w.status.textContent=text;w.status.classList.toggle('stock-error',bad);}
  function close() {if(!view)return;const w=view;view=null;w.playing?.pause();clearTimeout(w.webTimer);clearTimeout(w.liveTimer);w.liveAbort?.abort();clearTimeout(w.timer);clearTimeout(w.inboxTimer);clearTimeout(w.qualityTimer);clearInterval(w.contextTimer);clearInterval(w.backgroundTimer);clearInterval(w.libraryTimer);document.removeEventListener('keydown',w.key,true);w.bg.remove();w.opener?.focus();}
  function searchUrl(provider,term,type) {
    return provider==='envato'?`https://elements.envato.com/${type==='video'?'stock-video':'photos'}/${encodeURIComponent(term)}`:
      `https://www.storyblocks.com/${type==='video'?'video':'images'}/search/${encodeURIComponent(term)}`;
  }
  function meta(w) {return {project:w.project,uid:w.uid,type:w.type.value,...(w.selected||{})};}
  async function browse(w,item) {
    if(!current(w))return;
    try {
      w.selected=item;
      const r=await call('/api/stock/browser',{...meta(w),...item});
      if(!current(w))return;
      w.ticket=r.ticket; w.seen=new Set();
      w.downloads.replaceChildren();w.downloads.hidden=false;
      const fallback=node('a','hint','Sign-in blocked here? Open the website in your browser, then import the downloaded file.');fallback.href=item.url;fallback.target='_blank';fallback.rel='noopener noreferrer';w.downloads.append(fallback);
      status(w,'Stock browser opened. Sign in if needed, preview the item and download it there. Completed downloads appear here.');
      pollInbox(w);
    } catch(e) {status(w,e.message,true);}
  }
  async function pollInbox(w) {
    clearTimeout(w.inboxTimer);if(!current(w)||!w.ticket)return;
    try {
      const r=await call(`/api/stock/inbox/${w.ticket}`);
      if(!current(w))return;
      for(const f of r.files||[]) {
        if(w.seen.has(f.file))continue;w.seen.add(f.file);
        const row=node('div','stock-download');row.append(node('strong','',f.name));
        if(f.error)row.append(node('p','hint',f.error));
        else if(f.members) {
          if(!f.members.length)row.append(node('p','hint','No supported media files in this archive.'));
          for(const m of f.members)row.append(button(`Preview ${m.name}`,()=>prepare(w,{ticket:w.ticket,file:f.file,member:m.name})));
        } else row.append(button('Preview download',()=>prepare(w,{ticket:w.ticket,file:f.file})));
        w.downloads.append(row);
      }
      if(r.status?.state==='error')status(w,r.status.message,true);
      else if(r.files?.length)status(w,'Download received. Preview it, then choose Use & approve.');
    } catch(e) {status(w,e.message,true);}
    if(current(w))w.inboxTimer=setTimeout(()=>pollInbox(w),1800);
  }
  async function previewCatalog(w,item,thumb) {
    if(!current(w))return;
    if(!item.preview){status(w,'This provider does not offer an in-app preview for this clip.');return;}
    w.playing?.pause();
    const token={};w.previewToken=token;
    if(item.provider==='library') {
      const play=q('.stock-play',thumb);if(play){play.disabled=true;play.textContent='…';}
      try {
        status(w,'Preparing Library preview…');
        let first=true;
        while(current(w)&&w.previewToken===token&&thumb.isConnected) {
          const result=await call(item.preview,first?{retry:true}:{});first=false;
          if(!current(w)||w.previewToken!==token||!thumb.isConnected)return;
          if(result.status==='error')throw Error(result.error);
          if(result.status==='ready')break;
          await new Promise(resolve=>setTimeout(resolve,800));
        }
      }catch(e){status(w,e.message,true);return;}
      finally{if(play){play.disabled=false;play.textContent='▶';}}
      if(!current(w)||w.previewToken!==token||!thumb.isConnected)return;
      status(w,'Preview Ready');
    }
    const media=node(item.type==='video'?'video':'img');media.src=item.preview;
    if(item.type==='video'){media.controls=true;media.playsInline=true;media.preload='metadata';media.poster=item.thumbnail||'';w.playing=media;}
    media.onerror=()=>{if(current(w))status(w,'Preview could not load. Try searching again.',true);};
    thumb.replaceChildren(media,node('span','stock-source',names[item.provider]||item.provider));
    if(item.type==='video'){media.play().catch(()=>{});}
  }
  async function useItem(w,item,use) {
    if(!current(w)||w.livePending||w.using||w.importing||w.applying||item.rejection||item._feedbackPending)return;
    const chosenSection=null;
    w.using=true;const controls=[...w.useButtons,w.search,w.provider,w.type,w.importButton,...w.filterFields.querySelectorAll("input,select"),w.query,w.refresh,...w.pagination.querySelectorAll('button')];controls.forEach(b=>b.disabled=true);use.textContent='Preparing…';
    status(w,'Preparing your selected stock…');
    const transfer=progressToast('Preparing Selected Stock…');transfer.update('Preparing Selected Stock…',0,true);
    try {
      await saveFirst();if(!current(w))return;
      if(item.provider==='envato')toast('Envato: Choose Download In The Stock Browser. Prefer HD; MOV Is Converted To HD MP4.','info');
      const r=await call(`/api/stock/${encodeURIComponent(w.project)}/use`,{uid:w.uid,search_job:w.job,item_id:item.id});
      while(current(w)) {
        const d=await call(`/api/stock/use/${r.job}`);if(!current(w))return;
        if(d.status==='error')throw Error(d.error);
        if(d.status==='ready') {
          w.prepared={id:d.id,section:chosenSection};use.textContent='Placing…';transfer.update('Download Complete · Placing Stock…',100);await apply(w);return;
        }
        const size=d.phase==='downloading'&&d.received?` · ${(d.received/1048576).toFixed(1)}${d.total?` / ${(d.total/1048576).toFixed(1)}`:''} MB`:'';
        use.textContent=d.percent!=null?`Downloading ${d.percent}%`:d.phase==='waiting'?'Waiting For Download…':'Preparing…';
        status(w,(d.progress||'Preparing Stock…')+size);transfer.update((d.progress||'Preparing Stock…')+size,d.percent,d.percent==null);
        await new Promise(resolve=>setTimeout(resolve,800));
      }
    }catch(e){status(w,e.message,true);if(current(w))toast(e.message,'warn');}finally{transfer.close();w.using=false;use.textContent='Use';controls.forEach(b=>b.disabled=false);if(w.provider.value==='library')w.type.disabled=true;for(const card of w.results.querySelectorAll('[data-stock-id]'))if(card._item)paintRejection(card,card._item);}
  }
  function drawResults(w,r) {
    if(['all','storyblocks','envato'].includes(r.spec?.provider))w.websiteResult=r;
    const items=['storyblocks','envato'].includes(w.provider.value)?(r.items||[]).filter(item=>item.provider===w.provider.value):(r.items||[]);
    w.results.replaceChildren();w.useButtons=[];
    w.pagination.replaceChildren();
    if(w.provider.value==='library'&&(w.query.value.trim()||r.spec?._live)&&((r.page||1)>1||r.has_more)) {
      const page=r.page||1;
      if(page>1)w.pagination.append(button('← Previous',()=>{w.page=page-1;r.spec?._live?queueLibrary(w,0,false):search(w);}));
      w.pagination.append(node('span','hint','Page '+page));
      if(r.has_more)w.pagination.append(button('Next →',()=>{w.page=page+1;r.spec?._live?queueLibrary(w,0,false):search(w);}));
    }
    for(const item of items) {
      const card=node('article','stock-card');card.dataset.stockId=item.id;card._item=item;
      const thumb=node('div','stock-thumb');
      if(item.thumbnail) {const img=node('img');img.src=item.thumbnail;img.alt='Stock '+item.type;img.loading='lazy';img.referrerPolicy='no-referrer';thumb.append(img);}
      else thumb.append(node('span','',item.type==='video'?'▶':'▧'));
      if(item.type==='video'){
        const play=button('▶',()=>previewCatalog(w,item,thumb),'stock-play');play.setAttribute('aria-label','Play stock preview');play.title=item.preview?'Play preview':'In-app preview unavailable';
        if(!item.preview)play.disabled=true;thumb.append(play);
      }else if(item.preview){const enlarge=button('⤢',()=>previewCatalog(w,item,thumb),'stock-play');enlarge.setAttribute('aria-label','View stock image');thumb.append(enlarge);}
      thumb.append(node('span','stock-source',(names[item.provider]||item.provider)+(item.observations?.watermark==='yes'?' · Watermark':'')));
      const use=button('Use',()=>useItem(w,item,use));w.useButtons.push(use);card.append(thumb);
      const evidence=node('span','stock-evidence');card.append(evidence);paintEvidence(evidence,item);
      const reject=button(item.rejection?'↶':'✕',()=>rejectClip(w,item,card,reject,use),'stock-reject ghost');
      reject.title=item.rejection?'Restore Clip':'Reject Clip';reject.setAttribute('aria-label',reject.title);
      const actions=node('div','stock-card-actions');actions.append(use,reject);card.append(actions);
      card._use=use;card._reject=reject;w.useButtons.push(reject);paintRejection(card,item);
      w.results.append(card);
    }
    w.notes.textContent=(r.warnings||[]).join(' ');
    watchQuality(w,r);
    status(w,items.length?`${items.length} ${r.type==='image'?'images':'clips'}`:'No Clips From This Source In These Results. Choose Find Candidates To Search Again.');
  }
  function paintRejection(card,item) {
    card.classList.toggle('stock-rejected',!!item.rejection);card._use.disabled=!!item.rejection||!!item._feedbackPending;
    card._reject.textContent=item.rejection?'↶':'✕';card._reject.title=item.rejection?'Restore Clip':'Reject Clip';card._reject.setAttribute('aria-label',card._reject.title);
  }
  async function rejectClip(w,item,card,reject,use) {
    if(!current(w)||w.using||w.applying||w.livePending)return;
    const old=q('.stock-rejection-menu',card);if(old){old.remove();return;}
    const version=w.configVersion,jid=w.job;let keep,change,scope;
    const submit=async(reason)=>{
      if(item._feedbackPending)return;
      item._feedbackPending=true;reject.disabled=true;use.disabled=true;
      try{
        const preference=reason&&keep?{keep:keep.value,change:change.value,scope:scope.value}:null;
        await call(`/api/stock/${encodeURIComponent(w.project)}/feedback`,{uid:w.uid,search_job:jid,item_id:item.id,reason,preference});
        if(!current(w)||version!==w.configVersion||!card.isConnected)return;
        item.rejection=reason;item._feedbackLocal=true;paintRejection(card,item);q('.stock-rejection-menu',card)?.remove();
        status(w,reason?(preference?.scope==='scene'||!preference?'Feedback Saved For This Scene · Next Search Will Use It':'Preference Saved For Similar Scenes · New Direction And Searches Will Use It'):'Clip Restored · Feedback Removed');
      }catch(e){if(current(w)&&version===w.configVersion)status(w,e.message,true);}
      finally{item._feedbackPending=false;if(current(w)&&version===w.configVersion&&!w.using&&!w.applying){reject.disabled=false;paintRejection(card,item);}}
    };
    if(item.rejection){await submit(null);return;}
    const menu=node('div','stock-rejection-menu');menu.append(node('span','hint','Why Does It Not Fit This Scene?'));
    const details=node('details','stock-feedback-details');details.append(node('summary','','Keep / Change · Optional'));
    for(const [key,label,placeholder] of [['keep','Keep','Example: Framing And Action'],['change','Change','Example: Neutral Expression, Not Smiling']]){const field=node('label','',label),input=node('textarea');input.rows=2;input.maxLength=400;input.placeholder=placeholder;input.setAttribute('aria-label',label+' In This Clip');field.append(input);details.append(field);if(key==='keep')keep=input;else change=input;}
    const label=node('label','','Use For');scope=node('select');scope.setAttribute('aria-label','Feedback Scope');for(const [value,text] of [['scene','This Scene'],['project','Similar Scenes In This Project'],['global','Similar Scenes Across My Projects']]){const option=node('option','',text);option.value=value;scope.append(option)}label.append(scope);details.append(label);menu.append(details);
    for(const [value,label] of Object.entries({wrong_action:'Wrong Action',wrong_age:'Wrong Age',wrong_mood:'Wrong Expression',wrong_setting:'Wrong Setting',too_similar:'Too Similar',not_suitable:'Not Suitable'}))menu.append(button(label,()=>submit(value),'ghost'));
    card.append(menu);
  }
  function paintEvidence(el,item) {
    const review=item.visual_review;
    const label=review?({'match':'Frames Match','uncertain':'Check Frames','mismatch':'Possible Mismatch'}[review.fit]||''):(item.visual_unavailable?'Preview Unavailable':'');
    const repeated=item.repetition==='used'?'Already Used':item.repetition==='similar'?'Similar Nearby':'';
    el.textContent=[label,repeated].filter(Boolean).join(' · ');
    el.title=review?'Sampled frames only. '+(review.reason||''):repeated;
    // Reserve this line even before review completes so the Use button never moves.
    el.hidden=false;
  }
  function qualityNote(w,state,count=0) {
    let el=q('.stock-quality-note',w.notes.parentNode);
    if(!el){el=node('div','hint stock-quality-note');w.notes.after(el);}
    el.textContent=state==='queued'||state==='running'?'Checking Top Clips · Results Are Ready To Use':
      state==='done'?`${count} Clips Checked · Sampled Frames`:state==='unavailable'?'Visual Check Unavailable · Review Clips Before Use':
      state==='stopped'||state==='cancelled'?'Visual Check Stopped':'';
  }
  function clearReviewNotes(w) {
    clearTimeout(w.qualityTimer);
    for(const cls of ['.stock-quality-note','.stock-refinement-note'])q(cls,w.notes.parentNode)?.remove();
  }
  function watchQuality(w,r) {
    clearTimeout(w.qualityTimer);qualityNote(w,r.quality_status,r.quality_reviewed||0);
    let refinement=q('.stock-refinement-note',w.notes.parentNode);
    if(!refinement&&r.refinement_status){refinement=node('div','hint stock-refinement-note');w.notes.after(refinement)}
    if(refinement)refinement.replaceChildren();
    if(['queued','running'].includes(r.refinement_status))refinement.textContent='Looking For Better Alternatives · Current Results Stay Available';
    else if(r.refinement_status==='done'&&r.refinement_added>0){const version=w.configVersion;refinement.append(button(`Show ${r.refinement_added} Additional Matches`,async()=>{if(!current(w)||version!==w.configVersion||w.using||w.applying)return;try{const next=await call('/api/stock/search/'+r.refinement_job);if(!current(w)||version!==w.configVersion||w.using||w.applying)return;w.playing?.pause();w.job=next.id;drawResults(w,next);}catch(e){if(current(w)&&version===w.configVersion)status(w,e.message,true)}},'ghost'));}
    else if(r.refinement_status==='done')refinement.textContent='No Better New Alternatives Found · Original Matches Kept';
    else if(r.refinement_status==='error')refinement.textContent='Additional Search Unavailable · Original Matches Kept';
    if(!r.id||(!['queued','running'].includes(r.quality_status)&&!['queued','running'].includes(r.refinement_status)))return;
    const version=w.configVersion,jid=r.id;
    w.qualityTimer=setTimeout(async()=>{
      if(!current(w)||version!==w.configVersion||w.job!==jid||w.using)return;
      try {
        const fresh=await call('/api/stock/search/'+jid);
        if(!current(w)||version!==w.configVersion||w.job!==jid||w.using||w.applying)return;
        for(const card of w.results.querySelectorAll('[data-stock-id]')){
          const item=fresh.items?.find(i=>i.id===card.dataset.stockId);
          if(item){
            if(card._item){
              const rejection=card._item.rejection,local=card._item._feedbackLocal||card._item._feedbackPending;
              Object.assign(card._item,item);if(local)card._item.rejection=rejection;
            }
            paintEvidence(q('.stock-evidence',card),item);
            if(card._use)paintRejection(card,card._item);
          }
        }
        // Apply improved ordering next time results are opened; never jump beneath a click/player.
        watchQuality(w,fresh);
      }catch(e){if(current(w)&&version===w.configVersion)qualityNote(w,'unavailable');}
    },2000);
  }
  function queueLibrary(w,delay=120,resetPage=true,refresh=false) {
    if(!current(w)||w.loading||w.using||w.provider.value!=='library')return;
    clearTimeout(w.liveTimer);clearTimeout(w.timer);w.liveAbort?.abort();
    const version=++w.configVersion;if(resetPage)w.page=1;
    w.searching=false;w.search.disabled=false;w.livePending=true;
    // Retain the previous thumbnails while typing, but never use them as the new query's results.
    w.results.setAttribute('aria-busy','true');w.useButtons.forEach(b=>b.disabled=true);
    w.pagination.querySelectorAll('button').forEach(b=>b.disabled=true);
    status(w,'Searching Library…');
    w.liveTimer=setTimeout(async()=>{
      const controller=new AbortController();w.liveAbort=controller;
      try {
        await w.prefSave;if(!current(w)||version!==w.configVersion)return;
        const result=await call(`/api/stock/${encodeURIComponent(w.project)}/library-search`,{uid:w.uid,...searchSpec(w),refresh},controller.signal);
        if(!current(w)||version!==w.configVersion)return;
        w.playing?.pause();w.job=result.id;w.partialId=null;drawResults(w,result);
      } catch(e) {
        if(e.name!=='AbortError'&&current(w)&&version===w.configVersion)status(w,e.message,true);
      } finally {
        if(current(w)&&version===w.configVersion){w.livePending=false;w.results.removeAttribute('aria-busy');}
      }
    },delay);
  }
  async function search(w,refresh=false) {
    clearTimeout(w.webTimer);
    if(!current(w)||w.searching||w.using||w.loading)return;
    if(w.provider.value==='library'&&(w.query.value.trim()||w.livePending)){queueLibrary(w,0,false,refresh);return;}
    clearTimeout(w.liveTimer);w.liveAbort?.abort();w.livePending=false;
    w.searching=true;w.search.disabled=true;w.playing?.pause();w.results.replaceChildren();w.notes.textContent='';clearReviewNotes(w);
    const version=++w.configVersion;if(w.provider.value!=='library')w.websiteResult=null;status(w,'Preparing this search…');
    try {
      await saveFirst();await w.prefSave;if(!current(w)||version!==w.configVersion)return;
      const r=await call(`/api/stock/${encodeURIComponent(w.project)}/search`,{uid:w.uid,...searchSpec(w),refresh});
      if(!current(w)||version!==w.configVersion)return;w.job=r.job;await pollSearch(w,r.job,version);
    }catch(e){if(current(w)&&version===w.configVersion){status(w,e.message,true);w.searching=false;w.search.disabled=false;}}
  }
  async function prepare(w, source) {
    if(!current(w)||w.importing||w.using||w.applying)return;
    w.importing=true;status(w,'Checking the media and preparing its preview…');
    try {
      await saveFirst();if(!current(w))return;
      let body;
      if(source instanceof File) {body=new FormData();body.append('file',source);Object.entries({uid:w.uid,provider:'local',title:source.name}).forEach(([k,v])=>body.append(k,v));}
      else body={...meta(w),...source};
      const r=await call(`/api/stock/${encodeURIComponent(w.project)}/prepare`,body);if(!current(w))return;
      w.prepared=r;w.preview.replaceChildren();w.preview.hidden=false;
      const media=node(r.media.type==='video'?'video':'img');media.src=`/api/stock/prepared/${r.id}/media`;
      if(r.media.type==='video'){media.controls=true;media.preload='metadata';media.poster=`/api/stock/prepared/${r.id}/poster`;w.playing?.pause();w.playing=media;}
      w.preview.append(node('h4','',r.media.title||'Selected Stock'));
      if(r.media.type==='video'){const thumb=node('div','stock-thumb');thumb.append(media);w.preview.append(thumb)}else w.preview.append(media);
      w.preview.append(node('p','hint',r.media.type==='video'?'The complete video will be used.':'This image will become a new approved version.'),
        button('Use & Approve',()=>apply(w),'primary'),button('Choose Something Else',()=>{w.prepared=null;w.playing?.pause();w.preview.hidden=true;}));
      status(w,'Preview the downloaded file. Your scene has not changed yet.');w.preview.scrollIntoView({block:'nearest',behavior:'smooth'});
    } catch(e) {status(w,e.message,true);} finally {w.importing=false;}
  }
  function adoptMedia(w,r,label) {
    if(!current(w))return false;
    const s=scene(w);if(!s||s.uid!==r.uid)return false;
    pushUndo(label);
    s.image=r.image;s.video=r.video;s.approved=r.approved;s._appLock=Date.now()+8000;
    _vidCache.delete(s.id);renderScenes();renderVideos();buildSceneJump();return true;
  }
  async function apply(w) {
    if(!current(w)||!w.prepared||w.applying)return;
    w.applying=true;w.preview.querySelectorAll('button').forEach(b=>b.disabled=true);
    status(w,'Placing stock on this scene…');
    try {
      await saveFirst();if(!current(w))return;
      const r=await call(`/api/stock/${encodeURIComponent(w.project)}/apply`,{id:w.prepared.id,uid:w.uid,section:null});
      if(adoptMedia(w,r,'use stock media')) {toast(`Stock Approved: Scene ${scene(w).id}`,'ok');close();}
    } catch(e) {status(w,e.message,true);} finally {w.applying=false;if(w.preview.isConnected)w.preview.querySelectorAll('button').forEach(b=>b.disabled=false);}
  }
  let filterOptions=null, backgroundTimer=null, backgroundProgress=null, backgroundPhase=null, backgroundState=null, backgroundRequest=0, stopping=false;
  const friendly=s=>String(s).replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
  function searchSpec(w) {return {provider:w.provider.value,type:w.type.value,query:w.query.value.trim(),filters:structuredClone(w.filters),page:w.page||1};}
  function queueWeb(w) {
    if(!current(w)||w.loading||w.using||w.applying)return;
    clearTimeout(w.webTimer);filtersChanged(w);
    if(!w.query.value.trim()){switchSource(w);return;}
    status(w,'Searching Your Keywords…');
    w.webTimer=setTimeout(()=>search(w),850);
  }
  function filtersChanged(w) {
    if(!current(w)||w.loading)return;
    clearTimeout(w.liveTimer);w.liveAbort?.abort();w.livePending=false;w.results.removeAttribute("aria-busy");
    w.page=1;w.pagination.replaceChildren();
    ++w.configVersion;clearTimeout(w.timer);w.searching=false;w.search.disabled=false;w.results.replaceChildren();w.notes.textContent='';clearReviewNotes(w);
    w.job=null;w.selected=null;w.prepared=null;w.preview.hidden=true;if(w.provider.value!=='library')w.websiteResult=null;
    const spec=searchSpec(w);
    w.prefSave=(w.prefSave||Promise.resolve()).catch(()=>{}).then(()=>call(`/api/stock/${encodeURIComponent(w.project)}/preferences`,{uid:w.uid,spec}));
    w.prefSave.catch(e=>status(w,e.message,true));status(w,'Filters saved. Choose Find Candidates to update this scene.');
    if(w.provider.value==='library')queueLibrary(w);
  }
  function renderFilters(w) {
    if(!filterOptions)return;
    w.filterFields.replaceChildren();
    const aspectLabel=w.filters.aspect==='portrait-first'?'9:16 First · Mixed':w.filters.aspect==='16:9'?'16:9 Landscape':w.filters.aspect==='9:16'?'9:16 Portrait':w.filters.aspect==='1:1'?'Square':friendly(w.filters.aspect);
    w.filterSummary.textContent='Filters · '+aspectLabel;
    const field=(label,control)=>{const box=node('label','field');box.append(node('span','',label),control);return box;};
    const aspect=node('select');aspect.setAttribute('aria-label','Aspect Ratio');
    for(const [value,label] of [['portrait-first','9:16 First (Mixed Results)'],['16:9','16:9 Landscape'],['9:16','9:16 Portrait'],['1:1','1:1 Square'],['landscape','Landscape (Any Ratio)'],['portrait','Portrait (Any Ratio)'],['any','Any Orientation']]){const o=node('option','',label);o.value=value;aspect.append(o);}
    aspect.value=w.filters.aspect;aspect.onchange=()=>{w.filters.aspect=aspect.value;w.filters.project_default=false;renderFilters(w);filtersChanged(w);};w.filterFields.append(field('Aspect Ratio',aspect));
    for(const provider of ['storyblocks','envato']) {
      if(w.provider.value!=='all'&&w.provider.value!==provider)continue;
      const group=node('fieldset','stock-provider-filters');group.append(node('legend','',names[provider]));
      const grid=node('div','stock-filter-grid');group.append(grid);
      for(const f of filterOptions[w.type.value][provider]) {
        let control;const values=w.filters[provider]||(w.filters[provider]={});
        if(!(f.key in values))values[f.key]=f.default;
        if(f.kind==='select'||f.kind==='bool'||f.kind==='multi') {
          control=node('select');if(f.kind==='multi')control.multiple=true;
          else {const option=node('option','',f.kind==='select'&&f.key==='sort_by'?'Default':'Any');option.value='';control.append(option);}
          let options=f.kind==='bool'?[['true',f.key==='is_editorial'?'Editorial Only':'Yes'],['false',f.key==='is_editorial'?'Commercial Only':'No']]:(f.options||[]).map(v=>[v,friendly(v)]);
          if(provider==='storyblocks'&&f.key==='categories'&&values.content_type&&f.groups[values.content_type])options=options.filter(([v])=>f.groups[values.content_type].includes(v));
          if(provider==='envato'&&f.key==='subcategories')options=options.filter(([v])=>{const all=filterOptions.video.envato.find(x=>x.key==='subcategories').options;const edge=all.indexOf('Backgrounds');return values.categories==='Motion Graphics'?all.indexOf(v)>=edge:all.indexOf(v)<edge;});
          for(const [value,label] of options){const option=node('option','',label);option.value=value;control.append(option);}
          if(f.kind==='multi'){for(const option of control.options)option.selected=(values[f.key]||[]).includes(option.value);}
          else control.value=values[f.key]==null?'':String(values[f.key]);
        } else {control=node('input');control.type=f.kind==='number'?'number':'text';control.value=values[f.key]??'';if(f.kind==='number'){control.min='0';control.max='3600';control.step='1';}else{control.maxLength=200;if(f.kind==='color')control.placeholder='#4A8B62';}}
        control.setAttribute('aria-label',names[provider]+' '+f.label);
        control.onchange=()=>{
          let value=control.value;
          if(f.kind==='multi')value=[...control.selectedOptions].map(x=>x.value);
          else if(value==='')value=null;
          else if(f.kind==='number')value=Number(value);
          else if(f.kind==='bool')value=value==='true';
          values[f.key]=value;
          if(provider==='storyblocks'&&f.key==='content_type'){values.categories=null;renderFilters(w);}
          if(provider==='envato'&&f.key==='categories'){values.subcategories=null;renderFilters(w);}
          filtersChanged(w);
        };
        grid.append(field(f.label,control));
      }
      w.filterFields.append(group);
    }
  }
  function paintAutomatic(data) {
    backgroundState=data;
    const prepare=q('#prepareStockBtn');
    if(prepare){prepare.disabled=!!(data.enabled&&(data.scanning||data.queued||data.running||data.review_queued||data.review_running));prepare.textContent=data.enabled&&(data.scanning||data.queued||data.running||data.review_queued||data.review_running)?'🎬 Preparing Stock…':'🎬 Prepare Stock';}
    const busy=data.enabled&&(data.scanning||data.queued||data.running||data.review_queued||data.review_running);
    if(busy) {
      const reviewOnly=!(data.scanning||data.queued||data.running);
      backgroundPhase=reviewOnly?'review':'search';
      if(!backgroundProgress)backgroundProgress=progressToast(reviewOnly?'Checking Stock Clips…':'Preparing Stock…',()=>automatic({stop:true}));
      const label=data.stopping?'Stopping Stock · Waiting For Current Request…':reviewOnly?`Checking Stock Clips · ${data.review_done||0} Checks Done`+(data.current_project?' · '+data.current_project:''):data.scanning?'Preparing Stock · Checking Scenes…':`Preparing Stock · ${data.ready}/${data.total} Scenes Ready`+(data.library_total?` · Library ${data.library_ready}/${data.library_total}`:'')+(data.review_queued||data.review_running?` · Checking Clips ${data.review_done||0} Done`:'')+(data.current_project?' · '+data.current_project:'');
      const totalChecks=(data.review_done||0)+(data.review_queued||0)+(data.review_running||0);
      backgroundProgress.update(label,data.scanning||data.stopping?null:reviewOnly?(totalChecks?100*(data.review_done||0)/totalChecks:null):(data.total?100*data.ready/data.total:null));
    } else if(backgroundProgress) {
      const phase=backgroundPhase;backgroundProgress.close();backgroundProgress=null;backgroundPhase=null;
      if(data.paused)toast('Stock Preparation Paused: '+data.paused,'warn');
      else if(!data.enabled)toast('Stock Preparation Stopped','info');
      else if(data.needs_attention)toast(`Stock Preparation Finished · ${data.ready}/${data.total} Scenes Ready · ${data.needs_attention} Searches Need Attention. Use Prepare Stock To Retry.`, 'warn');
      else if(data.review_paused)toast('Stock Results Ready · Visual Checks Paused. Use Prepare Stock To Resume.','warn');
      else if(phase==='review')toast('Stock Clip Checks Finished','ok');
      else if(data.total&&data.ready===data.total)toast(`Stock Ready · ${data.ready} Scenes · ${data.project||PROJECT}`,'ok');
      else if(data.total)toast(`Stock Preparation Finished · ${data.ready}/${data.total} Scenes Ready`,'info');
    }
  }
  async function automatic(body) {
    if(body?.stop&&stopping)return;
    if(body?.stop){stopping=true;backgroundProgress?.update('Stopping Stock…',null);}
    const project=body?.project||PROJECT;
    if(!project||projectPtype()==='youtube')return;
    const serial=++backgroundRequest;clearTimeout(backgroundTimer);
    try {
      const data=await call('/api/stock/background'+(body?'':'?project='+encodeURIComponent(project)),body?{...body,project}:undefined);
      if(serial!==backgroundRequest||PROJECT!==project)return;
      paintAutomatic(data);
    } catch(e) {if(body)toast('Stock Preparation: '+e.message,'warn');}
    finally {
      if(body?.stop)stopping=false;
      if(serial===backgroundRequest&&PROJECT===project)backgroundTimer=setTimeout(()=>automatic(),4000);
    }
  }
  async function switchSource(w) {
    if (!current(w) || w.using || w.applying) return;
    const provider=w.provider.value, type=provider==='library'?'video':w.type.value,query=w.query.value.trim();
    clearTimeout(w.webTimer);
    w.playing?.pause();clearTimeout(w.timer);clearTimeout(w.liveTimer);w.liveAbort?.abort();
    const version=++w.configVersion;
    w.searching=false;w.livePending=false;w.job=null;w.partialId=null;w.selected=null;w.prepared=null;
    w.results.replaceChildren();w.pagination.replaceChildren();w.notes.textContent='';w.preview.hidden=true;clearReviewNotes(w);
    w.results.removeAttribute('aria-busy');w.useButtons=[];w.loading=true;w.search.disabled=true;
    w.type.value=type;w.type.disabled=provider==='library';w.libraryStatus.hidden=provider!=='library';
    status(w,'Loading '+(names[provider]||'Website')+' Results…');
    let missing=false;
    try {
      await w.prefSave;
      if(!current(w)||version!==w.configVersion)return;
      if(query){w.page=1;renderFilters(w);w.loading=false;await search(w);return;}
      if(provider!=='library'&&w.websiteResult?.type===type&&!w.websiteResult.spec?.query&&['all',provider].includes(w.websiteResult.spec?.provider)) {
        const result=w.websiteResult,spec={...result.spec,provider};
        w.query.value=spec.query;w.filters=structuredClone(spec.filters);w.page=spec.page||1;renderFilters(w);
        w.job=result.id;drawResults(w,result);
        w.prefSave=call(`/api/stock/${encodeURIComponent(w.project)}/preferences`,{uid:w.uid,spec});
        await w.prefSave;return;
      }
      // Empty input always means the scene's saved recommendations, not an old keyword search.
      const requested={...searchSpec(w),query:'',page:1};
      w.prefSave=call(`/api/stock/${encodeURIComponent(w.project)}/preferences`,{uid:w.uid,spec:requested});await w.prefSave;
      if(!current(w)||version!==w.configVersion)return;
      const state=await call(`/api/stock/${encodeURIComponent(w.project)}/state/${encodeURIComponent(w.uid)}?provider=${encodeURIComponent(provider)}&type=${encodeURIComponent(type)}`);
      if(!current(w)||version!==w.configVersion)return;
      const spec=state.spec;w.query.value=spec.query;w.filters=spec.filters;w.page=spec.page||1;renderFilters(w);
      w.prefSave=call(`/api/stock/${encodeURIComponent(w.project)}/preferences`,{uid:w.uid,spec});
      await w.prefSave;
      if(!current(w)||version!==w.configVersion)return;
      if(state.result){w.job=state.result.id;drawResults(w,state.result);}
      if(state.job){w.searching=true;pollSearch(w,state.job,version);}
      else missing=!state.result;
    } catch(e){if(current(w)&&version===w.configVersion)status(w,e.message,true);}
    finally {
      if(current(w)&&version===w.configVersion){
        w.loading=false;w.search.disabled=w.searching;
        if(missing&&provider==='library')search(w); // Web source changes only filter already prepared candidates.
        else if(missing)status(w,'No Saved Results For This Source. Choose Find Candidates To Search This Scene.');
      }
    }
  }
  async function restoreSearch(w) {
    let startMissing=false;
    w.loading=true;w.search.disabled=true;w.provider.disabled=true;w.type.disabled=true;status(w,'Loading saved stock searches…');
    try {
      const [options,state]=await Promise.all([filterOptions||call('/api/stock/filter-options'),call(`/api/stock/${encodeURIComponent(w.project)}/state/${encodeURIComponent(w.uid)}`)]);
      if(!current(w))return;filterOptions=options;
      // While a search is active, only restore cached cards for that exact search.
      const saved=state.job?state.result:(state.last_result||state.result), spec=(state.source_filter?state.spec:(!state.job&&saved?.spec))||state.spec;
      w.provider.value=spec.provider;w.type.value=spec.type;w.query.value=spec.query;w.filters=spec.filters;w.page=spec.page||1;w.libraryStatus.hidden=spec.provider!=='library';renderFilters(w);
      if(saved){w.job=saved.id;drawResults(w,saved);}
      else {startMissing=!state.job;status(w,'Finding Stock For This Scene…');}
      if(state.job){w.searching=true;pollSearch(w,state.job,w.configVersion);}
    }catch(e){status(w,e.message,true);}finally{w.loading=false;if(current(w)){w.search.disabled=w.searching;w.provider.disabled=false;w.type.disabled=w.provider.value==='library';if(startMissing)search(w);}}
  }
  async function pollSearch(w,jid,version) {
    if(!current(w)||version!==w.configVersion)return;
    try {
      const data=await call(`/api/stock/search/${jid}`);if(!current(w)||version!==w.configVersion)return;
      if(w.using){w.timer=setTimeout(()=>pollSearch(w,jid,version),400);return;}
      if(data.status==='error')throw Error(data.error);
      if(['cancelled','paused'].includes(data.status))throw Error(data.progress||'Search paused. Choose Find Candidates to try again.');
      if(data.status==='done'){w.job=jid;drawResults(w,data);w.searching=false;w.search.disabled=false;return;}
      if(data.partial?.items?.length&&w.partialId!==jid){w.job=jid;w.partialId=jid;drawResults(w,data.partial);}
      status(w,data.progress||'Searching…');w.timer=setTimeout(()=>pollSearch(w,jid,version),data.spec?.provider==='library'&&data.spec.query?150:1200);
    }catch(e){if(current(w)&&version===w.configVersion){status(w,e.message,true);w.searching=false;w.search.disabled=false;}}
  }
  function projectReady({afterSplit=false}={}) {
    const prepare=q('#prepareStockBtn');if(prepare)prepare.hidden=!PROJECT||projectPtype()==='youtube';
    if(PROJECT&&DOC&&projectPtype()!=='youtube')automatic({project:PROJECT,observe:true,after_split:afterSplit});
  }
  let automaticStarted=false;
  function start() {if(!automaticStarted){automaticStarted=true;automatic();}}

  function open(s,opener) {
    if(projectPtype()==='youtube'||!PROJECT)return;
    close();
    const w={project:PROJECT,epoch:PROJECT_EPOCH,uid:s.uid,opener,seen:new Set(),useButtons:[]};view=w;
    w.bg=node('div','stock-bg');w.panel=node('section','stock-panel');w.panel.setAttribute('role','dialog');w.panel.setAttribute('aria-modal','true');w.panel.setAttribute('aria-label',`Stock for Scene ${s.id}`);
    const header=node('div','stock-heading');header.append(node('h3','',`Find Stock · Scene ${s.id}`),button('✕',()=>{if(!w.applying)close();}));
    w.panel.append(header,node('p','stock-scene',s.vo||'This scene has no script text yet. Enter a search below.'));
    const filters=node('div','stock-filters');
    const select=(label,values)=>{const field=node('label','field');field.append(node('span','',label));const sel=node('select');for(const [v,t] of values){const o=node('option','',t);o.value=v;sel.append(o);}field.append(sel);filters.append(field);return sel;};
    w.provider=select('Source',[['all','All Sources · Storyblocks First'],['storyblocks','Storyblocks'],['envato','Envato'],['library','Library']]);
    w.type=select('Media',[['video','Video'],['image','Image']]);
    w.query=node('input');w.query.type='search';w.query.placeholder='Optional: enter your own search';w.query.setAttribute('aria-label','Stock search');
    w.query.oninput=e=>{if(!e.isComposing)w.provider.value==='library'?queueLibrary(w):queueWeb(w);};
    w.query.oncompositionend=()=>{w.provider.value==='library'?queueLibrary(w):queueWeb(w);};
    w.query.onkeydown=e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();w.provider.value==='library'?queueLibrary(w,0):search(w);}};
    w.configVersion=0;w.filters={aspect:projectImageAspect()==='9:16'?'portrait-first':'16:9',storyblocks:{},envato:{}};
    w.provider.onchange=()=>switchSource(w);
    w.type.onchange=()=>{w.filters={aspect:w.type.value==='video'?(projectImageAspect()==='9:16'?'portrait-first':'16:9'):'landscape',storyblocks:{},envato:{}};renderFilters(w);filtersChanged(w);};
    const searchRow=node('div','stock-search');w.search=button('Find Candidates',()=>search(w),'primary');w.refresh=button('Refresh Results',()=>search(w,true));searchRow.append(w.query,w.search,w.refresh);
    w.status=node('p','stock-status','Find candidates uses the scene, its visual direction and your target audience.');w.status.setAttribute('role','status');
    w.notes=node('p','stock-notes hint');w.results=node('div','stock-results');w.pagination=node('div','stock-pagination');w.downloads=node('div','stock-downloads');w.preview=node('div','stock-selected');w.preview.hidden=true;
    w.libraryStatus=node('p','hint');w.libraryStatus.hidden=true;
    const libraryStatus=async()=>{try{const r=await call('/api/stock/library/status');if(!current(w))return;w.libraryStatus.textContent=r.configured?`Library · ${r.ready} Videos Available · ${r.reviewed} Visually Reviewed`+(['copying','preparing','reviewing'].includes(r.index?.state)||r.copy?.state==='copying'?' · Preparing…':''):'Library is not connected on this computer.';}catch(_){}};
    libraryStatus();w.libraryTimer=setInterval(libraryStatus,10000);
    const local=node('div','stock-local');const file=node('input');file.type='file';file.hidden=true;file.accept='.mp4,.mov,.m4v,.webm,.png,.jpg,.jpeg,.webp';
    file.onchange=()=>{const f=file.files[0];file.value='';if(f)prepare(w,f);};
    w.importButton=button('Import downloaded file',()=>file.click());
    local.append(w.importButton,node('span','hint','Already downloaded? Choose the original video or image.'),file);
    const filterBox=node('details','stock-filter-box');w.filterSummary=node('summary','','Filters · 16:9 Landscape');w.filterFields=node('div');filterBox.append(w.filterSummary,w.filterFields,node('p','hint','Filters apply to their named provider. Catalog resolution does not change downloads: videos still use HD MP4. Templates are excluded because they are not playable stock clips.'));
    w.panel.append(filters,filterBox,searchRow,w.libraryStatus,w.status,w.notes,w.results,w.pagination,w.downloads,w.preview,local);w.bg.append(w.panel);document.body.append(w.bg);
    w.key=e=>{if(e.key==='Escape'){e.stopImmediatePropagation();if(!w.applying)close();}if((e.ctrlKey||e.metaKey)&&['z','y'].includes(e.key.toLowerCase()))e.stopImmediatePropagation();if(e.key==='Tab'){const items=[...w.panel.querySelectorAll('button,input,select,a[href],video[controls],summary')].filter(x=>!x.disabled&&x.getClientRects().length);const first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}};document.addEventListener('keydown',w.key,true);
    w.bg.onclick=e=>{if(e.target===w.bg&&!w.applying)close();};
    w.contextTimer=setInterval(()=>{if(!current(w))close();},500);w.query.focus();restoreSearch(w);
  }
  function accounts() {
    const box=node('div','stock-accounts');box.hidden=mPtype==='youtube';box.append(node('h4','','Stock Accounts'),node('p','hint','Shared across your projects on this computer. Sign in on each provider’s own page.'));
    const refresh=async()=>{
      try {const data=await call('/api/stock/accounts');if(!box.isConnected)return;
        for(const [p,s] of Object.entries(data.accounts))q(`[data-stock-state="${p}"]`,box).textContent=s.last_download?'Download verified':s.opened?'Browser session available':'Not opened yet';
      }catch(_){}
    };
    for(const p of ['storyblocks','envato']) {
      const row=node('div','stock-account-row'),state=node('span','hint','Checking…');state.dataset.stockState=p;
      row.append(node('strong','',names[p]),state,button('Sign in / open',async()=>{try{await call('/api/stock/browser',{provider:p});toast(`${names[p]} stock browser opened. Sign in on the website.`,'info');refresh();}catch(e){toastErr(e.message);}}));box.append(row);
    }
    setTimeout(refresh,0);return box;
  }
  function decorateScene(el,s) {
    if(projectPtype()==='youtube')return;
    let b=q('.find-stock',el);if(!b){b=button('🎬 Find Stock',()=>open((DOC?.scenes||[]).find(x=>x.uid===s.uid)||s,b),'ghost find-stock');q('.gen-img',el)?.parentElement.append(b);}
    const im=s.image||{},versions=im.versions||[],shownFile=versions.length?versions[im.current==null?versions.length-1:im.current]:im.file;
    const meta=im.stock_assets?.[shownFile],prev=q('.img-preview',el);
    q('.stock-scene-tag',el)?.remove();
    if(!meta||!prev)return;
    const tag=node('span','stock-scene-tag',`${names[meta.provider]||'Stock'} · ${meta.type==='video'?'video':'image'}`);prev.append(tag);
    if(meta.type==='video') {
      const pair=Object.entries(s.video?.stock_assets||{}).find(([p,m])=>m.poster===shownFile&&(s.video.versions||[]).includes(p));
      if(pair) {
        prev.classList.remove('img-loading');
        const old=q(':scope > img, :scope > .framing-plane > img',prev);let v=q('video.stock-scene-video',prev);
        if(!v){v=node('video','stock-scene-video');v.controls=true;v.preload='none';v.poster=mediaUrl(shownFile);v.src=mediaUrl(pair[0]);v.onclick=e=>e.stopPropagation();if(old)(old.closest('.framing-plane')||old).replaceWith(v);else prev.prepend(v);renderSceneIcons(el,s);}
        const previousApprove=q('.ia.approve',prev),approve=previousApprove?.cloneNode(true);
        if(approve){previousApprove.replaceWith(approve);approve.title='Approve this stock video';approve.onclick=async(e)=>{e.stopPropagation();const project=PROJECT,epoch=PROJECT_EPOCH;try{await saveFirst();if(project!==PROJECT||epoch!==PROJECT_EPOCH)return;const r=await call(`/api/stock/${encodeURIComponent(project)}/approve`,{uid:s.uid,poster:shownFile,approved:!(s.approved&&s.video?.approved&&s.video?.approved_file===pair[0])});if(project!==PROJECT||epoch!==PROJECT_EPOCH)return;const live=DOC.scenes.find(x=>x.uid===s.uid);if(live){live.image=r.image;live.video=r.video;live.approved=r.approved;live._appLock=Date.now()+8000;renderScenes();renderVideos();}}catch(err){toastErr(err.message);}};}
        const previousDownload=q('.ia.download',prev),download=previousDownload?.cloneNode(true);
        if(download){previousDownload.replaceWith(download);download.title='Download this stock video';download.onclick=e=>{e.stopPropagation();downloadMedia(pair[0],`${pad2(s.id)}_${slug(s.vo)}.${pair[0].split('.').pop()}`,`Scene ${s.id}`);};}
      }
    }
  }
  function decorateVideo(el,s) {
    if(projectPtype()==='youtube')return;
    const poster=s.image?.approved_file||s.image?.file,meta=s.image?.stock_assets?.[poster];
    if(meta?.type!=='video')return;
    const msg=node('p','stock-ready-note','Stock video · ready to use. No AI generation needed.');q('.video-desc',el)?.closest('.field')?.before(msg);
    for(const sel of ['.gen-vid','.gen-vid-prompt','.video-edit-apply']) {const b=q(sel,el);if(b){b.disabled=true;b.title='This scene already uses stock video. Approve an image in Scene & Image to animate it instead.';}}
    const change=q('.vid-preview .ia.change',el);
    if(change){const replacement=change.cloneNode(true);change.replaceWith(replacement);replacement.title='Choose different stock media';replacement.onclick=e=>{e.stopPropagation();open(s,replacement);};}
  }
  const prepareStock=q('#prepareStockBtn');
  if(prepareStock)prepareStock.onclick=()=>{
    if(!PROJECT||projectPtype()==='youtube')return;
    q('#sceneTools')?.removeAttribute('open');automatic({project:PROJECT,resume:true,library:true});
  };
  window.Stock={open,accounts,decorateScene,decorateVideo,close,projectReady,start};
  if(window.AUTHED===true)start();
})();
