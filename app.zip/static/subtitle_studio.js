/* One caption-only editor and the projectless finished-video subtitle workspace. */
(() => {
  'use strict';
  const esc = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const time = n => {const cent=Math.round(Math.max(0,Number(n)||0)*100);return `${String(Math.floor(cent/6000)).padStart(2,'0')}:${String(Math.floor(cent/100)%60).padStart(2,'0')}.${String(cent%100).padStart(2,'0')}`;};
  const seconds = text => {const parts=String(text).trim().replace(',','.').split(':');if(parts.length>3||parts.some(v=>!/^\d+(\.\d+)?$/.test(v)))return NaN;return parts.reduce((n,v)=>n*60+Number(v),0);};
  async function json(url,body) {
    const r=await fetch(url,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    let data;try{data=await r.json();}catch(_){throw Error('The application could not complete this request.');}
    if(!r.ok||data.error)throw Error(data.error||'Request failed.');return data;
  }
  function autoWindow(cue,value) {
    const norm=s=>String(s).normalize('NFKC').toLowerCase().replace(/ı/g,'i').replace(/[^\p{L}\p{N}]/gu,'');
    const wanted=String(value).split(/\s+/).map(norm).filter(Boolean);
    const words=(cue.words||[]).filter(w=>norm(w.text)&&Number.isFinite(w.start)&&Number.isFinite(w.end));
    if(!wanted.length||!words.length||wanted.length>words.length)return null;
    const all=words.map(w=>norm(w.text)),indices=[];let pos=0;
    for(const token of wanted){const i=all.indexOf(token,pos);if(i<0)return null;indices.push(i);pos=i+1;}
    const first=indices[0],last=indices.at(-1);
    // A unique retained substring disambiguates repeated opening words.
    const hits=[];for(let i=0;i<=all.length-wanted.length;i++)if(wanted.every((w,j)=>all[i+j]===w))hits.push(i);
    let a=first,b=last;if(hits.length===1){a=hits[0];b=a+wanted.length-1;}
    const start=a===0?cue.start:Math.max(cue.start,words[a].start);
    const end=b===words.length-1?cue.end:Math.min(cue.end,words[b].end);
    return end-start>=1/60?{start,end,estimated:words.slice(a,b+1).some(w=>!w.aligned)}:null;
  }
  function editor({stage,cue,project,playhead,current,apply,reload,duration,sourceTime=t=>t,displayTime=t=>t}) {
    if(!cue.display_new&&(!cue.display_id||!cue.display_base)){toast('Refresh The Preview To Enable Caption Editing.','info');return;}
    document.querySelector('.caption-editor-bg')?.remove();
    const custom=!!(cue.display_new||cue.display_custom),base={start:0,end:duration},span=base.end-base.start;
    const box=document.createElement('div');box.className='pv-caption-editor subtitle-display-editor';
    box.setAttribute('role','dialog');box.setAttribute('aria-label','Edit Caption Only');
    box.innerHTML=`<strong>${cue.display_new?'Add Caption':'Edit Caption'}</strong><p class="hint">Caption only · Enter starts a new line. Script, scenes and voice-over stay unchanged.</p><textarea aria-label="Subtitle Text"></textarea>
      <div class="caption-word-buttons" aria-label="Click A Word To Remove It"></div>
      <label class="caption-auto-timing"><input type="checkbox" checked>Auto Timing · Fit To Remaining Words</label>
      <p class="caption-auto-note hint">Click a word to remove it. Drag the handles to fine-tune the timing.</p>
      <div class="caption-range-track"><div class="caption-range-selection"></div><input type="range" class="caption-range-start" aria-label="Drag Caption Start"><input type="range" class="caption-range-end" aria-label="Drag Caption End"></div>
      <div class="caption-time-fields"><label>Start<input aria-label="Caption Start" value="${time(cue.start)}"><button type="button" class="ghost" data-clock="start">Use Playhead</button></label><label>End<input aria-label="Caption End" value="${time(cue.end)}"><button type="button" class="ghost" data-clock="end">Use Playhead</button></label></div>
      <p class="hint">Available time: ${time(base.start)} – ${time(base.end)}</p><p class="caption-edit-error" role="alert"></p>
      <div class="caption-edit-actions"><button type="button" class="ghost" data-action="reset">Reset</button><button type="button" class="ghost" data-action="hide">Hide Caption</button><button type="button" class="ghost" data-action="delete">Delete Caption</button><button type="button" class="ghost" data-action="cancel">Cancel</button><button type="button" class="primary" data-action="save">Save Caption</button></div>`;
    const text=box.querySelector('textarea');text.value=cue.text;
    const start=box.querySelector('[aria-label="Caption Start"]'),end=box.querySelector('[aria-label="Caption End"]'),error=box.querySelector('[role="alert"]');
    const auto=box.querySelector('.caption-auto-timing input'),note=box.querySelector('.caption-auto-note');
    const ranges=[box.querySelector('.caption-range-start'),box.querySelector('.caption-range-end')];
    const showRange=()=>{ranges[0].value=seconds(start.value);ranges[1].value=seconds(end.value);const band=box.querySelector('.caption-range-selection');band.style.left=`${(Number(ranges[0].value)-base.start)/span*100}%`;band.style.right=`${(base.end-Number(ranges[1].value))/span*100}%`;};
    for(const [i,range] of ranges.entries()){
      range.min=base.start;range.max=base.end;range.step=1/60;
      range.oninput=()=>{auto.checked=false;const other=seconds((i?start:end).value);const v=i?Math.max(other+1/60,Number(range.value)):Math.min(other-1/60,Number(range.value));(i?end:start).value=time(v);showRange();note.textContent='Manual timing · Original audio and scene timing stay unchanged.';};
    }
    const drawWords=()=>{const holder=box.querySelector('.caption-word-buttons');holder.replaceChildren();const words=text.value.trim().split(/\s+/).filter(Boolean);words.forEach((w,i)=>{const b=document.createElement('button');b.type='button';b.className='ghost';b.textContent=w;b.title='Remove '+w;b.onclick=()=>{let index=0;text.value=text.value.replace(/\S+/g,token=>index++===i?'':token).split('\n').map(line=>line.replace(/[^\S\n]+/g,' ').trim()).join('\n').trim();text.dispatchEvent(new Event('input'));};holder.append(b);});};
    const fit=()=>{if(auto.checked){const win=autoWindow(cue,text.value);if(win){start.value=time(win.start);end.value=time(win.end);note.textContent=win.estimated?'Timing fitted to remaining words (estimated).':'Timing fitted to the remaining spoken words.';}else note.textContent='Drag the handles to set timing for this wording.';}showRange();};
    text.addEventListener('input',()=>{drawWords();fit();});auto.onchange=fit;
    for(const field of [start,end])field.addEventListener('input',()=>{auto.checked=false;showRange();});
    drawWords();showRange();
    if(custom){auto.checked=false;box.querySelector('.caption-auto-timing').hidden=true;box.querySelector('[data-action="reset"]').hidden=true;box.querySelector('[data-action="hide"]').hidden=true;note.textContent='Choose an empty time range. Delete or shorten an existing caption to replace it.';}
    box.querySelector('[data-action="delete"]').hidden=!!cue.display_new;
    let closed=false,busy=false;
    const bg=document.createElement('div');bg.className='modal-bg caption-editor-bg';bg.append(box);
    const close=()=>{closed=true;bg.remove();};
    const commit=async action=>{
      if(busy||closed)return;if(!current()){close();return;}
      const a=seconds(start.value),b=seconds(end.value),epsilon=.011;
      if(!['reset','delete'].includes(action)&&(!Number.isFinite(a)||!Number.isFinite(b)||a<base.start-epsilon||b>base.end+epsilon||b-a<1/60)){
        error.textContent='Keep Start before End, within the video or voice-over duration.';return;
      }
      const payload=action==='delete'?{id:cue.display_id,delete:true}:custom?{...(cue.display_new?{add:true}:{id:cue.display_id}),caption:{text:text.value.trim(),start:sourceTime(a),end:sourceTime(b)}}:action==='reset'?{id:cue.display_id,reset:true}:{id:cue.display_id,edit:{text:action==='hide'?'':text.value.trim(),start:sourceTime(a),end:sourceTime(b)}};
      busy=true;box.querySelectorAll('button').forEach(b=>b.disabled=true);error.textContent='Saving…';
      try{
        const response=await json('/api/subtitle-display/'+encodeURIComponent(project),payload);
        if(!current()){close();return;}
        if((custom||action==='delete')&&reload){await reload();close();return;}
        const updated=response.captions.find(c=>c.display_id===cue.display_id);
        if(!updated&&action==='reset'&&reload){await reload();close();return;}
        if(!updated)throw Error('Caption changed. Refresh the preview and try again.');
        // Absolute edits may cross scene boundaries; use the complete source map.
        for(const word of updated.words||[]){word.start=displayTime(word.start);word.end=displayTime(word.end);}
        updated.start=displayTime(updated.start);updated.end=displayTime(updated.end);
        if(updated.display_base){updated.display_base.start=displayTime(updated.display_base.start);updated.display_base.end=displayTime(updated.display_base.end);}
        apply(updated);close();
      }catch(e){error.textContent=e.message;}finally{busy=false;box.querySelectorAll('button').forEach(b=>b.disabled=false);}
    };
    box.querySelectorAll('[data-clock]').forEach(b=>b.onclick=()=>{auto.checked=false;(b.dataset.clock==='start'?start:end).value=time(Math.max(base.start,Math.min(base.end,playhead())));showRange();});
    box.querySelectorAll('[data-action]').forEach(b=>b.onclick=e=>{e.stopPropagation();b.dataset.action==='cancel'?close():commit(b.dataset.action);});
    for(const event of ['click','dblclick','pointerdown'])box.addEventListener(event,e=>e.stopPropagation());
    box.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'&&!busy)close();if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();commit('save');}});
    (document.fullscreenElement||document.body).append(bg);text.focus();
  }
  function list(host,captions,select,add) {
    host.innerHTML='';
    if(add){const button=document.createElement('button');button.type='button';button.className='ghost caption-add';button.textContent='+ Add Caption';button.onclick=add;host.append(button);}
    const items=document.createElement('div');items.className='subtitle-cue-list';
    for(const cue of captions){
      const row=document.createElement('button');row.type='button';row.className='subtitle-cue-row'+(cue.display_edited?' edited':'');
      row.innerHTML=`<span>${time(cue.start)} – ${time(cue.end)}</span><span>${esc(cue.text||'[Hidden Caption]')}</span><small>${cue.display_edited?'Edited · ':''}Edit</small>`;
      row.onclick=()=>select(cue);items.append(row);
    }
    host.append(items);
  }
  function freshCaption(captions,playhead,duration){
    const occupied=captions.filter(c=>c.text.trim()).sort((a,b)=>a.start-b.start);let start=Math.max(0,Math.min(duration-1/60,playhead));
    for(const c of occupied)if(start>=c.start&&start<c.end)start=c.end;
    if(start>=duration-1/60){start=0;for(const c of occupied){if(c.start-start>=1/60)break;start=Math.max(start,c.end);}}
    if(start>=duration-1/60){toast('Delete Or Shorten A Caption To Make Room For A New One.','info');return null;}
    const next=occupied.find(c=>c.start>start),end=Math.min(duration,start+2,next?next.start:duration);
    return {display_new:true,text:'',start,end};
  }
  let captionBusy=false,captionDraft=null,captionUndo=null,captionSelected=null,captionScrollSync=false;
  const cq=s=>document.querySelector(s);
  const captionState=c=>({text:c.text,start:c.start,end:c.end});
  function sourceTime(t){const s=PV.m?.scenes.find(s=>t>=s.start-.00001&&t<=s.end+.00001),r=s&&PV.captionSourceRanges?.find(r=>r.id===s.id);return r?r.start+(t-s.start)/(s.end-s.start)*(r.end-r.start):t;}
  function displayTime(t){const r=PV.captionSourceRanges?.find(r=>t>=r.start-.00001&&t<=r.end+.00001),s=r&&PV.m?.scenes.find(s=>s.id===r.id);return s?s.start+(t-r.start)/(r.end-r.start)*(s.end-s.start):t;}
  function mapCaptions(captions){
    for(const c of captions){c.start=displayTime(c.start);c.end=displayTime(c.end);for(const w of c.words||[]){w.start=displayTime(w.start);w.end=displayTime(w.end);}if(c.display_base){c.display_base.start=displayTime(c.display_base.start);c.display_base.end=displayTime(c.display_base.end);}}
    return captions;
  }
  function captionStatus(message){const el=cq('#pvCaptionStatus');if(el)el.textContent=message;}
  function resetTimeline(){captionBusy=false;captionDraft=null;captionUndo=null;captionSelected=null;cq('#pvCaptionTrack')?.setAttribute('hidden','');cq('#pvCaptionInline')?.setAttribute('hidden','');}
  async function saveCaptionChanges(changes,undo=false){
    if(captionBusy||!PV.m)return false;
    const owner=musicContext(),model=PV.m,prior=changes.map(c=>({id:c.id,edit:{...c.expected},expected:{...c.edit}}));
    captionBusy=true;captionStatus('Saving subtitle changes…');
    try{
      const payload=changes.map(c=>({...c,edit:{...c.edit,start:sourceTime(c.edit.start),end:sourceTime(c.edit.end)},expected:{...c.expected,start:sourceTime(c.expected.start),end:sourceTime(c.expected.end)}}));
      const result=await json('/api/subtitle-display/'+encodeURIComponent(owner.project),{changes:payload});
      if(!musicCurrent(owner)||PV.m!==model)return false;
      PV.m.captions=mapCaptions(result.captions);PV.cap=-1;captionUndo=undo?null:prior;
      pvRender(cq('#pvVo').currentTime||0);renderSubMini();captionStatus('Saved');renderTimeline();
      return true;
    }catch(e){if(musicCurrent(owner)&&PV.m===model){captionStatus(e.message);await refreshAssemble(true);}return false;}
    finally{if(musicCurrent(owner)&&PV.m===model){captionBusy=false;renderTimeline();}}
  }
  function captionBounds(cues,cue,mode,delta,total,separate=false){
    const frame=1/60,others=cues.filter(c=>c!==cue&&c.text.trim()).sort((a,b)=>a.start-b.start);
    const previous=others.filter(c=>c.end<=cue.start+frame/2).at(-1),next=others.find(c=>c.start>=cue.end-frame/2);
    let a=cue.start,b=cue.end,neighbor=null;
    delta=Math.round(delta*60)/60;
    if(mode==='move'){a=Math.max(previous?.end||0,Math.min(cue.start+delta,(next?.start??total)-(b-a)));b=a+cue.end-cue.start;}
    else if(mode==='l'){
      neighbor=!separate&&previous&&Math.abs(previous.end-cue.start)<frame/2?previous:null;
      a=Math.max(neighbor?neighbor.start+frame:previous?.end||0,Math.min(cue.start+delta,b-frame));
    }else{
      neighbor=!separate&&next&&Math.abs(next.start-cue.end)<frame/2?next:null;
      b=Math.min(neighbor?neighbor.end-frame:next?.start??total,Math.max(cue.end+delta,a+frame));
    }
    const changes=[{id:cue.display_id,expected:captionState(cue),edit:{text:cue.text,start:a,end:b}}];
    if(neighbor)changes.push({id:neighbor.display_id,expected:captionState(neighbor),edit:{text:neighbor.text,start:mode==='r'?b:neighbor.start,end:mode==='l'?a:neighbor.end}});
    return changes;
  }
  async function assemble(cue){
    if(captionBusy||!PV.m)return;
    if(captionDraft&&captionDraft.cue.display_id!==cue.display_id){if(!await saveDraft())return;cue=PV.m.captions.find(c=>c.display_id===cue.display_id)||cue;}
    pvPause();
    captionSelected=cue.display_id;captionDraft={cue,original:captionState(cue)};
    const box=cq('#pvCaptionInline');box.hidden=false;box.querySelector('textarea').value=cue.text;
    renderTimeline();box.querySelector('textarea').focus();
  }
  async function saveDraft(){
    if(!captionDraft)return true;
    const draft=captionDraft,value=cq('#pvCaptionInline textarea').value.trim();
    if(value===draft.original.text){captionDraft=null;cq('#pvCaptionInline').hidden=true;return true;}
    if(draft.cue.display_new || (!value && draft.cue.display_custom)){
      const owner=musicContext(),model=PV.m;captionBusy=true;captionStatus('Saving subtitle…');
      try{
        const payload=draft.cue.display_new?{add:true,caption:{text:value,start:sourceTime(draft.cue.start),end:sourceTime(draft.cue.end)}}:{id:draft.cue.display_id,delete:true};
        const result=await json('/api/subtitle-display/'+encodeURIComponent(owner.project),payload);
        if(!musicCurrent(owner)||PV.m!==model)return false;
        PV.m.captions=mapCaptions(result.captions);PV.cap=-1;captionUndo=null;captionDraft=null;cq('#pvCaptionInline').hidden=true;
        pvRender(cq('#pvVo').currentTime||0);renderSubMini();captionStatus('Saved');return true;
      }catch(e){if(musicCurrent(owner))captionStatus(e.message);return false;}
      finally{if(musicCurrent(owner)&&PV.m===model){captionBusy=false;renderTimeline();}}
    }
    const ok=await saveCaptionChanges([{id:draft.cue.display_id,expected:draft.original,edit:{...draft.original,text:value}}]);
    if(ok){captionDraft=null;cq('#pvCaptionInline').hidden=true;}return ok;
  }
  function renderTimeline(){
    const host=cq('#pvCaptionTrack'),content=cq('#pvCaptionContent'),scroll=cq('#pvCaptionScroll');if(!host||!content)return;
    host.hidden=!PV.m;if(!PV.m)return;
    const m=PV.m,total=m.duration||1,zoom=PV.ttZoom||1;
    const sharedWidth=cq('#pvTtContent')?.offsetWidth||scroll.clientWidth*zoom;
    content.style.width=sharedWidth+'px';content.style.height='38px';content.replaceChildren();
    const selected=c=>c.display_id===captionSelected;
    for(const cue of m.captions.filter(c=>c.text.trim())){
      const bar=document.createElement('div');bar.className='pv-caption-bar'+(selected(cue)?' selected':'');bar.dataset.id=cue.display_id;
      const label=document.createElement('span');label.textContent=cue.text;
      const left=document.createElement('i'),right=document.createElement('i');left.className='caption-edge left';right.className='caption-edge right';bar.append(left,label,right);
      const place=(a,b)=>{bar.style.left=a/total*100+'%';bar.style.width=(b-a)/total*100+'%';};place(cue.start,cue.end);
      bar.title=`${time(cue.start)} – ${time(cue.end)} · ${cue.text}`;
      bar.onpointerdown=e=>{
        if(e.button!==0||captionBusy||captionDraft)return;e.preventDefault();e.stopPropagation();pvPause();
        const mode=e.target===left?'l':e.target===right?'r':'move',owner=musicContext(),x=e.clientX,W=content.getBoundingClientRect().width||1;
        let proposal=null;captionSelected=cue.display_id;bar.classList.add('selected');bar.setPointerCapture(e.pointerId);
        const move=ev=>{
          if(Math.abs(ev.clientX-x)<3&&!proposal)return;
          proposal=captionBounds(m.captions,cue,mode,(ev.clientX-x)/W*total,total,ev.altKey);
          for(const change of proposal){const el=[...content.children].find(n=>n.dataset.id===change.id);if(el){el.style.left=change.edit.start/total*100+'%';el.style.width=(change.edit.end-change.edit.start)/total*100+'%';}}
          captionStatus(`${time(proposal[0].edit.start)} – ${time(proposal[0].edit.end)}`);
        };
        const end=async ev=>{
          bar.removeEventListener('pointermove',move);bar.removeEventListener('pointerup',end);bar.removeEventListener('pointercancel',end);try{bar.releasePointerCapture(e.pointerId);}catch(_){}
          if(!musicCurrent(owner)||PV.m!==m)return;
          if(ev.type==='pointercancel'){renderTimeline();return;}
          if(proposal){await saveCaptionChanges(proposal);renderTimeline();}
          else{cq('#pvVo').currentTime=cue.start;pvRender(cue.start);assemble(cue);}
        };
        bar.addEventListener('pointermove',move);bar.addEventListener('pointerup',end);bar.addEventListener('pointercancel',end);
      };content.append(bar);
    }
    const head=document.createElement('div');head.className='pv-caption-head';content.append(head);timelineHead(cq('#pvVo').currentTime||0);
    host.querySelector('[data-caption="undo"]').disabled=!captionUndo||captionBusy;
    if(!host._bound){
      const resize=()=>{
        if(!PV.m)return;
        const width=cq('#pvTtContent')?.offsetWidth||scroll.clientWidth*(PV.ttZoom||1);
        if(width>0)content.style.width=width+'px';
        cq('#previewWrap')?.style.setProperty('--pv-caption-h',host.offsetHeight+'px');
      };
      if(window.ResizeObserver){host._resize=new ResizeObserver(resize);host._resize.observe(host);host._resize.observe(scroll);}
      host._bound=true;host.addEventListener('click',async e=>{
        const action=e.target.closest('[data-caption]')?.dataset.caption;if(!action||captionBusy)return;
        if(action==='out'||action==='in'){pvTtSetZoom((PV.ttZoom||1)*(action==='in'?1.6:1/1.6));renderTimeline();return;}
        if(action==='undo'){if(captionUndo)await saveCaptionChanges(captionUndo,true);return;}
        if(action==='cancel'){captionDraft=null;cq('#pvCaptionInline').hidden=true;return;}
        if(action==='save'){await saveDraft();return;}
        if(action==='delete'&&captionDraft){cq('#pvCaptionInline textarea').value='';await saveDraft();return;}
        if(action==='previous'||action==='next'){
          const id=captionSelected;if(!await saveDraft())return;
          const cues=PV.m.captions,i=cues.findIndex(c=>c.display_id===id),cue=cues[i+(action==='next'?1:-1)];
          if(cue){cq('#pvVo').currentTime=cue.start;pvRender(cue.start);assemble(cue);}return;
        }
        if(action==='add'){
          if(!await saveDraft())return;
          const cue=freshCaption(PV.m.captions,cq('#pvVo').currentTime||0,PV.m.duration);if(!cue)return;
          assemble(cue);
        }
      });
      cq('#pvCaptionInline textarea').onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();void saveDraft();}if(e.key==='Escape'){captionDraft=null;cq('#pvCaptionInline').hidden=true;}};
      content.addEventListener('pointerdown',e=>{if(e.target.closest('.pv-caption-bar'))return;if(e.button!==0)return;pvPause();const r=content.getBoundingClientRect();const t=Math.max(0,Math.min(PV.m.duration,(e.clientX-r.left)/r.width*PV.m.duration));cq('#pvVo').currentTime=t;pvRender(t);});
      scroll.addEventListener('scroll',()=>{if(captionScrollSync)return;captionScrollSync=true;for(const id of ['pvTtScroll','pvBarRow']){const el=cq('#'+id);if(el)el.scrollLeft=scroll.scrollLeft;}captionScrollSync=false;});
    }
    scroll.scrollLeft=cq('#pvTtScroll')?.scrollLeft||0;
  }
  function timelineHead(t){const head=cq('.pv-caption-head');if(head&&PV.m)head.style.left=t/PV.m.duration*100+'%';const scroll=cq('#pvCaptionScroll');if(scroll&&!captionScrollSync){captionScrollSync=true;scroll.scrollLeft=cq('#pvTtScroll')?.scrollLeft||0;captionScrollSync=false;}}

  const ostSignature=()=>JSON.stringify([PROJECT,DOC?.image_aspect,DOC?.subtitle_style,DOC?.subtitle_auto_ost,DOC?.scenes?.map(s=>[s.id,s.vo,s.ost_on,s.overlays])]);
  let ostRequest=null;
  async function refreshAssemble(force=false){
    if(ostRequest){if(!force)return;await ostRequest;}
    if(!PV.m||!DOC)return;const owner=musicContext(),signature=ostSignature();
    if(!force&&PV.ostCaptionSignature===signature)return;let done;ostRequest=new Promise(resolve=>done=resolve);
    try{await flushSave();if(!musicCurrent(owner))return;
      const next=await json('/api/subtitle-display/'+encodeURIComponent(owner.project));
      if(!musicCurrent(owner)||!PV.m||signature!==ostSignature())return;
      PV.captionSourceRanges=next.ranges||[];
      const remap=t=>{const r=next.ranges?.find(r=>t>=r.start-.00001&&t<=r.end+.00001),s=r&&PV.m.scenes.find(s=>s.id===r.id);return s?s.start+(t-r.start)/(r.end-r.start)*(s.end-s.start):t;};
      for(const c of next.captions){c.start=remap(c.start);c.end=remap(c.end);for(const w of c.words||[]){w.start=remap(w.start);w.end=remap(w.end);}if(c.display_base){c.display_base.start=remap(c.display_base.start);c.display_base.end=remap(c.display_base.end);}}
      PV.m.captions=next.captions;PV.ostCaptionSignature=signature;PV.cap=-1;pvRender(document.querySelector('#pvVo').currentTime||0);renderSubMini();
      renderTimeline();
    }catch(e){if(musicCurrent(owner))toastErr(e.message);}finally{ostRequest=null;done();}
  }
  window.CaptionEditor={open:editor,assemble,autoWindow,refreshAssemble,listAssemble:renderTimeline,renderTimeline,timelineHead,resetTimeline,captionBounds};

  const API='/api/studio/subtitle',host=document.querySelector('#subtitleStudio');
  if(!host)return;
  host.innerHTML=`<div class="subtitle-studio-head"><h2>Voiceover &amp; Subtitles</h2><p class="hint">Upload or generate a voice-over, then create subtitles. Add a video whenever you want to style and preview them.</p></div>
    <div class="subtitle-upload-row">
      <label class="ghost subtitle-upload"><span>🎙 Upload Voiceover</span><input type="file" data-upload="audio" accept=".mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.wma" hidden><small data-name="audio">No Recording Selected</small></label>
      <label class="ghost subtitle-upload"><span>📄 Upload Script</span><input type="file" data-upload="script" accept=".txt,.docx" hidden><small>TXT or DOCX</small></label>
      <label class="ghost subtitle-upload"><span>🎬 Add Video</span><input type="file" data-upload="video" accept=".mp4,.mov,.m4v,.webm" hidden><small data-name="video">Optional · For Preview &amp; Styled Exports</small></label></div>
    <div class="subtitle-studio-grid"><section class="subtitle-inputs">
      <div class="subtitle-script-head"><label for="svScript">Script</label></div>
      <div class="sv-script-wrap"><textarea id="svScript" placeholder="Paste your script here…"></textarea></div>
      <details id="svVoiceTools" class="sv-voice-tools"><summary>🎙 Generate Voiceover</summary><div class="sv-voice-controls"><input id="svVoiceId" aria-label="Voice ID" placeholder="ElevenLabs Voice ID"><div id="svVoices"></div><button type="button" class="ghost" id="svSaveVoice">+ Save Voice</button></div><div id="svSaveVoiceRow" hidden><input id="svVoiceName" aria-label="Voice Name" placeholder="Voice Name"><button type="button" class="ghost" id="svSaveVoiceConfirm">Save</button></div><button type="button" class="primary" id="svGenerateVoice">🎙 Generate Voiceover</button><div id="svGenerated" hidden><audio id="svGeneratedPlayer" controls></audio><div class="sv-voice-actions"><button type="button" class="ghost" id="svUseGenerated">Use This Voiceover</button><button type="button" class="ghost" id="svDownloadGenerated">⬇ Download Voiceover</button></div></div></details>
      <div id="svAudioPrep" class="audio-prep"></div>
      <div class="subtitle-generate-row"><label>Language<select id="svLanguage" aria-label="Subtitle Language"></select></label><button type="button" class="primary" id="svGenerate">Generate SRT</button></div>
      <p id="svVideoHint" class="hint" hidden>Use the same recording and timing as the finished video. Trim changes audio timing.</p>
      <p id="svStatus" class="hint" role="status"></p>
    </section><section class="subtitle-preview-column"><div id="svStage" class="subtitle-video-stage"><video id="svVideo" playsinline preload="metadata"></video><div class="sv-caption-position"><div class="sv-caption-text"></div></div><canvas id="svMotion" hidden></canvas><div class="sv-placeholder">Add A Video To Preview Subtitles<br><small>Video is optional for SRT</small></div></div>
      <div class="sv-player"><button class="ghost" id="svPlay" aria-label="Play Video">▶</button><input id="svSeek" type="range" min="0" max="1" step="0.016667" value="0" aria-label="Video Time"><span id="svTime">00:00</span><button class="ghost" id="svMute" aria-label="Mute Audio">🔊</button><button class="ghost" id="svFullscreen" aria-label="Fullscreen Preview">⛶</button></div>
      <div class="subtitle-preview-tools"><label class="sv-audio-choice">Playback Audio<select id="svAudioMode"><option value="video">Video Audio</option><option value="voiceover">Uploaded Voiceover</option></select></label>
        <div id="svOstTools" class="subtitle-ost-tools" hidden><button id="svScanOst" type="button" class="ghost">🔎 Detect On-Screen Text</button><label class="sv-hide-matching"><input id="svAutoOst" type="checkbox" checked>Hide Matching On-Screen Words</label><button id="svReviewOst" type="button" class="ghost" hidden>Review Matches</button></div>
        <button id="svRemoveVideo" type="button" class="ghost" title="Clear video, voiceover, script and subtitles">Remove Video</button></div><audio id="svVoice" preload="metadata"></audio>
    </section></div>
    <section id="subtitleStudioStyles" class="pv-sub" hidden></section>
    <details id="svCaptions" hidden><summary>Edit Captions</summary><div id="svCaptionList"></div></details>
    <div class="subtitle-downloads"><button class="ghost" data-export="srt" disabled>💬 Download SRT</button><button class="ghost" data-export="overlay" disabled>💬 Subtitle Overlay</button><button class="primary" data-export="video" disabled>⬇ Download Video</button></div>
    <p class="hint subtitle-overlay-note">Subtitle Overlay: transparent MOV at 2× resolution. In Premiere, use 50% Scale for the same size. Download Video keeps your video’s original dimensions.</p>`;
  const q=s=>host.querySelector(s),video=q('#svVideo'),voice=q('#svVoice'),stage=q('#svStage'),motion=q('#svMotion'),classic=q('.sv-caption-position'),inner=q('.sv-caption-text');
  host.querySelectorAll('[data-upload],#svScript,#svLanguage,#svGenerate').forEach(el=>el.disabled=true);
  const langSource=document.querySelector('#subtitleLanguages')?.content.querySelector('select');if(langSource)q('#svLanguage').innerHTML=langSource.innerHTML;else q('#svLanguage').innerHTML='<option value="en">English</option>';
  let data=null,active=false,epoch=0,raf=0,cap=null,styleKey='',layout=null,poll=null,genToast=null,pending={},saving=null,saveTimer=null,editSeq=0,uploading=false,exporting=false,starting=false,resetting=false,animClock=null;
  const current=()=>active&&!PROJECT;
  let prep;
  const prepBusy=()=>!!prep?.busy();
  prep=new AudioPrep(q('#svAudioPrep'),{
    context:()=>({area:'subtitle',scope:'_subtitle_video',key:'_subtitle_video:'+epoch,current}),
    message:(t,k)=>toast(t,k),progress:(t,stop)=>progressToast(t,stop),blocked:()=>data?.status?.status==='running'||starting||uploading,
    download:(url,name)=>downloadUrl(url,name,'Voiceover'),
    changed:()=>{if(!current()||!data)return;locks();
      if(prep?.ref()&&prep.ready()&&prep.ref()!==data.prep_ref)refresh().catch(e=>toastErr(e.message));},
  });
  let refreshing=null;
  function locks(){
    if(!data)return;const running=data.status?.status==='running',blocked=running||uploading||prepBusy()||starting||exporting||resetting;
    q('#svGenerate').disabled=blocked;
    host.querySelectorAll('[data-upload],#svScript,#svLanguage,#svUseGenerated,#svGenerateVoice,#svRemoveVideo').forEach(el=>el.disabled=blocked);
    host.querySelectorAll('[data-export]').forEach(el=>el.disabled=exporting||blocked||!data.captions?.length||(el.dataset.export==='overlay'&&!data.captions?.some(c=>c.text.trim()))||(el.dataset.export!=='srt'&&!data.video));
    q('#svScanOst').disabled=blocked||!data.video||!data.captions?.length;
    q('#svAutoOst').disabled=blocked;q('#svReviewOst').disabled=blocked;
  }
  async function refresh(){
    if(refreshing)return refreshing;const visit=epoch;
    refreshing=json(API+'/state').then(next=>{if(current()&&visit===epoch)adopt(next);return next;}).finally(()=>refreshing=null);
    return refreshing;
  }
  attachScriptFix(q('#svScript'),q('#svScript').parentElement,null,{scope:()=> '_subtitle_video'});
  async function voices(){const saved=await api.getVoices();if(!current())return;const holder=q('#svVoices');holder.innerHTML='';holder.append(tcSelect('',[{value:'',label:'🎧 Saved Voices'},...(saved||[]).map(x=>({value:x.voice_id,label:x.name}))],v=>{if(v){q('#svVoiceId').value=v;queue({voice_id:v});}},'🎧 Saved Voices'));}
  q('#svVoiceId').oninput=()=>queue({voice_id:q('#svVoiceId').value});
  q('#svSaveVoice').onclick=()=>{q('#svSaveVoiceRow').hidden=!q('#svSaveVoiceRow').hidden;};
  q('#svSaveVoiceConfirm').onclick=async()=>{try{const name=q('#svVoiceName').value.trim(),id=q('#svVoiceId').value.trim();if(!name||!id)throw Error('Enter a Voice ID and name.');const r=await api.addVoice(name,id);if(r.error)throw Error(r.error);q('#svSaveVoiceRow').hidden=true;await voices();}catch(e){toastErr(e.message);}};
  q('#svGenerateVoice').onclick=async()=>{
    if(!data||prepBusy()||uploading||starting)return;const visit=epoch,voiceId=q('#svVoiceId').value.trim(),text=q('#svScript').value.trim();
    if(!voiceId||!text){toastErr('Enter the script and choose a Voice ID.');return;}
    try{queue({script:text,voice_id:voiceId});await flush();await generateProjectVoice({project:data.project,voiceId,text,button:q('#svGenerateVoice'),current:()=>current()&&visit===epoch,unchanged:()=>q('#svScript').value.trim()===text&&q('#svVoiceId').value.trim()===voiceId,success:()=>refresh().catch(e=>toastErr(e.message))});}catch(e){toastErr(e.message);}
  };
  q('#svUseGenerated').onclick=async()=>{try{await flush();const next=await json(API+'/use-generated',{});adopt(next);await prep.load();}catch(e){toastErr(e.message);}};
  q('#svDownloadGenerated').onclick=()=>downloadMediaFrom('_subtitle_video','voiceover/voiceover.mp3','Voiceover.mp3');
  q('#svRemoveVideo').onclick=async()=>{
    if(resetting||uploading||exporting||starting||prepBusy()||data?.status?.status==='running')return;
    resetting=true;host.inert=true;locks();
    try{
      await flush();const visit=++epoch;editSeq++;clearTimeout(poll);poll=null;animClock=null;
      for(const player of [video,voice,q('#svGeneratedPlayer'),prep.player]){player.pause();player.removeAttribute('src');delete player.dataset.source;player.load();}
      const next=await json(API+'/state',{remove_video:true});pending={};clearTimeout(saveTimer);
      if(!current()||visit!==epoch)return;
      genToast?.close();genToast=null;cancelAnimationFrame(raf);prep.reset();prep.pace.value='natural';
      cap=null;layout=null;styleKey='';motion._motionLayout=null;motion.getContext('2d').clearRect(0,0,motion.width,motion.height);inner.textContent='';
      q('#svSeek').value=0;q('#svSeek').max=1;q('#svTime').textContent='00:00';q('#svPlay').textContent='▶';
      muted=false;q('#svMute').textContent='🔊';q('#svVoiceTools').open=false;q('#svSaveVoiceRow').hidden=true;q('#svVoiceName').value='';q('#svCaptions').open=false;
      document.querySelector('.caption-editor-bg')?.remove();data=null;adopt(next,true);controls();await prep.load();await voices();
      toast('Voiceover & Subtitles Cleared.','ok');
    }catch(e){toastErr(e.message);if(current()){await refresh().catch(()=>{});await prep.load();}}
    finally{resetting=false;host.inert=false;if(current())locks();}
  };
  function stageSize(){const v=data?.video;return {width:v?.width||1920,height:v?.height||1080};}
  function style(){return data?.style||subDefaults();}
  function paint() {
    if(!data||!active)return;
    if(!data.video){classic.hidden=true;motion.hidden=true;cap=null;return;}
    q('#svSeek').max=Number.isFinite(video.duration)?video.duration:1;q('#svSeek').value=video.currentTime;q('#svTime').textContent=time(video.currentTime).slice(0,-3);q('#svPlay').textContent=video.paused?'▶':'Ⅱ';
    const t=animClock??video.currentTime,cue=(data.captions||[]).find(c=>c.start<=t&&c.end>t&&c.text.trim());
    const st=style(),size=stageSize(),key=JSON.stringify(st);
    if(!cue){classic.hidden=true;motion.hidden=true;cap=null;return;}
    if(SubtitleMotion.enabled(st)){
      classic.hidden=true;motion.hidden=false;
      if(cap!==cue||styleKey!==key||!layout){motion.width=size.width;motion.height=size.height;layout=SubtitleMotion.layout(cue,st,size.width,size.height);}
      SubtitleMotion.paint(motion,layout,t);motion._motionLayout=layout;
    }else{
      motion.hidden=true;classic.hidden=false;
      inner.textContent=wrapSubLines(cue.text,st,size.width).join('\n');styleCaption(inner,classic,stage.clientWidth,st,size.width);
      subtitleSentenceCss(inner,cue,st,t,stage.clientWidth/size.width);
    }
    cap=cue;styleKey=key;
  }
  function loop(){cancelAnimationFrame(raf);paint();if(active&&!video.paused)raf=requestAnimationFrame(loop);}
  let muted=false;
  q('#svPlay').onclick=()=>video.paused?video.play().catch(e=>toastErr('Video playback could not start.')):video.pause();
  q('#svSeek').oninput=()=>{video.currentTime=Number(q('#svSeek').value);paint();};
  q('#svMute').onclick=()=>{muted=!muted;q('#svMute').textContent=muted?'🔇':'🔊';syncAudio();};
  q('#svFullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():stage.parentElement.requestFullscreen();
  function syncAudio(force=false){
    const use=!!data?.video&&data?.audio_mode==='voiceover';video.muted=use||muted;voice.muted=muted;
    if(!use){voice.pause();return;}
    if(force||Math.abs(voice.currentTime-video.currentTime)>.18)voice.currentTime=video.currentTime;
    voice.playbackRate=video.playbackRate;
    if(!video.paused)voice.play().catch(()=>{});else voice.pause();
  }
  ['play','pause','seeked','seeking','timeupdate','ratechange'].forEach(event=>video.addEventListener(event,()=>{if(event==='play'){prep.player.pause();q('#svGeneratedPlayer').pause();}syncAudio(event==='seeked');loop();}));
  video.addEventListener('ended',()=>voice.pause());
  video.addEventListener('error',()=>{q('#svStatus').textContent='This video cannot play in the browser. Export it as H.264 MP4 and upload it again.';});
  new ResizeObserver(()=>paint()).observe(stage);
  document.fonts?.addEventListener('loadingdone',()=>{layout=null;paint();});
  function open(cue){
    if(!current()||!cue)return;video.pause();const visit=epoch;
    editor({stage,cue,duration:studioDuration(),project:data.project,playhead:()=>data.video?video.currentTime:prep.player.currentTime,current:()=>current()&&epoch===visit,reload:refresh,apply:updated=>{
      const i=data.captions.findIndex(c=>c.display_id===updated.display_id);data.captions[i]=updated;data.captions.sort((a,b)=>a.start-b.start||a.end-b.end);cap=null;layout=null;paint();renderList();
    }});
  }
  stage.addEventListener('dblclick',e=>{
    if(!cap||e.target.closest('.pv-caption-editor'))return;
    let hit=e.target.closest('.sv-caption-position');
    if(!hit&&!motion.hidden&&layout?.bounds){const rect=stage.getBoundingClientRect(),size=stageSize(),x=(e.clientX-rect.left)*size.width/rect.width,y=(e.clientY-rect.top)*size.height/rect.height,b=layout.bounds;hit=x>=b.x&&x<=b.x+b.width&&y>=b.y&&y<=b.y+b.height;}
    if(hit){e.preventDefault();e.stopPropagation();open(cap);}
  },true);
  function studioDuration(){return Math.max(Number(data?.video?.duration)||0,Number(data?.audio?.duration)||0,Number.isFinite(prep.player.duration)?prep.player.duration:0,...(data?.captions||[]).map(c=>c.end));}
  function renderList(){q('#svCaptions').hidden=!(data?.captions?.length||data?.status?.status==='done');list(q('#svCaptionList'),data?.captions||[],cue=>{video.pause();prep.player.pause();if(data.video)video.currentTime=cue.start;else prep.player.currentTime=cue.start;paint();open(cue);},()=>{const cue=freshCaption(data.captions||[],data.video?video.currentTime:prep.player.currentTime,studioDuration());if(cue)open(cue);});}
  function controls(){
    const target=q('#subtitleStudioStyles');target.innerHTML='';target.hidden=!data?.video;
    if(!data?.video)return;
    const panel=document.querySelector('#subStyleTpl').content.firstElementChild.cloneNode(true);target.append(panel);
    wireSubtitleStyle(panel,data.style,()=>{layout=null;paint();queue({style:data.style});},()=>{controls();layout=null;paint();queue({style:data.style});},data.captions||[],()=>{
      const cue=cap||data.captions?.find(c=>c.text);if(!cue)return;video.pause();video.currentTime=cue.start;const start=performance.now(),visit=epoch;
      const tick=()=>{if(!current()||visit!==epoch)return;animClock=cue.start+(performance.now()-start)/1000;paint();if(animClock<cue.end)requestAnimationFrame(tick);else{animClock=null;paint();}};tick();
    },()=>{data.style=subDefaults();controls();paint();queue({style:data.style});});
  }
  function adopt(next,form=false){
    // next can be the current object during busy-state updates. Snapshot first:
    // writing defaults into that same style before reading it lost the user's look.
    const incomingStyle={...subDefaults(),...(next.style||{})},previousStyle=data?.style;data=next;
    data.style=previousStyle?Object.assign(previousStyle,incomingStyle):incomingStyle;
    if(form){q('#svScript').value=data.script||'';q('#svLanguage').value=data.language||'en';q('#svVoiceId').value=data.voice_id||'';}
    const v=data.video;stage.classList.toggle('has-video',!!v);
    if(v){stage.style.aspectRatio=`${v.width}/${v.height}`;stage.style.setProperty('--sv-ratio',v.width/v.height);stage.style.maxWidth=`min(100%, ${Math.round(480*v.width/v.height)}px)`;if(video.dataset.source!==v.file){video.src=v.url;video.dataset.source=v.file;}}
    else{video.pause();if(video.hasAttribute('src')){video.removeAttribute('src');video.load();}delete video.dataset.source;stage.style.aspectRatio='16/9';stage.style.removeProperty('--sv-ratio');stage.style.maxWidth='100%';}
    q('.sv-player').hidden=!v;q('.subtitle-preview-tools').hidden=!v;q('#svVideoHint').hidden=!v;q('.subtitle-overlay-note').hidden=!v;
    q('#svOstTools').hidden=!v||!data.captions?.length;q('#svAutoOst').checked=data.auto_ost!==false;q('#svReviewOst').hidden=!data.ost_windows?.length;
    for(const k of ['video','audio'])q(`[data-name="${k}"]`).textContent=data[k]?.name||(k==='video'?'For Preview & Styled Exports':'No Recording Selected');
    q('#svGenerated').hidden=!data.generated_voice;
    if(data.generated_voice&&q('#svGeneratedPlayer').dataset.source!==data.generated_voice.url){q('#svGeneratedPlayer').src=data.generated_voice.url;q('#svGeneratedPlayer').dataset.source=data.generated_voice.url;}
    if(!data.generated_voice){const player=q('#svGeneratedPlayer');player.pause();if(player.hasAttribute('src')){player.removeAttribute('src');player.load();}delete player.dataset.source;}
    if(data.audio&&voice.dataset.source!==data.audio.file){voice.src=data.audio.url;voice.dataset.source=data.audio.file;}
    if(!data.audio){voice.pause();if(voice.hasAttribute('src')){voice.removeAttribute('src');voice.load();}delete voice.dataset.source;}
    q('#svAudioMode').value=data.audio_mode||'video';syncAudio();
    const running=data.status?.status==='running';locks();
    q('#svStatus').textContent=running?(data.status.step||'Generating Subtitles…'):(data.captions?.length?`${data.captions.length} Captions Ready`:'Generate subtitles after uploading your inputs.');
    cap=null;layout=null;paint();renderList();
    if(running)watch();
  }
  function queue(fields){if(resetting)return;pending={...pending,...structuredClone(fields)};editSeq++;clearTimeout(saveTimer);saveTimer=setTimeout(()=>flush().catch(e=>toastErr(e.message)),400);}
  async function flush(){
    clearTimeout(saveTimer);if(saving)return saving;
    saving=(async()=>{while(Object.keys(pending).length){const fields=pending;pending={};const seq=editSeq;try{const result=await json(API+'/state',fields);if(current()&&seq===editSeq)adopt(result);}catch(e){pending={...fields,...pending};throw e;}}})().finally(()=>saving=null);
    return saving;
  }
  q('#svScript').addEventListener('input',()=>queue({script:q('#svScript').value}));
  window.addEventListener('pagehide',()=>{
    if(Object.keys(pending).length)fetch(API+'/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(pending),keepalive:true}).catch(()=>{});
  });
  q('#svLanguage').onchange=()=>queue({language:q('#svLanguage').value});
  q('#svAudioMode').onchange=()=>{data.audio_mode=q('#svAudioMode').value;syncAudio(true);queue({audio_mode:data.audio_mode});};
  q('#svAutoOst').onchange=()=>queue({auto_ost:q('#svAutoOst').checked});
  function reviewOst(windows,source){
    const visit=epoch,bg=document.createElement('div');bg.className='modal-bg caption-editor-bg';
    bg.innerHTML='<div class="pv-caption-editor subtitle-display-editor"><strong>On-Screen Text Matches</strong><p class="hint">Only matching spoken words will be hidden. Review the detected text and approximate times before applying.</p><div class="subtitle-ost-matches"></div><p class="caption-edit-error" role="alert"></p><div class="caption-edit-actions"><button type="button" class="ghost" data-cancel>Cancel</button><button type="button" class="primary" data-apply>Apply Selected</button></div></div>';
    const list=bg.querySelector('.subtitle-ost-matches');
    windows.forEach((w,i)=>{const row=document.createElement('label');row.innerHTML=`<input type="checkbox" checked data-index="${i}"><span>${esc(w.text)}<small>${time(w.start)} – ${time(w.end)}</small></span>`;list.append(row);});
    if(!windows.length)list.textContent='No matching spoken text was detected.';
    bg.querySelector('[data-cancel]').onclick=()=>bg.remove();
    bg.querySelector('[data-apply]').onclick=async e=>{e.target.disabled=true;try{
      if(!current()||visit!==epoch||source!==data.video?.file)throw Error('The video changed. Scan its on-screen text again.');
      await flush();const selected=[...list.querySelectorAll('input:checked')].map(el=>windows[Number(el.dataset.index)]);
      adopt(await json(API+'/state',{ost_windows:selected,ost_video:source,auto_ost:true}));bg.remove();
    }catch(error){bg.querySelector('[role="alert"]').textContent=error.message;e.target.disabled=false;}};
    document.body.append(bg);
  }
  q('#svReviewOst').onclick=()=>reviewOst(data.ost_windows||[],data.video.file);
  q('#svScanOst').onclick=async()=>{
    if(exporting)return;exporting=true;locks();let progress;const visit=epoch;
    try{await flush();const result=await json(API+'/scan-ost',{});
      progress=progressToast('Detecting On-Screen Text…',()=>json(API+'/job/'+result.job,{}));
      let job;do{await new Promise(r=>setTimeout(r,650));job=await json(API+'/job/'+result.job);progress.update(job.phase||'Detecting On-Screen Text…',job.pct,false,{etaSeconds:job.remaining_seconds});}while(job.status==='running');
      if(job.status==='done'&&current()&&visit===epoch)reviewOst(job.windows,job.video);
      else if(job.status==='error')throw Error(job.error);
    }catch(e){toastErr(e.message);}finally{exporting=false;progress?.close();if(current())locks();}
  };
  async function upload(kind,file){
    if(!file||uploading||!data)return;await flush();video.pause();uploading=true;const visit=epoch;adopt(data);
    const progress=progressToast(`Uploading ${kind==='audio'?'Voiceover':kind==='video'?'Video':'Script'}…`);
    try{
      const result=await new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST',API+'/upload/'+kind);xhr.responseType='json';xhr.upload.onprogress=e=>progress.update(`Uploading ${kind}…`,e.lengthComputable?e.loaded/e.total*100:null);xhr.upload.onload=()=>progress.update('Checking Uploaded File…',null);xhr.onload=()=>xhr.status<300&&!xhr.response?.error?resolve(xhr.response):reject(Error(xhr.response?.error||'Upload failed.'));xhr.onerror=()=>reject(Error('Upload could not reach the application.'));const form=new FormData();form.append('file',file);xhr.send(form);});
      if(current()&&epoch===visit){adopt(result,true);controls();if(kind==='audio')await prep.load();}
    }catch(e){toastErr(e.message);}finally{uploading=false;progress.close();if(current())adopt(data);}
  }
  host.querySelectorAll('[data-upload]').forEach(input=>input.onchange=()=>{const file=input.files[0];input.value='';upload(input.dataset.upload,file).catch(e=>toastErr(e.message));});
  async function watch(){
    if(poll)return;const visit=epoch;
    if(!genToast)genToast=progressToast('Generating Subtitles…',()=>json('/api/subtitle/_subtitle_video/cancel',{}));
    poll=setTimeout(async()=>{
      poll=null;if(!current()||visit!==epoch)return;
      try{const next=await json(API+'/state');if(!current()||visit!==epoch)return;
        const st=next.status;genToast?.update(st.step||'Generating Subtitles…',st.pct);
        if(st.status==='running'){data.status=st;watch();}else{genToast?.close();genToast=null;adopt(next,true);controls();if(st.status==='error')toastErr(st.error||'Subtitle generation failed.');}
      }catch(e){genToast?.update('Reconnecting To Subtitle Progress…',null);watch();}
    },1000);
  }
  q('#svGenerate').onclick=async()=>{
    if(uploading||starting||prepBusy()||!data)return;starting=true;q('#svGenerate').disabled=true;
    try{queue({script:q('#svScript').value,language:q('#svLanguage').value,style:data.style});await flush();await refresh();let result=await json(API+'/generate',{});
      if(result.lang_mismatch){if(!await confirmDialog(result.lang_mismatch,{title:'Check The Language',okText:'Generate Anyway',danger:false}))return;result=await json(API+'/generate',{force:true});}
      if(result.status==='running'){data.status={status:'running',step:'Starting…'};adopt(data);}
    }catch(e){toastErr(e.message);}finally{starting=false;if(current())locks();}
  };
  host.querySelectorAll('[data-export]').forEach(button=>button.onclick=async()=>{
    if(exporting)return;exporting=true;let progress;adopt(data);
    try{queue({style:data.style});await flush();const result=await json(API+'/export/'+button.dataset.export,{});
      progress=progressToast('Preparing Subtitle Export…',()=>json(API+'/job/'+result.job,{}));
      let job;do{await new Promise(r=>setTimeout(r,650));job=await json(API+'/job/'+result.job);progress.update(job.phase||'Preparing Download…',job.pct,false,{etaSeconds:job.remaining_seconds});}while(job.status==='running');
      if(job.status==='done')downloadUrl(API+'/download/'+result.job,job.name,'Subtitle Studio');
      else if(job.status==='outdated')toast(job.message,'info');
      else if(job.status==='error')throw Error(job.error||'Export failed.');
    }catch(e){toastErr(e.message);}finally{exporting=false;progress?.close();if(current())adopt(data);}
  });
  document.addEventListener('script-review-choice',e=>{if(e.detail?.scope===data?.project&&current()&&e.detail.script){q('#svScript').value=e.detail.script;}});
  window.SubtitleStudio={async enter(){
    if(PROJECT)return;active=true;const visit=++epoch;host.querySelectorAll('[data-upload],#svScript,#svLanguage,#svGenerate').forEach(el=>el.disabled=true);
    try{await flush();const next=await json(API+'/state');if(!current()||visit!==epoch)return;adopt(next,true);controls();await prep.load();await voices();}
    catch(e){if(current())toastErr(e.message);}
  },leave(){active=false;epoch++;video.pause();voice.pause();q('#svGeneratedPlayer').pause();prep.reset();cancelAnimationFrame(raf);clearTimeout(poll);poll=null;genToast?.close();genToast=null;document.querySelector('.caption-editor-bg')?.remove();flush().catch(e=>toastErr(e.message));}};
})();
