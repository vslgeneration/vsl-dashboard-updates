/* One caption-only editor and the projectless finished-video subtitle workspace. */
(() => {
  'use strict';
  const esc = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const time = n => {const cent=Math.round(Math.max(0,Number(n)||0)*100);return `${String(Math.floor(cent/6000)).padStart(2,'0')}:${String(Math.floor(cent/100)%60).padStart(2,'0')}.${String(cent%100).padStart(2,'0')}`;};
  const seconds = text => {const parts=String(text).trim().replace(',','.').split(':');if(parts.length>3||parts.some(v=>!/^\d+(\.\d+)?$/.test(v)))return NaN;return parts.reduce((n,v)=>n*60+Number(v),0);};
  async function json(url,body) {
    const r=await fetch(url,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    let data;try{data=await r.json();}catch(_){throw Error('The application could not complete this request.');}
    if(!r.ok||data.error)throw Error(data.error||'Request failed.');return data;
  }
  function editor({stage,cue,project,playhead,current,apply}) {
    if(!cue.display_id||!cue.display_base){toast('Refresh The Preview To Enable Caption Editing.','info');return;}
    document.querySelector('.caption-editor-bg')?.remove();
    const base=cue.display_base, span=base.end-base.start;
    const box=document.createElement('div');box.className='pv-caption-editor subtitle-display-editor';
    box.setAttribute('role','dialog');box.setAttribute('aria-label','Edit Caption Only');
    box.innerHTML=`<strong>Edit Caption</strong><p class="hint">Caption only · Script, scenes and voice-over stay unchanged.</p><textarea aria-label="Subtitle Text"></textarea>
      <div class="caption-time-fields"><label>Start<input aria-label="Caption Start" value="${time(cue.start)}"><button type="button" class="ghost" data-clock="start">Use Playhead</button></label><label>End<input aria-label="Caption End" value="${time(cue.end)}"><button type="button" class="ghost" data-clock="end">Use Playhead</button></label></div>
      <p class="hint">Original window: ${time(base.start)} – ${time(base.end)}</p><p class="caption-edit-error" role="alert"></p>
      <div class="caption-edit-actions"><button type="button" class="ghost" data-action="reset">Reset</button><button type="button" class="ghost" data-action="hide">Hide Caption</button><button type="button" class="ghost" data-action="cancel">Cancel</button><button type="button" class="primary" data-action="save">Save Caption</button></div>`;
    const text=box.querySelector('textarea');text.value=cue.text;
    const start=box.querySelector('[aria-label="Caption Start"]'),end=box.querySelector('[aria-label="Caption End"]'),error=box.querySelector('[role="alert"]');
    let closed=false,busy=false;
    const bg=document.createElement('div');bg.className='modal-bg caption-editor-bg';bg.append(box);
    const close=()=>{closed=true;bg.remove();};
    const commit=async action=>{
      if(busy||closed)return;if(!current()){close();return;}
      const a=seconds(start.value),b=seconds(end.value),epsilon=.011;
      if(action!=='reset'&&(!Number.isFinite(a)||!Number.isFinite(b)||a<base.start-epsilon||b>base.end+epsilon||b-a<1/60)){
        error.textContent='Keep Start before End, within the original caption window.';return;
      }
      const clamp=x=>Math.min(1,Math.max(0,x));
      const payload=action==='reset'?{id:cue.display_id,reset:true}:{id:cue.display_id,edit:{text:action==='hide'?'':text.value.trim(),in:clamp((a-base.start)/span),out:clamp((b-base.start)/span)}};
      busy=true;box.querySelectorAll('button').forEach(b=>b.disabled=true);error.textContent='Saving…';
      try{
        const response=await json('/api/subtitle-display/'+encodeURIComponent(project),payload);
        if(!current()){close();return;}
        const updated=response.captions.find(c=>c.display_id===cue.display_id);
        if(!updated)throw Error('Caption changed. Refresh the preview and try again.');
        // Custom testimonial recordings can remap the project clock. Keep the
        // existing preview clock without re-encoding its audio on a caption edit.
        const original=updated.display_base, remap=t=>Math.round((base.start+(t-original.start)/(original.end-original.start)*span)*1e6)/1e6;
        for(const word of updated.words||[]){word.start=remap(word.start);word.end=remap(word.end);}
        updated.start=remap(updated.start);updated.end=remap(updated.end);updated.display_base={...base};
        apply(updated);close();
      }catch(e){error.textContent=e.message;}finally{busy=false;box.querySelectorAll('button').forEach(b=>b.disabled=false);}
    };
    box.querySelectorAll('[data-clock]').forEach(b=>b.onclick=()=>{(b.dataset.clock==='start'?start:end).value=time(Math.max(base.start,Math.min(base.end,playhead())));});
    box.querySelectorAll('[data-action]').forEach(b=>b.onclick=e=>{e.stopPropagation();b.dataset.action==='cancel'?close():commit(b.dataset.action);});
    for(const event of ['click','dblclick','pointerdown'])box.addEventListener(event,e=>e.stopPropagation());
    box.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'&&!busy)close();if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();commit('save');}});
    document.body.append(bg);text.focus();
  }
  function list(host,captions,select) {
    host.innerHTML='';
    const items=document.createElement('div');items.className='subtitle-cue-list';
    for(const cue of captions){
      const row=document.createElement('button');row.type='button';row.className='subtitle-cue-row'+(cue.display_edited?' edited':'');
      row.innerHTML=`<span>${time(cue.start)} – ${time(cue.end)}</span><span>${esc(cue.text||'[Hidden Caption]')}</span><small>${cue.display_edited?'Edited · ':''}Edit</small>`;
      row.onclick=()=>select(cue);items.append(row);
    }
    host.append(items);
  }
  function assemble(cue) {
    const owner=musicContext();pvPause();
    editor({stage:document.querySelector('#pvStage'),cue,project:PROJECT,playhead:()=>document.querySelector('#pvVo').currentTime||0,current:()=>musicCurrent(owner),apply:updated=>{
      const i=PV.m.captions.findIndex(c=>c.display_id===updated.display_id);if(i<0)return;
      PV.m.captions[i]=updated;PV.cap=-1;pvRender(document.querySelector('#pvVo').currentTime||0);renderSubMini();
      const host=document.querySelector('#pvSubtitleEdits');if(host)assembleList(host);
    }});
  }
  function assembleList(host) {
    list(host,PV.m.captions,cue=>{pvPause();const a=document.querySelector('#pvVo');a.currentTime=cue.start;pvRender(cue.start);document.querySelector('#pvStage').scrollIntoView({behavior:'smooth',block:'center'});assemble(cue);});
  }
  window.CaptionEditor={open:editor,assemble,listAssemble(){
    let host=document.querySelector('#pvSubtitleEdits');
    if(host){host.remove();return;}
    host=document.createElement('div');host.id='pvSubtitleEdits';document.querySelector('#pvSubPanel').append(host);assembleList(host);
  }};

  const API='/api/studio/subtitle',host=document.querySelector('#subtitleStudio');
  if(!host)return;
  host.innerHTML=`<div class="subtitle-studio-head"><h2>Subtitle</h2><p class="hint">Add styled subtitles to a finished video. Double-click a caption to edit its text or display time.</p></div>
    <div class="subtitle-studio-grid"><section class="subtitle-inputs"><div class="subtitle-upload-row">
      <label class="ghost subtitle-upload">🎬 Upload Video<input type="file" data-upload="video" accept=".mp4,.mov,.m4v,.webm" hidden><small data-name="video">MP4 · MOV · WebM</small></label>
      <label class="ghost subtitle-upload">🎙 Upload Voiceover<input type="file" data-upload="audio" accept=".mp3,.wav,.m4a,.aac,.ogg,.flac" hidden><small data-name="audio">The recording used in this video</small></label></div>
      <div class="subtitle-script-head"><label for="svScript">Script</label><label class="ghost subtitle-upload">📄 Upload Script<input type="file" data-upload="script" accept=".txt,.docx" hidden></label></div>
      <textarea id="svScript" placeholder="Paste the words spoken in your video…"></textarea>
      <div class="subtitle-generate-row"><label>Language<select id="svLanguage" aria-label="Subtitle Language"></select></label><button type="button" class="primary" id="svGenerate">Generate Subtitles</button></div>
      <p class="hint">Use the recording as it appears in the finished video, starting at 00:00. Subtitles follow this recording; the video is not trimmed.</p>
      <p id="svStatus" class="hint" role="status"></p>
    </section><section class="subtitle-preview-column"><div id="svStage" class="subtitle-video-stage"><video id="svVideo" playsinline preload="metadata"></video><div class="sv-caption-position"><div class="sv-caption-text"></div></div><canvas id="svMotion" hidden></canvas><div class="sv-placeholder">Upload Your Video</div></div>
      <div class="sv-player"><button class="ghost" id="svPlay" aria-label="Play Video">▶</button><input id="svSeek" type="range" min="0" max="1" step="0.016667" value="0" aria-label="Video Time"><span id="svTime">00:00</span><button class="ghost" id="svMute" aria-label="Mute Audio">🔊</button><button class="ghost" id="svFullscreen" aria-label="Fullscreen Preview">⛶</button></div><div class="subtitle-preview-tools"><label>Playback Audio<select id="svAudioMode"><option value="video">Video Audio</option><option value="voiceover">Uploaded Voiceover</option></select></label><span id="svCanvas" class="hint"></span></div><audio id="svVoice" preload="metadata"></audio>
    </section></div>
    <section id="subtitleStudioStyles" class="pv-sub" hidden></section>
    <details id="svCaptions" hidden><summary>Edit Captions</summary><div id="svCaptionList"></div></details>
    <div class="subtitle-downloads"><button class="ghost" data-export="srt" disabled>💬 Download SRT</button><button class="ghost" data-export="overlay" disabled>💬 Subtitle Overlay</button><button class="primary" data-export="video" disabled>⬇ Download Video</button></div>
    <p class="hint subtitle-overlay-note">Subtitle Overlay: transparent MOV at 2× resolution. In Premiere, use 50% Scale for the same size. Download Video keeps your video’s original dimensions.</p>`;
  const q=s=>host.querySelector(s),video=q('#svVideo'),voice=q('#svVoice'),stage=q('#svStage'),motion=q('#svMotion'),classic=q('.sv-caption-position'),inner=q('.sv-caption-text');
  host.querySelectorAll('[data-upload],#svScript,#svLanguage,#svGenerate').forEach(el=>el.disabled=true);
  const langSource=document.querySelector('#ssrtLang');if(langSource)q('#svLanguage').innerHTML=langSource.innerHTML;else q('#svLanguage').innerHTML='<option value="en">English</option>';
  let data=null,active=false,epoch=0,raf=0,cap=null,styleKey='',layout=null,poll=null,genToast=null,pending={},saving=null,saveTimer=null,editSeq=0,uploading=false,exporting=false,starting=false,animClock=null;
  const current=()=>active&&!PROJECT;
  function stageSize(){const v=data?.video;return {width:v?.width||1920,height:v?.height||1080};}
  function style(){return data?.style||subDefaults();}
  function paint() {
    if(!data||!active)return;
    q('#svSeek').max=Number.isFinite(video.duration)?video.duration:1;q('#svSeek').value=video.currentTime;q('#svTime').textContent=time(video.currentTime).slice(0,-3);q('#svPlay').textContent=video.paused?'▶':'Ⅱ';
    const t=animClock??video.currentTime,cue=(data.captions||[]).find(c=>c.start<=t&&c.end>t&&c.text.trim());
    const st=style(),size=stageSize(),key=JSON.stringify(st);
    if(!cue){classic.hidden=true;motion.hidden=true;cap=null;return;}
    if(SubtitleMotion.enabled(st)){
      classic.hidden=true;motion.hidden=false;
      if(cap!==cue||styleKey!==key||!layout){motion.width=size.width;motion.height=size.height;layout=SubtitleMotion.layout(cue,st,size.width,size.height);}
      SubtitleMotion.paint(motion,layout,t);motion._motionLayout=layout;
    }else{
      motion.hidden=true;classic.hidden=false;
      inner.textContent=wrapSubLines(cue.text,st,size.width).join('\n');styleCaption(inner,classic,stage.clientWidth,st,size.width);
      subtitleSentenceCss(inner,cue,st,t,stage.clientWidth/size.width);
    }
    cap=cue;styleKey=key;
  }
  function loop(){cancelAnimationFrame(raf);paint();if(active&&!video.paused)raf=requestAnimationFrame(loop);}
  let muted=false;
  q('#svPlay').onclick=()=>video.paused?video.play().catch(e=>toastErr('Video playback could not start.')):video.pause();
  q('#svSeek').oninput=()=>{video.currentTime=Number(q('#svSeek').value);paint();};
  q('#svMute').onclick=()=>{muted=!muted;q('#svMute').textContent=muted?'🔇':'🔊';syncAudio();};
  q('#svFullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():stage.parentElement.requestFullscreen();
  function syncAudio(force=false){
    const use=data?.audio_mode==='voiceover';video.muted=use||muted;voice.muted=muted;
    if(!use){voice.pause();return;}
    if(force||Math.abs(voice.currentTime-video.currentTime)>.18)voice.currentTime=video.currentTime;
    voice.playbackRate=video.playbackRate;
    if(!video.paused)voice.play().catch(()=>{});else voice.pause();
  }
  ['play','pause','seeked','seeking','timeupdate','ratechange'].forEach(event=>video.addEventListener(event,()=>{syncAudio(event==='seeked');loop();}));
  video.addEventListener('ended',()=>voice.pause());
  video.addEventListener('error',()=>{q('#svStatus').textContent='This video cannot play in the browser. Export it as H.264 MP4 and upload it again.';});
  new ResizeObserver(()=>paint()).observe(stage);
  document.fonts?.addEventListener('loadingdone',()=>{layout=null;paint();});
  function open(cue){
    if(!current()||!cue)return;video.pause();const visit=epoch;
    editor({stage,cue,project:data.project,playhead:()=>video.currentTime,current:()=>current()&&epoch===visit,apply:updated=>{
      const i=data.captions.findIndex(c=>c.display_id===updated.display_id);data.captions[i]=updated;cap=null;layout=null;paint();renderList();
    }});
  }
  stage.addEventListener('dblclick',e=>{
    if(!cap||e.target.closest('.pv-caption-editor'))return;
    let hit=e.target.closest('.sv-caption-position');
    if(!hit&&!motion.hidden&&layout?.bounds){const rect=stage.getBoundingClientRect(),size=stageSize(),x=(e.clientX-rect.left)*size.width/rect.width,y=(e.clientY-rect.top)*size.height/rect.height,b=layout.bounds;hit=x>=b.x&&x<=b.x+b.width&&y>=b.y&&y<=b.y+b.height;}
    if(hit){e.preventDefault();e.stopPropagation();open(cap);}
  },true);
  function renderList(){q('#svCaptions').hidden=!data?.captions?.length;list(q('#svCaptionList'),data?.captions||[],cue=>{video.pause();video.currentTime=cue.start;paint();open(cue);});}
  function controls(){
    const target=q('#subtitleStudioStyles');target.innerHTML='';target.hidden=!data?.video;
    if(!data?.video)return;
    const panel=document.querySelector('#subStyleTpl').content.firstElementChild.cloneNode(true);target.append(panel);
    wireSubtitleStyle(panel,data.style,()=>{layout=null;paint();queue({style:data.style});},()=>{controls();layout=null;paint();queue({style:data.style});},data.captions||[],()=>{
      const cue=cap||data.captions?.find(c=>c.text);if(!cue)return;video.pause();video.currentTime=cue.start;const start=performance.now();
      const tick=()=>{if(!current())return;animClock=cue.start+(performance.now()-start)/1000;paint();if(animClock<cue.end)requestAnimationFrame(tick);else{animClock=null;paint();}};tick();
    },()=>{data.style=subDefaults();controls();paint();queue({style:data.style});});
  }
  function adopt(next,form=false){
    const previousStyle=data?.style;data=next;
    if(previousStyle){Object.assign(previousStyle,subDefaults(),data.style||{});data.style=previousStyle;}else data.style={...subDefaults(),...(data.style||{})};
    if(form){q('#svScript').value=data.script||'';q('#svLanguage').value=data.language||'en';}
    const v=data.video;stage.classList.toggle('has-video',!!v);
    if(v){stage.style.aspectRatio=`${v.width}/${v.height}`;stage.style.setProperty('--sv-ratio',v.width/v.height);stage.style.maxWidth=`min(100%, ${Math.round(480*v.width/v.height)}px)`;if(video.dataset.source!==v.file){video.src=v.url;video.dataset.source=v.file;}q('#svCanvas').textContent=`${v.width} × ${v.height}`;}
    for(const k of ['video','audio'])q(`[data-name="${k}"]`).textContent=data[k]?.name||(k==='video'?'MP4 · MOV · WebM':'The recording used in this video');
    if(data.audio&&voice.dataset.source!==data.audio.file){voice.src=data.audio.url;voice.dataset.source=data.audio.file;}
    q('#svAudioMode').value=data.audio_mode||'video';syncAudio();
    const running=data.status?.status==='running';q('#svGenerate').disabled=running||uploading||starting;
    host.querySelectorAll('[data-upload],#svScript,#svLanguage').forEach(el=>el.disabled=running||uploading);
    host.querySelectorAll('[data-export]').forEach(el=>el.disabled=exporting||!data.captions?.some(c=>c.text.trim()));
    q('#svStatus').textContent=running?(data.status.step||'Generating Subtitles…'):(data.captions?.length?`${data.captions.length} Captions Ready`:'Generate subtitles after uploading your inputs.');
    cap=null;layout=null;paint();renderList();
    if(running)watch();
  }
  function queue(fields){pending={...pending,...structuredClone(fields)};editSeq++;clearTimeout(saveTimer);saveTimer=setTimeout(()=>flush().catch(e=>toastErr(e.message)),400);}
  async function flush(){
    clearTimeout(saveTimer);if(saving)return saving;
    saving=(async()=>{while(Object.keys(pending).length){const fields=pending;pending={};const seq=editSeq;try{const result=await json(API+'/state',fields);if(current()&&seq===editSeq)adopt(result);}catch(e){pending={...fields,...pending};throw e;}}})().finally(()=>saving=null);
    return saving;
  }
  q('#svScript').addEventListener('input',()=>queue({script:q('#svScript').value}));
  q('#svLanguage').onchange=()=>queue({language:q('#svLanguage').value});
  q('#svAudioMode').onchange=()=>{data.audio_mode=q('#svAudioMode').value;syncAudio(true);queue({audio_mode:data.audio_mode});};
  async function upload(kind,file){
    if(!file||uploading||!data)return;await flush();video.pause();uploading=true;const visit=epoch;adopt(data);
    const progress=progressToast(`Uploading ${kind==='audio'?'Voiceover':kind==='video'?'Video':'Script'}…`);
    try{
      const result=await new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST',API+'/upload/'+kind);xhr.responseType='json';xhr.upload.onprogress=e=>progress.update(`Uploading ${kind}…`,e.lengthComputable?e.loaded/e.total*100:null);xhr.upload.onload=()=>progress.update('Checking Uploaded File…',null);xhr.onload=()=>xhr.status<300&&!xhr.response?.error?resolve(xhr.response):reject(Error(xhr.response?.error||'Upload failed.'));xhr.onerror=()=>reject(Error('Upload could not reach the application.'));const form=new FormData();form.append('file',file);xhr.send(form);});
      if(current()&&epoch===visit){adopt(result,true);controls();}
    }catch(e){toastErr(e.message);}finally{uploading=false;progress.close();if(current())adopt(data);}
  }
  host.querySelectorAll('[data-upload]').forEach(input=>input.onchange=()=>{const file=input.files[0];input.value='';upload(input.dataset.upload,file).catch(e=>toastErr(e.message));});
  async function watch(){
    if(poll)return;const visit=epoch;
    if(!genToast)genToast=progressToast('Generating Subtitles…',()=>json('/api/subtitle/_subtitle_video/cancel',{}));
    poll=setTimeout(async()=>{
      poll=null;if(!current()||visit!==epoch)return;
      try{const next=await json(API+'/state');if(!current()||visit!==epoch)return;
        const st=next.status;genToast?.update(st.step||'Generating Subtitles…',st.pct);
        if(st.status==='running'){data.status=st;watch();}else{genToast?.close();genToast=null;adopt(next,true);controls();if(st.status==='error')toastErr(st.error||'Subtitle generation failed.');}
      }catch(e){genToast?.update('Reconnecting To Subtitle Progress…',null);watch();}
    },1000);
  }
  q('#svGenerate').onclick=async()=>{
    if(uploading||starting||!data)return;starting=true;q('#svGenerate').disabled=true;
    try{queue({script:q('#svScript').value,language:q('#svLanguage').value,style:data.style});await flush();let result=await json(API+'/generate',{});
      if(result.lang_mismatch){if(!await confirmDialog(result.lang_mismatch,{title:'Check The Language',okText:'Generate Anyway',danger:false}))return;result=await json(API+'/generate',{force:true});}
      if(result.status==='running'){data.status={status:'running',step:'Starting…'};adopt(data);}
    }catch(e){toastErr(e.message);}finally{starting=false;if(current())q('#svGenerate').disabled=data?.status?.status==='running';}
  };
  host.querySelectorAll('[data-export]').forEach(button=>button.onclick=async()=>{
    if(exporting)return;exporting=true;let progress;adopt(data);
    try{queue({style:data.style});await flush();const result=await json(API+'/export/'+button.dataset.export,{});
      progress=progressToast('Preparing Subtitle Export…',()=>json(API+'/job/'+result.job,{}));
      let job;do{await new Promise(r=>setTimeout(r,650));job=await json(API+'/job/'+result.job);progress.update(job.phase||'Preparing Download…',job.pct,false,{etaSeconds:job.remaining_seconds});}while(job.status==='running');
      if(job.status==='done')downloadUrl(API+'/download/'+result.job,job.name,'Subtitle Studio');
      else if(job.status==='error')throw Error(job.error||'Export failed.');
    }catch(e){toastErr(e.message);}finally{exporting=false;progress?.close();if(current())adopt(data);}
  });
  document.addEventListener('script-review-choice',e=>{if(e.detail?.scope===data?.project&&current()&&e.detail.script){q('#svScript').value=e.detail.script;}});
  window.SubtitleStudio={async enter(){
    if(PROJECT)return;active=true;const visit=++epoch;host.querySelectorAll('[data-upload],#svScript,#svLanguage,#svGenerate').forEach(el=>el.disabled=true);
    try{await flush();const next=await json(API+'/state');if(!current()||visit!==epoch)return;adopt(next,true);controls();}
    catch(e){if(current())toastErr(e.message);}
  },leave(){active=false;epoch++;video.pause();voice.pause();cancelAnimationFrame(raf);clearTimeout(poll);poll=null;genToast?.close();genToast=null;document.querySelector('.caption-editor-bg')?.remove();flush().catch(e=>toastErr(e.message));}};
})();
