/* Local render cache report and recovery. This panel never changes the scene document. */
(() => {
  const bg = document.querySelector('#storageBg');
  const content = document.querySelector('#storageContent');
  const status = document.querySelector('#storageStatus');
  const refresh = document.querySelector('#storageRefresh');
  const trigger = document.querySelector('#storageBtn');
  let generation = 0, context = null;
  const bytes = value => {
    if (value === null || !Number.isFinite(value)) return 'Unavailable';
    const units = ['B', 'KB', 'MB', 'GB', 'TB']; let n = value, i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
  };
  const node = (tag, text, cls) => {
    const el = document.createElement(tag); if (text !== undefined) el.textContent = text;
    if (cls) el.className = cls; return el;
  };
  const current = (ctx, token) => context === ctx && generation === token && !bg.hidden && PROJECT === ctx.project && PROJECT_EPOCH === ctx.epoch;
  const close = () => { bg.hidden = true; generation++; context = null; trigger.focus(); };
  async function request(ctx, suffix = '', payload) {
    const response = await fetch(`/api/storage/${encodeURIComponent(ctx.project)}${suffix}`, payload ? {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)
    } : {});
    let result;
    try { result = await response.json(); } catch (_) { throw new Error('Could not read the storage response. Refresh and try again.'); }
    if (!response.ok) throw new Error(result.error || 'The storage request failed.');
    return result;
  }
  function draw(report, ctx) {
    content.replaceChildren();
    const stats = node('div', undefined, 'storage-stats');
    for (const [label, value] of [['Active render cache', report.cache_bytes], ['Cache held for recovery', report.quarantine_bytes]]) {
      const tile = node('div', label, 'storage-stat'); tile.append(node('strong', bytes(value))); stats.append(tile);
    }
    content.append(stats, node('p', 'Recovery files still use disk space. They are not freed space.', 'hint'));
    content.append(node('p', 'Before a render, unused cache older than 7 days may be moved here when active cache exceeds 3 GB. After 30 days, eligible recovery files may be removed during a later render.', 'hint'));
    if (report.blocked) content.append(node('p', 'Cache checks are incomplete: ' + report.blocked, 'storage-warning'));
    else content.append(node('p', `${bytes(report.candidate_bytes)} currently eligible to move into recovery.`, 'hint'));
    if (report.quarantine_warning) content.append(node('p', 'Recovery report is incomplete: ' + report.quarantine_warning, 'storage-warning'));
    content.append(node('h4', 'Recovery batches'));
    if (!report.batches.length) content.append(node('p', report.quarantine_warning ? 'Refresh after the report becomes available.' : 'No recovery batches are waiting.', 'hint'));
    for (const batch of report.batches) {
      const row = node('div', undefined, 'storage-batch'), details = node('div');
      details.append(node('strong', batch.created ? new Date(batch.created * 1000).toLocaleString('en-US') : 'Unreadable recovery record'));
      details.append(node('p', `${batch.files} files · ${bytes(batch.bytes)} · ${batch.restorable} available to restore`));
      if (batch.eligible_after) details.append(node('p', `Cleanup may begin after ${new Date(batch.eligible_after * 1000).toLocaleDateString('en-US')}.`, 'hint'));
      if (batch.blocked) details.append(node('p', batch.blocked, 'storage-warning'));
      const button = node('button', 'Restore cache', 'ghost'); button.type = 'button';
      button.disabled = !batch.restorable || !!batch.blocked;
      button.addEventListener('click', () => restore(ctx, batch.batch));
      row.append(details, button); content.append(row);
    }
  }
  async function load(ctx, message = '') {
    const token = ++generation;
    refresh.disabled = true; status.textContent = 'Reading local cache…'; content.replaceChildren();
    try {
      const report = await request(ctx);
      if (!current(ctx, token)) return;
      draw(report, ctx); status.textContent = message;
    } catch (error) { if (current(ctx, token)) status.textContent = error.message; }
    finally { if (current(ctx, token)) refresh.disabled = false; }
  }
  async function restore(ctx, batch) {
    if (context !== ctx || bg.hidden || PROJECT !== ctx.project || PROJECT_EPOCH !== ctx.epoch) return;
    const token = ++generation;
    refresh.disabled = true;
    content.querySelectorAll('button').forEach(button => { button.disabled = true; });
    status.textContent = 'Restoring cache…';
    try {
      const result = await request(ctx, '/restore', {batch});
      if (!current(ctx, token)) return;
      await load(ctx, `${result.restored} files restored. ${result.kept} left in recovery because they changed or a cache file already exists.`);
    } catch (error) {
      if (current(ctx, token)) await load(ctx, error.message);
    }
  }
  trigger.addEventListener('click', () => {
    if (!PROJECT) { toastErr('Open a project first.'); return; }
    context = {project: PROJECT, epoch: PROJECT_EPOCH};
    document.querySelector('#storageProject').textContent = (DOC && DOC.title) || PROJECT;
    bg.hidden = false; document.querySelector('#storageClose').focus(); load(context);
  });
  document.querySelector('#storageClose').addEventListener('click', close);
  refresh.addEventListener('click', () => { if (context) load(context); });
  bdClose(bg, close);
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !bg.hidden) close(); });
})();
