/* The edit preview reads source media directly. It never calls a render job. */
window.LiveMedia = (() => {
  'use strict';
  let host=null,canvas=null,ctx=null,clock=null,model=null,owner=()=>false,raf=0,last=-1,generation=0;
  let scenes=[],sources=new Map(),audio=new Map(),snapshots=new Map(),listeners=[],resize=null,options={},voiceRequest=0,grader=null,scratch=null;
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,Number(v)||0));
  const number=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
  const playing=()=>clock&&!clock.paused&&!clock.ended;
  const dims=()=>({width:model?.canvas?.width||1920,height:model?.canvas?.height||1080});
  const identity=s=>s.uid||s.id;
  const mediaSignature=s=>JSON.stringify([s?.approved,s?.image?.approved_file,s?.image?.approved_version,s?.video?.approved,s?.video?.approved_file,s?.video?.approved_version,s?.speaker_clip]);
  function signal(text){if(host)host.dispatchEvent(new CustomEvent('livemediaerror',{bubbles:true,detail:{message:text}}));}
  function release(e){e.dead=true;e.media.pause?.();e.media.removeAttribute('src');e.media.load?.();e.media.remove();}
  function sourceKey(sc,index){
    // Keep one decoder through a continuous speaker take, even across cards.
    let first=index;
    while(first>0){const a=scenes[first-1],b=scenes[first],x=a.speaker_clip,y=b.speaker_clip;
      if(!x||!y||a.url!==b.url||a.transition!=='none'||Math.abs(a.end-b.start)>1/120||x.fps!==y.fps||x.source_out_frame!==y.source_in_frame)break;
      first--;
    }
    return JSON.stringify([sc.type,sc.url,identity(scenes[first]||sc)]);
  }
  function source(sc,index){
    if(!sc.url||!['image','video'].includes(sc.type))return null;
    const key=sourceKey(sc,index);if(sources.has(key)){const e=sources.get(key);e.used=performance.now();return e;}
    const movie=sc.type==='video',media=document.createElement(movie?'video':'img');
    const e={key,media,movie,dead:false,ready:false,used:performance.now(),wanted:null,source:sc.url};sources.set(key,e);
    if(movie){media.muted=true;media.defaultMuted=true;media.playsInline=true;media.preload='auto';media.setAttribute('muted','');}
    let pending=true;const done=()=>{if(e.dead||!owner())return;e.ready=movie?media.readyState>=2:!!media.naturalWidth;
      if(e.ready&&pending){pending=false;e.resolve();}if(clock?.paused)paint(clock.currentTime||0);};
    e.promise=new Promise(resolve=>e.resolve=resolve);
    for(const event of movie?['loadeddata','canplay','seeked']:['load'])media.addEventListener(event,done);
    media.addEventListener('error',()=>{if(e.dead)return;
      if(movie&&sc.compat_url&&media.getAttribute('src')!==sc.compat_url){media.src=sc.compat_url;media.load();return;}
      if(pending){pending=false;e.resolve();}signal(`Scene ${sc.id}: source media could not be decoded.`);
    });
    media.src=sc.url;if(movie)media.load();else media.decode?.().then(done).catch(()=>{});
    return e;
  }
  function windowFor(sc,e){
    const span=Math.max(1/60,sc.end-sc.start),v=e?.media,duration=number(v?.duration,span),speaker=sc.speaker_clip;
    const start=speaker?number(speaker.source_in_frame)/number(speaker.fps,60):clamp(sc.video_start,0,Math.max(0,duration-.5));
    const available=Math.max(1/60,duration-start);
    return {start,rate:speaker||available>=span-1/60?1:available/span,
      limit:speaker?.delivery_clock?start+(speaker.source_out_frame-speaker.source_in_frame)/speaker.fps:duration};
  }
  function sync(sc,e,t,active){
    if(!e?.movie)return;const v=e.media,w=windowFor(sc,e),wanted=w.start+Math.max(0,t-sc.start)*w.rate;
    const time=clamp(wanted,0,Math.max(0,number(v.duration,Infinity)-.001));
    if(v.readyState>=1){
      v.playbackRate=clamp(w.rate*number(clock.playbackRate,1),.0625,16);
      const tolerance=playing()&&active?.12:1/120;
      if(!v.seeking&&Math.abs(v.currentTime-time)>tolerance){try{v.currentTime=time;}catch(_){};}
    }
    if(active&&playing()&&wanted<w.limit){if(v.paused&&!e.starting){e.starting=true;v.play().catch(()=>{}).finally(()=>e.starting=false);}}
    else if(!v.paused)v.pause();
  }
  function transition(index,t){
    if(!options.transitions||index<1)return null;
    const old=scenes[index-1],next=scenes[index],kind=old.transition;
    if(!kind||kind==='none'||kind.startsWith('dip-')||model.transition_clips?.[kind]||Math.abs(old.end-next.start)>1/60)return null;
    let duration=Math.min(.4,(old.end-old.start)/2,(next.end-next.start)/2);
    if(kind==='crossfade'&&old.type==='video'){
      const e=source(old,index-1),d=e?.media?.duration,w=windowFor(old,e);
      if(!Number.isFinite(d)||d-w.start<(old.end-old.start)+duration-1e-7)return null;
    }
    duration=Math.round(duration*60)/60;
    if(duration<1/60||t>=next.start+duration)return null;
    return {old,index:index-1,kind,progress:clamp((t-next.start)/duration)};
  }
  function rect(mw,mh,f,W,H){
    const zoom=Math.max(1,number(f?.zoom,1)),fit=f?.fit==='contain'?Math.min:Math.max;
    const scale=fit(W/mw,H/mh)*zoom,w=mw*scale,h=mh*scale;
    const x=clamp(f?.x,-Math.max(0,(w/W-1)/2),Math.max(0,(w/W-1)/2));
    const y=clamp(f?.y,-Math.max(0,(h/H-1)/2),Math.max(0,(h/H-1)/2));
    return {x:(W-w)/2+x*W,y:(H-h)/2+y*H,w,h};
  }
  function draw(sc,e,t,alpha=1,dx=0,dy=0){
    if(!e?.ready||alpha<=0)return false;
    const v=e.media,mw=v.videoWidth||v.naturalWidth,mh=v.videoHeight||v.naturalHeight;if(!mw||!mh)return false;
    if(e.movie&&sc.speaker_clip?.delivery_clock&&windowFor(sc,e).start+Math.max(0,t-sc.start)>=windowFor(sc,e).limit)return false;
    const {width:W,height:H}=dims(),f=sc.framing,elapsed=Math.max(0,t-sc.start);
    ctx.save();ctx.globalAlpha=alpha;ctx.translate(dx,dy);
    const portrait=e.movie&&!sc.speaker_clip&&mh>mw&&mw/mh<W/H-.01&&Math.abs(number(f?.zoom,1)-1)<1e-6&&Math.abs(number(f?.x))<1e-6&&Math.abs(number(f?.y))<1e-6;
    if(portrait){
      const r=rect(mw,mh,null,W,H);ctx.save();ctx.filter=`blur(${24*canvas.height/1080}px)`;
      ctx.drawImage(v,r.x-3,r.y-3,r.w+6,r.h+6);ctx.restore();ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(0,0,W,H);
      const w=mw*H/mh;ctx.drawImage(v,(W-w)/2,0,w,H);ctx.restore();return true;
    }
    let zoom=1;
    if(!e.movie&&options.kenburns&&(f?sc.framed_zoom:!sc.no_zoom)){
      const rate=number(model.realtime?.zoom_rate,.02)*(f?1:sc.move==='hold'?.35:1);
      zoom=1+rate*(sc.move==='pull'&&!f?Math.max(0,sc.end-sc.start-elapsed):elapsed);
    }
    const camera=!e.movie&&!f&&!sc.no_zoom,px=camera&&model.look?.parallax,floaty=camera&&model.look?.cam_float;
    const n=sc.camera_index??scenes.indexOf(sc),p=(n*1.7)%6.283,q=(n*2.9)%6.283;
    const x=40+(floaty?2.6*Math.sin(2*Math.PI*.13*elapsed+p)+1.5*Math.sin(2*Math.PI*.31*elapsed+q):0);
    const y=40+(floaty?2.6*Math.sin(2*Math.PI*.31*elapsed+q)+1.5*Math.sin(2*Math.PI*.13*elapsed+p):0);
    const dest=ctx;
    if(px){
      scratch??=document.createElement('canvas');
      if(scratch.width!==canvas.width||scratch.height!==canvas.height){scratch.width=canvas.width;scratch.height=canvas.height;}
      ctx=scratch.getContext('2d');ctx.setTransform(scratch.width/W,0,0,scratch.height/H,0,0);ctx.clearRect(0,0,W,H);
    }
    ctx.save();
    if(floaty&&!px){ctx.translate(-x,-y);ctx.scale((W+80)/W,(H+80)/H);}
    ctx.translate(W/2,H/2);ctx.scale(zoom,zoom);ctx.translate(-W/2,-H/2);
    if(sc.tcard_id&&f?.fit==='contain'){ctx.fillStyle='white';ctx.fillRect(0,0,W,H);}
    const r=rect(mw,mh,f,W,H);ctx.drawImage(v,r.x,r.y,r.w,r.h);ctx.restore();
    if(px){
      ctx=dest;
      // The renderer's destination-perspective trapezoid, with subpixel strips.
      const w=W+80,h=H+80,d=26*(n%2===0?1:-1)*(2*elapsed/Math.max(1/60,sc.end-sc.start)-1),ratio=(w+2*d)/(w-2*d),count=256;
      for(let row=0;row<count;row++){
        const a=row/count,b=(row+1)/count,den=1+(ratio-1)*(a+b)/2,width=(w+2*d)/den;
        const top=ratio*a*h/(1+(ratio-1)*a),bottom=ratio*b*h/(1+(ratio-1)*b);
        ctx.drawImage(scratch,0,a*scratch.height,scratch.width,scratch.height/count,(w-width)/2-x,top-y,width,bottom-top+.35);
      }
    }
    ctx.restore();return true;
  }
  function paint(t){
    if(!host||!owner()||!model)return;
    let i=scenes.findIndex(s=>t>=s.start&&t<s.end);const sc=scenes[i],tx=sc?transition(i,t):null,active=new Set();
    const e=sc?source(sc,i):null;if(e){active.add(e);sync(sc,e,t,true);}
    const old=tx?source(tx.old,tx.index):null;if(old){active.add(old);sync(tx.old,old,t,true);}
    for(const [n,s]of scenes.entries())if(n!==i&&n!==tx?.index&&s.start>=t&&s.start<=t+4){const p=source(s,n);if(p&&!active.has(p)){active.add(p);sync(s,p,s.start,false);}if(active.size>=4)break;}
    for(const p of sources.values())if(!active.has(p))p.media.pause?.();
    const {width:W,height:H}=dims();ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);
    if(tx){const p=tx.progress;
      if(tx.kind.startsWith('slide-')){const k=tx.kind.slice(6),x=k==='left'?-W:k==='right'?W:0,y=k==='up'?-H:k==='down'?H:0;draw(tx.old,old,t,1,x*p,y*p);draw(sc,e,t,1,x*(p-1),y*(p-1));}
      else{draw(tx.old,old,t);draw(sc,e,t,p);}
    }else if(sc)draw(sc,e,t);
    if(sources.size>8)for(const p of [...sources.values()].sort((a,b)=>a.used-b.used)){if(sources.size<=8)break;if(!active.has(p)){release(p);sources.delete(p.key);}}
    grader?.paint(model.look?.grade,!!model.realtime?.youtube);
    mix(t);
  }
  function audioEntry(spec,key){
    let e=audio.get(key);if(e)return e;
    const media=document.createElement('audio');media.preload='auto';media.src=spec.url;media.load();e={media,key};audio.set(key,e);return e;
  }
  function mix(t){
    if(!clock||!model)return;const used=new Set(),outro=number(model.realtime?.outro_fade),duration=model.duration;
    const tail=outro>.05&&duration>outro+1?clamp((duration-t)/outro):1;
    // The VO is the existing mastered recording; imported picture audio is muted.
    if(Math.abs(clock.volume-tail)>1e-5)clock.volume=tail;
    for(const kind of ['music','sfx'])for(const [i,s]of (model[kind]||[]).entries()){
      if(!s.url||kind==='music'&&!options.music||s.transition&&!options.transitions||kind==='sfx'&&s.kind==='cash'&&!options.onscreentext)continue;
      if(t<s.start-3||t>=s.end)continue;
      const key=JSON.stringify([kind,s.url,s.start,i]),e=audioEntry(s,key),a=e.media;used.add(key);a.muted=clock.muted;
      const on=t>=s.start&&t<s.end,elapsed=Math.max(0,t-s.start),offset=number(s.source_start),span=s.end-s.start;
      const fadeOut=kind==='music'?Math.min(span/2,s.end>=duration-1/120?number(model.music_end_fade,4):number(model.realtime?.music_fade,1.5)):number(s.fade_out);
      const gain=number(s.level,1)*Math.min(1,s.fade_in?elapsed/s.fade_in:1,fadeOut?(s.end-t)/fadeOut:1)*(kind==='sfx'&&s.kind!=='hit'?tail:1);
      a.volume=clamp(on?gain:0);a.loop=kind==='music';a.playbackRate=number(clock.playbackRate,1);
      const wanted=kind==='music'&&Number.isFinite(a.duration)&&a.duration>offset?offset+elapsed%(a.duration-offset):offset+elapsed;
      if(a.readyState>=1&&!a.seeking&&Math.abs(a.currentTime-wanted)>.08)try{a.currentTime=wanted;}catch(_){}
      if(on&&playing()){if(a.paused&&!e.starting){e.starting=true;a.play().catch(()=>{}).finally(()=>e.starting=false);}}
      else a.pause();
    }
    for(const [key,e]of audio)if(!used.has(key)){release(e);audio.delete(key);}
  }
  function arm(){if(raf||!playing()||!host)return;const gen=generation;raf=requestAnimationFrame(now=>{raf=0;if(gen!==generation||!owner())return;if(now-last>=1000/30-1){last=now;paint(clock.currentTime||0);}arm();});}
  function tick(t,force=false){if(!host)return;if(force||!playing()||clock.seeking)paint(t);arm();}
  function update(manifest,opt){model=manifest;options={...opt};scenes=(manifest.scenes||[]).map(s=>({...s}));tick(clock?.currentTime||0,true);}
  function capture(doc){snapshots=new Map((doc?.scenes||[]).map(s=>[identity(s),mediaSignature(s)]));}
  function cancelResume(){voiceRequest++;}
  function voice(src){
    if(!clock||clock.getAttribute('src')===src)return;
    const token=++voiceRequest,v=clock,t=v.currentTime,wasPlaying=playing(),rate=v.playbackRate;
    const restore=()=>{v.removeEventListener('loadedmetadata',restore);if(!owner()||clock!==v)return;
      v.currentTime=Math.min(t,Math.max(0,v.duration-1/60));v.playbackRate=rate;
      if(token===voiceRequest&&wasPlaying)v.play().catch(()=>{});
    };
    v.addEventListener('loadedmetadata',restore,{once:true});v.src=src;v.load();
  }
  function local(doc,opt){
    if(!model||!owner())return;options={...opt};
    for(const sc of scenes){const s=(doc.scenes||[]).find(s=>identity(s)===identity(sc));if(!s)continue;
      if(typeof sceneFraming==='function')sc.framing=sceneFraming(s);
      sc.move=s.move||'hold';
      if(typeof effectiveSceneTransition==='function')sc.transition=effectiveSceneTransition(s,doc.scenes[doc.scenes.indexOf(s)+1]);
      if(!sc.speaker_clip&&typeof sceneVideoStart==='function')sc.video_start=sceneVideoStart(s,s.video?.approved_file||s.video?.file);
      if(snapshots.get(identity(s))!==mediaSignature(s)&&!s.speaker_clip&&typeof pvSceneMedia==='function')Object.assign(sc,pvSceneMedia(s));
    }
    model.look={...model.look,cam_float:!!doc.cam_float,grade:!!doc.film_grade,parallax:!!doc.cam_parallax&&!!model.realtime?.youtube};
    tick(clock.currentTime||0,true);
  }
  function clear(){
    generation++;cancelResume();cancelAnimationFrame(raf);raf=0;for(const [event,fn]of listeners)clock?.removeEventListener(event,fn);listeners=[];
    for(const e of sources.values())release(e);for(const e of audio.values())release(e);sources.clear();audio.clear();snapshots.clear();
    resize?.disconnect();resize=null;grader?.clear();grader=null;scratch=null;host?.remove();host=null;canvas=null;ctx=null;clock=null;model=null;scenes=[];last=-1;owner=()=>false;
  }
  function mount(stage,base,manifest,opt,current){
    clear();clock=base;owner=current;host=document.createElement('div');host.className='live-media';canvas=document.createElement('canvas');host.append(canvas);stage.prepend(host);ctx=canvas.getContext('2d',{alpha:false});
    grader=window.LiveGrade?.mount(host,canvas,()=>tick(clock?.currentTime||0,true),signal);
    const size=()=>{const d=dims(),scale=Math.min(1,Math.max(640,stage.clientWidth*devicePixelRatio)/d.width);canvas.width=Math.round(d.width*scale);canvas.height=Math.round(d.height*scale);tick(clock.currentTime||0,true);};
    const on=(name,fn)=>{clock.addEventListener(name,fn);listeners.push([name,fn]);};
    on('playing',()=>{tick(clock.currentTime||0);arm();});on('pause',()=>{cancelAnimationFrame(raf);raf=0;tick(clock.currentTime||0);});
    for(const event of ['seeking','seeked','loadeddata','volumechange','ratechange'])on(event,()=>tick(clock.currentTime||0));
    update(manifest,opt);capture(DOC);size();resize=new ResizeObserver(size);resize.observe(stage);
    // No movie encoding or whole-project preload. Warm the current and next sources.
    return Promise.resolve();
  }
  return {mount,update,local,capture,tick,clear,rect,windowFor,transition,voice,cancelResume};
})();
