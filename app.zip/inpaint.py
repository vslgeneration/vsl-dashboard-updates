"""Local Stable-Diffusion INPAINTING (generative fill / object removal) — runs on the user's GPU, no cloud.
Lazy-loads the pipeline on first use (heavy import). Low-VRAM config (cpu offload + slicing) so it fits a ~3 GB
budget. safety_checker off + VAE upcast avoids the classic all-black fp16 output. Only the packaged runtime
python has torch+diffusers+the model; on any machine without them, `available()` is False and callers degrade."""
import os
import threading
from pathlib import Path
from PIL import Image

# model cache lives in VSLDashboard/models (next to app/ and source/). app/inpaint.py -> parent.parent = VSLDashboard.
_MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
for _p in (Path(__file__).resolve().parents[i] / "models" for i in range(1, 5)):
    if _p.exists():
        _MODELS_DIR = _p
        break
os.environ.setdefault("HF_HOME", str(_MODELS_DIR))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

_MODEL = "stable-diffusion-v1-5/stable-diffusion-inpainting"
_pipe = None
_lama = None
_lock = threading.Lock()
_load_err = None


def lama_available():
    """True if LaMa (content-aware REMOVAL, no hallucination) is importable."""
    try:
        import simple_lama_inpainting  # noqa
        return True
    except Exception:
        return False


def _dilate(mask_L, frac=0.03):
    """Grow the mask by ~`frac` of the short side so it fully covers the object + its edges/shadow (residue-free)."""
    try:
        import cv2
        import numpy as np
        a = np.array(mask_L)
        k = max(3, (int(round(min(mask_L.size) * frac)) | 1))     # odd kernel
        a = cv2.dilate(a, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)), iterations=1)
        return Image.fromarray(a)
    except Exception:
        from PIL import ImageFilter
        return mask_L.filter(ImageFilter.MaxFilter(15))


def _flat_fill(image, m):
    """If the background just OUTSIDE the mask is near-uniform (plain white / solid / smooth-gradient backdrop),
    fill the hole by SMOOTHLY propagating the surrounding pixels inward (cv2 Telea). This tracks a subtle
    gradient/vignette so no rectangular patch shows — LaMa would smear a grey haze here instead. None if textured."""
    try:
        import cv2
        import numpy as np
        a = np.array(m, dtype=np.uint8)
        img = np.array(image, dtype=np.uint8)
        k = max(5, (int(round(min(m.size) * 0.05)) | 1))
        ring = cv2.dilate(a, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))) & (~a)
        px = img[ring > 0]
        if px.shape[0] < 50:
            return None
        std = float(px.reshape(-1, 3).std(axis=0).mean())
        if std > 14:                                   # textured surroundings -> let LaMa handle it
            return None
        rad = max(4, int(round(min(m.size) * 0.02)))
        bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        filled = cv2.inpaint(bgr, a, rad, cv2.INPAINT_TELEA)
        out = cv2.cvtColor(filled, cv2.COLOR_BGR2RGB)
        return Image.fromarray(out)
    except Exception:
        return None


def _lama_run(image, m):
    """Run LaMa on the smallest region that fully contains the mask (bbox + generous margin) instead of the
    whole frame: this focuses the model's context near the hole -> sharper texture (wood-grain, fabric) and it
    leaves every pixel outside the crop bit-for-bit identical. Huge crops are gently down-scaled toward LaMa's
    training sweet-spot (~1280) so a big hole doesn't fill as a low-frequency blur. Falls back to whole-frame."""
    global _lama
    if _lama is None:
        with _lock:
            if _lama is None:
                from simple_lama_inpainting import SimpleLama
                _lama = SimpleLama()
    try:
        import numpy as np
        from PIL import ImageFilter
        a = np.array(m, np.uint8)
        ys, xs = np.where(a > 0)
        if len(xs) == 0:
            return image
        x0, x1, y0, y1 = int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max())
        bw, bh = x1 - x0, y1 - y0
        mx, my = int(bw * 1.1) + 24, int(bh * 1.1) + 24                 # generous margin -> real context around the hole
        cx0, cy0 = max(0, x0 - mx), max(0, y0 - my)
        cx1, cy1 = min(image.width, x1 + mx), min(image.height, y1 + my)
        crop, cmask = image.crop((cx0, cy0, cx1, cy1)), m.crop((cx0, cy0, cx1, cy1))
        cw, ch = crop.size
        scale = min(1.0, 1280.0 / max(cw, ch))                          # only ever down-scale, and only if large
        work, wmask = crop, cmask
        if scale < 1.0:
            work = crop.resize((max(8, int(cw * scale)), max(8, int(ch * scale))), Image.LANCZOS)
            wmask = cmask.resize(work.size, Image.LANCZOS)
        filled = _lama(work, wmask).convert("RGB")
        if filled.size != (cw, ch):
            filled = filled.resize((cw, ch), Image.LANCZOS)
        hard = cmask.point(lambda v: 255 if v > 40 else 0).filter(ImageFilter.GaussianBlur(2))
        out = image.copy()
        out.paste(Image.composite(filled, crop, hard), (cx0, cy0))
        return out
    except Exception:
        out = _lama(image, m).convert("RGB")                           # safe fallback: whole-frame
        return out.resize(image.size, Image.LANCZOS) if out.size != image.size else out


def erase(image, mask):
    """CONTENT-AWARE removal: fill the masked (white) region from the SURROUNDINGS — no invented content.
    This is what an empty-prompt 'erase' should do (SD would hallucinate). Fast, keeps the rest identical.
    The mask is DILATED first so a rough brush still removes the whole object + its edges (no left-over trace).
    Near-uniform backdrops (plain white etc.) are solid-filled to avoid LaMa's grey haze; textured -> LaMa
    run on a focused crop around the hole (sharper texture, rest of the frame untouched)."""
    image = image.convert("RGB")
    m = _dilate(mask.convert("L").point(lambda v: 255 if v > 40 else 0))
    flat = _flat_fill(image, m)
    if flat is not None:
        return flat
    return _lama_run(image, m)


def available():
    """True if torch (with CUDA) + diffusers are importable — i.e. this python can run inpainting."""
    try:
        import torch  # noqa
        import diffusers  # noqa
        return True
    except Exception:
        return False


def load(progress=None):
    """Load (once) and return the pipeline, or raise. `progress(msg)` optional status callback."""
    global _pipe, _load_err
    if _pipe is not None:
        return _pipe
    with _lock:
        if _pipe is not None:
            return _pipe
        if progress:
            progress("loading model (first run downloads ~2 GB)…")
        import torch
        from diffusers import AutoPipelineForInpainting
        p = AutoPipelineForInpainting.from_pretrained(_MODEL, torch_dtype=torch.float16,
                                                      safety_checker=None, requires_safety_checker=False)
        p.set_progress_bar_config(disable=True)
        try:
            p.vae.config.force_upcast = True          # VAE in fp32 -> no fp16 NaN -> no black image
        except Exception:
            pass
        p.enable_model_cpu_offload()                  # keep model in system RAM, stream to GPU -> low VRAM
        for fn in ("enable_attention_slicing", "enable_vae_slicing", "enable_vae_tiling"):
            try:
                getattr(p, fn)()
            except Exception:
                pass
        _pipe = p
        return _pipe


def _fit(im, long=768):
    """Scale so the long side is ~`long` and both sides are multiples of 8 (SD requires /8)."""
    w, h = im.size
    s = long / max(w, h)
    nw, nh = max(64, round(w * s / 8) * 8), max(64, round(h * s / 8) * 8)
    return nw, nh


def inpaint(image, mask, prompt="", steps=30, guidance=7.5, seed=None, feather=6):
    """Return a new PIL image: the masked (white) region regenerated. Empty prompt = clean removal. `image`/`mask`
    are PIL (mask: white=change, black=keep). Output is the SAME size as `image`, with only the masked area changed."""
    import torch
    from PIL import ImageFilter
    pipe = load()
    image = image.convert("RGB")
    mask = mask.convert("L")
    ow, oh = image.size
    nw, nh = _fit(image, 768)
    img_s = image.resize((nw, nh), Image.LANCZOS)
    msk_s = mask.resize((nw, nh), Image.LANCZOS)
    if feather:
        msk_s = msk_s.filter(ImageFilter.GaussianBlur(feather))
    gen = None
    if seed is not None:
        try:
            gen = torch.Generator(device="cuda").manual_seed(int(seed))
        except Exception:
            gen = None
    p = (prompt or "").strip() or "clean, seamless, photorealistic, high detail"
    neg = "text, watermark, blurry, distorted, low quality, artifacts"
    result = pipe(prompt=p, negative_prompt=neg, image=img_s, mask_image=msk_s,
                  num_inference_steps=int(steps), guidance_scale=float(guidance), generator=gen).images[0]
    result = result.resize((ow, oh), Image.LANCZOS)
    # composite ONLY the masked area back onto the original (keeps the rest pixel-identical)
    hard = mask.point(lambda v: 255 if v > 40 else 0)
    if feather:
        hard = hard.filter(ImageFilter.GaussianBlur(max(1, feather // 2)))
    return Image.composite(result, image, hard)
