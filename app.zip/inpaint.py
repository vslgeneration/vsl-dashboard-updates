"""Local Stable-Diffusion INPAINTING (generative fill / object removal) — runs on the user's GPU, no cloud.
Lazy-loads the pipeline on first use (heavy import). Low-VRAM config (cpu offload + slicing) so it fits a ~3 GB
budget. safety_checker off + VAE upcast avoids the classic all-black fp16 output. Only the packaged runtime
python has torch+diffusers+the model; on any machine without them, `available()` is False and callers degrade."""
import os
import threading
from pathlib import Path
from PIL import Image

# model cache lives in VSLDashboard/models (next to app/ and source/). app/inpaint.py -> parent.parent = VSLDashboard.
_MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
for _p in (Path(__file__).resolve().parents[i] / "models" for i in range(1, 5)):
    if _p.exists():
        _MODELS_DIR = _p
        break
os.environ.setdefault("HF_HOME", str(_MODELS_DIR))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

_MODEL = "stable-diffusion-v1-5/stable-diffusion-inpainting"
_pipe = None
_lock = threading.Lock()
_load_err = None


def available():
    """True if torch (with CUDA) + diffusers are importable — i.e. this python can run inpainting."""
    try:
        import torch  # noqa
        import diffusers  # noqa
        return True
    except Exception:
        return False


def load(progress=None):
    """Load (once) and return the pipeline, or raise. `progress(msg)` optional status callback."""
    global _pipe, _load_err
    if _pipe is not None:
        return _pipe
    with _lock:
        if _pipe is not None:
            return _pipe
        if progress:
            progress("loading model (first run downloads ~2 GB)…")
        import torch
        from diffusers import AutoPipelineForInpainting
        p = AutoPipelineForInpainting.from_pretrained(_MODEL, torch_dtype=torch.float16,
                                                      safety_checker=None, requires_safety_checker=False)
        p.set_progress_bar_config(disable=True)
        try:
            p.vae.config.force_upcast = True          # VAE in fp32 -> no fp16 NaN -> no black image
        except Exception:
            pass
        p.enable_model_cpu_offload()                  # keep model in system RAM, stream to GPU -> low VRAM
        for fn in ("enable_attention_slicing", "enable_vae_slicing", "enable_vae_tiling"):
            try:
                getattr(p, fn)()
            except Exception:
                pass
        _pipe = p
        return _pipe


def _fit(im, long=768):
    """Scale so the long side is ~`long` and both sides are multiples of 8 (SD requires /8)."""
    w, h = im.size
    s = long / max(w, h)
    nw, nh = max(64, round(w * s / 8) * 8), max(64, round(h * s / 8) * 8)
    return nw, nh


def inpaint(image, mask, prompt="", steps=30, guidance=7.5, seed=None, feather=6):
    """Return a new PIL image: the masked (white) region regenerated. Empty prompt = clean removal. `image`/`mask`
    are PIL (mask: white=change, black=keep). Output is the SAME size as `image`, with only the masked area changed."""
    import torch
    from PIL import ImageFilter
    pipe = load()
    image = image.convert("RGB")
    mask = mask.convert("L")
    ow, oh = image.size
    nw, nh = _fit(image, 768)
    img_s = image.resize((nw, nh), Image.LANCZOS)
    msk_s = mask.resize((nw, nh), Image.LANCZOS)
    if feather:
        msk_s = msk_s.filter(ImageFilter.GaussianBlur(feather))
    gen = None
    if seed is not None:
        try:
            gen = torch.Generator(device="cuda").manual_seed(int(seed))
        except Exception:
            gen = None
    p = (prompt or "").strip() or "clean, seamless, photorealistic, high detail"
    neg = "text, watermark, blurry, distorted, low quality, artifacts"
    result = pipe(prompt=p, negative_prompt=neg, image=img_s, mask_image=msk_s,
                  num_inference_steps=int(steps), guidance_scale=float(guidance), generator=gen).images[0]
    result = result.resize((ow, oh), Image.LANCZOS)
    # composite ONLY the masked area back onto the original (keeps the rest pixel-identical)
    hard = mask.point(lambda v: 255 if v > 40 else 0)
    if feather:
        hard = hard.filter(ImageFilter.GaussianBlur(max(1, feather // 2)))
    return Image.composite(result, image, hard)
