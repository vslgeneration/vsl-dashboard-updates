"""VSL Dashboard — desktop launcher.

Starts the local Flask server in a background thread and opens the dashboard in its own
native window (pywebview / Edge WebView2) — no browser, feels like a real program. Everything
runs on this machine (127.0.0.1); only image/video generation reaches out to the internet.

Run with:  python desktop.py     (packaged: the .exe runs this)
"""
import os
import socket
import threading
import time
import urllib.request
from pathlib import Path

# Make the process DPI-aware BEFORE any window exists — otherwise Windows virtualizes coordinates
# on scaled displays (125/150%), so our resize/move land short (thin gap at the edges, title bar
# shifted). Per-monitor aware keeps SPI_GETWORKAREA and resize/move in the same pixel space.
try:
    import ctypes as _ctypes
    try:
        _ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_AWARE
    except Exception:
        _ctypes.windll.user32.SetProcessDPIAware()
except Exception:
    pass

HOST = "127.0.0.1"

# ---- packaged-layout wiring (no-op in a plain dev checkout) -----------------
# Packaged tree:  VSLDashboard/{VSLDashboard.exe, runtime/, ffmpeg/, app/, data/}
# desktop.py lives in app/. When the sibling runtime/ or ffmpeg/ exists we're packaged, so point
# ffmpeg + all user data at the bundled folders. In dev these siblings don't exist → unchanged.
_HERE = Path(__file__).resolve().parent          # app/  (dev: the dashboard folder)
_ROOT = _HERE.parent                             # VSLDashboard/  (dev: video-agent-template)
_PACKAGED = (_ROOT / "runtime").exists() or (_ROOT / "ffmpeg").exists()
if _PACKAGED:
    _ff = _ROOT / "ffmpeg"
    if _ff.exists():
        os.environ["PATH"] = str(_ff) + os.pathsep + os.environ.get("PATH", "")
    _data = _ROOT / "data"
    _data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VSL_DATA_DIR", str(_data))
    # bundled whisper models → offline SRT. whisper reads $XDG_CACHE_HOME/whisper/*.pt (respected
    # by its load_model); the SRT subprocess inherits this env, so no code change is needed there.
    _cache = _ROOT / "cache"
    if (_cache / "whisper").exists():
        os.environ.setdefault("XDG_CACHE_HOME", str(_cache))
    # seed the user's voices list on first run (bundled default lives beside the app)
    _seed = _HERE / "voices.json"
    _dst = _data / "voices.json"
    if _seed.exists() and not _dst.exists():
        try:
            _dst.write_bytes(_seed.read_bytes())
        except Exception:
            pass

# WebView2 storage (cookies + localStorage) lives here so the login session, zoom level, last
# project etc. PERSIST across restarts (needs private_mode=False in webview.start).
STORAGE_PATH = str(((_ROOT / "data") if _PACKAGED else _HERE) / "webview-data")

# Splash shown instantly while the local server boots (a second or two), then we swap to the app.
SPLASH_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
html,body{height:100%;margin:0;overflow:hidden;background:radial-gradient(900px 520px at 50% 42%,#0d1a12,#060c09 70%);
 display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;color:#e6ede8}
.w{text-align:center;animation:f .32s ease both}
.x{position:fixed;top:12px;right:16px;width:36px;height:36px;border:0;background:rgba(255,255,255,.05);color:#8ca596;border-radius:9px;font-size:22px;line-height:1;cursor:pointer;z-index:20;font-family:inherit}
.x:hover{background:rgba(224,67,67,.22);color:#fff}
.d{display:flex;gap:15px;justify-content:center;margin-bottom:24px}
.d span{width:17px;height:17px;border-radius:50%;background:linear-gradient(180deg,#46ac5a,#237e43);
 box-shadow:0 0 18px rgba(82,189,102,.55);animation:b 1s ease-in-out infinite}
.d span:nth-child(2){animation-delay:.16s}.d span:nth-child(3){animation-delay:.32s}
h1{margin:0;font-size:24px;font-weight:700;letter-spacing:.6px}
p{margin:10px 0 0;font-size:13px;color:#839a8c}
@keyframes b{0%,75%,100%{transform:translateY(0) scale(.85);opacity:.45}38%{transform:translateY(-20px) scale(1);opacity:1}}
@keyframes f{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:none}}
</style></head><body><button class="x" onclick="try{window.pywebview.api.win_close()}catch(e){}" title="Close">&times;</button>
<div class="w"><div class="d"><span></span><span></span><span></span></div>
<h1>VSL Dashboard</h1><p>Checking for updates…</p></div></body></html>"""


def _free_port():
    """Grab a free loopback port so we never clash with anything already listening."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, 0))
        return s.getsockname()[1]
    finally:
        s.close()


def _port():
    """Prefer a STABLE fixed port so the window's origin (127.0.0.1:PORT) — and therefore its
    localStorage (zoom, last project, saved style presets…) — persists across restarts. Only fall
    back to a random free port if the fixed one is already taken."""
    env = os.environ.get("VSL_PORT")
    if env:
        return int(env)
    fixed = 8770
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, fixed))
        return fixed
    except OSError:
        return _free_port()
    finally:
        s.close()


PORT = _port()
os.environ["VSL_HOST"] = HOST
os.environ["VSL_PORT"] = str(PORT)

# Desktop app: require a fresh sign-in every launch (a random session key per run invalidates any
# leftover session cookie). The login form still remembers the username/password in localStorage,
# so the user just clicks Sign in.
os.environ.setdefault("VSL_FRESH_SESSION", "1")

import app  # noqa: E402  (env must be set before app decides its host/port)


def _serve():
    # threaded so long polls / renders don't block the UI; no reloader inside a frozen app.
    app.app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)


def _wait_until_up(url, timeout=30.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.2)
    return False


_window = None


def _work_area():
    """Monitor work area (screen minus the taskbar) in PHYSICAL pixels, via SPI_GETWORKAREA."""
    import ctypes
    from ctypes import wintypes
    r = wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def _logical_work_area():
    """Work-area size in LOGICAL (DIP) pixels = physical / primary-monitor DPI scale. create_window
    expects logical px, so on a scaled display (125/150%) this is what makes the window open full-size."""
    import ctypes
    from ctypes import wintypes
    _x, _y, w, h = _work_area()   # physical
    scale = 1.0
    try:
        mon = ctypes.windll.user32.MonitorFromPoint(wintypes.POINT(0, 0), 1)   # MONITOR_DEFAULTTOPRIMARY
        dx, dy = ctypes.c_uint(), ctypes.c_uint()
        ctypes.windll.shcore.GetDpiForMonitor(mon, 0, ctypes.byref(dx), ctypes.byref(dy))   # MDT_EFFECTIVE_DPI
        if dx.value:
            scale = dx.value / 96.0
    except Exception:
        pass
    return max(1000, int(w / scale)), max(650, int(h / scale))


def _logical_work_rect():
    """Work-area ORIGIN + size in logical px, so create_window can open ALREADY at the full work area
    (top-left, full size) instead of being centered — which after an update-relaunch showed as a small,
    right-shifted window until _fill_work_area kicked in."""
    import ctypes
    from ctypes import wintypes
    lx, ly, w, h = _work_area()   # physical
    scale = 1.0
    try:
        mon = ctypes.windll.user32.MonitorFromPoint(wintypes.POINT(0, 0), 1)   # primary
        dx, dy = ctypes.c_uint(), ctypes.c_uint()
        ctypes.windll.shcore.GetDpiForMonitor(mon, 0, ctypes.byref(dx), ctypes.byref(dy))
        if dx.value:
            scale = dx.value / 96.0
    except Exception:
        pass
    return int(lx / scale), int(ly / scale), max(1000, int(w / scale)), max(650, int(h / scale))


def _hwnd():
    try:
        import ctypes
        return ctypes.windll.user32.FindWindowW(None, "VSL Dashboard")
    except Exception:
        return 0


def _enable_taskbar_minimize():
    """Frameless windows lack WS_MINIMIZEBOX, so Windows won't minimize on a taskbar-button click and
    the minimize is un-animated. Add the style bit (WITHOUT SWP_FRAMECHANGED, so no title bar/frame is
    drawn) → clicking the taskbar icon toggles minimize/restore with the normal smooth animation."""
    try:
        import ctypes
        hwnd = _hwnd()
        if not hwnd:
            return
        GWL_STYLE = -16
        WS_MINIMIZEBOX = 0x00020000
        cur = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE)
        if not (cur & WS_MINIMIZEBOX):
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, cur | WS_MINIMIZEBOX)
    except Exception:
        pass


def _set_bounds(x, y, w, h):
    """Position the window in PHYSICAL pixels straight through the Win32 HWND — pywebview's own
    resize/move mis-scale on high-DPI displays (window too big/small, title bar shifted); SetWindowPos
    uses the same pixel space as SPI_GETWORKAREA, so this lands exactly."""
    try:
        import ctypes
        hwnd = _hwnd()
        if hwnd:
            ctypes.windll.user32.SetWindowPos(hwnd, 0, int(x), int(y), int(w), int(h), 0x0004)  # SWP_NOZORDER
            return True
    except Exception:
        pass
    return False


def _get_rect():
    try:
        import ctypes
        from ctypes import wintypes
        hwnd = _hwnd()
        r = wintypes.RECT()
        if hwnd and ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return r.left, r.top, r.right - r.left, r.bottom - r.top
    except Exception:
        pass
    return None


def _animate_to(x, y, w, h, dur=0.19, steps=13):
    """Glide the window from its current bounds to the target (easeOut) so maximize/restore feels
    smooth instead of snapping."""
    cur = _get_rect()
    if not cur:
        _set_bounds(x, y, w, h)
        return
    cx, cy, cw, ch = cur
    for i in range(1, steps + 1):
        e = 1 - (1 - i / steps) ** 3   # easeOutCubic
        _set_bounds(cx + (x - cx) * e, cy + (y - cy) * e, cw + (w - cw) * e, ch + (h - ch) * e)
        time.sleep(dur / steps)
    _set_bounds(x, y, w, h)


def _set_corners(rounded):
    """Win11 rounds window corners via DWM. Maximized apps normally get SQUARE corners; because we
    fill the screen ourselves (not a real OS-maximize) DWM keeps rounding, leaving a thin grey edge.
    Force square when filled, rounded when windowed — matches every other app."""
    try:
        import ctypes
        hwnd = _hwnd()
        if not hwnd:
            return
        dwm = ctypes.windll.dwmapi
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        pref = ctypes.c_int(2 if rounded else 1)   # 2 = ROUND, 1 = DONOTROUND
        dwm.DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(pref), ctypes.sizeof(pref))
        # remove the thin 1px window border line (DWMWA_BORDER_COLOR=34, DWMWA_COLOR_NONE=0xFFFFFFFE)
        col = ctypes.c_uint(0xFFFFFFFE)
        dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(col), ctypes.sizeof(col))
    except Exception:
        pass


def _fill_work_area(animate=False):
    x, y, w, h = _work_area()
    if animate:
        _animate_to(x, y, w, h)
    elif not _set_bounds(x, y, w, h):
        try:
            _window.resize(w, h); _window.move(x, y)
        except Exception:
            pass
    _set_corners(False)              # maximized → square corners (kills the grey edge line)


def _restore_win(animate=True):
    x, y, w, h = _work_area()
    ww, wh = int(w * 0.72), int(h * 0.82)
    tx, ty = x + (w - ww) // 2, y + (h - wh) // 2
    if animate:
        _animate_to(tx, ty, ww, wh)
    elif not _set_bounds(tx, ty, ww, wh):
        try:
            _window.resize(ww, wh); _window.move(tx, ty)
        except Exception:
            pass
    _set_corners(True)               # windowed → rounded corners (like every other Win11 app)


# ---- auto-update: pull newer app code from GitHub, staged for the launcher to apply next start ----
def _is_newer(remote, local):
    def parse(v):
        try:
            return [int(x) for x in str(v).strip().lstrip("vV").split(".")]
        except Exception:
            return [0]
    return parse(remote) > parse(local)


def _repo_base():
    try:
        import json
        cfg = json.loads((_HERE / "update.json").read_text(encoding="utf-8"))
        repo = (cfg.get("repo") or "").strip()
        if cfg.get("enabled") and repo:
            return f"https://raw.githubusercontent.com/{repo}/main"
    except Exception:
        pass
    return None


def _pending_version():
    """Return the newer remote version string if an update is available, else None (fast + safe)."""
    base = _repo_base()
    if not base:
        return None
    try:
        vf = _HERE / "version.txt"
        local = vf.read_text(encoding="utf-8").strip() if vf.exists() else "0"
        remote = urllib.request.urlopen(base + "/version.txt", timeout=6).read().decode("utf-8").strip()
        return remote if (remote and _is_newer(remote, local)) else None
    except Exception:
        return None


def _download_update(remote):
    """Download the newer app.zip into _update/ so the launcher applies it on the next start."""
    base = _repo_base()
    if not base:
        return False
    try:
        data = urllib.request.urlopen(base + "/app.zip", timeout=300).read()
        upd = _ROOT / "_update"
        upd.mkdir(parents=True, exist_ok=True)
        (upd / "app.zip").write_bytes(data)
        (upd / "version.txt").write_text(remote, encoding="utf-8")
        return True
    except Exception:
        return False


def _relaunch():
    """Apply the just-downloaded update in place, then restart by re-running THIS interpreter directly.
    We deliberately do NOT relaunch through VSLDashboard.exe: its PyInstaller one-file bootloader can
    fail with 'Failed to load Python DLL' when spawned programmatically (parent exiting mid-launch).
    app/ files aren't locked on Windows (Python reads sources into memory), so we can overwrite them."""
    try:
        upd = _ROOT / "_update"
        zp = upd / "app.zip"
        if zp.exists():
            import zipfile
            with zipfile.ZipFile(zp) as z:
                z.extractall(_HERE)                       # _HERE = app/  (staged update → live code)
            vp = upd / "version.txt"
            if vp.exists():
                (_HERE / "version.txt").write_bytes(vp.read_bytes())
            import shutil
            shutil.rmtree(upd, ignore_errors=True)
    except Exception:
        pass
    try:
        import sys as _sys
        import subprocess
        # sys.executable is runtime/pythonw.exe (the bundled interpreter) — no fragile .exe bootloader
        _env = dict(os.environ); _env["VSL_RELAUNCH"] = "1"   # child waits out the old instance's singleton mutex
        subprocess.Popen([_sys.executable, str(_HERE / "desktop.py")], cwd=str(_HERE), env=_env)
    except Exception:
        pass
    os._exit(0)


# ---- "what's new" notes: show a simple list of changes the first launch after an update ----
def _data_dir():
    return Path(os.environ.get("VSL_DATA_DIR") or _HERE)


def _app_version():
    try:
        return (_HERE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return "0"


def _vnum(v):
    try:
        return int(str(v).strip().lstrip("vV").split(".")[0])
    except Exception:
        return None


def _update_notes_js():
    """If the app version advanced since the last launch, return JS that shows an overlay listing
    what changed (from changelog.json), else None. Records the current version as 'seen' so the notes
    appear exactly once — on the first launch after an update."""
    try:
        import json
        seen_f = _data_dir() / "seen_version.txt"
        cur = _app_version()
        seen = seen_f.read_text(encoding="utf-8").strip() if seen_f.exists() else None
        seen_f.write_text(cur, encoding="utf-8")          # remember for next launch (always)
        cn, sn = _vnum(cur), _vnum(seen)
        if not seen or cn is None or sn is None or cn <= sn:
            return None                                    # fresh install or no jump → nothing to show
        cl_f = _HERE / "changelog.json"
        if not cl_f.exists():
            return None
        cl = json.loads(cl_f.read_text(encoding="utf-8"))
        notes = []
        for k in sorted(cl, key=lambda x: _vnum(x) or 0):
            kn = _vnum(k)
            if kn is not None and sn < kn <= cn:
                block = cl[k] if isinstance(cl[k], list) else [str(cl[k])]
                notes.extend(str(s) for s in block)
        if not notes:
            return None
        payload = json.dumps({"from": seen, "to": cur, "notes": notes}, ensure_ascii=False)
        return _NOTES_JS.replace("__PAYLOAD__", payload)
    except Exception:
        return None


_NOTES_JS = r"""(function run(){
  try{
    if(!document.body){ return void setTimeout(run,120); }
    var D = __PAYLOAD__;
    if(!D.notes || !D.notes.length || document.getElementById('vslUpd')) return;
    var esc = function(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); };
    var items = D.notes.map(function(s){
      return '<li style="margin:0 0 11px;padding-left:26px;position:relative;line-height:1.5;color:#dfeae2;font-size:14px">'
           + '<span style="position:absolute;left:0;top:0;color:#52bd66;font-weight:700">✓</span>'
           + esc(s) + '</li>';
    }).join('');
    var st = document.createElement('style');
    st.textContent = '@keyframes vslUf{from{opacity:0}to{opacity:1}}@keyframes vslUc{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}';
    document.head.appendChild(st);
    var wrap = document.createElement('div'); wrap.id='vslUpd';
    wrap.style.cssText='position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;'
      +'background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif;animation:vslUf .25s ease';
    var card = document.createElement('div');
    card.style.cssText='max-width:470px;width:86%;max-height:80vh;overflow:auto;background:#0e1a13;border:1px solid #1f3a29;'
      +'border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:26px 26px 22px;animation:vslUc .28s ease';
    card.innerHTML =
      '<div style="display:flex;align-items:center;gap:11px;margin-bottom:4px">'
      +'<div style="width:36px;height:36px;border-radius:50%;flex:none;background:linear-gradient(180deg,#46ac5a,#237e43);'
      +'display:flex;align-items:center;justify-content:center;box-shadow:0 0 16px rgba(82,189,102,.5)">'
      +'<span style="color:#fff;font-size:20px">✓</span></div>'
      +'<div><div style="font-size:17px;font-weight:700;color:#eaf3ec">Application updated</div>'
      +'<div style="font-size:12px;color:#7f9788">Version '+esc(D.from)+' → '+esc(D.to)+'</div></div></div>'
      +'<div style="font-size:12.5px;color:#8ca596;margin:14px 0 12px">What\'s new in this update:</div>'
      +'<ul style="list-style:none;margin:0;padding:0">'+items+'</ul>'
      +'<button id="vslUpdOk" style="margin-top:18px;width:100%;padding:11px;border:0;border-radius:10px;'
      +'background:linear-gradient(180deg,#3fa554,#2b8443);color:#fff;font-size:14px;font-weight:600;cursor:pointer">OK</button>';
    wrap.appendChild(card);
    document.body.appendChild(wrap);
    function close(){ wrap.style.animation='vslUf .18s ease reverse'; setTimeout(function(){ wrap.remove(); },170); }
    card.querySelector('#vslUpdOk').onclick = close;
    wrap.addEventListener('click', function(e){ if(e.target===wrap) close(); });
  }catch(e){}
})();"""


# ---- notification-sound preference (shared with the web app via app_config.json) --------------
def _notif_on():
    try:
        return bool(app._load_config().get("notif_sound", True))
    except Exception:
        return True


def _set_notif(on):
    try:
        cfg = app._load_config(); cfg["notif_sound"] = bool(on); app._save_config(cfg)
    except Exception:
        pass
    try:
        _window.run_js("try{window.__setNotifSound(%s)}catch(e){}" % ("true" if on else "false"))
    except Exception:
        pass


# ---- system tray: dependency-free Win32 (Shell_NotifyIcon). Runs in its OWN thread with a
# message-only window. EVERYTHING is guarded — if any step fails, `_tray` stays None and the app
# behaves exactly as before (the close button quits). It can never block launch. -----------------
_quitting = {"v": False}
_tray = None


class _Tray:
    def __init__(self, icon_path, on_show, on_exit):
        self.icon_path = str(icon_path)
        self.on_show = on_show
        self.on_exit = on_exit
        self.hwnd = None
        self._nid = None
        self._added = False
        self._proc_ref = None      # keep the WNDPROC callback alive (GC would crash the message loop)
        self._u = self._shell = self._ctypes = self._wt = None

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            import ctypes
            from ctypes import wintypes
            self._ctypes = ctypes; self._wt = wintypes
            u = ctypes.windll.user32; k = ctypes.windll.kernel32
            shell = ctypes.windll.shell32
            self._u = u; self._shell = shell

            WM_APP = 0x8000; WM_TRAY = WM_APP + 1
            WM_RBUTTONUP = 0x0205; WM_LBUTTONDBLCLK = 0x0203; WM_DESTROY = 0x0002
            NIM_ADD, NIM_DELETE = 0, 2
            NIF_MESSAGE, NIF_ICON, NIF_TIP = 1, 2, 4
            IMAGE_ICON = 1; LR_LOADFROMFILE = 0x10; LR_DEFAULTSIZE = 0x40
            MF_STRING, MF_CHECKED, MF_SEPARATOR = 0x0, 0x8, 0x800
            TPM_RIGHTBUTTON, TPM_RETURNCMD = 0x2, 0x100
            LRESULT = ctypes.c_ssize_t

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            class NID(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND), ("uID", wintypes.UINT),
                            ("uFlags", wintypes.UINT), ("uCallbackMessage", wintypes.UINT),
                            ("hIcon", wintypes.HICON), ("szTip", wintypes.WCHAR * 128),
                            ("dwState", wintypes.DWORD), ("dwStateMask", wintypes.DWORD),
                            ("szInfo", wintypes.WCHAR * 256), ("uVersion", wintypes.UINT),
                            ("szInfoTitle", wintypes.WCHAR * 64), ("dwInfoFlags", wintypes.DWORD),
                            ("guidItem", GUID), ("hBalloonIcon", wintypes.HICON)]

            WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)

            class WNDCLASS(ctypes.Structure):
                _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", WNDPROC),
                            ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                            ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                            ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HBRUSH),
                            ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR)]

            u.DefWindowProcW.restype = LRESULT
            u.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
            u.CreateWindowExW.restype = wintypes.HWND
            u.TrackPopupMenu.restype = ctypes.c_int

            def _menu():
                u.SetForegroundWindow(self.hwnd)
                m = u.CreatePopupMenu()
                u.AppendMenuW(m, MF_STRING | (MF_CHECKED if _notif_on() else 0), 1, "Notification sound")
                u.AppendMenuW(m, MF_STRING, 2, "Show VSL Dashboard")
                u.AppendMenuW(m, MF_SEPARATOR, 0, None)
                u.AppendMenuW(m, MF_STRING, 3, "Exit")
                pt = wintypes.POINT(); u.GetCursorPos(ctypes.byref(pt))
                cmd = u.TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, self.hwnd, None)
                u.DestroyMenu(m)
                u.PostMessageW(self.hwnd, 0, 0, 0)   # MSDN-recommended after TrackPopupMenu
                if cmd == 1:
                    _set_notif(not _notif_on())
                elif cmd == 2:
                    try: self.on_show()
                    except Exception: pass
                elif cmd == 3:
                    try: self.on_exit()
                    except Exception: pass

            def _wndproc(hwnd, msg, wparam, lparam):
                if msg == WM_TRAY:
                    low = lparam & 0xFFFF
                    if low == WM_RBUTTONUP:
                        _menu()
                    elif low == WM_LBUTTONDBLCLK:
                        try: self.on_show()
                        except Exception: pass
                    return 0
                if msg == WM_DESTROY:
                    u.PostQuitMessage(0); return 0
                return u.DefWindowProcW(hwnd, msg, wparam, lparam)

            self._proc_ref = WNDPROC(_wndproc)
            hinst = k.GetModuleHandleW(None)
            wc = WNDCLASS()
            wc.lpfnWndProc = self._proc_ref
            wc.hInstance = hinst
            wc.lpszClassName = "VSLDashboardTray"
            u.RegisterClassW(ctypes.byref(wc))   # if already registered we still create below
            self.hwnd = u.CreateWindowExW(0, "VSLDashboardTray", "VSLTray", 0, 0, 0, 0, 0, None, None, hinst, None)
            if not self.hwnd:
                return
            # Dark context menu (matches the app's dark theme) instead of the default white Windows menu.
            # Uses uxtheme's dark-mode entry points (Win10 1903+/Win11). Undocumented ordinals → guarded:
            # if unavailable the menu just renders in the default light theme, no functional impact.
            try:
                ux = ctypes.WinDLL("uxtheme.dll")
                try: ux[135](2)          # SetPreferredAppMode(AppMode_ForceDark)
                except Exception: pass
                try: ux[133](self.hwnd, 1)   # AllowDarkModeForWindow(hwnd, TRUE)
                except Exception: pass
                try: ux[136]()           # FlushMenuThemes()
                except Exception: pass
            except Exception:
                pass
            hicon = 0
            try:
                hicon = u.LoadImageW(None, self.icon_path, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            except Exception:
                hicon = 0
            nid = NID()
            nid.cbSize = ctypes.sizeof(NID); nid.hWnd = self.hwnd; nid.uID = 1
            nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
            nid.uCallbackMessage = WM_TRAY
            nid.hIcon = hicon or 0
            nid.szTip = "VSL Dashboard"
            if not shell.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid)):
                return
            self._nid = nid; self._added = True
            msg = wintypes.MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                u.TranslateMessage(ctypes.byref(msg))
                u.DispatchMessageW(ctypes.byref(msg))
        except Exception:
            self._added = False

    def remove(self):
        try:
            if self._added and self._shell and self._nid is not None:
                self._shell.Shell_NotifyIconW(2, self._ctypes.byref(self._nid))   # NIM_DELETE
        except Exception:
            pass
        try:
            if self.hwnd and self._u:
                self._u.DestroyWindow(self.hwnd)
        except Exception:
            pass


def _tray_show():
    try:
        _window.restore()      # if it was minimized
    except Exception:
        pass
    try:
        _window.show()         # if it was hidden to the tray
    except Exception:
        pass
    try:
        import ctypes
        hwnd = _hwnd()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 9)          # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(hwnd)    # bring it to the front / focus
    except Exception:
        pass
    try:
        _fill_work_area(); _enable_taskbar_minimize()
    except Exception:
        pass


def _tray_exit():
    _quitting["v"] = True
    try:
        if _tray:
            _tray.remove()
    except Exception:
        pass
    try:
        _window.destroy()
    except Exception:
        pass
    os._exit(0)


# ---- single instance: a second launch (desktop icon) just SHOWS the running one, no new window -----
_SINGLETON_MUTEX = "VSLDashboard_SingleInstance_Mutex"
_SINGLETON_EVENT = "VSLDashboard_ShowWindow_Event"
_mutex_handle = None
_show_event = None
_ERROR_ALREADY_EXISTS = 183


def _singleton_check():
    """Return True if we're the instance that should run. If another instance is already alive, signal it
    to show its window and return False (caller exits). After an auto-update relaunch we WAIT for the old
    process to release the mutex instead of bailing (else the app would never reopen)."""
    global _mutex_handle, _show_event
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = wintypes.HANDLE
        k.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
        k.CreateEventW.restype = wintypes.HANDLE
        k.CreateEventW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
        k.OpenEventW.restype = wintypes.HANDLE
        k.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
        k.SetEvent.argtypes = [wintypes.HANDLE]
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        relaunch = os.environ.pop("VSL_RELAUNCH", None)
        tries = 50 if relaunch else 1     # relaunch: give the exiting old process ~5s to free the mutex
        for _i in range(tries):
            h = k.CreateMutexW(None, False, _SINGLETON_MUTEX)
            if k.GetLastError() != _ERROR_ALREADY_EXISTS:
                _mutex_handle = h         # we own it → we're the live instance
                _show_event = k.CreateEventW(None, False, False, _SINGLETON_EVENT)
                return True
            if h:
                k.CloseHandle(h)
            if not relaunch:              # genuine second launch → tell the running instance to show, then exit
                he = k.OpenEventW(0x0002, False, _SINGLETON_EVENT)   # EVENT_MODIFY_STATE
                if he:
                    k.SetEvent(he); k.CloseHandle(he)
                return False
            time.sleep(0.1)
        _show_event = k.CreateEventW(None, False, False, _SINGLETON_EVENT)   # relaunch fallback: proceed anyway
        return True
    except Exception:
        return True                        # never block launch over the singleton check


def _show_listener():
    """First instance: wait for a second launch to signal the show-event, then surface our window."""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        k.WaitForSingleObject.restype = wintypes.DWORD
        k.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    except Exception:
        return
    while _show_event:
        try:
            if k.WaitForSingleObject(_show_event, 0xFFFFFFFF) == 0:   # WAIT_OBJECT_0
                _tray_show()
            else:
                time.sleep(1)
        except Exception:
            time.sleep(1)


class DesktopApi:
    """JS bridge: file downloads + custom (frameless) window controls."""

    def __init__(self):
        self.maximized = True   # the window opens maximized

    # ---- custom title-bar window controls ----
    def win_minimize(self):
        try:
            _window.minimize()
        except Exception:
            pass
        return True

    def win_maximize(self):
        try:
            if self.maximized:
                _restore_win(animate=True)
            else:
                _fill_work_area(animate=True)
            self.maximized = not self.maximized
        except Exception:
            pass
        return self.maximized

    def win_close(self):
        # With the tray active, the close button HIDES to the system tray (near the clock) instead of
        # quitting — the app keeps running (still hears generation chimes). Only tray → Exit truly quits.
        if _tray is not None and not _quitting["v"]:
            try:
                _window.hide()
                return True
            except Exception:
                pass
        try:
            _window.destroy()
        except Exception:
            pass
        return True

    def win_bounds(self):
        r = _get_rect()   # physical px
        return {"x": r[0], "y": r[1], "w": r[2], "h": r[3]} if r else None

    def win_set_bounds(self, x, y, w, h):
        _set_bounds(x, y, w, h)   # edge-drag resize (physical px)
        self.maximized = False
        return True

    # ---- folder picker (for the export/import sync folder) ----
    def pick_folder(self):
        try:
            import webview
            res = _window.create_file_dialog(webview.FOLDER_DIALOG)
            if not res:
                return {"ok": False, "cancelled": True}
            path = res if isinstance(res, str) else res[0]
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- downloads ----
    # The browser's <a download> / window.location downloads don't trigger a save inside WebView2,
    # so the frontend calls save_download(url, ...) which streams that URL from the local server
    # (any file, including generated .zip exports) and writes it to a native Save-As location.
    def save_download(self, url, cookie, fallback):
        try:
            import re as _re
            import requests
            import webview
            from urllib.parse import unquote
            full = url if str(url).startswith("http") else f"http://{HOST}:{PORT}{url}"
            headers = {"Cookie": cookie} if cookie else {}
            with requests.get(full, headers=headers, stream=True, timeout=1800) as resp:
                resp.raise_for_status()
                name = fallback or "download"
                cd = resp.headers.get("Content-Disposition", "")
                m = _re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)\"?", cd)
                if m:
                    name = unquote(m.group(1))
                info = resp.headers.get("X-Export-Info")   # the "all zip" export summary, if present
                dest = _window.create_file_dialog(webview.SAVE_DIALOG, save_filename=name)
                if not dest:
                    return {"ok": False, "cancelled": True}
                dest = dest if isinstance(dest, str) else dest[0]
                with open(dest, "wb") as f:
                    for chunk in resp.iter_content(1 << 16):
                        if chunk:
                            f.write(chunk)
            return {"ok": True, "path": str(dest), "info": info}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- reveal a saved file in Explorer (folder opens with the file selected) ----
    def reveal(self, path):
        try:
            import subprocess as _sp
            _sp.Popen(["explorer", "/select,", str(path)])   # explorer returns 1 even on success
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def main():
    global _window
    # Single instance: if the app is already running (e.g. minimized to the tray), tell it to show its
    # window and exit — clicking the desktop icon reopens the EXISTING one instead of a second copy.
    if not _singleton_check():
        os._exit(0)
    threading.Thread(target=_serve, daemon=True).start()
    base = f"http://{HOST}:{PORT}/"

    import webview
    # Frameless — open the window ALREADY at the full work-area size so it never flashes small before
    # filling the screen. create_window wants LOGICAL (DIP) px; earlier we passed PHYSICAL px, which on a
    # scaled display (e.g. 150%) came out the wrong size (small, offset) until _fill_work_area corrected it.
    try:
        _ix, _iy, _iw, _ih = _logical_work_rect()
    except Exception:
        _ix, _iy, _iw, _ih = 0, 0, 1280, 800
    _cw_kw = dict(
        html=SPLASH_HTML,
        frameless=True,
        easy_drag=False,                 # only the title bar (.pywebview-drag-region) drags the window
        background_color="#0a130d",      # dark from the very first frame → no white flash before content
        width=_iw, height=_ih,           # full-screen (logical px) from the first frame → no small-window flash
        x=_ix, y=_iy,                    # open AT the work-area origin, full size (no centered/offset flash)
        min_size=(1000, 650),
        js_api=DesktopApi(),
    )
    try:
        _window = webview.create_window("VSL Dashboard", **_cw_kw)
    except TypeError:
        _cw_kw.pop("x", None); _cw_kw.pop("y", None)   # older pywebview without x/y → open centered as before
        _window = webview.create_window("VSL Dashboard", **_cw_kw)

    # Re-snap to the full work area on the window's OWN lifecycle events (not just timed guesses). After an
    # update-relaunch the window sometimes lands half-size/offset until the display/DPI settles; firing on
    # shown + every page load + resize makes it self-correct instead of needing a manual click. (#7)
    def _snap(*_a):
        try: _fill_work_area()
        except Exception: pass
    for _ev in ("shown", "loaded"):
        try:
            getattr(_window.events, _ev).__iadd__(_snap)
        except Exception:
            pass

    # Alt+F4 / taskbar "Close window" while the tray is active → hide to tray instead of quitting.
    # Returning False cancels the close (pywebview). Only tray → Exit sets _quitting and lets it through.
    def _on_closing():
        if _quitting["v"] or _tray is None:
            return True
        try: _window.hide()
        except Exception: pass
        return False
    try:
        _window.events.closing += _on_closing
    except Exception:
        pass

    _loaded = {"v": False}
    def _watchdog():
        # Fail-safe: if the app page never loads (WebView2 / server stall left a blank green splash
        # that couldn't be closed), force the app in after a while so the user is never stuck.
        time.sleep(35)
        if not _loaded["v"]:
            try:
                _window.load_url(base); _loaded["v"] = True
                _fill_work_area(); _enable_taskbar_minimize()
            except Exception:
                pass
    def _boot():
        threading.Thread(target=_watchdog, daemon=True).start()
        for _ in range(60):              # wait for the (hidden) window handle to exist
            if _hwnd():
                break
            time.sleep(0.05)
        _fill_work_area()                # snap to the exact work-area position/size (frameless "maximized")
        _enable_taskbar_minimize()       # taskbar-icon click toggles minimize/restore (smooth)
        # Update BEFORE opening the app — the user never sees the old version if a newer one exists.
        if _PACKAGED:
            remote = _pending_version()
            if remote:
                try:
                    _window.run_js("var p=document.querySelector('p'); if(p){p.textContent='Downloading update…';}")
                except Exception:
                    pass
                if _download_update(remote):
                    time.sleep(0.5)      # let the splash text show
                    _relaunch()          # exit → launcher applies the update → reopens on the new version
                    return
        _wait_until_up(base, timeout=30)
        _window.load_url(base)           # splash → app
        _loaded["v"] = True              # tell the watchdog the app is up
        # Size/position the window FIRST (after an update it can land small) BEFORE anything overlays it,
        # so the "what's new" notes never appear over a half-size window that then jumps to full-screen.
        _fill_work_area(); _enable_taskbar_minimize()   # immediately (don't wait for the first tick)
        for _d in (0.05, 0.1, 0.15, 0.25, 0.35, 0.6, 1.0, 1.5):
            time.sleep(_d)
            _fill_work_area()
            _enable_taskbar_minimize()
        if _PACKAGED:                    # first launch after an update → show "what's new" notes (window is full now)
            js = _update_notes_js()
            if js:
                try:
                    _window.run_js(js)
                except Exception:
                    pass
        # System tray (near the clock). Start it and only COMMIT `_tray` once the icon truly appears, so
        # the close button never hides to a tray that isn't there. Any failure → app quits on close as before.
        global _tray
        try:
            _t = _Tray(_HERE / "vsllogo.ico", on_show=_tray_show, on_exit=_tray_exit)
            _t.start()
            for _ in range(30):
                if _t._added:
                    _tray = _t
                    break
                time.sleep(0.1)
        except Exception:
            _tray = None
        # listen for a second launch (desktop icon while we're in the tray) → show this window
        if _show_event:
            threading.Thread(target=_show_listener, daemon=True).start()

    # private_mode=False + a fixed storage_path so cookies (login session) + localStorage (zoom,
    # last project, …) persist across restarts.
    try:
        os.makedirs(STORAGE_PATH, exist_ok=True)
    except Exception:
        pass
    _kw = {"private_mode": False, "storage_path": STORAGE_PATH}
    _icon = _HERE / "vsllogo.ico"          # window + taskbar icon (replaces the Python logo)
    if _icon.exists():
        _kw["icon"] = str(_icon)
    webview.start(_boot, **_kw)


if __name__ == "__main__":
    main()
