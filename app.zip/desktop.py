"""VSL Dashboard — desktop launcher.

Starts the local Flask server in a background thread and opens the dashboard in its own
native window (pywebview / Edge WebView2) — no browser, feels like a real program. Everything
runs on this machine (127.0.0.1); only image/video generation reaches out to the internet.

Run with:  python desktop.py     (packaged: the .exe runs this)
"""
import os
import socket
import threading
import time
import urllib.request
from pathlib import Path

# Make the process DPI-aware BEFORE any window exists — otherwise Windows virtualizes coordinates
# on scaled displays (125/150%), so our resize/move land short (thin gap at the edges, title bar
# shifted). Per-monitor aware keeps SPI_GETWORKAREA and resize/move in the same pixel space.
try:
    import ctypes as _ctypes
    try:
        _ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_AWARE
    except Exception:
        _ctypes.windll.user32.SetProcessDPIAware()
except Exception:
    pass

HOST = "127.0.0.1"

# ---- packaged-layout wiring (no-op in a plain dev checkout) -----------------
# Packaged tree:  VSLDashboard/{VSLDashboard.exe, runtime/, ffmpeg/, app/, data/}
# desktop.py lives in app/. When the sibling runtime/ or ffmpeg/ exists we're packaged, so point
# ffmpeg + all user data at the bundled folders. In dev these siblings don't exist → unchanged.
_HERE = Path(__file__).resolve().parent          # app/  (dev: the dashboard folder)
_ROOT = _HERE.parent                             # VSLDashboard/  (dev: video-agent-template)
_PACKAGED = (_ROOT / "runtime").exists() or (_ROOT / "ffmpeg").exists()
if _PACKAGED:
    _ff = _ROOT / "ffmpeg"
    if _ff.exists():
        os.environ["PATH"] = str(_ff) + os.pathsep + os.environ.get("PATH", "")
    _data = _ROOT / "data"
    _data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VSL_DATA_DIR", str(_data))
    # bundled whisper models → offline SRT. whisper reads $XDG_CACHE_HOME/whisper/*.pt (respected
    # by its load_model); the SRT subprocess inherits this env, so no code change is needed there.
    _cache = _ROOT / "cache"
    if (_cache / "whisper").exists():
        os.environ.setdefault("XDG_CACHE_HOME", str(_cache))
    # seed the user's voices list on first run (bundled default lives beside the app)
    _seed = _HERE / "voices.json"
    _dst = _data / "voices.json"
    if _seed.exists() and not _dst.exists():
        try:
            _dst.write_bytes(_seed.read_bytes())
        except Exception:
            pass

# WebView2 storage (cookies + localStorage) lives here so the login session, zoom level, last
# project etc. PERSIST across restarts (needs private_mode=False in webview.start).
STORAGE_PATH = str(((_ROOT / "data") if _PACKAGED else _HERE) / "webview-data")

# Splash shown instantly while the local server boots (a second or two), then we swap to the app.
SPLASH_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
html,body{height:100%;margin:0;overflow:hidden;background:radial-gradient(900px 520px at 50% 42%,#0d1a12,#060c09 70%);
 display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;color:#e6ede8}
.w{text-align:center;animation:f .5s ease}
.d{display:flex;gap:15px;justify-content:center;margin-bottom:24px}
.d span{width:17px;height:17px;border-radius:50%;background:linear-gradient(180deg,#46ac5a,#237e43);
 box-shadow:0 0 18px rgba(82,189,102,.55);animation:b 1s ease-in-out infinite}
.d span:nth-child(2){animation-delay:.16s}.d span:nth-child(3){animation-delay:.32s}
h1{margin:0;font-size:24px;font-weight:700;letter-spacing:.6px}
p{margin:10px 0 0;font-size:13px;color:#839a8c}
@keyframes b{0%,75%,100%{transform:translateY(0) scale(.85);opacity:.45}38%{transform:translateY(-20px) scale(1);opacity:1}}
@keyframes f{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:none}}
</style></head><body><div class="w"><div class="d"><span></span><span></span><span></span></div>
<h1>VSL Dashboard</h1><p>Starting up…</p></div></body></html>"""


def _free_port():
    """Grab a free loopback port so we never clash with anything already listening."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, 0))
        return s.getsockname()[1]
    finally:
        s.close()


def _port():
    """Prefer a STABLE fixed port so the window's origin (127.0.0.1:PORT) — and therefore its
    localStorage (zoom, last project, saved style presets…) — persists across restarts. Only fall
    back to a random free port if the fixed one is already taken."""
    env = os.environ.get("VSL_PORT")
    if env:
        return int(env)
    fixed = 8770
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, fixed))
        return fixed
    except OSError:
        return _free_port()
    finally:
        s.close()


PORT = _port()
os.environ["VSL_HOST"] = HOST
os.environ["VSL_PORT"] = str(PORT)

# Desktop app: require a fresh sign-in every launch (a random session key per run invalidates any
# leftover session cookie). The login form still remembers the username/password in localStorage,
# so the user just clicks Sign in.
os.environ.setdefault("VSL_FRESH_SESSION", "1")

import app  # noqa: E402  (env must be set before app decides its host/port)


def _serve():
    # threaded so long polls / renders don't block the UI; no reloader inside a frozen app.
    app.app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)


def _wait_until_up(url, timeout=30.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.2)
    return False


_window = None


def _work_area():
    """Monitor work area (screen minus the taskbar) in PHYSICAL pixels, via SPI_GETWORKAREA."""
    import ctypes
    from ctypes import wintypes
    r = wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def _hwnd():
    try:
        import ctypes
        return ctypes.windll.user32.FindWindowW(None, "VSL Dashboard")
    except Exception:
        return 0


def _set_bounds(x, y, w, h):
    """Position the window in PHYSICAL pixels straight through the Win32 HWND — pywebview's own
    resize/move mis-scale on high-DPI displays (window too big/small, title bar shifted); SetWindowPos
    uses the same pixel space as SPI_GETWORKAREA, so this lands exactly."""
    try:
        import ctypes
        hwnd = _hwnd()
        if hwnd:
            ctypes.windll.user32.SetWindowPos(hwnd, 0, int(x), int(y), int(w), int(h), 0x0004)  # SWP_NOZORDER
            return True
    except Exception:
        pass
    return False


def _get_rect():
    try:
        import ctypes
        from ctypes import wintypes
        hwnd = _hwnd()
        r = wintypes.RECT()
        if hwnd and ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return r.left, r.top, r.right - r.left, r.bottom - r.top
    except Exception:
        pass
    return None


def _animate_to(x, y, w, h, dur=0.19, steps=13):
    """Glide the window from its current bounds to the target (easeOut) so maximize/restore feels
    smooth instead of snapping."""
    cur = _get_rect()
    if not cur:
        _set_bounds(x, y, w, h)
        return
    cx, cy, cw, ch = cur
    for i in range(1, steps + 1):
        e = 1 - (1 - i / steps) ** 3   # easeOutCubic
        _set_bounds(cx + (x - cx) * e, cy + (y - cy) * e, cw + (w - cw) * e, ch + (h - ch) * e)
        time.sleep(dur / steps)
    _set_bounds(x, y, w, h)


def _remove_window_border():
    """Strip the thin residual frame Windows draws around the frameless window (WS_BORDER/DLGFRAME/
    THICKFRAME). Our own edge handles do the resizing, so we don't need the OS sizing border."""
    try:
        import ctypes
        hwnd = _hwnd()
        if not hwnd:
            return
        GWL_STYLE = -16
        WS_BORDER, WS_DLGFRAME, WS_THICKFRAME = 0x00800000, 0x00400000, 0x00040000
        style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE)
        style &= ~(WS_BORDER | WS_DLGFRAME | WS_THICKFRAME)
        ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, style)
        # SWP_NOSIZE|NOMOVE|NOZORDER|FRAMECHANGED — reapply the frame change without touching geometry
        ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0004 | 0x0020)
    except Exception:
        pass


def _fill_work_area(animate=False):
    x, y, w, h = _work_area()
    if animate:
        _animate_to(x, y, w, h)
    elif not _set_bounds(x, y, w, h):
        try:
            _window.resize(w, h); _window.move(x, y)
        except Exception:
            pass


def _restore_win(animate=True):
    x, y, w, h = _work_area()
    ww, wh = int(w * 0.72), int(h * 0.82)
    tx, ty = x + (w - ww) // 2, y + (h - wh) // 2
    if animate:
        _animate_to(tx, ty, ww, wh)
    elif not _set_bounds(tx, ty, ww, wh):
        try:
            _window.resize(ww, wh); _window.move(tx, ty)
        except Exception:
            pass


# ---- auto-update: pull newer app code from GitHub, staged for the launcher to apply next start ----
def _is_newer(remote, local):
    def parse(v):
        try:
            return [int(x) for x in str(v).strip().lstrip("vV").split(".")]
        except Exception:
            return [0]
    return parse(remote) > parse(local)


def _repo_base():
    try:
        import json
        cfg = json.loads((_HERE / "update.json").read_text(encoding="utf-8"))
        repo = (cfg.get("repo") or "").strip()
        if cfg.get("enabled") and repo:
            return f"https://raw.githubusercontent.com/{repo}/main"
    except Exception:
        pass
    return None


def _pending_version():
    """Return the newer remote version string if an update is available, else None (fast + safe)."""
    base = _repo_base()
    if not base:
        return None
    try:
        vf = _HERE / "version.txt"
        local = vf.read_text(encoding="utf-8").strip() if vf.exists() else "0"
        remote = urllib.request.urlopen(base + "/version.txt", timeout=6).read().decode("utf-8").strip()
        return remote if (remote and _is_newer(remote, local)) else None
    except Exception:
        return None


def _download_update(remote):
    """Download the newer app.zip into _update/ so the launcher applies it on the next start."""
    base = _repo_base()
    if not base:
        return False
    try:
        data = urllib.request.urlopen(base + "/app.zip", timeout=300).read()
        upd = _ROOT / "_update"
        upd.mkdir(parents=True, exist_ok=True)
        (upd / "app.zip").write_bytes(data)
        (upd / "version.txt").write_text(remote, encoding="utf-8")
        return True
    except Exception:
        return False


def _relaunch():
    """Restart via the launcher so the just-downloaded update is applied before the app opens."""
    try:
        exe = _ROOT / "VSLDashboard.exe"
        if exe.exists():
            import subprocess
            subprocess.Popen([str(exe)], cwd=str(_ROOT))
    except Exception:
        pass
    os._exit(0)


class DesktopApi:
    """JS bridge: file downloads + custom (frameless) window controls."""

    def __init__(self):
        self.maximized = True   # the window opens maximized

    # ---- custom title-bar window controls ----
    def win_minimize(self):
        try:
            _window.minimize()
        except Exception:
            pass
        return True

    def win_maximize(self):
        try:
            if self.maximized:
                _restore_win(animate=True)
            else:
                _fill_work_area(animate=True)
            self.maximized = not self.maximized
        except Exception:
            pass
        return self.maximized

    def win_close(self):
        try:
            _window.destroy()
        except Exception:
            pass
        return True

    def win_bounds(self):
        r = _get_rect()   # physical px
        return {"x": r[0], "y": r[1], "w": r[2], "h": r[3]} if r else None

    def win_set_bounds(self, x, y, w, h):
        _set_bounds(x, y, w, h)   # edge-drag resize (physical px)
        self.maximized = False
        return True

    # ---- downloads ----
    # The browser's <a download> / window.location downloads don't trigger a save inside WebView2,
    # so the frontend calls save_download(url, ...) which streams that URL from the local server
    # (any file, including generated .zip exports) and writes it to a native Save-As location.
    def save_download(self, url, cookie, fallback):
        try:
            import re as _re
            import requests
            import webview
            from urllib.parse import unquote
            full = url if str(url).startswith("http") else f"http://{HOST}:{PORT}{url}"
            headers = {"Cookie": cookie} if cookie else {}
            with requests.get(full, headers=headers, stream=True, timeout=1800) as resp:
                resp.raise_for_status()
                name = fallback or "download"
                cd = resp.headers.get("Content-Disposition", "")
                m = _re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)\"?", cd)
                if m:
                    name = unquote(m.group(1))
                info = resp.headers.get("X-Export-Info")   # the "all zip" export summary, if present
                dest = _window.create_file_dialog(webview.SAVE_DIALOG, save_filename=name)
                if not dest:
                    return {"ok": False, "cancelled": True}
                dest = dest if isinstance(dest, str) else dest[0]
                with open(dest, "wb") as f:
                    for chunk in resp.iter_content(1 << 16):
                        if chunk:
                            f.write(chunk)
            return {"ok": True, "path": str(dest), "info": info}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def main():
    global _window
    threading.Thread(target=_serve, daemon=True).start()
    base = f"http://{HOST}:{PORT}/"

    import webview
    # Frameless (no gray OS title bar) — the app draws its own title bar + window buttons. Shows the
    # splash instantly; swaps to the real app once the local server is up, then fills the screen.
    _window = webview.create_window(
        "VSL Dashboard",
        html=SPLASH_HTML,
        frameless=True,
        background_color="#0a130d",      # dark from the very first frame → no white flash before content
        width=1280, height=800,          # size used when the user un-maximizes
        min_size=(1000, 650),
        js_api=DesktopApi(),
    )

    def _boot():
        for _ in range(60):              # wait for the window handle to exist, then fill the screen
            if _hwnd():
                break
            time.sleep(0.05)
        _remove_window_border()          # kill the thin gray OS frame
        _fill_work_area()                # open filling the work area (frameless "maximized")
        # Update BEFORE opening the app — the user never sees the old version if a newer one exists.
        if _PACKAGED:
            remote = _pending_version()
            if remote:
                try:
                    _window.run_js("var p=document.querySelector('p'); if(p){p.textContent='Downloading update…';}")
                except Exception:
                    pass
                if _download_update(remote):
                    time.sleep(0.5)      # let the splash text show
                    _relaunch()          # exit → launcher applies the update → reopens on the new version
                    return
        _wait_until_up(base, timeout=60)
        _window.load_url(base)           # splash → app

    # private_mode=False + a fixed storage_path so cookies (login session) + localStorage (zoom,
    # last project, …) persist across restarts.
    try:
        os.makedirs(STORAGE_PATH, exist_ok=True)
    except Exception:
        pass
    _kw = {"private_mode": False, "storage_path": STORAGE_PATH}
    _icon = _HERE / "vsllogo.ico"          # window + taskbar icon (replaces the Python logo)
    if _icon.exists():
        _kw["icon"] = str(_icon)
    webview.start(_boot, **_kw)


if __name__ == "__main__":
    main()
