"""AI Dashboard — desktop launcher.

Starts the local Flask server in a background thread and opens the dashboard in its own
native window (pywebview / Edge WebView2) — no browser, feels like a real program. Everything
runs on this machine (127.0.0.1); only image/video generation reaches out to the internet.

Run with:  python desktop.py     (packaged: the .exe runs this)
"""
import os
import sys
import socket
import threading
import time
import urllib.request
from pathlib import Path

# Make the process DPI-aware BEFORE any window exists — otherwise Windows virtualizes coordinates
# on scaled displays (125/150%), so our resize/move land short (thin gap at the edges, title bar
# shifted). Per-monitor aware keeps SPI_GETWORKAREA and resize/move in the same pixel space.
try:
    import ctypes as _ctypes
    try:
        _ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_AWARE
    except Exception:
        _ctypes.windll.user32.SetProcessDPIAware()
except Exception:
    pass

HOST = "127.0.0.1"

# ---- packaged-layout wiring (no-op in a plain dev checkout) -----------------
# Packaged tree:  VSLDashboard/{VSLDashboard.exe, runtime/, ffmpeg/, app/, data/}
# desktop.py lives in app/. When the sibling runtime/ or ffmpeg/ exists we're packaged, so point
# ffmpeg + all user data at the bundled folders. In dev these siblings don't exist → unchanged.
_HERE = Path(__file__).resolve().parent          # app/  (dev: the dashboard folder)
_ROOT = _HERE.parent                             # VSLDashboard/  (dev: video-agent-template)
_PACKAGED = (_ROOT / "runtime").exists() or (_ROOT / "ffmpeg").exists()
if _PACKAGED:
    _ff = _ROOT / "ffmpeg"
    if _ff.exists():
        os.environ["PATH"] = str(_ff) + os.pathsep + os.environ.get("PATH", "")
    _data = _ROOT / "data"
    _data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VSL_DATA_DIR", str(_data))
    # bundled whisper models → offline SRT. whisper reads $XDG_CACHE_HOME/whisper/*.pt (respected
    # by its load_model); the SRT subprocess inherits this env, so no code change is needed there.
    _cache = _ROOT / "cache"
    if (_cache / "whisper").exists():
        os.environ.setdefault("XDG_CACHE_HOME", str(_cache))
    # seed the user's voices list on first run (bundled default lives beside the app)
    _seed = _HERE / "voices.json"
    _dst = _data / "voices.json"
    if _seed.exists() and not _dst.exists():
        try:
            _dst.write_bytes(_seed.read_bytes())
        except Exception:
            pass

# WebView2 storage (cookies + localStorage) lives here so the login session, zoom level, last
# project etc. PERSIST across restarts (needs private_mode=False in webview.start).
STORAGE_PATH = str(((_ROOT / "data") if _PACKAGED else _HERE) / "webview-data")

# Splash shown instantly while the local server boots (a second or two), then we swap to the app.
SPLASH_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
html,body{height:100%;margin:0;overflow:hidden;background:radial-gradient(900px 520px at 50% 42%,#14171a,#08090a 70%);
 display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;color:#e6eaec}
.w{text-align:center;animation:f .32s ease both}
.x{position:fixed;top:12px;right:16px;width:36px;height:36px;border:0;background:rgba(255,255,255,.05);color:#838c91;border-radius:9px;font-size:22px;line-height:1;cursor:pointer;z-index:20;font-family:inherit}
.x:hover{background:rgba(224,67,67,.22);color:#fff}
.d{display:flex;gap:15px;justify-content:center;margin-bottom:24px}
.d span{width:17px;height:17px;border-radius:50%;background:linear-gradient(180deg,#5f6a70,#363d42);
 box-shadow:0 0 18px rgba(150,166,176,.38);animation:b 1s ease-in-out infinite}
.d span:nth-child(2){animation-delay:.16s}.d span:nth-child(3){animation-delay:.32s}
h1{margin:0;font-size:24px;font-weight:700;letter-spacing:.6px}
p{margin:10px 0 0;font-size:13px;color:#838c91}
@keyframes b{0%,75%,100%{transform:translateY(0) scale(.85);opacity:.45}38%{transform:translateY(-20px) scale(1);opacity:1}}
@keyframes f{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:none}}
</style></head><body><button class="x" onclick="try{window.pywebview.api.win_close()}catch(e){}" title="Close">&times;</button>
<div class="w"><div class="d"><span></span><span></span><span></span></div>
<h1>AI Dashboard</h1><p>Checking for updates…</p></div></body></html>"""


def _free_port():
    """Grab a free loopback port so we never clash with anything already listening."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, 0))
        return s.getsockname()[1]
    finally:
        s.close()


def _port():
    """Prefer a STABLE fixed port so the window's origin (127.0.0.1:PORT) — and therefore its
    localStorage (zoom, last project, saved style presets…) — persists across restarts. Only fall
    back to a random free port if the fixed one is already taken."""
    env = os.environ.get("VSL_PORT")
    if env:
        return int(env)
    fixed = 8770
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((HOST, fixed))
        return fixed
    except OSError:
        return _free_port()
    finally:
        s.close()


PORT = _port()
os.environ["VSL_HOST"] = HOST
os.environ["VSL_PORT"] = str(PORT)

# Desktop app: require a fresh sign-in every launch (a random session key per run invalidates any
# leftover session cookie). The login form still remembers the username/password in localStorage,
# so the user just clicks Sign in.
os.environ.setdefault("VSL_FRESH_SESSION", "1")

# Hold the import/update guard until main() has established the live-instance marker.
# A click during installation waits here, before loading app.py from mixed code files.
_startup_code_guard = None
if _PACKAGED and __name__ == "__main__":
    from safe_update import code_guard
    _startup_code_guard = code_guard(_ROOT / "_update")
    _startup_code_guard.__enter__()

def _release_startup_code_guard():
    global _startup_code_guard
    if _startup_code_guard is not None:
        _startup_code_guard.__exit__(None,None,None)
        _startup_code_guard = None

# Recover an interrupted code installation BEFORE importing app.py from that installation.
if _PACKAGED:
    from safe_update import recover as _recover_update
    try:
        _recover_update(_HERE, _ROOT / "_update")
    except Exception as _recovery_error:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                "The interrupted update could not be restored. Your project data and code backup are preserved.\n"
                + str(_recovery_error), "AI Dashboard — update recovery", 0x10)
        finally:
            raise

def _apply_prepared_local_update():
    if not (_PACKAGED and __name__ == "__main__"):
        return
    upd = _ROOT / "_update"
    if not (upd / "app.zip").is_file() or not (upd / "version.txt").is_file():
        return
    try:
        incoming = int((upd / "version.txt").read_text(encoding="utf-8").strip())
        current = int((_HERE / "version.txt").read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return
    if incoming <= current:
        return
    # Opening a second window must never install over the existing running session.
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.windll.kernel32
    kernel.OpenMutexW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.OpenMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenMutexW(0x00100000, False, "VSLDashboard_SingleInstance_Mutex")
    if handle:
        kernel.CloseHandle(handle)
        return
    if kernel.GetLastError() != 2:   # access denied / unknown is not evidence that the app is closed
        return
    from safe_update import install
    install(_HERE, upd)             # caller already holds the startup code guard; recoverable transaction
    _release_startup_code_guard()
    os.execv(sys.executable, [sys.executable, str(_HERE / "desktop.py")])


_apply_prepared_local_update()

import app  # noqa: E402  (env must be set before app decides its host/port)


def _serve():
    # threaded so long polls / renders don't block the UI; no reloader inside a frozen app.
    app.app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)


def _wait_until_up(url, timeout=30.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.2)
    return False


_window = None
_geometry_lock = threading.RLock()
_window_user_sized = False
_normal_bounds = None


def _user32():
    """Use pointer-sized HWND signatures on 64-bit Windows."""
    import ctypes
    from ctypes import wintypes as w
    u = ctypes.windll.user32
    signatures = {
        'FindWindowW': ([w.LPCWSTR, w.LPCWSTR], w.HWND),
        'GetWindowThreadProcessId': ([w.HWND, ctypes.POINTER(w.DWORD)], w.DWORD),
        'GetWindowRect': ([w.HWND, ctypes.POINTER(w.RECT)], w.BOOL),
        'SetWindowPos': ([w.HWND, w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.UINT], w.BOOL),
        'MonitorFromWindow': ([w.HWND, w.DWORD], w.HANDLE),
        'GetMonitorInfoW': ([w.HANDLE, ctypes.c_void_p], w.BOOL),
        'IsZoomed': ([w.HWND], w.BOOL),
        'ShowWindow': ([w.HWND, ctypes.c_int], w.BOOL),
    }
    for name, (args, result) in signatures.items():
        fn = getattr(u, name); fn.argtypes = args; fn.restype = result
    return u


def _work_area():
    """Current monitor's usable area in physical pixels; never cover its taskbar."""
    import ctypes
    from ctypes import wintypes
    class MonitorInfo(ctypes.Structure):
        _fields_ = [('cbSize', wintypes.DWORD), ('rcMonitor', wintypes.RECT),
                    ('rcWork', wintypes.RECT), ('dwFlags', wintypes.DWORD)]
    u = _user32()
    hwnd = _hwnd()
    if hwnd:
        info = MonitorInfo(); info.cbSize = ctypes.sizeof(info)
        monitor = u.MonitorFromWindow(hwnd, 2)  # nearest monitor
        if monitor and u.GetMonitorInfoW(monitor, ctypes.byref(info)):
            r = info.rcWork
            return r.left, r.top, r.right - r.left, r.bottom - r.top
    r = wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def _logical_work_rect():
    """Work-area ORIGIN + size in logical px, so create_window can open ALREADY at the full work area
    (top-left, full size) instead of being centered — which after an update-relaunch showed as a small,
    right-shifted window until _fill_work_area kicked in."""
    import ctypes
    from ctypes import wintypes
    lx, ly, w, h = _work_area()   # physical
    scale = 1.0
    try:
        mon = ctypes.windll.user32.MonitorFromPoint(wintypes.POINT(0, 0), 1)   # primary
        dx, dy = ctypes.c_uint(), ctypes.c_uint()
        ctypes.windll.shcore.GetDpiForMonitor(mon, 0, ctypes.byref(dx), ctypes.byref(dy))
        if dx.value:
            scale = dx.value / 96.0
    except Exception:
        pass
    return int(lx / scale), int(ly / scale), max(1000, int(w / scale)), max(650, int(h / scale))


def _hwnd():
    try:
        import ctypes
        from ctypes import wintypes
        native = getattr(_window, 'native', None)
        if native is not None:
            return int(native.Handle.ToInt64())
        u = _user32()
        hwnd = u.FindWindowW(None, "AI Dashboard")
        pid = wintypes.DWORD()
        if hwnd:
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value == os.getpid():
                return hwnd
        return 0
    except Exception:
        return 0


def _enable_taskbar_minimize():
    """Frameless windows lack WS_MINIMIZEBOX, so Windows won't minimize on a taskbar-button click and
    the minimize is un-animated. Add the style bit (WITHOUT SWP_FRAMECHANGED, so no title bar/frame is
    drawn) → clicking the taskbar icon toggles minimize/restore with the normal smooth animation."""
    try:
        import ctypes
        hwnd = _hwnd()
        if not hwnd:
            return
        GWL_STYLE = -16
        WS_MINIMIZEBOX = 0x00020000
        cur = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE)
        if not (cur & WS_MINIMIZEBOX):
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, cur | WS_MINIMIZEBOX)
    except Exception:
        pass


def _set_bounds(x, y, w, h):
    """Position the window in PHYSICAL pixels straight through the Win32 HWND — pywebview's own
    resize/move mis-scale on high-DPI displays (window too big/small, title bar shifted); SetWindowPos
    uses the same pixel space as SPI_GETWORKAREA, so this lands exactly."""
    try:
        import ctypes
        hwnd = _hwnd()
        if hwnd:
            return bool(_user32().SetWindowPos(hwnd, 0, int(x), int(y), int(w), int(h), 0x0014))  # NOZORDER | NOACTIVATE
    except Exception:
        pass
    return False


def _get_rect():
    try:
        import ctypes
        from ctypes import wintypes
        hwnd = _hwnd()
        r = wintypes.RECT()
        if hwnd and _user32().GetWindowRect(hwnd, ctypes.byref(r)):
            return r.left, r.top, r.right - r.left, r.bottom - r.top
    except Exception:
        pass
    return None


def _animate_to(x, y, w, h, dur=0.19, steps=13):
    """Glide the window from its current bounds to the target (easeOut) so maximize/restore feels
    smooth instead of snapping."""
    cur = _get_rect()
    if not cur:
        _set_bounds(x, y, w, h)
        return
    cx, cy, cw, ch = cur
    for i in range(1, steps + 1):
        e = 1 - (1 - i / steps) ** 3   # easeOutCubic
        _set_bounds(cx + (x - cx) * e, cy + (y - cy) * e, cw + (w - cw) * e, ch + (h - ch) * e)
        time.sleep(dur / steps)
    _set_bounds(x, y, w, h)


def _set_corners(rounded):
    """Win11 rounds window corners via DWM. Maximized apps normally get SQUARE corners; because we
    fill the screen ourselves (not a real OS-maximize) DWM keeps rounding, leaving a thin grey edge.
    Force square when filled, rounded when windowed — matches every other app."""
    try:
        import ctypes
        hwnd = _hwnd()
        if not hwnd:
            return
        dwm = ctypes.windll.dwmapi
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        pref = ctypes.c_int(2 if rounded else 1)   # 2 = ROUND, 1 = DONOTROUND
        dwm.DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(pref), ctypes.sizeof(pref))
        # remove the thin 1px window border line (DWMWA_BORDER_COLOR=34, DWMWA_COLOR_NONE=0xFFFFFFFE)
        col = ctypes.c_uint(0xFFFFFFFE)
        dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(col), ctypes.sizeof(col))
    except Exception:
        pass


def _fill_work_area(animate=False):
    x, y, w, h = _work_area()
    if animate:
        _animate_to(x, y, w, h)
    elif not _set_bounds(x, y, w, h):
        try:
            _window.resize(w, h); _window.move(x, y)
        except Exception:
            pass
    _set_corners(False)              # maximized → square corners (kills the grey edge line)


def _restore_bounds():
    """Calculate normal bounds without moving the window (also used by title-bar dragging)."""
    x, y, w, h = _work_area()
    if _normal_bounds:
        tx, ty, ww, wh = _normal_bounds
    else:
        ww, wh = int(w * 0.72), int(h * 0.82)
        tx, ty = x + (w - ww) // 2, y + (h - wh) // 2
    # A disconnected monitor must not leave the restored window off-screen.
    if ww >= w and wh >= h:
        ww, wh = int(w * 0.9), int(h * 0.9)
    ww, wh = min(ww, w), min(wh, h)
    tx, ty = max(x, min(tx, x + w - ww)), max(y, min(ty, y + h - wh))
    return tx, ty, ww, wh


def _restore_win(animate=True):
    tx, ty, ww, wh = _restore_bounds()
    hwnd = _hwnd()
    if hwnd and _user32().IsZoomed(hwnd):
        _user32().ShowWindow(hwnd, 9)
    if animate:
        _animate_to(tx, ty, ww, wh)
    elif not _set_bounds(tx, ty, ww, wh):
        try:
            _window.resize(ww, wh); _window.move(tx, ty)
        except Exception:
            pass
    _set_corners(True)               # windowed → rounded corners (like every other Win11 app)


def _snap_startup(*_args):
    # Delayed startup/page events must never undo a user's restore, resize or minimize.
    with _geometry_lock:
        if not _window_user_sized:
            _fill_work_area()


# ---- auto-update: pull newer app code from GitHub, staged for the launcher to apply next start ----
def _is_newer(remote, local):
    def parse(v):
        try:
            return [int(x) for x in str(v).strip().lstrip("vV").split(".")]
        except Exception:
            return [0]
    return parse(remote) > parse(local)


def _repo_base():
    try:
        import json
        cfg = json.loads((_HERE / "update.json").read_text(encoding="utf-8"))
        repo = (cfg.get("repo") or "").strip()
        if cfg.get("enabled") and repo:
            return f"https://raw.githubusercontent.com/{repo}/main"
    except Exception:
        pass
    return None


def _pending_version():
    """Return the newer remote version string if an update is available, else None (fast + safe)."""
    base = _repo_base()
    if not base:
        return None
    try:
        vf = _HERE / "version.txt"
        local = vf.read_text(encoding="utf-8").strip() if vf.exists() else "0"
        remote = urllib.request.urlopen(base + "/version.txt", timeout=6).read().decode("utf-8").strip()
        return remote if (remote and _is_newer(remote, local)) else None
    except Exception:
        return None


def _zip_is_whole(data, base):
    """True when the downloaded app.zip matches the checksum published beside it (when there is one)
    and every member passes the zip's own CRC. Half a download used to be unpacked over the live app."""
    import hashlib, io as _io, zipfile
    try:
        want = urllib.request.urlopen(base + "/app.zip.sha256", timeout=15).read().decode("utf-8").split()
        want = (want[0] if want else "").strip().lower()
    except Exception:
        want = ""                                        # released before checksums existed
    if want and hashlib.sha256(data).hexdigest() != want:
        return False
    try:
        with zipfile.ZipFile(_io.BytesIO(data)) as z:
            return z.testzip() is None
    except Exception:
        return False


def _download_update(remote):
    """Download the newer app.zip into _update/ so the launcher applies it on the next start."""
    base = _repo_base()
    if not base:
        return False
    try:
        data = urllib.request.urlopen(base + "/app.zip", timeout=300).read()
        if not _zip_is_whole(data, base):
            return False                                  # a short or damaged download is never staged
        upd = _ROOT / "_update"
        upd.mkdir(parents=True, exist_ok=True)
        (upd / "app.zip").write_bytes(data)
        (upd / "version.txt").write_text(remote, encoding="utf-8")
        return True
    except Exception:
        return False


def _relaunch():
    """Apply the just-downloaded update in place, then restart by re-running THIS interpreter directly.
    We deliberately do NOT relaunch through VSLDashboard.exe: its PyInstaller one-file bootloader can
    fail with 'Failed to load Python DLL' when spawned programmatically (parent exiting mid-launch).
    app/ files aren't locked on Windows (Python reads sources into memory), so we can overwrite them."""
    upd = _ROOT / "_update"
    try:
        if (upd / "app.zip").exists():
            from safe_update import install
            install(_HERE, upd)
    except Exception as error:
        from quietlog import quiet
        quiet(error, "desktop update")
        if (upd / "pending-install.json").exists():
            # Recovery is still pending: do not open an interface against mixed code files.
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                "The update was interrupted. Close and reopen AI Dashboard to restore the saved code backup.\n"
                + str(error), "AI Dashboard — update recovery", 0x10)
            os._exit(1)
        return False                     # old code was restored; open the existing version normally
    try:
        import sys as _sys
        import subprocess
        # sys.executable is runtime/pythonw.exe (the bundled interpreter) — no fragile .exe bootloader
        _env = dict(os.environ); _env["VSL_RELAUNCH"] = "1"   # child waits out the old instance's singleton mutex
        subprocess.Popen([_sys.executable, str(_HERE / "desktop.py")], cwd=str(_HERE), env=_env)
    except Exception:
        pass
    os._exit(0)


# ---- "what's new" notes: show a simple list of changes the first launch after an update ----
def _data_dir():
    return Path(os.environ.get("VSL_DATA_DIR") or _HERE)


def _app_version():
    try:
        return (_HERE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return "0"


def _vnum(v):
    try:
        return int(str(v).strip().lstrip("vV").split(".")[0])
    except Exception:
        return None


def _update_notes_js():
    """If the app version advanced since the last launch, return JS that shows an overlay listing
    what changed (from changelog.json), else None. Records the current version as 'seen' so the notes
    appear exactly once — on the first launch after an update."""
    try:
        import json
        seen_f = _data_dir() / "seen_version.txt"
        cur = _app_version()
        seen = seen_f.read_text(encoding="utf-8").strip() if seen_f.exists() else None
        seen_f.write_text(cur, encoding="utf-8")          # remember for next launch (always)
        cn, sn = _vnum(cur), _vnum(seen)
        if not seen or cn is None or sn is None or cn <= sn:
            return None                                    # fresh install or no jump → nothing to show
        cl_f = _HERE / "changelog.json"
        if not cl_f.exists():
            return None
        cl = json.loads(cl_f.read_text(encoding="utf-8"))
        notes = []
        for k in sorted(cl, key=lambda x: _vnum(x) or 0):
            kn = _vnum(k)
            if kn is not None and sn < kn <= cn:
                block = cl[k] if isinstance(cl[k], list) else [str(cl[k])]
                notes.extend(str(s) for s in block)
        if not notes:
            return None
        payload = json.dumps({"from": seen, "to": cur, "notes": notes}, ensure_ascii=False)
        return _NOTES_JS.replace("__PAYLOAD__", payload)
    except Exception:
        return None


_NOTES_JS = r"""(function run(){
  try{
    if(!document.body){ return void setTimeout(run,120); }
    var D = __PAYLOAD__;
    if(!D.notes || !D.notes.length || document.getElementById('vslUpd')) return;
    var esc = function(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); };
    var items = D.notes.map(function(s){
      return '<li style="margin:0 0 11px;padding-left:26px;position:relative;line-height:1.5;color:var(--text);font-size:14px">'
           + '<span style="position:absolute;left:0;top:0;color:#fff;font-weight:700">✓</span>'
           + esc(s) + '</li>';
    }).join('');
    var st = document.createElement('style');
    st.textContent = '@keyframes vslUf{from{opacity:0}to{opacity:1}}@keyframes vslUc{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}';
    document.head.appendChild(st);
    var wrap = document.createElement('div'); wrap.id='vslUpd';
    wrap.style.cssText='position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;'
      +'background:rgba(4,9,6,.74);font-family:Segoe UI,system-ui,sans-serif;animation:vslUf .25s ease';
    var card = document.createElement('div');
    card.style.cssText='max-width:470px;width:86%;max-height:80vh;overflow:auto;background:var(--panel);border:1px solid var(--border);'
      +'border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.55);padding:26px 26px 22px;animation:vslUc .28s ease';
    card.innerHTML =
      '<div style="display:flex;align-items:center;gap:11px;margin-bottom:4px">'
      +'<div style="width:36px;height:36px;border-radius:50%;flex:none;background:linear-gradient(180deg,var(--accent),var(--accent2));'
      +'display:flex;align-items:center;justify-content:center">'
      +'<span style="color:#fff;font-size:20px">✓</span></div>'
      +'<div><div style="font-size:17px;font-weight:700;color:var(--text)">Application updated</div>'
      +'<div style="font-size:12px;color:var(--muted)">Version '+esc(D.from)+' → '+esc(D.to)+'</div></div></div>'
      +'<div style="font-size:12.5px;color:var(--muted);margin:14px 0 12px">What\'s new in this update:</div>'
      +'<ul style="list-style:none;margin:0;padding:0">'+items+'</ul>'
      +'<button id="vslUpdOk" style="margin-top:18px;width:100%;padding:11px;border:0;border-radius:10px;'
      +'background:linear-gradient(180deg,var(--accent),var(--accent2));color:#fff;font-size:14px;font-weight:600;cursor:pointer">OK</button>';
    wrap.appendChild(card);
    document.body.appendChild(wrap);
    function close(){ wrap.style.animation='vslUf .18s ease reverse'; setTimeout(function(){ wrap.remove(); },170); }
    card.querySelector('#vslUpdOk').onclick = close;
    wrap.addEventListener('click', function(e){ if(e.target===wrap) close(); });
  }catch(e){}
})();"""


# ---- notification-sound preference (shared with the web app via app_config.json) --------------
def _notif_on():
    try:
        return bool(app._load_config().get("notif_sound", True))
    except Exception:
        return True


def _set_notif(on):
    try:
        cfg = app._load_config(); cfg["notif_sound"] = bool(on); app._save_config(cfg)
    except Exception:
        pass
    try:
        _window.run_js("try{window.__setNotifSound(%s)}catch(e){}" % ("true" if on else "false"))
    except Exception:
        pass


# ---- system tray: dependency-free Win32 (Shell_NotifyIcon). Runs in its OWN thread with a
# message-only window. EVERYTHING is guarded — if any step fails, `_tray` stays None and the app
# behaves exactly as before (the close button quits). It can never block launch. -----------------
_quitting = {"v": False}
_tray = None


class _Tray:
    def __init__(self, icon_path, on_show, on_exit):
        self.icon_path = str(icon_path)
        self.on_show = on_show
        self.on_exit = on_exit
        self.hwnd = None
        self._nid = None
        self._added = False
        self._proc_ref = None      # keep the WNDPROC callback alive (GC would crash the message loop)
        self._u = self._shell = self._ctypes = self._wt = None
        self._font = None
        self._menu_brush = None
        self._menu_proc_ref = None
        self._menu_hwnd = 0
        self._mi_items = []
        self._mi_hover = -1
        self._mi_w = 0
        self._mi_h = 0

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            import ctypes
            from ctypes import wintypes
            self._ctypes = ctypes; self._wt = wintypes
            u = ctypes.windll.user32; k = ctypes.windll.kernel32
            shell = ctypes.windll.shell32
            self._u = u; self._shell = shell

            WM_APP = 0x8000; WM_TRAY = WM_APP + 1
            WM_RBUTTONUP = 0x0205; WM_LBUTTONDBLCLK = 0x0203; WM_DESTROY = 0x0002
            WM_MEASUREITEM = 0x002C; WM_DRAWITEM = 0x002B
            NIM_ADD, NIM_DELETE = 0, 2
            NIF_MESSAGE, NIF_ICON, NIF_TIP = 1, 2, 4
            IMAGE_ICON = 1; LR_LOADFROMFILE = 0x10; LR_DEFAULTSIZE = 0x40
            MF_OWNERDRAW = 0x100; MF_DISABLED = 0x2; MF_GRAYED = 0x1
            TPM_RIGHTBUTTON, TPM_RETURNCMD = 0x2, 0x100
            ODS_SELECTED = 0x0001
            DT_SINGLELINE, DT_VCENTER, DT_LEFT, DT_RIGHT = 0x20, 0x4, 0x0, 0x2
            MIM_BACKGROUND = 0x2
            LRESULT = ctypes.c_ssize_t
            SEP_ID = 9
            # our theme, as COLORREF (0x00BBGGRR)
            def _rgb(r, g, b): return r | (g << 8) | (b << 16)
            # The tray belongs to the APP, not to any one project, so it wears the same anthracite as
            # the sign-in and project-picker screens rather than either project colour.
            COL_BG = _rgb(0x13, 0x15, 0x17)       # dark panel
            COL_HOVER = _rgb(0x36, 0x3d, 0x42)    # steel highlight
            COL_TXT = _rgb(0xd8, 0xdc, 0xde)      # light text
            COL_TXT_SEL = _rgb(0xff, 0xff, 0xff)  # text on the highlight
            COL_CHECK = _rgb(0xa8, 0xb2, 0xb8)    # the tick when a toggle is on
            COL_SEP = _rgb(0x2a, 0x2f, 0x33)      # faint divider line
            ITEM_W, ITEM_H, SEP_H = 186, 34, 10
            LABELS = {2: "Show", 1: "Sound", 3: "Quit"}

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            class NID(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND), ("uID", wintypes.UINT),
                            ("uFlags", wintypes.UINT), ("uCallbackMessage", wintypes.UINT),
                            ("hIcon", wintypes.HICON), ("szTip", wintypes.WCHAR * 128),
                            ("dwState", wintypes.DWORD), ("dwStateMask", wintypes.DWORD),
                            ("szInfo", wintypes.WCHAR * 256), ("uVersion", wintypes.UINT),
                            ("szInfoTitle", wintypes.WCHAR * 64), ("dwInfoFlags", wintypes.DWORD),
                            ("guidItem", GUID), ("hBalloonIcon", wintypes.HICON)]

            WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)

            class WNDCLASS(ctypes.Structure):
                _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", WNDPROC),
                            ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                            ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                            ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HBRUSH),
                            ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR)]

            u.DefWindowProcW.restype = LRESULT
            u.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
            u.CreateWindowExW.restype = wintypes.HWND
            u.TrackPopupMenu.restype = ctypes.c_int
            u.AppendMenuW.argtypes = [wintypes.HMENU, wintypes.UINT, ctypes.c_size_t, wintypes.LPCWSTR]

            # ---- owner-draw so the menu matches the app (green hover, our font) instead of a native list ----
            gdi = ctypes.windll.gdi32
            gdi.CreateSolidBrush.restype = wintypes.HBRUSH
            gdi.CreateSolidBrush.argtypes = [wintypes.COLORREF]
            u.FillRect.argtypes = [wintypes.HDC, ctypes.POINTER(wintypes.RECT), wintypes.HBRUSH]
            gdi.SetTextColor.argtypes = [wintypes.HDC, wintypes.COLORREF]
            gdi.SetBkMode.argtypes = [wintypes.HDC, ctypes.c_int]
            u.DrawTextW.argtypes = [wintypes.HDC, wintypes.LPCWSTR, ctypes.c_int, ctypes.POINTER(wintypes.RECT), wintypes.UINT]
            gdi.SelectObject.restype = wintypes.HGDIOBJ
            gdi.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
            gdi.DeleteObject.argtypes = [wintypes.HGDIOBJ]
            gdi.CreateFontW.restype = wintypes.HGDIOBJ
            gdi.AddFontResourceExW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p]
            # load Poppins privately (it isn't installed system-wide) so the menu uses the app's own font
            face = "Segoe UI"
            try:
                for _fn in ("Poppins-Regular.ttf", "Poppins-Medium.ttf"):
                    fp = _HERE / "static" / "fonts" / _fn
                    if fp.exists():
                        gdi.AddFontResourceExW(str(fp), 0x10, None)   # FR_PRIVATE
                        face = "Poppins"
            except Exception:
                pass
            try:
                self._font = gdi.CreateFontW(-14, 0, 0, 0, 500, 0, 0, 0, 1, 0, 0, 5, 0, face)
            except Exception:
                self._font = None
            try:
                self._menu_brush = gdi.CreateSolidBrush(COL_BG)   # dark menu background (kills the white gaps/border)
            except Exception:
                self._menu_brush = None

            class MENUINFO(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("fMask", wintypes.DWORD), ("dwStyle", wintypes.DWORD),
                            ("cyMax", wintypes.UINT), ("hbrBack", wintypes.HBRUSH),
                            ("dwContextHelpID", wintypes.DWORD), ("dwMenuData", ctypes.c_size_t)]

            class MEASUREITEMSTRUCT(ctypes.Structure):
                _fields_ = [("CtlType", wintypes.UINT), ("CtlID", wintypes.UINT), ("itemID", wintypes.UINT),
                            ("itemWidth", wintypes.UINT), ("itemHeight", wintypes.UINT), ("itemData", ctypes.c_size_t)]

            class DRAWITEMSTRUCT(ctypes.Structure):
                _fields_ = [("CtlType", wintypes.UINT), ("CtlID", wintypes.UINT), ("itemID", wintypes.UINT),
                            ("itemAction", wintypes.UINT), ("itemState", wintypes.UINT), ("hwndItem", wintypes.HWND),
                            ("hDC", wintypes.HDC), ("rcItem", wintypes.RECT), ("itemData", ctypes.c_size_t)]

            def _measure(lparam):
                mis = ctypes.cast(lparam, ctypes.POINTER(MEASUREITEMSTRUCT)).contents
                mis.itemWidth = ITEM_W
                mis.itemHeight = SEP_H if mis.itemID == SEP_ID else ITEM_H
                return 1

            def _draw(lparam):
                dis = ctypes.cast(lparam, ctypes.POINTER(DRAWITEMSTRUCT)).contents
                hdc = dis.hDC; rc = dis.rcItem
                if dis.itemID == SEP_ID:                       # thin faint divider above Quit
                    bg = gdi.CreateSolidBrush(COL_BG); u.FillRect(hdc, ctypes.byref(rc), bg); gdi.DeleteObject(bg)
                    ln = gdi.CreateSolidBrush(COL_SEP)
                    my = (rc.top + rc.bottom) // 2
                    line = wintypes.RECT(rc.left + 12, my, rc.right - 12, my + 1)
                    u.FillRect(hdc, ctypes.byref(line), ln); gdi.DeleteObject(ln)
                    return 1
                sel = bool(dis.itemState & ODS_SELECTED)
                br = gdi.CreateSolidBrush(COL_HOVER if sel else COL_BG)
                u.FillRect(hdc, ctypes.byref(rc), br); gdi.DeleteObject(br)
                gdi.SetBkMode(hdc, 1)   # TRANSPARENT
                gdi.SetTextColor(hdc, COL_TXT_SEL if sel else COL_TXT)
                old = gdi.SelectObject(hdc, self._font) if self._font else None
                label = LABELS.get(dis.itemID, "")
                tr = wintypes.RECT(rc.left + 15, rc.top, rc.right - 12, rc.bottom)
                u.DrawTextW(hdc, label, -1, ctypes.byref(tr), DT_SINGLELINE | DT_VCENTER | DT_LEFT)
                if dis.itemID == 1 and _notif_on():   # Sound is on → green check on the right
                    gdi.SetTextColor(hdc, COL_TXT_SEL if sel else COL_CHECK)
                    u.DrawTextW(hdc, "✓", -1, ctypes.byref(tr), DT_SINGLELINE | DT_VCENTER | DT_RIGHT)
                if old:
                    gdi.SelectObject(hdc, old)
                return 1

            def _visible_menu_win():
                # there can be several cached #32768 windows; style only the VISIBLE one (the real popup),
                # otherwise we were darkening a stale hidden window and nothing changed on screen.
                mw = 0; prev = 0
                while True:
                    prev = u.FindWindowExW(0, prev, "#32768", None)
                    if not prev:
                        break
                    if u.IsWindowVisible(prev):
                        mw = prev
                return mw

            def _round_menu():
                # the popup-menu window (class #32768) is OS-owned; make its frame dark, round its corners and
                # drop the light border so it matches the app. The window appears a few ms after the menu opens.
                try:
                    dwm = ctypes.windll.dwmapi
                    ux = ctypes.WinDLL("uxtheme.dll")
                    u.FindWindowExW.restype = wintypes.HWND
                except Exception:
                    return
                applied = 0
                for _ in range(24):
                    try:
                        mw = _visible_menu_win()
                        if mw:
                            try: ux[133](mw, 1)   # AllowDarkModeForWindow(menu, TRUE)
                            except Exception: pass
                            dark = ctypes.c_int(1)
                            dwm.DwmSetWindowAttribute(mw, 20, ctypes.byref(dark), ctypes.sizeof(dark))   # immersive dark frame
                            pref = ctypes.c_int(2)
                            dwm.DwmSetWindowAttribute(mw, 33, ctypes.byref(pref), ctypes.sizeof(pref))   # rounded corners
                            col = ctypes.c_uint(0xFFFFFFFE)
                            dwm.DwmSetWindowAttribute(mw, 34, ctypes.byref(col), ctypes.sizeof(col))     # DWMWA_COLOR_NONE → no border
                            try:
                                u.RedrawWindow(mw, None, None, 0x0001 | 0x0100)   # RDW_INVALIDATE|RDW_UPDATENOW
                            except Exception:
                                pass
                            applied += 1
                            if applied >= 4:
                                break
                    except Exception:
                        pass
                    time.sleep(0.012)

            def _menu():
                # native owner-drawn popup (reliable): dark bg, Poppins, green hover, ✓ on Sound, faint divider.
                u.SetForegroundWindow(self.hwnd)
                m = u.CreatePopupMenu()
                u.AppendMenuW(m, MF_OWNERDRAW, 2, None)                                   # Show
                u.AppendMenuW(m, MF_OWNERDRAW, 1, None)                                   # Sound
                u.AppendMenuW(m, MF_OWNERDRAW | MF_DISABLED | MF_GRAYED, SEP_ID, None)    # faint divider
                u.AppendMenuW(m, MF_OWNERDRAW, 3, None)                                   # Quit
                if self._menu_brush:
                    try:
                        mi = MENUINFO(); mi.cbSize = ctypes.sizeof(MENUINFO)
                        mi.fMask = MIM_BACKGROUND; mi.hbrBack = self._menu_brush
                        u.SetMenuInfo(m, ctypes.byref(mi))
                    except Exception:
                        pass
                threading.Thread(target=_round_menu, daemon=True).start()   # best-effort dark frame / rounded corners
                pt = wintypes.POINT(); u.GetCursorPos(ctypes.byref(pt))
                cmd = u.TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, self.hwnd, None)
                u.DestroyMenu(m)
                u.PostMessageW(self.hwnd, 0, 0, 0)   # MSDN-recommended after TrackPopupMenu
                if cmd == 1:
                    _set_notif(not _notif_on())
                elif cmd == 2:
                    try: self.on_show()
                    except Exception: pass
                elif cmd == 3:
                    try: self.on_exit()
                    except Exception: pass

            def _wndproc(hwnd, msg, wparam, lparam):
                if msg == WM_TRAY:
                    low = lparam & 0xFFFF
                    if low == WM_RBUTTONUP:
                        _menu()
                    elif low == WM_LBUTTONDBLCLK:
                        try: self.on_show()
                        except Exception: pass
                    return 0
                if msg == WM_MEASUREITEM:
                    try: return _measure(lparam)
                    except Exception: return 0
                if msg == WM_DRAWITEM:
                    try: return _draw(lparam)
                    except Exception: return 0
                if msg == WM_DESTROY:
                    u.PostQuitMessage(0); return 0
                return u.DefWindowProcW(hwnd, msg, wparam, lparam)

            self._proc_ref = WNDPROC(_wndproc)
            hinst = k.GetModuleHandleW(None)
            wc = WNDCLASS()
            wc.lpfnWndProc = self._proc_ref
            wc.hInstance = hinst
            wc.lpszClassName = "VSLDashboardTray"
            u.RegisterClassW(ctypes.byref(wc))   # if already registered we still create below
            self.hwnd = u.CreateWindowExW(0, "VSLDashboardTray", "VSLTray", 0, 0, 0, 0, 0, None, None, hinst, None)
            if not self.hwnd:
                return
            # Dark context menu (matches the app's dark theme) instead of the default white Windows menu.
            # Uses uxtheme's dark-mode entry points (Win10 1903+/Win11). Undocumented ordinals → guarded:
            # if unavailable the menu just renders in the default light theme, no functional impact.
            try:
                ux = ctypes.WinDLL("uxtheme.dll")
                try: ux[135](2)          # SetPreferredAppMode(AppMode_ForceDark)
                except Exception: pass
                try: ux[133](self.hwnd, 1)   # AllowDarkModeForWindow(hwnd, TRUE)
                except Exception: pass
                try: ux[136]()           # FlushMenuThemes()
                except Exception: pass
            except Exception:
                pass
            hicon = 0
            try:
                hicon = u.LoadImageW(None, self.icon_path, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            except Exception:
                hicon = 0
            nid = NID()
            nid.cbSize = ctypes.sizeof(NID); nid.hWnd = self.hwnd; nid.uID = 1
            nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
            nid.uCallbackMessage = WM_TRAY
            nid.hIcon = hicon or 0
            nid.szTip = "AI Dashboard"
            if not shell.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid)):
                return
            self._nid = nid; self._added = True
            msg = wintypes.MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                u.TranslateMessage(ctypes.byref(msg))
                u.DispatchMessageW(ctypes.byref(msg))
        except Exception:
            self._added = False

    def remove(self):
        try:
            if self._added and self._shell and self._nid is not None:
                self._shell.Shell_NotifyIconW(2, self._ctypes.byref(self._nid))   # NIM_DELETE
        except Exception:
            pass
        try:
            if self.hwnd and self._u:
                self._u.DestroyWindow(self.hwnd)
        except Exception:
            pass
        try:
            if self._font:
                self._ctypes.windll.gdi32.DeleteObject(self._font)
        except Exception:
            pass
        try:
            if getattr(self, "_menu_brush", None):
                self._ctypes.windll.gdi32.DeleteObject(self._menu_brush)
        except Exception:
            pass


def _tray_show():
    try:
        _window.restore()      # if it was minimized
    except Exception:
        pass
    try:
        _window.show()         # if it was hidden to the tray
    except Exception:
        pass
    try:
        import ctypes
        hwnd = _hwnd()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 9)          # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(hwnd)    # bring it to the front / focus
    except Exception:
        pass
    try:
        _enable_taskbar_minimize()
    except Exception:
        pass


def _tray_exit():
    _stop_windows_dictation()
    _quitting["v"] = True
    try:
        if _tray:
            _tray.remove()
    except Exception:
        pass
    try:
        _window.destroy()
    except Exception:
        pass
    os._exit(0)


# ---- single instance: a second launch (desktop icon) just SHOWS the running one, no new window -----
_SINGLETON_MUTEX = "VSLDashboard_SingleInstance_Mutex"
_SINGLETON_EVENT = "VSLDashboard_ShowWindow_Event"
_mutex_handle = None
_show_event = None
_ERROR_ALREADY_EXISTS = 183


def _singleton_check():
    """Return True if we're the instance that should run. If another instance is already alive, signal it
    to show its window and return False (caller exits). After an auto-update relaunch we WAIT for the old
    process to release the mutex instead of bailing (else the app would never reopen)."""
    global _mutex_handle, _show_event
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = wintypes.HANDLE
        k.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
        k.CreateEventW.restype = wintypes.HANDLE
        k.CreateEventW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
        k.OpenEventW.restype = wintypes.HANDLE
        k.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
        k.SetEvent.argtypes = [wintypes.HANDLE]
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        relaunch = os.environ.pop("VSL_RELAUNCH", None)
        tries = 50 if relaunch else 1     # relaunch: give the exiting old process ~5s to free the mutex
        for _i in range(tries):
            h = k.CreateMutexW(None, False, _SINGLETON_MUTEX)
            if k.GetLastError() != _ERROR_ALREADY_EXISTS:
                _mutex_handle = h         # we own it → we're the live instance
                _show_event = k.CreateEventW(None, False, False, _SINGLETON_EVENT)
                return True
            if h:
                k.CloseHandle(h)
            if not relaunch:              # genuine second launch → tell the running instance to show, then exit
                he = k.OpenEventW(0x0002, False, _SINGLETON_EVENT)   # EVENT_MODIFY_STATE
                if he:
                    k.SetEvent(he); k.CloseHandle(he)
                return False
            time.sleep(0.1)
        _show_event = k.CreateEventW(None, False, False, _SINGLETON_EVENT)   # relaunch fallback: proceed anyway
        return True
    except Exception:
        return True                        # never block launch over the singleton check


def _show_listener():
    """First instance: wait for a second launch to signal the show-event, then surface our window."""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        k.WaitForSingleObject.restype = wintypes.DWORD
        k.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    except Exception:
        return
    while _show_event:
        try:
            if k.WaitForSingleObject(_show_event, 0xFFFFFFFF) == 0:   # WAIT_OBJECT_0
                _tray_show()
            else:
                time.sleep(1)
        except Exception:
            time.sleep(1)


# Windows voice typing is opt-in through a prompt microphone click. No startup hooks.
class _VoiceTypingWindows:
    def __init__(self, hwnd):
        import ctypes as C
        from ctypes import wintypes as W
        self.C, self.W, self.hwnd = C, W, hwnd
        self.u = C.WinDLL('user32', use_last_error=True)
        self.k = C.WinDLL('kernel32', use_last_error=True)
        u,k=self.u,self.k
        u.GetForegroundWindow.restype=W.HWND
        u.GetWindowThreadProcessId.argtypes=[W.HWND,C.POINTER(W.DWORD)]
        u.IsWindowVisible.argtypes=[W.HWND];u.IsWindow.argtypes=[W.HWND]
        u.GetWindowTextW.argtypes=[W.HWND,W.LPWSTR,C.c_int]
        u.GetClassNameW.argtypes=[W.HWND,W.LPWSTR,C.c_int]
        u.GetWindowRect.argtypes=[W.HWND,C.POINTER(W.RECT)]
        u.GetWindowLongPtrW.argtypes=[W.HWND,C.c_int];u.GetWindowLongPtrW.restype=C.c_ssize_t
        u.SetWindowLongPtrW.argtypes=[W.HWND,C.c_int,C.c_ssize_t];u.SetWindowLongPtrW.restype=C.c_ssize_t
        u.GetLayeredWindowAttributes.argtypes=[W.HWND,C.POINTER(W.DWORD),C.POINTER(C.c_ubyte),C.POINTER(W.DWORD)]
        u.SetLayeredWindowAttributes.argtypes=[W.HWND,W.DWORD,C.c_ubyte,W.DWORD]
        k.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenProcess.restype=W.HANDLE
        k.QueryFullProcessImageNameW.argtypes=[W.HANDLE,W.DWORD,W.LPWSTR,C.POINTER(W.DWORD)]
        k.CloseHandle.argtypes=[W.HANDLE]
        class Key(C.Structure):
            _fields_=[('vk',W.WORD),('scan',W.WORD),('flags',W.DWORD),('time',W.DWORD),('extra',C.c_size_t)]
        class Mouse(C.Structure):
            _fields_=[('dx',W.LONG),('dy',W.LONG),('data',W.DWORD),('flags',W.DWORD),('time',W.DWORD),('extra',C.c_size_t)]
        class Payload(C.Union):_fields_=[('key',Key),('mouse',Mouse)]
        class Input(C.Structure):_fields_=[('type',W.DWORD),('data',Payload)]
        self.Input,self.Key=Input,Key
        u.SendInput.argtypes=[W.UINT,C.POINTER(Input),C.c_int];u.SendInput.restype=W.UINT

    def focused(self, panel=None):
        foreground=int(self.u.GetForegroundWindow() or 0)
        hwnd=int(self.hwnd() or 0)
        return bool(hwnd and foreground==hwnd) or bool(panel and foreground==panel['hwnd'] and self.alive(panel))

    def send(self, chord):
        C,u=self.C,self.u
        if chord=='start' and any(u.GetAsyncKeyState(key)&0x8000 for key in (0x10,0x11,0x12,0x5B,0x5C)):
            return dict(ok=False,error='Release Shift/Ctrl/Alt/Windows keys and try the microphone again.')
        sequence=[(0x5B,0),(0x48,0),(0x48,2),(0x5B,2)] if chord=='start' else [(0x1B,0),(0x1B,2)]
        def inject(seq):
            entries=(self.Input*len(seq))()
            for i,(key,flags) in enumerate(seq):entries[i].type=1;entries[i].data.key=self.Key(key,0,flags,0,0)
            C.set_last_error(0)
            count=u.SendInput(len(seq),entries,C.sizeof(self.Input))
            return count,C.get_last_error()
        count,error=inject(sequence)
        if 0<count<len(sequence):inject([(key,2) for key in dict.fromkeys(key for key,_ in sequence)])
        return dict(ok=count==len(sequence),sent=int(count),winerror=error,
                    error='' if count==len(sequence) else 'Windows did not accept the shortcut. Click the prompt and press Win+H manually, or choose Local Dictation from the microphone menu.')

    def _path(self,pid):
        C,W,k=self.C,self.W,self.k;handle=k.OpenProcess(0x1000,False,pid)
        if not handle:return ''
        try:
            buf=C.create_unicode_buffer(2048);size=W.DWORD(len(buf))
            return buf.value if k.QueryFullProcessImageNameW(handle,0,buf,C.byref(size)) else ''
        finally:k.CloseHandle(handle)

    def panels(self):
        C,W,u=self.C,self.W,self.u;out=[]
        @C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
        def visit(hwnd,_):
            if not u.IsWindowVisible(hwnd):return True
            pid=W.DWORD();u.GetWindowThreadProcessId(hwnd,C.byref(pid));path=self._path(pid.value)
            # Never manipulate an arbitrary application with a similar window title.
            root=os.environ.get('SystemRoot',r'C:\Windows').lower().rstrip('\\')+'\\systemapps\\'
            if not path.lower().startswith(root) or not path.lower().endswith('\\textinputhost.exe'):return True
            title=C.create_unicode_buffer(512);cls=C.create_unicode_buffer(256);r=W.RECT()
            u.GetWindowTextW(hwnd,title,512);u.GetClassNameW(hwnd,cls,256);u.GetWindowRect(hwnd,C.byref(r))
            if 30<r.right-r.left<1400 and 25<r.bottom-r.top<900:
                out.append(dict(hwnd=int(hwnd),pid=pid.value,path=path,title=title.value,cls=cls.value,rect=(r.left,r.top,r.right,r.bottom)))
            return True
        u.EnumWindows(visit,0)
        return out

    def exists(self,panel):
        C,W,u=self.C,self.W,self.u;pid=W.DWORD();u.GetWindowThreadProcessId(panel['hwnd'],C.byref(pid))
        return bool(u.IsWindow(panel['hwnd']) and pid.value==panel['pid'])

    def alive(self,panel):
        return self.exists(panel) and bool(self.u.IsWindowVisible(panel['hwnd']))

    def hide(self,panel):
        C,W,u=self.C,self.W,self.u
        if not self.alive(panel):raise RuntimeError('Windows panel is no longer available.')
        h=panel['hwnd'];C.set_last_error(0);style=u.GetWindowLongPtrW(h,-20)
        if C.get_last_error():raise RuntimeError('Windows panel could not be read; it remains visible.')
        color=W.DWORD();alpha=C.c_ubyte();flags=W.DWORD();layered=bool(style&0x80000)
        if layered and not u.GetLayeredWindowAttributes(h,C.byref(color),C.byref(alpha),C.byref(flags)):
            raise RuntimeError('This Windows panel cannot be hidden safely; it remains visible.')
        original=dict(style=style,color=color.value,alpha=alpha.value,flags=flags.value,layered=layered)
        C.set_last_error(0);u.SetWindowLongPtrW(h,-20,style|0x80000|0x20)
        if C.get_last_error():raise RuntimeError('Windows declined panel hiding; it remains visible.')
        if not u.SetLayeredWindowAttributes(h,0,0,2):
            self.restore(panel,original)
            raise RuntimeError('Windows declined panel transparency; it remains visible.')
        return original

    def restore(self,panel,original):
        if not self.exists(panel):return
        u=self.u;h=panel['hwnd'];o=original
        u.SetLayeredWindowAttributes(h,o['color'] if o['layered'] else 0,o['alpha'] if o['layered'] else 255,o['flags'] if o['layered'] else 2)
        u.SetWindowLongPtrW(h,-20,o['style'])


class _PromptDictationSession:
    """Pure session rules; adapter owns native calls. Status never claims ASR is listening."""
    def __init__(self,native,clock=None):
        self.native=native;self.clock=clock or time.monotonic;self.lock=threading.RLock();self.session=None

    def snapshot(self):
        s=self.session
        return {k:s.get(k) for k in ('token','state','hidden','warning')} if s else dict(state='idle',hidden=False)

    def heartbeat(self,token):
        # UI requests read cached state. Only the watchdog enumerates/checks native windows.
        with self.lock:
            s=self.session
            if not s or token!=s['token']:return dict(state='idle',hidden=False)
            if s['state']!='ended':s['heartbeat']=self.clock()
            return self.snapshot()

    def start(self,token,hide=False):
        with self.lock:
            if not isinstance(token,str) or not 8<=len(token)<=100 or not all(c.isalnum() or c in '-_' for c in token):
                return dict(ok=False,error='Invalid dictation session.')
            if self.session and self.session['state']!='ended':return dict(ok=False,error='Stop the current Windows dictation first.')
            if not self.native.focused():return dict(ok=False,error='Click this prompt before starting Windows dictation.')
            before=self.native.panels()
            if before:return dict(ok=False,error='A Windows typing panel is already open. Close it, then click this microphone again. No panel was changed.')
            result=self.native.send('start')
            if not result.get('ok'):return result
            self.session=dict(token=token,state='opening',started=self.clock(),heartbeat=self.clock(),hide=bool(hide),hidden=False,original=None,panel=None,warning='')
            return dict(ok=True,**self.snapshot())

    def _restore(self):
        s=self.session
        if s and s.get('original'):
            self.native.restore(s['panel'],s['original']);s['original']=None;s['hidden']=False

    def stop(self,token=None):
        with self.lock:
            s=self.session
            if not s or (token is not None and token!=s['token']):return dict(ok=True,state='idle')
            self._restore()
            if s['state']=='ended':return dict(ok=True,**self.snapshot())
            focused=self.native.focused(s.get('panel'))
            result=self.native.send('stop') if focused else dict(ok=False)
            s['state']='ended'
            if not result.get('ok'):s['warning']='Windows panel restored. Stop its microphone manually if it is still listening.'
            return dict(ok=True,**self.snapshot())

    def poll(self,token=None,heartbeat=False):
        with self.lock:
            s=self.session
            if not s or (token is not None and token!=s['token']):return dict(state='idle',hidden=False)
            if s['state']=='ended':return self.snapshot()
            now=self.clock()
            if heartbeat:s['heartbeat']=now
            if now-s['started']>115 or now-s['heartbeat']>6:
                return self.stop(s['token'])
            discovered=False
            if not s['panel'] and s['state']=='opening':
                panels=self.native.panels()
                if len(panels)==1:
                    s['panel']=panels[0];s['state']='ready';discovered=True
                elif now-s['started']>8:
                    s['state']='unconfirmed';s['warning']='The Windows shortcut was sent, but its panel could not be confirmed. If typing did not start, stop and try Win+H manually or Local Dictation.'
            # Windows may foreground its panel as it opens. Identify it before
            # checking focus, but never hide it while an unrelated app is active.
            if not self.native.focused(s.get('panel')):return self.stop(s['token'])
            if s['panel']:
                if not self.native.alive(s['panel']):
                    self._restore();s['state']='ended'
                elif discovered and s['hide']:
                    try:s['original']=self.native.hide(s['panel']);s['hidden']=True
                    except Exception as error:s['warning']=str(error)
            return self.snapshot()

    def set_hidden(self,token,hide):
        with self.lock:
            s=self.session
            if not s or token!=s['token'] or s['state']=='ended':return dict(state='idle',hidden=False)
            s['hide']=bool(hide);s['warning']=''
            if not hide:self._restore()
            elif s['panel'] and not s['hidden'] and self.native.focused(s['panel']):
                try:s['original']=self.native.hide(s['panel']);s['hidden']=True
                except Exception as error:s['warning']=str(error)
            return self.snapshot()


_windows_dictation=None
_windows_dictation_lock=threading.Lock()
def _dictation_manager():
    global _windows_dictation
    with _windows_dictation_lock:
        if _windows_dictation is None:
            _windows_dictation=_PromptDictationSession(_VoiceTypingWindows(_hwnd))
        return _windows_dictation

def _stop_windows_dictation():
    if _windows_dictation:
        try:_windows_dictation.stop()
        except Exception:pass

def _watch_windows_dictation(manager,token):
    while True:
        time.sleep(.5)
        try:
            if manager.poll(token).get('state') in ('idle','ended'):return
        except Exception:
            manager.stop(token);return


class DesktopApi:
    """JS bridge: file downloads + custom (frameless) window controls."""

    def prompt_dictation_start(self, token, hide_panel=False):
        try:
            manager=_dictation_manager();result=manager.start(token,hide_panel)
            if result.get('ok'):
                threading.Thread(target=_watch_windows_dictation,args=(manager,token),daemon=True).start()
            return result
        except Exception as error:
            return dict(ok=False,error='Windows dictation could not start: '+str(error))

    def prompt_dictation_status(self, token):
        return _windows_dictation.heartbeat(token) if _windows_dictation else dict(state='idle')

    def prompt_dictation_stop(self, token):
        return _windows_dictation.stop(token) if _windows_dictation else dict(ok=True,state='idle')

    def prompt_dictation_panel(self, token, hidden):
        return _windows_dictation.set_hidden(token,hidden) if _windows_dictation else dict(state='idle')

    def __init__(self):
        self.maximized = True   # the window opens maximized

    # ---- custom title-bar window controls ----
    def win_minimize(self):
        global _window_user_sized
        _window_user_sized = True
        try:
            _window.minimize()
        except Exception:
            pass
        return True

    def win_is_maximized(self):
        """Is the window ACTUALLY filling the work area right now? Measured, not remembered.

        `self.maximized` starts True because the window is meant to open maximized - but if it did not
        (a minimised launch, a failed SetWindowPos, a display change), the flag lies and the title-bar
        button then does the opposite of what it looks like: press it once and nothing appears to
        happen. Ask the window instead."""
        with _geometry_lock:
            try:
                r = _get_rect()
                if not r:
                    return bool(self.maximized)
                hwnd = _hwnd()
                if hwnd and _user32().IsZoomed(hwnd):
                    return True
                wx, wy, ww, wh = _work_area()
                near = 6                                  # a few px of shadow/rounding either way
                return (abs(r[0] - wx) <= near and abs(r[1] - wy) <= near and
                        abs(r[2] - ww) <= near and abs(r[3] - wh) <= near)
            except Exception:
                return bool(self.maximized)

    def win_maximize(self):
        global _window_user_sized, _normal_bounds
        with _geometry_lock:
            _window_user_sized = True
            try:
                if self.win_is_maximized():
                    _restore_win(animate=True)
                else:
                    current = _get_rect()
                    if current and current[2] > 0 and current[3] > 0:
                        _normal_bounds = current
                    _fill_work_area(animate=True)
                self.maximized = self.win_is_maximized()
            except Exception:
                pass
            return self.maximized

    def win_close(self):
        _stop_windows_dictation()
        global _window_user_sized
        _window_user_sized = True
        # With the tray active, the close button HIDES to the system tray (near the clock) instead of
        # quitting — the app keeps running (still hears generation chimes). Only tray → Exit truly quits.
        if _tray is not None and not _quitting["v"]:
            try:
                _window.hide()
                return True
            except Exception:
                pass
        try:
            _window.destroy()
        except Exception:
            pass
        return True

    def win_bounds(self):
        r = _get_rect()   # physical px
        return {"x": r[0], "y": r[1], "w": r[2], "h": r[3]} if r else None

    def win_drag_bounds(self):
        # A click/double-click must not restore the window. JS commits the first
        # move only after the pointer has travelled beyond the drag threshold.
        with _geometry_lock:
            bounds = self.win_bounds()
            if bounds:
                bounds["maximized"] = self.win_is_maximized()
                normal = _restore_bounds()
                bounds.update(restoreW=normal[2], restoreH=normal[3])
            return bounds

    def win_set_bounds(self, x, y, w, h):
        global _window_user_sized, _normal_bounds
        with _geometry_lock:
            _window_user_sized = True
            hwnd = _hwnd()
            if hwnd and _user32().IsZoomed(hwnd):
                _user32().ShowWindow(hwnd, 9)
            if not _set_bounds(x, y, w, h):
                return False
            _normal_bounds = _get_rect()
            self.maximized = self.win_is_maximized()
            _set_corners(not self.maximized)
            return True

    # ---- folder picker (for the export/import sync folder) ----
    def pick_folder(self):
        try:
            import webview
            res = _window.create_file_dialog(webview.FOLDER_DIALOG)
            if not res:
                return {"ok": False, "cancelled": True}
            path = res if isinstance(res, str) else res[0]
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- downloads ----
    # The browser's <a download> / window.location downloads don't trigger a save inside WebView2,
    # so the frontend calls save_download(url, ...) which streams that URL from the local server
    # (any file, including generated .zip exports) and writes it to a native Save-As location.
    def download_status(self, token):
        import download_progress
        return download_progress.status(self, token) or {}

    def save_download(self, url, cookie, fallback, token=None):
        import download_progress
        record = download_progress.begin(self, token)
        report = record.update if record else lambda *args: None
        try:
            import re as _re
            import requests
            import webview
            from urllib.parse import unquote
            full = url if str(url).startswith("http") else f"http://{HOST}:{PORT}{url}"
            headers = {"Cookie": cookie} if cookie else {}
            if record: headers["X-Download-Id"] = token
            with requests.get(full, headers=headers, stream=True, timeout=1800) as resp:
                if resp.status_code >= 400 and 'application/json' in resp.headers.get('Content-Type', '').lower():
                    # Preserve the local export's actionable message instead of hiding it behind HTTP 500.
                    import json
                    payload = bytearray()
                    for chunk in resp.iter_content(4096):
                        payload.extend(chunk)
                        if len(payload) > 16384: break
                    try:
                        detail = json.loads(payload).get('error') if len(payload) <= 16384 else None
                    except (ValueError, AttributeError):
                        detail = None
                    if isinstance(detail, str) and detail.strip():
                        raise ValueError(detail.strip()[:1500])
                resp.raise_for_status()
                name = fallback or "download"
                cd = resp.headers.get("Content-Disposition", "")
                m = _re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)\"?", cd)
                if m:
                    name = unquote(m.group(1))
                info = resp.headers.get("X-Export-Info")   # the "all zip" export summary, if present
                report("Choose Save Location")
                dest = _window.create_file_dialog(webview.SAVE_DIALOG, save_filename=name)
                if not dest:
                    report("Cancelled")
                    return {"ok": False, "cancelled": True}
                dest = dest if isinstance(dest, str) else dest[0]
                try: total = int(resp.headers.get("Content-Length", "0"))
                except (TypeError, ValueError): total = 0
                completed = 0
                report("Saving File", 0, total, "bytes")
                with open(dest, "wb") as f:
                    for chunk in resp.iter_content(1 << 16):
                        if chunk:
                            f.write(chunk)
                            completed += len(chunk)
                            report("Saving File", completed, total, "bytes")
                    report("Finishing Save")
                report("Saved", completed, completed, "bytes")
            return {"ok": True, "path": str(dest), "info": info}
        except Exception as e:
            report("Download Failed")
            return {"ok": False, "error": str(e)}

    # ---- reveal a saved file in Explorer (folder opens with the file selected) ----
    def reveal(self, path):
        try:
            import subprocess as _sp
            _sp.Popen(["explorer", "/select,", str(path)])   # explorer returns 1 even on success
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def main():
    global _window
    # Single instance: if the app is already running (e.g. minimized to the tray), tell it to show its
    # window and exit — clicking the desktop icon reopens the EXISTING one instead of a second copy.
    own_instance = _singleton_check()
    _release_startup_code_guard()
    if not own_instance:
        os._exit(0)
    threading.Thread(target=_serve, daemon=True).start()
    base = f"http://{HOST}:{PORT}/"

    import webview
    # Frameless — open the window ALREADY at the full work-area size so it never flashes small before
    # filling the screen. create_window wants LOGICAL (DIP) px; earlier we passed PHYSICAL px, which on a
    # scaled display (e.g. 150%) came out the wrong size (small, offset) until _fill_work_area corrected it.
    try:
        _ix, _iy, _iw, _ih = _logical_work_rect()
    except Exception:
        _ix, _iy, _iw, _ih = 0, 0, 1280, 800
    _cw_kw = dict(
        html=SPLASH_HTML,
        frameless=True,
        easy_drag=False,                 # app.js title-bar pointer handling shares the native geometry bridge
        background_color="#08090a",      # anthracite from the very first frame: the app opens on the
                                         # sign-in / project picker, which belongs to no project and so
                                         # wears no project colour. Green here flashed for a beat first.
        width=_iw, height=_ih,           # full-screen (logical px) from the first frame → no small-window flash
        x=_ix, y=_iy,                    # open AT the work-area origin, full size (no centered/offset flash)
        min_size=(1000, 650),
        js_api=DesktopApi(),
    )
    try:
        _window = webview.create_window("AI Dashboard", **_cw_kw)
    except TypeError:
        _cw_kw.pop("x", None); _cw_kw.pop("y", None)   # older pywebview without x/y → open centered as before
        _window = webview.create_window("AI Dashboard", **_cw_kw)

    # Correct the initial size only until the user takes control of the window.
    for _ev in ("shown", "loaded"):
        try:
            getattr(_window.events, _ev).__iadd__(_snap_startup)
        except Exception:
            pass

    # Alt+F4 / taskbar "Close window" while the tray is active → hide to tray instead of quitting.
    # Returning False cancels the close (pywebview). Only tray → Exit sets _quitting and lets it through.
    def _on_closing():
        _stop_windows_dictation()
        global _window_user_sized
        _window_user_sized = True
        if _quitting["v"] or _tray is None:
            return True
        try: _window.hide()
        except Exception: pass
        return False
    try:
        _window.events.closing += _on_closing
    except Exception:
        pass

    _loaded = {"v": False}
    def _watchdog():
        # Fail-safe: if the app page never loads (WebView2 / server stall left a blank green splash
        # that couldn't be closed), force the app in after a while so the user is never stuck.
        time.sleep(35)
        if not _loaded["v"]:
            try:
                _window.load_url(base); _loaded["v"] = True
                _snap_startup(); _enable_taskbar_minimize()
            except Exception:
                pass
    def _boot():
        threading.Thread(target=_watchdog, daemon=True).start()
        for _ in range(60):              # wait for the (hidden) window handle to exist
            if _hwnd():
                break
            time.sleep(0.05)
        _snap_startup()
        _enable_taskbar_minimize()       # taskbar-icon click toggles minimize/restore (smooth)
        # Update BEFORE opening the app — the user never sees the old version if a newer one exists.
        if _PACKAGED:
            remote = _pending_version()
            if remote:
                try:
                    _window.run_js("var p=document.querySelector('p'); if(p){p.textContent='Downloading update…';}")
                except Exception:
                    pass
                if _download_update(remote):
                    time.sleep(0.5)      # let the splash text show
                    if _relaunch():      # a failed, rolled-back update leaves the existing version usable
                        return
        _wait_until_up(base, timeout=30)
        _window.load_url(base)           # splash → app
        _loaded["v"] = True              # tell the watchdog the app is up
        # WIN10 GREEN-SCREEN FIX: some WebView2 builds LOAD the page (200 in the log) but defer PAINTING it until the
        # window is brought to the FOREGROUND — the user was stuck on the green splash until they clicked the tray
        # (which foregrounds it and makes WebView2 finally render). Do that automatically here: bring the window to
        # the front a few times over the first seconds (SW_RESTORE + SetForegroundWindow, exactly what the tray
        # "Show" does). This is a no-op on a PC that already renders on first load (foregrounding an already-front
        # window does nothing), so it can't disturb the working machine.
        def _force_paint():
            for _w in (0.6, 1.0, 1.5, 2.5):
                time.sleep(_w)
                if _window_user_sized:
                    return
                try:
                    import ctypes
                    hwnd = _hwnd()
                    if hwnd:
                        ctypes.windll.user32.ShowWindow(hwnd, 9)          # SW_RESTORE
                        ctypes.windll.user32.SetForegroundWindow(hwnd)
                except Exception:
                    pass
        threading.Thread(target=_force_paint, daemon=True).start()
        # Size/position the window FIRST (after an update it can land small) BEFORE anything overlays it,
        # so the "what's new" notes never appear over a half-size window that then jumps to full-screen.
        _snap_startup(); _enable_taskbar_minimize()
        for _d in (0.05, 0.1, 0.15, 0.25, 0.35, 0.6, 1.0, 1.5):
            time.sleep(_d)
            _snap_startup()
            _enable_taskbar_minimize()
        if _PACKAGED:                    # first launch after an update → show "what's new" notes (window is full now)
            js = _update_notes_js()
            if js:
                try:
                    _window.run_js(js)
                except Exception:
                    pass
        # System tray (near the clock). Start it and only COMMIT `_tray` once the icon truly appears, so
        # the close button never hides to a tray that isn't there. Any failure → app quits on close as before.
        global _tray
        try:
            _t = _Tray(_HERE / "vsllogo.ico", on_show=_tray_show, on_exit=_tray_exit)
            _t.start()
            for _ in range(30):
                if _t._added:
                    _tray = _t
                    break
                time.sleep(0.1)
        except Exception:
            _tray = None
        # listen for a second launch (desktop icon while we're in the tray) → show this window
        if _show_event:
            threading.Thread(target=_show_listener, daemon=True).start()

    # private_mode=False + a fixed storage_path so cookies (login session) + localStorage (zoom,
    # last project, …) persist across restarts.
    try:
        os.makedirs(STORAGE_PATH, exist_ok=True)
    except Exception:
        pass
    _kw = {"private_mode": False, "storage_path": STORAGE_PATH}
    _icon = _HERE / "vsllogo.ico"          # window + taskbar icon (replaces the Python logo)
    if _icon.exists():
        _kw["icon"] = str(_icon)
    webview.start(_boot, **_kw)


if __name__ == "__main__":
    main()
