"""Scene-relative effect edits shared by Assemble, rendering and XML export."""
import math
import re

FPS = 60


def normalize(value):
    if not isinstance(value, dict):
        return {}
    out = {}
    for key, edit in list(value.items())[:64]:
        if not isinstance(key, str) or not re.fullmatch(r'(?:effect[12]|dust|grain|filmgrain|atmo-(?:fog|rain|snow|embers)|plate-\d{1,3})', key) or not isinstance(edit, dict):
            continue
        row = {}
        for field in ('in', 'out', 'fade_in', 'fade_out'):
            if field not in edit or isinstance(edit[field], bool):
                continue
            v = number(edit[field], None)
            if v is not None:
                row[field] = max(0, min(1 if field in ('in', 'out') else 60, v))
        if type(edit.get('hidden')) is bool:
            row['hidden'] = edit['hidden']
        if row:
            out[key] = row
    return out


def number(value, fallback):
    try:
        value = float(value)
        return value if math.isfinite(value) else fallback
    except (TypeError, ValueError):
        return fallback


def window(scene, key, scene_start, scene_end, base):
    """Keep automatic windows until this particular layer is explicitly edited."""
    first, last = round(scene_start * FPS), round(scene_end * FPS)
    span = last - first
    if span <= 0:
        return None
    out = dict(base, key=key, scene_uid=scene.get('uid'), scene_id=scene.get('id'),
               base_start=base['start'], base_end=base['end'],
               base_fade_in=base.get('fade_in', 0), base_fade_out=base.get('fade_out', 0))
    edits = scene.get('effect_windows')
    edit = edits.get(key) if isinstance(edits, dict) else None
    if not isinstance(edit, dict):
        return out
    if edit.get('hidden') is True:
        return None
    a = max(0, min(1, number(edit.get('in'), (base['start'] * FPS - first) / span)))
    b = max(0, min(1, number(edit.get('out'), (base['end'] * FPS - first) / span)))
    start = min(last - 1, first + round(span * a))
    end = min(last, max(start + 1, first + round(span * b)))
    out.update(start=start / FPS, end=end / FPS)
    for field in ('fade_in', 'fade_out'):
        out[field] = min((end - start) // 2, round(max(0, number(edit.get(field), base.get(field, 0))) * FPS)) / FPS
    return out


def envelope(spec, time):
    if time < spec['start'] or time > spec['end']:
        return 0
    fi, fo = spec.get('fade_in', 0), spec.get('fade_out', 0)
    return max(0, min(1, (time - spec['start']) / fi if fi else 1,
                      (spec['end'] - time) / fo if fo else 1))


def opacity_points(spec, chunk_start, chunk_end, fps=FPS):
    """A repeated source clip continues one envelope, without restarting each loop."""
    if not spec.get('fade_in') and not spec.get('fade_out'):
        return None
    times = {chunk_start, chunk_end}
    times.update(t for t in (spec['start'] + spec.get('fade_in', 0),
                            spec['end'] - spec.get('fade_out', 0)) if chunk_start < t < chunk_end)
    return [(round((t - chunk_start) * fps), spec['level'] * 100 * envelope(spec, t)) for t in sorted(times)]


def fade_expression(spec):
    """FFmpeg blend's T is the global output clock, just like the preview clock."""
    terms = ['1']
    if spec.get('fade_in'):
        terms.append(f"(T-{spec['start']:.8f})/{spec['fade_in']:.8f}")
    if spec.get('fade_out'):
        terms.append(f"({spec['end']:.8f}-T)/{spec['fade_out']:.8f}")
    result = terms[0]
    for term in terms[1:]:
        result = f'min({result},{term})'
    return f'max(0,{result})'
