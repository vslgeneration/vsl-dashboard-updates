"""Render native XML icon keyframes with the same frame clock and artwork."""
from pathlib import Path
import hashlib,json,math,xml.etree.ElementTree as ET


def _curve(parameter,default=0):
    if parameter is None:return [(0,default)]
    def value(node):
        if node is None:return default
        if node.find('horiz') is not None:return (float(node.findtext('horiz')),float(node.findtext('vert')))
        return float(node.text or default)
    points=[(int(k.findtext('when')),value(k.find('value'))) for k in parameter.findall('keyframe')]
    return points or [(0,value(parameter.find('value')))]


def from_xml(xml):
    root=ET.fromstring(xml);params={p.findtext('parameterid'):p for p in root.findall('./filter/effect/parameter')}
    return dict(start=int(root.findtext('start')),end=int(root.findtext('end')),
        scale=_curve(params.get('scale'),100),rotation=_curve(params.get('rotation'),0),
        center=_curve(params.get('center'),(0.,0.)),opacity=_curve(params.get('opacity'),100),
        blend=root.findtext('compositemode') or 'normal')


def value_at(points,frame):
    if frame<=points[0][0]:return points[0][1]
    for (a,x),(b,y) in zip(points,points[1:]):
        if frame<=b:
            f=(frame-a)/max(1,b-a)
            if isinstance(x,(tuple,list)):return tuple(v+(w-v)*f for v,w in zip(x,y))
            return x+(y-x)*f
    return points[-1][1]


def expression(points,var='n',component=None):
    points=[(a,b[component] if component is not None else b) for a,b in points]
    expr=f'{points[-1][1]:.10f}'
    for (a,x),(b,y) in reversed(list(zip(points,points[1:]))):
        linear=f'({x:.10f}+({y-x:.10f})*clip(({var}-{a})/{max(1,b-a)},0,1))'
        expr=f'if(lt({var},{b}),{linear},{expr})'
    return expr


def _crop_source(path,flip,workdir):
    from PIL import Image,ImageOps
    path=Path(path);stamp=path.stat()
    key=hashlib.sha256(json.dumps([str(path.resolve()),stamp.st_size,stamp.st_mtime_ns,flip,'xml-motion-v1']).encode()).hexdigest()[:24]
    out=Path(workdir)/('icon_motion_'+key+'.png')
    with Image.open(path) as source:
        art=source.convert('RGBA');w,h=art.size
        if flip:art=ImageOps.mirror(art)
        box=art.getchannel('A').getbbox()
        if not box:return None
        # Keep the original XML anchor at the exact center of the cropped canvas.
        rx=max(1,math.ceil(max(w/2-box[0],box[2]-w/2)))
        ry=max(1,math.ceil(max(h/2-box[1],box[3]-h/2)))
        if not out.is_file():art.crop((w//2-rx,h//2-ry,w//2+rx,h//2+ry)).save(out)
    return out,2*rx,2*ry


def static_specs(kind,ix,iy,size,rot,flip,hue,start,end,scene_end,workdir,icon_dir,canvas,fps):
    """Use the XML emitter itself for pop, jab, sway, ripple and sparkle curves."""
    import premiere_export as pe
    w,h=canvas;fps=pe.FPS;native_w,_=pe.project_canvas.size()
    first=pe.frame_number(start,fps);last=pe.frame_number(end,fps);shown=last-first
    cx,cy=ix-.5,iy-.5;events=[]
    def add(xml):events.append(from_xml(xml))
    if kind=='burst':
        ip=Path(icon_dir)/'icon_ring.png'
        if not ip.exists():return []
        ip=pe._icon_hue_file(pe._project_icon_canvas(ip),hue)
        life=pe.frame_number(1.9,fps);stagger=pe.frame_number(.95,fps)
        for t in range(first,last,stagger):
            stop=min(t+life,last)
            if stop-t>=pe.frame_number(.6,fps):
                add(pe._ripple_clipitem('c','m','f',kind,t,stop,s0=round(45*size),s1=round(170*size),cx=cx,cy=cy))
    else:
        filename={'x':'icon_x.png','check':'icon_check.png','arrow':'icon_arrow_flip.png' if flip else 'icon_arrow.png','sparkle':'icon_sparkle.png'}.get(kind,'icon_'+kind+'.png')
        ip=pe.logo_art_file(kind) if pe.is_logo(kind) else Path(icon_dir)/filename
        if not ip.exists():return []
        finished=pe.is_badge(kind) or pe.is_logo(kind)
        ip=pe._badge_fullframe(ip,pe.icon_onscreen(kind)) if finished else pe._project_icon_canvas(ip)
        af,_,_=pe._icon_geom(ip);pw,ph=pe.image_size(ip)
        art=pe.icon_onscreen(kind) if finished and pw==native_w else (1. if finished else af or .2)
        k=max(1. if pe.is_logo(kind) else 10.,100*pe.icon_onscreen(kind)*size*native_w/(art*pw))
        if not finished:ip=pe._icon_hue_file(ip,hue)
        if kind=='sparkle':
            offsets=[(0.,0.),(-.05,-.045),(.055,-.04),(-.04,.05),(.05,.05)]
            for i,t in enumerate(range(first,last,pe.frame_number(.42,fps))):
                stop=min(t+pe.frame_number(.9,fps),last);ox,oy=offsets[i%len(offsets)]
                if stop-t>=pe.frame_number(.5,fps):
                    add(pe._icon_clipitem('c','m','f',kind,t,stop,pe.frame_number(.22,fps),pe.frame_number(.35,fps),composite='screen',cx=cx+ox,cy=cy+oy,scale=k))
        else:
            badge=pe.is_badge(kind);fin=min(pe.frame_number(.5 if badge else .35,fps),max(1,shown//3))
            center=pe._arrow_point_kf(shown,fin,cx,cy,left=flip,rot=rot) if kind=='arrow' else ''
            add(pe._icon_clipitem('c','m','f',kind,first,last,fin,0,center_kf=center,cx=cx,cy=cy,scale=k,rot=rot,
                pop=kind!='arrow',fade_in=not badge,sway=pe.BADGE_SWAY_DEG if badge else 0,sway_sec=pe.BADGE_SWAY_SEC))
    cropped=_crop_source(ip,flip and kind not in ('arrow','burst'),workdir)
    if not cropped:return []
    path,cw,ch=cropped;fade=pe.icon_exit_seconds(first/fps,last/fps,scene_end,kind)
    return [dict(video=False,src=str(path),start=e['start']/fps,end=e['end']/fps,fade_out=0,
                 motion=dict(e,fps=fps,pixel_scale=w/native_w,source_w=cw,source_h=ch,exit_start=(last/fps-fade-e['start']/fps) if fade else None,
                             exit_duration=fade,kind=kind)) for e in events]


def filters(spec,canvas,fps):
    """A bounded transparent plane keeps a constant pivot during per-frame scaling."""
    motion=spec['motion'];w,h=canvas
    clock=motion.get('fps',fps);n=f'(n*{clock}/{fps})';N=f'(N*{clock}/{fps})'
    ratio=motion.get('pixel_scale',1)
    scale=f'({expression(motion["scale"],n)})*{ratio:.12f}';rotation=expression(motion['rotation'],n)
    peak=max(v for _,v in motion['scale'])/100*ratio
    diagonal=max(2,math.ceil(math.hypot(motion['source_w']*peak,motion['source_h']*peak))+4)
    # scale and rotate see the same local frame index; the pad never clips an overshoot.
    chain=(f"fps={fps},format=rgba,scale=w='max(1,round(iw*({scale})/100))':h='max(1,round(ih*({scale})/100))':eval=frame,"
           f"pad={diagonal}:{diagonal}:(ow-iw)/2:(oh-ih)/2:color=black@0:eval=frame,"
           f"rotate='({rotation})*PI/180':ow=iw:oh=ih:c=none,")
    alpha=expression(motion['opacity'],N)+'/100'
    # A zero-scale first frame remains completely transparent, including badges without an opacity fade.
    alpha+=f'*gt(({expression(motion["scale"],N)}),0)'
    if motion.get('exit_duration'):
        alpha+=f'*clip(({motion["exit_start"]+motion["exit_duration"]:.10f}-T)/{motion["exit_duration"]:.10f},0,1)'
    chain+=f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*({alpha})',"
    frame=f'((t-{spec["start"]:.10f})*{clock})'
    x=f'({w}*(0.5+({expression(motion["center"],frame,0)}))-{diagonal}/2)'
    y=f'({h}*(0.5+({expression(motion["center"],frame,1)}))-{diagonal}/2)'
    return chain,x,y
