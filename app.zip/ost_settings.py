"""Per-account generation options, shared only within a named project group."""
IN = ('none','popup','fade','slide-left','slide-top','slide-bottom','slide-right')
OUT = ('none','fade','pop','slide-left','slide-right','slide-top','slide-bottom')

def options(value=None):
    v=value if isinstance(value,dict) else {}
    def number(k,d,lo,hi):
        try:return min(hi,max(lo,int(v.get(k,d))))
        except (ValueError,TypeError):return d
    def animations(k,allowed):
        rows=v.get(k)
        if not isinstance(rows,list): return ['fade']
        if not rows or all(x=='none' for x in rows): return []
        return list(dict.fromkeys(x for x in rows if isinstance(x,str) and x in allowed and x!='none')) or ['fade']
    return dict(max_chars=number('max_chars',17,6,40),max_lines=number('max_lines',3,1,3),
        anims=animations('anims',IN),out_anims=animations('out_anims',OUT),
        positive_preset=str(v.get('positive_preset') or '')[:160],negative_preset=str(v.get('negative_preset') or '')[:160])

def scope(project,groups):
    gid=(groups.get('assign') or {}).get(project)
    return 'group:'+gid if gid and any(g.get('id')==gid for g in groups.get('groups') or []) else 'project:'+project
