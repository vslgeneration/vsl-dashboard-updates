"""One paid Grok keyframe task, mapped to immutable narration slots.

Scene UIDs, not display numbers, identify members. Model output is decoded on
the delivery frame clock; frame-exact segments are kept as normal takes.
The complete generated movie is retained too. No concatenated AI generations.
"""
import copy
import hashlib
import json
import math
import os
import subprocess
import time
import uuid
from pathlib import Path
import linked_continuation as continuation
import video_direction
from prompts import VIDEO_STORY_RULES

MODEL = 'grok-video-1-5'
BUSY = ('queued', 'generating')


def resolution_settings(output, mode='native'):
    """Keyframes/last-frame use Grok reference mode, which is capped at 720p."""
    if output in ('480p','720p') and mode == 'native':
        return dict(resolution=output, output_resolution=output, output_mode='native')
    if output == '1080p' and mode == 'upscale':
        return dict(resolution='720p', output_resolution='1080p', output_mode='upscale')
    if output == '1080p':
        raise ValueError('Grok linked images support up to 720p generation. Open Link Images and choose 720p or 1080p output (upscaled from 720p). No new video request was sent.')
    raise ValueError('Choose 480p, 720p, or 1080p output upscaled from 720p in Link Images.')


def validate_provider_payload(body):
    if body.get('resolution') not in ('480p','720p'):
        raise ValueError('Grok keyframes and last-frame inputs support up to 720p generation. Choose a supported quality in Link Images.')
    if not 1 <= body.get('duration',0) <= 15:
        raise ValueError('Each linked generation must last 1–15 seconds.')
    anchors=body.get('keyframes') or []
    stamps=[k.get('timestamp_s') for k in anchors]
    if len(stamps)>4 or any(not isinstance(t,(int,float)) or not 0<t<body['duration'] for t in stamps):
        raise ValueError('Invalid linked-image keyframe timing.')
    if any(b-a < 1/3-1e-8 for a,b in zip(stamps,stamps[1:])):
        raise ValueError('Linked-image keyframes must be at least one third of a second apart.')
    return body


def output_filter(p):
    if p.get('output_mode') != 'upscale': return ''
    a,b=map(int,p['aspect'].split(':'))
    if a<=0 or b<=0: raise ValueError('Invalid linked-video output aspect ratio.')
    scale=1080/min(a,b); w=2*round(a*scale/2); h=2*round(b*scale/2)
    if max(w,h)>8192: raise ValueError('Linked-video output aspect ratio is too wide.')
    # Uniform scaling + a tiny edge crop for rounded provider dimensions; never stretch.
    return f',scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def motion_intent(link):
    value = link.get('motion_intent', '')
    if not isinstance(value, str) or len(value) > 800:
        raise ValueError('Linked motion direction must be text of at most 800 characters.')
    return value.strip()


def identity_rule(p):
    if p.get('motion_intent'):
        return ('Follow the explicit user motion intent below. A requested transformation between supplied '
                'reference states is intentional; do not replace it with a dissolve. Change only the '
                'specified subjects or structures, preserve panel layout, and avoid accidental distortion. '
                'USER MOTION INTENT: ' + p['motion_intent'] + '\n')
    return ('Preserve identities by default. No unrequested morphing or melting of people or products. '
            'Only a transformation explicitly specified in the motion direction may change a supplied '
            'subject into its other supplied reference state. ')


def group(scene):
    value = scene.get('video_link')
    return value if isinstance(value, dict) and value.get('id') else None


def members(doc, link):
    by_uid = {s.get('uid'): s for s in doc.get('scenes', [])}
    uids = link.get('scene_uids', [])
    if not 2 <= len(uids) <= 5 or len(set(uids)) != len(uids) or any(u not in by_uid for u in uids):
        raise ValueError('Linked scenes changed. Open Link Images and select them again.')
    return [by_uid[u] for u in uids]


def clock(g, doc, d):
    """Use the identical acoustic boundaries and quantizer as Assemble/XML."""
    pe = g['premiere_export']
    srt = g['_find_srt'](d)
    vo = g['_normalized_vo'](d)
    if not srt or not vo or g['_vo_is_stale'](d):
        raise ValueError('Generate subtitles from the current voice-over before linking images. Measured sentence timing is required.')
    words = pe.load_word_tsv(g['_subtitle_dir'](d))
    if not words:
        raise ValueError('Measured word timing is missing. Generate subtitles from the voice-over first.')
    cues = pe.parse_srt(srt.read_text(encoding='utf-8', errors='ignore'))
    if not cues:
        raise ValueError('The current subtitle timing is empty.')
    scenes = doc.get('scenes', [])
    total = max(pe.audio_duration(vo) or 0, cues[-1]['end'])
    starts = pe.word_scene_starts(scenes, words)
    ranges, included = pe.scene_time_ranges(scenes, cues, total, starts)
    fps = pe.FPS
    return {s['uid']: (round(pe.frame_time(a, fps) * fps), round(pe.frame_time(b, fps) * fps))
            for s, (a, b), inc in zip(scenes, ranges, included) if inc and b > a}


def plan(g, doc, d, link):
    scenes = members(doc, link)
    ordered = [s['uid'] for s in doc['scenes'] if s['uid'] in link['scene_uids']]
    if ordered != link['scene_uids']:
        raise ValueError('Scene order changed. Relink the images to the current sentence order.')
    positions = [i for i,s in enumerate(doc['scenes']) if s['uid'] in link['scene_uids']]
    if any(b != a + 1 for a,b in zip(positions,positions[1:])):
        raise ValueError('Select consecutive scenes without gaps. Each image must follow the preceding sentence.')
    inputs = link.get('image_uids', ordered)
    if sorted(inputs) != sorted(ordered):
        raise ValueError('Each selected image must be assigned to exactly one sentence.')
    timing = clock(g, doc, d)
    by_uid = {s['uid']: s for s in scenes}
    fps = g['premiere_export'].FPS
    slots, frames, aspects = [], 0, []
    for sc, image_uid in zip(scenes, inputs):
        if g['speaker_package'].locked(sc) or g['speaker_package'].pending_text(sc) or g['stock_media'].has_stock_video(sc):
            raise ValueError('Link Images is for approved AI images. Spokesperson and stock videos cannot be included.')
        image_sc = by_uid[image_uid]
        im = image_sc.get('image') or {}
        rel = im.get('approved_file') or im.get('file')
        path = (d / (rel or '')).resolve()
        if not image_sc.get('approved') or not rel or not path.is_relative_to(d.resolve()) or not path.is_file():
            raise ValueError('Approve every selected image before linking.')
        if sc['uid'] not in timing:
            raise ValueError(f"Scene #{sc['id']} has no measured narration slot. Correct its sentence timing first.")
        start, end = timing[sc['uid']]
        if slots and start != slots[-1]['end_frame']:
            raise ValueError('These scenes are not consecutive on the voice-over timeline. Check their sentence timing before linking.')
        length = end - start
        if length / fps < 1 / 3:
            raise ValueError('Each linked sentence must last at least one third of a second for Grok keyframes.')
        stat = path.stat()
        aspect = g['source_image_aspect'](path)
        aspects.append(aspect)
        slots.append(dict(uid=sc['uid'], id=sc['id'], image_uid=image_uid, image_id=image_sc['id'],
                          image=rel, image_stamp=[stat.st_size, stat.st_mtime_ns],
                          own_image=(sc.get('image') or {}).get('approved_file') or (sc.get('image') or {}).get('file'),
                          vo=sc.get('vo') or '', start_frame=start, end_frame=end,
                          offset_frame=frames, frames=length, camera_locked=bool(sc.get('video_cam_lock')),
                          image_prompt=image_sc.get('prompt') or ''))
        frames += length
    seconds = frames / fps
    duration = math.ceil(seconds - 1e-8)
    if len(set(aspects)) != 1:
        raise ValueError('Linked images must have the same aspect ratio. Their proportions will not be stretched.')
    quality = resolution_settings(scenes[0].get('video_res') or '720p',link.get('output_mode','native'))
    out = dict(id=link['id'], slots=slots, fps=fps, frames=frames, seconds=seconds,
               duration=duration, resolution=quality['resolution'], aspect=aspects[0])
    intent = motion_intent(link)
    if intent: out['motion_intent'] = intent
    # UI numbering may change without changing the linked visual or sentence.
    stamp = copy.deepcopy(out)
    for slot in stamp['slots']:
        slot.pop('id'); slot.pop('image_id')
    if seconds > 15: stamp['continuation_version'] = 1
    if quality['output_mode']=='upscale': stamp['output_mode']='upscale1080'
    out['signature'] = digest(stamp)
    out.update(quality)
    out.update(continuation.schedule(out))
    return out


def timing_prompt(p):
    rows = []
    for i, slot in enumerate(p['slots']):
        a = slot['offset_frame'] / p['fps']; b = (slot['offset_frame'] + slot['frames']) / p['fps']
        rows.append(f"Image {i+1}: {a:.6f}s–{b:.6f}s. Arrive at this image at {a:.6f}s; keep its subjects and situation readable throughout this interval.")
    return ('Generate ONE coherent moving video following the supplied frame schedule. '
            'The first frame is image 1. Each timed keyframe starts its assigned narration interval; '
            'the last-frame image is also pinned at the START of the final interval. '
            'Establish each reference state at its scheduled arrival; a requested connecting transformation may lead into that arrival. '
            'Make each connection smooth and continuous: no hard cuts, sudden jumps, flashes or black frames. '
            + identity_rule(p) +
            'Do not add text, subtitles, logos, narration, music or dialogue. Do not animate people speaking to camera. '
            'Keep ordinary physical motion, product counts and image composition outside the requested change. '
            'Hold the final situation through any fractional-second padding.\n' + '\n'.join(rows))


def final_prompt(p, motion):
    text = video_direction.realtime(timing_prompt(p) + '\n\nMOTION DIRECTION:\n' + (motion or '').strip())
    if len(text) > 4096:
        raise ValueError('The linked video prompt is too long for Grok (4096 characters). Shorten the motion description; timing instructions are kept.')
    return text


def payload(p, urls, motion):
    if len(urls) != len(p['slots']):
        raise ValueError('Every linked image must upload successfully before a video request is sent.')
    return validate_provider_payload(dict(prompt=final_prompt(p, motion), first_frame_url=urls[0], last_frame_url=urls[-1],
                keyframes=[dict(url=url, timestamp_s=slot['offset_frame'] / p['fps'])
                           for slot, url in zip(p['slots'][1:], urls[1:])],
                duration=p['duration'], resolution=p['resolution'], enable_audio=False))


def prompt_targets(doc, targets):
    out, seen = [], set()
    for sc in targets:
        link = group(sc)
        key = link['id'] if link else sc['uid']
        if key in seen: continue
        seen.add(key)
        out.append(members(doc, link)[0] if link else sc)
    return out


def prompt_for(g, sc, project, doc):
    d, _ = g['proj_dir'](project)
    p = plan(g, doc, d, group(sc))
    instructions = ('Write only an English motion direction, at most 1800 characters, for ONE Grok keyframe video. '
                    'Inspect ALL supplied images in their given order. Read the script context and the timed narration slots. '
                    'Invent appropriate natural movement and transitions that connect these actual images, without replacing them. '
                    'Each image must be established at its assigned start, then remain meaningful for its full sentence. '
                    'Do not paraphrase/reorder the narration or change the timing. No voice generation, captions, slow motion, '
                    'new characters, talking to camera or added products. Camera-locked slots must remain locked. '
                    'Preserve identities unless the explicit user motion intent requests a transformation between supplied states. '
                    'Connect the images with smooth continuous motion, no abrupt cuts, flashes or black frames. '
                    'For a multi-part plan, continue the same action across each handoff within its existing scene. '
                    'Do not invent a new shot at a handoff. Keep a compatible camera direction and movement. '
                    'Scientific changes must follow the narrated mechanism, not arbitrary transformations. '
                    'Use ordinary real-world speed; restrained action means small amplitude, not stretched time.\n'
                    + VIDEO_STORY_RULES + '\nLINKED-IMAGE EXCEPTION: ' + identity_rule(p)
                    + 'A requested age/state transformation follows the timed anchors, not biological elapsed time. '
                    'Ordinary breathing and blinking remain real-time. Do not describe the requested transformation as an accidental identity change.')
    context = dict(slots=p['slots'], duration=p['seconds'], parts=p['chunks'])
    by_uid={s['uid']:s for s in doc['scenes']}
    paths = [video_direction.source_image(d,by_uid[x['image_uid']]) for x in p['slots']]
    user=json.dumps(context, ensure_ascii=False)+video_direction.context(doc,members(doc,group(sc)))
    text = video_direction.generate(lambda u:g['_claude_vision'](instructions,u,paths[0],extra=paths[1:]),user)
    final_prompt(p, text)  # reject, never silently truncate the director's intent
    return text


def prompt_updates(g, doc, project, sc, text=None, error=None):
    link = group(sc)
    targets = members(doc, link) if link else [sc]
    stamp = None
    if link and not error:
        stamp = plan(g, doc, g['proj_dir'](project)[0], link)['signature']
    out = {}
    for s in targets:
        out[s['uid']] = {'video_prompt_error': str(error)[:500]} if error else dict(
            video_desc=text, video_prompt='', video_prompt_error=None, video_dur=sc.get('video_dur'))
        if link and not error: out[s['uid']]['video_link_prompt_stamp'] = stamp
    return out


def fail(doc, owner, message, d=None, provider_failed=False):
    pending = (owner.get('video') or {}).get('pending_link')
    token = (pending or {}).get('token')
    chained = pending and continuation.multiple(pending['plan'])
    # Retain diagnostics even after clearing an active task; never resubmit here.
    diagnostic = dict(task_id=(owner.get('video') or {}).get('taskId'), message=str(message),
                      provider_failed=bool(provider_failed), at=time.time(),
                      signature=((pending or {}).get('plan') or {}).get('signature'))
    if chained and d is not None:
        old = continuation.read(d, pending)
        if not old or old['state'] not in ('submitting','unknown','failed'):
            continuation.checkpoint(d, pending, 'failed' if provider_failed else 'error',
                                    task=owner['video'].get('taskId'), error=str(message))
    for s in doc.get('scenes', []):
        v = s.get('video') or {}
        if s is owner or (token and v.get('link_wait_token') == token):
            v['last_link_failure'] = copy.deepcopy(diagnostic)
            v.update(status='error', error=str(message), taskId=None)
            if not chained:
                v.pop('link_wait_token', None); v.pop('pending_link', None)


def queue(g, doc, d, targets):
    """Validate all selected groups before any queue is modified."""
    pending, seen = [], set()
    for sc in targets:
        link = group(sc)
        if not link or link['id'] in seen: continue
        seen.add(link['id']); ms = members(doc, link)
        if any((x.get('video') or {}).get('status') in BUSY for x in ms): continue
        p = plan(g, doc, d, link)
        motion = (sc.get('video_prompt') or sc.get('video_desc') or '').strip()
        if any(x.get('video_model') != MODEL for x in ms):
            raise ValueError('Linked images require Grok 1.5. Open Link Images to restore the linked model.')
        if not motion or any(x.get('video_prompt_error') or x.get('video_link_prompt_stamp') != p['signature'] for x in ms):
            raise ValueError('Generate the shared prompt again: linked images, sentence timing or settings changed.')
        if any((x.get('video_prompt') or x.get('video_desc') or '').strip() != motion for x in ms):
            raise ValueError('Linked scenes need the same motion prompt. Generate Prompt again to synchronize them.')
        final_prompt(p, motion)
        resume = None
        if continuation.multiple(p):
            for chunk in p['chunks']:
                continuation.payload(p, chunk, ['image']*len(ms), 'bridge' if chunk['index'] else None, motion)
            previous = ms[0]['video'].get('pending_link') or ms[0]['video'].get('resume_link')
            if previous and previous['plan']['signature']==p['signature'] and previous['motion']==motion:
                saved = continuation.read(d,previous)
                if saved and saved['state'] in ('unknown','submitting'):
                    raise ValueError('The preceding submission has no confirmed task ID. Check Kie before generating again; no duplicate was sent.')
                if saved and saved['state'] != 'complete': resume = saved
        pending.append((ms, p, motion, resume))
    for ms, p, motion, resume in pending:
        token = resume['pending']['token'] if resume else uuid.uuid4().hex
        for s in ms:
            g['_enqueue_job'](s, 'video')
            s['video']['link_wait_token'] = token
            s['video'].pop('resume_link',None)
        state = copy.deepcopy(resume['pending']) if resume else dict(plan=p, motion=motion, token=token)
        ms[0]['video']['pending_link'] = state
        if continuation.multiple(p):
            if resume and resume.get('task') and resume['state'] in ('generating','error','cancelled'):
                continuation.checkpoint(d,state,'generating',task=resume['task'])
                ms[0]['video'].update(status='generating',taskId=resume['task'],api='jobs',gen_started=time.time())
            else: continuation.checkpoint(d,state,'queued')
            continuation.progress(doc,state)
    return [s for s in targets if not group(s)]


def submit(g, sc, d, safe, doc):
    if not group(sc): return False
    v = sc.setdefault('video', {})
    pending = v.get('pending_link')
    if not pending:
        token = v.get('link_wait_token')
        owner = next((x for x in doc['scenes'] if ((x.get('video') or {}).get('pending_link') or {}).get('token') == token), None) if token else None
        if not owner:
            v.update(status='error', error='Start this linked video with Generate Video after generating its shared prompt.')
            v.pop('link_wait_token', None)
        return True
    try:
        if continuation.multiple(pending['plan']):
            continuation.submit(g,doc,d,safe,sc,pending)
            return True
        p = plan(g, doc, d, group(sc))
        if p['signature'] != pending['plan']['signature']:
            raise ValueError('Linked video inputs changed while queued. Generate its shared prompt again.')
        urls = [g['cloudinary_upload'](d / slot['image'], f"{safe}/linked/{pending['token']}/{i}")
                for i, slot in enumerate(p['slots'])]
        if not all(urls): raise ValueError('A linked image could not be uploaded. No video generation was sent.')
        tid, error = g['kie_create']('grok-imagine-video-1-5-preview', payload(p, urls, pending['motion']))
        if not tid: raise ValueError(error or 'Grok did not return a task ID.')
        v.update(status='generating', taskId=tid, api='jobs', gen_started=time.time(), error=None)
    except Exception as error:
        fail(doc, sc, error, d)
    return True


def prepare_download(g,d,v,tmp):
    if continuation.multiple(v['pending_link']['plan']):
        return continuation.prepare(g,d,v,tmp)
    return dict(ok=True,tmp=tmp,linked_parts=prepare_result(g,d,v,tmp))


def _run(args):
    result = subprocess.run(args, capture_output=True, timeout=180,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise ValueError('Could not prepare the linked video at its narration boundaries: ' + result.stderr.decode('utf-8', errors='replace')[-400:])


def prepare_result(g, d, v, tmp):
    """Run outside the project lock; no source footage/audio is altered."""
    p = v['pending_link']['plan']; made = []
    try:
        actual = g['_shared_video_duration'](d / tmp)
        if actual is None or actual + .5 / p['fps'] < p['seconds']:
            raise ValueError('Grok returned a video shorter than the linked narration. Existing takes were kept; no automatic regeneration was sent.')
        outputs = []
        for slot in p['slots']:
            rel = 'videos/_linked_' + uuid.uuid4().hex + '.mp4'
            made.append(rel)
            a, b = slot['offset_frame'], slot['offset_frame'] + slot['frames']
            # fps before trim uses one clock for all windows. Audio comes only
            # from the existing voice-over, never from Grok's generated track.
            _run(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-filter_threads', '1',
                  '-i', str(d / tmp), '-an', '-vf', f"fps={p['fps']},trim=start_frame={a}:end_frame={b},setpts=PTS-STARTPTS"+output_filter(p),
                  '-c:v', 'libx264', '-crf', '18', '-preset', 'fast', '-pix_fmt', 'yuv420p',
                  '-threads', '2', '-movflags', '+faststart', '-y', str(d / rel)])
            duration = g['_shared_video_duration'](d / rel)
            if duration is None or abs(duration * p['fps'] - slot['frames']) > 1:
                raise ValueError('The linked video segment did not preserve its narration frame count.')
            outputs.append(dict(uid=slot['uid'], tmp=rel))
        # The provider accepts whole seconds; the visible movie must end on the
        # exact narration frame, just like the per-scene windows. Retain the raw
        # provider take separately rather than exposing its padding as Full video.
        master = 'videos/_linked_master_' + uuid.uuid4().hex + '.mp4'; made.append(master)
        _run(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-filter_threads', '1',
              '-i', str(d / tmp), '-an', '-vf', f"fps={p['fps']},trim=end_frame={p['frames']},setpts=PTS-STARTPTS"+output_filter(p),
              '-c:v', 'libx264', '-crf', '18', '-preset', 'fast', '-pix_fmt', 'yuv420p',
              '-threads', '2', '-movflags', '+faststart', '-y', str(d / master)])
        length = g['_shared_video_duration'](d / master)
        if length is None or abs(length * p['fps'] - p['frames']) > .1:
            raise ValueError('The complete linked video did not preserve the voice-over frame count.')
        outputs[0]['master_tmp'] = master
        return outputs
    except Exception:
        for rel in made: (d / rel).unlink(missing_ok=True)
        raise


def cleanup(d, update):
    continuation.cleanup(d,update)
    for item in update.get('linked_parts') or []:
        if item.get('tmp'): (d / item['tmp']).unlink(missing_ok=True)
        if item.get('master_tmp'): (d / item['master_tmp']).unlink(missing_ok=True)


def land(g, doc, d, sc, update, landed):
    v = sc.get('video') or {}; pending = v.get('pending_link')
    if not pending: return False
    if not update['ok']:
        fail(doc, sc, update['error'], d, update.get('provider_failed',False)); return True
    moved = []; original_videos = None
    try:
        p = plan(g, doc, d, group(sc))
        if p['signature'] != pending['plan']['signature']:
            raise ValueError('Linked images or narration changed during generation. Existing takes were kept.')
        ms = members(doc, group(sc))
        original_videos = {s['uid']:copy.deepcopy(s.get('video') or {}) for s in ms}
        if any((s.get('video') or {}).get('link_wait_token') != pending['token'] for s in ms):
            raise ValueError('One linked scene was changed or cancelled. Existing takes were kept.')
        if continuation.multiple(p):
            index=pending.get('next_chunk',0)
            before_parts=copy.deepcopy(pending.get('completed') or [])
            entry=continuation.land_chunk(d,pending,update,landed)
            if index<len(p['chunks'])-1:
                pending.update(next_chunk=index+1,not_before=time.time()+2)
                continuation.checkpoint(d,pending,'queued')
                # Durable checkpoint owns these now, even if the project save fails.
                for rel in (entry['raw'],entry['clip'],entry['bridge']):
                    if rel in landed: landed.remove(rel)
                v.update(status='queued',taskId=None,error=None)
                continuation.progress(doc,pending)
                return True
            update['linked_originals']=[x['raw'] for x in pending['completed']]
            pending['completed']=before_parts  # final download can be recovered from its same task
            continuation.checkpoint(d,pending,'generating',task=v.get('taskId'))
            for rel in (entry['raw'],entry['clip'],entry['bridge']):
                if rel in landed: landed.remove(rel)
        parts = update.get('linked_parts') or []
        if [x['uid'] for x in parts] != [s['uid'] for s in ms]:
            raise ValueError('Incomplete linked video download. Existing takes were kept.')
        master = 'videos/linked_' + pending['token'] + '.mp4'
        original = 'videos/linked_original_' + pending['token'] + '.mp4'
        if not parts[0].get('master_tmp'):
            raise ValueError('The complete linked video is not ready. Existing takes were kept.')
        moves = [(update['tmp'], original), (parts[0]['master_tmp'], master)]
        for s, part in zip(ms, parts):
            moves.append((part['tmp'], g['_new_take_name'](d, s['uid'], s.get('video') or {})))
        for src, dest in moves:
            os.replace(d / src, d / dest); landed.append(dest); moved.append(dest)
        update.pop('tmp'); update['linked_parts'] = []
        for s, slot, (_, rel) in zip(ms, p['slots'], moves[2:]):
            video = s.setdefault('video', {})
            g['_freeze_one_take'](video)
            takes = video.setdefault('versions', [])
            takes.append(rel)
            g['_record_take_source'](video, len(takes)-1, slot['own_image'])
            video.setdefault('linked_takes', {})[rel] = dict(group_id=p['id'], run=pending['token'],
                master=master, original=original, offset_frame=slot['offset_frame'], frames=slot['frames'], fps=p['fps'],
                originals=update.get('linked_originals', [original]), generation_count=p.get('generation_count',1),
                generation_resolution=p['resolution'], output_resolution=p.get('output_resolution',p['resolution']), output_mode=p.get('output_mode','native'),
                vo=slot['vo'], scene_uids=[x['uid'] for x in p['slots']], signature=p['signature'],
                start_frame=slot['start_frame'], end_frame=slot['end_frame'])
            video.update(status='ready', file=rel, current=len(takes)-1, source=slot['own_image'], error=None, taskId=None)
            for field in ('pending_link', 'resume_link', 'link_progress', 'link_wait_token', 'from_video', 'from_scene', 'waiting_for_uid', 'last_error'):
                video.pop(field, None)
        if continuation.multiple(p): continuation.checkpoint(d,pending,'complete',task=update.get('taskId'))
        return True
    except Exception as error:
        if original_videos is not None:
            for s in doc['scenes']:
                if s['uid'] in original_videos: s['video'] = original_videos[s['uid']]
        for rel in moved:
            (d / rel).unlink(missing_ok=True)
            if rel in landed: landed.remove(rel)
        fail(doc, sc, error, d)
        return True


def cancel(doc, sc, d=None):
    token = (sc.get('video') or {}).get('link_wait_token')
    if not token: return False
    for s in doc.get('scenes', []):
        v = s.get('video') or {}
        if v.get('link_wait_token') != token: continue
        pending=v.get('pending_link')
        if pending and continuation.multiple(pending['plan']):
            if d is not None:
                old=continuation.read(d,pending)
                # Never turn an unknown paid submission into a safe-to-retry job.
                if not old or old['state'] not in ('submitting','unknown'):
                    continuation.checkpoint(d,pending,'cancelled',task=v.get('taskId'))
            v['resume_link']=copy.deepcopy(pending)
        v.update(status='ready' if v.get('file') else 'empty', taskId=None, error=None)
        v.pop('pending_link', None); v.pop('link_wait_token', None); v.pop('link_progress',None)
    return True


def validate_timing(scenes, ranges, included, fps):
    for s, (a,b), inc in zip(scenes, ranges, included):
        v = s.get('video') or {}
        rel = v.get('approved_file') if v.get('approved') else None
        meta = (v.get('linked_takes') or {}).get(rel)
        if not meta: continue
        length = round(b*fps)-round(a*fps)
        if not inc or length != meta['frames'] or s.get('vo','') != meta['vo']:
            raise ValueError(f"Linked video in scene #{s.get('id')} was generated for different narration timing. Regenerate its shared prompt and video before export.")


def continuous(left, right):
    def take(s):
        if not s: return None
        if s.get('linked_take'): return s['linked_take']
        v = s.get('video') or {}
        rel = v.get('approved_file') if v.get('approved') else None
        return (v.get('linked_takes') or {}).get(rel)
    a, b = take(left), take(right)
    return bool(a and b and a['run'] == b['run'] and a['offset_frame'] + a['frames'] == b['offset_frame'])


def apply_reviewed_motion(g, project, path):
    """Apply a prepared local correction on reopen, under the normal project locks.

    Busy jobs and newer edits win. This never queues or submits media generation.
    """
    pending = path.parent / '_pending_video_motion_edits.json'
    if not pending.is_file(): return False
    with g['_project_lock'](project), g['_lock']:
        if not pending.is_file(): return False
        review = json.loads(pending.read_text('utf8'))
        if review.get('schema') != 1 or review.get('project') != path.parent.name:
            raise ValueError('Video motion review belongs to another project.')
        changes = review.get('updates')
        if not isinstance(changes,list) or not 1 <= len(changes) <= 5:
            raise ValueError('Video motion review must contain one to five scenes.')
        doc = json.loads(path.read_text('utf8')); edited = copy.deepcopy(doc)
        by_uid = {s['uid']: s for s in edited['scenes']}; seen = set()
        if all(by_uid.get(c.get('uid'))==c.get('after') and isinstance(c.get('after'),dict) for c in changes):
            pending.replace(path.parent/'_applied_video_motion_edits.json')
            return False
        allowed = {'video_desc','video_prompt','video_prompt_error','video_link',
                   'video_link_prompt_stamp','video_model','video_dur','video_res','video'}
        for change in changes:
            uid = change.get('uid'); scene = by_uid.get(uid)
            if scene is None or uid in seen or g['speaker_package'].locked(scene):
                raise ValueError('Unavailable, duplicated or protected scene in video motion review.')
            seen.add(uid)
            if any((scene.get(k) or {}).get('status') in BUSY for k in ('image','video')): return False
            if scene != change.get('before'):
                raise ValueError('A newer scene edit was kept; video motion review was not applied.')
            after = change.get('after')
            if not isinstance(after,dict) or set(scene)-set(after):
                raise ValueError('Video motion review cannot remove scene fields.')
            if {k for k,v in after.items() if scene.get(k)!=v} - allowed:
                raise ValueError('Video motion review cannot change images, words, approvals or other settings.')
            old_video, new_video = scene.get('video') or {}, after.get('video') or {}
            changed_video = {k for k in set(old_video)|set(new_video) if old_video.get(k)!=new_video.get(k)}
            if changed_video-{'status','error','taskId','gen_started','pending_aspect'}:
                raise ValueError('Video motion review cannot change media or take history.')
            if new_video.get('status') not in ('empty','ready','error') or (new_video.get('taskId') and new_video!=old_video):
                raise ValueError('Video motion review cannot start or change an active job.')
            if not isinstance(after.get('video_desc'),str) or not after['video_desc'].strip():
                raise ValueError('Video motion review needs a motion prompt.')
            scene.update(copy.deepcopy(after))
        checked = set()
        for uid in seen:
            scene = by_uid[uid]; link = group(scene)
            if not link or link['id'] in checked: continue
            checked.add(link['id']); ms = members(edited,link)
            if any(s['uid'] not in seen or group(s)!=link for s in ms):
                raise ValueError('Review must update every linked member together.')
            p = plan(g,edited,path.parent,link)
            text = scene.get('video_prompt') or scene['video_desc']
            if any(s.get('video_link_prompt_stamp')!=p['signature'] or (s.get('video_prompt') or s['video_desc'])!=text for s in ms):
                raise ValueError('Reviewed link timing changed; regenerate its motion direction.')
            final_prompt(p,text)
        edited['_revision'] = int(doc.get('_revision',0))+1
        g['_write_atomic'](path,json.dumps(edited,ensure_ascii=False,indent=2),backup=True)
        pending.replace(path.parent/'_applied_video_motion_edits.json')
        return True


def register(g):
    app, request, jsonify = g['app'], g['request'], g['jsonify']

    @app.route('/api/scenes/<project>/video-links/plan', methods=['POST'])
    @app.route('/api/scenes/<project>/video-links', methods=['POST'])
    def save_link(project):
        with g['_project_lock'](project):
            doc = g['load_doc'](project)
            if doc is None: g['abort'](404)
            body = request.get_json(force=True) or {}
            try:
                uids = body.get('uids') or []
                if not isinstance(uids, list) or not all(isinstance(x, str) for x in uids):
                    raise ValueError('Select two to five approved images.')
                selected = [s for s in doc['scenes'] if s['uid'] in uids]
                if len(selected) != len(uids): raise ValueError('Selected scenes changed. Select them again.')
                old = group(selected[0]) if selected else None
                link = dict(id=(old or {}).get('id') or uuid.uuid4().hex,
                            scene_uids=[s['uid'] for s in selected], image_uids=body.get('image_uids') or [s['uid'] for s in selected])
                intent = motion_intent(body if 'motion_intent' in body else (old or {}))
                if intent: link['motion_intent'] = intent
                if any(group(s) and group(s) != old for s in selected):
                    raise ValueError('A selected scene belongs to another link. Unlink it first.')
                if old and old['scene_uids'] != link['scene_uids']:
                    raise ValueError('Unlink the existing group before changing its members.')
                if any((s.get('video') or {}).get('status') in BUSY for s in selected):
                    raise ValueError('Wait for the current video generation before changing its link.')
                d, _ = g['proj_dir'](project)
                resolution = body.get('resolution') or (selected[0].get('video_res') if selected else None) or '1080p'
                mode = body.get('output_mode','native')
                resolution_settings(resolution,mode)
                link['output_mode']=mode
                draft = copy.deepcopy(doc)
                for s in draft['scenes']:
                    if s['uid'] in uids: s['video_res'] = resolution
                p = plan(g, draft, d, link)
                if request.path.endswith('/plan'): return jsonify(plan=p)
                link.update(frames=p['frames'], fps=p['fps'], generation_count=p['generation_count'],
                            generation_resolution=p['resolution'], output_resolution=p['output_resolution'],
                            estimated_credits=p['estimated_credits'], billed_seconds=p['billed_seconds'])
                for s in selected:
                    s.update(video_link=copy.deepcopy(link), video_model=MODEL, video_dur=p['duration'], video_res=p['output_resolution'])
                    s.pop('video_link_prompt_stamp', None)
                g['save_doc'](project, doc)
                return jsonify(doc=doc, plan=p)
            except (ValueError, TypeError, KeyError) as error:
                return jsonify(error=str(error)), 400

    @app.route('/api/scenes/<project>/video-links/remove', methods=['POST'])
    def remove_link(project):
        with g['_project_lock'](project):
            doc = g['load_doc'](project)
            if doc is None: g['abort'](404)
            uid = (request.get_json(force=True) or {}).get('uid')
            sc = next((s for s in doc['scenes'] if s['uid'] == uid), None)
            if not sc or not group(sc): return jsonify(error='The link no longer exists.'), 404
            ms = members(doc, group(sc))
            if any((s.get('video') or {}).get('status') in BUSY for s in ms):
                return jsonify(error='Wait for the linked video to finish before unlinking.'), 409
            for s in ms:
                s.pop('video_link', None); s.pop('video_link_prompt_stamp', None)
            g['save_doc'](project, doc)
            return jsonify(doc=doc)
