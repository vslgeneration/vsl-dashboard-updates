# -*- coding: utf-8 -*-
"""A place for the errors the app deliberately swallows.

Dozens of handlers carry on after a failure on purpose - a missing thumbnail, a cache that would not
delete, a provider blip. That is the right behaviour, but "carry on" used to mean "leave no trace",
and a render that failed on another PC could not be explained afterwards. quiet() appends one line
per swallowed error to <data>/logs/quiet_errors.log. It never raises, and a burst of identical
errors is written once with a count."""
import os
import threading
import time
from pathlib import Path

_LOCK = threading.Lock()
_MAX_BYTES = 2 * 1024 * 1024
_last = {"key": None, "n": 0}


def log_path():
    base = os.environ.get("VSL_DATA_DIR") or str(Path(__file__).resolve().parent)
    return Path(base) / "logs" / "quiet_errors.log"


def quiet(err, where=""):
    """Record a swallowed exception: when, where (the function), what. Safe to call from anywhere."""
    try:
        what = "%s: %s" % (type(err).__name__, str(err)[:400].replace("\n", " "))
        key = "%s | %s" % (where, what)
        with _LOCK:
            if key == _last["key"]:
                _last["n"] += 1          # the same error again: count it, do not repeat it
                return
            p = log_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            if p.exists() and p.stat().st_size > _MAX_BYTES:
                try:
                    os.replace(p, p.with_suffix(".log.1"))
                except OSError:
                    pass
            with open(p, "a", encoding="utf-8") as fh:
                if _last["n"]:
                    fh.write("    (the previous line repeated %d more time%s)\n"
                             % (_last["n"], "" if _last["n"] == 1 else "s"))
                fh.write("%s  %-36s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), where[:36], what))
            _last["key"], _last["n"] = key, 0
    except Exception:
        pass
