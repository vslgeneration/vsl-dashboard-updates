# -*- coding: utf-8 -*-
"""
Pre-publish smoke test. FAST and NETWORK-FREE. Verifies the invariants that, if broken, would ship a
bug live to every other PC (the auto-update is unforgiving). publish_update.py runs this first and
ABORTS the publish if it fails. Run standalone any time:  python smoke_test.py

Checks:
  1. every .py compiles
  2. app.py imports and registers the critical routes
  3. build_image_prompt: RAW mode = ONLY the user's prompt; normal mode = style preset + exactly one "No text."
  4. assemble_image_prompt: RAW returns no continuity ref and flags RAW in its info
  5. localize_prompt: the signage/"write text in <lang>" clause is OFF by default (it would fight "No text.")
  6. STYLE_KEYS / STYLE_PRESETS integrity
  7. api_save_scenes whitelist keeps the fields the UI persists (vo_tr, no_cast, …) and EXCLUDES refs/ref_free (dedicated endpoints)
  8. every api.* fetch URL in app.js maps to a real @app.route (method + path)
"""
import sys, os, re, py_compile, pathlib

# The Git-Bash console is cp1254; make our own prints encoding-proof so the gate can never crash (and
# falsely block a publish) on a stray non-ASCII character in a message.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = pathlib.Path(__file__).resolve().parent
FAILS = []


def check(name, cond, detail=""):
    print(("  ok   " if cond else "  FAIL ") + name + (("  -> " + detail) if (detail and not cond) else ""))
    if not cond:
        FAILS.append(name + ((": " + detail) if detail else ""))


# 1) compile every .py in the dashboard dir
for py in sorted(HERE.glob("*.py")):
    if py.name == "smoke_test.py":
        continue
    try:
        py_compile.compile(str(py), doraise=True)
        print(f"  ok   compile {py.name}")
    except py_compile.PyCompileError as e:
        check(f"compile {py.name}", False, str(e).splitlines()[-1])

# 2) import app + critical routes
sys.path.insert(0, str(HERE))
app = None
try:
    import app as app  # noqa
    rules = {str(r.rule): set(r.methods) for r in app.app.url_map.iter_rules()}
    print(f"  ok   import app ({len(rules)} routes)")
    for path, method in [
        ("/api/scenes/<project>/split", "POST"),
        ("/api/scenes/<project>/genprompt", "POST"),
        ("/api/scenes/<project>/generate", "POST"),
        ("/api/scenes/<project>/generate-video", "POST"),
        ("/api/scenes/<project>/poll", "POST"),
        ("/api/scenes/<project>/<int:sid>/approve", "POST"),
        ("/api/scenes/<project>/<int:sid>/cancel-image", "POST"),
        ("/api/scenes/<project>/<int:sid>/cancel-video", "POST"),
        ("/api/scenes/<project>/<int:sid>/preview-prompt", "GET"),
        ("/api/subtitle/<project>/cancel", "POST"),
        ("/api/projects/<project>", "DELETE"),
        ("/api/trash", "GET"),
        ("/api/trash/<tname>/restore", "POST"),
        ("/api/trash/<tname>", "DELETE"),
        ("/api/scenes/<project>/sync-approved-current", "POST"),
        ("/api/product/<project>", "POST"),
        ("/api/product/<project>/remove", "POST"),
        ("/api/credits/<project>", "GET"),
        ("/api/characters/<project>/<cid>/generate", "POST"),
        ("/api/characters/<project>/<cid>/edit-candidate", "POST"),
        ("/api/characters/<project>/<cid>/use-candidate", "POST"),
        ("/api/characters/<project>/<cid>/discard-candidate", "POST"),
    ]:
        check(f"route {method} {path}", path in rules and method in rules[path])
    # A route accidentally bound to a private _helper (an @app.route decorator landing on the WRONG function —
    # e.g. a helper inserted just under it) silently 500s that endpoint. This bit us on /api/imports (the route
    # got bound to _zip_ready → every Import errored, stuck on "Loading"). Catch the whole class here.
    _helper_routes = [str(r.rule) for r in app.app.url_map.iter_rules()
                      if r.endpoint.startswith("_") and r.endpoint != "static"]
    check("no route bound to a private _helper function", not _helper_routes, ", ".join(_helper_routes))
except Exception as e:
    check("import app", False, repr(e))

# 3-6) prompt-assembly invariants (pure, no network — English prompt so nothing translates)
if app is not None:
    raw_scene = {"id": 1, "no_cast": True, "prompt": "a shiny red sports car on a mountain road", "style": "2d"}
    out_raw = app.build_image_prompt(raw_scene, None)
    check("RAW build_image_prompt = only the user's prompt",
          out_raw == "a shiny red sports car on a mountain road", repr(out_raw[:80]))

    norm_scene = {"id": 2, "prompt": "a woman drinking tea in a kitchen", "style": "natural"}
    out_norm = app.build_image_prompt(norm_scene, None)
    check("normal prompt ends with the no-added-text clause", out_norm.rstrip().endswith("is fine.)"), repr(out_norm[-40:]))
    check("normal prompt has exactly one no-added-text clause", out_norm.count("Do NOT add any captions") == 1, f"count={out_norm.count('Do NOT add any captions')}")
    check("normal prompt includes the style preset",
          app.STYLE_PRESETS["natural"].strip().split(".")[0][:24] in out_norm)

    d = pathlib.Path(".")
    doc = {"scenes": [raw_scene], "audience": None}
    p, cont_rel, info = app.assemble_image_prompt(raw_scene, doc, d)
    check("assemble RAW: no continuity ref", cont_rel is None)
    check("assemble RAW: prompt == raw", p == raw_scene["prompt"])
    check("assemble RAW: info flags RAW", any("RAW" in x for x in info))

    loc = app.localize_prompt("a woman drinking tea", {"locations": ["France"], "currencies": ["EUR"]}, translate=False)
    check("localize signage OFF by default (no language clause)", "must be written in" not in loc, repr(loc[-60:]))

    check("STYLE_KEYS == natural/2d/3d/scientific", app.STYLE_KEYS == ["natural", "2d", "3d", "scientific"], repr(app.STYLE_KEYS))
    check("every STYLE_KEY has a non-empty preset",
          all(app.STYLE_PRESETS.get(k, "").strip() for k in app.STYLE_KEYS))

    # auto-anchor: photo-less recurring character adopts an approved frame as its face-lock
    check("char_has_photo: true with user photo", app.char_has_photo({"urls": ["refs/x.png"]}))
    check("char_has_photo: false when empty", not app.char_has_photo({"name": "X"}))
    check("char_urls includes the anchor", app.char_urls({"anchor": "images/a.png"}) == ["images/a.png"])
    d_one = {"characters": [{"id": "c2", "name": "Sophie"}], "scenes": []}
    sc_one = {"id": 9, "cast": ["c2"], "image": {"approved_file": "images/sc_9_v1.png", "file": None}}
    app._auto_anchor(d_one, sc_one)
    check("_auto_anchor sets anchor for the lone photo-less char",
          d_one["characters"][0].get("anchor") == "images/sc_9_v1.png")
    d_two = {"characters": [{"id": "a", "name": "A"}, {"id": "b", "name": "B"}], "scenes": []}
    sc_two = {"id": 1, "cast": ["a", "b"], "image": {"approved_file": "images/x.png"}}
    app._auto_anchor(d_two, sc_two)
    check("_auto_anchor skips ambiguous 2-photo-less shot",
          not d_two["characters"][0].get("anchor") and not d_two["characters"][1].get("anchor"))

    # outfit-lock (👕): free ref → clothing MUST differ; locked ref → whole appearance faithful
    free_sc = {"id": 3, "prompt": "a person walking", "style": "natural", "refs": ["char_1.png"], "ref_free": ["char_1.png"]}
    out_free = app.build_image_prompt(free_sc, None)
    check("outfit FREE -> 'DIFFERENT clothing' instruction", "DIFFERENT clothing" in out_free)
    lock_sc = {"id": 4, "prompt": "a person walking", "style": "natural", "refs": ["char_1.png"], "ref_free": []}
    out_lock = app.build_image_prompt(lock_sc, None)
    check("outfit LOCKED -> 'faithful to the reference' instruction", "faithful to the reference" in out_lock)
    check("outfit lock/free is a SINGLE ref line (no bloat)",
          out_free.count("reference image(s)") == 1 and out_lock.count("reference image(s)") == 1)

# 7) save whitelist keeps the fields the UI persists
src = (HERE / "app.py").read_text(encoding="utf-8")
m = re.search(r"def api_save_scenes.*?for f in \((.*?)\):", src, re.S)
wl = set(re.findall(r'"([^"]+)"', m.group(1))) if m else set()
for f in ["vo", "vo_tr", "prompt", "cast", "note", "no_cast", "style", "video_cam_lock", "overlays"]:
    check(f"save whitelist keeps '{f}'", f in wl)
# refs / ref_free are DELIBERATELY out of the whitelist now — managed only by their dedicated endpoints
# (add / ref-scene / DELETE ref / ref-lock) so a full-doc save can't clobber a just-added reference.
for f in ["refs", "ref_free"]:
    check(f"save whitelist EXCLUDES '{f}' (dedicated endpoint only)", f not in wl)

# 8) every api.* fetch URL maps to a real route
if app is not None:
    js = (HERE / "static" / "app.js").read_text(encoding="utf-8")

    def norm(path):
        segs = []
        for seg in path.split("/"):
            segs.append("*" if ("${" in seg or seg.startswith("<")) else seg)
        return "/".join(segs)

    route_norm = {}  # normalized path -> set of methods
    for r in app.app.url_map.iter_rules():
        route_norm.setdefault(norm(str(r.rule)), set()).update(r.methods)

    # api.name: (p...) => fetch(`/api/...`, { method: "X" })   — only the object-literal `api = {…}` block
    apiblock = re.search(r"\bapi\s*=\s*\{(.*?)\n\};", js, re.S)
    scope = apiblock.group(1) if apiblock else js
    pat = re.compile(r"fetch\(\s*[`\"'](/api/[^`\"'?]*)[`\"']([^)]*)\)", re.S)
    seen = 0
    for mm in pat.finditer(scope):
        url = mm.group(1)
        tail = mm.group(2)
        method = "GET"
        mo = re.search(r'method:\s*[`"\']([A-Z]+)', tail)
        if mo:
            method = mo.group(1)
        elif "method:" in tail:
            method = "POST"  # method present but on a following line (rare) — assume mutation
        seen += 1
        nu = norm(url)
        ok = nu in route_norm and (method in route_norm[nu] or method == "GET")
        check(f"api route {method} {url}", ok, f"no @app.route matches {nu} [{method}]")
    check("found api fetch URLs to verify", seen > 5, f"only {seen}")

# 9) every LOCAL module app.py imports must be in publish_update.py's FILES list.
# Splitting code into a new module and forgetting to ship it means the packaged app dies on startup with
# ModuleNotFoundError on every other PC — and the auto-update makes that instant and universal.
# DEV TREE ONLY: the packaged copy (VSLDashboard/app) may carry a stale publish_update.py that is never
# used there, and checking it would fail for no reason. The dev source lives in a dir named "dashboard".
if HERE.name != "dashboard":
    print("  ok   publish FILES check skipped (packaged copy, not the source tree)")
else:
    try:
        pub = (HERE / "publish_update.py").read_text(encoding="utf-8")
        shipped = set(re.findall(r'"([\w.]+\.py)"', pub))
        local_mods = {p.stem for p in HERE.glob("*.py")}
        imported = set(re.findall(r"^\s*(?:import|from)\s+([a-zA-Z_]\w*)", src, re.M)) & local_mods
        for mod in sorted(imported):
            check(f"publish ships local module '{mod}.py'", f"{mod}.py" in shipped,
                  "add it to FILES in publish_update.py or the packaged app won't start")
        # 9b) the aligner scripts live outside dashboard/ and were left out of the bundle for a long
        # time. Nothing broke loudly — the other PCs just kept running an older aligner and drifted a
        # release behind on subtitle timing, which is far harder to notice than a crash.
        subs = HERE.parent / "subtitle"
        if subs.is_dir():
            bundled = "EXTRA_DIRS" in pub and '"subtitle"' in pub
            check("publish ships the subtitle/ aligners", bundled,
                  "add subtitle/ to EXTRA_DIRS in publish_update.py or other PCs keep the old aligner")
            for need in ("vsl_align_srt.py", "align_clip.py", "_mms_align.py"):
                check(f"aligner '{need}' present", (subs / need).exists(),
                      f"missing from {subs}")
    except Exception as e:
        check("publish FILES check", False, repr(e))

# N) names used but never defined - the NameError that only appears when a button is pressed.
# py_compile cannot see these, and a worker thread turns them into a job error rather than a crash,
# which is how Audit & Fix shipped broken after the YouTube/VSL split.
try:
    import undefined_names as _un
    for _py in sorted(HERE.glob("*.py")):
        if _py.name in ("smoke_test.py", "undefined_names.py"):
            continue
        _bad = _un.scan(_py.read_text(encoding="utf-8"), _py.name)
        check(f"no undefined names in {_py.name}", not _bad,
              "; ".join(f"line {l}: {sc} uses '{nm}'" for l, sc, nm in _bad[:4]))
except Exception as _e:
    check("undefined-name check", False, repr(_e))

print()
if FAILS:
    print(f"SMOKE TEST FAILED — {len(FAILS)} problem(s):")
    for f in FAILS:
        print("   - " + f)
    sys.exit(1)
print("SMOKE TEST PASSED")
sys.exit(0)
