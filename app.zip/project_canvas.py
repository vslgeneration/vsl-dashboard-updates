"""Project canvas shared by preview, compositing and editable exports.

Dimensions are job-local: two exports of different projects must never change
each other's geometry. Stored text sizes/offsets use native canvas pixels.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from inspect import signature

SIZES = {"16:9": (1920, 1080), "1:1": (1080, 1080),
         "4:5": (1080, 1350), "9:16": (1080, 1920)}
_canvas = ContextVar("project_canvas", default=(1920, 1080))


def approved_image_file(scene):
    """A video's poster is not an independently approved still image."""
    image = scene.get('image') or {}
    rel = (image.get('approved_file') or image.get('file')) if scene.get('approved') else None
    if not rel:
        return None
    if ((image.get('stock_assets') or {}).get(rel) or {}).get('type') == 'video':
        return None
    video = scene.get('video') or {}
    if any(isinstance(meta, dict) and meta.get('poster') == rel
           for field in ('stock_assets', 'local_edits') for meta in (video.get(field) or {}).values()):
        return None
    return rel


def video_starts(value):
    """Per-take edit decisions; never alter the downloaded/original media."""
    import math
    if not isinstance(value, dict):
        return {}
    out = {}
    for key, val in list(value.items())[:1000]:
        if not isinstance(key, str) or len(key) > 512:
            continue
        try:
            number = float(val)
        except (TypeError, ValueError):
            continue
        if math.isfinite(number) and 0 <= number <= 86400:
            out[key] = round(number * 60) / 60
    return out


def video_start_editable(scene, rel, scenes=(), seen=None):
    """Only a proven external/stock take has a user-editable playback in-point."""
    if scene.get('speaker_clip') or not rel:
        return False
    seen = set() if seen is None else seen
    if rel in seen:
        return False
    seen.add(rel)
    v = scene.get('video') or {}
    if (v.get('stock_assets') or {}).get(rel):
        return True
    takes = v.get('versions') or ([v['file']] if v.get('file') else [])
    sources = v.get('version_sources') or []
    i = takes.index(rel) if rel in takes else -1
    source = sources[i] if 0 <= i < len(sources) else None
    if not source and len(takes) == 1 and rel in takes:
        source = 'uploaded' if v.get('uploaded') else v.get('source')
    if source == 'uploaded':
        return True
    original = ((v.get('local_edits') or {}).get(rel) or {}).get('source')
    if original and video_start_editable(scene, original, scenes, seen):
        return True
    if rel == v.get('file') and v.get('from_video'):
        original = v['from_video']
        for other in scenes or ():
            ov = other.get('video') or {}
            if original in (ov.get('versions') or [ov.get('file')]):
                return video_start_editable(other, original, scenes, seen)
    return False


def clamp_video_start(value, duration=None):
    """Clamp an already resolved timeline offset; do not classify its media again."""
    start = video_starts({'clip': value}).get('clip', 0)
    if duration is not None and duration > 0:
        start = min(start, max(0, int((duration - .5) * 60) / 60))
    return start


def video_start(scene, rel, duration=None, scenes=()):
    if scene.get('speaker_clip'):
        c = scene['speaker_clip']
        return c['source_in_frame'] / c['fps']
    if not video_start_editable(scene, rel, scenes):
        return 0
    return clamp_video_start(video_starts(scene.get('video_starts')).get(str(rel), 0), duration)


def timeline_video_start(scene, duration=None):
    # Linked-take windows and speaker source ranges have already been resolved
    # by the authoritative timeline. They are not user preview seek positions.
    if scene.get('speaker_clip'):
        c = scene['speaker_clip']
        return c['source_in_frame'] / c['fps']
    return clamp_video_start(scene.get('video_start', 0), duration)


def xml_video_window(path, start, cache_root=None):
    """Prepare a frame-accurate XML source window once, without changing the original.

    A cached high-quality copy avoids the differing FCP in-point semantics of
    Time Remap, nested clips and dissolve handles. Geometry remains editable.
    """
    import media_delivery
    return media_delivery.premiere_source(path,start,cache_root)


def aspect(doc=None):
    value = doc.get("image_aspect") if isinstance(doc, dict) else doc
    return value if isinstance(value, str) and value in SIZES else "16:9"


def dimensions(doc=None, fast=False):
    w, h = SIZES[aspect(doc)]
    if fast:
        # Exactly 2/3, even in all four formats; matches the former 720p test.
        w, h = w * 2 // 3, h * 2 // 3
    return w, h


def metadata(doc=None, fast=False):
    w, h = dimensions(doc, fast)
    return {"aspect": aspect(doc), "width": w, "height": h,
            "fps": 30 if fast else 60}


def size():
    return _canvas.get()


@contextmanager
def scope(doc=None, *, dims=None):
    token = _canvas.set(tuple(dims) if dims else dimensions(doc))
    try:
        yield
    finally:
        _canvas.reset(token)


def job(argument):
    """Capture a document/timeline for the complete synchronous operation."""
    def decorate(fn):
        sig = signature(fn)
        @wraps(fn)
        def wrapped(*args, **kwargs):
            bound = sig.bind(*args, **kwargs)
            with scope(bound.arguments.get(argument)):
                return fn(*args, **kwargs)
        return wrapped
    return decorate


def cache_suffix():
    w, h = size()
    return "" if (w, h) == SIZES["16:9"] else f"_{w}x{h}"


def card_image(path, doc, force=False):
    """Frame saved written-card artwork without cropping. Originals remain untouched."""
    if aspect(doc) == "16:9" and not force:
        return path
    from pathlib import Path
    from PIL import Image, ImageOps
    import hashlib, os, tempfile
    src = Path(path)
    w, h = dimensions(doc)
    with Image.open(src) as im:
        if im.size == (w, h):
            return src
        stat = src.stat()
        key = hashlib.sha256(f"{src.name}|{stat.st_mtime_ns}|{stat.st_size}|{w}x{h}".encode()).hexdigest()[:20]
        cache = src.parent / "_canvas"
        cache.mkdir(exist_ok=True)
        target = cache / (key + ".png")
        if target.exists():
            return target
        fitted = ImageOps.contain(im.convert("RGBA"), (w, h), Image.Resampling.LANCZOS)
    frame = Image.new("RGB", (w, h), "white")
    frame.paste(fitted, ((w-fitted.width)//2, (h-fitted.height)//2), fitted)
    fd, temp = tempfile.mkstemp(prefix="card-", suffix=".part", dir=cache)
    try:
        with os.fdopen(fd, "wb") as f:
            frame.save(f, "PNG")
        os.replace(temp, target)
    finally:
        Path(temp).unlink(missing_ok=True)
    return target


def clean_framing(value):
    """Only finite, bounded geometry; offsets are fractions of the output canvas."""
    import math
    if not isinstance(value, dict):
        return None
    out = {}
    for key, default, lo, hi in (("zoom", 1, .25, 4), ("x", 0, -1, 1), ("y", 0, -1, 1)):
        v = value.get(key, default)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            return None
        out[key] = round(max(lo, min(hi, v)), 6)
    out["fit"] = "contain" if value.get("fit") == "contain" else "cover"
    return out


def framing_map(value):
    if not isinstance(value, dict):
        return {}
    return {a: f for a, v in value.items() if a in SIZES and (f := clean_framing(v)) is not None}


def scene_framing(scene, doc):
    """Resolve saved framing for every delivery path without rewriting the scene.

    Ordinary scene media always fill the output canvas. Legacy contain settings
    must not reintroduce white/black bars when a model returns a near-match ratio.
    Written cards retain their intentional white canvas and uncropped layout.
    None still means automatic motion; saved zoom and pan remain editable.
    """
    frame = framing_map(scene.get("media_framing")).get(aspect(doc))
    if frame is not None and not scene.get("tcard_id"):
        frame["fit"] = "cover"
    return frame


def bounded_framing(media_w, media_h, canvas_w, canvas_h, framing):
    """Keep the filled canvas inside the source; zooming out also clamps pan."""
    f = clean_framing(framing) or dict(zoom=1, x=0, y=0, fit="cover")
    f['zoom'] = max(1, f['zoom'])
    fit = min if f["fit"] == "contain" else max
    scale = fit(canvas_w / max(1, media_w), canvas_h / max(1, media_h)) * f["zoom"]
    w, h = media_w * scale, media_h * scale
    for key, extent, canvas in (('x', w, canvas_w), ('y', h, canvas_h)):
        limit = max(0, (extent / max(1, canvas) - 1) / 2)
        f[key] = max(-limit, min(limit, f[key]))
    return f


def frame_geometry(media_w, media_h, canvas_w, canvas_h, framing):
    f = bounded_framing(media_w, media_h, canvas_w, canvas_h, framing)
    fit = min if f["fit"] == "contain" else max
    scale = fit(canvas_w / max(1, media_w), canvas_h / max(1, media_h)) * f["zoom"]
    w, h = media_w * scale, media_h * scale
    return scale, (canvas_w-w)/2 + f["x"]*canvas_w, (canvas_h-h)/2 + f["y"]*canvas_h


def overlay_ranks(scene):
    """Identity-to-rank for explicitly ordered text/icons; None keeps legacy order.

    New unranked objects join above authored ones, without mutating the document.
    Source media, effects, subtitles and readability plates are never participants.
    """
    import math
    icons=[v for v in (scene.get('icons') or []) if isinstance(v,dict) and (v.get('type') or v.get('icon'))]
    key='texts' if 'texts' in scene else 'overlays'
    texts=[v for v in (scene.get(key) or []) if isinstance(v,dict) and str(v.get('text' if key=='texts' else 'onscreen') or '').strip()]
    entries=icons+texts
    def valid(v):
        n=v.get('overlay_layer')
        return isinstance(n,(int,float)) and not isinstance(n,bool) and math.isfinite(n)
    if not any(valid(v) for v in entries):return None
    entries.sort(key=lambda v:v['overlay_layer'] if valid(v) else math.inf)
    return {id(v):i for i,v in enumerate(entries)}
