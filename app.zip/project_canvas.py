"""Project canvas shared by preview, compositing and editable exports.

Dimensions are job-local: two exports of different projects must never change
each other's geometry. Stored text sizes/offsets use native canvas pixels.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from inspect import signature

SIZES = {"16:9": (1920, 1080), "1:1": (1080, 1080),
         "4:5": (1080, 1350), "9:16": (1080, 1920)}
_canvas = ContextVar("project_canvas", default=(1920, 1080))


def aspect(doc=None):
    value = doc.get("image_aspect") if isinstance(doc, dict) else doc
    return value if isinstance(value, str) and value in SIZES else "16:9"


def dimensions(doc=None, fast=False):
    w, h = SIZES[aspect(doc)]
    if fast:
        # Exactly 2/3, even in all four formats; matches the former 720p test.
        w, h = w * 2 // 3, h * 2 // 3
    return w, h


def metadata(doc=None, fast=False):
    w, h = dimensions(doc, fast)
    return {"aspect": aspect(doc), "width": w, "height": h,
            "fps": 30 if fast else 60}


def size():
    return _canvas.get()


@contextmanager
def scope(doc=None, *, dims=None):
    token = _canvas.set(tuple(dims) if dims else dimensions(doc))
    try:
        yield
    finally:
        _canvas.reset(token)


def job(argument):
    """Capture a document/timeline for the complete synchronous operation."""
    def decorate(fn):
        sig = signature(fn)
        @wraps(fn)
        def wrapped(*args, **kwargs):
            bound = sig.bind(*args, **kwargs)
            with scope(bound.arguments.get(argument)):
                return fn(*args, **kwargs)
        return wrapped
    return decorate


def cache_suffix():
    w, h = size()
    return "" if (w, h) == SIZES["16:9"] else f"_{w}x{h}"


def card_image(path, doc):
    """Frame saved written-card artwork without cropping. Originals remain untouched."""
    if aspect(doc) == "16:9":
        return path
    from pathlib import Path
    from PIL import Image, ImageOps
    import hashlib, os, tempfile
    src = Path(path)
    w, h = dimensions(doc)
    with Image.open(src) as im:
        if im.size == (w, h):
            return src
        stat = src.stat()
        key = hashlib.sha256(f"{src.name}|{stat.st_mtime_ns}|{stat.st_size}|{w}x{h}".encode()).hexdigest()[:20]
        cache = src.parent / "_canvas"
        cache.mkdir(exist_ok=True)
        target = cache / (key + ".png")
        if target.exists():
            return target
        fitted = ImageOps.contain(im.convert("RGBA"), (w, h), Image.Resampling.LANCZOS)
    frame = Image.new("RGB", (w, h), "white")
    frame.paste(fitted, ((w-fitted.width)//2, (h-fitted.height)//2), fitted)
    fd, temp = tempfile.mkstemp(prefix="card-", suffix=".part", dir=cache)
    try:
        with os.fdopen(fd, "wb") as f:
            frame.save(f, "PNG")
        os.replace(temp, target)
    finally:
        Path(temp).unlink(missing_ok=True)
    return target
