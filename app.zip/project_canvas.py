"""Project canvas shared by preview, compositing and editable exports.

Dimensions are job-local: two exports of different projects must never change
each other's geometry. Stored text sizes/offsets use native canvas pixels.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from inspect import signature

SIZES = {"16:9": (1920, 1080), "1:1": (1080, 1080),
         "4:5": (1080, 1350), "9:16": (1080, 1920)}
_canvas = ContextVar("project_canvas", default=(1920, 1080))


def video_starts(value):
    """Per-take edit decisions; never alter the downloaded/original media."""
    import math
    if not isinstance(value, dict):
        return {}
    out = {}
    for key, val in list(value.items())[:1000]:
        if not isinstance(key, str) or len(key) > 512:
            continue
        try:
            number = float(val)
        except (TypeError, ValueError):
            continue
        if math.isfinite(number) and 0 <= number <= 86400:
            out[key] = round(number * 60) / 60
    return out


def video_start(scene, rel, duration=None):
    start = video_starts(scene.get('video_starts')).get(str(rel), 0)
    if duration is not None and duration > 0:
        # Keep at least half a second (or the whole clip if shorter).
        start = min(start, max(0, int((duration - .5) * 60) / 60))
    return start


def xml_video_window(path, start):
    """Prepare a frame-accurate XML source window once, without changing the original.

    A cached high-quality copy avoids the differing FCP in-point semantics of
    Time Remap, nested clips and dissolve handles. Geometry remains editable.
    """
    if start <= 0:
        return path
    import hashlib, os, subprocess, uuid
    from pathlib import Path
    path = Path(path)
    stamp = path.stat()
    key = hashlib.sha256(f'1:{path.resolve()}:{stamp.st_size}:{stamp.st_mtime_ns}:{start:.9f}'.encode()).hexdigest()[:24]
    folder = path.parent / '_start_windows'
    folder.mkdir(exist_ok=True)
    target = folder / (key + '.mp4')
    if target.exists() and target.stat().st_size > 0:
        return target
    temp = folder / (key + '-' + uuid.uuid4().hex + '.part.mp4')
    try:
        result = subprocess.run(['ffmpeg','-v','error','-nostdin','-ss',f'{start:.9f}','-i',str(path),
                                 '-map','0:v:0','-an','-vf','setpts=PTS-STARTPTS',
                                 '-c:v','libx264','-preset','fast','-crf','12','-pix_fmt','yuv420p',
                                 '-movflags','+faststart','-y',str(temp)],
                                capture_output=True, timeout=900,
                                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode or not temp.exists() or not temp.stat().st_size:
            raise RuntimeError('Could not prepare the selected video start for XML: '+result.stderr.decode('utf8','replace')[-500:])
        os.replace(temp,target)
        return target
    finally:
        temp.unlink(missing_ok=True)


def aspect(doc=None):
    value = doc.get("image_aspect") if isinstance(doc, dict) else doc
    return value if isinstance(value, str) and value in SIZES else "16:9"


def dimensions(doc=None, fast=False):
    w, h = SIZES[aspect(doc)]
    if fast:
        # Exactly 2/3, even in all four formats; matches the former 720p test.
        w, h = w * 2 // 3, h * 2 // 3
    return w, h


def metadata(doc=None, fast=False):
    w, h = dimensions(doc, fast)
    return {"aspect": aspect(doc), "width": w, "height": h,
            "fps": 30 if fast else 60}


def size():
    return _canvas.get()


@contextmanager
def scope(doc=None, *, dims=None):
    token = _canvas.set(tuple(dims) if dims else dimensions(doc))
    try:
        yield
    finally:
        _canvas.reset(token)


def job(argument):
    """Capture a document/timeline for the complete synchronous operation."""
    def decorate(fn):
        sig = signature(fn)
        @wraps(fn)
        def wrapped(*args, **kwargs):
            bound = sig.bind(*args, **kwargs)
            with scope(bound.arguments.get(argument)):
                return fn(*args, **kwargs)
        return wrapped
    return decorate


def cache_suffix():
    w, h = size()
    return "" if (w, h) == SIZES["16:9"] else f"_{w}x{h}"


def card_image(path, doc, force=False):
    """Frame saved written-card artwork without cropping. Originals remain untouched."""
    if aspect(doc) == "16:9" and not force:
        return path
    from pathlib import Path
    from PIL import Image, ImageOps
    import hashlib, os, tempfile
    src = Path(path)
    w, h = dimensions(doc)
    with Image.open(src) as im:
        if im.size == (w, h):
            return src
        stat = src.stat()
        key = hashlib.sha256(f"{src.name}|{stat.st_mtime_ns}|{stat.st_size}|{w}x{h}".encode()).hexdigest()[:20]
        cache = src.parent / "_canvas"
        cache.mkdir(exist_ok=True)
        target = cache / (key + ".png")
        if target.exists():
            return target
        fitted = ImageOps.contain(im.convert("RGBA"), (w, h), Image.Resampling.LANCZOS)
    frame = Image.new("RGB", (w, h), "white")
    frame.paste(fitted, ((w-fitted.width)//2, (h-fitted.height)//2), fitted)
    fd, temp = tempfile.mkstemp(prefix="card-", suffix=".part", dir=cache)
    try:
        with os.fdopen(fd, "wb") as f:
            frame.save(f, "PNG")
        os.replace(temp, target)
    finally:
        Path(temp).unlink(missing_ok=True)
    return target


def clean_framing(value):
    """Only finite, bounded geometry; offsets are fractions of the output canvas."""
    import math
    if not isinstance(value, dict):
        return None
    out = {}
    for key, default, lo, hi in (("zoom", 1, .25, 4), ("x", 0, -1, 1), ("y", 0, -1, 1)):
        v = value.get(key, default)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            return None
        out[key] = round(max(lo, min(hi, v)), 6)
    out["fit"] = "contain" if value.get("fit") == "contain" else "cover"
    return out


def framing_map(value):
    if not isinstance(value, dict):
        return {}
    return {a: f for a, v in value.items() if a in SIZES and (f := clean_framing(v)) is not None}


def scene_framing(scene, doc):
    return framing_map(scene.get("media_framing")).get(aspect(doc))


def bounded_framing(media_w, media_h, canvas_w, canvas_h, framing):
    """Keep the filled canvas inside the source; zooming out also clamps pan."""
    f = clean_framing(framing) or dict(zoom=1, x=0, y=0, fit="cover")
    f['zoom'] = max(1, f['zoom'])
    fit = min if f["fit"] == "contain" else max
    scale = fit(canvas_w / max(1, media_w), canvas_h / max(1, media_h)) * f["zoom"]
    w, h = media_w * scale, media_h * scale
    for key, extent, canvas in (('x', w, canvas_w), ('y', h, canvas_h)):
        limit = max(0, (extent / max(1, canvas) - 1) / 2)
        f[key] = max(-limit, min(limit, f[key]))
    return f


def frame_geometry(media_w, media_h, canvas_w, canvas_h, framing):
    f = bounded_framing(media_w, media_h, canvas_w, canvas_h, framing)
    fit = min if f["fit"] == "contain" else max
    scale = fit(canvas_w / max(1, media_w), canvas_h / max(1, media_h)) * f["zoom"]
    w, h = media_w * scale, media_h * scale
    return scale, (canvas_w-w)/2 + f["x"]*canvas_w, (canvas_h-h)/2 + f["y"]*canvas_h
