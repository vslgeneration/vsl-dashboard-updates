"""Bake saved scene framing into a download copy; never change the master or scene."""
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import uuid

import browser_video
import project_canvas

_ENCODER = threading.BoundedSemaphore(1)


def display_size(info):
    v = info['video']
    w, h = v['width'], v['height']
    try:
        a, b = map(float, v.get('sample_aspect_ratio', '1:1').split(':'))
        sar = a / b
        if not math.isfinite(sar) or sar <= 0: sar = 1
    except (ValueError, ZeroDivisionError): sar = 1
    if round(info['rotation']) % 180:
        return h, w, h, w * sar
    return w, h, w * sar, h


def filters(info, dims, frame):
    """Crop before scaling to avoid allocating a zoomed 4K/8K intermediate."""
    w, h, dw, dh = display_size(info)
    cw, ch = dims
    scale, left, top = project_canvas.frame_geometry(dw, dh, cw, ch, frame)
    # The decoder applies display rotation before these filters. Translate the
    # displayed rectangle back into its decoded pixel coordinates (including SAR).
    x = max(0, min(w - 1, round(-left / scale * w / dw)))
    y = max(0, min(h - 1, round(-top / scale * h / dh)))
    rw = max(1, min(w - x, round(min(cw, dw * scale) / scale * w / dw)))
    rh = max(1, min(h - y, round(min(ch, dh * scale) / scale * h / dh)))
    visible_w, visible_h = rw * dw / w, rh * dh / h
    contain = frame.get('fit') == 'contain' and (left > 0 or top > 0)
    target_w, target_h = min(cw, dw * scale), min(ch, dh * scale)
    factor = (min if contain else max)(target_w / visible_w, target_h / visible_h)
    sw, sh = max(2, math.ceil(visible_w * factor / 2) * 2), max(2, math.ceil(visible_h * factor / 2) * 2)
    chain = []
    if info['video'].get('color_transfer') in ('smpte2084', 'arib-std-b67'):
        chain += ['zscale=t=linear:npl=100', 'format=gbrpf32le', 'zscale=p=bt709',
                  'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv']
    chain += [f'crop={rw}:{rh}:{x}:{y}:exact=1', f'scale={sw}:{sh}:flags=lanczos', 'setsar=1']
    if sw < cw or sh < ch:
        chain += [f'pad={max(cw,sw)}:{max(ch,sh)}:(ow-iw)/2:(oh-ih)/2:color=black']
    chain += [f'crop={cw}:{ch}', 'format=yuv420p']
    return ','.join(chain)


def prepare(source, directory, dims, frame, progress=lambda *a: None, cancelled=lambda: False):
    source = Path(source).resolve()
    def stamp():
        s = source.stat()
        return [1, str(source).casefold(), s.st_size, s.st_mtime_ns, dims, frame]
    identity = stamp()
    key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:32]
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    target = directory / (key + '.mp4')
    def check():
        if cancelled(): raise InterruptedError('Video download cancelled.')
    progress('Preparing Framed Video…', None)
    while not _ENCODER.acquire(timeout=.2): check()
    part = directory / ('.' + uuid.uuid4().hex + '.part.mp4')
    try:
        check()
        if target.is_file() and target.stat().st_size > 100: return target
        info = browser_video.probe(source)
        vf = filters(info, dims, frame)
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)
        args = ['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2', '-filter_threads', '1',
                '-i', str(source), '-map', '0:v:0', '-map', '0:a:0?', '-map_metadata', '-1',
                '-vf', vf, '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-threads', '2',
                '-fps_mode', 'passthrough', '-c:a', 'aac', '-b:a', '192k',
                '-movflags', '+faststart', '-progress', 'pipe:1', '-n', str(part)]
        # File-backed logs keep the UI thread and the encoder's pipes unblocked.
        with tempfile.TemporaryDirectory(prefix='download-log-', dir=directory) as logs, \
             open(Path(logs) / 'progress', 'wb') as writer, \
             open(Path(logs) / 'progress', 'rb') as log, tempfile.TemporaryFile() as errors:
            process = subprocess.Popen(args, stdout=writer, stderr=errors, creationflags=flags)
            started = time.monotonic(); position = 0; pending = b''
            try:
                while process.poll() is None:
                    check()
                    if time.monotonic() - started > 1800: raise TimeoutError('Preparing this video took too long. Please retry.')
                    log.seek(position); chunk = log.read(); position += len(chunk); pending += chunk
                    lines = pending.split(b'\n'); pending = lines.pop()
                    for line in lines:
                        if line.startswith(b'out_time_us='):
                            try:
                                elapsed = max(0, int(line.split(b'=')[1]) / 1_000_000)
                                pct = min(99, 100 * elapsed / info['duration'])
                                spent = time.monotonic() - started
                                remaining = max(0, round(spent * (info['duration'] - elapsed) / elapsed)) if elapsed > .1 else None
                                title = 'Applying Saved Framing' + (f' · about {remaining}s left' if remaining is not None else '…')
                                progress(title, pct)
                            except ValueError: pass
                    time.sleep(.2)
                if process.returncode:
                    errors.seek(0)
                    raise ValueError('Could not prepare the framed video: ' + errors.read().decode('utf8','replace')[-350:])
            finally:
                if process.poll() is None: process.kill(); process.wait()
        check()
        result = browser_video.probe(part)
        if ((result['video']['width'], result['video']['height']) != tuple(dims)
            or bool(result['audio']) != bool(info['audio'])
            or abs(result['duration'] - info['duration']) > max(.1, 2 / info['fps'])):
            raise ValueError('The framed video did not preserve the original duration or audio. Please retry.')
        if stamp() != identity: raise ValueError('The source video changed. Download it again.')
        os.replace(part, target)
        return target
    finally:
        part.unlink(missing_ok=True)
        _ENCODER.release()


def register(g):
    app, request, jsonify = g['app'], g['request'], g['jsonify']
    jobs = g['_user_job_registry']('scene-video-download')

    @app.route('/api/scene-video-download/<project>', methods=['POST'], endpoint='scene_video_download_start')
    def start(project):
        body = request.get_json(silent=True) or {}
        with g['_project_lock'](project):
            doc = g['load_doc'](project)
            if doc is None: g['abort'](404)
            scene = next((s for s in doc.get('scenes',[]) if s.get('uid') == body.get('uid')), None)
            rel = body.get('file')
            d = g['proj_dir'](project)[0]
            if (not scene or not isinstance(rel, str) or rel not in g['_video_takes'](scene.get('video') or {})
                or not g['_inside'](d / rel, d) or not (d / rel).is_file()):
                return jsonify(error='The selected scene video is no longer available.'), 409
            frame = project_canvas.scene_framing(scene, doc)
            dims = project_canvas.dimensions(doc)
            if frame is None: return jsonify(file=rel, framed=False)
            frame = copy.deepcopy(frame)
        job = dict(id=uuid.uuid4().hex, project=project, status='running', step='Preparing Framed Video…', pct=None, cancel=False)
        jobs[job['id']] = job
        def work():
            try:
                target = prepare(d / rel, d / 'export/framed-videos', dims, frame,
                                 lambda step,pct:job.update(step=step,pct=pct), lambda:job['cancel'])
                job.update(status='done', file=target.relative_to(d).as_posix(), framed=True, pct=100)
            except Exception as error:
                job.update(status='cancelled' if isinstance(error,InterruptedError) else 'error', error=str(error)[:600])
        g['_KeyThread'](target=work, daemon=True).start()
        return jsonify(job=job['id']), 202

    @app.route('/api/scene-video-download-job/<job_id>', methods=['GET','POST'], endpoint='scene_video_download_status')
    def status(job_id):
        job = jobs.get(job_id)
        if not job: g['abort'](404)
        if request.method == 'POST': job['cancel'] = True
        return jsonify({k:v for k,v in job.items() if k != 'cancel'})
