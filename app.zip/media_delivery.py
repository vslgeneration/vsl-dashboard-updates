"""Local delivery transforms; never replace imported or generated source media."""
import hashlib,json,math,os,subprocess,tempfile,threading
from pathlib import Path
from functools import lru_cache

_LOCK=threading.RLock()
_FLAGS=getattr(subprocess,'CREATE_NO_WINDOW',0)
PORTRAIT_BLUR=24.0
PORTRAIT_BLACK=.5

@lru_cache(maxsize=512)
def _probe(path,size,mtime):
 r=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_tag_string,codec_name,width,height,duration,nb_frames,sample_aspect_ratio,avg_frame_rate,start_time:stream_tags=rotate,timecode:stream_side_data=rotation:format=duration,start_time:format_tags=timecode','-of','json',path],capture_output=True,text=True,timeout=45,creationflags=_FLAGS)
 if r.returncode:raise ValueError('Video metadata could not be read.')
 j=json.loads(r.stdout);streams=j.get('streams') or [];s=next((s for s in streams if s.get('codec_type')=='video'),{});w,h=int(s.get('width') or 0),int(s.get('height') or 0)
 if not w or not h:raise ValueError('Video dimensions are unavailable.')
 rotation=float(next((v['rotation'] for v in s.get('side_data_list',[]) if 'rotation' in v),(s.get('tags') or {}).get('rotate',0)))
 sar=s.get('sample_aspect_ratio','1:1').split(':')
 try:pixel=float(sar[0])/float(sar[1]);pixel=pixel if math.isfinite(pixel) and pixel>0 else 1
 except (ValueError,ZeroDivisionError,IndexError):pixel=1
 w=round(w*pixel)
 if round(rotation)%180:w,h=h,w
 try:a,b=s.get('avg_frame_rate','0/1').split('/');fps=float(a)/float(b)
 except (ValueError,ZeroDivisionError):fps=0
 duration=float(s.get('duration') or j.get('format',{}).get('duration') or 0)
 try:source_start=float(s.get('start_time') or 0)
 except (ValueError,TypeError):source_start=0
 if not math.isfinite(source_start):source_start=0
 timecodes=[str(v.get('tags',{}).get('timecode') or '').strip() for v in [*streams,j.get('format',{})]]
 has_timecode=any(timecodes) or any(str(v.get('codec_tag_string','')).lower()=='tmcd' for v in streams)
 return dict(width=w,height=h,rotation=rotation,codec=s.get('codec_name',''),duration=duration,fps=fps,sar=pixel,
  source_start=source_start,timecode=next((v for v in timecodes if v),None),has_timecode=has_timecode,
  has_data=any(v.get('codec_type')=='data' for v in streams),has_audio=any(v.get('codec_type')=='audio' for v in streams))

def probe(path):
 p=Path(path);s=p.stat();return dict(_probe(str(p.resolve()),s.st_size,s.st_mtime_ns))

def automatic_portrait(width,height,canvas_w,canvas_h,framing=None,speaker=False):
 """Default portrait presentation; a deliberate zoom or pan retains its crop."""
 if speaker or width<=0 or height<=width or width/height>=canvas_w/canvas_h-.01:return False
 f=framing or {}
 return abs(float(f.get('zoom',1))-1)<1e-6 and abs(float(f.get('x',0)))<1e-6 and abs(float(f.get('y',0)))<1e-6

def crossfade_seconds(kind,source_duration,shown,next_shown,offset=0,fps=60):
 """A moving transition needs a real outgoing handle; never synthesize an EOF hold."""
 duration=max(0,min(.4,shown/2,next_shown/2));frames=round(duration*fps)
 if frames<1:return 0.0
 duration=frames/fps
 if kind=='image':return duration
 if kind!='video' or not source_duration or source_duration-offset+1e-7<shown+duration:return 0.0
 return duration

def portrait_graph(source,output,w,h,prefix='portrait',clock=''):
 """Split after the source clock, keeping foreground and blurred background in sync."""
 blur=PORTRAIT_BLUR*h/1080
 return (f'[{source}]{clock}scale=trunc(iw*sar/2)*2:ih,setsar=1,split=2[{prefix}b][{prefix}f];'
  f'[{prefix}b]scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1,'
  f'gblur=sigma={blur:.6f}:steps=2,format=rgba,drawbox=c=black@{PORTRAIT_BLACK}:t=fill[{prefix}bg];'
  f'[{prefix}f]scale=-2:{h}:flags=lanczos,setsar=1,format=rgba[{prefix}fg];'
  f'[{prefix}bg][{prefix}fg]overlay=(W-w)/2:0:shortest=1:format=rgb,setsar=1[{output}]')

def _cached(source,folder,options,build,codec='h264',suffix='.mp4',clean_clock=False):
 source=Path(source);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);s=source.stat()
 key=hashlib.sha256(json.dumps([str(source.resolve()),s.st_size,s.st_mtime_ns,options],sort_keys=True).encode()).hexdigest()[:24]
 target=folder/(key+suffix)
 with _LOCK:
  if target.is_file() and target.stat().st_size>100:return target
  fd,name=tempfile.mkstemp(prefix='.delivery-',suffix=suffix,dir=folder);os.close(fd);temp=Path(name)
  try:
   args=build(temp)
   r=subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-threads','2','-filter_threads','2',*args],capture_output=True,timeout=900,creationflags=_FLAGS)
   if r.returncode or temp.stat().st_size<100:raise RuntimeError('Premiere media preparation failed: '+r.stderr.decode(errors='replace')[-350:])
   checked=probe(temp)
   if checked['codec']!=codec or checked['duration']<=0:raise RuntimeError('Prepared Premiere media could not be verified.')
   if clean_clock and (checked['has_timecode'] or checked['has_data'] or checked['has_audio'] or abs(checked['source_start'])>.000001):
    raise RuntimeError('Prepared Premiere media did not have a clean source clock.')
   os.replace(temp,target)
  finally:temp.unlink(missing_ok=True)
 return target

def premiere_source(source,start=0,cache_root=None):
 """Return an XML-safe source, preserving originals and native video geometry.

 Imported stock may carry a QuickTime source timecode even when decoded PTS
 starts at zero. Premiere can apply that offset to our zero-based XML in/out.
 Remove that metadata/data track with a lossless video-only remux. Decoding is
 needed only for an authored trim, rotation, pixel aspect or unsupported codec.
 """
 source=Path(source);info=probe(source);start=max(0,float(start))
 compatible=info['codec'] in ('h264','hevc','prores','dnxhd','qtrle','mjpeg','png') and source.suffix.lower() in ('.mp4','.mov','.m4v','.mxf') and not info['rotation'] and info['sar']==1
 dirty_clock=info['has_timecode'] or info['has_data'] or abs(info['source_start'])>.000001
 if compatible and start<=0 and not dirty_clock:return source
 folder=Path(cache_root) if cache_root else source.parent/'_premiere_media'
 clean=['-map','0:v:0','-an','-dn','-sn','-map_metadata','-1','-map_metadata:s:v','-1','-map_chapters','-1',
        '-metadata:s:v:0','timecode=','-write_tmcd','0']
 if compatible and start<=0:
  suffix='.mp4' if info['codec'] in ('h264','hevc') else '.mov'
  def copy_cmd(temp):
   # Use the video origin, not the container/audio origin. Keep negative DTS
   # preroll: avoid_negative_ts=make_zero would shift B-frame video by frames.
   return ['-copyts','-itsoffset',f'{-info["source_start"]:.9f}','-i',str(source),*clean,'-c:v','copy','-movflags','+faststart',str(temp)]
  return _cached(source,folder,dict(operation='premiere-source-v2-clock-remux',codec=info['codec']),copy_cmd,
                 codec=info['codec'],suffix=suffix,clean_clock=True)
 def cmd(temp):
  return [*(['-ss',f'{start:.9f}'] if start else []),'-i',str(source),*clean,
   '-vf','setpts=PTS-STARTPTS,scale=trunc(iw*sar/2)*2:trunc(ih/2)*2,setsar=1','-metadata:s:v:0','rotate=0',
   '-c:v','libx264','-preset','fast','-crf','14','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(temp)]
 return _cached(source,folder,dict(operation='premiere-source-v2-clock',start=start),cmd,clean_clock=True)

def blurred_background(source,w,h,cache_root):
 """Background-only asset; XML foreground and 50% matte stay independently editable."""
 source=Path(source);blur=PORTRAIT_BLUR*h/1080
 def cmd(temp):return ['-i',str(source),'-an','-vf',f'setpts=PTS-STARTPTS,scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1,gblur=sigma={blur:.6f}:steps=2',
  '-c:v','libx264','-preset','fast','-crf','14','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(temp)]
 return _cached(source,cache_root,dict(operation='portrait-background-v1',width=w,height=h,blur=blur),cmd)
