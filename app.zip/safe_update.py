"""Recoverable code updates. No network, no process launch, and no access outside the app/update roots."""
import hashlib
import json
import os
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path


def _child(root, rel):
    if not isinstance(rel, str) or not rel or '\\' in rel or rel.startswith('/'):
        raise ValueError('Unsafe update path')
    parts = rel.split('/')
    reserved = {'CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$'}
    reserved.update('%s%d' % (p, i) for p in ('COM', 'LPT') for i in range(1, 10))
    for part in parts:
        if (part in ('', '.', '..') or part.endswith(('.', ' '))
                or any(c in part for c in ':<>"|?*') or any(ord(c) < 32 for c in part)
                or part.split('.', 1)[0].upper() in reserved):
            raise ValueError('Unsafe update path: ' + rel)
    root = Path(root).resolve()
    result = root.joinpath(*parts).resolve()
    result.relative_to(root)
    return result


def _hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _journal_write(path, data):
    fd, tmp = tempfile.mkstemp(prefix='.journal-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def recover(app_dir, update_dir):
    """Restore an interrupted update before importing application code. Backups are never consumed."""
    app_dir, update_dir = Path(app_dir).resolve(), Path(update_dir).resolve()
    journal = update_dir / 'pending-install.json'
    if not journal.exists():
        return False
    data = json.loads(journal.read_text(encoding='utf-8'))
    if data.get('schema') != 1 or not isinstance(data.get('files'), list):
        raise ValueError('Invalid update recovery record; backups were preserved')
    txn = data.get('transaction', '')
    if not txn.startswith('txn-') or '/' in txn or '\\' in txn:
        raise ValueError('Invalid update backup directory')
    base = _child(update_dir, txn)
    if data.get('committed'):
        journal.unlink()                 # fully installed; a crash only interrupted housekeeping
        return False
    # Validate every backup and current target before restoring any file.
    for item in data['files']:
        target = _child(app_dir, item['path'])
        old = _child(base / 'old', item['path'])
        if item['existed'] and (not old.is_file() or _hash(old) != item['old_hash']):
            raise RuntimeError('Update backup is missing or damaged: ' + item['path'])
        if target.exists() and (not target.is_file() or _hash(target) not in (item['new_hash'], item.get('old_hash'))):
            raise RuntimeError('File changed outside the update; backup preserved: ' + item['path'])
    for item in reversed(data['files']):
        target = _child(app_dir, item['path'])
        if item['existed']:
            target.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix='.restore-', dir=target.parent)
            os.close(fd)
            try:
                shutil.copyfile(_child(base / 'old', item['path']), tmp)
                os.replace(tmp, target)
            finally:
                Path(tmp).unlink(missing_ok=True)
        elif target.exists():
            target.unlink()             # hash was checked: only the new file from this update
    journal.unlink()
    return True


def install(app_dir, update_dir):
    """Stage/validate everything, back up touched files, then atomically replace each with a recovery journal."""
    app_dir, update_dir = Path(app_dir).resolve(), Path(update_dir).resolve()
    recover(app_dir, update_dir)
    archive = update_dir / 'app.zip'
    expected = (update_dir / 'version.txt').read_text(encoding='utf-8').strip()
    if not expected:
        raise ValueError('Missing update version')
    txn = update_dir / ('txn-' + uuid.uuid4().hex)
    stage, old = txn / 'new', txn / 'old'
    stage.mkdir(parents=True)
    old.mkdir()
    journal = update_dir / 'pending-install.json'
    data = dict(schema=1, transaction=txn.name, committed=False, files=[])
    try:
        with zipfile.ZipFile(archive) as z:
            seen = set()
            for info in z.infolist():
                rel = info.filename.rstrip('/')
                out = _child(stage, rel)
                _child(app_dir, rel)
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Update archive contains a link')
                key = rel.casefold()
                if key in seen:
                    raise ValueError('Duplicate update path: ' + rel)
                seen.add(key)
                if info.is_dir():
                    out.mkdir(parents=True, exist_ok=True)
                    continue
                out.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, open(out, 'xb') as dest:
                    shutil.copyfileobj(src, dest)
                if out.suffix.lower() == '.py':
                    compile(out.read_bytes(), rel, 'exec')
                data['files'].append(dict(path=rel, new_hash=_hash(out)))
        for required in ('app.py', 'desktop.py', 'version.txt'):
            if not (stage / required).is_file():
                raise ValueError('Incomplete update: ' + required)
        if (stage / 'version.txt').read_text(encoding='utf-8').strip() != expected:
            raise ValueError('The archive version does not match the downloaded version')
        data['files'].sort(key=lambda item: item['path'] == 'version.txt')
        for item in data['files']:
            target = _child(app_dir, item['path'])
            item['existed'] = target.exists()
            if item['existed']:
                if not target.is_file():
                    raise ValueError('Update target is not a file: ' + item['path'])
                backup = _child(old, item['path'])
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(target, backup)
                item['old_hash'] = _hash(backup)
        _journal_write(journal, data)     # no app file changes before this durable recovery record
        for item in data['files']:
            target = _child(app_dir, item['path'])
            target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(_child(stage, item['path']), target)
        data['committed'] = True
        _journal_write(journal, data)
    except Exception:
        if journal.exists():
            recover(app_dir, update_dir)
        raise
    # Backups remain under txn-*/old. A failed cleanup must not turn a completed install into failure.
    for p in (journal, archive, update_dir / 'version.txt'):
        try:
            p.unlink(missing_ok=True)
        except OSError:
            pass
    return txn
