"""Unrelated generic adults get a concrete identity, without changing their scene.

No provider calls, reference uploads, document writes or image analysis here.
The generation record's prompt is the durable history; no global casting state.
"""
import hashlib
import re

FACES = (
    'a broad oval face, gently arched brows and a short straight nose',
    'a long rectangular face, straight brows and a narrow gently curved nose',
    'a rounded face with full cheeks, softly angled brows and a small rounded nose',
    'a heart-shaped face with high cheekbones, wide-set eyes and a tapered nose',
    'a square face with a broad lower face, deep-set eyes and a straight medium-width nose',
    'a narrow oval face, close-set eyes and a prominent gently curved nose',
    'a wide face with low cheekbones, hooded eyes and a softly rounded nose',
    'an oblong face with a high forehead, rounded brows and a short upturned nose',
    'a compact oval face, almond-shaped eyes and a broad straight nose',
    'an angular face with pronounced cheekbones, straight brows and a narrow nose',
    'a pear-shaped face with full lower cheeks, round eyes and a small straight nose',
    'a softly rectangular face with a broad forehead, curved brows and a rounded nose',
)
WOMEN_HAIR = ('loose shoulder-length curls', 'a short textured pixie cut',
    'straight collarbone-length hair with a side part', 'a chin-length blunt bob with a fringe',
    'wavy hair loosely tied at the nape', 'a layered ear-length cut',
    'long loose waves', 'a softly curled shoulder-length cut with a fringe')
MEN_HAIR = ('short side-parted hair', 'close-cropped hair', 'short loose curls',
    'a receding hairline with short hair at the sides', 'medium-length wavy hair',
    'short textured hair brushed forward', 'a closely shaved head', 'swept-back short hair')
MARKER = re.compile(r'GENERIC CAST\[f(\d+)-h(\d+)-c(\d+)\]')
SUBJECT = re.compile(r'\b(?:a|an)\s+(?:[\w-]+\s+){0,5}?(woman|man|lady|gentleman|patient|customer|nurse|doctor|scientist)\b', re.I)
FIXED_HAIR = re.compile(r'\b(hair|haired|hairstyle|haircut|bald|balding|bob|pixie|ponytail|bun|blond\w*|brunette|redhead|curls|fringe)\b', re.I)
FIXED_FACE = re.compile(r'\b(?:oval|round|rounded|long|square|angular|broad|narrow|heart.shaped|rectangular)\s+(?:\w+\s+)?face\b|\b(?:short|long|broad|narrow|rounded|curved|straight|upturned|prominent)\s+nose\b|\b(?:high|low|prominent)\s+cheekbones\b|\b(?:arched|straight|thick|curved)\s+brows?\b', re.I)
SAME_PERSON = re.compile(r'(?<!not the )\b(?:same|previous|continuing)\s+(?:woman|man|person|couple|family|patient)\b', re.I)

def eligible(scene):
    return not any(scene.get(k) for k in ('pure', 'no_cast', 'testimonial', 'tcard_id',
        'speaker_clip', 'cast', 'refs', 'cont_of', 'split')) and not SAME_PERSON.search(scene.get('prompt') or '')

def _seed(value):
    return int(hashlib.sha256(str(value).encode('utf8')).hexdigest()[:16], 16)

def _history(scene):
    records = ((scene.get('image') or {}).get('generation_records') or {})
    if not isinstance(records, dict): return []
    out = []
    for record in records.values():
        if isinstance(record, dict):
            out.extend(tuple(map(int, m)) for m in MARKER.findall(record.get('sent_prompt') or ''))
    return out

def identity(scene, hair_colours, scenes=()):
    """Choose independently of scene numbering; rerolls avoid old/nearby faces.

    Compare against existing recorded choices, and stable choices for ungenerated
    neighbours. Only this scene gets a new choice, even during parallel generation.
    """
    uid = str(scene.get('uid') or scene.get('id') or 'generic')
    attempt = len((scene.get('image') or {}).get('versions') or [])
    seed = _seed(uid)
    own = _history(scene)
    indexed = list(scenes)
    pos = next((i for i, s in enumerate(indexed) if str(s.get('uid') or s.get('id')) == uid), -1)
    neighbours = indexed[max(0, pos-3):pos] + indexed[pos+1:pos+4] if pos >= 0 else []
    previous = own[-4:]
    for other in neighbours:
        if not eligible(other): continue
        history = _history(other)
        previous += history[-1:] or [(_seed(other.get('uid') or other.get('id')) % len(FACES),
            (_seed(other.get('uid') or other.get('id')) // 17) % 8, -1)]
    choices = []
    for offset in range(len(FACES)):
        face = (seed + attempt * 5 + offset) % len(FACES)
        hair = (seed // 17 + attempt * 3 + offset) % 8
        colour = (seed // 97 + attempt + offset) % max(1, len(hair_colours))
        score = sum(8*(face == f) + 2*(hair == h) + (colour == c) for f,h,c in previous)
        choices.append((score, offset, (face,hair,colour)))
    return min(choices)[2]

def cue(scene, hair_colours=(), scenes=()):
    if not eligible(scene): return ''
    text = scene.get('prompt') or ''
    match = SUBJECT.search(text)
    if not match: return ''  # no invention of a person in object/anatomy shots
    role = match.group(1).lower()
    if re.search(r'\b(child|girl|boy|baby|teenager)\b', text, re.I): return ''
    face, hair, colour = identity(scene, hair_colours, scenes)
    details = []
    if not FIXED_FACE.search(text): details.append(FACES[face])
    if not FIXED_HAIR.search(text):
        styles = MEN_HAIR if role in ('man','gentleman') else WOMEN_HAIR
        # Ungendered professionals must not be assigned female hair by default.
        if role in ('woman','lady','man','gentleman'):
            details.append(styles[hair])
        if hair_colours: details.append(hair_colours[colour] + ' hair')
    if not details: details.append('the exact facial features and hairstyle already specified in the scene')
    return (f' GENERIC CAST[f{face}-h{hair}-c{colour}]: For the first unnamed {role} described in this shot, '
        'use this distinct, ordinary adult identity only where appearance is unspecified: ' + '; '.join(details) + '. '
        'Keep the stated age, gender, body condition, ethnicity constraints, clothing, action and camera. '
        'A stated facial condition, including sagging, remains visible and takes priority over these neutral face features. '
        'Other people already required by the scene have their own visibly different facial proportions; '
        'do not copy this person onto a clinician, relative or bystander. Never add a person, expose an off-camera face, '
        'or change a named/reference identity. Do not beautify or caricature these features. The casting code is metadata, never visible text.')
