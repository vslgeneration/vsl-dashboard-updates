"""Visible provider browser for human verification; no Dashboard API or challenge solver."""
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import json
import os
import subprocess
import sys
import threading
import time
import uuid

import stock_cancel
import web_image_search as images

_guard = threading.RLock()
_lanes = {}
_processes = {}
_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def _read(path):
    try: return json.loads(Path(path).read_text('utf8'))
    except (OSError, ValueError): return {}


def _write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False), 'utf8'); os.replace(tmp, path)
    finally: tmp.unlink(missing_ok=True)


def session_enabled(profile):
    return _read(Path(profile)/'session-enabled.json').get('enabled') is True


def matching_page(provider, url, query, page):
    try:
        p = urlsplit(images.validate_url(url, resolve=False))
        if not images._search_host(provider, p.hostname): return False
        q = parse_qs(p.query)
        if provider == 'google':
            return p.path == '/search' and q.get('q') == [query] and (q.get('udm') == ['2'] or q.get('tbm') == ['isch']) and int(q.get('start', ['0'])[0]) == (page-1)*images.PAGE_SIZE
        return p.path.rstrip('/') in ('/images/search','/gorsel/search') and q.get('text') == [query] and int(q.get('p', ['0'])[0]) == page-1
    except (ValueError, TypeError): return False


def search(profile, provider, query, page=1, aspect='any', cancelled=None, progress=None, activate=False):
    """One explicit query/page. Closing Find Stock never cancels this owner-bound job."""
    profile = Path(profile).resolve()
    if provider not in images.PROVIDERS or not query.strip() or type(page) is not int or not 1 <= page <= 1000:
        raise ValueError('Choose a valid image search.')
    if not activate and not session_enabled(profile): raise images.SearchError(provider, 'blocked')
    query = query.strip()[:160]
    with _guard: lane = _lanes.setdefault(str(profile), threading.Lock())
    while not lane.acquire(timeout=.15):
        images._check(cancelled)
        if progress: progress('Waiting for '+images.LABELS[provider]+' browser…')
    target = None
    try:
        images._check(cancelled); profile.mkdir(parents=True, exist_ok=True)
        ident = uuid.uuid4().hex; target = profile/'requests'/ident
        target.mkdir(parents=True, exist_ok=True)
        command = dict(id=ident, provider=provider, query=query, page=page, aspect=aspect,
                       url=images.search_url(provider, query, page))
        _write(profile/'command.json', command)
        if activate: _write(profile/'session-enabled.json', {'enabled':True})
        with _guard:
            proc = _processes.get(str(profile))
            if proc is None or proc.poll() is not None:
                python = Path(sys.executable)
                if python.with_name('pythonw.exe').exists(): python = python.with_name('pythonw.exe')
                with (profile/'browser.log').open('ab') as log:
                    proc = subprocess.Popen([str(python), str(Path(__file__).resolve()), str(profile)],
                        stdout=log, stderr=log, creationflags=_NO_WINDOW)
                _processes[str(profile)] = proc
        deadline = time.monotonic()+600
        while True:
            images._check(cancelled, deadline)
            result = _read(target/'result.json')
            if result.get('id') == ident:
                if result.get('error'): raise images.SearchError(provider, result['error'] if result['error'] in ('blocked','closed','changed','timeout') else 'unavailable')
                # The remote page cannot supply files or API calls. Revalidate every returned URL and size.
                rows = []
                for item in result.get('items', [])[:images.MAX_RESULTS]:
                    try:
                        checked = images.validate_item(item)
                        if checked['provider'] == provider and images._aspect(checked, aspect): rows.append(checked)
                    except (ValueError, TypeError): pass
                return dict(items=rows, warnings=[], page=page, has_more=result.get('has_more') is True,
                    search_url=command['url'], minimum_dimensions=dict(longest=images.MIN_LONG, shortest=images.MIN_SHORT))
            if proc.poll() is not None: raise images.SearchError(provider, 'closed')
            status = _read(target/'progress.json')
            label = 'Complete verification in '+images.LABELS[provider]+'…' if status.get('state') == 'verification' else 'Reading '+images.LABELS[provider]+' results…'
            if progress: progress(label)
            time.sleep(.3)
    except TimeoutError: raise images.SearchError(provider, 'timeout') from None
    finally:
        if target is not None: _write(target/'cancel.json', {'cancelled':True})
        lane.release()


def main(profile):
    import webview
    profile = Path(profile).resolve(); command = _read(profile/'command.json')
    provider = command.get('provider')
    if provider not in images.PROVIDERS: return 2
    webview.settings['ALLOW_FILE_URLS'] = False
    webview.settings['ALLOW_DOWNLOADS'] = False
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER'] = True
    window = webview.create_window(images.LABELS[provider], html='<html><body>Opening image search…</body></html>',
        width=1120, height=800, min_size=(720,520), js_api=None)
    stopped = threading.Event(); current = {'id':None, 'done':False, 'unread_since':None}; handlers=[]

    def valid(cmd):
        return (cmd.get('provider') == provider and isinstance(cmd.get('id'),str) and len(cmd['id']) == 32
            and all(c in '0123456789abcdef' for c in cmd['id'])
            and isinstance(cmd.get('query'),str) and cmd['query'].strip() and type(cmd.get('page')) is int
            and 1 <= cmd['page'] <= 1000 and cmd.get('url') == images.search_url(provider,cmd['query'],cmd['page']))

    def closing():
        stopped.set()
        if current['id'] and not current['done']:
            _write(profile/'requests'/current['id']/'result.json', {'id':current['id'],'error':'closed'})

    window.events.closed += closing

    def boot():
        # Restrict remote navigation without exposing an application bridge.
        try:
            from System import Action
            def navigation(sender, args):
                try:
                    url=str(args.Uri)
                    if url == 'about:blank': return
                    p=urlsplit(images.validate_url(url,resolve=False))
                    if not images._search_host(provider,p.hostname): args.Cancel=True
                except Exception: args.Cancel=True
            def no_download(sender,args): args.Cancel=True
            def no_popup(sender,args): args.Handled=True
            ready=threading.Event()
            def attach():
                core=control.CoreWebView2
                if core is None: return
                core.NavigationStarting += navigation
                core.DownloadStarting += no_download
                core.NewWindowRequested += no_popup
                core.Settings.AreHostObjectsAllowed=False
                core.Settings.IsWebMessageEnabled=False
                core.Settings.AreDevToolsEnabled=False
                core.Settings.IsPasswordAutosaveEnabled=False
                core.Settings.IsGeneralAutofillEnabled=False
                ready.set()
            for _ in range(60):
                try:
                    browser=window.native.browser;control=browser.webview
                    control.Invoke(Action(attach))
                except Exception: pass
                if ready.is_set(): break
                if stopped.wait(.25): return
            if not ready.is_set(): raise RuntimeError('Browser did not initialize.')
            handlers.extend((navigation,no_download,no_popup))
        except Exception:
            # Fail closed if the provider-only boundary could not be installed.
            _write(profile/'requests'/command['id']/'result.json', {'id':command['id'],'error':'unavailable'})
            window.destroy();return
        while not stopped.is_set():
            cmd=_read(profile/'command.json')
            if cmd.get('action') == 'close' and cmd.get('provider') == provider:
                window.destroy();return
            if valid(cmd) and cmd['id'] != current['id']:
                current.update(id=cmd['id'],done=False,unread_since=None);window.show();window.load_url(cmd['url'])
            if current['id'] and not current['done']:
                target=profile/'requests'/current['id']
                if _read(target/'cancel.json').get('cancelled'):
                    current['done']=True;window.hide()
                else:
                    try:
                        snapshot=window.evaluate_js('({url:location.href,html:document.documentElement.outerHTML})')
                        if isinstance(snapshot,dict):
                            url=snapshot.get('url','');html=snapshot.get('html','')
                            if isinstance(html,str) and len(html)<=images.MAX_HTML:
                                if images.verification_required(provider,html,url):
                                    current['unread_since']=None
                                    _write(target/'progress.json',{'state':'verification'})
                                elif matching_page(provider,url,cmd['query'],cmd['page']):
                                    _write(target/'progress.json',{'state':'reading'})
                                    try: result=images.page_results(provider,html,url,cmd['query'],cmd['page'],cmd.get('aspect','any'))
                                    except images.SearchError:
                                        if current['unread_since'] is None:current['unread_since']=time.monotonic()
                                        elif time.monotonic()-current['unread_since']>20:
                                            _write(target/'result.json',{'id':cmd['id'],'error':'changed'});current['done']=True
                                    else:
                                        _write(target/'result.json',dict(result,id=cmd['id']));current['done']=True;window.hide()
                    except Exception: pass
            stopped.wait(.75)
    webview.start(boot, gui='edgechromium', private_mode=False, storage_path=str(profile/'session'))
    return 0


if __name__ == '__main__': raise SystemExit(main(sys.argv[1]))
