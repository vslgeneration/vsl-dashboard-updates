"""Required first-mention labels for the project's ingredient roster. No AI or I/O.

Only explicit names/aliases count; an attached reference, a prompt, or one generic
word in a compound ingredient name must never invent a spoken introduction.
"""
import re
import unicodedata
import roster_identity


def tokens(text):
    # Keep original offsets so labels use the script's language/spelling, including
    # elisions and hyphens. Diacritics and typographic punctuation do not hide names.
    folded = []; starts = []; ends = []
    for i, char in enumerate(str(text or '')):
        normalized = ''.join(c for c in unicodedata.normalize('NFKD', char.casefold())
                             if not unicodedata.combining(c))
        if not normalized and ends:
            ends[-1] = i+1
        for c in normalized:
            folded.append(c); starts.append(i); ends.append(i+1)
    result = []
    for m in re.finditer(r"[^\W_]+\+?", ''.join(folded), re.UNICODE):
        result.append((m.group(), starts[m.start()], ends[m.end()-1]))
    return result


def key(text):
    return tuple(t[0] for t in tokens(text))


def _names(row):
    name = str(row.get('name') or '').strip()
    aliases = row.get('aliases') or []
    if isinstance(aliases, str): aliases = [aliases]
    labels = [name] + [a for a in aliases if isinstance(a, str)]
    # Explicit slash alternatives and short parenthesized names/acronyms. Do not
    # turn explanatory parentheses ("supports healthy skin") into an alias.
    for label in list(labels):
        labels.extend(p.strip() for p in label.split('/') if p.strip())
        base = re.split(r'\(', label)[0].strip()
        if base: labels.append(base)
        labels.extend(p.strip() for p in re.findall(r'\(([^()]*)\)', label)
                      if len(key(p)) == 1 and len(p.strip()) >= 2)
    keys = set().union(*(roster_identity.keys(n, 'ingredient', row) for n in labels))
    for group in roster_identity._GROUPS:
        if keys.intersection(roster_identity.keys(group[0], 'ingredient')):
            labels.extend(group)
    return sorted({k for n in labels if (k := key(n))}, key=lambda k: (-len(k), k))


def _entries(doc):
    entries = []
    for i, row in enumerate(doc.get('ingredients') or []):
        if not isinstance(row, dict) or not str(row.get('name') or '').strip(): continue
        # A deliberately split roster reference represents each named component.
        parts = [p.strip() for p in row['name'].split('/') if p.strip()]
        components = parts if row.get('split') is True and len(parts) > 1 else [row['name']]
        for j, name in enumerate(components):
            item = dict(row, name=name)
            if len(components) > 1: item['aliases'] = []
            entries.append(dict(identity=(str(row.get('id', i)), j), name=name,
                                aliases=_names(item)))
    return entries


def _matches(text, aliases):
    rows = tokens(text); words = [t[0] for t in rows]
    found = []
    for alias in aliases:
        for i in range(len(rows)-len(alias)+1):
            if tuple(words[i:i+len(alias)]) == alias:
                found.append((rows[i][1], rows[i+len(alias)-1][2]))
    return sorted(set(found), key=lambda p: (p[0], -(p[1]-p[0])))


def first_mentions(doc):
    """First named scene that permits OST, in timeline order (not numeric id).

    Speaker/testimonial cards remain protected. If a name is first spoken there,
    its first subsequent ordinary named scene is eligible. No labels are moved to
    an unrelated line. Shared/ambiguous aliases are not used to guess identities.
    """
    entries = _entries(doc); seen = set(); result = {}
    for scene in doc.get('scenes') or []:
        if scene.get('speaker_clip') or scene.get('testimonial'): continue
        text = str(scene.get('vo') or '')
        candidates = []
        for entry in entries:
            for a,b in _matches(text, entry['aliases']):
                candidates.append((a,b,entry))
        # Prefer a full chemical name over a shorter roster name contained in it.
        candidates = [(a,b,e) for a,b,e in candidates
                      if not any(c <= a and b <= d and (c,d) != (a,b)
                                 for c,d,_ in candidates)]
        chosen = []
        for a,b,entry in sorted(candidates, key=lambda x:(x[0], -(x[1]-x[0]))):
            identity = entry['identity']
            if identity in seen: continue
            peers = [e for c,d,e in candidates if (c,d)==(a,b)]
            # Exact same names in duplicate roster rows describe one label. A
            # shared alias of distinct entries needs a full name, not a guess.
            if len({key(e['name']) for e in peers}) > 1:
                exact = [e for e in peers if key(e['name']) == key(text[a:b])]
                if len(exact) != 1 or exact[0]['identity'] != identity: continue
            seen.add(identity)
            if any(key(x['text']) == key(text[a:b]) for x in chosen): continue
            chosen.append(dict(text=text[a:b], name=entry['name'], aliases=entry['aliases']))
        if chosen: result[scene['id']] = chosen
    return result


def covered(texts, requirement):
    return any(_matches(text, requirement['aliases']) for text in texts)


def missing(scene, requirements):
    texts = [o.get('onscreen', '') for o in scene.get('overlays') or []] if scene.get('ost_on') else []
    return [r for r in requirements if not covered(texts, r)]


def wrap_name(text, max_chars=20, max_lines=2):
    """Soft limits: retain every word and never split a name's word in half."""
    words = str(text).split()
    if not words: return ''
    max_chars = max(6, int(max_chars)); max_lines = max(1, int(max_lines))
    lines = []; line = ''
    for word in words:
        candidate = (line+' '+word).strip()
        if line and len(candidate) > max_chars and len(lines) < max_lines-1:
            lines.append(line); line=word
        else: line=candidate
    return '\n'.join(lines+[line])


def place_new(overlays, existing, width, height):
    """Keep manual positions; choose free callout slots for additional names."""
    occupied = []
    for o in existing:
        x=float(o.get('ost_x') or 0); y=float(o.get('ost_y') or 0)
        if o.get('ost_place') == 'top': y -= height*.32
        elif o.get('ost_place') == 'bottom': y += height*.32
        occupied.append((x,y))
    candidates = [(0,-height*.32),(0,height*.32),(0,0),(-width*.26,0),(width*.26,0),
                  (-width*.26,-height*.24),(width*.26,-height*.24),
                  (-width*.26,height*.24),(width*.26,height*.24)]
    for o in overlays:
        x,y = max(candidates, key=lambda p:min(((p[0]-q[0])/width)**2+((p[1]-q[1])/height)**2
                                               for q in occupied)) if occupied else (0,0)
        o.update(ost_place='center', ost_x=round(x), ost_y=round(y))
        occupied.append((x,y))
