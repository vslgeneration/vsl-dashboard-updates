' Put a proper AI Dashboard icon on the Desktop.
'
' Windows Smart App Control blocks the unsigned PyInstaller exe, which is why the app is started
' through the signed Python interpreter instead - and a .vbs cannot carry an icon of its own. A
' SHORTCUT can: it points at the same signed interpreter and wears vsllogo.ico, so the app gets its
' own icon on the Desktop without turning any security off.
'
' Double-click this once on each computer. Safe to run again - it just rewrites the shortcut.

Option Explicit
Dim sh, fso, here, root, target, script, icon, lnk, desktop, made

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

here = fso.GetParentFolderName(WScript.ScriptFullName)

' Works whether this sits in the VSLDashboard folder or inside app\ (where an update puts it).
If fso.FolderExists(fso.BuildPath(here, "runtime")) Then
  root = here
Else
  root = fso.GetParentFolderName(here)
End If

target = fso.BuildPath(root, "runtime\pythonw.exe")
script = fso.BuildPath(root, "app\desktop.py")
icon   = fso.BuildPath(root, "app\vsllogo.ico")

If (Not fso.FileExists(target)) Or (Not fso.FileExists(script)) Then
  MsgBox "Could not find the app next to this file." & vbCrLf & vbCrLf & _
         "Keep 'Create Desktop Icon.vbs' inside the VSLDashboard folder (or in its app folder) " & _
         "and run it again.", 48, "AI Dashboard"
  WScript.Quit
End If

desktop = sh.SpecialFolders("Desktop")
made = ""

' one on the Desktop, one beside the app so it can be found again later
Dim places, i
places = Array(fso.BuildPath(desktop, "AI Dashboard.lnk"), fso.BuildPath(root, "AI Dashboard.lnk"))
For i = 0 To UBound(places)
  On Error Resume Next
  Set lnk = sh.CreateShortcut(places(i))
  lnk.TargetPath = target
  lnk.Arguments = """" & script & """"
  lnk.WorkingDirectory = fso.BuildPath(root, "app")
  lnk.Description = "AI Dashboard"
  If fso.FileExists(icon) Then lnk.IconLocation = icon & ", 0"
  lnk.WindowStyle = 7                       ' the interpreter's console stays out of the way
  lnk.Save
  If Err.Number = 0 Then made = made & vbCrLf & places(i)
  Err.Clear
  On Error GoTo 0
Next

If made = "" Then
  MsgBox "The shortcut could not be created. Try running this file as administrator.", 48, "AI Dashboard"
Else
  MsgBox "Done. AI Dashboard is on your Desktop now:" & made & vbCrLf & vbCrLf & _
         "Open the app from that icon from now on.", 64, "AI Dashboard"
End If
