"""Validate the actual main response model, not aggregate web-tool usage.

Protocol: https://code.claude.com/docs/en/headless#stream-responses
Assistant envelopes identify their model and parent_tool_use_id. Aggregate usage
may also include internal search helpers. Never infer the final model from usage.
"""
import json
import re

def parse(text, expected):
    try:
        events=[json.loads(line) for line in text.splitlines() if line.strip()]
    except (ValueError,TypeError):
        raise ValueError('Could not verify the Claude web response stream.') from None
    if not events or any(not isinstance(e,dict) for e in events) or events[-1].get('type')!='result':
        raise ValueError('Claude web search ended without a complete result.')
    result=events[-1]
    if result.get('is_error') or result.get('subtype','success')!='success':return result,[]
    if sum(e.get('type')=='result' for e in events)!=1:
        raise ValueError('Claude web search returned ambiguous final results.')
    main=[e for e in events if e.get('type')=='assistant' and e.get('parent_tool_use_id') is None]
    if not main or any(e.get('error') or e.get('aborted') for e in main):
        raise ValueError('Could not verify the completed main Claude web response.')
    models=[];texts=[]
    for event in main:
        message=event.get('message') or {};model=message.get('model')
        if not isinstance(model,str) or not re.fullmatch(re.escape(expected)+r'(?:-\d{8})?',model):
            raise ValueError('Claude web search used a different or unidentified main model. Its response was not used.')
        models.append(model)
        content=message.get('content')
        if not isinstance(content,list):raise ValueError('Claude web response has no verifiable content.')
        answer=''.join(c.get('text','') for c in content if isinstance(c,dict) and c.get('type')=='text')
        if answer.strip():texts.append(answer.strip())
    if not texts or not isinstance(result.get('result'),str) or texts[-1]!=result['result'].strip():
        raise ValueError('Claude web result did not match its verified main response.')
    usage=result.get('modelUsage')
    if not isinstance(usage,dict) or not all(m in usage for m in models):
        raise ValueError('Could not verify the model record in the Claude web response.')
    # Leave the ordinary strict result parser in place. Only verified main models
    # are its input; preserve auxiliary names separately for honest diagnostics.
    auxiliary=sorted(set(usage)-set(models))
    return dict(result,modelUsage={m:usage[m] for m in set(models)}),auxiliary
