"""Shared, explicit visual-choice guidance. Local reads only; never infer taste from a trial click."""
import copy,json,threading
from pathlib import Path
import editorial_preferences as ep

GUIDANCE='''
VISUAL DECISION PRIORITIES (apply to AI direction and stock selection):
First decide what the viewer must actually SEE to understand this line. Preserve that visible action,
object or expression before flexible wardrobe, setting or camera details. A meal-plan line may need a
legible plan, not just someone near food. Separate must-show evidence, things to avoid and flexible details.
Respect the editor's intended later overlay/cross: showing the rejected activity can be useful; do not
automatically replace it with a generic sad person. Never invent an overlay intention or medical proof.
Preserve faces, outfits and props across actual continuation scenes; plan the shared outfit before the
first shot. A character reference establishes identity, not a mandatory outfit in every unrelated setting.
Allow concrete object details or generic people when a recurring character is not needed. Explicit scene
instructions and RAW/PURE win; project preferences override global defaults. Transfer only the relevant
technique from examples, not their product, person, claims or outfit. A correction to expression alone
does not mean the composition/action was bad. Unknown visible details remain uncertain.
'''
SCOPES={'scene','project','global'}
LOCK=threading.RLock();CACHE={}

def mode(scene):return 'PURE' if scene.get('pure') else 'RAW' if scene.get('no_cast') else 'AUTO'

def detail(value,doc,scene,project):
 if value is None:return None
 if not isinstance(value,dict):raise ValueError('Invalid visual preference.')
 out={}
 for key in ('keep','change'):
  text=value.get(key,'')
  if not isinstance(text,str) or len(text)>400:raise ValueError('Keep and Change allow up to 400 characters each.')
  out[key]=text.strip()
 scope=value.get('scope','scene')
 if scope not in SCOPES:raise ValueError('Choose where this feedback applies.')
 vo=str(scene.get('vo') or '').strip()
 if scope!='scene':
  if not out['change']:raise ValueError('Describe the change before remembering it for similar scenes.')
  if not vo or ep._normalized(vo) not in ep._normalized(str(doc.get('script') or '')) or str(scene.get('note') or '').strip():
   raise ValueError('This scene is not a confirmed script example. Save feedback for This Scene instead.')
 if not any(out.values()):return None
 return dict(out,scope=scope,project=project,uid=scene['uid'],vo=vo,mode=mode(scene),ptype='vsl')

def read_rows(folder):
 folder=Path(folder).resolve()
 if not folder.exists():return []
 # Used by existing model workers, never by Library typing or status polling.
 with LOCK:
  paths=sorted(folder.glob('*.json'));stamp=tuple((p.name,p.stat().st_mtime_ns,p.stat().st_size) for p in paths)
  cached=CACHE.get(str(folder))
  if cached and cached[0]==stamp:return copy.deepcopy(cached[1])
  rows=[]
  for p in paths:
   try:
    saved=json.loads(p.read_text(encoding='utf-8'))
    for key,row in (saved.get('items') or {}).items():
     pref=row.get('preference') if isinstance(row,dict) else None
     if not isinstance(pref,dict) or pref.get('scope') not in SCOPES or pref.get('mode') not in ('AUTO','RAW','PURE'):continue
     if not all(isinstance(pref.get(k),str) for k in ('project','uid','vo','keep','change','ptype')):continue
     if len(pref['keep'])>400 or len(pref['change'])>400:continue
     rows.append(dict(row,id=p.stem+':'+key))
   except (OSError,ValueError,TypeError,AttributeError):continue
  CACHE[str(folder)]=(stamp,rows)
  if len(CACHE)>12:CACHE.pop(next(iter(CACHE)))
  return copy.deepcopy(rows)

def context(folder,doc,project,vo):
 if (doc.get('ptype') or 'vsl')!='vsl':return ''
 segments=ep._segments(vo)
 if not segments:return ''
 rows=read_rows(folder);selected=[]
 for line in segments:
  matching=[s for s in doc.get('scenes',[]) if ep._normalized(str(s.get('vo') or ''))==ep._normalized(line)]
  modes={mode(s) for s in matching} or {'AUTO'}
  for row in rows:
   p=row['preference'];scope=p.get('scope')
   if scope not in SCOPES or p.get('ptype')!='vsl' or p.get('mode') not in modes:continue
   if scope!='global' and p.get('project')!=project:continue
   if scope=='scene':
    if ep._normalized(p.get('vo',''))!=ep._normalized(line):continue
    if matching and p.get('uid') not in {s.get('uid') for s in matching}:continue
   else:
    example=dict(id=row['id'],ptype='vsl',vo=p.get('vo',''),prompt=p.get('change',''))
    if not ep._rank_examples(dict(example_ids=[row['id']]),'vsl',line,[example]):continue
   if row['id'] in {r['id'] for r in selected}:continue
   selected.append(row)
 selected.sort(key=lambda r:({'scene':0,'project':1,'global':2}[r['preference']['scope']],r['id']))
 if not selected:return ''
 evidence=[]
 for row in selected[:4]:
  p=row['preference'];evidence.append(dict(applies_to_narration=p['vo'],scope=p['scope'],recorded_mode=p['mode'],
   keep=p['keep'],change=p['change'],rejected_reason=row.get('label'),chosen_alternative=row.get('chosen')))
 return '\nEDITOR-EXPLAINED VISUAL CORRECTIONS: apply only to matching narration/purpose and recorded mode. Keep and Change refer to separate attributes. A chosen alternative is evidence, not a universal style rule; obey explicit current instructions first.\n'+json.dumps(evidence,ensure_ascii=False)

def requirements(plan):
 value=plan.get('requirements') or {};out={}
 if not isinstance(value,dict):return out
 for key in ('must_show','avoid','flexible'):
  rows=value.get(key,[])
  if isinstance(rows,list):out[key]=[r.strip()[:180] for r in rows if isinstance(r,str) and r.strip()][:3]
 return out

def scene_feedback(rows):
 out=[]
 for row in rows[-6:]:
  value={k:row.get(k) for k in ('asset','title','reason','label')}
  if row.get('preference'):value.update({k:row['preference'].get(k,'') for k in ('keep','change')})
  out.append(value)
 return out
