"""
VSL Scene Dashboard — local control panel for the script -> prompt -> image -> video pipeline.

Everything is driven by one file per project: projects/<name>/scenes.json
Both this app and Claude Code read/write that file, so prompts authored in Claude Code
show up here instantly, and edits made here are visible to Claude Code.

Run:  python app.py    ->  http://localhost:8000
"""
import os, re, json, time, hashlib, io, threading, shutil, zipfile, subprocess, uuid, tempfile
from urllib.parse import quote as _urlquote, unquote as _urlunquote, urlparse as _urlparse
from pathlib import Path
from datetime import datetime, timedelta
import requests
from PIL import Image
from flask import Flask, request, jsonify, send_file, abort, render_template, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import premiere_export
import suno_music
import render_video

# The dashboard runs windowless (pythonw), so every child process would otherwise pop up
# its own console — a black box flashing over the screen once per ffmpeg/ffprobe call.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

BASE = Path(__file__).resolve().parent
# All user-writable data (projects, keys, login, voices) lives under DATA_DIR. It defaults to BASE
# so a plain dev checkout is unchanged; the packaged desktop app sets VSL_DATA_DIR to its portable
# data/ folder so everything the user creates stays in one place next to the .exe.
DATA_DIR = Path(os.environ["VSL_DATA_DIR"]).resolve() if os.environ.get("VSL_DATA_DIR") else BASE
DATA_DIR.mkdir(parents=True, exist_ok=True)
ENV_PATH = (DATA_DIR / ".env") if os.environ.get("VSL_DATA_DIR") else (BASE.parent / ".env")   # API keys
PROJECTS = DATA_DIR / "projects"
PROJECTS.mkdir(exist_ok=True)
# Background music is now the SUNO library (AI-generated instrumentals) — the old Envato "Background Music"
# folder is intentionally NO LONGER USED. This lives under DATA_DIR so it's writable and grows with each
# generation. _ensure_suno_lib() creates the per-mood folders and seeds them from the bundled "Suno Seed/".
BGM_ROOT = DATA_DIR / "Suno Music"
_SUNO_SEED = BASE / "Suno Seed"           # bundled starter tracks copied into the library on first run
SUNO_PLAN_VERSION = 11                    # bump to force old cached music_plans to re-segment with new logic
MUSIC_SHIFT_SEC = 1.783                   # push every music transition LATER by this (1s 47f @60fps); was entering too early

# ---- config / secrets -------------------------------------------------------
def load_env():
    env = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env

def write_env(updates):
    """Update/insert KEY=VALUE lines in the .env, preserving every other line (comments, spacing,
    unrelated keys). Used by the in-app API-keys editor so a new user can plug in their own keys."""
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    seen, out = set(), []
    for line in lines:
        s = line.strip()
        if s and not s.startswith("#") and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in updates:
                out.append(f"{k}={updates[k]}"); seen.add(k); continue
        out.append(line)
    for k, v in updates.items():
        if k not in seen:
            out.append(f"{k}={v}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")

ENV = load_env()

# ---- local login (no internet / no domain needed) ---------------------------
# auth.json lives next to the app (part of the copied folder). The admin sets per-person
# credentials by editing it; passwords typed in plaintext are hashed on first load, so the
# file ends up storing only hashes. A random session secret is generated once and persisted
# so logins survive server restarts.
AUTH_PATH = DATA_DIR / "auth.json"

def _is_hashed(v):
    v = str(v)
    return v.startswith("pbkdf2:") or v.startswith("scrypt:") or v.startswith("argon2")

def load_auth():
    if AUTH_PATH.exists():
        try:
            data = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    else:
        data = {}
    users = data.get("users") or {}
    if not users:                                   # first run: seed a default admin/admin
        users = {"admin": "admin"}
        data["users"] = users
    changed = False
    # hash any plaintext passwords the admin typed by hand
    for u, p in list(users.items()):
        if not _is_hashed(p):
            users[u] = generate_password_hash(str(p))
            changed = True
    if not data.get("secret"):                      # persistent session secret
        data["secret"] = os.urandom(24).hex()
        changed = True
    if changed or not AUTH_PATH.exists():
        try:
            AUTH_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass
    return data

AUTH = load_auth()

def check_login(username, password):
    h = (AUTH.get("users") or {}).get((username or "").strip())
    if not h:
        return False
    try:
        return check_password_hash(h, password or "")
    except Exception:
        return False

KIE_KEY = ENV.get("KIE_API_KEY", "")
CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
ELEVEN_MODEL = "eleven_multilingual_v2"   # good multilingual quality; matches script language automatically
VOICES_PATH = DATA_DIR / "voices.json"    # frequently-used ElevenLabs voices (name -> voice_id); user-editable → data
OST_PRESETS_PATH = DATA_DIR / "ost_presets.json"   # saved on-screen-text style presets (shared across projects)

KIE_BASE = "https://api.kie.ai/api/v1/jobs"
IMAGE_MODEL = "nano-banana-2"
# selectable per-scene image model families (label shown in the UI dropdown). Each family
# auto-resolves to a text-to-image or image-to-image Kie model id depending on whether the
# scene has reference images — see build_kie_image_request().
IMAGE_MODELS = [
    {"key": "nano-banana-2", "label": "NanoBanana 2"},
    {"key": "gpt-image-2", "label": "GPT Image 2"},
    {"key": "seedream-5-pro", "label": "Seedream 5.0 Pro"},
]
IMAGE_MODEL_KEYS = {m["key"] for m in IMAGE_MODELS}
IMAGE_MODELS_READY = IMAGE_MODEL_KEYS     # all wired

def build_kie_image_request(family, prompt, refs, aspect="16:9", resolution="2K"):
    """Map a dropdown model family (+ whether refs exist) to the exact Kie model id and input
    body. Reference images -> image-to-image variant; none -> text-to-image. `aspect` (default 16:9)
    lets callers request 1:1 / 9:16 etc.; `resolution` = "2K" / "4K" (nano & gpt)."""
    refs = refs or []
    has = bool(refs)
    res = resolution if resolution in ("2K", "4K") else "2K"
    if family == "gpt-image-2":
        if has:
            return "gpt-image-2-image-to-image", {"prompt": prompt, "input_urls": refs[:16], "aspect_ratio": aspect, "resolution": res}
        return "gpt-image-2-text-to-image", {"prompt": prompt, "aspect_ratio": aspect, "resolution": res}
    if family == "seedream-5-pro":
        if has:
            return "seedream/5-pro-image-to-image", {"prompt": prompt, "image_urls": refs[:10], "aspect_ratio": aspect, "quality": "high", "output_format": "png"}
        return "seedream/5-pro-text-to-image", {"prompt": prompt, "aspect_ratio": aspect, "quality": "high", "output_format": "png"}
    # default: nano-banana-2 (one model id, optional image_input)
    inp = {"prompt": prompt, "aspect_ratio": aspect, "resolution": res, "output_format": "png"}
    if has:
        inp["image_input"] = refs
    return "nano-banana-2", inp
# ---- video models --------------------------------------------------------
# Each family: durations (seconds the model supports) + resolutions, so the UI can adapt
# the dropdowns per model. `api` = which endpoint/flow to use ("jobs" = unified createTask,
# "veo" = the separate /api/v1/veo endpoint). `id` = the Kie model id (or veo model tier).
VIDEO_MODELS = [
    {"key": "seedance-2-mini", "label": "Seedance 2.0 Mini", "id": "bytedance/seedance-2-mini", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2-fast", "label": "Seedance 2.0 Fast", "id": "bytedance/seedance-2-fast", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2", "label": "Seedance 2.0", "id": "bytedance/seedance-2", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p", "1080p", "4k"], "defaultDur": 5, "defaultRes": "1080p"},
    {"key": "veo-3-1", "label": "Veo 3.1", "id": "veo3_fast", "api": "veo",
     "durations": [4, 6, 8], "resolutions": ["720p", "1080p", "4k"], "defaultDur": 8, "defaultRes": "1080p"},
    {"key": "grok-imagine", "label": "Grok Imagine", "id": "grok-imagine/image-to-video", "api": "jobs",
     "durations": [6, 8, 10, 12, 15, 20, 25, 30], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-1-5-pro", "label": "Seedance 1.5 Pro", "id": "bytedance/seedance-1.5-pro", "api": "jobs",
     "durations": [4, 6, 8, 10, 12], "resolutions": ["480p", "720p", "1080p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "kling-2-1-standard", "label": "Kling 2.1 Standard", "id": "kling/v2-1-standard", "api": "jobs",
     "durations": [5, 10], "resolutions": ["720p"], "defaultDur": 5, "defaultRes": "720p"},
    {"key": "kling-2-6", "label": "Kling 2.6", "id": "kling-2.6/image-to-video", "api": "jobs",
     "durations": [5, 10], "resolutions": ["720p"], "defaultDur": 5, "defaultRes": "720p"},
    {"key": "grok-video-1-5", "label": "Grok Imagine Video 1.5", "id": "grok-imagine-video-1-5-preview", "api": "jobs",
     "durations": [4, 6, 8, 10, 12, 15], "resolutions": ["480p", "720p", "1080p"], "defaultDur": 6, "defaultRes": "1080p"},
]
VIDEO_MODEL_BY_KEY = {m["key"]: m for m in VIDEO_MODELS}
DEFAULT_VIDEO_MODEL = "grok-video-1-5"    # Grok Imagine Video 1.5 @ 1080p, 6s, static camera (user's chosen default)
VIDEO_CONFIGURED = True

def _clamp_video_opts(cfg, duration, resolution):
    dur = duration if duration in cfg["durations"] else cfg["defaultDur"]
    res = resolution if resolution in cfg["resolutions"] else cfg["defaultRes"]
    return dur, res

def build_video_request(model_key, img_url, prompt, duration, resolution):
    """Return (api_type, model_id, payload) for the chosen video model. jobs -> {model,input}
    body for kie_create; veo -> flat body for /api/v1/veo/generate."""
    cfg = VIDEO_MODEL_BY_KEY.get(model_key) or VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
    dur, res = _clamp_video_opts(cfg, duration, resolution)
    mid = cfg["id"]
    if cfg["api"] == "veo":
        return "veo", mid, {"prompt": prompt, "imageUrls": [img_url], "model": mid,
                            "aspect_ratio": "16:9", "resolution": res, "duration": dur}
    if model_key == "grok-imagine":
        return "jobs", mid, {"prompt": prompt, "image_urls": [img_url], "mode": "normal",
                             "duration": str(dur), "resolution": res, "aspect_ratio": "16:9"}
    if model_key == "kling-2-1-standard":   # input: image_url (string), duration "5"/"10", no resolution
        return "jobs", mid, {"prompt": prompt, "image_url": img_url, "duration": str(dur),
                             "negative_prompt": "blur, distort, low quality", "cfg_scale": 0.5}
    if model_key == "kling-2-6":            # input: image_urls (array), sound bool, duration "5"/"10", no resolution
        return "jobs", mid, {"prompt": prompt, "image_urls": [img_url], "sound": False, "duration": str(dur)}
    if model_key == "seedance-1-5-pro":     # input: input_urls (array), aspect_ratio, resolution 480/720/1080, duration NUMBER
        return "jobs", mid, {"prompt": prompt, "input_urls": [img_url], "aspect_ratio": "16:9",
                             "resolution": res, "duration": int(dur), "generate_audio": False}
    if model_key == "grok-video-1-5":       # Grok Imagine Video 1.5 preview: image_urls array, resolution, duration NUMBER, no audio
        return "jobs", mid, {"prompt": prompt, "image_urls": [img_url], "aspect_ratio": "16:9",
                             "resolution": res, "duration": int(dur)}
    # seedance 2.x family (mini / fast / 2)
    return "jobs", mid, {"prompt": prompt, "first_frame_url": img_url, "generate_audio": False,
                         "duration": dur, "resolution": res, "aspect_ratio": "16:9"}

def kie_veo_create(payload):
    def _do():
        r = requests.post("https://api.kie.ai/api/v1/veo/generate",
                          headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                          json=payload, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"].get("taskId"), None
    return None, d.get("msg", "unknown error")

def kie_veo_record(task_id):
    def _do():
        r = requests.get("https://api.kie.ai/api/v1/veo/record-info", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=60)
        return r.json()
    return _retry(_do)

# Prompt generation runs through Kie.ai's Anthropic-native Claude endpoint,
# so it uses the SAME KIE_API_KEY — no separate Anthropic key needed.
KIE_CLAUDE_URL = "https://api.kie.ai/claude/v1/messages"
# Quality-first, right-tool-per-task:
#  - SMART_MODEL = Fable 5 (Anthropic's most capable model) for the single hardest pass (whole-script
#    analyze). Thinking is always on and can run long, but it's one call per split, so it pays off.
#  - PROMPT_MODEL = Opus 4.8 for everything high-volume/fast (split cut, camera, per-scene image/video
#    prompt, music). Fable there would make "Generate All" very slow and can return empty on tight budgets.
PROMPT_MODEL = "claude-opus-4-8"
SMART_MODEL = "claude-fable-5"

# Per-scene visual style. The preset text below is injected into the image prompt as the "how it looks"
# layer (medium + lighting + composition + quality); the scene text stays style-free so they can't conflict.
STYLE_KEYS = ["natural", "2d", "scientific"]
DEFAULT_STYLE = "natural"   # every new/split scene starts Realistic; the user flips it per scene as needed
STYLE_PRESETS = {
    "natural": "Photorealistic but candid and slightly amateur — like a real everyday photo taken by an ordinary person on a normal phone or consumer camera, NOT a polished stock photo and NOT a studio shot. Natural available light only (window or ordinary room light), soft and a little uneven, no studio lighting or softboxes, gentle real-world shadows. A slightly imperfect, candid feel, as if a quick real snapshot — but FOLLOW whatever shot framing/composition is specified separately (this LOOK does not decide the framing). Natural true-to-life colors, not over-saturated or heavily color-graded. Real ordinary people (not models) with authentic skin texture — visible pores, fine lines, minor blemishes; absolutely no skin smoothing, airbrushing, or retouching. Believable, unposed, documentary/candid snapshot feel. Avoid glossy stock-photo perfection, studio lighting, cinematic color grading, and flawless model faces.",
    "2d": "2D cartoon illustration in a modern Western TV / adult-animation explainer style (a clean, friendly cartoon still). BOLD, clean, evenly-weighted dark outlines around every shape; FLAT colors with simple soft cel-shading (a few gentle gradient bands, NOT realistic rendering); soft glossy highlights on rounded or curved surfaces. Warm, friendly, slightly muted palette. Characters are simplified and expressive with large clear cartoon eyes and clean simple features. COMPOSITION (important): place the subject on a plain solid WHITE background, centered and isolated, with ONLY the one or two props essential to the action — NO full detailed room, NO busy scenery, NO edge-to-edge environment, no floor/wall/furniture filling the frame. Leave generous empty white space around the subject — a clean, uncluttered explainer frame. The ONLY exception, where a detailed full-frame illustration may cover the whole background, is anatomical / inside-the-body / organ / cellular / medical-diagram content — render THOSE as a clean CARTOON cross-section with the same bold outlines, flat cel-shading and soft glowing accents (still a cartoon, not a realistic render). Clean hand-drawn / vector cartoon look — NOT photorealistic, NOT a 3D CGI render, NOT a photo.",
    "scientific": "Photorealistic 3D CGI medical / anatomical visualization — the look of a high-end medical stock animation still (a Blender/Cinema-4D render), NOT a diagram, NOT a cartoon, NOT a real photo. Hyper-detailed, realistically 3D-rendered anatomy with glossy, wet, sub-surface-scattering surfaces, realistic materials, soft reflections, and cinematic lighting with a shallow depth of field (background softly blurred). Two typical looks: (1) a specific organ (brain, heart, liver, gut…) glowing luminously inside a translucent, semi-transparent X-RAY-like body silhouette on a dark, moody background; or (2) a rich CLOSE-UP of internal biology — blood vessels / arteries in cross-section, flowing red blood cells, fat cells, cholesterol / plaque, gut bacteria — with translucent membranes, warm golden or clinical-blue tones, and gentle glowing highlights on the area of interest. Deep, dimensional, premium science-documentary feel with soft shadows and depth. NOT flat, NOT hand-drawn, NOT a 2D illustration, NOT a photograph of a real person.",
}

# Camera framing/angle. The scene prompt itself stays framing-free (see PROMPT_SYSTEM); the chosen
# angle's phrasing is appended to the final image prompt so it can't conflict. A few common,
# sensible angles only.
CAMERA_ANGLES = [
    {"key": "closeup", "label": "Close-up",          "prompt": "Framed as a CLOSE-UP shot: the camera is pushed in TIGHT on the main subject (a face or a single key detail), which fills most of the frame. Crop in close — the wider setting and any secondary people fall largely out of frame. This tight framing is REQUIRED and OVERRIDES the scene's default wider composition; reframe closer even if the scene reads as broader."},
    {"key": "extreme", "label": "Extreme Close-up",  "prompt": "Framed as an EXTREME CLOSE-UP (macro): the camera is EXTREMELY tight on ONE small detail, and that single detail FILLS THE ENTIRE FRAME. Crop out everything else — no wider scene, no room, no other people, no background context; only the one detail is visible, edge to edge. This is REQUIRED and OVERRIDES the scene's default composition; reframe drastically closer even if the described scene is much broader."},
    {"key": "medium",  "label": "Medium Shot",       "prompt": "Framed as a MEDIUM shot at a moderate distance: a PERSON shown from roughly the waist up, or — if the subject is an OBJECT/PRODUCT — the whole object shown at mid-distance with a little of its immediate surroundings (not cropped in tight). Even if a reference photo is a tighter close-up or a wider crop, REFRAME to this moderate medium distance."},
    {"key": "wide",    "label": "Wide Shot",         "prompt": "Framed as a WIDE establishing shot: ZOOM OUT so the WHOLE subject is seen from a distance — a PERSON full-length head-to-toe, or an OBJECT/PRODUCT shown in full — with plenty of the surrounding environment/room around it; the subject occupies only a modest part of the frame. This framing is REQUIRED — even if a reference photo is a close/tight crop, reframe WIDE and do NOT crop in to a close or medium shot."},
    {"key": "ots",     "label": "Over the Shoulder", "prompt": "Framed as an over-the-shoulder shot: the camera looks past the shoulder of ONE of the people ALREADY described in this scene toward whoever they are facing. Use ONLY those people — do NOT add, invent or insert any extra or anonymous person, and do NOT put a stranger's back in the foreground; the foreground shoulder MUST belong to one of the existing subjects. If the scene has only one person, keep a normal framing instead of forcing this."},
    {"key": "top",     "label": "Top View",          "prompt": "Shot from a top-down overhead angle, looking straight down on the scene (bird's-eye view)."},
    {"key": "side",    "label": "Side View",         "prompt": "Shot from a side profile angle, with the camera at ninety degrees to the subject."},
]
CAMERA_ANGLES_BY_KEY = {c["key"]: c for c in CAMERA_ANGLES}
CAMERA_KEYS = [c["key"] for c in CAMERA_ANGLES]
DEFAULT_CAMERA = "medium"

# Per-scene transition: how this scene hands off to the NEXT one (preview + render; not the Premiere XML).
TRANSITIONS = ["none", "crossfade", "dip-black", "dip-white"]   # slides removed (never carried into Premiere well)
DEFAULT_TRANSITION = "none"

# Country -> language used for any visible text/signage in generated images
COUNTRY_LANG = {
    "United States": "English", "United Kingdom": "English", "Canada": "English", "Australia": "English",
    "Ireland": "English", "New Zealand": "English",
    "France": "French", "Belgium": "French", "Switzerland": "French",
    "Germany": "German", "Austria": "German",
    "Spain": "Spanish", "Mexico": "Spanish", "Argentina": "Spanish",
    "Italy": "Italian", "Portugal": "Portuguese", "Brazil": "Portuguese",
    "Netherlands": "Dutch", "Turkey": "Turkish", "Poland": "Polish", "Sweden": "Swedish",
    "Norway": "Norwegian", "Denmark": "Danish", "Finland": "Finnish", "Russia": "Russian",
    "Japan": "Japanese", "China": "Chinese", "Korea": "Korean",
}
def country_language(aud):
    locs = (aud or {}).get("locations") or []
    return COUNTRY_LANG.get(locs[0], "English") if locs else "English"

# Country -> 2-letter Whisper language code for the subtitle forced-aligner (default English).
LANG_CODE = {
    "United States": "en", "United Kingdom": "en", "Canada": "en", "Australia": "en", "Ireland": "en",
    "New Zealand": "en", "France": "fr", "Belgium": "fr", "Switzerland": "fr", "Germany": "de",
    "Austria": "de", "Spain": "es", "Mexico": "es", "Argentina": "es", "Italy": "it", "Portugal": "pt",
    "Brazil": "pt", "Netherlands": "nl", "Turkey": "tr", "Poland": "pl", "Sweden": "sv", "Norway": "no",
    "Denmark": "da", "Finland": "fi", "Russia": "ru", "Japan": "ja", "China": "zh", "Korea": "ko",
}
def audience_lang(aud):
    """2-letter Whisper language code from the audience's first location (default 'en')."""
    locs = (aud or {}).get("locations") or []
    return LANG_CODE.get(locs[0], "en") if locs else "en"

def _align_models(lang):
    """(small, medium) forced-aligner models for a language. English keeps the tuned .en ensemble; any
    other language uses the multilingual variants (small / medium) so French, German, etc. align correctly."""
    return ("small.en", "medium.en") if (lang or "en") == "en" else ("small", "medium")

def looks_turkish(t):
    return any(ch in "çğıışöüÇĞİÖŞÜ" for ch in (t or ""))

def slugify(t, n=40):
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"

def fname_slug(t):
    """Underscore-joined name for output filenames, e.g. 'CitruSlim VSL' -> 'CitruSlim_VSL'."""
    return re.sub(r"[^A-Za-z0-9]+", "_", (t or "").strip()).strip("_") or "project"

def today_ddmmyyyy():
    return datetime.now().strftime("%d%m%Y")

def speaker_slug(voice_id):
    """Map a voice_id back to a saved voice name (underscored), or '' if not a saved voice."""
    for v in load_voices():
        if v.get("voice_id") == voice_id and v.get("name"):
            return fname_slug(v["name"])
    return ""

app = Flask(__name__)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0   # always serve fresh static assets during dev
app.config["TEMPLATES_AUTO_RELOAD"] = True    # pick up index.html edits without restart
# The desktop "Save As" (save_download in desktop.py) authenticates the local /media request with the
# cookie read from document.cookie — which excludes an HttpOnly session cookie, so the download 401'd
# ("login required") on some machines. This is a localhost-only app, so expose the session cookie to JS.
app.config["SESSION_COOKIE_HTTPONLY"] = False
# VSL_FRESH_SESSION (set by the desktop launcher) → a new key every run, so a previous session
# cookie no longer validates and the login gate always shows on launch. Dev/browser keeps the
# persisted key so it stays logged in across server restarts.
app.secret_key = os.urandom(24).hex() if os.environ.get("VSL_FRESH_SESSION") else (AUTH.get("secret") or os.urandom(24).hex())
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)   # stay logged in for a month

# ---- per-user data isolation ------------------------------------------------
# Each account gets its OWN projects + API keys under data/users/<name>/. One user is "active" per
# running instance (the desktop app signs one person in per launch); before_request re-points the
# project/key globals whenever the signed-in user changes, so baran and merih never see each other's
# projects or keys. voices.json / ost_presets.json stay shared (they hold no per-user secrets).
USERS_ROOT = DATA_DIR / "users"
try:
    USERS_ROOT.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

def _safe_user(u):
    return re.sub(r"[^a-zA-Z0-9_-]", "-", (u or "").strip()).strip("-") or "user"

def user_root(u):
    return USERS_ROOT / _safe_user(u)

_ACTIVE_USER = None
_ACTIVE_GUARD = threading.Lock()

def _activate_user(u):
    """Point PROJECTS/ENV_PATH at this user's private folder and reload their API keys. The key
    globals (KIE_KEY, …) are read by name at call time throughout the app, so reassigning them here
    switches every downstream request to the active user's credentials with no restart."""
    global _ACTIVE_USER, PROJECTS, ENV_PATH, ENV, KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY
    root = user_root(u)
    try:
        (root / "projects").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    PROJECTS = root / "projects"
    ENV_PATH = root / ".env"
    ENV = load_env()
    KIE_KEY = ENV.get("KIE_API_KEY", "")
    CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
    CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
    _ACTIVE_USER = u
    global _KEYS_PROJECT
    _KEYS_PROJECT = None                              # force per-project keys to re-activate for the new user

# ---- per-PROJECT API keys ---------------------------------------------------
# Keys live in <project>/keys.json so they travel with export/import — each project carries its own Kie /
# Cloudinary / ElevenLabs credentials, independent of which membership (baran/merih) opens it.
_KEY_ENV_NAMES = ["KIE_API_KEY", "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET", "ELEVENLABS_API_KEY"]
_KEYS_PROJECT = None                                 # name of the project whose keys are currently in the globals

def _proj_keys_path(project):
    d, _safe = proj_dir(project)
    return d / "keys.json"

def _read_proj_keys(project):
    p = _proj_keys_path(project)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return None                                      # None = no keys.json yet (legacy project)

def _write_proj_keys(project, keys):
    d, _safe = proj_dir(project)
    d.mkdir(parents=True, exist_ok=True)
    _proj_keys_path(project).write_text(json.dumps(keys, ensure_ascii=False, indent=2), encoding="utf-8")

def _activate_project_keys(project):
    """Point the key globals at THIS project's keys.json for the current request. A legacy project (no
    keys.json) is migrated once by seeding from the active user's account keys, so nothing breaks; new
    projects start empty and must be filled in Settings -> API Keys."""
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY, _KEYS_PROJECT
    if project == _KEYS_PROJECT:
        return                                       # already active — keep the ref-upload cache warm
    keys = _read_proj_keys(project)
    if keys is None:                                 # migrate legacy project → seed from the user's .env
        keys = {n: ENV.get(n, "") for n in _KEY_ENV_NAMES}
        try:
            _write_proj_keys(project, keys)
        except Exception:
            pass
    KIE_KEY = keys.get("KIE_API_KEY", "")
    CL_CLOUD = keys.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = keys.get("CLOUDINARY_API_KEY", "")
    CL_SECRET = keys.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = keys.get("ELEVENLABS_API_KEY", "")
    _REF_URL_CACHE.clear()                           # ref URLs are per-Cloudinary-account — drop them when switching project
    _KEYS_PROJECT = project

def _keys_ok(need):
    """Guard a generation route: if this project is missing a required key, return a clear error the UI
    turns into a 'add API keys for this project' warning (instead of a confusing provider error later)."""
    miss = []
    if "kie" in need and not KIE_KEY:
        miss.append("Kie")
    if "cloud" in need and not (CL_CLOUD and CL_KEY and CL_SECRET):
        miss.append("Cloudinary")
    if "eleven" in need and not ELEVEN_KEY:
        miss.append("ElevenLabs")
    if miss:
        return jsonify({"error": "This project has no " + " / ".join(miss) + " API key yet. "
                        "Open Settings → API Keys and add it for this project."}), 400
    return None

# Everything requires a local login EXCEPT the login page itself and the static assets it needs
# (CSS/JS/fonts hold no secrets). Page requests redirect to /login; API/media requests get 401.
@app.before_request
def _require_login():
    u = session.get("user")
    if u:
        if u != _ACTIVE_USER:                    # signed-in user changed → point data at their folder
            with _ACTIVE_GUARD:
                if u != _ACTIVE_USER:
                    _activate_user(u)
        proj = (request.view_args or {}).get("project")   # a <project> in the URL → use THAT project's own keys
        if proj:
            try:
                _activate_project_keys(proj)
            except Exception:
                pass
        return None
    # Not logged in: gate only the data endpoints. Pages/static still load so the single-page
    # login gate (rendered inside "/") can show over the home, then reveal it after sign-in.
    if request.path.startswith("/api/") or request.path.startswith("/media/"):
        return ("login required", 401)
    return None

@app.after_request
def _no_cache(resp):
    if request.path == "/" or request.path.startswith("/static/"):
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

_lock = threading.Lock()   # serialize scenes.json writes

# Per-project lock so an endpoint's load→modify→save runs atomically. Without it, the 6s poll
# loop (which does its own load→save) can overwrite a scene that a concurrent Generate just
# marked "generating" with its own stale copy — the second scene appears to start then stop.
_PROJECT_LOCKS = {}
_PROJECT_LOCKS_GUARD = threading.Lock()
def _project_lock(name):
    with _PROJECT_LOCKS_GUARD:
        lk = _PROJECT_LOCKS.get(name)
        if lk is None:
            lk = threading.RLock()
            _PROJECT_LOCKS[name] = lk
        return lk

def _locked(fn):
    """Serialize a route's whole load→modify→save against the 6s poll (which also holds this lock).
    Without it a poll that loaded the doc BEFORE the user's approve/save can write its stale copy back
    afterward and revert the change ('geriye atma'). Applies to every route whose first arg is `project`."""
    import functools
    @functools.wraps(fn)
    def _w(project, *a, **kw):
        with _project_lock(project):
            return fn(project, *a, **kw)
    return _w

# ---- helpers ----------------------------------------------------------------
def proj_dir(name):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", name).strip("-") or "project"
    d = PROJECTS / safe
    return d, safe

def scenes_path(name):
    d, _ = proj_dir(name)
    return d / "scenes.json"

# on-screen text overlay defaults — burned onto preview + render, NOT sent to the image AI.
# Grouped: type / geometry / stroke / background / effects+animation.
# per-overlay style fields (each overlay = onscreen text + these). ost_on is section-level (see norm_scene).
# Default look = the user's saved "Montserrat White" style: Montserrat Extrabold 115px, UPPERCASE,
# centered, white fill, no stroke / no background / no drop shadow, slide-from-bottom in + fade out.
OST_OVERLAY_DEFAULTS = {
    "onscreen": "",
    "ost_fill": True, "ost_color": "#ffffff", "ost_font": "Montserrat", "ost_size": 115, "ost_weight": "800",
    "ost_bold": False, "ost_italic": False, "ost_upper": True, "ost_underline": False,
    "ost_letter": 0, "ost_leading": 0.85,
    "ost_place": "center", "ost_x": 0, "ost_y": 0, "ost_rotation": 0,
    "ost_stroke": False, "ost_stroke_w": 4, "ost_stroke_color": "#000000", "ost_stroke_pos": "outer",
    "ost_bg": False, "ost_bg_color": "#000000", "ost_bg_opacity": 60, "ost_bg_pad": 12, "ost_bg_radius": 8,
    "ost_shadow": False, "ost_shadow_color": "#000000", "ost_shadow_opacity": 80, "ost_shadow_size": 6, "ost_shadow_dir": 135,
    "ost_anim": "slide-bottom", "ost_out_anim": "fade",
    "ost_in": 0.0, "ost_out": 1.0,   # when the text shows, as a fraction of its scene (0=scene start, 1=scene end)
}

def new_overlay():
    return dict(OST_OVERLAY_DEFAULTS)

def _overlay_timeline(ov):
    """Map ONE overlay's ost_* fields to the text_* keys the renderer + preview consume."""
    return {
        "text": (ov.get("onscreen") or "").strip(),
        "text_fill": bool(ov.get("ost_fill", True)),
        "text_color": ov.get("ost_color") or "#ffffff",
        "text_font": ov.get("ost_font") or "Arial",
        "text_size": int(ov.get("ost_size") or 56),
        "text_weight": str(ov.get("ost_weight") or "400"),
        "text_bold": bool(ov.get("ost_bold")),
        "text_italic": bool(ov.get("ost_italic")),
        "text_upper": bool(ov.get("ost_upper")),
        "text_underline": bool(ov.get("ost_underline")),
        "text_letter": int(ov.get("ost_letter") or 0),
        "text_leading": float(ov.get("ost_leading") or 1.15),
        "text_place": ov.get("ost_place") or "top",
        "text_x": int(ov.get("ost_x") or 0),
        "text_y": int(ov.get("ost_y") or 0),
        "text_rotation": int(ov.get("ost_rotation") or 0),
        "text_stroke": bool(ov.get("ost_stroke", True)),
        "text_stroke_w": int(ov.get("ost_stroke_w") or 0),
        "text_stroke_color": ov.get("ost_stroke_color") or "#000000",
        "text_stroke_pos": ov.get("ost_stroke_pos") or "outer",
        "text_bg": bool(ov.get("ost_bg")),
        "text_bg_color": ov.get("ost_bg_color") or "#000000",
        "text_bg_opacity": int(ov.get("ost_bg_opacity") or 0),
        "text_bg_pad": int(ov.get("ost_bg_pad") or 0),
        "text_bg_radius": int(ov.get("ost_bg_radius") or 0),
        "text_shadow": bool(ov.get("ost_shadow", True)),
        "text_shadow_color": ov.get("ost_shadow_color") or "#000000",
        "text_shadow_opacity": int(ov.get("ost_shadow_opacity") or 0),
        "text_shadow_size": int(ov.get("ost_shadow_size") or 0),
        "text_shadow_dir": int(ov.get("ost_shadow_dir") or 0),
        # enforce the on-screen-text animation rule EVERYWHERE (old/manual overlays too): never plain fade-in,
        # never slide-right; the OUT is a FIXED function of the IN (pop->pop, slide-left->slide-left, slide-top/
        # bottom->fade).
        "text_anim": _ost_in_anim(ov.get("ost_anim")),
        "text_out_anim": _OST_OUT_FOR.get(_ost_in_anim(ov.get("ost_anim")), "fade"),
        "text_in": _ost_frac(ov.get("ost_in"), 0.0),      # show window as a fraction of the scene
        "text_out": _ost_frac(ov.get("ost_out"), 1.0),
    }

def _ost_frac(v, default):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, f))

def _scene_overlays(s):
    """List of text_* dicts for a scene's overlays (empty when the section is off)."""
    if not s.get("ost_on"):
        return []
    return [_overlay_timeline(ov) for ov in (s.get("overlays") or []) if (ov.get("onscreen") or "").strip()]

def norm_scene(s):
    """Normalize a scene to the versioned-image model + defaults (backward compatible)."""
    s.setdefault("style", None)
    s.setdefault("no_cast", False)
    s.setdefault("model", IMAGE_MODEL)
    if s.get("model") not in IMAGE_MODEL_KEYS:   # migrate removed/old model keys (e.g. gpt-4o)
        s["model"] = IMAGE_MODEL
    s.setdefault("refs", [])
    s.setdefault("ref_free", [])      # ref paths whose STYLE (clothing/hair) is unlocked (default: locked)
    s.setdefault("cast", [])          # ids of doc.characters present in this scene
    s.setdefault("cont_of", None)     # uid of an earlier scene this one visually continues (same place+people)
    s.setdefault("tcard_id", None)    # id of a linked testimonial_card (this scene mirrors that card's image)
    s.setdefault("camera", DEFAULT_CAMERA)          # camera framing/angle key
    if s.get("camera") not in CAMERA_ANGLES_BY_KEY and s.get("camera") not in ("", None, "none"):
        s["camera"] = DEFAULT_CAMERA   # "none" is a valid choice → no camera-angle text in the prompt
    s.setdefault("transition", DEFAULT_TRANSITION)  # transition into the NEXT scene
    if s.get("transition") not in TRANSITIONS:
        s["transition"] = DEFAULT_TRANSITION
    # on-screen text overlays: migrate legacy flat fields → overlays[0], normalize the list
    fresh = "overlays" not in s
    if fresh:
        s["overlays"] = [{k: s.get(k, OST_OVERLAY_DEFAULTS[k]) for k in OST_OVERLAY_DEFAULTS}]
    if not isinstance(s.get("overlays"), list) or not s["overlays"]:
        s["overlays"] = [new_overlay()]
    for ov in s["overlays"]:
        for k, v in OST_OVERLAY_DEFAULTS.items():
            ov.setdefault(k, v)
        ov["ost_in"] = _ost_frac(ov.get("ost_in"), 0.0)          # show window within the scene, 0..1
        ov["ost_out"] = _ost_frac(ov.get("ost_out"), 1.0)
        if ov["ost_out"] <= ov["ost_in"]:                        # keep at least a sliver visible
            ov["ost_out"] = min(1.0, ov["ost_in"] + 0.05)
    has_text = any((ov.get("onscreen") or "").strip() for ov in s["overlays"])
    if fresh:
        s["ost_on"] = has_text                       # legacy scenes with text migrate to ON
    else:
        s.setdefault("ost_on", has_text)
    for lk in list(OST_OVERLAY_DEFAULTS) + ["onscreen"]:   # drop legacy flat copies (now inside overlays)
        s.pop(lk, None)
    # video model + options (clamp to the selected model's supported values)
    if s.get("video_model") not in VIDEO_MODEL_BY_KEY:
        s["video_model"] = DEFAULT_VIDEO_MODEL
    _vcfg = VIDEO_MODEL_BY_KEY[s["video_model"]]
    if s.get("video_dur") not in _vcfg["durations"]:
        s["video_dur"] = _vcfg["defaultDur"]
    if s.get("video_res") not in _vcfg["resolutions"]:
        s["video_res"] = _vcfg["defaultRes"]
    s.setdefault("video_cam_lock", True)            # image→video keeps the camera static unless the user unlocks it
    s.setdefault("video", {"status": "empty", "taskId": None, "file": None, "error": None})
    s["video"].setdefault("approved", False)
    s["video"].setdefault("api", "jobs")
    img = s.setdefault("image", {})
    if "versions" not in img:
        vers = list(img.get("history") or [])
        if img.get("file"):
            vers.append(img["file"])
        img["versions"] = vers
        img["current"] = len(vers) - 1
    img.setdefault("current", len(img.get("versions", [])) - 1)
    for k, dv in (("status", "empty"), ("taskId", None), ("error", None)):
        img.setdefault(k, dv)
    vs, cur = img.get("versions", []), img.get("current", -1)
    img["file"] = vs[cur] if (vs and 0 <= cur < len(vs)) else None   # "file" = current (shown) version
    av = img.get("approved_version")
    img["approved_file"] = vs[av] if (isinstance(av, int) and 0 <= av < len(vs)) else None
    # MODEL PER VERSION: keep version_models aligned with versions (legacy versions → best-guess = last selection).
    # The DROPDOWN is reconciled to the shown image's model on the FRONTEND at project-open (NOT here) — doing it
    # server-side would also clobber the model the user just picked for the NEXT generation.
    vm = img.setdefault("version_models", [])
    while len(vm) < len(vs):
        vm.append(s.get("model") or IMAGE_MODEL)
    if len(vm) > len(vs):
        del vm[len(vs):]
    return s

def new_uid():
    """A short, permanent per-scene identity. Media files are named by this (NOT the 1..N display id),
    so inserting/splitting/deleting/reordering scenes — which renumbers ids — never renames files,
    never collides two scenes on one filename, and never detaches a video from its scene."""
    return hashlib.md5(f"{time.time()}".encode() + os.urandom(6)).hexdigest()[:8]

def load_doc(name):
    p = scenes_path(name)
    if not p.exists():
        return None
    doc = json.loads(p.read_text(encoding="utf-8"))
    doc.setdefault("characters", [])     # per-project cast: [{id, name, url}]
    doc.setdefault("testimonials", [])   # per-project TESTIMONIAL PEOPLE roster (separate pool from cast): [{id, name, desc, urls}]
    doc.setdefault("testimonial_cards", [])   # written testimonial card drafts: [{id, format, charId, text, extra}]
    doc.setdefault("ingredients", [])    # per-project INGREDIENTS: [{id, name, desc, urls}] — the product's real ingredients, attached (i2i) to ingredient shots
    doc.setdefault("product", {"urls": []})   # per-project PRODUCT reference image(s) — attached (i2i) to scenes flagged show-product
    doc.setdefault("brief", "")          # free-text project brief/context fed to the split + prompt LLM passes
    changed = False
    used = set()
    for s in doc.get("scenes", []):
        u = s.get("uid")
        if not u or u in used:           # one-time migration: give every existing scene a stable uid
            u = new_uid(); s["uid"] = u; changed = True
        used.add(u)
        norm_scene(s)
    # one-time migration: adopt the current default video model (Grok Imagine Video 1.5 @ 6s / 1080p) on EVERY
    # existing scene, so pre-existing projects match the chosen default. Runs ONCE per project (flagged) — after
    # this, any per-scene model/duration/resolution the user picks is preserved on later loads.
    if not doc.get("_vid_default_grok15"):
        _vd = VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
        for s in doc.get("scenes", []):
            s["video_model"] = DEFAULT_VIDEO_MODEL
            s["video_dur"] = _vd["defaultDur"]
            s["video_res"] = _vd["defaultRes"]
        doc["_vid_default_grok15"] = True
        changed = True
    if changed:
        save_doc(name, doc)              # persist the assigned uids / video-default migration once
    return doc

def save_doc(name, doc):
    d, _ = proj_dir(name)
    (d / "images").mkdir(parents=True, exist_ok=True)
    (d / "videos").mkdir(parents=True, exist_ok=True)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    with _lock:
        scenes_path(name).write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

def new_scene(i):
    return {
        "id": i, "uid": new_uid(), "vo": "", "prompt": "", "refs": [], "cast": [], "ingredients": [], "states": {}, "camera": "none", "transition": DEFAULT_TRANSITION, "style": DEFAULT_STYLE, "no_cast": False, "pure": False, "split": False, "testimonial": False, "testimonial_n": 8, "tcard_id": None, "model": IMAGE_MODEL,
        "ost_on": False, "overlays": [new_overlay()],   # on-screen text (section toggle + overlay list)
        "image": {"status": "empty", "taskId": None, "error": None,
                  "versions": [], "current": -1, "file": None, "approved_version": None},
        "approved": False,
        "video_desc": "", "video_prompt": "", "video_cam_lock": True,
        "video_model": DEFAULT_VIDEO_MODEL,
        "video_dur": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultDur"],
        "video_res": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultRes"],
        "video": {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False, "api": "jobs"},
    }

# ---- Cloudinary (for uploading local refs -> public URL for Kie) ------------
def cloudinary_upload(local_path, public_id):
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{CL_SECRET}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    with open(local_path, "rb") as fh:
        r = requests.post(
            f"https://api.cloudinary.com/v1_1/{CL_CLOUD}/image/upload",
            files={"file": fh},
            data={"public_id": public_id, "timestamp": ts, "api_key": CL_KEY, "signature": sig},
            timeout=120,
        )
    d = r.json()
    url = d.get("secure_url")
    # deliver a size-limited PNG so Kie always gets a valid, <25MP image
    if url:
        url = url.replace("/upload/", "/upload/c_limit,w_1600,f_png/")
        url = re.sub(r"\.(webp|jpg|jpeg)$", ".png", url)
    return url

def cloudinary_upload_audio(local_path, public_id):
    """Upload an audio file to Cloudinary (resource_type=video) → public URL Kie can fetch. No transform."""
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{CL_SECRET}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    try:
        with open(local_path, "rb") as fh:
            r = requests.post(
                f"https://api.cloudinary.com/v1_1/{CL_CLOUD}/video/upload",
                files={"file": fh},
                data={"public_id": public_id, "timestamp": ts, "api_key": CL_KEY, "signature": sig},
                timeout=120,
            )
        return (r.json() or {}).get("secure_url")
    except Exception:
        return None

# Reference images are stored LOCALLY on add (fast, no network/quota). Only when a scene is
# actually generated do we upload each local ref to Cloudinary to get the public URL Kie fetches.
_REF_URL_CACHE = {}   # (path, mtime_ns) -> cloudinary url, so a ref uploads at most once per session

def ref_public_url(d, safe, ref):
    """Public URL Kie can fetch for a stored reference. A local path ('refs/…') is uploaded to
    Cloudinary now; an http URL passes through — EXCEPT a Cloudinary URL from a different (old)
    account, which Kie can no longer fetch: we re-upload the local copy to the CURRENT account so
    old references self-heal instead of failing with 'image fetch failed'. Returns None if it can't."""
    if not ref:
        return None
    if ref.startswith("http://") or ref.startswith("https://"):
        if CL_CLOUD and "res.cloudinary.com/" in ref and f"res.cloudinary.com/{CL_CLOUD}/" not in ref:
            local = _local_ref_for_url(d, ref)          # find the on-disk copy by filename
            if local is not None:
                return ref_public_url(d, safe, str(local))   # re-upload it to the new account
        return ref
    p = d / ref
    if not p.is_file():
        p = d / "refs" / Path(ref).name
    if not p.is_file():
        return None
    try:
        key = (str(p), p.stat().st_mtime_ns)
    except OSError:
        key = (str(p), 0)
    if key in _REF_URL_CACHE:
        return _REF_URL_CACHE[key]
    url = cloudinary_upload(p, f"{safe}/refs/{p.stem}")
    if url:
        _REF_URL_CACHE[key] = url
    return url

def resolve_refs(d, safe, refs):
    """Turn stored refs into public URLs for Kie. Raises ValueError if a local ref can't upload
    (e.g. Cloudinary over quota) so generation fails with a clear message instead of silently
    dropping the reference."""
    out = []
    for r in (refs or []):
        u = ref_public_url(d, safe, r)
        if u is None:
            raise ValueError("reference image upload failed (check Cloudinary account)")
        out.append(u)
    return out

# ---- Kie.ai ----------------------------------------------------------------
def _retry(fn, tries=3, base=0.6, cap=5.0):
    """Call fn(); on ANY exception retry up to `tries` times with exponential backoff (capped at `cap`s so a
    high retry count can't explode into minute-long waits). Rides out transient blips / provider 500s.
    Raises the last error only if every attempt fails."""
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            last = e
            if i < tries - 1:
                time.sleep(min(base * (2 ** i), cap))
    raise last

def kie_create(model, inp):
    def _do():
        r = requests.post(f"{KIE_BASE}/createTask",
                          headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                          json={"model": model, "input": inp}, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"]["taskId"], None
    return None, d.get("msg", "unknown error")

def kie_record(task_id):
    # A status check must stay fast: a hung/slow Kie must not make ONE poll occupy a worker for minutes
    # (that was what made Stop/regenerate feel dead while a scene was stuck). Short timeout, few tries.
    def _do():
        r = requests.get(f"{KIE_BASE}/recordInfo", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=20)
        return r.json()
    return _retry(_do, tries=2)

def result_url(record):
    try:
        rj = record["data"].get("resultJson") or ""
        if rj:
            urls = json.loads(rj).get("resultUrls") or []
            if urls:
                return urls[0]
    except Exception:
        pass
    return None

def download_as_png(url, dest_path):
    """Download bytes and save as a *real* PNG regardless of what Kie actually returns.
    Retried so a transient blip doesn't discard an image Kie already generated."""
    def _do():
        r = requests.get(url, timeout=180)
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGB")
        img.save(dest_path, "PNG")
    _retry(_do)

def download_as_mp4(url, dest_path):
    def _do():
        r = requests.get(url, timeout=600, stream=True)
        r.raise_for_status()
        with open(dest_path, "wb") as fh:
            for chunk in r.iter_content(65536):
                fh.write(chunk)
    _retry(_do)

# ---- subtitle / SRT (local forced alignment, no API) -----------------------
# Wraps the tested standalone tool subtitle/vsl_align_srt.py. Runs entirely on
# this machine (stable-whisper + ffmpeg) — no Kie.ai, no Claude Code tokens.
import sys as _sys
SRT_SCRIPT = BASE.parent / "subtitle" / "vsl_align_srt.py"
SUB_STATUS = {}            # {project: {status, step, srt, error, updated}}
SUB_LOCK = threading.Lock()

def sub_dir(name):
    d, _ = proj_dir(name)
    return d / "subtitle"

def sub_status_path(name):
    return sub_dir(name) / "status.json"

def set_sub_status(name, **kw):
    with SUB_LOCK:
        st = SUB_STATUS.get(name, {})
        st.update(kw); st["updated"] = time.time()
        SUB_STATUS[name] = st
    try:
        sub_dir(name).mkdir(parents=True, exist_ok=True)
        sub_status_path(name).write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return st

def get_sub_status(name):
    with SUB_LOCK:
        if name in SUB_STATUS:
            return dict(SUB_STATUS[name])
    p = sub_status_path(name)
    if p.exists():
        try:
            st = json.loads(p.read_text(encoding="utf-8"))
            # A persisted "running" with no live in-process job = the server was restarted mid-job
            # (which kills it). Report it as stopped so the UI never hangs on a dead job, and clear
            # the stale file so it doesn't resurface.
            if st.get("status") == "running":
                st = {"status": "error", "step": "",
                      "error": "Subtitle generation was interrupted (the server restarted). Please run it again."}
                try:
                    p.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
            return st
        except Exception:
            pass
    return {"status": "idle"}

# silence trimming (ffmpeg silenceremove). Each mode = how much gap to KEEP between sentences.
TRIM_MODES = {
    "fast":    {"sd": 0.15, "ss": 0.08},   # aggressive — very tight
    "natural": {"sd": 0.20, "ss": 0.28},   # keep a normal pause
    "slow":    {"sd": 0.25, "ss": 0.45},   # keep a gentle pause
}
def trim_silences(src, dst, mode="natural"):
    """Shorten silences (below -35dB) between sentences to the mode's target gap. Also trims
    leading/trailing silence. Returns True on success."""
    m = TRIM_MODES.get(mode, TRIM_MODES["natural"])
    thr = "-35dB"
    af = (f"silenceremove=start_periods=1:start_threshold={thr}:start_duration=0.1:start_silence=0.05:"
          f"stop_periods=-1:stop_threshold={thr}:stop_duration={m['sd']}:stop_silence={m['ss']}:detection=peak")
    try:
        subprocess.run(["ffmpeg", "-y", "-i", str(src), "-af", af, str(dst)],
                       check=True, capture_output=True, creationflags=_NO_WINDOW)
        return True
    except Exception:
        return False

# live subtitle jobs, so the UI's "⏹ Stop" can kill the running aligner subprocess (+ its child
# whisper/ffmpeg tree) immediately. _SUB_PROCS: project → Popen; _SUB_CANCEL: projects asked to stop.
_SUB_PROCS = {}
_SUB_CANCEL = set()

def _kill_proc_tree(proc):
    if not proc or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           creationflags=_NO_WINDOW, capture_output=True)
        else:
            proc.terminate()
    except Exception:
        pass

def _run_align(name, wd, audio, docx, out, model, vad, step, lang="en"):
    """Run one alignment pass of vsl_align_srt.py as a subprocess (its own CWD = wd,
    so all caches — words_*.tsv, silence_all.log — land in the project subtitle dir)."""
    set_sub_status(name, status="running", step=step, error=None)
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out), VSL_LANG=lang)
    # Run under console python inside a HIDDEN console (not CREATE_NO_WINDOW): the aligner's OWN
    # child processes (whisper's ffmpeg) then inherit that hidden console and never pop a black
    # window. CREATE_NO_WINDOW would leave the parent console-less, so each grandchild ffmpeg
    # allocates its own visible console instead.
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _cand = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_cand):
                exe = _cand
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0   # SW_HIDE
    args = [exe, str(SRT_SCRIPT), model]
    if vad:
        args.append("--vad")
    log_path = wd / "align.log"
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"\n===== {step} =====\n"); log.flush()
        # Popen (not run) so a Stop request can kill this + its child whisper/ffmpeg tree mid-pass.
        proc = subprocess.Popen(args, cwd=str(wd), env=env,
                                stdout=log, stderr=subprocess.STDOUT,
                                startupinfo=si, creationflags=cf)
        _SUB_PROCS[name] = proc
        try:
            proc.wait()
        finally:
            _SUB_PROCS.pop(name, None)
    return proc.returncode

def run_subtitle_job(name, audio, docx, out, trimmed_rel=None, lang="en"):
    """Ensemble flow: small --vad first (builds the secondary cache), then medium --vad which merges it →
    final SRT. English uses the tuned .en models; other languages (fr, de…) use the multilingual variants."""
    wd = sub_dir(name)
    small_m, med_m = _align_models(lang)
    _SUB_CANCEL.discard(name)
    def _cancelled():
        if name in _SUB_CANCEL:
            _SUB_CANCEL.discard(name)
            set_sub_status(name, status="idle", step="", error=None, srt=None)   # user stopped it
            return True
        return False
    try:
        rc = _run_align(name, wd, audio, docx, out, small_m, True, "Synchronizing subtitles…", lang)
        if _cancelled():
            return
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the first pass (exit {rc}); see align.log")
            return
        rc = _run_align(name, wd, audio, docx, out, med_m, True, "Finalizing subtitles…", lang)
        if _cancelled():
            return
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the final pass (exit {rc}); see align.log")
            return
        if not Path(out).exists():
            set_sub_status(name, status="error", error="alignment finished but no SRT was produced; see align.log")
            return
        rel = f"subtitle/{Path(out).name}"
        set_sub_status(name, status="done", step="Done", srt=rel,
                       srt_name=Path(out).name, trimmed=trimmed_rel, error=None)
    except Exception as e:
        set_sub_status(name, status="error", error=str(e))

# ---- routes: auth -----------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    # The login UI is now an overlay inside the home page (single page), submitted via fetch.
    if request.method == "GET":
        return redirect(url_for("index"))
    u = request.form.get("username", "").strip()
    p = request.form.get("password", "")
    if check_login(u, p):
        session.permanent = True
        session["user"] = u
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Wrong username or password."}), 401

@app.route("/logout")
def logout():
    session.clear()
    # Redirect straight to "/" (the home shows the login gate when signed out) and forbid caching —
    # a cached 302 was letting a repeat sign-out skip the server, so the session never cleared.
    resp = redirect("/")
    resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

# ---- routes: pages ----------------------------------------------------------
@app.route("/")
def index():
    static = BASE / "static"
    try:
        v = str(int(max((static / "app.js").stat().st_mtime, (static / "style.css").stat().st_mtime)))
    except Exception:
        v = "1"
    try:
        appver = (BASE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        appver = ""
    return render_template("index.html", v=v, authed=bool(session.get("user")), appver=appver)

# ---- routes: API keys (let a new user plug in their own keys from the UI) ----
_KEY_MAP = {   # UI field -> .env variable
    "kie": "KIE_API_KEY", "cloud_name": "CLOUDINARY_CLOUD_NAME",
    "cloud_key": "CLOUDINARY_API_KEY", "cloud_secret": "CLOUDINARY_API_SECRET",
    "elevenlabs": "ELEVENLABS_API_KEY",
}
@app.route("/api/keys/<project>")
def api_get_keys(project):
    # before_request already activated this project's keys into the globals
    return jsonify({"kie": KIE_KEY, "cloud_name": CL_CLOUD, "cloud_key": CL_KEY,
                    "cloud_secret": CL_SECRET, "elevenlabs": ELEVEN_KEY})

@app.route("/api/keys/<project>", methods=["POST"])
def api_set_keys(project):
    """Save API keys FOR THIS PROJECT (into <project>/keys.json), so they travel with export/import and
    are used whenever this project is open — regardless of which membership opens it."""
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY, _KEYS_PROJECT
    data = request.get_json(force=True) or {}
    updates = {_KEY_MAP[k]: str(data[k]).strip() for k in _KEY_MAP if k in data}
    if not updates:
        return jsonify({"error": "no keys provided"}), 400
    keys = _read_proj_keys(project) or {n: "" for n in _KEY_ENV_NAMES}
    keys.update(updates)
    try:
        _write_proj_keys(project, keys)
    except Exception as e:
        return jsonify({"error": f"could not save keys: {e}"}), 500
    KIE_KEY = keys.get("KIE_API_KEY", ""); CL_CLOUD = keys.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = keys.get("CLOUDINARY_API_KEY", ""); CL_SECRET = keys.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = keys.get("ELEVENLABS_API_KEY", "")
    _REF_URL_CACHE.clear()
    _KEYS_PROJECT = project
    return jsonify({"ok": True})

# ---- Kie.ai credit balance + a small spend ledger (real spend = the drop between balance snapshots) ----
KIE_CREDIT_URL = "https://api.kie.ai/api/v1/chat/credit"

def _ledger_path():
    return DATA_DIR / "credit_ledger.json"     # global, shared across users/projects (keyed by the account key)

def _read_ledger():
    p = _ledger_path()
    if p.exists():
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return {}
    return {}

def _write_ledger(d):
    try: _ledger_path().write_text(json.dumps(d), encoding="utf-8")
    except Exception: pass

def _key_hash():
    return hashlib.md5(KIE_KEY.encode()).hexdigest()[:10] if KIE_KEY else None

def fetch_kie_balance():
    def _do():
        r = requests.get(KIE_CREDIT_URL, headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=30)
        d = r.json()
        if d.get("code") == 200 and isinstance(d.get("data"), (int, float)):
            return float(d["data"])
        raise RuntimeError(d.get("msg") or "could not read balance")
    return _retry(_do, tries=3)

@app.route("/api/credits/<project>")
def api_credits(project):
    """Live Kie.ai balance for THIS project's key, plus a spend history derived from balance snapshots.
    Each check appends a {t, balance} snapshot to a per-account ledger; the drop between snapshots = spend."""
    if not KIE_KEY:
        return jsonify({"keyPresent": False})
    try:
        bal = fetch_kie_balance()
    except Exception as e:
        return jsonify({"keyPresent": True, "error": str(e)}), 502
    kh = _key_hash()
    now = int(time.time())
    led = _read_ledger()
    arr = led.get(kh, [])
    # record a snapshot when the balance moved, or the last one is older than 20s (throttle duplicates)
    if not arr or abs(arr[-1].get("balance", -1) - bal) >= 0.001 or (now - arr[-1].get("t", 0)) > 20:
        arr.append({"t": now, "balance": bal})
        arr = arr[-80:]
        led[kh] = arr
        _write_ledger(led)
    spends = []
    for i in range(1, len(arr)):
        drop = arr[i - 1]["balance"] - arr[i]["balance"]     # positive = credits spent
        if drop >= 0.001:
            spends.append({"t": arr[i]["t"], "spent": round(drop, 2), "balance": round(arr[i]["balance"], 2)})
    spends.reverse()                                          # newest first
    total_tracked = round(sum(s["spent"] for s in spends), 2)
    return jsonify({"keyPresent": True, "balance": round(bal, 2), "history": spends[:25],
                    "tracked_spend": total_tracked, "since": (arr[0]["t"] if arr else now)})

# ---- routes: translate VO lines to Turkish (faint reference under each scene's sentence) ----
_TRANSLATE_SYSTEM = (
    "You are a professional translator. Translate each numbered line into natural, faithful Turkish. "
    "Preserve meaning and tone; do not add or omit content. Return ONLY a JSON array of strings — one "
    "Turkish translation per input line, in the SAME order and SAME count. No commentary, no numbering."
)

@app.route("/api/translate", methods=["POST"])
def api_translate():
    data = request.get_json(force=True) or {}
    texts = data.get("texts") or []
    source = (data.get("source") or "").strip()
    if not isinstance(texts, list) or not texts:
        return jsonify({"translations": []})
    numbered = "\n".join(f"{i+1}. {str(t)}" for i, t in enumerate(texts))
    user = (f"Source language: {source}.\nTranslate to Turkish:\n{numbered}" if source
            else f"Translate to Turkish:\n{numbered}")
    try:
        arr = _parse_json_array(_claude_text(_TRANSLATE_SYSTEM, user, max_tokens=6000))
        trs = [str(x) for x in arr][:len(texts)]
        while len(trs) < len(texts):
            trs.append("")
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"translations": trs})

# ---- routes: sync folder (Google Drive/OneDrive/Dropbox desktop) + export/import ----
# A single machine-level "sync folder" (a folder that a cloud-sync app mirrors between PCs). Export
# writes a project .zip there; the other PC lists + imports those zips. No API keys, no size limits.
APP_CONFIG_PATH = DATA_DIR / "app_config.json"

def _load_config():
    try:
        return json.loads(APP_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_config(cfg):
    try:
        APP_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

def _sync_dir():
    p = (_load_config().get("sync_dir") or "").strip()
    return Path(p) if p else None

@app.route("/api/config")
def api_get_config():
    cfg = _load_config()
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir()),
                    "notif_sound": cfg.get("notif_sound", True)})

@app.route("/api/config", methods=["POST"])
def api_set_config():
    data = request.get_json(force=True) or {}
    cfg = _load_config()
    if "sync_dir" in data:
        cfg["sync_dir"] = str(data["sync_dir"]).strip()
    if "notif_sound" in data:
        cfg["notif_sound"] = bool(data["notif_sound"])
    _save_config(cfg)
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"ok": True, "sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir()),
                    "notif_sound": cfg.get("notif_sound", True)})

_MANIFEST_NAME = "__vsl_manifest__.json"
_MUSIC_PREFIX = "__music__/"            # bundled Background Music tracks live here inside the zip

def _bundled_music(doc):
    """(src_path, arcname) for every Background Music track this project's plan uses — so the export
    is self-contained and plays/renders identically even on a PC that lacks that track."""
    out, seen = [], set()
    for seg in (doc.get("music_plan") or []):
        emo, track = seg.get("emotion"), seg.get("track")
        key = f"{emo}/{track}"
        if emo and track and key not in seen:
            seen.add(key)
            src = BGM_ROOT / emo / track
            if src.exists():
                out.append((src, f"{_MUSIC_PREFIX}{emo}/{track}"))
    return out

_EXPORT_JOBS = {}                        # job_id -> {pct, done, error, file, title, scenes}
_EXPORT_GUARD = threading.Lock()

def _run_export(job_id, d, safe, manifest, sd):
    tmp = sd / (safe + ".zip.part")
    final = sd / (safe + ".zip")
    try:
        files = []                       # (src, arcname) project files under <safe>/…
        for root, _dirs, fns in os.walk(d):
            if "__pycache__" in root:
                continue
            for fn in fns:
                fp = Path(root) / fn
                files.append((fp, str(Path(safe) / fp.relative_to(d))))
        try:
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
        except Exception:
            doc = {}
        files += _bundled_music(doc)     # self-contained: carry the music too
        total = sum(fp.stat().st_size for fp, _ in files) or 1
        written = 0
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED, allowZip64=True) as z:
            z.writestr(_MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
            for fp, arc in files:
                z.write(fp, arc)
                written += fp.stat().st_size
                _EXPORT_JOBS[job_id]["pct"] = min(99, int(written * 100 / total))
        if final.exists():
            final.unlink()
        tmp.replace(final)
        _EXPORT_JOBS[job_id].update(pct=100, done=True, file=final.name)
    except Exception as e:
        try:
            tmp.unlink()
        except Exception:
            pass
        _EXPORT_JOBS[job_id].update(done=True, error=str(e))

@app.route("/api/projects/<project>/export", methods=["POST"])
def api_export_project(project):
    """Kick off a background zip of the project folder (+ its music) into the sync folder as <name>.zip
    (stored = fast copy since media is already compressed). Returns a job id to poll for progress."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    sd = _sync_dir()
    if not sd:
        return jsonify({"error": "no-sync-dir"}), 400
    if not sd.is_dir():
        return jsonify({"error": "sync-dir-missing"}), 400
    try:
        doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
    except Exception:
        doc = {}
    manifest = {"name": safe, "title": doc.get("title", safe), "scenes": len(doc.get("scenes", [])),
                "exported_by": _ACTIVE_USER or "", "exported_at": datetime.now().isoformat(timespec="seconds")}
    job_id = uuid.uuid4().hex
    _EXPORT_JOBS[job_id] = {"pct": 0, "done": False, "error": None, "file": None, "title": manifest["title"]}
    threading.Thread(target=_run_export, args=(job_id, d, safe, manifest, sd), daemon=True).start()
    return jsonify({"ok": True, "job": job_id, "title": manifest["title"]})

@app.route("/api/export-status/<job>")
def api_export_status(job):
    j = _EXPORT_JOBS.get(job)
    if not j:
        return jsonify({"error": "not-found"}), 404
    return jsonify(j)

@app.route("/api/imports")
def api_list_imports():
    """List the project zips sitting in the sync folder (with manifest metadata for the picker)."""
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"sync_ok": False, "items": []})
    items = []
    for zp in sorted(sd.glob("*.zip")):
        info = {"file": zp.name, "title": zp.stem, "name": zp.stem, "scenes": None,
                "exported_by": "", "exported_at": "", "size": zp.stat().st_size}
        try:
            with zipfile.ZipFile(zp) as z:
                if _MANIFEST_NAME in z.namelist():
                    m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                    info.update({"title": m.get("title", info["title"]), "name": m.get("name", info["name"]),
                                 "scenes": m.get("scenes"), "exported_by": m.get("exported_by", ""),
                                 "exported_at": m.get("exported_at", "")})
        except Exception:
            pass
        items.append(info)
    return jsonify({"sync_ok": True, "items": items})

@app.route("/api/imports/delete", methods=["POST"])
def api_delete_import():
    """Delete one export zip from the sync folder (housekeeping from the import window)."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    try:
        if zp.exists():
            zp.unlink()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True})

@app.route("/api/import", methods=["POST"])
def api_import_project():
    """Pull one zip from the sync folder into THIS user's projects. overwrite=True replaces a project
    of the same name (2-PC round-trip); otherwise it's auto-renamed so nothing is clobbered. Bundled
    music (__music__/…) is restored into the local Background Music folder."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))     # basename → no path traversal
    overwrite = bool(data.get("overwrite"))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    if not zp.exists():
        return jsonify({"error": "not-found"}), 404
    base = zp.stem
    try:
        with zipfile.ZipFile(zp) as z:
            if _MANIFEST_NAME in z.namelist():
                m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                base = m.get("name") or base
    except Exception:
        pass
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", base).strip("-") or "project"
    if overwrite and (PROJECTS / safe).exists():
        target = safe                            # replace the existing same-named project
    else:
        target, n = safe, 1
        while (PROJECTS / target).exists():      # never clobber unless explicitly overwriting
            n += 1
            target = f"{safe}-import" + ("" if n == 2 else str(n))
    dest = PROJECTS / target
    tmp = PROJECTS / (target + ".importing")
    try:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(zp) as z:
            for nm in z.namelist():
                if nm == _MANIFEST_NAME:
                    continue
                if nm.startswith(_MUSIC_PREFIX):        # restore bundled music into Background Music/
                    rel = nm[len(_MUSIC_PREFIX):]
                    if not rel or nm.endswith("/"):
                        continue
                    mp = (BGM_ROOT / rel)
                    try:
                        if not mp.exists():             # never overwrite a shipped track
                            mp.parent.mkdir(parents=True, exist_ok=True)
                            with z.open(nm) as src, open(mp, "wb") as f:
                                shutil.copyfileobj(src, f)
                    except Exception:
                        pass
                    continue
                rel = nm.split("/", 1)[1] if "/" in nm else nm   # strip the top folder (original name)
                if not rel:
                    continue
                outp = tmp / rel
                if nm.endswith("/"):
                    outp.mkdir(parents=True, exist_ok=True)
                    continue
                outp.parent.mkdir(parents=True, exist_ok=True)
                with z.open(nm) as src, open(outp, "wb") as f:
                    shutil.copyfileobj(src, f)
        sp = tmp / "scenes.json"                 # retarget the project id to its new folder name
        if sp.exists():
            try:
                jdoc = json.loads(sp.read_text(encoding="utf-8"))
                jdoc["name"] = target
                sp.write_text(json.dumps(jdoc, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                pass
        if dest.exists():                        # overwrite: swap in the fresh copy atomically-ish
            shutil.rmtree(dest, ignore_errors=True)
        tmp.replace(dest)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({"error": str(e)}), 500
    title = target
    try:
        title = json.loads((dest / "scenes.json").read_text(encoding="utf-8")).get("title", target)
    except Exception:
        pass
    return jsonify({"ok": True, "name": target, "title": title, "overwritten": overwrite and dest == PROJECTS / safe})

# ---- routes: projects -------------------------------------------------------
@app.route("/api/projects")
def api_projects():
    out = []
    for d in sorted(PROJECTS.iterdir()):
        if (d / "scenes.json").exists():
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
            out.append({"name": d.name, "title": doc.get("title", d.name),
                        "scenes": len(doc.get("scenes", []))})
    return jsonify(out)

@app.route("/api/projects", methods=["POST"])
def api_create_project():
    body = request.get_json(force=True)
    name = body.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    d, safe = proj_dir(name)
    if (d / "scenes.json").exists():
        return jsonify({"error": "project exists", "name": safe}), 409
    doc = {"name": safe, "title": name, "created": datetime.now().isoformat(timespec="seconds"),
           "audience": body.get("audience", {}), "brief": body.get("brief", ""), "refs": [], "characters": [], "scenes": []}
    save_doc(safe, doc)
    try:
        _write_proj_keys(safe, {n: "" for n in _KEY_ENV_NAMES})   # start EMPTY (no seeding) → user fills keys per project
    except Exception:
        pass
    return jsonify({"name": safe})

@app.route("/api/projects/<project>/rename", methods=["POST"])
def api_rename_project(project):
    """Rename a project's display title (the folder / id stays the same)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    title = (request.get_json(force=True).get("title") or "").strip()
    if not title:
        return jsonify({"error": "title required"}), 400
    doc["title"] = title
    save_doc(project, doc)
    return jsonify({"ok": True, "title": title})

def trash_dir():
    """Per-user recycle bin, sibling of the projects folder so it's never listed as a project."""
    return PROJECTS.parent / "_trash"

def _safe_trash_child(tname):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", tname).strip("-") or "project"
    return trash_dir() / safe, safe

@app.route("/api/projects/<project>", methods=["DELETE"])
def api_delete_project(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    mode = (request.args.get("mode") or "disk").lower()
    if mode == "dashboard":
        # SOFT delete — move the folder into _trash (files stay on disk, fully restorable).
        td = trash_dir(); td.mkdir(parents=True, exist_ok=True)
        title = safe
        try:
            title = json.loads((d / "scenes.json").read_text(encoding="utf-8")).get("title", safe)
        except Exception:
            pass
        dest = td / safe
        n = 2
        while dest.exists():
            dest = td / f"{safe}-{n}"; n += 1
        shutil.move(str(d), str(dest))
        try:
            (dest / "__trashinfo__.json").write_text(json.dumps(
                {"orig": safe, "title": title, "deleted": datetime.now().isoformat(timespec="seconds")}),
                encoding="utf-8")
        except Exception:
            pass
        return jsonify({"ok": True, "mode": "dashboard", "trash": dest.name})
    # HARD delete — remove the folder from disk permanently.
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True, "mode": "disk"})

@app.route("/api/trash")
def api_trash():
    out = []
    td = trash_dir()
    if td.exists():
        for d in sorted(td.iterdir()):
            if not d.is_dir() or not (d / "scenes.json").exists():
                continue
            info = {}
            ip = d / "__trashinfo__.json"
            if ip.exists():
                try: info = json.loads(ip.read_text(encoding="utf-8"))
                except Exception: info = {}
            try:
                doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
                nsc = len(doc.get("scenes", []))
                title = info.get("title") or doc.get("title", d.name)
            except Exception:
                nsc = 0; title = info.get("title") or d.name
            out.append({"name": d.name, "orig": info.get("orig", d.name),
                        "title": title, "scenes": nsc, "deleted": info.get("deleted", "")})
    out.sort(key=lambda x: x.get("deleted", ""), reverse=True)
    return jsonify(out)

@app.route("/api/trash/<tname>/restore", methods=["POST"])
def api_trash_restore(tname):
    d, safe = _safe_trash_child(tname)
    if not (d / "scenes.json").exists():
        abort(404)
    orig = safe
    ip = d / "__trashinfo__.json"
    if ip.exists():
        try: orig = json.loads(ip.read_text(encoding="utf-8")).get("orig", safe)
        except Exception: pass
    dest = PROJECTS / (re.sub(r"[^a-zA-Z0-9_-]", "-", orig).strip("-") or "project")
    base = dest
    n = 2
    while dest.exists():
        dest = base.parent / f"{base.name}-{n}"; n += 1
    shutil.move(str(d), str(dest))
    try: (dest / "__trashinfo__.json").unlink()
    except Exception: pass
    title = dest.name
    try:
        sp = dest / "scenes.json"
        doc = json.loads(sp.read_text(encoding="utf-8"))
        doc["name"] = dest.name
        title = doc.get("title", dest.name)
        sp.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception: pass
    return jsonify({"ok": True, "name": dest.name, "title": title})

@app.route("/api/trash/<tname>", methods=["DELETE"])
def api_trash_delete(tname):
    d, safe = _safe_trash_child(tname)
    if not d.exists():
        abort(404)
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True})

@app.route("/api/projects/<project>/duplicate", methods=["POST"])
def api_duplicate_project(project):
    """Deep-copy a project (all files + scenes.json) into a NEW, fully independent project. The folder
    gets the next -vN version; the display title gets a bumped ' vN'. Editing one never touches the other."""
    src, safe = proj_dir(project)
    if not (src / "scenes.json").exists():
        abort(404)
    doc = load_doc(project)
    # unique folder name: bump a trailing -vN (or add -v2), skipping any that already exist
    m = re.match(r"^(.*?)[-_ ]v(\d+)$", safe, re.I)
    stem, n = (m.group(1), int(m.group(2))) if m else (safe, 1)
    while True:
        n += 1
        new_name = f"{stem}-v{n}"
        if not (PROJECTS / new_name).exists():
            break
    # display title: bump a trailing vN, else append ' v2'
    tm = re.match(r"^(.*?)[-_ ]v(\d+)$", (doc.get("title") or "").strip(), re.I)
    new_title = (f"{tm.group(1).strip()} v{int(tm.group(2)) + 1}" if tm
                 else f"{(doc.get('title') or stem).strip()} v2")
    shutil.copytree(src, PROJECTS / new_name)
    d2 = json.loads((PROJECTS / new_name / "scenes.json").read_text(encoding="utf-8"))
    d2["name"], d2["title"] = new_name, new_title
    (PROJECTS / new_name / "scenes.json").write_text(json.dumps(d2, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"name": new_name, "title": new_title})

# ---- routes: scenes ---------------------------------------------------------
@app.route("/api/scenes/<project>")
def api_get_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    return jsonify(doc)

@app.route("/api/scenes/<project>", methods=["PUT"])
@_locked
def api_save_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    # only allow editable fields to be overwritten from the UI
    incoming = {s["id"]: s for s in body.get("scenes", [])}
    for s in doc["scenes"]:
        u = incoming.get(s["id"])
        if not u:
            continue
        # NOTE: "approved" is intentionally NOT here — it's managed only by the /approve endpoint.
        # Including it let a routine full-doc save (from a text edit) with a stale value clobber a
        # concurrent approve, silently un-approving images.
        # NOTE: "refs" and "ref_free" are intentionally NOT here — like "approved", they are managed ONLY by
        # their dedicated endpoints (add / ref-scene / DELETE ref / ref-lock). Leaving them in let a routine
        # full-doc save (or a racing approve that reassigns DOC) write a stale/empty refs list and silently
        # drop a just-added reference image.
        for f in ("vo", "vo_tr", "note", "prompt", "director_prompt", "cast", "cast_locked", "ingredients", "product", "product_suggested", "split", "split_suggested", "testimonial", "testimonial_n", "tcard_id", "states", "camera", "transition", "cont_of", "video_desc", "video_prompt", "video_cam_lock", "style", "no_cast", "pure", "model", "video_model", "video_dur", "video_res", "ost_on", "overlays", "fx_on", "icon", "sfx", "icon_x", "icon_y", "icon_size", "icons"):
            if f in u:
                s[f] = u[f]
    if "title" in body:
        doc["title"] = body["title"]
    if "script" in body:
        doc["script"] = body["script"]
    if "script_draft" in body:
        doc["script_draft"] = body["script_draft"]   # live, unsaved script text (autosaved before Split) so it survives a restart
    if "audience" in body:
        doc["audience"] = body["audience"]
    if "brief" in body:
        doc["brief"] = body["brief"]
    if "subtitle_style" in body:
        doc["subtitle_style"] = body["subtitle_style"]   # global caption look (applies to all subtitles)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/video-models")
def api_video_models():
    return jsonify(VIDEO_MODELS)

@app.route("/api/scenes/<project>/insert", methods=["POST"])
def api_insert_scene(project):
    """Insert a blank scene after the given id (0 = at the start), then renumber."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    after = request.get_json(force=True).get("after", 0)
    scenes = doc["scenes"]
    idx = 0
    for i, s in enumerate(scenes):
        if s["id"] == after:
            idx = i + 1
            break
    scenes.insert(idx, new_scene(0))
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/duplicate", methods=["POST"])
def api_duplicate_scene(project, sid):
    """Clone a scene (all settings + overlays; the copy shares the original's image/video file
    references — regenerating either later just writes new files, so they never clash) and insert
    it right after, then renumber 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc["scenes"]
    idx = next((i for i, s in enumerate(scenes) if s["id"] == sid), None)
    if idx is None:
        return jsonify(doc)
    copy = json.loads(json.dumps(scenes[idx]))   # deep copy
    copy["uid"] = new_uid()                       # its OWN identity — so regenerating it can't overwrite the original's files
    scenes.insert(idx + 1, copy)
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/delete-scene", methods=["POST"])
def api_delete_scene(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] != sid]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/delete-scenes", methods=["POST"])
def api_delete_scenes(project):
    """Delete several scenes at once (multi-select). Removes all given ids, then renumbers 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = set(request.get_json(force=True).get("ids", []) or [])
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] not in ids]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/reorder", methods=["POST"])
def api_reorder(project):
    """Reorder scenes to the given list of ids, then RENUMBER 1..N (so output filenames follow)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    order = request.get_json(force=True).get("order", [])
    by_id = {s["id"]: s for s in doc["scenes"]}
    new = [by_id[i] for i in order if i in by_id]
    new += [s for s in doc["scenes"] if s["id"] not in order]   # safety: keep any missing
    for i, s in enumerate(new, 1):
        s["id"] = i
    doc["scenes"] = new
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/restore", methods=["POST"])
def api_restore(project):
    """Undo support: replace the editable doc state (scenes/audience/characters/refs/script) from a
    client snapshot and save it wholesale. Keeps name/title/created."""
    cur = load_doc(project)
    if cur is None:
        abort(404)
    snap = request.get_json(force=True) or {}
    for k in ("scenes", "audience", "characters", "product", "refs", "script", "brief"):
        if k in snap:
            cur[k] = snap[k]
    for s in cur.get("scenes", []):
        norm_scene(s)
    save_doc(project, cur)
    return jsonify(cur)

SPLIT_SYSTEM = """You segment a VSL (video sales letter) script into scenes for a video.
Each scene is the chunk of narration (VO) that is spoken while ONE image/clip is on screen.

Rules:
- DEFAULT to ONE sentence per scene — the large majority of scenes are a single sentence.
- EXCEPTION (HIGHEST PRIORITY) — KEEP A WRITTEN CUSTOMER TESTIMONIAL WHOLE: when a stretch is a first-person written review by ONE named customer sharing their own result (e.g. "My name is Lisa, I live in Manchester, and I've lost two stone and I feel amazing again.", 'Helen F. adds: "I've kept the weight off for a year and my energy is back."'), keep that ENTIRE testimonial — EVERY sentence of that one person's quote — as ONE single scene. NEVER split it into sentences or visual beats, even if it is long or lists several results. Each DIFFERENT named customer's testimonial is its OWN one scene. This OVERRIDES all the sentence / visual-beat splitting rules below.
- BREAK A LONG SENTENCE into as MANY scenes as it has DISTINCT VISUAL BEATS — do NOT cap this at two. A single sentence often carries several separate images (clauses/phrases split by commas, dashes, or "and"/"but"), and EACH image a viewer would picture on its own gets its OWN scene, so a rich sentence can become three, four or more scenes. Example: "your skin is firm and glowing, your movements are fluid and easy, as if you've turned the clock back ten years" -> THREE scenes (glowing skin / easy movement / turned back the clock). This is the most important rule — never leave a long, multi-image sentence sitting in one scene.
- BUT do NOT split a sentence that is ONE single continuous action or moment, even if it is long — e.g. "You play with your children or your grandchildren for hours without ever losing your breath." is ONE image -> ONE scene. Cut only where the viewer would genuinely picture a DIFFERENT image.
- When a single sentence lists distinct LIFESTYLE ACTIONS / MOMENTS — separate things a person DOES, e.g. "enjoy meals with family, step on the scales, and go shopping" — split it into ONE scene per action (three or more scenes), because each action is its own little moment that needs its own image.
- When a sentence lists FIVE OR MORE distinct items of any kind (e.g. "your metabolism, your joints, your energy, your heart, and your mind") — split it into ONE scene per item, because five-plus cannot read as side-by-side panels. This applies EVEN when the list is a rhetorical aside inside dashes or parentheses (e.g. "— gym memberships, diets, personal trainers, useless supplements, expensive injections —" -> FIVE scenes, one per item). A list of only TWO to FOUR distinct items/benefits is NOT split — leave it as ONE scene (it becomes side-by-side panels later).
- MERGE two adjacent sentences into ONE scene ONLY when one of them is VERY SHORT (a few words) or a connective fragment that cannot stand on its own as an image — e.g. "And that's when it hit me.", "But it was too late.", "Here's the truth.", "Until now." Attach such a short fragment to the neighbouring sentence it belongs with.
- NEVER MERGE three or more separate sentences into one scene. When merging adjacent sentences, a scene is AT MOST two, and only when one is very short. (This cap is about MERGING; splitting ONE long sentence into several visual-beat scenes, per the rules above, is encouraged and expected.)
- Do NOT change, add, remove, rephrase, reorder, or translate ANY words. Only decide where the cuts go. Keep the original wording, punctuation, and casing exactly.
- Output ONLY the scenes, ONE per line, in order. No numbering, no bullet points, no blank lines, no commentary."""

def split_script(script):
    """Split via Claude (Kie.ai). Raises on failure — NO naive fallback (bad splits)."""
    script = (script or "").strip()
    if not script:
        return []
    text = _claude_text(SPLIT_SYSTEM, script, max_tokens=8000)   # may raise
    parts = [re.sub(r"^\s*\d+[\.\)\-:]\s*", "", ln.strip()) for ln in text.splitlines() if ln.strip()]
    parts = [p for p in parts if p]
    if not parts:
        raise RuntimeError("splitter returned no scenes")
    return parts

def _parse_json_array(text):
    """Best-effort parse of a JSON array from an LLM reply (tolerates ```json fences / stray prose)."""
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("["), t.rfind("]")
    if a < 0 or b < a:
        raise ValueError("no JSON array")
    return json.loads(t[a:b + 1])

# ---- NEW prompt pipeline (whole-script, conflict-free) --------------------------------------------
# 1) CAST DETECTION: read the whole script, list ONLY the recurring/central people so they can be kept
#    consistent (same face/look) across scenes. Generic one-off people are deliberately ignored.
CAST_SYSTEM = """You are a casting director for a VSL (video sales letter) advertisement. Read the ENTIRE script.

Identify ONLY the people who RECUR or are central to the story and therefore must look the SAME every time they appear — a specific named person, a protagonist whose journey we follow, a specific doctor/expert, the first-person narrator if they are ever shown.

IGNORE one-off or generic/background people who do NOT need to stay consistent (crowds, an anonymous passer-by, generic "people who struggle with X", a random patient shown once).

ALSO IGNORE named CUSTOMERS who appear ONLY in a written or first-person customer TESTIMONIAL / review (social proof) — e.g. "My name is Lisa, I've lost two stone…", 'Helen F. adds: "…"', a quoted five-star review by a named buyer. These review-only customers are handled by a SEPARATE testimonial system, so they are NOT story cast. (Keep a person only if they ALSO appear in the main story beyond their testimonial.)

Carefully resolve pronouns and references across the WHOLE script to decide who each "she/he/they" is (the same pronoun can point to different people in different lines — e.g. the doctor in one place, the wife in another).

For EACH recurring person output:
- "label": a short stable name — their name if the script gives one (e.g. "Sophie", "Dr Carbonell"), else their role ("Narrator", "Doctor").
- "role": one or two words (e.g. "wife / patient", "doctor", "narrator").
- "desc": a concise FIXED physical description to keep them consistent (apparent gender, age range, 2-3 key visual traits). Infer sensibly from context; if unknown give a natural default that fits.

Output ONLY a JSON array, nothing else:
[{"label":"Sophie","role":"wife / patient","desc":"woman, 40s, warm but tired, shoulder-length brown hair"}]
If nobody recurs, output []."""


def _detect_cast_raw(script, brief=""):
    """Whole-script cast pass. RAISES on an LLM/parse failure so callers can tell a real error apart from a
    genuine 'nobody recurs' ([]). Use detect_cast() where a silent [] fallback is wanted (e.g. split)."""
    script = (script or "").strip()
    if not script:
        return []
    user = script
    if (brief or "").strip():
        user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
    data = _parse_json_array(_claude_text(CAST_SYSTEM, user, max_tokens=4000, model=PROMPT_MODEL))   # Opus 4.8: cast detection is a simple extraction — near-lossless vs Fable 5, and far fewer Kie overloads
    out, seen = [], set()
    for it in data:
        if not isinstance(it, dict):
            continue
        label = str(it.get("label") or "").strip()
        if not label or label.lower() in seen:
            continue
        seen.add(label.lower())
        out.append({"label": label, "role": str(it.get("role") or "").strip(), "desc": str(it.get("desc") or "").strip()})
    return out

def detect_cast(script, brief=""):
    """Whole-script pass → recurring people [{label, role, desc}]. Never raises (returns [] on any problem)."""
    try:
        return _detect_cast_raw(script, brief)
    except Exception:
        return []

# ---- INGREDIENT DETECTION: the product's real named ingredients, so on-screen ingredient shots use the
#      ACTUAL ones the script talks about (and, once you give each a reference image, they look consistent).
INGREDIENT_SYSTEM = """You read a VSL (video sales letter) advertising script for a health/supplement/food product and list the SPECIFIC INGREDIENTS that make up the advertised product — the real named components the script (or the project context) actually mentions.

Include ONLY concrete, nameable ingredients of the product: a specific fruit, plant, herb, root, seed, extract, vitamin, mineral or compound that the script names (e.g. "Moro blood orange", "green tea extract", "cayenne / red pepper", "L-carnitine").

IGNORE: the finished product itself, generic words ("ingredients", "extracts", "nutrients", "a blend"), body parts, foods the viewer eats, and anything that is not a named component of THIS product.

For EACH ingredient output:
- "name": the ingredient's name as the script/brand uses it (short, e.g. "Moro Blood Orange", "Green Tea").
- "desc": a concise FIXED visual description of the ingredient in its natural/raw form, for a consistent reference image (e.g. "deep-red blood oranges, sliced, showing dark red flesh"). Keep it about the ingredient's real appearance.

Output ONLY a JSON array, nothing else:
[{"name":"Moro Blood Orange","desc":"deep-red blood oranges, some sliced, dark red flesh"}]
If the script names no specific ingredients, output []."""

def _detect_ingredients_raw(script, brief=""):
    script = (script or "").strip()
    if not script:
        return []
    user = script
    if (brief or "").strip():
        user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
    data = _parse_json_array(_claude_text(INGREDIENT_SYSTEM, user, max_tokens=3000, model=PROMPT_MODEL))
    out, seen = [], set()
    for it in data:
        if not isinstance(it, dict):
            continue
        name = str(it.get("name") or "").strip()
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        out.append({"name": name, "desc": str(it.get("desc") or "").strip()})
    return out

def detect_ingredients(script, brief=""):
    """Whole-script pass → the product's named ingredients [{name, desc}]. Never raises ([] on any problem)."""
    try:
        return _detect_ingredients_raw(script, brief)
    except Exception:
        return []

AVATAR_SYSTEM = """From this advertising (VSL) script and context, describe in a SHORT phrase what the TARGET VIEWER — the ordinary/relatable person the ad speaks to — looks like at the START, BEFORE any transformation the product promises.

Focus on the visible starting state relevant to the product (e.g. a weight-loss ad → "overweight, tired middle-aged women"; a skin ad → "older women with wrinkled, tired skin"). Include apparent gender/age band and the key visible condition. Keep it to a few words.

Output ONLY the short phrase — no sentence, no quotes, no explanation. If the script gives no basis, output nothing."""

def detect_avatar(script, brief=""):
    """Short 'target viewer looks like' phrase inferred from the script (for the ordinary/relatable people).
    Never raises ('' on any problem)."""
    try:
        script = (script or "").strip()
        if not script:
            return ""
        user = script if not (brief or "").strip() else ("PROJECT CONTEXT:\n" + brief.strip() + "\n\nSCRIPT:\n" + script)
        txt = _claude_text(AVATAR_SYSTEM, user, max_tokens=60, model=PROMPT_MODEL)
        av = " ".join((txt or "").strip().strip('"').split())[:120]
        return av
    except Exception:
        return ""


# 2) DIRECTOR: ONE whole-script pass that replaces the old camera + analyze + per-scene-prompt passes.
#    For each scene it decides who's present (from the roster), any generic person, the on-screen CONTENT
#    (no camera/appearance/quality words — those are separate layers), camera, transition, continuity, style.
DIRECTOR_SYSTEM = """You are the director of a VSL (video sales letter) ad — a persuasion film, not a slideshow. You get the CAST roster (recurring people, each with a fixed description), an AUDIENCE note, and the full script cut into numbered scenes in order. First read the WHOLE script and map its persuasion arc; then design the single most persuasive IMAGE for each scene.

THINK about the arc first (do NOT output it). A VSL moves through stages — roughly: HOOK (grab attention, break a false belief), AGITATE (stack the pain, make it visceral and specific), ROOT CAUSE (why nothing has worked), ROCK BOTTOM (the emotional low / cost of inaction), SOLUTION (introduce the product/mechanism as the hero), PROOF (results, credibility, social proof), CTA (a calm, confident nudge to act). Infer each scene's role from its position and its line.

Then design each shot to ADVANCE persuasion at that moment — not a literal illustration of the words. Make each image VISUALLY DISTINCT from its neighbours and EMOTIONALLY SPECIFIC:
- Hook: a pattern-interrupt — an unexpected, arresting image that stops the scroll.
- Agitate / rock bottom: make the pain concrete and human — a telling gesture, a small revealing object, a real lived moment (never a generic "worried person in a room").
- Root cause: one simple, striking visual that explains WHY (a comparison, a hidden culprit).
- Solution: make the product/mechanism the clear HERO of the frame — appealing and unmistakable, a clean and premium (never cluttered or amateur) hero moment.
- Proof: something tangible — a result, a before/after, a credential, a real person's genuine reaction.
- CTA: one clear, confident focal subject, uncluttered.
Reach for a concrete object, a specific action, or a simple visual metaphor when it lands harder than a literal scene. VARY the compositions across the video — do not repeat the same setup shot after shot. But stay TRUE to what each scene's line is actually about: never introduce the product, a character, or a claim the line itself doesn't cover (e.g. don't show the product before the script brings it in).

HOUSE STYLE (the standard this account expects — follow it strictly, it reflects how the user rewrites weak shots):
- USE THE NARRATOR SPARINGLY. Put the on-screen narrator/host ONLY in genuine self-introduction beats and direct study citations. For generic sincerity / reassurance / transition / "listen up" lines ("don't worry", "as promised", "pay close attention", "let me explain", "I encourage you to…"), do NOT default to a talking-head of the narrator gesturing at the viewer — show a CONCRETE relatable scene or the topic itself instead. A "narrator holding / presenting the product" shot is almost never the best choice — avoid it.
- LEAD WITH THE VIEWER'S REAL LIFE. Prefer concrete, emotionally specific target-viewer moments — their pain and daily life with telling props (a pill organiser, a blood-pressure cuff, swollen ankles, a wallet with few coins, bills on a table, an empty armchair) — over abstract graphics or narrator shots.
- BEFORE/AFTER & SPLIT-SCREENS ARE PREFERRED (not optional): when a line contrasts two states, or lists 2-4 distinct items/benefits/body-parts, use a 2- or 3-panel split-screen or an explicit before→after; when it lists 5+, one panel per item.
- PRODUCT / PROOF shots: keep a clean hero but ENRICH it with the actual raw INGREDIENT beside the pack, and LOCALISE to the audience's country (local home, courier/parcel, signage, currency). Don't reuse the identical hero framing repeatedly — vary angle/context (macro, in-hand, market, being sliced).
- TANGIBLE OVER ABSTRACT: favour real objects and human moments over cold number/chart graphics; if a statistic must be shown, anchor it to a human (a family, a face) rather than a bare number.
- MATCH THIS LINE EXACTLY — never the previous or next line's idea. A BENEFIT line gets a positive/after image; a WARNING/PROBLEM line gets a problem image; a SOLUTION line gets the fix. Do NOT show the solution on a problem line, or a problem on a benefit line.
- DON'T RE-SHOW AN INGREDIENT/MOLECULE ON ITS BENEFIT LINES. Use a plain ingredient- or molecule-only shot ONLY on the line that first INTRODUCES or NAMES it. Once it has been introduced, for the following lines about its BENEFITS/EFFECTS either (a) SPLIT the frame — the ingredient/molecule on one side, the CONCRETE benefit/result on the other — or (b) drop the ingredient entirely and show the benefit/result itself (the healthier organ, the shrinking fat, the relieved person). Never repeat the same molecule render shot after shot across a run of benefit lines.

CONCRETE, NEVER VAGUE (this is where weak shots come from — avoid these clichés):
- MECHANISM / "how it works" / "targets the root cause" / "burns fat" / "resets metabolism" lines: show a CONCRETE mechanism. E.g. a semi-transparent overweight belly revealing the fat cells inside being surrounded and visibly shrunk/burned by the product's coloured ingredient extracts; or the product with a clear arrow acting directly on the fat cells. Do NOT fall back on a vague "glowing human silhouette", "vitality flowing through the body", sparkles, or an abstract aura.
- LAB / SCIENCE / QUALITY lines ("formulated", "purest", "most concentrated", "tested", "purity", "potency", "rigorous", "third-party", "certified", "small batch", "extraction"): show a clean, meticulous LABORATORY — a gloved scientist/technician doing precise measurements with real instruments; the real ingredients in glass vials/tubes; purity or certificate paperwork. Show ALL the real ingredients the script has introduced up to here, not just one or two. Do NOT show an ordinary person in a kitchen for these lines. A generic scientist/technician's face need not be shown (hands + the work is often stronger).
- SETTING: for a "natural" (realistic) shot NEVER call for a magical glow, radiant aura, halo, light rays, sparkles, "energy" or "vitality" glow effects — keep it a believable real photograph. (Glowing/luminous belongs ONLY to "scientific" style.)
- PRODUCT-CLAIM lines ("100% natural", "vegetarian", "non-GMO", "gluten-free"): show a clean, authentic product hero/mockup in a fitting NATURAL setting (e.g. among greenery) — no person, and NEVER on-image badges/seals/labels for the claims.
- Any capsule/pill you describe (only for the finished pill product) is a plain WHITE OPAQUE capsule.

TARGET VIEWER (very important for a VSL): when the AUDIENCE note gives a "TARGET VIEWER look", the ordinary / relatable stand-in people (NOT the roster cast) must EMBODY that look — and follow the arc like a real before→after story:
- In the HOOK / PROBLEM / AGITATE / ROOT CAUSE / ROCK BOTTOM stages (the "before"), show them in that STARTING state (e.g. if the target look is "overweight, tired", the relatable person is visibly overweight and weary). An abstract line here ("be honest about what this would be worth to you") still shows the BEFORE person.
- From the SOLUTION onward, and in ANY explicit "after / transformed" beat — looking in the mirror slimmer, energetic, playing with the kids without getting tired, a happier lighter life — show them IMPROVED (slimmer, healthier, energised).
You MAY and SHOULD state this body/condition in "shows" (a person's body type / physical condition is allowed to describe; only age, ethnicity, hair and skin are barred). Judge before vs after from the scene's position and its wording.

For EACH scene output an object with:
- "present": the exact CAST labels visually present in this shot. Resolve pronouns/continuity across the whole script (the same "she" can be different people in different lines — read who each refers to). Use ONLY labels from the roster, spelled exactly. [] if only generic/ordinary people, or no person.
- "generic": if the shot shows an ordinary/one-off person who is NOT a roster character, a short description of them; else null. Never put a roster person here. AUDIENCE gender/age/look describes the RELATABLE, stand-in "viewer" people — use it ONLY as the DEFAULT for a person the line leaves unspecified (e.g. audience = women → an unspecified ordinary person is "a tired middle-aged woman at home"). If the sentence ITSELF fixes who the person is — a man, her husband, a father, a male doctor, a boy, or any explicitly-gendered role — depict EXACTLY that gender and NEVER flip them to match the audience. The audience default fills in only the people the line doesn't already gender; it never overrides an explicitly male (or explicitly female) person the script calls for. WHO APPEARS, BY VOICE: a line that ADDRESSES THE VIEWER ("you", "your", "your turn") shows a GENERIC target-viewer person — put them in "generic" and keep "present":[]; do NOT use a recurring roster character (e.g. Sophie, the Narrator) for a generic "you" line. A FIRST-PERSON line the narrator speaks ("I", "me", "my", "we", "our") DOES show the Narrator, and anyone the line names too ("Dr Carbonell and I" → both). Use a named roster character ONLY when the line is spoken by them or explicitly names/refers to them — otherwise prefer a generic target-viewer person. COLLEAGUES / TEAM: when a line names a character AND their colleagues/team/fellow experts ("Dr Carbonell and her colleagues around the world", "and his team", "researchers everywhere") — put the OTHER roster doctors/experts in "present" too (not just the one named), shown together as a group or team, e.g. the named person among several colleagues.
- "shows": the image content — setting + subject + action + the key object(s) — vivid, specific and persuasion-advancing, in ONE or TWO sentences. Be CONCRETE and richly specific, never thin or generic: name the actual PLACE, two or three telling PROPS/objects, and exactly what the person is DOING — never a bare "a woman at home" or "a tired person in a room". VARY THE SETTING across the video: for everyday / relatable / "you" lifestyle lines do NOT keep returning to the same kitchen or living room — move between different rooms (kitchen, living room, bedroom, home office, hallway, dining area) and different everyday places (a park, a street, a cafe, a workplace, a car, a garden, a shop) as the line allows, so consecutive lifestyle shots never look like the same house. CONTENT ONLY: describe WHAT is in the frame, never HOW it is shot. Do NOT mention camera / shot-size / angle / viewpoint, lighting, image quality or medium (photoreal/cartoon/3D/etc.), or a person's age/ethnicity/hair/skin (a roster person's look comes from their reference; refer to them by their label). EXCEPTION — nationality/ethnicity the LINE ITSELF specifies: if the narration explicitly calls for a people's nationality, ethnicity or region (e.g. "des Japonais" / "Japanese people", "a Japanese family", "in Japan", "an Italian grandmother"), you MUST KEEP that word in "shows" (say "Japanese people", "a Japanese family", etc.) — it is essential to the meaning and is the ONE case ethnicity may appear. Honor the AUDIENCE's location/currency for any signage, packaging, or setting.
- "camera": one key from: closeup, extreme, medium, wide, ots, top, side — pick the framing that best serves the shot's emotional job (closeup for an emotional beat / detail, wide to establish a place or group, ots for two people or someone regarding something, medium for one person acting, top for a laid-out comparison, side for movement/profile). FRAMING COHERENCE (critical): a closeup/extreme frame can only hold ONE localized region — either a face (head-and-shoulders) OR a single detail (e.g. hands on one object), NEVER both at once. If the shot needs the person's FACE / expression AND an action happening lower on the body at the same moment (at the waist / belt / trousers / stomach / hips / lap / knees / feet, or hands manipulating something down there), that spans two vertically-distant regions — do NOT use closeup or extreme, because the tight crop crushes the two regions together into distorted anatomy (a face landing on the belly). Use medium (or wider) so both fit naturally. Reserve closeup/extreme for when ONLY one region truly matters. Also pick the framing that lets the described ACTION read correctly: an action happening at floor level (stepping onto scales, feet) needs a framing that INCLUDES the feet and the floor — do NOT pick a tight medium/close-up that crops the scale or feet out and leaves the object floating.
- "transition": how this scene cuts to the NEXT: one of none, crossfade, dip-black, dip-white. "none" (a clean hard cut) is the DEFAULT and should be the MAJORITY — a VSL is punchy. Use others only when clearly earned (crossfade = soft emotional/time beat or moving through a list/steps; dip-black = hard chapter break / low point; dip-white = realization/hope/reveal flash).
- "continues": if this shot is the SAME place with the SAME people simply continuing an EARLIER scene, that earlier scene's number; else 0. Only when BOTH setting AND people carry over.
- "style": "natural" for everyday people/lifestyle/products; "scientific" ONLY for inside-the-body / microscopic biology (organs, cells, blood vessels, anatomy). Everyday scenes stay "natural".
- "product": true if this shot should prominently show the ADVERTISED PRODUCT ITSELF — the finished, branded bottle/package/supplement being sold (named in the PROJECT CONTEXT / brief), e.g. the product held, on a table, or as a hero shot. false for everything else (raw ingredients, generic props, or shots with no product). Use true only for the actual sold product. Set FALSE when the line is not about the product itself — a lifestyle, benefit, emotion or "you" line — do NOT sprinkle the product into unrelated shots just because it exists. When true, in "shows" name the product by its ACTUAL brand name from the brief (e.g. "a bottle of CitruSlim" / "the CitruSlim bottle"), never a generic "a bottle" or "a supplement", and describe it at a NATURAL size and placement (held in a hand or resting on a surface), sitting believably in the scene's own lighting — never a giant, floating, oversized hero out of proportion.
- "testimonial": true ONLY when the line leans on a LARGE CROWD of real satisfied customers as social proof — "thousands of men and women have reported…", "join the many who…", "so many happy customers…". Then the shot becomes a GRID of many separate amateur customer selfies, each an ordinary, slim, delighted person holding the product (this grid is composed downstream — you do NOT describe the grid, and keep "shows" short). false for a single person, a normal scene, or any shot that is not specifically the "lots of real happy users" social-proof beat.
- INGREDIENTS vs PILLS (important for "shows"): when the line is about ingredients, extracts, herbs, fruits, roots, botanicals or a natural remedy — and it is NOT the finished branded product — depict them in their NATURAL, RAW form: the actual plant / fruit / root / seeds / leaves / peel, or a natural blend, mixture, powder, tea, tincture or liquid being prepared or measured out. Do NOT draw them as capsules, pills, tablets, softgels or a supplement bottle. EXCEPTION: an ingredient tagged [MOLECULE] in the roster (a vitamin, mineral or synthesised compound that does not grow in nature — e.g. Chromium, Zinc, B Vitamins) is depicted NOT as a raw/natural form or powder but as a clean 3D scientific MOLECULE render, and that shot's "style" is "scientific". Capsules / pills / tablets appear ONLY when the script itself is about the finished pill-form product. So "taking extracts" → the raw extract or the ingredient it comes from (e.g. sliced blood oranges, a dropper of extract), NOT a capsule.
- USE THE SCRIPT'S REAL INGREDIENTS: when a shot shows the product's ingredients/extracts, name the SPECIFIC ingredients the SCRIPT itself (and the PROJECT CONTEXT / brief) actually mention — the real named ingredients of this product, e.g. the exact fruits/herbs/roots the script has introduced up to and including this scene. Do NOT invent generic or placeholder ingredients, and do NOT add other, unmentioned ones. Show ONLY those real ingredients; if they sit in labelled jars/containers, label them with those real ingredient names and include NO other/extra jars or invented labels. If the script names, say, three specific extracts, show exactly those three — not a shelf of random supplements.
- "split": true when this line holds distinct visual ideas best shown as side-by-side panels in ONE image — an ingredient AND its effect, a cause AND its result, a problem AND its solution, a direct comparison/contrast (e.g. diet vs exercise), before/after, or a short list of 2–4 distinct things/places (e.g. "sourced from Sicily and other regions" → the different growing regions; "neither diet nor exercise" → dieting person | exercising person). Count the distinct ideas: TWO → two panels, THREE → three panels, FOUR → four equal panels (a 2×2 grid or four columns). Do this whenever the line clearly pairs/lists 2–4 concrete visual ideas — it is common, not rare; a single unified image is for lines with ONE idea. NEVER pad: use exactly as many panels as the line names, and NEVER cram 5+ items into panels (a 5+ item line should already be its own separate scenes). Write "shows" as those panels explicitly, in order: two → "LEFT: … RIGHT: …"; three → "LEFT: … MIDDLE: … RIGHT: …"; four → "TOP-LEFT: … TOP-RIGHT: … BOTTOM-LEFT: … BOTTOM-RIGHT: …" — and STATE THE LOOK of each panel inline (photorealistic photo / 2D cartoon / scientific 3D medical illustration), because a split has no global style. Panels MAY use DIFFERENT looks when the content calls for it (e.g. "LEFT, photorealistic: a doctor examining a patient. RIGHT, scientific 3D medical illustration: a cross-section of the liver breaking down fat."). Do NOT mention any dividing line (there is none).

- "states": include this ONLY when a CAST member marked [TRANSFORMS …] in the roster is present in THIS shot. It is an object mapping that character's exact label to their STAGE at this point of the script: "start" (before the change has visibly begun), "mid" (partway through — the change is clearly visible but not complete), or "end" (fully transformed). Judge the stage from WHERE this scene sits in the arc and what the line implies (respect flashbacks — an early flashback to their finished state is "end"; a late memory of the old them is "start"). When such a character is present, ALSO describe their current stage inside "shows" (e.g. "noticeably slimmer", "visibly leaner and more energetic"). Omit this field entirely when no transforming character is present.
- "ingredients": ONLY when the shot actually shows the product's ingredients/extracts, an array of the exact ingredient NAMES from the INGREDIENTS roster that appear in THIS shot (spelled exactly as the roster). List only the ones the scene refers to; do NOT invent others. Also name them in "shows". Omit or [] when no ingredient is shown. IMPORTANT — a [MOLECULE]-tagged ingredient (a vitamin / mineral / compound that does NOT grow in nature) must be described in "shows" as a clean 3D scientific MOLECULE render (glossy glass-like ball-and-stick structure on a soft gradient), NEVER as a powder, plant, jar or raw natural form; for such a molecule shot set "style":"scientific".
- "testimonial_person": for a scene whose LINE is a WRITTEN FIRST-PERSON customer testimonial — a quoted or clearly first-person review by a NAMED individual customer sharing THEIR OWN result ("My name is Lisa, I live in Manchester, and I've lost two stone…"; 'And Helen F. adds: "I've lost a stone and a half…"') — output an object describing that ONE customer; else null. This is a SINGLE named person's written review, NOT the crowd social-proof grid (that is "testimonial" — keep that false here). The object fields:
    • "name": the customer's name EXACTLY as the line gives it ("Lisa", "Robert", "Helen F.").
    • "gender": "male" or "female", inferred from the name / wording.
    • "location": ALWAYS "City, CC" — a city followed by the country's short code, e.g. "Manchester, UK", "Bristol, UK", "Austin, USA". Use the CITY the line names (or, if the line names no place, a real common city in the AUDIENCE's country) and ALWAYS append the country abbreviation matching the audience's market (United Kingdom → UK, United States → USA, etc.).
    • "age": a number — the age if the line states one; otherwise a plausible age taken from the AUDIENCE age range (e.g. range 45-65 → 54).
    • "text": the testimonial in the customer's OWN words, with any surrounding quotation marks and lead-ins removed — strip a leading 'And Helen F. adds:' / 'She says:' etc. and any wrapping " " quotes, keeping ONLY the person's actual words. Do NOT change or translate the wording.
  Output null for EVERY line that is not one person's written first-person testimonial.

Output ONLY a JSON array, one object per scene IN ORDER (position = scene number; do not add a number field), nothing else. No prose, no code fences:
[{"present":["Dr Carbonell"],"generic":null,"shows":"...","camera":"ots","transition":"none","continues":0,"style":"natural","product":false,"split":false,"testimonial":false,"testimonial_person":null,"states":{},"ingredients":[]}]"""


def _audience_note(aud):
    if not aud:
        return "(no specific audience set)"
    bits = []
    for k, lbl in (("genders", "gender(s)"), ("ages", "age(s)"), ("locations", "location/market"), ("currencies", "currency")):
        v = aud.get(k)
        if v:
            bits.append(f"{lbl}: {', '.join(v)}")
    excl = aud.get("appearance")
    if excl:
        bits.append("avoid these looks for ordinary people: " + ", ".join(excl))
    av = (aud.get("avatar") or "").strip()
    if av:
        bits.append("TARGET VIEWER (the relatable/ordinary people this ad speaks to) look like: " + av)
    return "; ".join(bits) if bits else "(no specific audience set)"


def _norm_testimonial_person(tp):
    """Normalize the director's extracted written-testimonial customer (name/gender/location/age/text), or None."""
    if not isinstance(tp, dict):
        return None
    name = str(tp.get("name") or "").strip()
    if not name:
        return None
    g = str(tp.get("gender") or "").strip().lower()
    g = g if g in ("male", "female") else ""
    return {
        "name": name[:80],
        "gender": g,
        "location": str(tp.get("location") or "").strip()[:120],
        "age": str(tp.get("age") or "").strip()[:12],
        "text": str(tp.get("text") or "").strip()[:5000],
    }


DIRECTOR_CHUNK = 25   # scenes described per director call — bounds the JSON OUTPUT so a long script never truncates

# A closeup/extreme crop can hold only ONE localized region. When a shot's description asks for BOTH a
# face/expression AND an action lower on the body (waist/belt/trousers/stomach/hips/lap/knees/feet, or
# hands working down there), those two regions sit too far apart vertically for a tight crop — the image
# model collapses them into mangled anatomy (the classic 'face landing on the belly', scene #91). We
# detect that co-occurrence to widen the director's AUTO camera pick to a medium shot. Both cues are
# required, so a plain face closeup (emotional beat) or a single-object detail macro never trips it.
_FRAMING_FACE_CUES = re.compile(
    r"\b(face|smil\w+|grin\w+|laugh\w+|frown\w+|expression|eyes?|cheeks?|mouth|tearful|crying|beaming|wink\w*)\b",
    re.I)
_FRAMING_LOWER_CUES = re.compile(
    r"\b(belt|waist\w*|trousers?|pants|jeans|belly|stomach|tummy|midriff|hips?|buckle|notch|"
    r"lap|knees?|thighs?|shoelaces?|laces|ankles?|hem|crotch|groin)\b",
    re.I)
def _framing_conflict(text):
    """True when a shot demands BOTH a face/expression and a waist-or-lower / hands-down-there action —
    the co-occurrence a tight crop can't hold without distorting anatomy. Used only to widen the
    director's auto camera pick; never touches a camera the user set by hand."""
    t = text or ""
    return bool(_FRAMING_FACE_CUES.search(t) and _FRAMING_LOWER_CUES.search(t))

def direct_scenes(scene_texts, characters, aud=None, brief="", targets=None, split_overrides=None, ingredients=None):
    """Whole-script director, processed in CHUNKS. Every call sees the ENTIRE script (so the arc and
    pronoun continuity stay correct) but only OUTPUTS a slice of scenes — that keeps each reply's JSON
    small enough to never truncate, even on a 100-scene VSL. Per scene:
    {cast:[ids], generic, prompt, camera, transition, continues, style, product_suggested, director_failed}.
    director_failed=True means the director could NOT produce that scene — the caller surfaces it instead of
    silently pasting the raw voice-over line into the prompt (the old, invisible failure mode).

    `targets` (0-based indices) → produce output ONLY for those scenes (still with the FULL script as context).
    Used when re-generating a hand-picked subset: ~30× cheaper and seconds instead of a whole-script pass, and
    picking a contiguous set (e.g. one long line the user cut into 3) gets them designed together → distinct."""
    n = len(scene_texts)
    if not n:
        return [], {"model_label": "", "fable_down": False, "fable_err": None}
    chars = [c for c in (characters or []) if c.get("name")]
    id_by_lower = {c["name"].strip().lower(): c.get("id") for c in chars}
    trans_ids = {c.get("id") for c in chars if c.get("transforms")}   # characters whose look changes across the video
    roster = "\n".join(f"- {c['name']}"
                       + (f" ({c.get('role')})" if c.get("role") else "")
                       + (f": {c.get('desc')}" if c.get("desc") else "")
                       + (f" [TRANSFORMS across the video — {(c.get('transform_note') or '').strip() or 'their appearance changes gradually over the script'}; for each shot they appear in, decide their stage: start / mid / end]" if c.get("transforms") else "")
                       for c in chars) or "(none — every scene's people are generic/ordinary)"
    has_transformers = any(c.get("transforms") for c in chars)
    ings = [i for i in (ingredients or []) if i.get("name")]
    ing_id_by_lower = {i["name"].strip().lower(): i.get("id") for i in ings}
    def _ing_tag(i):
        t = []
        if i.get("scientific"): t.append("MOLECULE")
        if i.get("split"): t.append("SPLIT")
        if i.get("use_directly"): t.append("USE-DIRECTLY")
        return (" [" + ", ".join(t) + "]") if t else ""
    ing_roster = "\n".join(f"- {i['name']}{_ing_tag(i)}" + (f": {i.get('desc')}" if i.get("desc") else "") for i in ings)
    numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(scene_texts))
    base = f"CAST roster:\n{roster}\n\nAUDIENCE: {_audience_note(aud)}\n"
    if ings:
        base += ("\nPRODUCT INGREDIENTS roster (the real ingredients of the product — use ONLY these when a shot shows "
                 "ingredients; name the exact ones a scene refers to, never invent others). An ingredient tagged "
                 "[MOLECULE] is NOT a plant/food you show naturally — it is a vitamin/mineral/compound; when such an "
                 "ingredient is shown, describe it as a clean 3D scientific MOLECULE render (glossy glass-like "
                 "ball-and-stick molecular structure on a soft gradient), NOT as a powder, plant, or raw form. "
                 "[SPLIT] means it is several components shown as equal side-by-side molecule panels. "
                 "[USE-DIRECTLY] means the user has ALREADY provided a finished, ready-made image for that ingredient "
                 "(often a combined 'all ingredients' shot). When a scene's line is ABOUT that ingredient — or about the "
                 "product's ingredients COLLECTIVELY (e.g. 'these five ingredients', 'all the ingredients', 'our "
                 "blend/formula', 'by combining the ingredients') and a [USE-DIRECTLY] ingredient covers them — make THAT "
                 "scene a pure INGREDIENTS shot: set \"present\":[] (NO cast person — do NOT invent a doctor / a hand on a "
                 "page / a desk or any other action), put that ingredient's exact name in \"ingredients\", set "
                 "\"product\":false, and keep \"shows\" to a brief mention of those ingredients. We drop the ready image in "
                 "directly, so do NOT design a different scene for such a line:\n" + ing_roster + "\n")
    if (brief or "").strip():
        base += f"\nPROJECT CONTEXT (may be Turkish; use it to understand the product/story, do NOT copy it into scenes):\n{brief.strip()}\n"
    base += f"\nFULL SCRIPT — all {n} scenes in order, for arc & pronoun continuity (CONTEXT ONLY):\n{numbered}\n"
    if has_transformers:
        base += ("\nNOTE: one or more cast are marked [TRANSFORMS …]. For EVERY shot such a character appears in, you MUST set "
                 "\"states\" with their stage (start/mid/end) judged from the arc, and describe that stage in \"shows\".\n")

    # which scenes to actually OUTPUT, grouped into director calls (each call ≤ DIRECTOR_CHUNK scenes)
    if targets is None:
        out_idx = list(range(n))
    else:
        out_idx = sorted({i for i in targets if 0 <= i < n})
    groups = [out_idx[x:x + DIRECTOR_CHUNK] for x in range(0, len(out_idx), DIRECTOR_CHUNK)]

    raw = [None] * n   # parsed director object per scene, or None if that scene wasn't produced / its chunk failed
    use_fable = True                     # prefer Fable 5 (best at the whole-script arc pass)…
    used = set()                         # …but Kie's Fable capacity is flaky ("Resources are tight"): on the
    fable_err = None                     #    first Fable CALL failure, drop to Opus 4.8 for the rest of this run
    for idxs in groups:
        if not idxs:
            continue
        nums = [i + 1 for i in idxs]     # 1-based scene numbers this call must output
        k = len(idxs)
        contiguous = (nums == list(range(nums[0], nums[-1] + 1)))
        which = (f"SCENES {nums[0]}–{nums[-1]}" if contiguous else "SCENES " + ", ".join(map(str, nums)))
        ask = base + (f"\nNow write the director objects for {which} ONLY: a JSON array of EXACTLY {k} object(s), "
                      f"in that exact order — the 1st object is scene {nums[0]} and the last is scene {nums[-1]}. "
                      f"Do NOT include any other scene, and do NOT add a scene-number field. JSON array only.")
        if split_overrides:   # the user has forced split on/off for some scenes → the director MUST honour it
            fs = [i + 1 for i in idxs if split_overrides.get(i) is True]
            fo = [i + 1 for i in idxs if split_overrides.get(i) is False]
            notes = []
            if fs:
                notes.append(f"Scene(s) {', '.join(map(str, fs))}: the user REQUIRES a SPLIT here. Writing a single image is FORBIDDEN. "
                             f"You MUST split the line into complementary panels — put the main subject/cause on one side and its "
                             f"effect, result, context or a contrasting view on the other. Use THREE panels only if the line genuinely "
                             f"names three distinct things (three ingredients/steps, before/during/after); otherwise TWO. Write \"shows\" "
                             f"starting EXACTLY with \"LEFT: … RIGHT: …\" (two panels) or \"LEFT: … MIDDLE: … RIGHT: …\" (three panels), "
                             f"stating each panel's look. There is ALWAYS a way to split a line; find it. Set split=true for these.")
            if fo:
                notes.append(f"Scene(s) {', '.join(map(str, fo))} MUST be split=false — a single unified image (no LEFT/RIGHT).")
            if notes:
                ask += "\nUSER OVERRIDES (obey exactly): " + " ".join(notes)
        budget = min(16000, max(6000, 2500 + 260 * k))
        data = None
        for model in ([SMART_MODEL, PROMPT_MODEL] if use_fable else [PROMPT_MODEL]):
            tries = 2 if model == SMART_MODEL else 8   # give flaky Fable only a quick shot, then lean on reliable Opus
            for _attempt in range(2):                  # one clean retry for a garbled/parse reply (model DID respond)
                try:
                    txt = _claude_text(DIRECTOR_SYSTEM, ask, max_tokens=budget, model=model, tries=tries)
                except Exception as e:                 # the CALL failed (overload / 500 / network) — don't hammer it
                    if model == SMART_MODEL:
                        use_fable = False              # Fable is down → stop trying it for the remaining chunks
                        fable_err = str(e)
                    break
                try:
                    got = _parse_json_array(txt)
                except Exception:
                    continue                           # replied but unparseable → retry once
                if isinstance(got, list) and got:
                    data = got
                    used.add(model)
                    break
            if isinstance(data, list):
                break
        if not isinstance(data, list):
            continue
        seg = data
        if len(data) == n and n != k:      # model ignored the slice and returned the WHOLE array → take our window
            seg = [data[i] for i in idxs]
        for j, i in enumerate(idxs):
            raw[i] = seg[j] if (j < len(seg) and isinstance(seg[j], dict)) else None

    out = []
    for i in range(n):
        item = raw[i]
        desc = ""
        if isinstance(item, dict):
            desc = str(item.get("shows") or item.get("scene") or item.get("scene_desc") or "").strip()
        tperson = _norm_testimonial_person(item.get("testimonial_person") if isinstance(item, dict) else None)
        if not desc:            # no usable shot description → FAIL LOUD, never fall back to the raw VO line
            out.append({"cast": [], "generic": None, "prompt": "", "camera": DEFAULT_CAMERA,
                        "transition": "none", "continues": 0, "style": DEFAULT_STYLE,
                        "product_suggested": False, "testimonial": False, "testimonial_person": tperson, "director_failed": True})
            continue
        cids = []
        for nm in (item.get("present") or []):
            cid = id_by_lower.get(str(nm).strip().lower())
            if cid is not None and cid not in cids:
                cids.append(cid)
        cam = str(item.get("camera") or "").strip().lower()
        cam = cam if cam in CAMERA_ANGLES_BY_KEY else DEFAULT_CAMERA
        # Safety net for the director's AUTO pick (a user's manual camera is saved on its own path and
        # never reaches here): a closeup/extreme frame holds one region — if the shot needs the face AND
        # a waist/lower-body action, widen to medium so the model doesn't crush them into bad anatomy.
        if cam in ("closeup", "extreme") and _framing_conflict(desc):
            cam = "medium"
        tr = item.get("transition")
        tr = tr if tr in TRANSITIONS else "none"
        try:
            cont = int(item.get("continues") or 0)
        except (TypeError, ValueError):
            cont = 0
        if not (1 <= cont <= i):
            cont = 0
        st = str(item.get("style") or "").strip().lower()
        st = st if st in ("natural", "scientific") else DEFAULT_STYLE
        gen = item.get("generic")
        gen = str(gen).strip() if gen else None
        states = {}                       # per-scene stage (start/mid/end) for any transforming cast present → keyed by char id
        raw_states = item.get("states")
        if trans_ids and isinstance(raw_states, dict):
            for lbl, v in raw_states.items():
                cid = id_by_lower.get(str(lbl).strip().lower())
                v = str(v or "").strip().lower()
                if cid in trans_ids and cid in cids and v in ("start", "mid", "end"):
                    states[cid] = v
        ing_ids = []                       # the product's ingredients shown in this shot → roster ids
        for nm in (item.get("ingredients") or []):
            iid = ing_id_by_lower.get(str(nm).strip().lower())
            if iid is not None and iid not in ing_ids:
                ing_ids.append(iid)
        out.append({"cast": cids, "generic": gen, "prompt": desc, "camera": cam,
                    "transition": tr, "continues": cont, "style": st,
                    "product_suggested": bool(item.get("product")), "split": bool(item.get("split")),
                    "testimonial": bool(item.get("testimonial")), "testimonial_person": tperson,
                    "states": states, "ingredients": ing_ids, "director_failed": False})
    if targets is None:
        out[-1]["transition"] = "none"   # last scene of a FULL pass never transitions out (targeted subset leaves others alone)
    labels = {SMART_MODEL: "Fable 5", PROMPT_MODEL: "Opus 4.8"}
    model_label = " + ".join(labels[m] for m in (SMART_MODEL, PROMPT_MODEL) if m in used)
    meta = {"model_label": model_label,          # which model(s) actually produced the scenes (for a toast)
            "fable_down": fable_err is not None,  # True if Fable 5 was tried and failed → we fell back to Opus
            "fable_err": fable_err}
    return out, meta


@app.route("/api/scenes/<project>/analyze", methods=["POST"])
def api_analyze(project):
    """Whole-script cast detection → fills the project's character roster (name/role/desc) so the user can
    add a reference photo to each BEFORE splitting. Keeps existing characters + their photos."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = (request.get_json(force=True).get("script") or "").strip()
    if not script:
        return jsonify({"error": "No script to analyze."}), 400
    try:
        detected = _detect_cast_raw(script, doc.get("brief", ""))
    except Exception as e:
        # surface the real reason instead of a silent empty roster
        msg = str(e).lower()
        if "internal error" in msg or "try again" in msg or "500" in msg or "timeout" in msg or "timed out" in msg:
            return jsonify({"error": "The AI service (Kie.ai) is temporarily overloaded and returned a server "
                            "error. Nothing is wrong with your script — just click Analyze Cast again in a "
                            "moment."}), 503
        return jsonify({"error": f"Cast analysis failed: {e}. If this keeps happening, check this project's "
                        f"Kie API key and credit balance."}), 502
    chars = doc.setdefault("characters", [])
    by_lower = {c.get("name", "").strip().lower(): c for c in chars}
    added = 0
    for d in detected:
        ex = by_lower.get(d["label"].strip().lower())
        if ex:                                   # keep the user's photos/edits, just refresh role/desc if empty
            ex.setdefault("role", d["role"]); ex.setdefault("desc", d["desc"])
        else:
            chars.append({"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"],
                          "urls": [], "auto": True})
            added += 1
    # ALSO detect the product's ingredients (same analyze pass) → fills the Ingredients roster. Never fails cast.
    ing_added = 0
    try:
        ings = doc.setdefault("ingredients", [])
        i_by_lower = {i.get("name", "").strip().lower(): i for i in ings}
        for d in detect_ingredients(script, doc.get("brief", "")):
            if d["name"].strip().lower() in i_by_lower:
                continue
            ings.append({"id": new_uid(), "name": d["name"], "desc": d["desc"], "urls": [], "auto": True})
            ing_added += 1
    except Exception:
        pass
    # AUTO target-viewer avatar (only if the user hasn't set one) → the relatable/ordinary people's before-look.
    try:
        aud = doc.setdefault("audience", {})
        if not (aud.get("avatar") or "").strip():
            av = detect_avatar(script, doc.get("brief", ""))
            if av:
                aud["avatar"] = av
    except Exception:
        pass
    save_doc(project, doc)
    return jsonify({"doc": doc, "detected": detected, "added": added, "ingredients_added": ing_added})


def _sync_auto_testimonials(doc, plan):
    """From the director plan, auto-create/refresh testimonial PEOPLE + written FACEBOOK cards for any
    first-person customer-testimonial line, and link each such scene to its card (scene.tcard_id).
    'auto' entries are reconciled on every split (refreshed/pruned); manually-added ones are left alone,
    and an existing auto person keeps its generated photo across re-splits (matched by name)."""
    scenes = doc.get("scenes") or []
    people = doc.setdefault("testimonials", [])
    cards = doc.setdefault("testimonial_cards", [])
    people_by_name = {}
    for p in people:
        nm = str(p.get("name") or "").strip().lower()
        if nm:
            people_by_name.setdefault(nm, p)
    wcard_by_char = {}
    for c in cards:
        if str(c.get("type") or "written") == "written" and c.get("charId"):
            wcard_by_char.setdefault(c.get("charId"), c)
    used_people, used_cards = set(), set()
    for i, sc in enumerate(scenes):
        a = plan[i] if i < len(plan) else {}
        tp = a.get("testimonial_person") if isinstance(a, dict) else None
        if not tp:
            continue
        key = tp["name"].strip().lower()
        person = people_by_name.get(key)
        if person is None:
            person = {"id": new_uid(), "name": tp["name"], "desc": "", "age": tp.get("age", ""),
                      "gender": tp.get("gender", ""), "location": tp.get("location", ""), "urls": [], "auto": True}
            people.append(person); people_by_name[key] = person
        elif person.get("auto"):                       # refresh an auto person's meta from the (maybe edited) script; keep its photo
            person["age"] = tp.get("age") or person.get("age", "")
            person["gender"] = tp.get("gender") or person.get("gender", "")
            person["location"] = tp.get("location") or person.get("location", "")
        used_people.add(person["id"])
        card = wcard_by_char.get(person["id"])
        if card is None:
            card = {"id": new_uid(), "type": "written", "format": "facebook", "charId": person["id"],
                    "text": tp.get("text", ""), "extra": {}, "auto": True, "sceneUid": sc["uid"]}
            cards.append(card); wcard_by_char[person["id"]] = card
        elif card.get("auto"):                          # refresh the auto card's wording; keep any produced image in extra
            card["text"] = tp.get("text", "") or card.get("text", "")
            card.setdefault("format", "facebook")
        card["sceneUid"] = sc["uid"]
        used_cards.add(card["id"])
        sc["tcard_id"] = card["id"]
    # prune AUTO entries that no longer match a detected testimonial (manual ones are kept)
    doc["testimonial_cards"] = [c for c in cards if (not c.get("auto")) or c["id"] in used_cards]
    referenced = {c.get("charId") for c in doc["testimonial_cards"]}
    doc["testimonials"] = [p for p in people if (not p.get("auto")) or p["id"] in used_people or p["id"] in referenced]


@app.route("/api/scenes/<project>/split", methods=["POST"])
def api_split(project):
    """Split the script into meaningful scenes via Claude (Kie.ai). Surfaces errors; no fallback.
    Then a whole-script director pass auto-assigns camera framing, transitions, cast, and continuity."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = request.get_json(force=True).get("script", "")
    try:
        parts = split_script(script)
    except Exception as e:
        return jsonify({"error": f"Split failed: {e}"}), 502
    # Make sure a cast roster exists so the director can keep recurring people consistent. If the user
    # already ran "Analyze Script" (and maybe added photos) we KEEP that roster; otherwise detect now.
    if not [c for c in (doc.get("characters") or []) if c.get("name")]:
        for d in detect_cast(script, doc.get("brief", "")):
            doc.setdefault("characters", []).append(
                {"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"], "urls": [], "auto": True})
    if not [i for i in (doc.get("ingredients") or []) if i.get("name")]:   # also seed the product's ingredient roster
        try:
            for d in detect_ingredients(script, doc.get("brief", "")):
                doc.setdefault("ingredients", []).append(
                    {"id": new_uid(), "name": d["name"], "desc": d["desc"], "urls": [], "auto": True})
        except Exception:
            pass
    # ONE whole-script director pass: who's present, generic person, on-screen content, camera, transition,
    # continuity, style — all resolved together so nothing conflicts and identity stays consistent.
    plan, dmeta = direct_scenes(parts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""), ingredients=doc.get("ingredients"))
    doc["scenes"] = []
    for i, sent in enumerate(parts, 1):
        sc = new_scene(i)
        sc["vo"] = sent
        a = plan[i - 1] if i - 1 < len(plan) else {}
        sc["prompt"] = a.get("prompt") or ""          # the director already wrote the on-screen content
        sc["cast"] = a.get("cast") or []
        sc["generic"] = a.get("generic")              # a non-roster ordinary person for this shot (or None)
        sc["camera"] = a.get("camera") or DEFAULT_CAMERA
        sc["transition"] = a.get("transition") or DEFAULT_TRANSITION
        sc["style"] = a.get("style") or DEFAULT_STYLE
        sc["product_suggested"] = bool(a.get("product_suggested"))   # director thinks the product belongs in this shot
        if sc["product_suggested"] and sc.get("product") is None:    # auto-select ONLY if the user has NEVER touched product (None); an explicit "" (cleared) is respected
            _pu = _default_product_url(doc)
            if _pu: sc["product"] = _pu
        sc["split"] = bool(a.get("split"))                           # two-panel/diptych composition (director decided)
        sc["split_suggested"] = bool(a.get("split"))                 # director chose split here → pulse the button green until the user touches it
        sc["testimonial"] = bool(a.get("testimonial"))              # social-proof crowd line → grid of real-customer selfies (auto-composed)
        if sc["testimonial"] and sc.get("product") is None:         # attach ONLY if never touched (respect an explicit cleared "")
            _pu = _default_product_url(doc)
            if _pu: sc["product"] = _pu
        sc["states"] = a.get("states") or {}                         # transforming cast → stage (start/mid/end) at this scene
        sc["ingredients"] = a.get("ingredients") or []                # the product's ingredients shown in this shot (roster ids)
        bind_named_cast(sc, doc)                                     # any roster character NAMED in the prompt → face-lock them too
        sc["_cont"] = a.get("continues") or 0        # temp: 1-based source scene #, resolved to a uid below
        doc["scenes"].append(sc)
    for sc in doc["scenes"]:                          # resolve continuity #→uid now that every scene has a uid
        c = sc.pop("_cont", 0)
        sc["cont_of"] = doc["scenes"][c - 1]["uid"] if 1 <= c <= len(doc["scenes"]) else None
    _sync_auto_testimonials(doc, plan)                # auto-build testimonial people + FB cards from first-person testimonial lines, and link their scenes
    save_doc(project, doc)
    _stamp_director_prompt(doc.get("scenes"))                 # baseline for the later edit-delta
    _learn_log("director", project, doc, doc.get("scenes"))   # passive: capture the director's fresh (vo → prompt) pairs
    failed = [i + 1 for i, a in enumerate(plan) if a.get("director_failed")]   # never silently ship raw-VO prompts
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)                              # which model actually ran (toast)
    if failed:
        resp["director_warning"] = (f"The director could not write a shot description for {len(failed)} scene(s): "
                                    f"{', '.join(map(str, failed))}. Their prompts are left empty — use “Re-run "
                                    f"director” or write/Generate a prompt for those scenes.")
    return jsonify(resp)

def _looks_multi(vo):
    """Cheap check: does this voice-over hold more than one sentence? (a sentence-ender with more text after
    it). Lets re-split skip single-sentence scenes entirely — no LLM call, nothing touched."""
    return bool(re.search(r"[.!?…]['\"”’)]?\s+\S", (vo or "").strip()))

@app.route("/api/scenes/<project>/resplit", methods=["POST"])
@_locked
def api_resplit_scenes(project):
    """WORK-PRESERVING re-split: break only the scenes whose voice-over holds several sentences into one
    sentence each. Single-sentence scenes are left 100% untouched (prompt, image, cast, approval all kept).
    For a multi-sentence scene, the FIRST sentence stays on the original scene (keeping its media/prompt);
    the extra sentences become NEW blank scenes right after it. Fixes old 3-4-sentence scenes without
    rebuilding the whole project. (New splits already follow the one-sentence rule, so this is a one-off tidy.)"""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    out, split_count, added, kept_approved = [], 0, 0, 0
    for s in scenes:
        vo = (s.get("vo") or "").strip()
        if s.get("approved"):                 # finalized scene → NEVER disturb it (unapprove first if you want it re-split)
            out.append(s)
            if _looks_multi(vo):
                kept_approved += 1
            continue
        if not _looks_multi(vo):
            out.append(s)                     # single sentence → untouched
            continue
        try:
            parts = [p for p in split_script(vo) if p.strip()]
        except Exception:
            out.append(s)                     # splitter hiccup → leave this scene as-is
            continue
        if len(parts) <= 1:
            out.append(s)
            continue
        s["vo"] = parts[0]                    # first sentence stays on THIS scene (keeps its image/prompt/cast)
        out.append(s)
        for extra in parts[1:]:
            ns = new_scene(0)
            ns["vo"] = extra
            ns["uid"] = new_uid()
            out.append(ns)
            added += 1
        split_count += 1
    for i, s in enumerate(out, 1):
        s["id"] = i
    doc["scenes"] = out
    save_doc(project, doc)
    resp = dict(doc)
    resp["resplit"] = {"split": split_count, "added": added, "total": len(out), "kept_approved": kept_approved}
    return jsonify(resp)

# ================= PROMPT AUDIT — QA the director's shots before image generation =================
# One LLM pass over the (unapproved) scenes that both FIXES weak/mismatched/duplicate prompts AND SPLITS
# long multi-beat scenes. Uses the best model with fallback (opus->sonnet->fable); if Kie is fully down it
# ERRORS and changes NOTHING (no degraded rules-only result) — and the apply is atomic (only after ALL
# batches succeed). Replaces the old "Re-split scenes" button (audit already re-splits).
AUDIT_SYSTEM = (
    "You are the QA reviewer of a VSL (video sales letter) ad's shot list. You receive a batch of scenes IN "
    "ORDER, each as one JSON object: id, the voice-over line (vo, in its ORIGINAL language — NEVER translate or "
    "change its wording), the current image prompt, its style and camera, whether a recurring narrator/named "
    "character is cast, and any product-ingredients shown. For EACH scene, decide if the image prompt is good, "
    "should be FIXED, or the scene should be SPLIT.\n\n"
    "HOUSE STYLE to enforce:\n"
    "- The image must depict THIS line's own beat: a BENEFIT line -> a positive/after image; a WARNING/PROBLEM "
    "line -> a problem image; a SOLUTION line -> the fix. Never the previous or next line's idea.\n"
    "- Use the on-screen narrator SPARINGLY: not for generic sincerity / transition / 'pay attention' lines "
    "(show a concrete relatable scene or the topic itself), and NEVER a 'narrator holding the product' shot.\n"
    "- Lead with concrete, emotionally specific target-viewer moments and telling props over abstract graphics "
    "or narrator talking-heads.\n"
    "- Prefer before/after or 2-3 panel split-screens when a line contrasts two states or lists 2-4 items.\n"
    "- Do NOT re-show an ingredient/molecule on its benefit lines: a plain molecule/ingredient shot only on the "
    "line that INTRODUCES it; afterwards either split (molecule on one side, the concrete benefit on the other) "
    "or drop it and show the benefit/result itself.\n"
    "- Be concrete and specific; for 'natural' style never use magical glow / aura / sparkles (those belong only "
    "to 'scientific' style). Keep product hero shots clean and enrich with the real raw ingredient; localise to "
    "the audience's country.\n"
    "- VARY compositions; avoid a prompt near-identical to a neighbour's.\n"
    "- ON-IMAGE TEXT LANGUAGE: if a shot legitimately shows readable words/signage/labels/screen or document text, "
    "the image prompt MUST state that this text is written in the scene's audience_language (given per scene) — "
    "never let it default to English. If audience_language is empty or English, no language clause is needed.\n"
    "- SPLIT a scene whose vo carries several DISTINCT visual beats (a list of actions/items, or clauses a "
    "viewer would picture separately) into one beat per scene — but do NOT split a single continuous moment/idea.\n\n"
    "Return ONLY a JSON array, one object per input scene, SAME order:\n"
    '{"id": <int>, "issue": "<short reason, or \\"\\" if already good>", '
    '"prompt": "<the improved English image prompt; repeat the current one unchanged if already good>", '
    '"style": "natural|scientific|2d" (optional, only if it should change), '
    '"camera": "closeup|medium|wide|extreme|top|side|ots" (optional, only if it should change), '
    '"split": [ {"vo": "<EXACT contiguous substring of THIS scene\'s vo>", "prompt": "<image prompt for this beat>", '
    '"style": "...", "camera": "..."}, ... ] (include ONLY when splitting; 2+ beats) }\n'
    "HARD RULES: never change the vo wording. If you split, the beats\' vo joined by a single space MUST equal "
    "the scene\'s vo word-for-word (never add, drop, reorder or translate any word). Output just the JSON array.")

AUDIT_JOBS = {}
_AUDIT_LOCK = threading.Lock()

def _audit_norm(s):
    return " ".join((s or "").split())

def _audit_batch(payload):
    """One LLM call over a batch of scene dicts -> list of verdicts. Retries a few times so a flaky/partial Kie
    response doesn't kill the whole audit; raises if it still can't get a valid non-empty JSON array (every model
    down or garbled), so the worker aborts atomically and saves nothing."""
    user = ("Review these scenes IN ORDER (one JSON per line). Return the JSON array of verdicts:\n"
            + "\n".join(json.dumps(p, ensure_ascii=False) for p in payload))
    last = None
    for _ in range(3):
        try:
            arr = _parse_json_array(_claude_text(AUDIT_SYSTEM, user, max_tokens=8000))
            if isinstance(arr, list) and arr:
                return arr
            last = ValueError("empty audit result")
        except Exception as e:
            last = e
    raise last or RuntimeError("audit failed")

def _audit_worker(jid, project):
    j = AUDIT_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _AUDIT_LOCK: j.update(status="error", error="project not found")
            return
        scenes = doc.get("scenes") or []
        alang = country_language(doc.get("audience")) or ""   # any on-image text must be in this language (not English)
        auditable = [s for s in scenes if not s.get("approved") and (s.get("vo") or "").strip()]
        if not auditable:
            with _AUDIT_LOCK: j.update(status="error", error="No scenes to audit (all approved or empty).")
            return
        B = 16
        batches = [auditable[i:i + B] for i in range(0, len(auditable), B)]
        verdicts = {}
        for bi, batch in enumerate(batches):
            if j.get("cancel"):
                with _AUDIT_LOCK: j.update(status="cancelled")
                return
            with _AUDIT_LOCK:
                j.update(step=f"Auditing scenes {bi * B + 1}-{min((bi + 1) * B, len(auditable))} of {len(auditable)}…",
                         pct=int(bi / max(1, len(batches)) * 90))
            payload = [{"id": s.get("id"), "vo": s.get("vo") or "", "current_prompt": s.get("prompt") or "",
                        "style": s.get("style") or "natural", "camera": s.get("camera") or "",
                        "narrator_or_named_cast_present": bool(s.get("cast")),
                        "audience_language": alang,
                        "ingredients_shown": s.get("ingredients") or []} for s in batch]
            for v in _audit_batch(payload):          # raises -> caught below -> job errors, nothing saved
                try:
                    verdicts[int(v.get("id"))] = v
                except Exception:
                    continue
        # APPLY atomically (only now that every batch succeeded)
        out, fixed, split_n, added, changes = [], 0, 0, 0, []
        for s in scenes:
            v = verdicts.get(s.get("id"))
            if s.get("approved") or not v:
                out.append(s); continue
            vo = s.get("vo") or ""
            beats = v.get("split") if isinstance(v.get("split"), list) else None
            if beats and len(beats) >= 2 and _audit_norm(" ".join(b.get("vo", "") for b in beats)) == _audit_norm(vo):
                for k, b in enumerate(beats):
                    ns = json.loads(json.dumps(s))          # deep clone -> keeps all fields/blocks
                    ns["vo"] = b.get("vo") or ""
                    ns["prompt"] = (b.get("prompt") or s.get("prompt") or "").strip()
                    if b.get("style"): ns["style"] = b["style"]
                    if b.get("camera"): ns["camera"] = b["camera"]
                    if k > 0:
                        ns["uid"] = new_uid()               # fresh beats get their own uid
                    out.append(ns)
                split_n += 1; added += len(beats) - 1
                changes.append({"id": s.get("id"), "issue": v.get("issue") or "split into visual beats"})
                continue
            np = (v.get("prompt") or "").strip()
            if np and _audit_norm(np) != _audit_norm(s.get("prompt") or ""):
                s["prompt"] = np
                if v.get("style"): s["style"] = v["style"]
                if v.get("camera"): s["camera"] = v["camera"]
                fixed += 1
                changes.append({"id": s.get("id"), "issue": v.get("issue") or "prompt improved"})
            out.append(s)
        for i, s in enumerate(out, 1):
            s["id"] = i
        doc["scenes"] = out
        save_doc(project, doc)
        report = {"audited": len(auditable), "fixed": fixed, "split": split_n, "added": added,
                  "total": len(out), "changes": changes[:150]}
        with _AUDIT_LOCK: j.update(status="done", pct=100, step="Done", report=report, scenes=out)
    except Exception as e:
        with _AUDIT_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/audit", methods=["POST"])
@_locked
def api_audit_scenes(project):
    """Start a prompt-audit job (best model -> fallback -> error; atomic; skips approved scenes)."""
    err = _keys_ok(("kie",))
    if err:
        return err
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    AUDIT_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_audit_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/audit-job/<jid>")
def api_audit_job(jid):
    j = AUDIT_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/audit-cancel/<jid>", methods=["POST"])
def api_audit_cancel(jid):
    j = AUDIT_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

def _director_note(meta):
    """One-line 'which model ran the director' message for a toast (e.g. 'Director: Opus 4.8 — Fable 5 was
    unavailable (Resources are tight)'). Returns '' if the director produced nothing."""
    meta = meta or {}
    label = meta.get("model_label") or ""
    if not label:
        return ""
    note = f"Director: {label}"
    if meta.get("fable_down"):
        err = (meta.get("fable_err") or "").strip()
        note += " — Fable 5 was unavailable" + (f" ({err})" if err else "") + ", used Opus 4.8"
    return note

@app.route("/api/scenes/<project>/redirect", methods=["POST"])
def api_redirect_scenes(project):
    """Re-run the whole-script director over the EXISTING scenes.
    - No selection (whole-doc): REPAIR only — rewrite prompts that are empty or just the raw voice-over line,
      and KEEP any prompt you wrote yourself. Voice-over, images and order are always preserved.
    - With `ids` (a selection): a FULL redo of just those scenes — the director re-decides EVERYTHING
      (prompt, cast, camera, transition, style, product/split hints, transformation stage), overwriting them.
      RAW ("My prompt") scenes are still left untouched."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    body = request.get_json(silent=True) or {}
    ids = body.get("ids")
    sel = set(ids) if ids else None            # a selection → FULL redo of those scenes; else whole-doc repair
    texts = [(s.get("vo") or "") for s in scenes]
    if sel is not None:
        targets = {i for i, s in enumerate(scenes) if s.get("id") in sel}
        split_overrides = {i: bool(scenes[i].get("split")) for i in targets if not scenes[i].get("no_cast")}
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides, ingredients=doc.get("ingredients"))
    else:
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""), ingredients=doc.get("ingredients"))
    fixed, failed, kept = 0, [], 0
    _redone = []
    for i, s in enumerate(scenes):
        a = plan[i] if i < len(plan) else {}
        if sel is not None:
            if s.get("id") not in sel:
                continue
            if s.get("no_cast"):               # RAW scene → the user's own prompt; never overwrite it
                kept += 1
                continue
        else:
            vo = (s.get("vo") or "").strip()
            cur = (s.get("prompt") or "").strip()
            broken = (cur == "" or cur == vo)  # empty, or the raw VO pasted in by the old fallback
            if not broken:
                kept += 1                      # a real, hand-written/earlier-good prompt → never touch it
                continue
        if a.get("director_failed"):
            failed.append(i + 1)
            continue
        s["prompt"] = a.get("prompt") or ""
        s["cast"] = a.get("cast") or []
        s["cast_locked"] = []   # Re-run Director is a fresh full decision → clear the user's earlier removals (it may re-add; the user can remove again and it stays removed)
        s["generic"] = a.get("generic")
        s["camera"] = a.get("camera") or DEFAULT_CAMERA
        s["transition"] = a.get("transition") or DEFAULT_TRANSITION
        s["style"] = a.get("style") or DEFAULT_STYLE
        s["product_suggested"] = bool(a.get("product_suggested"))
        if s["product_suggested"] and s.get("product") is None:   # auto-select ONLY if never touched; a cleared "" (user set None) is respected on re-run
            _pu = _default_product_url(doc)
            if _pu: s["product"] = _pu
        s["split"] = bool(a.get("split"))
        s["split_suggested"] = bool(a.get("split"))
        s["testimonial"] = bool(a.get("testimonial"))   # social-proof crowd → grid of real-customer selfies (auto-composed)
        if s["testimonial"] and s.get("product") is None:
            _pu = _default_product_url(doc)
            if _pu: s["product"] = _pu
        s["states"] = a.get("states") or {}
        s["ingredients"] = a.get("ingredients") or []
        bind_named_cast(s, doc)                     # face-lock any roster character the prompt names
        s["_cont"] = a.get("continues") or 0
        fixed += 1
        _redone.append(s)
    for s in scenes:                           # resolve continuity #→uid for the scenes we rewrote
        c = s.pop("_cont", 0)
        if c:
            s["cont_of"] = scenes[c - 1]["uid"] if 1 <= c <= len(scenes) else None
    save_doc(project, doc)
    _stamp_director_prompt(_redone)                  # baseline for the later edit-delta
    _learn_log("director", project, doc, _redone)   # passive: capture re-directed (vo → prompt) pairs
    return jsonify({"fixed": fixed, "kept": kept, "failed": failed, "total": len(scenes),
                    "note": _director_note(dmeta)})

# ---- routes: prompt generation (Anthropic) ---------------------------------
PROMPT_SYSTEM = """You describe what is SHOWN on screen for ONE scene of a VSL (video sales letter).
You get the spoken sentence (VO) and, optionally, an on-screen note. Output a vivid description of the CONTENT of the shot only.

INCLUDE:
- the subject(s) and their action, the setting/location, and the key objects in view
- concrete, specific, visual detail that illustrates the sentence's meaning

DO NOT INCLUDE (other layers own these — including them causes conflicts):
- ANY framing, shot size, camera angle or viewpoint (no "close-up", "wide view", "over the shoulder", "top view", "from the side", "in the foreground") — a separate Camera Angle layer owns this
- camera/lens/aperture/shot technicalities (no "85mm", "f/2.0", "DSLR", "drone shot")
- lighting descriptions (no "soft light", "golden hour")
- image-quality or medium words (no "photorealistic", "cinematic", "4k", "HDR", "amateur", "2D", "animation", "render", "illustration")
- the person's age, ethnicity, hair, or skin — describe people only by role/action ("a woman", "a doctor", "her hands"), UNLESS the user lists named characters present in the scene, in which case use their name for that person (e.g. "Loretta") instead of a generic role
- any on-screen text, captions, logos, or watermarks

Also choose the single best STYLE for this moment:
- natural    = real people / lifestyle / everyday objects, food, product, scenery
- 2d         = animation / illustration / motion-graphics
- scientific = inside-the-body / anatomy / microscopic biology / medical visualization

OUTPUT FORMAT: the FIRST line must be exactly "STYLE: <key>" (natural|2d|scientific).
Then, on the following line(s), output ONLY the content description — no preamble, no quotes, no explanation.
If a required STYLE is given by the user, you MUST use that one."""

def char_has_photo(c):
    """A USER-provided reference photo exists (not the auto-anchor)."""
    return bool((c.get("urls") and any(c.get("urls"))) or c.get("url"))

def char_urls(c):
    """Every reference image used to keep a character's face consistent: user-provided photos PLUS the
    auto-anchor (the first approved frame we adopted for a photo-less recurring person). New characters
    store `urls` (a list); legacy ones a single `url` — normalise both to a list."""
    urls = [u for u in (c.get("urls") or []) if u]
    if not urls and c.get("url"):
        urls = [c["url"]]
    if c.get("anchor"):
        urls = urls + [c["anchor"]]
    return urls

def scene_characters(scene, doc):
    """Resolve a scene's `cast` (character ids) against doc.characters → list of character dicts."""
    by_id = {c.get("id"): c for c in (doc.get("characters") or [])}
    return [by_id[cid] for cid in (scene.get("cast") or []) if cid in by_id]

# Broad "is there a person in this shot?" cues (deliberately generous → we only DROP a face-lock when there is
# ZERO human signal, so we never strip a legitimately-present person). Excludes 'human/body' (anatomy uses those).
_PERSON_CUES = re.compile(
    r"\b(he|she|him|her|his|hers|they|them|their|man|men|woman|women|boy|girl|kid|kids|child|children|baby|"
    r"person|people|folks|someone|somebody|everyone|doctor|nurse|patient|patients|expert|scientist|husband|"
    r"wife|mother|father|mom|mum|dad|parent|parents|family|friend|friends|couple|crowd|lady|gentleman|guy|"
    r"hand|hands|arm|arms|finger|fingers|holds?|holding|hold|wearing|wears|face|faces|head|smil\w+|frown\w*|"
    r"sits?|sitting|sat|stands?|standing|stood|walk\w*|runs?|running|looks?|looking|reach\w*|points?|pointing|"
    r"talk\w*|speak\w*|eat\w*|drink\w*|sleep\w*|cry\w*|laugh\w*|hug\w*|portrait|selfie)\b", re.I)

_NAME_TITLES = {"dr", "dr.", "mr", "mr.", "mrs", "mrs.", "ms", "ms.", "miss", "prof", "prof.", "sir", "madam", "the"}

def _char_name_tokens(name):
    """A character's matchable name forms: the FULL name plus each significant token (first name / surname),
    dropping titles (Dr, Mr…) and tokens shorter than 3 chars. So 'Dr Stefan Müller' → ['dr stefan müller',
    'stefan', 'müller'] — the person is recognised whether the prompt says the full name, 'Stefan' or 'Müller'."""
    nm = (name or "").strip().lower()
    if not nm:
        return []
    toks = [t for t in re.split(r"[\s/]+", nm) if len(t) >= 3 and t not in _NAME_TITLES]
    seen, out = set(), []
    for t in [nm] + toks:
        if t not in seen:
            seen.add(t); out.append(t)
    return out

def _text_has_word(word, low):
    return bool(re.search(r"(?<![a-z])" + re.escape(word) + r"(?![a-z])", low))

def _shot_has_people(scene, doc):
    """True if this shot plausibly contains a PERSON — a named roster character in the prompt, a director-set
    generic person, a split, or any generic person cue. False ONLY for pure object/product/anatomy shots with
    no human signal at all (where attaching a face reference just grafts it onto the object → 'head on belly')."""
    if scene.get("split") or scene.get("generic"):
        return True
    low = (scene.get("prompt") or "").lower()
    for c in (doc.get("characters") or []):
        # a character named in the prompt by full name OR any first-name/surname token → a person is present
        if any(_text_has_word(t, low) for t in _char_name_tokens(c.get("name"))):
            return True
    return bool(_PERSON_CUES.search(scene.get("prompt") or ""))

def scene_face_chars(scene, doc):
    """The cast (with photos) to FACE-LOCK for this shot. Empty when the shot has no person at all — so a face
    reference is never pasted onto an object/product/anatomy. Single source of truth for assemble + submit."""
    chars = [c for c in scene_characters(scene, doc) if char_urls(c)]
    if chars and not _shot_has_people(scene, doc):
        return []
    return chars

def scene_ingredients(scene, doc):
    """Resolve a scene's `ingredients` (roster ids) → ingredient dicts (the product's real ingredients shown here)."""
    by_id = {i.get("id"): i for i in (doc.get("ingredients") or [])}
    return [by_id[iid] for iid in (scene.get("ingredients") or []) if iid in by_id]

def scene_ingredient_refs(scene, doc):
    """Ingredients IN this shot that carry a reference image → attached (i2i) so the on-screen ingredient
    matches the approved look."""
    return [i for i in scene_ingredients(scene, doc) if [u for u in (i.get("urls") or []) if u]]

# --- transforming characters (e.g. someone who slims down across the video) ------------------------
# A character marked `transforms` has TWO reference buckets: `urls` = START look (e.g. heavier) and
# `urls_end` = END look (e.g. slim). The director tags each scene with the character's STAGE at that
# point (start / mid / end); we then attach the matching photo(s) and word the face-lock accordingly,
# so the SAME face stays consistent while the body changes gradually over the script.
def _char_state(c, s):
    """This transforming character's stage in THIS scene: 'start' | 'mid' | 'end' (None if not transforming)."""
    if not c.get("transforms"):
        return None
    v = str((s.get("states") or {}).get(c.get("id")) or "").strip().lower()
    return v if v in ("start", "mid", "end") else "start"   # default to START (the original reference)

def char_end_urls(c):
    return [u for u in (c.get("urls_end") or []) if u]

def char_urls_for(c, s):
    """The reference image(s) to attach for this character IN THIS scene. Normal characters → all their
    photos. A transforming character → the photo(s) for their stage here (start / mid=both / end)."""
    base = char_urls(c)
    if not c.get("transforms"):
        return base
    end = char_end_urls(c)
    if not end:                       # slim photo not uploaded yet → behave like a normal character
        return base
    st = _char_state(c, s)
    if st == "end":
        return end or base
    if st == "mid":
        return base + end             # both looks → the model interpolates a believable in-between
    return base                       # start

def _transform_who(c, s):
    """Face-lock wording for a transforming character at its current stage: keep the SAME face, but let the
    BODY match this scene's stage (so a single set of photos still yields a gradual, on-model transformation)."""
    name = c.get("name") or "the character"
    st = _char_state(c, s)
    has_end = bool(char_end_urls(c))
    if st == "end":
        return (f"{name}: depict her EXACTLY as in the slim reference image — same face, hair, identity AND the SAME slim, "
                f"lean, fit body shown there. This is her AFTER / transformed look; do NOT make her heavier or fuller than "
                f"the slim reference, and do NOT blend in any earlier heavier look. Match the slim reference faithfully.")
    if st == "mid" and has_end:
        return (f"{name}: keep the EXACT SAME face, hair and identity as in the reference images. Her body is MID-transformation "
                f"— clearly and noticeably slimmer than the heavier (start) reference, but not yet as lean as the slim (end) reference. "
                f"Render a believable in-between weight. Only the body changes, never the face.")
    if st == "mid":
        return (f"{name}: keep the EXACT SAME face and hair as in the reference; her body is MID-transformation — clearly and "
                f"noticeably slimmer than in the reference (do NOT copy the reference's fuller body). Only the body changes, never the face.")
    return (f"{name}: depict with the SAME face and overall appearance as in the reference — she is at the START, before her transformation.")

def _auto_anchor(doc, s):
    """AUTO-ANCHOR: when a scene is approved and it contains EXACTLY ONE recurring cast character that
    has no reference photo AND no anchor yet, adopt this approved frame as that character's anchor. From
    then on later scenes with that character use it as an i2i face-lock, so a photo-less recurring person
    stays the same face across the whole video. Ambiguous shots (2+ un-anchored photo-less people) are
    skipped — we can't attribute a single face. Mutates the shared character dict in doc (persisted on save)."""
    approved = (s.get("image") or {}).get("approved_file") or (s.get("image") or {}).get("file")
    if not approved:
        return
    fresh = [c for c in scene_characters(s, doc) if not char_has_photo(c) and not c.get("anchor")]
    if len(fresh) == 1:
        fresh[0]["anchor"] = approved

def _cont_source(scene, doc):
    """The earlier scene this one visually continues (same place + people), by stable uid, or None."""
    u = scene.get("cont_of")
    return next((x for x in doc.get("scenes", []) if x.get("uid") == u), None) if u else None


# When Kie breaks a SPECIFIC model (opus/sonnet return an `error` event "Server exception" at HTTP 200 while
# another model still streams fine — observed 2026-08-08), fall through to the next model instead of failing the
# whole step. Order = requested model first, then these, deduped. fable-5 is the most reliable fallback.
_CLAUDE_FALLBACKS = ["claude-sonnet-5", "claude-fable-5"]

def _claude_stream_once(system, user, max_tokens, model):
    # Kie's NON-streaming /claude/v1/messages path returns HTTP 500 "Server exception" in bursts while the
    # STREAMING path keeps working (it's what Kie's own playground uses). So we STREAM and accumulate the text
    # deltas. Read raw bytes + decode UTF-8 ourselves — iter_lines(decode_unicode=True) uses latin-1 and mangles
    # em-dashes / £ / accented names. Raises on an error event / empty stream so _retry + fallback can act.
    with requests.post(KIE_CLAUDE_URL,
                       headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                       json={"model": model, "max_tokens": max_tokens, "system": system,
                             "messages": [{"role": "user", "content": user}], "stream": True},
                       stream=True, timeout=120) as r:
        parts, err = [], None
        for raw in r.iter_lines():
            if not raw:
                continue
            line = raw.decode("utf-8", "ignore")
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                ev = json.loads(payload)
            except Exception:
                continue
            et = ev.get("type")
            if et == "content_block_delta":
                parts.append((ev.get("delta") or {}).get("text", ""))
            elif et == "error":
                e = ev.get("error") or {}
                err = e.get("message") or e.get("type") or "stream error"
        text = "".join(parts).strip()
        if text:
            return text
        raise RuntimeError(err or f"HTTP {r.status_code} (empty stream)")

_MODEL_COOLDOWN = {}      # model -> time.time() of its last failure; skip re-hammering a model Kie just broke

def _claude_text_kie(system, user, max_tokens=1024, model=None, tries=8):
    """[KIE PROVIDER] Stream a completion from Kie, ALWAYS starting with the best (requested) model and only
    falling through to the next when it errors — so a Kie per-model outage (opus down but fable up) degrades
    gracefully. A model that just failed is briefly tried only ONCE (cooldown) so we reach the working model
    fast during an outage, then go back to the best model once it recovers."""
    primary = model or PROMPT_MODEL
    chain, seen = [], set()
    for m in [primary, *_CLAUDE_FALLBACKS]:
        if m and m not in seen:
            seen.add(m); chain.append(m)
    now = time.time()
    last = None
    for i, mdl in enumerate(chain):
        recent_fail = (now - _MODEL_COOLDOWN.get(mdl, 0)) < 90     # Kie broke this model in the last 90s
        t = 1 if recent_fail else (tries if i == 0 else 3)         # full budget for the best model; probe others briefly
        try:
            r = _retry(lambda mdl=mdl: _claude_stream_once(system, user, max_tokens, mdl), tries=t, base=0.8)
            _MODEL_COOLDOWN.pop(mdl, None)                          # recovered → best model is preferred again
            return r
        except Exception as e:
            _MODEL_COOLDOWN[mdl] = time.time()
            last = e
    raise last if last else RuntimeError("no model available")

# ---- TEXT PROVIDER: the user's Claude subscription via the local Claude Code CLI (no API key, no per-token cost) ----
# EVERY text/script LLM call funnels through _claude_text. Default provider = the local `claude` CLI (subscription).
# Set VSL_TEXT_PROVIDER=kie to route every text step back to the Kie.ai API. Images/video ALWAYS use Kie regardless.
TEXT_PROVIDER = (os.environ.get("VSL_TEXT_PROVIDER") or "claude").strip().lower()
_CLAUDE_EXE_CACHE = None

class ClaudeNotLoggedIn(RuntimeError):
    pass

def _find_claude_exe():
    """Locate the installed Claude Code CLI (winget/native/PATH). Cached. None if not installed."""
    global _CLAUDE_EXE_CACHE
    if _CLAUDE_EXE_CACHE is not None:
        return _CLAUDE_EXE_CACHE or None
    import shutil, glob as _glob
    cands = []
    la = os.environ.get("LOCALAPPDATA", "")
    if la:
        cands.append(os.path.join(la, "Microsoft", "WinGet", "Links", "claude.exe"))
        cands += _glob.glob(os.path.join(la, "Microsoft", "WinGet", "Packages", "Anthropic.ClaudeCode*", "claude.exe"))
        cands.append(os.path.join(la, "Programs", "claude.exe"))
    w = shutil.which("claude")
    if w:
        cands.append(w)
    for c in cands:
        if c and os.path.exists(c):
            _CLAUDE_EXE_CACHE = c
            return c
    _CLAUDE_EXE_CACHE = ""
    return None

def _cli_model(model):
    m = (model or "").lower()
    if "sonnet" in m: return "sonnet"
    if "haiku" in m: return "haiku"
    return "opus"                       # default (and fable/opus) -> the subscription's best

def _claude_cli_text(system, user, model=None):
    """One text completion through the local Claude Code CLI = the user's SUBSCRIPTION (no API key/cost).
    Raises ClaudeNotLoggedIn if the CLI is missing or not logged in so the UI can warn (NO Kie fallback)."""
    import tempfile
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed on this PC. Install it (winget install Anthropic.ClaudeCode) and run 'claude' to log in.")
    prim = _cli_model(model)
    fb = "sonnet" if prim != "sonnet" else "haiku"
    cwd = os.path.join(tempfile.gettempdir(), "vsl_claude")
    try: os.makedirs(cwd, exist_ok=True)
    except Exception: cwd = tempfile.gettempdir()
    args = [exe, "-p", "--model", prim, "--fallback-model", fb,
            "--system-prompt", system, "--output-format", "text"]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    def _do():
        p = subprocess.run(args, input=(user or "").encode("utf-8"),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           cwd=cwd, startupinfo=si, timeout=300)
        out = (p.stdout or b"").decode("utf-8", "ignore").strip()
        err = (p.stderr or b"").decode("utf-8", "ignore").strip()
        if "Not logged in" in out or "Please run /login" in out or "Not logged in" in err:
            raise ClaudeNotLoggedIn("Your Claude subscription is not logged in on this PC. Open a terminal, run 'claude', and log in — then try again.")
        if not out:
            raise RuntimeError(err or "empty response from Claude CLI")
        return out
    return _retry(_do, tries=3, base=0.8)

def _claude_text(system, user, max_tokens=1024, model=None, tries=8):
    """Single entry point for ALL text/script LLM calls (split, director, cast, ingredients, avatar, prompt,
    still-image, translate, FAQ keywords, audit). Default provider = the local Claude Code CLI (the user's
    subscription, no API cost); set VSL_TEXT_PROVIDER=kie to route every text step back to Kie.ai. Images/video
    always use Kie regardless. On the CLI provider there is NO silent Kie fallback — a clear ClaudeNotLoggedIn
    error surfaces so the user knows to log in on this machine."""
    if TEXT_PROVIDER == "kie":
        return _claude_text_kie(system, user, max_tokens=max_tokens, model=model, tries=tries)
    return _claude_cli_text(system, user, model=model)

def _claude_vision(system, user, image_path, model=None):
    """One VISION completion via the local Claude Code CLI (the user's SUBSCRIPTION): it opens the image file
    and answers based on what is ACTUALLY in it. Used for image-aware video-prompt generation / QA. Uses Sonnet
    by default (plenty for image understanding, far lighter than Opus at scale). Raises ClaudeNotLoggedIn if the
    CLI is missing or not logged in."""
    import tempfile
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed / not logged in on this PC.")
    prim = _cli_model(model or "claude-sonnet-5")
    imgdir = os.path.dirname(image_path)
    args = [exe, "-p", "--model", prim, "--system-prompt", system, "--output-format", "text",
            "--allowedTools", "Read", "--add-dir", imgdir]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    full = f"{user}\n\nOpen and LOOK AT this image file, then answer: {image_path}"
    def _do():
        p = subprocess.run(args, input=full.encode("utf-8"), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           cwd=imgdir, startupinfo=si, timeout=180)
        out = (p.stdout or b"").decode("utf-8", "ignore").strip()
        err = (p.stderr or b"").decode("utf-8", "ignore").strip()
        if "Not logged in" in out or "Please run /login" in out or "Not logged in" in err:
            raise ClaudeNotLoggedIn("Your Claude subscription is not logged in on this PC. Run 'claude' and log in.")
        if not out:
            raise RuntimeError(err or "empty vision response")
        return out
    return _retry(_do, tries=2, base=0.8)

def claude_prompt(vo, onscreen, aud=None, forced_style=None, cast_names=None, brief=""):
    """Ask Claude (via Kie.ai) for (image_prompt, style_key)."""
    user = f"VO sentence: {vo}"
    if onscreen:
        user += f"\nOn-screen note: {onscreen}"
    if (brief or "").strip():
        user += (f"\n\nPROJECT CONTEXT (background about the whole project — may be in Turkish; for CONSISTENCY only): "
                 f"{brief.strip()}\nUse it to keep people, places, product and style consistent across scenes, but depict "
                 f"ONLY what THIS scene's VO describes — do NOT add the product, characters, or details the VO doesn't "
                 f"mention. Always write the final description in English.")
    if cast_names:
        user += (f"\nNamed characters present in THIS scene: {', '.join(cast_names)}. "
                 "When one of them appears, refer to them by their name (e.g. write the name, not "
                 "'a woman' / 'a man'). Do NOT invent characters who aren't in the sentence.")
    if forced_style:
        user += f"\nRequired STYLE: {forced_style}"
        if forced_style == "2d":
            user += ("\nThis scene will be drawn as a SIMPLE flat 2D cartoon, so describe it simply and iconically: "
                     "the key subject(s), their action, and only the one or two essential objects. Do NOT pile on fine "
                     "realistic micro-detail, intricate textures, or photographic specifics — those don't suit a flat cartoon.")
        elif forced_style == "scientific":
            user += ("\nThis scene is a medical / scientific visualization (inside the body, an organ, cells, etc.), so "
                     "describe the anatomical subject and what it shows clearly and specifically.")
    text = _claude_text(PROMPT_SYSTEM, user)
    style = None
    m = re.match(r"\s*STYLE:\s*([a-zA-Z0-9]+)", text)
    if m:
        k = m.group(1).lower()
        if k in STYLE_KEYS:
            style = k
        text = text[m.end():].lstrip("\n").strip()
    if forced_style:
        style = forced_style
    return text, style

def translate_to_english(text):
    return _claude_text(
        "Translate the user's image-generation prompt into natural English. "
        "Keep it as one single prompt with the same meaning. Output ONLY the translation.",
        text)

def localize_prompt(prompt, aud, translate=True, signage=False):
    """Translate Turkish prompts to English. `translate=False` keeps the user's exact wording.
    `signage=True` also requires any on-image text to be in the country's language — OFF by default
    because image prompts end with 'No text.', so a signage-language clause would only contradict it."""
    p = prompt or ""
    if translate and looks_turkish(p):
        try:
            p = translate_to_english(p)
        except Exception:
            pass
    if signage:
        lang = country_language(aud)
        if lang and lang != "English":
            p = p.rstrip() + f" If any text, signage, or packaging appears, it must be written in {lang}."
    return p

_CURRENCY_HINT = {
    "pound": "British pounds — the £ symbol", "gbp": "British pounds — the £ symbol", "sterling": "British pounds — the £ symbol",
    "euro": "euros — the € symbol", "eur": "euros — the € symbol",
    "dollar": "US dollars — the $ symbol", "usd": "US dollars — the $ symbol",
    "lira": "Turkish lira — the ₺ symbol", "try": "Turkish lira — the ₺ symbol",
    "yen": "Japanese yen — the ¥ symbol", "rupee": "Indian rupees — the ₹ symbol",
}
# Money/price cues (English + Turkish). The currency directive below is emitted ONLY when the shot
# actually depicts money — so its "£ symbol" tokens can't leak onto money-less scenes. Image models
# ignore the "if any money appears" conditional and would otherwise sprinkle a £ into e.g. a phone-call
# shot (scene #58). Precision-tuned: 'sipariş'/'al'/'öde-'stem excluded so 'paragraf','ödev' don't trip it.
_MONEY_CUES = re.compile(
    r"[£$€₺]"
    r"|\b(money|cash|price[ds]?|pricing|cost|costs|costly|pay|paying|payment|payments|paid"
    r"|buy|buying|bought|purchas\w+|checkout|check-out|receipt|invoice|wallet|coin|coins"
    r"|dollar|dollars|euro|euros|currency|discount|discounts|afford|affordable|budget"
    r"|fee|fees|subscription|refund|refunds|coupon|price[- ]?tag|banknotes?|bills?|quid|spend|spent|spending|savings?)\b"
    r"|\bpara(lar|m|n|sı|yı|ya|yla|nın)?\b"
    r"|\bfiyat\w*|\bücret\w*|\bödeme\b|\bsatın\b|\balışveriş\w*"
    r"|\bsepet\w*|\bfatura\w*|\bmakbuz\w*|\bcüzdan\w*|\bnakit\b|\blira\b|\bsterlin\b"
    r"|\bkuruş\b|\bindirim\w*|\btaksit\w*|\bbütçe\w*|\bpahalı\b|\bucuz\b",
    re.I)
# "pound(s)" is ambiguous — MONEY (£) vs WEIGHT (lbs). Only treat it as money when it's clearly not weight.
_WEIGHT_CUES = re.compile(r"\b(weigh\w*|weight|lost|lose|losing|los[et]|shed\w*|dropp\w*|lighter|slim\w*|"
                          r"leaner|thinner|fatter|overweight|obese|scales?|kg|kilo\w*|lbs|belly|body ?weight)\b", re.I)
def _mentions_money(text):
    """True if the shot description plausibly depicts money/prices (English or Turkish)."""
    t = text or ""
    if _MONEY_CUES.search(t):
        return True
    # a NUMBER + "pound(s)" reads as money ONLY when the shot isn't clearly about weight (lost/weigh/slim…)
    if re.search(r"\b\d[\d,.]*\s*pounds?\b", t, re.I) and not _WEIGHT_CUES.search(t):
        return True
    return False

def _currency_clause(aud, text=""):
    """Currency directive for the final image prompt — emitted ONLY when `text` (the shot description)
    actually shows money/prices. Gating on money content stops the "£ symbol" tokens leaking onto
    money-less scenes. Fixes the model defaulting to US dollars when the audience is e.g. UK/£."""
    curs = [str(c).strip() for c in ((aud or {}).get("currencies") or []) if str(c).strip()]
    if not curs or not _mentions_money(text):
        return ""
    hint = _CURRENCY_HINT.get(curs[0].lower(), curs[0])
    clause = (f"Any money, cash, banknotes, prices or price tags anywhere in the image MUST be {hint} — the correct "
              f"real banknotes/coins and symbol for that currency. Do NOT show US dollars, dollar bills or the $ "
              f"symbol (unless that IS the currency above), and do not mix currencies.")
    if curs[0].lower() in ("pound", "gbp", "sterling"):
        clause += " Here 'pounds' means British MONEY (£ sterling banknotes), not a unit of weight."
    return clause

def _raw_audience_note(aud, text=""):
    """Compact Target-Audience reminder appended to a RAW (user-written) prompt: market/location, age band,
    excluded looks, and currency. Kept short so it never rewrites the user's own wording — used ONLY in raw mode.
    `text` is the shot description; the currency line is added only if it actually depicts money/prices."""
    if not aud:
        return ""
    bits = []
    locs = [str(x).strip() for x in (aud.get("locations") or []) if str(x).strip()]
    if locs:
        bits.append(f"Set it in a {', '.join(locs)} context — signage, packaging, products and surroundings "
                    f"appropriate to {', '.join(locs)}.")
    ages = [str(a).strip() for a in (aud.get("ages") or []) if str(a).strip()]
    if ages:
        bits.append(f"Any ordinary people shown should be adults roughly in the {' or '.join(ages)} age range.")
    av = (aud.get("avatar") or "").strip()
    if av:
        bits.append(f"Any ordinary/relatable person shown is the target viewer — they look like: {av} (match this to the "
                    f"before/after state your prompt describes).")
    excl = aud.get("appearance")
    if excl:
        bits.append("Do NOT depict ordinary people who look " + ", ".join(excl) + ".")
    cc = _currency_clause(aud, text)
    if cc:
        bits.append(cc)
    return " ".join(bits)

def bind_named_cast(s, doc):
    """Ensure every roster character NAMED in the scene's prompt is in the scene's cast, so their reference
    face actually attaches (fixes e.g. a split's LEFT half naming 'Dr Carbonell' but her not being cast).
    Additive only — never removes a cast the user picked. Skipped for RAW scenes. Returns True if it changed."""
    if s.get("no_cast"):
        return False
    prompt = (s.get("prompt") or "")
    if not prompt.strip():
        return False
    low = prompt.lower()
    chars = doc.get("characters") or []
    # How many characters own each name token → a token shared by 2+ people (e.g. two "Dr Stefan"s) is AMBIGUOUS
    # and must NOT auto-bind, so we never attach the wrong face. A unique token (surname/first name) binds fine.
    owners = {}
    char_toks = {}
    for c in chars:
        toks = _char_name_tokens(c.get("name"))
        char_toks[c.get("id")] = toks
        for t in toks:
            owners[t] = owners.get(t, 0) + 1
    cast = s.setdefault("cast", [])
    locked = set(s.get("cast_locked") or [])   # ids the user explicitly removed → never silently re-add them
    changed = False
    for c in chars:
        cid = c.get("id")
        name = (c.get("name") or "").strip()
        if not cid or not name or cid in cast or cid in locked:
            continue
        # match on the full name, or on any name token that is UNIQUE to this character
        if any(owners.get(t, 0) == 1 and _text_has_word(t, low) for t in char_toks.get(cid, [])):
            cast.append(cid)
            changed = True
    return changed

SPLIT_CLAUSE = ("Compose this as ONE single image split into two side-by-side panels of EQUAL width — a seamless "
                "diptych with NO dividing line, bar, border or frame between the two halves. The description gives a "
                "LEFT half and a RIGHT half; render each subject in its own half of the same frame. Each half is drawn "
                "in the LOOK stated for it — the two halves MAY use DIFFERENT styles (e.g. a photorealistic photo on one "
                "side and a scientific 3D medical illustration on the other); follow exactly the look written for each half.")

SPLIT_CLAUSE_3 = ("Compose this as ONE single image split into three side-by-side panels of EQUAL width — a seamless "
                  "triptych with NO dividing line, bar, border or frame between the panels. The description gives a "
                  "LEFT, a MIDDLE and a RIGHT panel; render each subject in its own third of the same frame, in that "
                  "left-to-right order. Each panel is drawn in the LOOK stated for it — the panels MAY use DIFFERENT "
                  "styles; follow exactly the look written for each panel.")

# A panel marker is the label word (left/middle/right) optionally followed by its inline look, then a colon —
# e.g. "LEFT:" OR "LEFT, photorealistic:" OR "RIGHT, scientific 3D medical illustration:".
def _panel_mark_re(key):
    return r"(?<![a-z])" + key + r"\b[^:\n]{0,40}:"

SPLIT_CLAUSE_4 = ("Compose this as ONE single image divided into FOUR equal panels — a clean 2x2 grid of the same "
                  "size (top-left, top-right, bottom-left, bottom-right), a seamless composite with NO dividing lines, "
                  "bars, borders or frames between the panels. The description gives a TOP-LEFT, TOP-RIGHT, BOTTOM-LEFT "
                  "and BOTTOM-RIGHT panel; render each subject in its own quarter of the same frame, in that order. Each "
                  "panel is drawn in the LOOK stated for it — the panels MAY use DIFFERENT styles; follow exactly the "
                  "look written for each panel.")

def _split_clause(prompt_text):
    """Pick two-/three-/four-panel wording from what the prompt actually describes (a MIDDLE panel → triptych; a
    TOP-LEFT/BOTTOM-… panel → 2x2 quad)."""
    low = (prompt_text or "").lower()
    if re.search(r"(?<![a-z])(?:top|bottom)[ -](?:left|right)\b[^:\n]{0,40}:", low):
        return SPLIT_CLAUSE_4
    return SPLIT_CLAUSE_3 if re.search(_panel_mark_re("middle"), low) else SPLIT_CLAUSE

def _split_default_look(style):
    """A split skips the single global STYLE preset (each panel can state its own look). But the bare word
    'photorealistic' in a panel is a WEAK anchor — the model drifts to a glossy CGI/stock look. So re-apply
    the chosen style's FULL guidance as the DEFAULT look for any panel that doesn't explicitly call for a
    different medium. This is what pulls a 'photorealistic' panel back to a real, candid photo."""
    preset = STYLE_PRESETS.get(style or "natural", "")
    if not preset:
        return ""
    return ("DEFAULT LOOK — apply this to EVERY panel whose own description does not explicitly call for a "
            "different medium (a panel that literally says it is a 2D cartoon, or a scientific 3D medical "
            "illustration, keeps that): " + preset.strip())

def _panel_side_of(prompt_text, name):
    """Which panel (LEFT / MIDDLE / RIGHT) a named person is described in, by reading the split prompt. None
    if it can't be determined."""
    low = (prompt_text or "").lower()
    marks = []
    for key, disp in (("left", "LEFT"), ("middle", "MIDDLE"), ("right", "RIGHT")):
        m = re.search(_panel_mark_re(key), low)
        if m:
            marks.append((m.start(), disp))
    marks.sort()
    idx = low.find((name or "").lower())
    if idx < 0 or not marks:
        return None
    cur = None
    for p, disp in marks:
        if p <= idx:
            cur = disp
        else:
            break
    return cur

def _split_who(scene, chars):
    """WHO wording for a SPLIT with named cast: bind EACH person to their OWN reference face and their OWN
    panel, and forbid duplicating one face across panels. Fixes the bug where two different people (each with
    a photo) collapsed to the same face in both halves."""
    prompt = scene.get("prompt") or ""
    bits = []
    for c in chars:
        nm = c.get("name")
        if not nm:
            continue
        sd = _panel_side_of(prompt, nm)
        bits.append(f"{nm} (the {sd} panel)" if sd else nm)
    who = "; ".join(bits)
    return ("The reference images show DIFFERENT people, one per panel: " + who + ". Give EACH named person "
            "their OWN face and appearance from their OWN reference image — they are DISTINCT individuals and "
            "MUST look clearly different. Do NOT reuse or duplicate the same face across panels: the person in "
            "one panel must NOT also appear in another panel.")

def _multi_who(chars):
    """WHO wording for a NON-split scene with 2+ named cast that have photos: bind each face to the right
    person (photos are provided in cast order) and forbid blending/swapping. The single-frame cousin of
    _split_who — fixes two different people collapsing into one face when several references are attached."""
    names = [c.get("name") for c in chars if c.get("name")]
    order = ", then ".join(names)
    joined = ", ".join(names)
    return (f"The reference photos of these DIFFERENT people are provided in this order: {order}. Give EACH person "
            f"their OWN face and appearance from their OWN photo — {joined} are DISTINCT individuals; do NOT blend, "
            f"swap or merge their faces. (Any other reference image is a prop/product or a previous frame, not these people.)")

def _scene_has_ordinary(s):
    """Does this scene plausibly contain ORDINARY (non-cast) people? True if the director flagged a generic
    person, there is no named cast, or the prompt implies bystanders/crowd. Used to add the diversity /
    excluded-looks guidance ONLY when it's relevant (skips the noise on pure single-cast shots)."""
    if s.get("generic"):
        return True
    # NB: a scene with NO cast is NOT automatically "has ordinary people" — a product/object/anatomy shot has
    # no person, and injecting the target-viewer avatar there spawned a spurious (overweight) person. Require an
    # actual person cue in the prompt instead.
    p = (s.get("prompt") or "").lower()
    return bool(re.search(r"\b(people|crowd|everyone|others|family|friends|group|passers?-?by|bystander|audience|"
                          r"patients|customers|shoppers|colleagues|team|neighbou?rs|kids|children|"
                          r"woman|women|man|men|person|lady|guy|mother|father|mom|mum|dad|husband|wife|"
                          r"another (?:man|woman|person)|other (?:men|women|people))\b", p))

# nationality / ethnicity / region words the SCRIPT itself may explicitly call for (EN + FR + common variants).
# When a scene's own text names one, that look is ESSENTIAL to the meaning — we keep it and do NOT apply the
# target-audience excluded-looks to that scene (an explicit "des Japonais" must never be flipped to the audience).
_ETHNIC_TERMS = {
    "japanese": "Japanese", "japon": "Japanese", "japonais": "Japanese", "japonaise": "Japanese",
    "japonaises": "Japanese", "chinese": "Chinese", "chinois": "Chinese", "chinoise": "Chinese",
    "chine": "Chinese", "china": "Chinese", "korean": "Korean", "coreen": "Korean", "coréen": "Korean",
    "coréenne": "Korean", "coree": "Korean", "corée": "Korean", "indian": "Indian", "indien": "Indian",
    "indienne": "Indian", "inde": "Indian", "thai": "Thai", "thaï": "Thai", "vietnamese": "Vietnamese",
    "vietnamien": "Vietnamese", "african": "African", "africain": "African", "africaine": "African",
    "afrique": "African", "mexican": "Mexican", "mexicain": "Mexican", "italian": "Italian",
    "italien": "Italian", "italienne": "Italian", "italie": "Italian", "greek": "Greek", "grec": "Greek",
    "grecque": "Greek", "spanish": "Spanish", "espagnol": "Spanish", "espagnole": "Spanish",
    "arab": "Arab", "arabe": "Arab", "asian": "Asian", "asiatique": "Asian", "asiatiques": "Asian",
    "mediterranean": "Mediterranean", "méditerranéen": "Mediterranean", "scandinavian": "Scandinavian",
    "nordic": "Nordic", "nordique": "Nordic", "brazilian": "Brazilian", "brésilien": "Brazilian",
    "russian": "Russian", "russe": "Russian", "turkish": "Turkish", "turc": "Turkish",
}
# words that mean the nationality describes an OBJECT/STUDY, not a PERSON — so we must NOT force that ethnicity
# on the people in the shot. e.g. "condiment japonais" / "recette japonaise" / "étude coréenne" / "extrait".
_ETH_OBJECT_CTX = ("condiment", "recette", "ail", "extrait", "produit", "sauce", "épice", "epice", "plat",
                   "étude", "etude", "revue", "journal", "recherche", "publiée", "publiee", "publié", "publie",
                   "study", "recipe", "extract", "garlic", "cuisine", "dish")

def _scene_ethnicity(s):
    """If the scene's OWN wording explicitly names a nationality/ethnicity for the PEOPLE in the shot (e.g.
    'des Japonais', 'Japanese people'), return the English label; else None. Does NOT fire when the nationality
    merely describes an OBJECT or a STUDY ('condiment japonais', 'étude coréenne') — that must not turn the
    on-screen VIEWER into that ethnicity (bug: an Asian French viewer for a 'condiment japonais' line)."""
    blob = " ".join(str(s.get(k) or "") for k in ("text", "vo", "vo_tr", "prompt", "shows"))
    low = blob.lower()
    for term, label in _ETHNIC_TERMS.items():
        for m in re.finditer(r"(?<![\w])" + re.escape(term) + r"(?![\w])", low):
            pre = low[max(0, m.start() - 30):m.start()]           # is it "<object> <nationality>"?
            if any(w in pre for w in _ETH_OBJECT_CTX):
                continue                                          # describes the condiment/study, not a person
            return label
    return None

def _gender_word(desc):
    """Confidently read a person's gender from their roster description, or None if unclear. Used only to
    ADD a gender anchor so a cast member keeps their gender even when the face is turned away / seen from
    behind (a reference photo can't lock gender when the face isn't visible). Never guesses when ambiguous."""
    d = " " + (desc or "").lower() + " "
    fem = bool(re.search(r"\b(woman|women|female|lady|girl|mother|wife|daughter|actress|businesswoman|grandmother|mom|mum)\b", d))
    masc = bool(re.search(r"\b(man|men|male|boy|father|husband|son|gentleman|businessman|grandfather|dad)\b", d))
    if fem and not masc:
        return "a woman"
    if masc and not fem:
        return "a man"
    return None

def _wants_text(prompt):
    """True if the prompt explicitly asks for specific text/numbers to be SHOWN in the image (a quoted phrase,
    a screen/label/sign reading something, 'show this number', etc.). Used to relax the blanket 'No text.' rule
    so the requested text survives while stray captions/watermarks are still blocked."""
    p = prompt or ""
    if re.search(r"[\"'“”‘’][^\"'“”‘’\n]{1,60}[\"'“”‘’]", p):   # any quoted phrase → they want it shown
        return True
    return bool(re.search(r"(reads?|reading|it says|that says|labell?ed|caption|on (the|its|her|his) screen|screen (show|display|read)|display(s|ing)?|billboard|headline|"
                          r"show(s|ing)? (this|these|the) (number|numbers|text|word|words|price|label|message|time|date))", p, re.I))

# ── Passive learning capture — records how sentences become prompts, changes NOTHING about generation ──
# Silently appends (voice-over line → the prompt + settings the director wrote, and the prompt finally
# APPROVED) to a log so we can LATER distil sentence→visual techniques into generalised director rules.
# Nothing is read back during normal use; every call is wrapped so it can never break a request. Turn off
# with env VSL_LEARN_CAPTURE=0.
LEARN_LOG = DATA_DIR / "learn" / "learn_log.jsonl"

def _stamp_director_prompt(scenes):
    """Remember the director's fresh prompt as a baseline on the scene, so when the user later hand-edits
    the prompt (even in Turkish) and approves, the (director original -> user final) delta is captured in
    one record — we can see exactly how the user rewrote the director's prompt for that sentence."""
    for sc in (scenes or []):
        try:
            if (sc.get("prompt") or "").strip():
                sc["director_prompt"] = sc["prompt"]
        except Exception:
            pass

def _learn_record(scene, doc):
    try:
        cast_names = [c.get("name") for c in scene_characters(scene, doc)] if doc else []
    except Exception:
        cast_names = []
    return {
        "ts": time.time(), "scene_id": scene.get("id"), "uid": scene.get("uid"),
        "vo": scene.get("vo") or "", "prompt": scene.get("prompt") or "",
        "director_prompt": scene.get("director_prompt") or "",   # what the director wrote before the user edited it
        "style": scene.get("style"), "camera": scene.get("camera"),
        "split": bool(scene.get("split")), "product": bool(scene.get("product")),
        "testimonial": bool(scene.get("testimonial")), "no_cast": bool(scene.get("no_cast")),
        "pure": bool(scene.get("pure")), "generic": scene.get("generic"),
        "ingredients": scene.get("ingredients") or [], "cast": cast_names,
    }

def _learn_log(event, project, doc, scenes):
    """event = 'director' (a prompt the director just wrote) or 'approved' (prompt on the approved version).
    Append-only, passive, best-effort — NEVER raises, NEVER affects the response."""
    try:
        if os.environ.get("VSL_LEARN_CAPTURE", "1") == "0":
            return
        aud = (doc or {}).get("audience") or {}
        aud_slim = {k: aud.get(k) for k in ("genders", "ages", "locations", "avatar", "appearance")}
        LEARN_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(LEARN_LOG, "a", encoding="utf-8") as f:
            for sc in (scenes or []):
                if (sc.get("note") or "").strip():
                    continue   # user left a NOTE on this scene → they plan to do something different in Premiere; exclude it from the learn data
                rec = _learn_record(sc, doc)
                if not (rec["prompt"].strip() or rec["testimonial"]):
                    continue
                rec.update(event=event, project=project, audience=aud_slim)
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass

# No ADDED marketing text (used in every mode incl. PURE/RAW). Bans invented captions/titles/badges/watermarks;
# real text that is the SUBJECT of the shot (a document, test result, certificate) is still allowed.
_NO_ADDED_TEXT = ("Do NOT add any captions, titles, subtitles, headlines, watermarks, logos, or marketing "
                  "badges/seals/callouts of your own — no text overlaid on the image. (Real text that is genuinely "
                  "part of the scene — a document, a test result, a certificate the shot is actually about — is fine.)")

def _grid_dims(n):
    """Rows/cols for a testimonial grid of n cells — landscape-biased (wider than tall), for 16:9."""
    layouts = {4: (2, 2), 6: (3, 2), 8: (4, 2), 9: (3, 3), 10: (5, 2), 12: (4, 3), 15: (5, 3), 16: (4, 4)}
    if n in layouts:
        return layouts[n]
    cols = max(2, round((n * 16 / 9) ** 0.5))
    rows = (n + cols - 1) // cols
    return cols, rows


def _testimonial_prompt(scene, aud):
    """Social-proof shot: ONE image laid out as an even grid of many SEPARATE amateur customer selfies, each an
    ordinary, SLIM, happy person holding the product. Built deterministically (ignores the written prompt) so it
    is consistent; the product reference attaches downstream so every bottle is the real product."""
    try:
        n = int(scene.get("testimonial_n") or 8)
    except (TypeError, ValueError):
        n = 8
    n = max(4, min(n, 16))
    cols, rows = _grid_dims(n)
    aud = aud or {}
    ages = [str(a).strip() for a in (aud.get("ages") or []) if str(a).strip()]
    age_phrase = " or ".join(ages) if ages else None
    excl = aud.get("appearance") or []
    parts = [
        f"One single photograph laid out as a STRICT grid of EXACTLY {cols} columns and {rows} rows — that is EXACTLY "
        f"{n} equal rectangular cells / {n} people IN TOTAL, no more and no fewer. Do NOT add any extra rows, columns, "
        f"cells or people beyond {rows} rows of {cols}. Equal-size cells separated by thin uniform white gaps, edge to "
        f"edge, filling the whole 16:9 frame.",
        f"Each of the {n} cells is a SEPARATE, authentic user-generated testimonial selfie of a DIFFERENT ordinary, "
        "real-looking, SLIM and happy person, each smiling warmly straight at the camera and holding the SAME product "
        "up toward the camera with one hand.",
        "Shoot every cell like a genuine phone snapshot in a DIFFERENT real place and pose — e.g. some SITTING on a "
        "sofa or at a table, some STANDING in a kitchen, some OUTDOORS in a garden / on a street / in a park, some in "
        "an office, a car or a cafe. Vary the background, lighting and time of day per cell. Real amateur UGC (a quick "
        "phone photo), NOT polished studio work, NOT stock photography, NOT professional models — ordinary, believable, "
        "genuinely happy satisfied customers.",
        "CRITICAL — every person is a COMPLETELY DIFFERENT, UNRELATED real stranger, like a collage of unrelated people; "
        "NEVER repeat a face and they must NOT look like siblings or the same person. Give them clearly different FACE "
        "SHAPES (round, oval, long, square, heart), different facial features, different HAIR (short, long, curly, "
        "straight, wavy, tied up, loose — and different natural shades within the allowed look), a real spread of AGES "
        "across the range (some in their late 40s, some in their 60s), and different expressions, glasses/no-glasses, "
        "clothing colours, settings and poses. No two cells should look alike. (Do NOT vary ethnicity — see the audience limit below.)",
        "AMATEUR QUALITY (very important — must NOT look like stock photography): each cell looks like a real customer's "
        "own phone snapshot — uneven / harsh available light (a touch of on-phone flash, mixed warm-and-cool indoor "
        "light, mild over- or under-exposure, some shadow on the face), slightly soft focus or minor motion blur, faint "
        "sensor noise/grain, imperfect white balance, a slightly awkward hand-held selfie angle and off-centre framing, "
        "and mundane, a little cluttered real backgrounds. The people are ORDINARY, plain, average-looking (NOT attractive "
        "models) with real UNRETOUCHED skin — visible pores, wrinkles, blemishes, redness, flyaway hair, some looking "
        "tired or plain. Absolutely NO studio lighting, NO softboxes, NO airbrushing/retouching, NO glossy stock-photo "
        "polish, NO perfect model faces.",
    ]
    who = []
    if age_phrase:
        who.append(f"adults roughly in the {age_phrase} age range (not younger or older)")
    if who:
        parts.append("The people are " + "; ".join(who) + ".")
    if excl:
        parts.append("STRICT audience limit — EVERY single person in the grid must fit the target audience: do NOT "
                     "include ANYONE who looks " + ", ".join(excl) + ". Keep all of them within the allowed look.")
    parts.append("The product every person holds is IDENTICAL to the product reference image — the SAME bottle/package "
                 "shape, label, wording and colours; do NOT redesign, rename or restyle it.")
    parts.append(_NO_ADDED_TEXT)
    return "\n".join(parts)


# Deterministic per-scene look for the ORDINARY/target-viewer person, so consecutive scenes that describe the
# SAME subject ("an ordinary overweight woman") don't collapse to the SAME face. Varies only FACE/HAIR/AGE +
# accessories — NEVER body/build (that follows the scene's before/after) and NO colour/ethnicity (the audience's
# excluded-looks list owns that). Rotated by scene id.
# Per-scene FACE nudge so identical subjects aren't the same face across scenes. Deliberately NEUTRAL:
# only hairstyle / face shape / accessories + a RELATIVE age (younger/middle/older end of the audience's
# own age band) — NO ethnicity, skin tone, hair colour or body/build, so it can never fight the audience's
# excluded-appearance list or the scene's before/after body state. The excl list is enforced separately.
_FACE_VARIETY = [
    "short cropped hair and reading glasses, a rounder face, at the older end of the target age range",
    "shoulder-length hair and a light scatter of freckles, in the middle of the target age range",
    "hair tied back in a low bun, an angular face, at the older end of the range",
    "a wavy bob and warm smile lines, in the middle of the range",
    "straight hair with slim glasses and higher cheekbones, toward the older end of the range",
    "loose curly hair and a fuller face, at the younger end of the target age range",
    "a short layered cut, at the younger end of the range",
    "long hair worn loose with soft features, in the middle of the range",
    "a neat side-parted style and a squarer jaw, toward the older end of the range",
    "hair in a high ponytail and an oval face, at the younger end of the range",
    "a chin-length blunt cut and a small mole on one cheek, in the middle of the range",
    "swept-back hair, deeper laugh lines and rectangular glasses, at the older end of the range",
    "a messy topknot and rounder cheeks, at the younger end of the range",
    "fine straight hair and a heart-shaped face, in the middle of the range",
    "a cropped pixie cut and a leaner face, toward the older end of the range",
    "shoulder-length layered hair and a broad friendly face, in the middle of the range",
    "close-cropped greying hair and a lined, kindly face, at the older end of the range",
    "a low side plait and soft round cheeks, at the younger end of the range",
    "thinning hair combed back and a narrow face, toward the older end of the range",
    "a shoulder-length shag cut and a wide jaw, in the middle of the range",
    "a neat bob with a straight fringe and an oval face, in the middle of the range",
    "short curls and a dimpled chin, at the younger end of the range",
    "half-up tied hair and prominent cheekbones, in the middle of the range",
    "a slicked-back short cut with a strong brow, toward the older end of the range",
]
# Per-scene OUTFIT / COLOUR nudge so consecutive ordinary-people shots aren't wearing the same clothes/colours.
# NEUTRAL (clothing style + colour only — never ethnicity/skin/build) and a FALLBACK: defers to any clothing the
# scene text already specifies. Indexed on a different stride from _FACE_VARIETY so face+outfit combos keep varying.
_OUTFIT_VARIETY = [
    "a navy crew-neck jumper", "an olive-green cardigan", "a burgundy blouse", "a light-grey henley shirt",
    "a mustard-yellow knit top", "a soft blue button-down shirt", "a charcoal zip-up hoodie",
    "a teal V-neck sweater", "a cream turtleneck", "a rust-orange flannel shirt", "a plum long-sleeve top",
    "a forest-green polo shirt", "a dusty-pink cardigan over a white tee", "a slate-blue sweatshirt",
    "a warm beige jumper", "a deep-red knit sweater", "a striped grey-and-white long-sleeve tee",
    "a denim shirt over a plain top",
]
# Per-scene SETTING nudge (mirror of _FACE_VARIETY) so consecutive everyday/relatable shots aren't the SAME
# home. Applied only as a FALLBACK — it defers to any concrete place the scene text already fixes.
_SETTING_VARIETY = [
    "a kitchen", "a living room / lounge", "a bedroom", "a home office or study",
    "a hallway or by the front door", "a dining area", "a back garden or patio", "a local park",
    "an ordinary residential street / pavement", "a cafe or coffee shop", "a workplace / office desk area",
    "the driver's seat of a car", "a supermarket / shop aisle", "a gym or leisure centre",
]

def build_image_prompt(scene, aud, chars=None, chars_desc=None):
    """Assemble the final Nano Banana prompt from NON-OVERLAPPING layers, each owning ONE thing so they
    can't conflict:  STYLE (how it looks) + SCENE (what's shown) + CAMERA (framing) + WHO (identity of
    recurring characters, via their reference image) + "No text".

    Audience gender/age/appearance is NOT bolted on here anymore (that collapsed everyone to one look and
    flipped genders scene-to-scene). Recurring people get their identity from the roster/reference; any
    ordinary/one-off person is already described (audience-appropriate) inside the scene text by the
    director. `chars` = the roster characters present in this scene that carry a reference image.
    The per-scene "no_cast" toggle = "MY PROMPT — raw": generate from the user's exact words like a direct
    manual generation (as if handed straight to the image model). It drops ALL auto layers — style preset,
    camera, roster characters, audience, auto-translate — and sends only the prompt (+ any reference image
    the user themselves attached to this scene) + "No text"."""
    chars = chars or []
    if scene.get("testimonial"):
        # Social-proof crowd: a grid of many separate amateur customer selfies, each holding the product.
        return _testimonial_prompt(scene, aud)
    if scene.get("pure"):
        # PURE mode: your exact prompt + the camera framing, and ONLY the references YOU explicitly attached
        # (cast picked in In-scene, a chosen Product, ingredient chips, images you uploaded). No auto layers —
        # no style preset, no audience, no diversity, no "No text", no continuity, no binding verbiage.
        parts = [(scene.get("prompt") or "").strip()]
        if scene.get("split"):
            parts.append(_split_clause(scene.get("prompt")))
        pcam = None if scene.get("split") else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))
        if pcam:
            parts.append(pcam["prompt"])
        # You explicitly attached something → tell the model to actually USE it (a single vague "use the
        # references" line was too weak; the product/cast you picked was being ignored). Still NO style /
        # audience / no-text / continuity — only the identity of what YOU attached.
        refbits = []
        if chars:
            names = ", ".join(c.get("name", "?") for c in chars if c.get("name"))
            if names:
                refbits.append(f"The attached reference photo(s) show {names} — depict each with the SAME face and overall appearance as in their own photo.")
        if scene.get("product"):
            refbits.append("One of the attached reference images is the PRODUCT — depict it EXACTLY as shown (the SAME bottle/package shape, label, wording, colours and number of units — do NOT redesign or add/remove units) and place it naturally in the scene.")
        if scene.get("ingredients"):
            refbits.append("Some attached reference images are the product's INGREDIENTS — depict each exactly as in its own image, and only these.")
        if scene.get("refs"):
            refbits.append("The attached reference image(s) are the VISUAL BASIS for this shot — faithfully reproduce the "
                           "specific object(s), place, layout, product or style they show and keep them accurate; they are "
                           "there to be USED, do NOT ignore them or treat them as loose inspiration.")
        if refbits:
            parts.append(" ".join(refbits))
        # NO "no added text" clause in PURE (nor in RAW): these are your-exact-words modes, and the user may
        # deliberately want on-image text — a title card, a research-paper page, a labelled document, etc.
        return "\n".join(p for p in parts if p and p.strip())
    hand = bool(scene.get("no_cast"))
    if hand:
        # RAW mode ("My prompt"): send the user's prompt VERBATIM (their words, their language — not
        # translated, no style preset / camera / audience-diversity / "No text" layers). We add only:
        #   (a) FACE-LOCK for any cast in this scene that HAS a reference photo → the person still looks right,
        #   (b) a short AUDIENCE reminder (market/location, age band, excluded looks).
        # Any reference image the user attached is still sent as i2i.
        parts = [(scene.get("prompt") or "").strip()]
        if scene.get("split"):
            parts.append(_split_clause(scene.get("prompt")))
        rcam = None if scene.get("split") else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))   # honour the camera angle in RAW too (user asked)
        if rcam:
            parts.append(rcam["prompt"])
        if chars:
            normal = [c for c in chars if not c.get("transforms")]
            trans = [c for c in chars if c.get("transforms")]
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference PHOTOS of {names} show those exact people — depict each with the SAME "
                             "face and overall appearance as in their OWN reference photo.")
            for c in trans:
                parts.append(_transform_who(c, scene))
        extra = _raw_audience_note(aud, scene.get("prompt"))
        if extra:
            parts.append(extra)
        return "\n".join(p for p in parts if p and p.strip())   # RAW stays VERBATIM (the user's exact words + only face/audience)
    parts = []
    split = bool(scene.get("split"))
    style = scene.get("style") or "natural"
    preset = STYLE_PRESETS.get(style, "")
    if preset and not split:   # a SPLIT styles each half from the prompt (director writes each half's look, possibly DIFFERENT) → no single global style preset
        parts.append(preset.strip())
        if scene.get("product") and style == "natural":
            _has_person = bool(chars) or bool(chars_desc) or scene.get("generic") or _PERSON_CUES.search(scene.get("prompt") or "")
            if _has_person:
                # product WITHIN a lifestyle scene → keep it small & natural; the giant-bottle problem comes from
                # copying the reference's studio scale, so pin it to real-world/hand size and ignore the ref's framing.
                parts.append("The product appears in a real-life scene WITH a person: keep it CLEAN and label-accurate, but "
                             "at a NATURAL, SMALL real-world size — a normal ~10 cm supplement bottle that fits in one hand "
                             "(smaller than the person's forearm), held naturally or resting on a surface and occupying only "
                             "a SMALL part of the frame. Do NOT enlarge it or make it a giant/floating hero, and do NOT copy "
                             "the scale or framing of the product reference image (use that ONLY for its label/design/colours). "
                             "It sits in the same lighting as the scene. IMPORTANT: the product must still be in SHARP FOCUS "
                             "with its LABEL crisp and clearly readable — natural does NOT mean blurry; if the shot has a soft "
                             "background, the held bottle is on the SAME focal plane as the person (both sharp), never soft or "
                             "out of focus.")
            else:
                # dedicated product-hero shot (no people) → clean & premium, may be prominent
                parts.append("This is a dedicated PRODUCT hero shot (no people): render the product CLEAN, sharp, in crisp "
                             "focus and nicely lit so it looks appealing and premium — this overrides the casual/amateur feel "
                             "above for the product itself. Keep it believable and real (not a fake glossy render).")
    if split:
        parts.append(_split_clause(scene.get("prompt")))
        dl = _split_default_look(scene.get("style"))   # top style = DEFAULT look for the panels (so "photorealistic" = a real candid photo, not stock 3D)
        if dl:
            parts.append(dl)
    # SCENE content. Auto-translate Turkish → English (this is not the raw/hand path).
    parts.append(localize_prompt(scene.get("prompt") or "", aud, translate=True))
    cam = None if split else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))   # a split/diptych composition owns the framing → skip camera
    if cam:
        parts.append(cam["prompt"])
    # WHO (identity). Reference images are attached as i2i inputs elsewhere; name them so each maps right.
    if chars:
        normal = [c for c in chars if not c.get("transforms")]
        trans = [c for c in chars if c.get("transforms")]
        if split and len(normal) >= 2:        # a split with 2+ named people → bind each to their OWN panel + face (no face-mixing)
            parts.append(_split_who(scene, normal))
        elif len(normal) >= 2:                # a single frame with 2+ named people → bind each face in order, no blending
            parts.append(_multi_who(normal))
        else:
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference PHOTOS of {names} show those exact people — depict each with the SAME "
                             "face and overall appearance as in their OWN reference photo. (Any other reference image "
                             "is a prop/product or a previous frame, NOT one of these people.)")
        # Gender anchor (additive): a reference photo can't lock gender when the face is turned away / seen from
        # behind (e.g. an over-the-shoulder shot), so state it in text for any cast whose gender is CLEAR from
        # their roster description. Only fires when confident — otherwise nothing is added (no behaviour change).
        gnotes = [f"{c['name']} is {_gender_word(c.get('desc'))}" for c in normal
                  if c.get("name") and _gender_word(c.get("desc"))]
        if gnotes:
            parts.append("Keep each person's gender correct even if their face is turned away or seen from behind: "
                         + "; ".join(gnotes) + ".")
        for c in trans:                       # a person mid-transformation: same face, body per this scene's stage
            parts.append(_transform_who(c, scene))
        if style in ("2d", "scientific"):     # the reference photos are photographic → tell the model to RE-DRAW the person in this medium, not paste a real face
            who_names = ", ".join(c["name"] for c in (normal + trans) if c.get("name"))
            medium = "2D cartoon style (bold outlines, flat cel-shading)" if style == "2d" else "3D CGI style"
            if who_names:
                parts.append(f"Use the reference photo(s) ONLY for {who_names}'s identity/likeness — RE-DRAW them fully "
                             f"in the {medium}; do NOT paste a photographic/real face into the image.")
    elif scene.get("refs"):
        refs = scene.get("refs") or []
        free = set(scene.get("ref_free") or [])
        if free & set(refs):
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face and identity faithful to the reference; their hairstyle may stay the same, "
                         "but they MUST wear DIFFERENT clothing/outfit that fits THIS scene — do NOT reuse "
                         "the same clothes as in the reference image.")
        else:
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face, hair, clothing/outfit and overall appearance faithful to the reference.")
    # recurring people WITHOUT a reference photo → inject their fixed roster description so they at least
    # stay look-consistent scene to scene (adding a reference photo later gives the exact same face).
    if chars_desc:
        who = "; ".join(f"{c['name']} ({c['desc']})" for c in chars_desc if c.get("name") and c.get("desc"))
        if who:
            parts.append("Keep these recurring people's appearance consistent every time: " + who + ".")
    # ORDINARY / one-off / background people: keep them a believable, DIVERSE mix so the video doesn't
    # show the same repeated face. This targets ONLY unnamed everyday people, never the referenced cast
    # above (whose look comes from their reference/description). Realistic style only. Also carries the
    # audience's "appearance to exclude" so unwanted looks are actually kept out at the image level (the
    # director alone can't enforce it — its scene text is barred from naming ethnicity/skin).
    # ORDINARY / one-off / background people: a DIVERSE mix (varied so the video doesn't repeat one face),
    # constrained to the audience AGE band, honouring the audience's excluded looks. Applies to people
    # styles (photoreal + 2D cartoon) — NOT scientific (inside-the-body anatomy has no ordinary people).
    # Targets only unnamed everyday people, never the named/recurring cast (whose look comes from their reference).
    if (scene.get("style") or "natural") != "scientific":
        excl = (aud or {}).get("appearance") if aud else None
        ages = [str(a).strip() for a in ((aud or {}).get("ages") or []) if str(a).strip()]
        age_phrase = " or ".join(ages) if ages else None
        # HARD rule (ALWAYS): never invent people.
        line = ("Include ONLY the people the scene describes. Do NOT add any extra, background, bystander or random "
                "person who is not explicitly called for — no filling the scene with incidental people.")
        # The age-band / diversity / excluded-looks guidance only matters when ORDINARY people actually appear —
        # skip it on a pure named-cast shot (there it's just noise, and a long exclusion list can bias the image).
        avatar = ((aud or {}).get("avatar") or "").strip()
        if _scene_has_ordinary(scene):
            age_bit = f" adults roughly in the {age_phrase} age range — not younger or older —" if age_phrase else ""
            sid = scene.get("id") or 0
            fv = _FACE_VARIETY[sid % len(_FACE_VARIETY)]   # per-scene look so identical subjects aren't the SAME face
            if avatar:
                # target-viewer VSL avatar: ordinary/relatable people embody the target's BUILD/CONDITION, following
                # whatever before/after state the scene text already describes (do NOT randomise body type here).
                line += (f" Any ordinary/relatable people (NOT the named/recurring character(s) above) are the TARGET "
                         f"VIEWER — depict them{age_bit} in the spirit of: {avatar}. The avatar sets their age and "
                         f"relatable vibe, but THIS scene's own words decide their BODY/BUILD and MOOD: if the scene "
                         f"describes them as slim / lean / energetic / transformed, depict them SLIM and happy and IGNORE "
                         f"any 'overweight' in the avatar; if the scene describes a 'before' / struggling moment, depict "
                         f"the heavier starting body. Make each ordinary person a DIFFERENT individual — vary their FACE "
                         f"shape, facial features, hairstyle and exact age; do NOT change their body/build (that is set by "
                         f"the scene's before/after above).")
            else:
                if age_phrase:
                    line += (f" Any ordinary/background people (NOT the named/recurring character(s) above) should be adults "
                             f"roughly in the {age_phrase} age range — not younger or older — and look like DIFFERENT "
                             f"individuals, varied in face, hairstyle and exact age (not all the same look).")
                else:
                    line += (" Any ordinary/background people (NOT the named/recurring character(s) above) should look like "
                             "DIFFERENT individuals — varied in face, hairstyle and age.")
            # deterministic per-scene look → consecutive scenes with the SAME subject description aren't the same woman
            line += (f" For the main ordinary/relatable person in THIS specific scene, lean toward: {fv} — a clearly "
                     f"different individual from other scenes (keep within the allowed look; do NOT change the body/build "
                     f"the scene calls for).")
            # per-scene OUTFIT/COLOUR (fallback): different clothes & colour each scene, unless the scene fixes them
            ov = _OUTFIT_VARIETY[(sid * 5 + 2) % len(_OUTFIT_VARIETY)]
            line += (f" If the scene does not already specify their clothing, dress the main ordinary/relatable person in "
                     f"{ov} — vary the outfit and colour from other scenes; ordinary, everyday clothing.")
            # per-scene SETTING nudge (fallback only): defers to a place the scene already names, and is skipped for a
            # continuation shot (same place carries over) so we don't fight deliberate continuity.
            if not scene.get("cont_of"):
                sv = _SETTING_VARIETY[(scene.get("id") or 0) % len(_SETTING_VARIETY)]
                line += (f" If the scene text does NOT already fix a specific place, set this shot in {sv}, and in general "
                         f"VARY the location from the other scenes — do NOT default to the same kitchen/home every time. "
                         f"If the scene already names a place, keep that place.")
            # If the SCRIPT itself calls for a specific nationality/ethnicity (e.g. "des Japonais"), that look is
            # essential — depict it and OVERRIDE the audience default/excluded-looks for THIS scene only.
            ethnicity = _scene_ethnicity(scene)
            if ethnicity:
                line += (f" IMPORTANT: the script explicitly makes the people in THIS scene {ethnicity} — depict them "
                         f"as {ethnicity} people. This is REQUIRED and OVERRIDES the target-audience appearance and any "
                         f"excluded-looks for this scene (do NOT restyle them to match the audience).")
            elif excl:
                line += " Do NOT depict ordinary people who look " + ", ".join(excl) + "."
        parts.append(line)
    # CLEAN & PROFESSIONAL by default — the candid/amateur LOOK must not become a shabby SUBJECT. Unless the
    # scene text explicitly calls for it, everything is clean, tidy and in good condition.
    parts.append("Unless the scene explicitly calls for it, keep everything CLEAN, tidy and in good condition: no "
                 "stains, dirt, grime, spills, damage, scratches, rust, wear or mess. Settings look ordinary, everyday "
                 "and relatable — clean and neat but NOT ultra-modern, luxury or showroom-like. Clothing and uniforms "
                 "(e.g. a doctor's white coat) are clean and neat; desks, rooms and equipment look well-kept.")
    # Fill the whole frame — nano sometimes pads a portrait subject with blurred side bars (a fake letterbox).
    parts.append("Fill the ENTIRE 16:9 frame edge to edge — no blurred side bars, black bars, borders, letterboxing, "
                 "vignette frames or split-screen panels (unless a side-by-side split is explicitly described).")
    # Product house style: capsules are white opaque.
    parts.append("Any capsule or pill shown is a plain WHITE OPAQUE capsule unless the scene explicitly says otherwise.")
    # Don't let the model sneak the finished/branded PRODUCT into a shot that isn't a product shot — the pack must
    # not appear before it's introduced / unless this scene is flagged as a product shot. Raw ingredients are fine.
    if not scene.get("product"):
        parts.append("Do NOT show the finished BRANDED PRODUCT in this shot — no supplement bottle, pill jar, tube, "
                     "box, sachet or product packaging of any kind, and no person holding such a product. (Raw "
                     "ingredients like the black garlic itself, ordinary food and everyday objects are fine.)")
    if (scene.get("style") or "natural") == "natural":
        parts.append("This is a REAL photograph: do NOT add any magical glow, radiant aura, halo, light rays, "
                     "sparkles, or 'energy/vitality' glow effects to people or objects.")
    cc = _currency_clause(aud, scene.get("prompt"))   # emitted only if the shot itself shows money/prices (e.g. UK → £, not $)
    if cc:
        parts.append(cc)
    # "No text" normally keeps out stray captions/watermarks — but if the prompt asks for specific text/numbers
    # (a scale reading "9 st 6 lb", a sign, a screen), a blanket "No text" fights it. In that case, allow the
    # requested text and block only the rest.
    if _wants_text(scene.get("prompt")):
        txt = ("Render the specific text/numbers described above ACCURATELY and legibly. Do NOT add any OTHER "
               "text, captions, watermarks, logos or UI beyond what is explicitly described.")
        # any words shown in the image must be in the audience's language, not English (French project -> French text)
        lang = country_language(aud)
        if lang and lang != "English":
            txt += (f" Any words, signage, labels, screen or document text visible in the image MUST be written in "
                    f"correct {lang}, not English.")
        parts.append(txt)
    else:
        parts.append(_NO_ADDED_TEXT)
    return "\n".join(p for p in parts if p and p.strip())

@app.route("/api/scenes/<project>/genprompt", methods=["POST"])
def api_genprompt(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    scenes = doc.get("scenes", [])
    target_ids = None if ids == "all" else set(ids)
    # Re-generate uses the SAME whole-script director as Split (arc-aware, reads every scene together) —
    # not the old single-sentence pass — then applies ONLY the image prompt (+ style) to the target
    # scene(s). The user's camera / cast / transition / continuity are left exactly as they set them.
    scene_texts = [(s.get("vo") or "").strip() for s in scenes]
    # only the TARGETED scenes need director output — pass their indices so we don't burn a whole-script pass
    # (and ~30× the credits) to regenerate a handful. Full script still travels as context. "all" → whole pass.
    targets = None if target_ids is None else {i for i, s in enumerate(scenes) if s.get("id") in target_ids}
    # honour the user's SPLIT toggle when re-generating: force the director to write the target scene as two
    # halves (split on) or a single image (split off), so a manual Split choice actually shapes the prompt.
    tset = set(range(len(scenes))) if targets is None else targets
    split_overrides = {i: bool(scenes[i].get("split")) for i in tset if not scenes[i].get("no_cast")}
    dmeta = None
    _gp_touched = []
    try:
        plan, dmeta = direct_scenes(scene_texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides, ingredients=doc.get("ingredients"))
    except Exception:
        plan = None                                            # director failed → per-scene fallback below
    for i, s in enumerate(scenes):
        if target_ids is not None and s["id"] not in target_ids:
            continue
        if s.get("no_cast"):          # RAW ("My prompt") scene → it's the user's own text; never overwrite it
            continue
        vo = (s.get("vo") or "").strip()
        if not vo:
            continue
        try:
            if plan and i < len(plan) and (plan[i].get("prompt") or "").strip():
                s["prompt"] = plan[i]["prompt"]               # ONLY the image content — KEEP the user's chosen style
                # (style is a separate layer the user controls; re-generating the prompt must not revert it)
                # bind the recurring characters the director detected — but ONLY when the scene has no cast yet
                # (never overwrite a cast the user picked). Fixes manually-added scenes whose face wasn't locked.
                if not s.get("no_cast") and not (s.get("cast") or []):
                    _locked = set(s.get("cast_locked") or [])   # don't re-bind a cast the user explicitly removed
                    if plan[i].get("cast"):
                        s["cast"] = [cid for cid in plan[i]["cast"] if cid not in _locked]
                    if plan[i].get("generic") and not s.get("generic"):
                        s["generic"] = plan[i]["generic"]
                if plan[i].get("states"):                      # transforming cast → their stage at this scene
                    s["states"] = plan[i]["states"]
                s["ingredients"] = plan[i].get("ingredients") or []   # ingredients shown in this shot (roster ids)
            else:
                # fallback: the old single-sentence pass, so the button still works if the director errors
                cast_names = [c["name"] for c in scene_characters(s, doc) if c.get("name")]
                prompt, style = claude_prompt(vo, "", doc.get("audience"), s.get("style"), cast_names, doc.get("brief", ""))
                s["prompt"] = prompt
                if style:
                    s["style"] = style
            bind_named_cast(s, doc)   # ADD (never remove) any roster character the new prompt names — e.g. a split's
                                      # LEFT half names Dr Carbonell while the existing cast only had Dr Vasquez
            s["prompt_error"] = None
            _gp_touched.append(s)
        except Exception as e:
            s["prompt_error"] = str(e)
    save_doc(project, doc)
    _stamp_director_prompt(_gp_touched)                 # baseline for the later edit-delta
    _learn_log("director", project, doc, _gp_touched)   # passive: capture re-generated (vo → prompt) pairs
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)   # which model ran (toast) — Fable 5 / Opus 4.8
    return jsonify(resp)

# ---- routes: video-prompt generation ---------------------------------------
VIDEO_PROMPT_SYSTEM = """You write a SHORT image-to-video MOTION prompt for ONE shot of a VSL.
You are given the description of a STILL image. Describe realistic motion at a NATURAL, REAL-TIME pace
that brings the still to life WITHOUT changing what it shows — a living moment, NOT a slow-motion clip.

PACE: normal, real-life speed. NEVER ask for slow, slowed, slow-motion, gentle-drift, floaty or dreamy
motion — everything moves at the speed it actually would in reality.

CAMERA: at most ONE SMALL, MINIMAL camera move (a slight push-in or the tiniest drift). Keep it subtle —
never a large, fast, sweeping, or showy move. A nearly-still camera is fine.

SUBJECT/AMBIENT: natural subject motion that fits the line (a head or hand movement, a blink, a breath, a
gesture, hair/clothing) and ambient motion (steam/liquid/light/particles drifting, leaves) — all at
real-time speed.

DO NOT:
- add or remove people or objects, change the setting, morph or transform anything
- cut to another shot, add on-screen text, or use unrealistic / exaggerated motion

SCRIPT LINE: You may also be given the shot's VOICE-OVER (the script sentence spoken over this image).
Use it to decide WHICH motion and what emotional tone to emphasize so the motion matches what is being
said (e.g. a relieved smile, a worried glance, a confident nod, an energetic hand gesture) — but never
contradict, add to, or change what the image actually shows.

OUTPUT: 1-2 short sentences, ONLY the motion description. No preamble, no quotes."""

# Camera-LOCKED variant (the default): the camera does NOT move at all — only the subject/ambient moves.
VIDEO_PROMPT_SYSTEM_STATIC = """You write a SHORT image-to-video MOTION prompt for ONE shot of a VSL.
You are given the description of a STILL image. Describe realistic motion at a NATURAL, REAL-TIME pace
that brings the still to life WITHOUT changing what it shows — a living moment, NOT a slow-motion clip.

THE CAMERA IS LOCKED OFF (on a tripod) and does NOT move: NO push-in, NO pan, NO zoom, NO parallax,
NO tracking. Only the SUBJECT and AMBIENT elements move.

PACE: normal, real-life speed. NEVER ask for slow, slowed, slow-motion, gentle-drift, floaty or dreamy
motion — the subject moves at the speed it actually would in reality.

SUBJECT/AMBIENT: natural subject motion (a breath, a head or hand movement, a blink, a gesture that fits
the line, hair or clothing shifting) and ambient motion (steam/liquid/light/particles drifting, leaves) —
all at real-time speed.

DO NOT: move the camera in any way; add or remove people or objects; change the setting; morph anything;
cut to another shot; add on-screen text; or use unrealistic / exaggerated motion.

SCRIPT LINE: You may also be given the shot's VOICE-OVER (the script sentence spoken over this image).
Use it to decide WHICH subject/ambient motion and what emotional tone to emphasize so the motion matches
what is being said (e.g. a relieved smile, a worried glance, a confident nod) — but never contradict, add
to, or change what the image actually shows, and never move the camera.

OUTPUT: 1-2 short sentences, ONLY the motion description. No preamble, no quotes."""

_CAM_WORDS = ("camera", "zoom", "pan ", "push-in", "push in", "dolly", "tilt", "tracking", "parallax",
              "crane", "handheld", "orbit", "pull back", "pull-back", "kamera", "yakınlaş", "uzaklaş")


def _mentions_camera(text):
    t = (text or "").lower()
    return any(w in t for w in _CAM_WORDS)


def _apply_cam_lock(prompt, scene):
    """If this scene's camera is locked (default) AND the motion text doesn't already talk about the
    camera, spell out a completely static camera so the video model doesn't drift/zoom on its own."""
    if scene.get("video_cam_lock", True) and not _mentions_camera(prompt):
        prompt = (prompt or "").rstrip()
        prompt += (" " if prompt else "") + "The camera stays completely still (locked-off tripod): no camera movement, no zoom, no pan, no push-in."
    return prompt


def video_prompt_for(scene, project=None):
    """Generate a subtle, image-consistent motion prompt. When the scene's generated IMAGE exists we LOOK at it
    (vision) so the motion suits WHAT IS ACTUALLY in the frame and won't distort it (faces/hands/text/product);
    otherwise fall back to the image-prompt/VO text. Camera-locked (static) by default."""
    sys = VIDEO_PROMPT_SYSTEM_STATIC if scene.get("video_cam_lock", True) else VIDEO_PROMPT_SYSTEM
    vo = (scene.get("vo") or "").strip()
    im = scene.get("image") or {}
    f = im.get("approved_file") or im.get("file")
    if project and f:
        d, _ = proj_dir(project)
        img_path = str(d / f)
        if os.path.exists(img_path):
            user = ("This still is the FIRST FRAME of the video clip. Look at WHAT IS ACTUALLY IN THE IMAGE and write "
                    "the motion prompt for THIS exact image: only animate what can move naturally, and avoid ANY motion "
                    "that would warp or distort faces, hands, bodies, text, logos or the product. "
                    + (f"Script line (voice-over spoken over this shot): {vo}" if vo else ""))
            return _apply_cam_lock(_claude_vision(sys, user, img_path), scene)   # ClaudeNotLoggedIn propagates
    desc = (scene.get("prompt") or "").strip()
    user = f"Still image: {desc or vo}"
    if vo and desc:
        user += f"\nScript line (voice-over spoken over this shot): {vo}"
    return _apply_cam_lock(_claude_text(sys, user), scene)

@app.route("/api/scenes/<project>/gen-video-prompt", methods=["POST"])
def api_gen_video_prompt(project):
    """Write an AI motion prompt into each eligible scene's video_desc (the Videos-tab textbox). SYNC — used for
    a single scene / a small selection. The 'all' button uses the background job below (vision over many scenes)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = request.get_json(force=True).get("ids", "all")
    def eligible(s):
        return s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))
    targets = [s for s in doc["scenes"] if eligible(s) and (ids == "all" or s["id"] in ids)]
    for s in targets:
        try:
            s["video_desc"] = video_prompt_for(s, project)
            s["video_prompt_error"] = None
        except Exception as e:
            s["video_prompt_error"] = str(e)
    save_doc(project, doc)
    return jsonify(doc)

# ---- video-prompt "generate ALL" as a background JOB (vision over every approved scene → too slow for one
# request). Watches each scene's first frame and writes an image-consistent motion prompt, with progress + report.
VIDPROMPT_JOBS = {}
_VP_LOCK = threading.Lock()

def _vidprompt_worker(jid, project):
    j = VIDPROMPT_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _VP_LOCK: j.update(status="error", error="project not found")
            return
        def eligible(s):
            im = s.get("image") or {}
            return s.get("approved") and (im.get("approved_file") or im.get("file"))
        targets = [s for s in doc["scenes"] if eligible(s)]
        if not targets:
            with _VP_LOCK: j.update(status="error", error="No approved scenes with an image yet — approve the images first.")
            return
        written, done = 0, 0
        for s in targets:
            if j.get("cancel"):
                with _VP_LOCK: j.update(status="cancelled")
                return
            with _VP_LOCK:
                j.update(step=f"Watching image & writing motion prompt {done + 1}/{len(targets)}…",
                         pct=int(done / len(targets) * 100))
            try:
                s["video_desc"] = video_prompt_for(s, project)
                s["video_prompt_error"] = None
                written += 1
            except ClaudeNotLoggedIn as e:
                save_doc(project, doc)
                with _VP_LOCK: j.update(status="error", error=str(e))   # not logged in → abort, tell the user
                return
            except Exception as e:
                s["video_prompt_error"] = str(e)[:120]
            done += 1
            if done % 5 == 0:
                save_doc(project, doc)
        save_doc(project, doc)
        with _VP_LOCK: j.update(status="done", pct=100, report={"written": written, "total": len(targets)})
    except Exception as e:
        with _VP_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/gen-video-prompt-all", methods=["POST"])
@_locked
def api_gen_video_prompt_all(project):
    """Start the background vision video-prompt pass over every approved scene."""
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    VIDPROMPT_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_vidprompt_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/video-prompt-job/<jid>")
def api_video_prompt_job(jid):
    j = VIDPROMPT_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/video-prompt-cancel/<jid>", methods=["POST"])
def api_video_prompt_cancel(jid):
    j = VIDPROMPT_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

# ================= IMAGE QA — LOOK at every generated image and check it against the script =================
# A vision pass (subscription) that opens each scene's image and judges whether it matches the line, the
# audience, and has no defects/artifacts/wrong-ethnicity/stray-product. Background job -> report + flagged ids.
def _parse_json_obj(text):
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        raise ValueError("no JSON object")
    return json.loads(t[a:b + 1])

IMAGE_QA_SYSTEM = (
    "You are a STRICT QA reviewer for a French VSL (video sales letter). You are shown ONE generated IMAGE and "
    "given the scene's voice-over line (VO, French) and its intended shot description. Judge whether the image is "
    "correct for THIS line. Flag a problem when:\n"
    "- The image does not actually depict what THIS line/beat is about (wrong subject or mismatched content).\n"
    "- An ordinary 'viewer' / relatable person is the WRONG look for the target audience (French/European adults "
    "~50-75) — e.g. an East-Asian, Black, Indian, Hispanic or Middle-Eastern person shown as the everyday viewer — "
    "UNLESS the line itself is specifically about that nationality's people (then it is correct).\n"
    "- The finished BRANDED PRODUCT / supplement bottle / jar / packaging appears when this is NOT a product shot "
    "(raw black garlic and ordinary food are fine).\n"
    "- Visible defects: readable on-image text/caption/watermark that shouldn't be there, warped or extra fingers/"
    "hands, distorted or melted faces, duplicated or missing limbs, garbled anatomy, obvious AI artifacts.\n"
    "- WRONG-LANGUAGE TEXT: any readable words/signage/labels/screen or document text that legitimately belong in "
    "the shot but are written in a language OTHER than the project language given below (e.g. ENGLISH text in a "
    "French project) is a defect — flag it and set regenerate=true.\n"
    "- Anything clearly ugly, confusing or off for a viewer.\n"
    "Be fair: if the image is good and on-message, say so. Return ONLY JSON:\n"
    '{"verdict":"ok"|"issue","severity":"low"|"med"|"high","issue":"<short concrete problem, empty if ok>",'
    '"regenerate":true|false}  (regenerate=true only for a real problem worth re-rolling). Output just the JSON.')

QA_SUGGEST_SYSTEM = (
    "You are given a list of problems found across the generated images of a VSL. Identify up to 3 RECURRING "
    "CLASSES of problem that a PROJECT-WIDE prompt/rule change could PREVENT next time (e.g. 'garbled on-image "
    "text keeps appearing -> add a no-on-image-text rule to every image prompt', 'wrong-ethnicity everyday "
    "viewers -> tighten the audience guard', 'the product appears before it's introduced -> strengthen the "
    "no-product guard'). IGNORE one-off image glitches that no rule could prevent. Return ONLY a JSON array of "
    "short, concrete, actionable suggestion strings in English (each a rule the app could adopt), or [] if none.")

IMGQA_JOBS = {}
_IMGQA_LOCK = threading.Lock()

def _imgqa_worker(jid, project):
    j = IMGQA_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _IMGQA_LOCK: j.update(status="error", error="project not found")
            return
        aud = doc.get("audience") or {}
        excl = ", ".join(aud.get("appearance") or []) or "none"
        locs = ", ".join(aud.get("locations") or []) or "France"
        plang = country_language(aud) or "French"   # project language for any on-image text (wrong-language = defect)
        d, _ = proj_dir(project)
        def imgfile(s):
            im = s.get("image") or {}
            return im.get("approved_file") or im.get("file")
        targets = [s for s in doc["scenes"] if imgfile(s)]
        if not targets:
            with _IMGQA_LOCK: j.update(status="error", error="No generated images to check yet.")
            return
        issues, done = [], 0
        for s in targets:
            if j.get("cancel"):
                with _IMGQA_LOCK: j.update(status="cancelled")
                return
            with _IMGQA_LOCK:
                j.update(step=f"Checking image {done + 1}/{len(targets)} (scene #{s.get('id')})…",
                         pct=int(done / len(targets) * 100))
            img_path = str(d / imgfile(s))
            if not os.path.exists(img_path):
                done += 1; continue
            user = (f"VO of this shot (French): {s.get('vo') or ''}\n"
                    f"Intended shot description: {s.get('prompt') or ''}\n"
                    f"Target audience: adults in {locs}, roughly 50-75; do NOT show these looks for ordinary viewers: {excl}.\n"
                    f"Project language: {plang}. Any words/signage/labels/screen text visible in the image must be in {plang}, not English.\n"
                    f"Look at the image and judge it. Return the JSON verdict.")
            try:
                v = _parse_json_obj(_claude_vision(IMAGE_QA_SYSTEM, user, img_path))
            except ClaudeNotLoggedIn as e:
                with _IMGQA_LOCK: j.update(status="error", error=str(e))
                return
            except Exception:
                done += 1; continue        # a parse/vision hiccup on one scene → skip it, keep going
            if str(v.get("verdict")).lower() == "issue" and (v.get("issue") or "").strip():
                issues.append({"id": s.get("id"), "issue": v.get("issue").strip(),
                               "severity": (v.get("severity") or "med").lower(),
                               "regenerate": bool(v.get("regenerate"))})
            done += 1
        regen_ids = [x["id"] for x in issues if x["regenerate"]]
        flagged_ids = [x["id"] for x in issues]
        suggestions = []
        if len(issues) >= 3:      # only propose a system change when a class of problem RECURS
            try:
                summary = "\n".join(f"#{x['id']} ({x['severity']}): {x['issue']}" for x in issues[:80])
                arr = _parse_json_array(_claude_text(QA_SUGGEST_SYSTEM, summary, max_tokens=800))
                suggestions = [str(a).strip() for a in arr if str(a).strip()][:4]
            except Exception:
                suggestions = []
        report = {"reviewed": len(targets), "flagged": len(issues), "issues": issues[:200],
                  "regen_ids": regen_ids, "flagged_ids": flagged_ids, "system_suggestions": suggestions}
        with _IMGQA_LOCK: j.update(status="done", pct=100, report=report)
    except Exception as e:
        with _IMGQA_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/image-qa", methods=["POST"])
@_locked
def api_image_qa(project):
    """Start the background vision QA over every generated image."""
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    IMGQA_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_imgqa_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/image-qa-job/<jid>")
def api_image_qa_job(jid):
    j = IMGQA_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/image-qa-cancel/<jid>", methods=["POST"])
def api_image_qa_cancel(jid):
    j = IMGQA_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

# ============ VIDEO QA — vision over one frame of each GENERATED video vs the intended shot =============
VIDEO_QA_SYSTEM = (
    "You are checking ONE frame grabbed from a short GENERATED video clip in a health VSL, against what that shot "
    "was supposed to be. Judge ONLY clear, real problems a viewer would notice. Return ONLY JSON: "
    '{"verdict":"ok|issue","issue":"<short specific problem, empty if ok>","severity":"low|med|high"}. '
    "Flag an ISSUE only for: wrong or absent subject vs the description, badly warped/melting faces/hands/bodies, "
    "gross anatomical glitches, obvious AI artefacts, on-screen gibberish text, or content that clearly "
    "contradicts the voice-over. If the frame looks fine for a VSL b-roll shot, verdict \"ok\". Be strict about "
    "warping/artefacts, lenient about minor style.")
VIDQA_JOBS = {}
_VIDQA_LOCK = threading.Lock()

def _extract_frame(video_path, out_path):
    """Grab one representative frame (~midpoint) from a video to out_path. Returns True on success."""
    try:
        dur = premiere_export.audio_duration(video_path) or 0.0
        ts = max(0.1, dur / 2.0) if dur else 0.5
        subprocess.run(["ffmpeg", "-y", "-ss", str(ts), "-i", str(video_path), "-frames:v", "1",
                        "-q:v", "3", str(out_path)], check=True, capture_output=True, timeout=60,
                       creationflags=_NO_WINDOW)
        return os.path.exists(out_path)
    except Exception:
        return False

def _vidqa_worker(jid, project):
    j = VIDQA_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _VIDQA_LOCK: j.update(status="error", error="project not found")
            return
        d, _ = proj_dir(project)
        vidfile = lambda s: (s.get("video") or {}).get("file")
        targets = [s for s in doc["scenes"] if vidfile(s) and (d / vidfile(s)).exists()]
        if not targets:
            with _VIDQA_LOCK: j.update(status="error", error="No generated videos to check yet.")
            return
        tmp = d / "export" / "_vidqa_tmp"; tmp.mkdir(parents=True, exist_ok=True)
        issues, done = [], 0
        for s in targets:
            if j.get("cancel"):
                with _VIDQA_LOCK: j.update(status="cancelled")
                return
            with _VIDQA_LOCK:
                j.update(step=f"Checking video {done + 1}/{len(targets)} (scene #{s.get('id')})…",
                         pct=int(done / len(targets) * 100))
            fp = tmp / f"f_{s.get('id')}.jpg"
            if not _extract_frame(d / vidfile(s), fp):
                done += 1; continue
            user = (f"VO of this shot: {s.get('vo') or ''}\n"
                    f"Intended video: {s.get('video_desc') or s.get('prompt') or ''}\n"
                    "Judge the frame and return the JSON verdict.")
            try:
                v = _parse_json_obj(_claude_vision(VIDEO_QA_SYSTEM, user, str(fp)))
            except ClaudeNotLoggedIn as e:
                with _VIDQA_LOCK: j.update(status="error", error=str(e))
                return
            except Exception:
                done += 1; continue
            if str(v.get("verdict")).lower() == "issue" and (v.get("issue") or "").strip():
                issues.append({"id": s.get("id"), "issue": v.get("issue").strip(),
                               "severity": (v.get("severity") or "med").lower()})
            done += 1
        shutil.rmtree(tmp, ignore_errors=True)
        report = {"reviewed": len(targets), "flagged": len(issues), "issues": issues[:200],
                  "flagged_ids": [x["id"] for x in issues]}
        with _VIDQA_LOCK: j.update(status="done", pct=100, report=report)
    except Exception as e:
        with _VIDQA_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/video-qa", methods=["POST"])
@_locked
def api_video_qa(project):
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    VIDQA_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_vidqa_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/video-qa-job/<jid>")
def api_video_qa_job(jid):
    j = VIDQA_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/video-qa-cancel/<jid>", methods=["POST"])
def api_video_qa_cancel(jid):
    j = VIDQA_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/preflight/<project>")
def api_preflight(project):
    """Read-only pre-export readiness check: flags anything missing before you render (no SRT/VO, scenes with no
    media or not approved, music sections without a track). Returns items for the report modal."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _ = proj_dir(project)
    items = []
    scenes = doc.get("scenes") or []
    # subtitle + voice-over
    srt = _find_srt(d)
    if not srt:
        items.append({"text": "No subtitle (.srt) found — generate captions before exporting.", "kind": "error"})
    vo = None
    try:
        vo = _normalized_vo(d)
    except Exception:
        vo = None
    if not vo:
        items.append({"text": "No voice-over audio found — the export needs the VO.", "kind": "error"})
    # per-scene media + approval
    no_media, not_approved = [], []
    for s in scenes:
        if s.get("tcard_id"):
            continue                                   # testimonial-card scenes carry their own media
        im = s.get("image") or {}
        has_img = bool(im.get("approved_file") or im.get("file"))
        has_vid = bool((s.get("video") or {}).get("file"))
        if not (has_img or has_vid):
            no_media.append(s.get("id"))
        elif not s.get("approved"):
            not_approved.append(s.get("id"))
    if no_media:
        items.append({"text": f"{len(no_media)} scene(s) have NO image or video: #" + ", #".join(str(i) for i in no_media[:40]), "kind": "error"})
    if not_approved:
        items.append({"text": f"{len(not_approved)} scene(s) have media but are NOT approved: #" + ", #".join(str(i) for i in not_approved[:40]), "kind": "warn"})
    # music plan (if one is saved)
    plan = doc.get("music_plan") or []
    if plan:
        missing = [seg for seg in plan if not seg.get("track")]
        if missing:
            items.append({"text": f"{len(missing)} music section(s) have no track assigned — check the music panel.", "kind": "warn"})
    else:
        items.append({"text": "Music not planned yet — it will be planned on the next Build Preview.", "kind": "info"})
    errors = sum(1 for it in items if it["kind"] == "error")
    warns = sum(1 for it in items if it["kind"] == "warn")
    return jsonify({"items": items, "errors": errors, "warns": warns, "scenes": len(scenes)})

# ================= AUTO ON-SCREEN TEXT — Claude picks punchy keywords -> overlays with your presets =========
OST_SYSTEM = (
    "You choose ON-SCREEN TEXT (big punchy words shown over the video) for a VSL. You get the scenes in order "
    "(id<TAB>voice-over, in the script's language). For any scene with a HOOK worth reinforcing — a number/"
    "statistic, a benefit, the product/brand name, an offer term, a strong emotional/persuasive word, a symptom/"
    "problem/risk, or a memorable key phrase — pick a SHORT on-screen phrase taken VERBATIM from THAT scene's "
    "voice-over (same language, same words; you MAY drop words to shorten, but NEVER add or translate).\n"
    "RULES:\n"
    "- Respect the stated max lines and max characters-per-line. Put a single newline between two lines. If the key "
    "phrase cannot fit even after sensibly shortening, SKIP that scene (omit it).\n"
    "- Be GENEROUS but not spammy: aim for roughly a THIRD to a HALF of scenes to carry on-screen text. Skip only "
    "truly ordinary connective/filler lines that carry no hook, number, benefit, problem or memorable phrase.\n"
    "- sentiment: \"negative\" if the line is a problem/fear/pain (disease, risk, decline, danger, loss); "
    "\"positive\" otherwise (benefit, relief, solution, hope, proof).\n"
    "- anim: pick from the ALLOWED animations. A RUN of consecutive punchy scenes on the SAME theme/list (e.g. "
    "pills / injections / doctors) MUST all use the SAME animation; when a new/different on-screen idea starts "
    "(usually after a few-scene gap) pick a DIFFERENT allowed animation. Vary across the video, keep runs consistent.\n"
    "Return ONLY a JSON array of the chosen scenes: "
    "[{\"id\":N,\"text\":\"...\",\"sentiment\":\"positive|negative\",\"anim\":\"...\"}]. Omit scenes with no on-screen text.")

# OUT animation per IN animation (user rule): pop-up -> pop-up, slide-left -> slide-left, slide-top/bottom -> fade.
# On-screen text is NEVER a plain fade-in and NEVER slide-right.
_OST_OUT_FOR = {"popup": "pop", "slide-left": "slide-left", "slide-top": "fade",
                "slide-bottom": "fade", "fade": "fade", "none": "fade"}
_OST_ALLOWED_IN = ("popup", "slide-left", "slide-top", "slide-bottom")   # allowed on-screen-text entrances


def _ost_in_anim(a):
    """Coerce any stored IN animation to an allowed one (never plain fade-in, never slide-right)."""
    a = (a or "").strip()
    return a if a in _OST_ALLOWED_IN else "slide-bottom"
_OST_STYLE_COPY = ("ost_fill", "ost_color", "ost_font", "ost_size", "ost_weight", "ost_bold", "ost_italic",
                   "ost_upper", "ost_underline", "ost_letter", "ost_leading", "ost_place", "ost_stroke",
                   "ost_stroke_w", "ost_stroke_color", "ost_stroke_pos", "ost_bg", "ost_bg_color",
                   "ost_bg_opacity", "ost_bg_pad", "ost_bg_radius", "ost_shadow", "ost_shadow_color",
                   "ost_shadow_opacity", "ost_shadow_size", "ost_shadow_dir")
OST_JOBS = {}
_OST_LOCK = threading.Lock()

def _ost_est_dur(vo):
    return len((vo or "").split()) / 2.67          # ~French speaking rate, seconds

def _ost_worker(jid, project, params):
    j = OST_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _OST_LOCK: j.update(status="error", error="project not found")
            return
        presets = []
        if OST_PRESETS_PATH.exists():
            try: presets = json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8"))
            except Exception: presets = []
        by_name = {p.get("name"): p for p in presets if isinstance(p, dict) and p.get("name")}
        pos = by_name.get(params.get("positive_preset"))
        neg = by_name.get(params.get("negative_preset"))
        maxchars = int(params.get("max_chars") or 20)
        maxlines = int(params.get("max_lines") or 2)
        # only the allowed entrances (never plain fade-in, never slide-right); drop anything else the UI passed
        anims = [a for a in (params.get("anims") or []) if a in _OST_ALLOWED_IN] or list(_OST_ALLOWED_IN)
        min_dur = float(params.get("min_dur") or 3.0)
        scenes = doc["scenes"]
        eligible = [s for s in scenes if (s.get("vo") or "").strip() and _ost_est_dur(s.get("vo")) >= min_dur]
        if not eligible:
            with _OST_LOCK: j.update(status="error", error="No scenes long enough for on-screen text.")
            return
        with _OST_LOCK: j.update(step="Claude is choosing punchy keywords…", pct=25)
        lines = "\n".join(f'{s["id"]}\t{(s.get("vo") or "").strip()}' for s in eligible)
        user = (f"Allowed animations: {', '.join(anims)}. Max {maxlines} lines; each line at most {maxchars} "
                f"characters.\nScenes (id<TAB>voice-over), in order:\n{lines}")
        arr = _parse_json_array(_claude_text(OST_SYSTEM, user, max_tokens=8000))
        with _OST_LOCK: j.update(step="Applying on-screen text…", pct=85)
        byid = {s["id"]: s for s in scenes}
        added, changes = 0, []
        for v in (arr or []):
            try: sid = int(v.get("id"))
            except Exception: continue
            s = byid.get(sid)
            if not s: continue
            text = (v.get("text") or "").strip()
            ls = text.split("\n")
            if not text or len(ls) > maxlines or any(len(x) > maxchars + 2 for x in ls):
                continue                                    # doesn't fit the rule -> skip
            anim = (v.get("anim") or "").strip()
            if anim not in anims: anim = anims[0]
            preset = neg if str(v.get("sentiment") or "").lower().startswith("neg") else pos
            ov = new_overlay(); ov["onscreen"] = text
            if preset:
                for k in _OST_STYLE_COPY:
                    if k in preset: ov[k] = preset[k]
            ov["ost_anim"] = anim; ov["ost_out_anim"] = _OST_OUT_FOR.get(anim, "fade")
            s["overlays"] = [ov]; s["ost_on"] = True
            added += 1; changes.append({"id": sid, "text": text.replace("\n", " / ")})
        _align_ost_to_vo(project, doc)               # time each OST to WHEN its keyword is actually spoken
        save_doc(project, doc)
        report = {"added": added, "eligible": len(eligible), "changes": changes[:200]}
        with _OST_LOCK: j.update(status="done", pct=100, report=report)
    except ClaudeNotLoggedIn as e:
        with _OST_LOCK: j.update(status="error", error=str(e))
    except Exception as e:
        with _OST_LOCK: j.update(status="error", error=str(e)[:200])


def _ost_norm_w(w):
    """Normalize a word for OST<->voice-over matching: lowercase + drop non-[a-z0-9] (also strips accents
    uniformly on both sides, so 'énergie' and 'ENERGIE' both become 'nergie' and still match)."""
    return re.sub(r"[^a-z0-9]", "", str(w).lower())


def _ost_match_span(ost_text, scene_words):
    """First in-order (subsequence) occurrence of the OST's words within the scene's spoken words. Handles a
    SHORTENED overlay (its words appear in order but not necessarily adjacent). Returns (start_t, end_t) or None."""
    targets = [t for t in (_ost_norm_w(x) for x in re.split(r"\s+", ost_text or "")) if t]
    if not targets:
        return None
    ti, start_t, end_t = 0, None, None
    for ws, we, word in scene_words:            # load_word_tsv items are (start, end, word) tuples
        nw = _ost_norm_w(word)
        if nw and nw == targets[ti]:
            if ti == 0:
                start_t = ws
            end_t = we
            ti += 1
            if ti == len(targets):
                return (start_t, end_t)
    return None


def _align_ost_to_vo(project, doc):
    """Set each on-screen-text overlay's show window (ost_in/ost_out, fractions of the scene) to WHEN its
    keyword is actually SPOKEN, using the word-level alignment. Best-effort — a scene we can't time keeps its
    default full-scene window; NEVER raises."""
    try:
        d, _ = proj_dir(project)
        srtp = _find_srt(d)
        vo = _normalized_vo(d)
        words = premiere_export.load_word_tsv(d / "subtitle") if srtp else None
        if not (srtp and words):
            return
        cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
        if not cues:
            return
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        scenes = doc.get("scenes", [])
        word_starts = premiere_export.word_scene_starts(scenes, words)
        ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
        for s, (t0, t1), inc in zip(scenes, ranges, included):
            if not inc or not s.get("ost_on"):
                continue
            dur = max(0.001, t1 - t0)
            scene_words = [w for w in words if w[0] is not None and (t0 - 0.05) <= w[0] < (t1 + 0.05)]
            if not scene_words:
                continue
            for ov in (s.get("overlays") or []):
                span = _ost_match_span(ov.get("onscreen"), scene_words)
                if not span or span[0] is None or span[1] is None:
                    continue
                a = max(0.0, min(1.0, (span[0] - t0 - 0.10) / dur))   # appear ~0.1s before the keyword
                ov["ost_in"] = round(a, 4)
                ov["ost_out"] = 1.0                                    # then STAY until the scene ends (fades out at the cut)
    except Exception:
        pass

@app.route("/api/scenes/<project>/gen-ost", methods=["POST"])
@_locked
def api_gen_ost(project):
    if load_doc(project) is None:
        abort(404)
    params = request.get_json(force=True) or {}
    jid = new_uid()
    OST_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_ost_worker, args=(jid, project, params), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/ost-job/<jid>")
def api_ost_job(jid):
    j = OST_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/ost-cancel/<jid>", methods=["POST"])
def api_ost_cancel(jid):
    j = OST_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

# ============ ANALYZE & PLACE OVERLAYS — vision pass: image-aware icons (+position) & sound effects =========
OVERLAY_SYSTEM = (
    "You look at ONE still frame from a health VSL plus its voice-over line, and choose PUNCHY overlays that "
    "fit WHAT THE IMAGE ACTUALLY SHOWS (not just the words). Return ONLY JSON: "
    '{"icon":"x|arrow|burst|none","x":0.0-1.0,"y":0.0-1.0,"size":0.5-1.4,"dir":"right|left","good":true|false,'
    '"sfx":"ambulance|healthmonitor|hit|time|none",'
    '"icons":[{"type":"x|arrow|burst","x":0.0-1.0,"y":0.0-1.0,"size":0.5-1.4,"dir":"right|left","good":true|false}]}. '
    "BE VERY SPARING with icons: MOST scenes must be \"none\". Add an icon ONLY when it clearly and strongly "
    "lands on a specific thing in THIS image. When unsure, use \"none\".\n"
    "icon meanings + PLACEMENT (be precise — x,y is the EXACT focus point, 0,0=top-left .. 1,1=bottom-right):\n"
    "- burst = physical PAIN/symptom -> x,y ON the aching body part (e.g. the knee, the chest).\n"
    "- x = a thing being rejected / avoided / a myth being busted -> x,y ON that object (the pill, the cigarette, "
    "the junk food). Keep it ON the object, NOT near a frame edge unless the object is at the edge.\n"
    "- arrow = point at ONE spot -> x,y is the TARGET the arrow tip should touch (the arrow enters from the left "
    "and points right at it). Set \"good\": true when the arrow points at something POSITIVE (a benefit, an "
    "improvement, a healthy/desirable result) -> it will be coloured GREEN; set \"good\": false when it points at "
    "something NEGATIVE (a problem, a danger, a decline, a bad spot) -> it will be coloured RED. (X and burst are "
    "ALWAYS red; \"good\" only matters for arrow.)\n"
    "size: 0.5-1.4 relative scale — use SMALL (0.5-0.7) when the target object is small in frame, larger when it "
    "dominates. Default ~1.0.\n"
    "Use the 'icons' ARRAY ONLY for a genuine split-screen/collage with 2+ separate things to mark (else omit it).\n"
    "CRITICAL: if the image shows a calm/relaxed/smiling/healthy/positive scene, use \"none\" (no pain/x/alarm) "
    "even if the words are negative.\n"
    "CRITICAL: if the image is a CHART / GRAPH / diagram / infographic / table / mostly TEXT or a data "
    "visualisation, use \"none\" — NEVER put icons on graphic/text/chart images.\n"
    "sfx: ambulance if an ambulance/paramedic/stretcher/emergency is SEEN or clearly said; healthmonitor ONLY on "
    "a REALISTIC hospital/ICU/ward/monitor/serious-illness photo (NEVER on a scientific diagram, chart, molecule "
    "or 2D graphic — for a tense scientific/abstract shot use \"hit\" instead); time if a countdown / time "
    "pressure; hit for a shocking/dramatic beat; else none. Use sfx SPARINGLY too.")
OVERLAY_JOBS = {}
_OVERLAY_LOCK = threading.Lock()

def _ov_clamp(v, d=0.5):
    try: return min(1.0, max(0.0, float(v)))
    except Exception: return d

def _ov_size(v):
    try: return min(1.4, max(0.5, float(v)))
    except Exception: return 1.0

def _ov_icon(it):
    """Normalize one vision icon dict -> {type,x,y,size,rot,flip}. For an arrow, the vision x,y is the TARGET the
    tip should touch, so shift the CENTRE off it (the art points right; flip=left)."""
    t = (it.get("type") or it.get("icon") or "").strip().lower()
    if t not in ("x", "arrow", "burst", "check"):
        return None
    x, y, sz = _ov_clamp(it.get("x")), _ov_clamp(it.get("y")), _ov_size(it.get("size"))
    flip = str(it.get("dir", "")).strip().lower() == "left"
    # colour rule: X and pain-burst are ALWAYS red (hue 0). An arrow is GREEN (hue 120) when it points at
    # something positive/good, RED when it points at something negative. (hue 0 == the icon PNG's native red.)
    hue = 0
    if t == "arrow":
        x = _ov_clamp(x + (0.09 if flip else -0.09))
        if it.get("good") is True:
            hue = 120
    return {"type": t, "x": round(x, 4), "y": round(y, 4), "size": round(sz, 3), "rot": 0, "flip": flip, "hue": hue}

def _overlay_worker(jid, project, do_icons=True, do_sfx=True):
    j = OVERLAY_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _OVERLAY_LOCK: j.update(status="error", error="project not found")
            return
        d, _safe = proj_dir(project)
        media = []
        for s in doc["scenes"]:
            img = s.get("image") or {}
            ir = img.get("approved_file") or img.get("file")
            if s.get("approved") and ir and (d / ir).exists() and not s.get("tcard_id"):
                if s.get("style") == "2d":                # NEVER put icons on 2D animation scenes
                    if do_icons:
                        s["icon"] = ""; s.pop("icons", None)
                    continue
                media.append((s, d / ir))
        total = len(media)
        if not total:
            with _OVERLAY_LOCK: j.update(status="error", error="No approved images to analyze yet.")
            return
        icons = sfxn = 0
        for i, (s, ip) in enumerate(media):
            if j.get("cancel"):
                with _OVERLAY_LOCK: j.update(status="cancelled")
                return
            with _OVERLAY_LOCK: j.update(step=f"Looking at image {i + 1}/{total}…", pct=int(4 + 92 * i / total))
            try:
                r = _parse_json_obj(_claude_vision(OVERLAY_SYSTEM, f"Voice-over: {(s.get('vo') or '').strip()}", str(ip))) or {}
            except ClaudeNotLoggedIn as e:
                with _OVERLAY_LOCK: j.update(status="error", error=str(e))
                return
            except Exception:
                continue
            if do_icons:                                 # only (re)place icons if the user asked for them
                built = []
                arr = r.get("icons")
                if isinstance(arr, list):
                    for it in arr:
                        ic = _ov_icon(it) if isinstance(it, dict) else None
                        if ic: built.append(ic)
                if not built:                            # single-icon shape (icon/x/y/size/dir at top level)
                    ic = _ov_icon(r)
                    if ic: built.append(ic)
                s["icons"] = built                       # unified list is the ONE source of truth
                for _lk in ("icon", "icon_x", "icon_y", "icon_size"):
                    s.pop(_lk, None)
                if built: icons += 1
            if do_sfx:                                   # only (re)place sound effects if the user asked for them
                sx = (r.get("sfx") or "none").strip().lower()
                if sx == "healthmonitor" and s.get("style") != "natural":
                    sx = "hit"                           # monitor only on realistic shots; scientific/abstract -> cinematic hit
                s["sfx"] = sx if sx in ("ambulance", "healthmonitor", "hit", "time") else ""
                if s["sfx"]: sfxn += 1
        save_doc(project, doc)
        with _OVERLAY_LOCK: j.update(status="done", pct=100, report={"scenes": total, "icons": icons, "sfx": sfxn})
    except Exception as e:
        with _OVERLAY_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/overlays", methods=["POST"])
@_locked
def api_overlays(project):
    if load_doc(project) is None:
        abort(404)
    body = request.get_json(silent=True) or {}
    do_icons = body.get("icons", True) is not False        # default both on; the popup lets the user pick
    do_sfx = body.get("sfx", True) is not False
    if not (do_icons or do_sfx):
        return jsonify({"error": "Pick at least icons or sound effects."}), 400
    jid = new_uid()
    OVERLAY_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_overlay_worker, args=(jid, project, do_icons, do_sfx), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/overlays-job/<jid>")
def api_overlays_job(jid):
    j = OVERLAY_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/overlays-cancel/<jid>", methods=["POST"])
def api_overlays_cancel(jid):
    j = OVERLAY_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

# ================= AUTO TRANSITIONS — Claude chooses meaningful scene-to-scene transitions ================
AUTO_TRANS_SYSTEM = (
    "You choose the TRANSITION that plays as each scene BEGINS (the cut from the previous scene) for a VSL. You "
    "get the scenes in order (id<TAB>voice-over). Use transitions MEANINGFULLY and SPARINGLY — most cuts are a "
    "hard cut (none). Choose from EXACTLY these keys:\n"
    "- none : ordinary continuation (the MAJORITY of scenes).\n"
    "- crossfade : a soft change of place/time. Use it RARELY — only for a genuine time jump or a location "
    "settling; a hard cut is almost always better and keeps the VSL punchy.\n"
    "- dip-black : an emotional low, a somber beat, or a big chapter/topic change (fade through black).\n"
    "- dip-white : a flash for a reveal, a punchy solution, or an energetic positive hit.\n"
    "- crossfade also fits moving through a LIST or a run of similar items (a soft step between them).\n"
    "Rules: aim for only about a QUARTER to a THIRD of scenes to carry ANY transition — the rest are plain hard "
    "cuts; the FIRST scene is always none; NEVER put a transition on a very short (1-2 second) scene, it would eat "
    "the whole shot. Return ONLY a JSON array with EVERY scene: "
    "[{\"id\":N,\"transition\":\"none|crossfade|dip-black|dip-white\"}].")

_TRANS_ALLOWED = {"none", "crossfade", "dip-black", "dip-white"}
TRANS_JOBS = {}
_TRANS_LOCK = threading.Lock()

def _est_scene_secs(s):
    """Rough on-screen seconds from VO word count (~2.67 words/sec) — same basis as OST timing."""
    w = len((s.get("vo") or "").split())
    return (w / 2.67) if w else 0.0

def _thin_transitions(scenes):
    """House rules so Auto Transitions stays tasteful (see memory ost-and-auto-transitions):
    1) NO transition on a very short scene (< 2.5s est) — a transition would eat the whole clip;
    2) crossfade only where it can breathe (>= 3s) and never two within 3 scenes — keeps them rare."""
    for s in scenes:                                        # 1) drop transitions on very short scenes
        if (s.get("transition") or "none") != "none":
            d = _est_scene_secs(s)
            if 0 < d < 2.5:
                s["transition"] = "none"
    last_cf = -99                                           # 3) keep crossfades rare + spread out
    for idx, s in enumerate(scenes):
        if (s.get("transition") or "") == "crossfade":
            d = _est_scene_secs(s)
            if (0 < d < 3.0) or (idx - last_cf < 3):
                s["transition"] = "none"
            else:
                last_cf = idx
    return scenes

def _trans_worker(jid, project):
    j = TRANS_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _TRANS_LOCK: j.update(status="error", error="project not found")
            return
        scenes = doc.get("scenes") or []
        if not scenes:
            with _TRANS_LOCK: j.update(status="error", error="No scenes yet.")
            return
        with _TRANS_LOCK: j.update(step="Claude is choosing transitions…", pct=30)
        lines = "\n".join(f'{s["id"]}\t{(s.get("vo") or "").strip()}' for s in scenes)
        arr = _parse_json_array(_claude_text(AUTO_TRANS_SYSTEM, "Scenes (id<TAB>voice-over), in order:\n" + lines, max_tokens=8000))
        byid = {s["id"]: s for s in scenes}
        applied, changes = 0, []
        for v in (arr or []):
            try: sid = int(v.get("id"))
            except Exception: continue
            t = (v.get("transition") or "none").strip()
            if t not in _TRANS_ALLOWED: continue
            s = byid.get(sid)
            if not s: continue
            s["transition"] = t
        if scenes:
            scenes[0]["transition"] = "none"        # nothing precedes the first scene
        _thin_transitions(scenes)                   # enforce house rules (entry+exit slides, no short-clip / rare crossfade)
        changes = [{"id": s["id"], "transition": s["transition"]} for s in scenes if (s.get("transition") or "none") != "none"]
        applied = len(changes)
        save_doc(project, doc)
        report = {"applied": applied, "total": len(scenes), "changes": changes[:300]}
        with _TRANS_LOCK: j.update(status="done", pct=100, report=report)
    except ClaudeNotLoggedIn as e:
        with _TRANS_LOCK: j.update(status="error", error=str(e))
    except Exception as e:
        with _TRANS_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/auto-transitions", methods=["POST"])
@_locked
def api_auto_transitions(project):
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    TRANS_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    threading.Thread(target=_trans_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/transitions-job/<jid>")
def api_transitions_job(jid):
    j = TRANS_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/transitions-cancel/<jid>", methods=["POST"])
def api_transitions_cancel(jid):
    j = TRANS_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/qa/system-request/<project>", methods=["POST"])
def api_qa_system_request(project):
    """The user ticked QA-proposed system improvements + OK'd them → queue them (so they can be baked into the
    app's prompts/rules and not recur). Appended to data/learn/qa_system_requests.jsonl for later review."""
    b = request.get_json(force=True) or {}
    reqs = [str(x).strip() for x in (b.get("suggestions") or []) if str(x).strip()]
    if reqs:
        f = DATA_DIR / "learn" / "qa_system_requests.jsonl"
        f.parent.mkdir(parents=True, exist_ok=True)
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"project": project, "suggestions": reqs}, ensure_ascii=False) + "\n")
    return jsonify({"ok": True, "saved": len(reqs)})

# ---- routes: image generation ----------------------------------------------
# ---- generation QUEUE: cap how many jobs are submitted/in-flight at once so a big "Generate All"
# doesn't fire 40+ API calls simultaneously (which the provider rate-limits → failures). Extra
# scenes wait as status "queued" and are submitted by the poll loop as running jobs finish.
IMG_CONCURRENCY = 6
VID_CONCURRENCY = 3
IMG_GEN_TIMEOUT = 300     # seconds: a "generating" image that Kie never finishes is failed (not stuck forever)
VID_GEN_TIMEOUT = 900     # videos legitimately take longer

def _default_product_url(doc):
    """The pack to AUTO-attach when the director flags a scene as showing the product (like it auto-picks
    cast/ingredients). Prefer a single-bottle pack by name, else the first product image. None if no product."""
    prod = doc.get("product") or {}
    urls = prod.get("urls") or []
    if not urls:
        return None
    names = prod.get("names") or {}
    for u in urls:
        nm = (names.get(u) or "").lower()
        if any(k in nm for k in ("1 ", "1x", "1-", "single", "one bottle", "tek")):
            return u
    return urls[0]

def _scene_product_url(s, doc):
    """The ONE product image chosen for this scene (e.g. the 1-bottle / 3-pack / 6-pack render), or None.
    scene['product'] holds the chosen url; legacy True means the first product image. Attaches in RAW mode
    too (like a scene reference) — only the extra product WORDING is skipped in raw (see assemble)."""
    prod_urls = (doc.get("product") or {}).get("urls") or []
    if not prod_urls:
        return None
    chosen = s.get("product")
    if not chosen:
        return None
    if chosen is True:
        return prod_urls[0]
    return chosen if chosen in prod_urls else None

def _effective_product_url(s, doc):
    """Product image to attach for this scene. A TESTIMONIAL grid always shows the product (every person holds it),
    so fall back to the default pack even when none was explicitly chosen."""
    u = _scene_product_url(s, doc)
    if u:
        return u
    if s.get("testimonial"):
        return _default_product_url(doc)
    return None

def assemble_image_prompt(s, doc, d):
    """SINGLE SOURCE OF TRUTH for the final image prompt text — used by both the real generation
    (_submit_image) and the dry-run preview, so what the user previews is byte-identical to what gets
    sent. No network / no Cloudinary. Returns (prompt, cont_rel, info): `cont_rel` is the continuity
    frame to attach (or None); `info` is a human-readable list of which reference images would attach."""
    all_chars = scene_characters(s, doc)
    # The "In scene:" chips (scene.cast) control who is face-locked in BOTH normal AND raw mode. BUT a face is
    # NEVER attached to a shot with no person in it (scene_face_chars → []), so a reference face can't be grafted
    # onto an object/product/anatomy ("head on belly"). Remove a chip to drop someone from a scene that has people.
    chars_ref = scene_face_chars(s, doc)                                                     # cast WITH a photo, only if the shot has a person
    has_people = bool(chars_ref) or _shot_has_people(s, doc)
    chars_desc = [] if (s.get("no_cast") or not has_people) else [c for c in all_chars if not char_urls(c)]   # photo-less cast: description only in normal mode + when people are present
    prompt = build_image_prompt(s, doc.get("audience"), chars_ref, chars_desc)
    if s.get("pure"):   # PURE: prompt + camera + ONLY the references you explicitly attached (no auto layers, no continuity)
        bits = []
        if chars_ref: bits.append("cast: " + ", ".join(c.get("name", "?") for c in chars_ref))
        if _scene_product_url(s, doc): bits.append("product")
        if scene_ingredient_refs(s, doc): bits.append("ingredients")
        if s.get("refs"): bits.append(f"{len(s.get('refs'))} attached image(s)")
        info = ["PURE mode — your prompt + camera" + (" + " + " + ".join(bits) if bits else "; no references") + " (no style/audience/no-text/continuity)"]
        if s.get("split"):
            info.append("Split composition")
        return prompt, None, info
    info = []
    if s.get("testimonial"):
        _tn = max(4, min(int(s.get("testimonial_n") or 8), 16)) if str(s.get("testimonial_n") or 8).isdigit() else 8
        _c, _r = _grid_dims(_tn)
        info.append(f"Testimonial grid — {_c}×{_r} ({_tn} cells) of separate real-customer selfies holding the product (auto-composed)")
    if s.get("no_cast"):
        n = len(s.get("refs") or [])
        bits = ["your prompt (verbatim)"]
        if chars_ref:
            bits.append("face-locked: " + ", ".join(c.get("name", "?") for c in chars_ref))
        bits.append("Target Audience reminder (location / age / excluded looks)")
        if n:
            bits.append(f"{n} reference image(s) you attached")
        info.append("RAW mode — " + " + ".join(bits))
    else:
        if chars_ref:
            _fl = []
            for c in chars_ref:
                nm = c.get("name", "?")
                if c.get("transforms") and char_end_urls(c):
                    _fl.append(f"{nm} [transform: {_char_state(c, s)}]")
                else:
                    _fl.append(nm)
            info.append("Face-locked (reference photo): " + ", ".join(_fl))
        if chars_desc:
            info.append("Kept consistent by description: " + ", ".join(c.get("name", "?") for c in chars_desc))
        # cast chip(s) set but NOT attached because this shot has no person → avoids grafting a face onto an object
        _dropped = [c.get("name", "?") for c in all_chars if char_urls(c)] if not chars_ref else []
        if _dropped:
            info.append("In-scene cast NOT attached (no person in this shot): " + ", ".join(_dropped))
        if s.get("refs"):
            info.append(f"{len(s.get('refs'))} scene reference image(s)")
    # scene-continuity: if this scene continues an earlier one (same place + people) whose image exists,
    # feed that frame as an extra reference. Skipped entirely in raw mode.
    cont_rel = None
    if not s.get("no_cast") and not s.get("testimonial"):   # a testimonial grid is standalone → no continuity frame
        cont = _cont_source(s, doc)
        if cont is not None:
            rel = (cont.get("image") or {}).get("approved_file") or (cont.get("image") or {}).get("file")
            if rel and (d / rel).exists():
                cont_rel = rel
                prompt += ("\nOne of the reference images is a frame from the PREVIOUS moment in this SAME "
                           "scene — keep the same location, background, lighting and the same people's "
                           "appearance for visual continuity; only the action and framing change as described.")
                info.append(f"Continuity frame from scene {cont.get('id')}")
    # INGREDIENTS: real ingredient reference images attached → depict each exactly as its reference, and ONLY these.
    ing_ref = scene_ingredient_refs(s, doc)
    if ing_ref:
        ing_names = ", ".join(i.get("name", "?") for i in ing_ref)
        if not s.get("no_cast"):
            prompt += (f"\nSome of the reference images are the product's INGREDIENTS: {ing_names}. Depict each ingredient "
                       f"EXACTLY as in its own reference image (same real ingredient, colour and form) — show ONLY these "
                       f"ingredients, do NOT invent or add other/unnamed ingredients.")
        info.append("Ingredient reference(s): " + ing_names)
    # PRODUCT: this scene is flagged to show the product → attach the product image (i2i) and demand an
    # exact, label-accurate depiction (this is what makes clean mockup / product-in-use shots).
    prod_url = _effective_product_url(s, doc)
    if prod_url:
        if not s.get("no_cast"):   # normal mode → add the label-accuracy wording; RAW stays verbatim (image still attaches as a reference)
            plabel = ((doc.get("product") or {}).get("names") or {}).get(prod_url, "").strip()
            pack = f" (this is the '{plabel}' pack)" if plabel else ""
            prompt += ("\nOne of the reference images is the PRODUCT" + pack + ". Use that reference ONLY for the product's "
                       "label, wording, colours and shape — copy the SAME bottle/package shape, label, wording, colours and "
                       "the SAME number of bottles/units; do NOT redesign, rename or restyle it, and do NOT add or remove "
                       "bottles. Do NOT copy the reference's SIZE, framing or studio lighting. Render the product at a "
                       "BELIEVABLE real-world size and position for THIS scene (held in a hand, on a surface, or in use) — "
                       "never a giant, oversized or floating hero. Give it a NATURAL, everyday look: lit by the SAME ordinary "
                       "light as the rest of the scene, with soft real shadows and only gentle, realistic highlights — NOT "
                       "glossy, NOT shiny/plasticky, NOT a studio product render; it should look like a real bottle sitting in "
                       "the room, with a matching contact shadow so it isn't pasted/cut-out on top. It must still be in SHARP "
                       "FOCUS with its label crisp and clearly readable (natural, NOT blurry or out of focus). The 'No text' rule above "
                       "applies ONLY to added captions/watermarks — the product's OWN printed label and text MUST stay exactly "
                       "as in the reference.")
        info.append("Product reference" + (" (raw: image only)" if s.get("no_cast") else ""))
    # USER-ATTACHED scene references: they ARE sent as i2i inputs, but with no wording the model often ignores an
    # unexplained image → tell it these are references to honour (this is why a manually-added reference "wasn't used").
    if s.get("refs"):
        prompt += ("\nAdditional reference image(s) were attached for THIS shot — treat them as accurate VISUAL REFERENCES: "
                   "faithfully reproduce the specific object(s), place, layout, product or style they show, and keep them "
                   "consistent in this image (they are there to be USED, not ignored or treated as mere inspiration).")
    if s.get("split"):
        _low = (s.get("prompt") or "").lower()
        if re.search(r"(?<![a-z])(?:top|bottom)[ -](?:left|right)\b[^:\n]{0,40}:", _low):
            n = "four (2x2)"
        elif re.search(_panel_mark_re("middle"), _low):
            n = "three"
        else:
            n = "two"
        info.append(f"Split composition — {n} panels (no divider); camera framing disabled")
    return prompt, cont_rel, info

def _cover_crop(im, cw, ch):
    """Scale + centre-crop `im` to exactly cw×ch (fills the box, no letterbox)."""
    im = im.convert("RGB")
    scale = max(cw / im.width, ch / im.height)
    nw, nh = max(cw, round(im.width * scale)), max(ch, round(im.height * scale))
    im = im.resize((nw, nh))
    left, top = (nw - cw) // 2, (nh - ch) // 2
    return im.crop((left, top, left + cw, top + ch))


def _ingredient_panels(ings, d):
    """One PIL image per PANEL. A split ingredient (name has '/', k parts) whose reference image is itself a
    k-way strip is SLICED back into its k parts, so e.g. pepper + Chromium/Zinc/B → 4 panels."""
    panels = []
    for ing in ings:
        u = next((x for x in (ing.get("urls") or []) if x), None)
        if not u or not (d / u).exists():
            continue
        try:
            im = Image.open(d / u).convert("RGB")
        except Exception:
            continue
        # A "/"-joined name (e.g. "Chromium/Zinc/B Vitamins") declares its components — its reference image is a
        # k-panel strip, so slice it back into k equal parts. "/" is the explicit component delimiter in the UI,
        # so this does not depend on the Split toggle being on.
        parts = [p for p in (ing.get("name") or "").split("/") if p.strip()]
        k = len(parts) if len(parts) >= 2 else 1
        if k >= 2:
            sw = im.width // k
            for j in range(k):
                x0 = j * sw
                x1 = im.width if j == k - 1 else (j + 1) * sw
                panels.append(im.crop((x0, 0, x1, im.height)))
        else:
            panels.append(im)
    return panels


def _compose_ingredient_image(panels, dest):
    """Lay panels out as N EQUAL side-by-side columns, each cover-filled (cropped, NO white letterbox)."""
    try:
        panels = [p for p in panels if p is not None]
        if not panels:
            return False
        W, H = 2560, 1440
        n = len(panels)
        canvas = Image.new("RGB", (W, H), (10, 15, 12))
        x = 0
        for i, im in enumerate(panels):
            cw = (W - x) if i == n - 1 else (round(W * (i + 1) / n) - round(W * i / n))
            canvas.paste(_cover_crop(im, cw, H), (x, 0))
            x += cw
        canvas.save(dest, "PNG")
        return True
    except Exception:
        return False


def _ingredient_direct_image(s, doc, d, safe):
    """For an ingredient-only shot, build the image straight from the ingredients' OWN reference images
    (no AI, no cost): N equal side-by-side panels (a split ingredient contributes its sub-parts), or the
    single image for a 'use directly' ingredient. Returns a local 'images/…png' rel path or None → normal
    generation. Skipped when the scene shows people or a product (those are real generated shots)."""
    if s.get("pure"):
        # PURE = "use my exact prompt": never silently replace it with an auto ingredient montage.
        # The scene proceeds to real generation; any ingredient images still attach as i2i references
        # (exactly what the PURE preview promises). Remove the ingredient from the scene to drop it entirely.
        return None
    if s.get("testimonial"):          # a testimonial grid is a real generated shot, never an ingredient montage
        return None
    if s.get("product"):
        return None
    # Only real PEOPLE block the montage — cast assigned to the shot, or a director-set ordinary person.
    # (Do NOT scan the prompt text: an ingredient line like "their ground spice" falsely reads as a person and
    #  the montage ignores the written prompt anyway.)
    if scene_face_chars(s, doc) or s.get("generic"):
        return None
    ings = scene_ingredient_refs(s, doc)                      # only ingredients that carry an image
    panels = _ingredient_panels(ings, d)
    if not panels:
        return None
    # RAW ("My prompt") + an ingredient selected = "just drop this ingredient's existing image in, no AI".
    # So in RAW mode a single ingredient is ALSO used directly (like 'use directly'), no regeneration.
    if len(panels) == 1 and not (s.get("no_cast") or (ings and ings[0].get("use_directly"))):
        return None                                          # single, non-direct ingredient → generate a fresh/varied look
    (d / "images").mkdir(parents=True, exist_ok=True)
    ver = len(s["image"].get("versions", [])) + 1
    out = f"images/sc_{s.get('uid', 'x')}_v{ver}.png"
    return out if _compose_ingredient_image(panels, d / out) else None


def _submit_image(s, doc, d, safe):
    # Ingredient-combo (or 'use directly') shot → compose from the ingredients' own reference images, no AI.
    try:
        direct = _ingredient_direct_image(s, doc, d, safe)
    except Exception:
        direct = None
    if direct:
        img = s["image"]
        img.setdefault("versions", []).append(direct)
        vm = img.setdefault("version_models", [])
        while len(vm) < len(img["versions"]) - 1:
            vm.append(s.get("model") or IMAGE_MODEL)
        vm.append(s.get("model") or IMAGE_MODEL)
        img["current"] = len(img["versions"]) - 1
        img.update(status="ready", file=direct, error=None, taskId=None)
        return
    if not s.get("prompt") and not s.get("testimonial"):   # a testimonial grid builds its own prompt (no written prompt needed)
        s["image"].update(status="error", error="no prompt")
        return
    family = s.get("model") or IMAGE_MODEL
    if family not in IMAGE_MODELS_READY:
        family = IMAGE_MODEL
    s["image"]["pending_model"] = family   # remember which model THIS generation uses → recorded per version on completion
    pure = bool(s.get("pure"))             # PURE → prompt+camera + ONLY the refs the user explicitly attached (no continuity)
    chars_ref = scene_face_chars(s, doc)   # In-scene chips (honoured in pure too), only when the shot has a person
    prompt, cont_rel, _info = assemble_image_prompt(s, doc, d)   # same text the preview shows
    if pure:
        cont_rel = None                    # continuity is AUTO (not user-attached) → never in pure
    try:
        # scene refs AND every character image are stored locally now; upload each to Cloudinary here
        refs = resolve_refs(d, safe, s.get("refs")) + resolve_refs(d, safe, [u for c in chars_ref for u in char_urls_for(c, s)])
    except ValueError as e:
        s["image"].update(status="error", error=str(e))
        return
    ing_urls = [u for i in scene_ingredient_refs(s, doc) for u in (i.get("urls") or []) if u]   # ingredient reference images (i2i)
    if ing_urls:
        try:
            refs = refs + resolve_refs(d, safe, ing_urls)
        except ValueError:
            pass
    prod_url = _effective_product_url(s, doc)   # the ONE PRODUCT image (chosen pack, or default for a testimonial grid) as an i2i input
    if prod_url:
        try:
            refs = refs + resolve_refs(d, safe, [prod_url])
        except ValueError:
            pass
    if cont_rel:                                                 # continuity frame is optional — never fail the gen for it
        try:
            refs = refs + resolve_refs(d, safe, [cont_rel])
        except ValueError:
            pass
    try:
        model_id, inp = build_kie_image_request(family, prompt, refs)
        tid, err = kie_create(model_id, inp)
        if tid:
            s["image"].update(status="generating", taskId=tid, error=None, gen_started=time.time())
        else:
            s["image"].update(status="error", error=err)
    except Exception as e:                                  # any unexpected failure → visible error, never a silent 500
        s["image"].update(status="error", error=f"image submit failed: {e}")

def _drain_image_queue(doc, d, safe):
    """Submit queued image jobs up to IMG_CONCURRENCY. Returns True if anything was submitted."""
    gen = sum(1 for s in doc["scenes"] if s["image"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= IMG_CONCURRENCY:
            break
        if s["image"]["status"] != "queued":
            continue
        _submit_image(s, doc, d, safe)
        changed = True
        if s["image"]["status"] == "generating":
            gen += 1
    return changed

def _submit_video(s, d, safe, doc):
    # Never let an exception escape: any failure becomes a VISIBLE "error" on the video card with the
    # reason. Otherwise a raise here (missing frame file after import, Cloudinary/Kie network error…)
    # would 500 the request and the UI would show nothing at all ("clicked, nothing happened").
    try:
        frame = s["image"].get("approved_file") or s["image"].get("file")
        if not frame:
            s["video"].update(status="error", error="approve an image version first")
            return
        if not (d / frame).exists():                       # e.g. an imported project whose image file didn't come across
            s["video"].update(status="error", error="image file missing on disk — re-generate this image, then retry")
            return
        img_url = cloudinary_upload(d / frame, f"{safe}/frames/{s.setdefault('uid', new_uid())}")
        if not img_url:
            s["video"].update(status="error", error="frame upload failed (check Cloudinary keys / quota)")
            return
        prompt = s.get("video_prompt") or s.get("video_desc") or ""
        prompt = _apply_cam_lock(prompt, s)   # keep the camera static by default (lock on) unless off / user asked for movement
        api, mid, payload = build_video_request(s.get("video_model") or DEFAULT_VIDEO_MODEL, img_url,
                                                prompt, s.get("video_dur"), s.get("video_res"))
        tid, err = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
        if tid:
            # remember WHICH approved image this video is being made from, so the Videos tab can flag a
            # video as stale once the scene's approved image is changed/re-approved to a different one.
            s["video"].update(status="generating", taskId=tid, error=None, api=api, source=frame, gen_started=time.time())
        else:
            s["video"].update(status="error", error=err)
    except Exception as e:
        s["video"].update(status="error", error=f"video submit failed: {e}")

def _drain_video_queue(doc, d, safe):
    gen = sum(1 for s in doc["scenes"] if s["video"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= VID_CONCURRENCY:
            break
        if s["video"]["status"] != "queued":
            continue
        _submit_video(s, d, safe, doc)
        changed = True
        if s["video"]["status"] == "generating":
            gen += 1
    return changed

@app.route("/api/scenes/<project>/generate", methods=["POST"])
def api_generate(project):
    with _project_lock(project):
        return _api_generate(project)


def _api_generate(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    targets = doc["scenes"] if ids == "all" else [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        if not s.get("prompt"):
            s["image"].update(status="error", error="no prompt")
        else:
            s["image"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_image_queue(doc, d, safe)                                       # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/poll", methods=["POST"])
def api_poll(project):
    return _api_poll(project)


def _api_poll(project):
    # Phase 1 — Kie polling + downloads run WITHOUT the project lock, so a concurrent approve/save
    # never waits on Kie network I/O (this was the "freeze while generating" cause). We only collect
    # results here; nothing shared is mutated. Phase 2 then reloads a fresh doc under the lock and
    # applies the results atomically (so a stale poll can never revert a just-made change).
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    updates = {}   # sid -> {"image": {...}, "video": {...}}, each tagged with its taskId

    def _img_result(img, uid):
        try:
            rec = kie_record(img["taskId"])
        except Exception:
            rec = {}                                    # transient poll failure → treat as still running (may time out below)
        state = (rec.get("data") or {}).get("state")
        if state == "success":
            url = result_url(rec)
            if not url:
                return {"ok": False, "error": "no result url"}
            ver = len(img.get("versions", [])) + 1
            fname = f"sc_{uid}_v{ver}.png"
            try:
                download_as_png(url, d / "images" / fname)
                return {"ok": True, "path": f"images/{fname}"}
            except Exception as e:
                return {"ok": False, "error": f"download: {e}"}
        elif state == "fail":
            return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
        started = img.get("gen_started")                # stuck task safety-net: never spin "generating" forever
        if started and (time.time() - started) > IMG_GEN_TIMEOUT:
            return {"ok": False, "error": f"timed out after {IMG_GEN_TIMEOUT // 60} min — the image service did not finish; please try again"}
        return None   # still running

    def _vid_result(v, uid):
        fname = f"sc_{uid}.mp4"
        def _timed_out():
            started = v.get("gen_started")
            if started and (time.time() - started) > VID_GEN_TIMEOUT:
                return {"ok": False, "error": f"timed out after {VID_GEN_TIMEOUT // 60} min — the video service did not finish; please try again"}
            return None
        if v.get("api") == "veo":
            try:
                rec = kie_veo_record(v["taskId"])
            except Exception:
                rec = {}
            data = rec.get("data") or {}
            sf = data.get("successFlag")
            if sf == 1:
                resp = data.get("response") or {}
                urls = resp.get("fullResultUrls") or resp.get("resultUrls") or resp.get("originUrls") or []
                url = urls[0] if urls else None
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif sf in (2, 3):
                return {"ok": False, "error": data.get("errorMessage") or "generation failed"}
            return _timed_out()
        else:
            try:
                rec = kie_record(v["taskId"])
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec)
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif state == "fail":
                return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
            return _timed_out()

    for s in doc["scenes"]:
        uid = s.setdefault("uid", new_uid())
        img = s["image"]
        if img["status"] == "generating" and img.get("taskId"):
            r = _img_result(img, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["image"] = {"taskId": img["taskId"], **r}
        v = s["video"]
        if v["status"] == "generating" and v.get("taskId"):
            r = _vid_result(v, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["video"] = {"taskId": v["taskId"], **r}

    # Phase 2 — apply atomically under the lock (reload fresh so we merge onto the current truth).
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        changed = False
        for s in doc["scenes"]:
            u = updates.get(s["id"])
            if not u:
                continue
            iu = u.get("image")
            # only apply if the scene is STILL awaiting the SAME task (user didn't cancel/reset meanwhile)
            if iu and s["image"].get("status") == "generating" and s["image"].get("taskId") == iu["taskId"]:
                if iu["ok"]:
                    s["image"].setdefault("versions", []).append(iu["path"])
                    vm = s["image"].setdefault("version_models", [])   # keep aligned with versions
                    while len(vm) < len(s["image"]["versions"]) - 1:    # backfill any legacy versions with no recorded model
                        vm.append(s.get("model") or IMAGE_MODEL)
                    vm.append(s["image"].get("pending_model") or s.get("model") or IMAGE_MODEL)   # the model that made THIS version
                    s["image"]["current"] = len(s["image"]["versions"]) - 1
                    s["image"].update(status="ready", file=iu["path"], error=None)
                else:
                    s["image"].update(status="error", error=iu["error"])
                changed = True
            vu = u.get("video")
            if vu and s["video"].get("status") == "generating" and s["video"].get("taskId") == vu["taskId"]:
                if vu["ok"]:
                    s["video"].update(status="ready", file=vu["path"], error=None)
                else:
                    s["video"].update(status="error", error=vu["error"])
                changed = True
        # a running job finished → submit the next queued image/video jobs (keeps in-flight ≤ the limit)
        if _drain_image_queue(doc, d, safe):
            changed = True
        if _drain_video_queue(doc, d, safe):
            changed = True
        if changed:
            save_doc(project, doc)
        return jsonify(doc)

# ---- routes: video generation ----------------------------------------------
@app.route("/api/scenes/<project>/generate-video", methods=["POST"])
def api_generate_video(project):
    with _project_lock(project):
        return _api_generate_video(project)


def _api_generate_video(project):
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if not VIDEO_CONFIGURED:
        return jsonify({"error": "Seedance video model not configured yet (need exact model id/params)."}), 503
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", [])
    if ids == "all":
        targets = [s for s in doc["scenes"] if s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))]
    else:
        targets = [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        s["video"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_video_queue(doc, d, safe)                                   # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

# ---- local thumbnails for reference images ---------------------------------
# Every reference image exists twice: on disk under projects/<name>/refs/ (the original
# upload) and on Cloudinary (the public URL Kie fetches at generation time). Drawing the
# panel straight from Cloudinary re-downloaded every full-size ref on each render, which
# is what exhausted the account's bandwidth quota. The UI now asks for the local copy and
# only falls back to the remote URL when the file is missing.
def _norm_stem(s):
    """Loose filename key: scene refs are 's1-0-name' on Cloudinary but 's1_0_name' on disk."""
    return re.sub(r"[-_\s]+", " ", s).strip().lower()

def _local_ref_for_url(d, url):
    """Find the on-disk file a reference points to, or None."""
    refs = d / "refs"
    if not url or not refs.is_dir():
        return None
    # new-style refs are a local relative path stored directly (e.g. "refs/s1_0_name.png")
    if not url.startswith("http://") and not url.startswith("https://"):
        p = d / _urlunquote(url)
        if p.is_file():
            return p
        p = refs / Path(_urlunquote(url)).name
        return p if p.is_file() else None
    # old-style refs are a Cloudinary URL → match the local file by filename stem
    path = _urlunquote(_urlparse(url).path)
    stem = Path(path).stem
    # characters upload as <safe>/characters/<cid>, but are stored as char_<cid>_<original>
    if "/characters/" in path:
        hit = next((p for p in sorted(refs.glob(f"char_{stem}_*")) if p.is_file()), None)
        if hit:
            return hit
    want = _norm_stem(stem)
    for p in sorted(refs.iterdir()):
        if p.is_file() and _norm_stem(p.stem) == want:
            return p
    return None

@app.route("/api/ref-thumb/<project>")
def api_ref_thumb(project):
    """Serve a small cached thumbnail of a reference image straight from local disk."""
    d, safe = proj_dir(project)
    src = _local_ref_for_url(d, request.args.get("u", ""))
    if src is None:
        abort(404)                      # the UI falls back to the remote URL
    tdir = d / ".thumbs"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(src.name.encode("utf-8")).hexdigest() + ".jpg")
    if not thumb.exists() or thumb.stat().st_mtime < src.stat().st_mtime:
        try:
            im = Image.open(src)
            im = im.convert("RGB")
            im.thumbnail((360, 360))
            im.save(thumb, "JPEG", quality=82)
        except Exception:
            return send_file(src)       # not readable by PIL -> hand over the original
    return send_file(thumb, mimetype="image/jpeg")

@app.route("/icons/<name>")
def serve_icon(name):
    """Serve an overlay icon PNG (X / arrow / ring) from the Icons folder next to this module — used by the
    scene-card icon editor to preview icons on the image thumbnails."""
    if "/" in name or "\\" in name or ".." in name:
        abort(404)
    p = Path(__file__).resolve().parent / "Icons" / name
    if not p.is_file():
        abort(404)
    h = request.args.get("h", type=int)          # ?h=<hue> -> recolour to that absolute hue (same PNG the XML export uses)
    if h:
        try:
            p = premiere_export._icon_hue_file(p, h)
        except Exception:
            pass
    return send_file(p, mimetype="image/png")

# ---- routes: refs -----------------------------------------------------------
@app.route("/api/refs/<project>", methods=["POST"])
def api_upload_ref(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    local = d / "refs" / f.filename
    f.save(local)
    pid = f"{safe}/refs/{Path(f.filename).stem}"
    url = cloudinary_upload(local, pid)
    if not url:
        return jsonify({"error": "cloudinary upload failed"}), 500
    ref = {"name": f.filename, "url": url}
    doc.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify(ref)

# ---- routes: per-scene reference images ------------------------------------
@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["POST"])
def api_scene_ref(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    idx = len(scene.get("refs", []))
    fname = f"s{sid}_{idx}_{int(time.time())}_{f.filename}"
    f.save(d / "refs" / fname)
    # store the LOCAL path only — the Cloudinary upload is deferred to generation time (see
    # ref_public_url), so adding references never needs the network or the Cloudinary quota
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"]})

@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["DELETE"])
@_locked
def api_scene_ref_delete(project, sid):
    """Remove ONE reference image from a scene by index. Dedicated endpoint (refs are NOT in the
    save-scenes whitelist) so a routine full-doc save / a racing approve can never clobber a scene's
    references — this is what silently dropped a just-added reference."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    idx = (request.get_json(silent=True) or {}).get("index")
    refs = scene.get("refs") or []
    if not isinstance(idx, int) or idx < 0 or idx >= len(refs):
        return jsonify({"error": "bad index"}), 400
    url = refs.pop(idx)
    if scene.get("ref_free"):
        scene["ref_free"] = [u for u in scene["ref_free"] if u != url]
    scene["refs"] = refs
    save_doc(project, doc)
    return jsonify({"refs": scene["refs"], "ref_free": scene.get("ref_free", [])})


@app.route("/api/scenes/<project>/<int:sid>/ref-lock", methods=["POST"])
@_locked
def api_scene_ref_lock(project, sid):
    """Toggle a reference's outfit-lock (ref_free membership). Dedicated endpoint so a full-doc save
    can't clobber it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    body = request.get_json(force=True) or {}
    url = (body.get("url") or "").strip()
    if not url:
        return jsonify({"error": "no url"}), 400
    free = [u for u in (scene.get("ref_free") or []) if u != url]
    if not bool(body.get("locked")):      # unlocked → the ref's outfit is FREE → add to ref_free
        free.append(url)
    scene["ref_free"] = free
    save_doc(project, doc)
    return jsonify({"ref_free": scene["ref_free"]})


@app.route("/api/scenes/<project>/<int:sid>/ref-scene", methods=["POST"])
def api_scene_ref_scene(project, sid):
    """Add another scene's APPROVED image as a reference on scene <sid> — a snapshot copy into refs/.
    The filename carries the source scene number (sceneref-<N>-…) so the UI can badge it 'Scene N'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    from_id = (request.get_json(force=True) or {}).get("from")
    src_scene = next((s for s in doc["scenes"] if s["id"] == from_id), None)
    if src_scene is None:
        return jsonify({"error": "scene not found"}), 404
    im = src_scene.get("image", {}) or {}
    rel = im.get("approved_file") or im.get("file")     # prefer the approved image
    if not rel:
        return jsonify({"error": "that scene has no image yet"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not src.exists():
        return jsonify({"error": "source image missing"}), 400
    (d / "refs").mkdir(parents=True, exist_ok=True)
    fname = f"sceneref-{from_id}-{int(time.time())}{src.suffix or '.png'}"
    shutil.copy2(src, d / "refs" / fname)
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"], "doc": doc})

# ---- routes: PRODUCT reference image (per-project) --------------------------
@app.route("/api/product/<project>", methods=["POST"])
def api_add_product(project):
    """Add product reference image(s) for THIS project (saved locally; Cloudinary upload deferred to
    generation). These get attached (i2i) to any scene flagged show-product, keeping the real label/design."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a product image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    prod = doc.setdefault("product", {"urls": []})
    prod.setdefault("urls", [])
    prod.setdefault("names", {})
    for i, f in enumerate(files):
        fname = f"product_{int(time.time() * 1000)}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        rel = f"refs/{fname}"
        prod["urls"].append(rel)
        prod["names"][rel] = _product_default_name(f.filename)   # seed a label from the file name ("3 bottle.png" -> "3 bottle")
    save_doc(project, doc)
    return jsonify(prod)

def _product_default_name(filename):
    """A friendly default label from the uploaded file name — the user usually names the file by pack
    size ('3 bottle.png'), so that becomes the dropdown label right away, still editable in the panel."""
    stem = os.path.splitext(os.path.basename(filename or ""))[0]
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    return stem[:40] or "Product"

@app.route("/api/product/<project>/rename", methods=["POST"])
def api_rename_product(project):
    """Set the human label for one product image (e.g. '1 bottle', '3 bottle') — shown in the per-scene
    Product dropdown so the user picks the right pack by name instead of 'Product 1 / 2 / 3'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    url = (body.get("url") or "").strip()
    name = (body.get("name") or "").strip()[:40]
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod.setdefault("names", {})[url] = name or "Product"
    save_doc(project, doc)
    return jsonify(prod)

@app.route("/api/product/<project>/remove", methods=["POST"])
def api_remove_product(project):
    """Drop one product reference image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    url = ((request.get_json(force=True) or {}).get("url") or "").strip()
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod["urls"].remove(url)
    (prod.get("names") or {}).pop(url, None)
    save_doc(project, doc)
    return jsonify(prod)

# ---- routes: product INGREDIENTS (per-project) — mirror characters (upload reference images) --------
@app.route("/api/ingredients/<project>", methods=["POST"])
def api_add_ingredient(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "ingredient name is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    iid = hashlib.md5(f"ing{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"ing_{iid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ing = {"id": iid, "name": name, "desc": (request.form.get("desc") or "").strip(), "urls": urls,
           "scientific": False, "split": False, "use_directly": False}
    doc.setdefault("ingredients", []).append(ing)
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>", methods=["POST"])
def api_update_ingredient(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    if (request.form.get("name") or "").strip():
        ing["name"] = request.form.get("name").strip()
    if "desc" in request.form:
        ing["desc"] = (request.form.get("desc") or "").strip()
    if "scientific" in request.form:
        ing["scientific"] = request.form.get("scientific") == "true"
    if "split" in request.form:
        ing["split"] = request.form.get("split") == "true"
    if "use_directly" in request.form:
        ing["use_directly"] = request.form.get("use_directly") == "true"
    ing.setdefault("urls", [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"ing_{iid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ing["urls"].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>/remove-image", methods=["POST"])
def api_remove_ingredient_image(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    url = (request.get_json(force=True) or {}).get("url")
    lst = ing.setdefault("urls", [])
    if url in lst:
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception:
            pass
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>", methods=["DELETE"])
def api_del_ingredient(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["ingredients"] = [x for x in doc.get("ingredients", []) if x.get("id") != iid]
    for s in doc.get("scenes", []):                 # also drop it from any scene that referenced it
        if s.get("ingredients"):
            s["ingredients"] = [v for v in s["ingredients"] if v != iid]
    save_doc(project, doc)
    return jsonify({"ingredients": doc["ingredients"]})

def _ingredient_portrait_prompt(ing):
    """Reference-image prompt for ONE ingredient.
      default    → the real ingredient in its NATURAL setting (fruit on the tree, root in the soil…).
      scientific → a clean 3D molecular / scientific render instead (for complexes like a vitamin/mineral).
      split      → the name split on '/' into 2-4 items shown as EQUAL side-by-side vertical panels
                   (one item per panel); combines with scientific (each panel a molecule)."""
    name = (ing.get("name") or "an ingredient").strip()
    sci = bool(ing.get("scientific"))
    split = bool(ing.get("split"))

    _tones = ["soft glowing blue", "deep navy blue", "dark teal", "deep blue-violet"]
    _frames = [                                     # same MEDIUM distance in every panel (NO extreme close-ups) —
        "a hero molecule centred and tilted, seen from a slightly low angle, others drifting far behind",
        "an off-centre molecule seen from above at a diagonal, a looser scattered cluster around it",
        "a molecule slightly right of centre seen from a gentle side angle, a balanced cluster around it",
        "a molecule upper-left with a soft downward tilt, evenly spaced molecules behind",
    ]
    _mols = [                                       # tint the molecules differently per panel so they don't all look alike
        "clear glass-like spheres with a subtle cool blue tint",
        "warm amber / golden translucent glass spheres",
        "emerald-green translucent glass spheres",
        "soft violet-magenta tinted glass spheres",
    ]
    _NO_TEXT = ("Absolutely NO text, NO letters, NO numbers, NO chemical symbols, formulae, element abbreviations "
                "or labels of any kind anywhere in the image; no packaging, no captions, no hands.")

    def look(item, idx=0):
        if sci:
            bg = _tones[idx % len(_tones)]
            frame = _frames[idx % len(_frames)]
            mol = _mols[idx % len(_mols)]
            return (f"a premium cinematic 3D scientific render of a molecule: glossy GLASS-LIKE ball-and-stick "
                    f"molecular structures made of {mol}, with liquid-glass reflections and bright specular "
                    f"highlights — {frame}, in shallow depth-of-field with soft bokeh, tiny glowing dust particles "
                    f"drifting in the air, soft cinematic studio lighting, on a smooth {bg} gradient background")
        return (f"{item} in its NATURAL SETTING where it grows or is found (the fruit on its tree/branch, the "
                f"herb/leaves in a field, the root in the soil, or the spice as whole fresh pods/seeds), beautiful "
                f"natural light, fresh, vivid, sharp focus")

    parts = [p.strip() for p in name.split("/") if p.strip()] if split else []
    if split and len(parts) >= 2:
        n = min(len(parts), 4)
        parts = parts[:n]
        word = {2: "two", 3: "three", 4: "four"}[n]
        panels = "; ".join(f"panel {i + 1} shows {look(p, i)}" for i, p in enumerate(parts))
        if sci:
            panels += (" — make EACH panel clearly DIFFERENT via its own background tone, molecule colour and "
                       "angle/composition, BUT keep the molecules a similar MEDIUM size/distance in every panel "
                       "(all panels equally zoomed, NO extreme close-ups)")
        return (f"A single image divided into {word} EQUAL side-by-side vertical panels of the SAME width — a clean "
                f"{word}-way split screen with a thin or no divider, each panel showing ONE ingredient: {panels}. "
                f"Keep all panels equal-sized and balanced. {_NO_TEXT}")
    return (f"A photorealistic image showing {look(name)}. {_NO_TEXT}")

@app.route("/api/ingredients/<project>/<iid>/generate", methods=["POST"])
def api_generate_ingredient(project, iid):
    """Generate a reference-image CANDIDATE for an ingredient (text-to-image, natural setting) — reviewed in the
    same candidate window as cast (edit / regenerate / accept). Synchronous poll, like the cast portrait."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    body = request.get_json(silent=True) or {}
    if body.get("fresh"):
        for p in d.glob(f"refs/ingcand_{iid}_*"):
            try: p.unlink()
            except Exception: pass
    custom = (body.get("prompt") or "").strip()   # user's OWN prompt from the candidate window → overrides the auto prompt
    if custom:
        prompt = custom
        if looks_turkish(custom):
            try: prompt = translate_to_english(custom)
            except Exception: prompt = custom
    else:
        prompt = _ingredient_portrait_prompt(ing)
    rel, cerr = _run_char_candidate(d, iid, prompt, [], prefix="ingcand")   # nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})

@app.route("/api/ingredients/<project>/<iid>/edit-candidate", methods=["POST"])
def api_edit_ingredient_candidate(project, iid):
    """Edit an ingredient candidate with a typed instruction (image-to-image) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    # accept any existing image of this project as the edit base (a candidate OR an already-committed thumbnail)
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/ingedit/{iid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, iid, instr_en, [base_url], prefix="ingcand", family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})

@app.route("/api/ingredients/<project>/<iid>/use-candidate", methods=["POST"])
def api_use_ingredient_candidate(project, iid):
    """Accept an ingredient candidate → commit it as a reference image, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"ingcand_{iid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"ing_{iid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception: pass
    for p in d.glob(f"refs/ingcand_{iid}_*"):
        try: p.unlink()
        except Exception: pass
    ing.setdefault("urls", []).append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>/discard-candidate", methods=["POST"])
def api_discard_ingredient_candidate(project, iid):
    body = request.get_json(silent=True) or {}
    d, safe = proj_dir(project)
    if body.get("all"):
        for p in d.glob(f"refs/ingcand_{iid}_*"):
            try: p.unlink()
            except Exception: pass
    else:
        rel = (body.get("url") or "").strip()
        if rel.startswith("refs/") and f"ingcand_{iid}_" in rel:
            try: (d / rel).unlink()
            except Exception: pass
    return jsonify({"ok": True})

# ---- routes: named characters (per-project cast) ---------------------------
@app.route("/api/characters/<project>", methods=["POST"])
def api_add_character(project):
    """Add a named character: form fields `name` + `file` (reference image). The image is saved
    LOCALLY; the upload to Cloudinary (needed as an i2i reference for Kie) is deferred to image
    generation — so adding a character never needs the network or the Cloudinary quota."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "character name is required"}), 400
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a reference image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    cid = hashlib.md5(f"{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate(files):
        fname = f"char_{cid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ch = {"id": cid, "name": name, "urls": urls}   # local paths; Cloudinary upload happens at generation
    doc.setdefault("characters", []).append(ch)
    save_doc(project, doc)
    return jsonify(ch)


def _norm_char(ch):
    """Migrate a legacy single-`url` character to the multi-image `urls` shape in place."""
    if "urls" not in ch:
        ch["urls"] = [ch["url"]] if ch.get("url") else []
    ch.pop("url", None)
    return ch


def _role_outfit(name, role):
    """Map a character's role/name to a specific, unambiguous outfit so the profession reads at a glance —
    a 'Dr' or a doctor gets a WHITE COAT, not a suit. Returns a phrase or None."""
    r = (role or "").lower()
    n = (name or "").lower()
    is_dr = n.startswith("dr ") or n.startswith("dr.") or (" dr " in f" {n} ")
    if is_dr or any(k in r for k in ("doctor", "physician", "surgeon", "medical", "clinician", "gp")):
        return "a white medical doctor's coat worn over their clothes (a stethoscope is fine) — clearly a doctor"
    if "nurse" in r:
        return "medical nurse scrubs"
    if any(k in r for k in ("research", "scientist", "biolog", "botan", "chemist", "lab", "professor")):
        return "a white lab coat — clearly a scientist/researcher"
    if any(k in r for k in ("chef", "cook")):
        return "a chef's white uniform"
    if any(k in r for k in ("farmer", "grower")):
        return "practical rustic outdoor work clothes"
    return None

def _char_portrait_prompt(ch, aud):
    """Text-to-image prompt for a clean, reusable casting portrait of ONE character, built from the
    character's fixed description (falling back to name/role) + a role-appropriate outfit + a location hint."""
    desc = (ch.get("desc") or "").strip()
    role = (ch.get("role") or "").strip()
    name = (ch.get("name") or "a person").strip()
    who = desc or (name + (f", {role}" if role else ""))
    parts = [f"A clean casting reference portrait of ONE single person: {who}."]
    outfit = _role_outfit(name, role)
    if outfit:
        # forceful, specific — don't bury it in a menu of examples, or the model defaults to a generic suit
        parts.append(f"IMPORTANT: they MUST be clearly shown wearing {outfit}, so their profession is obvious at a glance.")
    elif role:
        parts.append(f"Dress them in clothing appropriate for their role ({role}).")
    loc = None
    try:
        locs = (aud or {}).get("locations")
        if isinstance(locs, list) and locs:
            loc = str(locs[0])
        elif isinstance(locs, str) and locs.strip():
            loc = locs.strip()
    except Exception:
        loc = None
    if loc:
        parts.append(f"If the appearance above doesn't already fix it, make them look like an ordinary person from {loc}.")
    parts.append("Waist-up, facing the camera, calm friendly neutral expression, plain uncluttered light-grey "
                 "background, only this one person in the frame and nothing else, no other people, no props, no "
                 "logos. This is a face/appearance reference to reuse across scenes — keep it simple and clear.")
    parts.append(STYLE_PRESETS.get("natural", ""))
    return "\n".join(p for p in parts if p and p.strip())


def _run_char_candidate(d, cid, prompt, refs, prefix="charcand", family=None, aspect="16:9", resolution="2K", cancel_check=None):
    """Generate ONE candidate PNG: build the request, create a Kie task, poll to completion, download.
    If the primary model fails/times out, AUTOMATICALLY retry with GPT Image (nano-banana has been flaky).
    Returns (rel_url, None) on success or (None, error_message). prefix = charcand (cast) / ingcand (ingredient).
    cancel_check: optional callable → if it returns truthy, abort ASAP with (None, 'cancelled')."""
    families = [family or IMAGE_MODEL]
    if "gpt-image-2" not in families:
        families.append("gpt-image-2")               # fallback model when the primary fails
    last_err = "could not start generation"
    for fam in families:
        if cancel_check and cancel_check():
            return None, "cancelled"
        try:
            model_id, inp = build_kie_image_request(fam, prompt, refs or [], aspect=aspect, resolution=resolution)
            tid, cerr = kie_create(model_id, inp)
        except Exception as e:
            last_err = str(e); continue
        if not tid:
            last_err = cerr or last_err; continue
        url = fail = None
        for _ in range(60):                          # poll up to ~2 minutes
            if cancel_check and cancel_check():
                return None, "cancelled"             # user pressed Stop → abort the in-flight poll
            time.sleep(2)
            try:
                rec = kie_record(tid)
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec); break
            if state == "fail":
                fail = (rec.get("data") or {}).get("failMsg", "generation failed"); break
        if fail:
            last_err = fail; continue                 # primary failed → try the fallback family
        if not url:
            last_err = "generation timed out"; continue
        fname = f"{prefix}_{cid}_{int(time.time() * 1000)}.png"   # ms so rapid regen/edit never collide
        try:
            download_as_png(url, d / "refs" / fname)
        except Exception as e:
            last_err = f"download failed: {e}"; continue
        return f"refs/{fname}", None
    return None, last_err


@app.route("/api/characters/<project>/<cid>/generate", methods=["POST"])
def api_generate_character(project, cid):
    """Generate a portrait CANDIDATE (never auto-committed). `fresh` (first open) clears old candidates;
    a regenerate keeps them so the user can flip between versions. Same model/resolution as scene images."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    body = request.get_json(silent=True) or {}
    if body.get("fresh"):
        for p in d.glob(f"refs/charcand_{cid}_*"):
            try: p.unlink()
            except Exception: pass
    custom = (body.get("prompt") or "").strip()   # user's OWN prompt from the candidate window → overrides the auto prompt
    if custom:
        prompt = custom
        if looks_turkish(custom):
            try: prompt = translate_to_english(custom)
            except Exception: prompt = custom
    else:
        prompt = _char_portrait_prompt(ch, doc.get("audience"))
    rel, cerr = _run_char_candidate(d, cid, prompt, [])   # nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/characters/<project>/<cid>/edit-candidate", methods=["POST"])
def api_edit_char_candidate(project, cid):
    """Edit a candidate with a typed instruction (image-to-image, NanoBanana) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    # accept any existing image of this project as the edit base (a candidate OR an already-committed thumbnail)
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/charedit/{cid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, cid, instr_en, [base_url], family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})


@app.route("/api/characters/<project>/<cid>/use-candidate", methods=["POST"])
def api_use_char_candidate(project, cid):
    """Accept a candidate → rename it into a normal character image, add to roster, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"charcand_{cid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"char_{cid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception: pass
    for p in d.glob(f"refs/charcand_{cid}_*"):          # committed one → drop the rest
        try: p.unlink()
        except Exception: pass
    _norm_char(ch)
    ch["urls"].append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>/discard-candidate", methods=["POST"])
def api_discard_char_candidate(project, cid):
    """Throw away un-accepted candidate(s). `all` clears every candidate for this character (on Cancel)."""
    body = request.get_json(silent=True) or {}
    d, safe = proj_dir(project)
    if body.get("all"):
        for p in d.glob(f"refs/charcand_{cid}_*"):
            try: p.unlink()
            except Exception: pass
    else:
        rel = (body.get("url") or "").strip()
        if rel.startswith("refs/") and f"charcand_{cid}_" in rel:
            try: (d / rel).unlink()
            except Exception: pass
    return jsonify({"ok": True})


@app.route("/api/characters/<project>/<cid>", methods=["POST"])
def api_update_character(project, cid):
    """Edit a character: optional rename (form `name`) and/or append reference image(s) (form `file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    name = (request.form.get("name") or "").strip()
    if name:
        ch["name"] = name
    # transforming character (e.g. slims down across the video): a flag + an optional note + a SECOND photo
    # bucket (`urls_end` = the END look). `bucket=end` routes uploads to that bucket; default is the start bucket.
    if "transforms" in request.form:
        ch["transforms"] = request.form.get("transforms") in ("1", "true", "on", "yes")
    if "transform_note" in request.form:
        ch["transform_note"] = (request.form.get("transform_note") or "").strip()
    bucket = "urls_end" if (request.form.get("bucket") == "end") else "urls"
    ch.setdefault(bucket, [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"char_{cid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ch[bucket].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>/remove-image", methods=["POST"])
def api_remove_character_image(project, cid):
    """Drop one reference image from a character (keeps at least one)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    body = request.get_json(force=True) or {}
    url = body.get("url")
    bucket = "urls_end" if (body.get("bucket") == "end") else "urls"
    lst = ch.setdefault(bucket, [])
    # start bucket must keep at least one photo; the END bucket is optional so it may go empty
    if url in lst and (bucket == "urls_end" or len(lst) > 1):
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception:
            pass
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>", methods=["DELETE"])
def api_del_character(project, cid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["characters"] = [c for c in doc.get("characters", []) if c.get("id") != cid]
    for s in doc.get("scenes", []):        # remove it from every scene's cast
        if cid in (s.get("cast") or []):
            s["cast"] = [x for x in s["cast"] if x != cid]
    save_doc(project, doc)
    return jsonify({"ok": True, "characters": doc["characters"]})

# ---- routes: testimonial people (per-project social-proof roster, separate from cast) --------
# Mirrors the cast routes but under DOC["testimonials"], allows name-only people (no reference image
# required — a portrait can be generated from the description afterwards), and reuses the shared
# candidate helper (_run_char_candidate) with a `tpcand`/`tp` file prefix so nothing collides with cast.
# Distinct setting + matching outfit per testimonial person, so a set of portraits doesn't all come out
# in the SAME room with the SAME clothes (nano-banana defaults everyone to a kitchen otherwise). Picked by
# index so different people differ; a regenerate rotates to the next one.
_TP_SCENES = [
    ("in a bright home kitchen", "a casual everyday jumper or shirt"),
    ("in a modern office / co-working space", "smart-casual corporate clothes — a collared shirt or a blazer"),
    ("outdoors in a green park", "relaxed sporty clothes, like a zip-up hoodie or a tracksuit top"),
    ("on an ordinary city high street", "an everyday street-casual jacket or coat"),
    ("in a cosy living room at home", "a comfortable soft sweater or cardigan"),
    ("in a cafe / coffee shop", "a relaxed casual top under a light jacket"),
    ("in a back garden / on a patio", "a light casual t-shirt or polo"),
    ("in the driver's seat of a car", "everyday casual clothes with a seatbelt on"),
    ("at a gym / leisure centre", "sporty activewear — a training top"),
    ("walking on a countryside path by the seaside", "an outdoor casual jacket"),
]


def _tp_portrait_prompt(person, aud, variety_idx=None):
    """Text-to-image prompt for an authentic, relatable everyday-person portrait — a believable real
    customer look for testimonials, built from the person's age / location / appearance note.
    `variety_idx` (when given) forces a SPECIFIC distinct setting + outfit so a batch of people vary."""
    desc = (person.get("desc") or "").strip()
    age = str(person.get("age") or "").strip()
    gender = (person.get("gender") or "").strip()
    loc = (person.get("location") or "").strip()
    bits = []
    if age:
        bits.append(f"around {age} years old")
    if gender:
        bits.append(gender.lower())
    if desc:
        bits.append(desc)
    who = ", ".join(bits) if bits else "an ordinary, relatable everyday person"
    parts = [f"A candid, authentic AMATEUR photo of ONE single real-looking ordinary person: {who}."]
    if not loc:
        # fall back to the project's audience locations when the person has none of their own
        try:
            locs = (aud or {}).get("locations")
            if isinstance(locs, list) and locs:
                loc = str(locs[0]).strip()
            elif isinstance(locs, str) and locs.strip():
                loc = locs.strip()
        except Exception:
            loc = ""
    if loc:
        parts.append(f"They look like an ordinary person from {loc}.")
    if variety_idx is not None:
        setting, outfit = _TP_SCENES[variety_idx % len(_TP_SCENES)]
        bg = (f"Set specifically {setting}, visible and MOSTLY IN FOCUS behind them like a normal phone snapshot "
              f"(NOT a blurred portrait-mode / shallow-depth background) — this exact setting is REQUIRED, do NOT "
              f"default to a kitchen. They are wearing {outfit}. ")
    else:
        bg = ("Set in a NATURAL EVERYDAY BACKGROUND (at home, in the kitchen, at work, in a car, a cafe, a park or "
              "an ordinary street), visible and mostly in focus behind them like a normal phone snapshot (NOT a "
              "blurred portrait-mode background). ")
    # alternate selfie vs an ordinary snapshot taken by someone else, so a batch of portraits isn't ALL selfies
    is_selfie = (variety_idx % 2 == 0) if variety_idx is not None else True
    shot = ("a real AMATEUR front-facing phone SELFIE the person snapped of themselves at arm's length (slight "
            "selfie front-camera look)" if is_selfie else
            "a casual AMATEUR snapshot an ordinary person took of them on a phone (NOT a selfie)")
    parts.append(f"This MUST look like {shot}, used as a social-media PROFILE PICTURE - absolutely NOT a studio shot, "
                 "NOT a professional headshot, NOT a polished stock photo, and NOT a model. Compose it like a profile "
                 "photo: the person CENTRED in the frame and facing the camera, framed CLOSE - a tight head-and-"
                 "shoulders crop where the FACE is large and fills much of the frame (top of the head near the top "
                 "edge). Warm, genuine, natural expression; relaxed and a little imperfect, but CENTRED and upright "
                 "(do not tilt or push them to a corner). " + bg +
                 "Shot on an ORDINARY, cheap / older smartphone camera - modest everyday quality, mixed available "
                 "lighting (a little uneven, maybe slightly over-exposed near a window or a hint of on-phone flash), "
                 "visible sensor noise/grain, a bit soft and NOT razor-sharp, plain UNRETOUCHED skin with real texture "
                 "and pores. Only this one ordinary person in the frame, no other people, no logos, no text, no "
                 "watermark. A believable real customer's profile photo - authentic, relatable and a little rough, "
                 "never glossy, sharp, cinematic or stock-looking.")
    parts.append(STYLE_PRESETS.get("natural", ""))
    return "\n".join(p for p in parts if p and p.strip())


@app.route("/api/testimonial-people/<project>", methods=["POST"])
@_locked
def api_add_tperson(project):
    """Add a testimonial person: form `name` (required), optional `desc`, optional `file`(s).
    Unlike cast, no reference image is required — a portrait can be generated from the description."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip() or "New character"   # name-less add is fine; filled in on the card
    desc = (request.form.get("desc") or "").strip()
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    pid = hashlib.md5(f"tp{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"tp_{pid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    person = {"id": pid, "name": name, "desc": desc,
              "age": (request.form.get("age") or "").strip(),
              "gender": (request.form.get("gender") or "").strip(),
              "location": (request.form.get("location") or "").strip(), "urls": urls}
    doc.setdefault("testimonials", []).append(person)
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>", methods=["POST"])
@_locked
def api_update_tperson(project, pid):
    """Edit a testimonial person: optional rename (`name`), appearance note (`desc`), and/or append image(s) (`file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    name = (request.form.get("name") or "").strip()
    if name:
        person["name"] = name
    if "desc" in request.form:
        person["desc"] = (request.form.get("desc") or "").strip()
    if "age" in request.form:
        person["age"] = (request.form.get("age") or "").strip()
    if "gender" in request.form:
        person["gender"] = (request.form.get("gender") or "").strip()
    if "location" in request.form:
        person["location"] = (request.form.get("location") or "").strip()
    person.setdefault("urls", [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"tp_{pid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        person["urls"].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>/remove-image", methods=["POST"])
@_locked
def api_remove_tperson_image(project, pid):
    """Drop one image from a testimonial person (may go empty — a portrait can be regenerated later)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    url = (request.get_json(force=True) or {}).get("url")
    lst = person.setdefault("urls", [])
    if url in lst:
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception:
            pass
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>", methods=["DELETE"])
@_locked
def api_del_tperson(project, pid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["testimonials"] = [c for c in doc.get("testimonials", []) if c.get("id") != pid]
    save_doc(project, doc)
    return jsonify({"ok": True, "testimonials": doc["testimonials"]})


@app.route("/api/testimonial-people/<project>/<pid>/generate", methods=["POST"])
def api_generate_tperson(project, pid):
    """Generate a portrait CANDIDATE for a testimonial person (never auto-committed). `fresh` clears old candidates."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    if (request.get_json(silent=True) or {}).get("fresh"):
        for p in d.glob(f"refs/tpcand_{pid}_*"):
            try: p.unlink()
            except Exception: pass
    # give each person a DISTINCT setting/outfit (index among the roster) and rotate on every regenerate
    # (count of remaining candidates) so re-rolls also change the scene instead of another kitchen.
    people = doc.get("testimonials", [])
    base_idx = next((i for i, c in enumerate(people) if c.get("id") == pid), 0)
    rot = len(list(d.glob(f"refs/tpcand_{pid}_*")))
    prompt = _tp_portrait_prompt(person, doc.get("audience"), variety_idx=base_idx + rot)
    rel, cerr = _run_char_candidate(d, pid, prompt, [], prefix="tpcand", aspect="1:1")   # square selfie/profile look; nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-people/<project>/<pid>/edit-candidate", methods=["POST"])
def api_edit_tperson_candidate(project, pid):
    """Edit a candidate with a typed instruction (image-to-image, NanoBanana) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/tpedit/{pid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, pid, instr_en, [base_url], prefix="tpcand", family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})


@app.route("/api/testimonial-people/<project>/<pid>/use-candidate", methods=["POST"])
@_locked
def api_use_tperson_candidate(project, pid):
    """Accept a candidate → rename it into a normal image, add to the person, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"tpcand_{pid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"tp_{pid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception: pass
    for p in d.glob(f"refs/tpcand_{pid}_*"):          # committed one → drop the rest
        try: p.unlink()
        except Exception: pass
    person.setdefault("urls", []).append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>/discard-candidate", methods=["POST"])
def api_discard_tperson_candidate(project, pid):
    """Throw away un-accepted candidate(s). `all` clears every candidate for this person (on Cancel)."""
    body = request.get_json(silent=True) or {}
    d, safe = proj_dir(project)
    if body.get("all"):
        for p in d.glob(f"refs/tpcand_{pid}_*"):
            try: p.unlink()
            except Exception: pass
    else:
        rel = (body.get("url") or "").strip()
        if rel.startswith("refs/") and f"tpcand_{pid}_" in rel:
            try: (d / rel).unlink()
            except Exception: pass
    return jsonify({"ok": True})


# ---- routes: written testimonial cards (HTML -> PNG) ------------------------
# The card DESIGN lives entirely in the frontend (single source of truth = the live preview). To export,
# the browser sends the card's self-contained HTML (inline styles + the portrait embedded as a data-URI)
# and we screenshot it with the SAME headless-browser engine as the caption/OST render — so the downloaded
# PNG is pixel-identical to what the user saw.
_TC_RENDER_LOCK = threading.Lock()

def _render_html_png(html, out_png, w, h, scale=2):
    edge = None
    try:
        from caption_layer import edge_exe
        edge = edge_exe()
    except Exception:
        edge = None
    if not edge:
        return False, "no headless browser (Edge/Chrome) found"
    out_png.parent.mkdir(parents=True, exist_ok=True)
    hp = out_png.with_suffix(".html")
    hp.write_text(html, encoding="utf-8")
    # isolated profile: without it, a headless launch hands off to an already-running Edge and never
    # writes the screenshot (produces no image).
    prof = tempfile.mkdtemp(prefix="tcedge_")
    if out_png.exists():
        try: out_png.unlink()
        except Exception: pass
    cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
           "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}",
           f"--force-device-scale-factor={scale}", "--allow-file-access-from-files",
           f"--window-size={int(w)},{int(h)}", f"--screenshot={out_png.resolve()}", hp.resolve().as_uri()]
    err = None
    with _TC_RENDER_LOCK:                                  # serialise renders (one headless Edge at a time)
        try:
            subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=120,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            err = str(e)
        # the headless parent can return BEFORE the screenshot child finishes writing the PNG — wait for the
        # file to appear and its size to settle. The source HTML must stay on disk until then, so we only
        # delete it AFTER (a premature delete makes Edge screenshot an "ERR_FILE_NOT_FOUND" page instead).
        if err is None:
            last = -1
            for _ in range(60):                           # up to ~18s
                if out_png.exists():
                    sz = out_png.stat().st_size
                    if sz > 0 and sz == last:
                        break
                    last = sz
                time.sleep(0.3)
    try: hp.unlink()
    except Exception: pass
    shutil.rmtree(prof, ignore_errors=True)
    if err:
        return False, err
    return (True, None) if (out_png.exists() and out_png.stat().st_size > 0) else (False, "render produced no image")


def _render_html_domdump(html, w, h, scale=2):
    """Run headless Edge on HTML and capture the post-script DOM (--dump-dom). An in-page script
    measures each word's box and writes it into the DOM, so we can read the laid-out word rects for
    the karaoke video. Returns (dom_string, err)."""
    try:
        from caption_layer import edge_exe
        edge = edge_exe()
    except Exception:
        edge = None
    if not edge:
        return None, "no headless browser found"
    prof = tempfile.mkdtemp(prefix="tcdom_")
    hp = Path(prof) / "page.html"
    hp.write_text(html, encoding="utf-8")
    cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
           "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}",
           f"--force-device-scale-factor={scale}", "--allow-file-access-from-files",
           "--virtual-time-budget=2000", f"--window-size={int(w)},{int(h)}", "--dump-dom",
           hp.resolve().as_uri()]
    out, err = None, None
    with _TC_RENDER_LOCK:
        try:
            r = subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=60,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            out = r.stdout.decode("utf-8", "replace")
        except Exception as e:
            err = str(e)
    shutil.rmtree(prof, ignore_errors=True)
    return (out, None) if err is None else (None, err)


@app.route("/api/testimonial-cards/<project>/render", methods=["POST"])
def api_render_testimonial_card(project):
    """Render a written-testimonial card (self-contained HTML from the browser) to a PNG under cards/."""
    if load_doc(project) is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    html = (body.get("html") or "").strip()
    if not html:
        return jsonify({"error": "no card html"}), 400
    try:
        w = max(64, min(4096, int(body.get("w") or 1080)))
        h = max(64, min(8192, int(body.get("h") or 1080)))
    except Exception:
        w, h = 1080, 1080
    (d / "cards").mkdir(parents=True, exist_ok=True)
    fname = f"cards/card_{int(time.time() * 1000)}.png"
    ok, err = _render_html_png(html, d / fname, w, h, scale=2)
    if not ok:
        return jsonify({"error": err or "render failed"}), 502
    return jsonify({"ok": True, "url": fname})


def _project_words(d):
    """Word-level timings [{s,e,w}] from the aligner's words_*.tsv cache (empty if none)."""
    sd = d / "subtitle"
    out = []
    if not sd.exists():
        return out
    cands = [sd / "words_medium_en_vad.tsv", sd / "words_medium_en.tsv"] + sorted(sd.glob("words_*.tsv"))
    wp = next((p for p in cands if p.exists()), None)
    if not wp:
        return out
    try:
        for ln in wp.read_text(encoding="utf-8").splitlines():
            if not ln.strip():
                continue
            parts = ln.split("\t", 2)
            if len(parts) >= 3:
                out.append({"s": float(parts[0]), "e": float(parts[1]), "w": parts[2]})
    except Exception:
        return []
    return out


def _karaoke_frames_mp4(tmp_dir, html, w, h, words, seg_start, seg_end, out_mp4, audio_path=None, fps=30):
    """Render a card HTML (with .kw[data-i] spans + a #__rects measuring script) to an MP4 with the
    cumulative GREEN karaoke burned in (multiply blend → paper turns green, text stays black). words=[{s,e}]
    are on the SAME timeline as seg_start/seg_end. audio_path=None → silent clip. Returns True on success."""
    import json as _json
    scale = 2
    tmp_dir.mkdir(parents=True, exist_ok=True)
    stem = out_mp4.stem
    base_png = tmp_dir / f"{stem}_base.png"
    ok, _e = _render_html_png(html, base_png, int(w), int(h), scale=scale)
    if not ok:
        return False
    dom, _d = _render_html_domdump(html, int(w), int(h), scale=scale)
    rmap = {}
    if dom:
        m = re.search(r'id="__rects"[^>]*>(.*?)</div>', dom, re.S)
        if m:
            try:
                for rr in _json.loads(m.group(1).strip() or "[]"):
                    rmap[int(rr["i"])] = (float(rr["x"]) * scale, float(rr["y"]) * scale,
                                          float(rr["w"]) * scale, float(rr["h"]) * scale)
            except Exception:
                rmap = {}
    from PIL import Image, ImageDraw, ImageChops
    base = Image.open(base_png).convert("RGB")
    green_full = Image.new("RGB", base.size, (143, 227, 106))
    pad = int(2 * scale)
    ANTIC = 0.22   # start each word's fade THIS early (= FADE) so the green reaches FULL exactly when the word is spoken — perfectly on-beat
    onsets = sorted([(wi, min(max(float(wd.get("s", 0.0)) - ANTIC, seg_start), seg_end)) for wi, wd in enumerate(words)
                     if float(wd.get("s", 1e9)) < seg_end], key=lambda x: x[1])
    fdir = tmp_dir / f"{stem}_f"; fdir.mkdir(parents=True, exist_ok=True)
    pil_cache, saved = {}, {}

    def img_for(cnt):
        if cnt in pil_cache:
            return pil_cache[cnt]
        frame = base
        if cnt > 0 and rmap:
            mask = Image.new("L", base.size, 0); dr = ImageDraw.Draw(mask); lines = {}
            for k in range(cnt):
                rc = rmap.get(onsets[k][0])
                if not rc:
                    continue
                x0, y0, x1, y1 = rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3]
                key = round(y0 / (6 * scale))
                if key in lines:
                    a = lines[key]; lines[key] = (min(a[0], x0), min(a[1], y0), max(a[2], x1), max(a[3], y1))
                else:
                    lines[key] = (x0, y0, x1, y1)
            for (x0, y0, x1, y1) in lines.values():
                dr.rectangle([x0 - pad, y0 - pad, x1 + pad, y1 + pad], fill=255)
            frame = Image.composite(ImageChops.multiply(base, green_full), base, mask)
        pil_cache[cnt] = frame
        return frame

    def path_for(key, img):
        if key in saved:
            return saved[key]
        p = fdir / f"{key}.png"; img.save(p); saved[key] = p
        return p

    def img_all():                                     # every card word green — the final held frame, so a last word the aligner dropped still lights
        if "ALL" in pil_cache:
            return pil_cache["ALL"]
        frame = base
        if rmap:
            mask = Image.new("L", base.size, 0); dr = ImageDraw.Draw(mask); lines = {}
            for rc in rmap.values():
                x0, y0, x1, y1 = rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3]
                key = round(y0 / (6 * scale))
                if key in lines:
                    a = lines[key]; lines[key] = (min(a[0], x0), min(a[1], y0), max(a[2], x1), max(a[3], y1))
                else:
                    lines[key] = (x0, y0, x1, y1)
            for (x0, y0, x1, y1) in lines.values():
                dr.rectangle([x0 - pad, y0 - pad, x1 + pad, y1 + pad], fill=255)
            frame = Image.composite(ImageChops.multiply(base, green_full), base, mask)
        pil_cache["ALL"] = frame
        return frame

    bounds = [seg_start] + [o[1] for o in onsets] + [seg_end]
    uniq = []
    for b in bounds:
        bb = min(max(b, seg_start), seg_end)
        if not uniq or bb > uniq[-1] + 1e-4:
            uniq.append(bb)
    if not uniq or uniq[-1] < seg_end - 1e-4:
        uniq.append(seg_end)
    FADE = 0.22
    STEPS = max(3, int(round(FADE * fps)))             # one blend frame per OUTPUT frame across the fade → maximally smooth at the render fps (no frame-doubling steppiness)
    lines_txt = []
    prev_cnt = 0
    n_int = len(uniq) - 1
    for k in range(n_int):
        b0, b1 = uniq[k], uniq[k + 1]; dur = max(0.02, b1 - b0)
        cnt = sum(1 for o in onsets if o[1] <= b0 + 1e-4)
        is_last = (k == n_int - 1)                     # final interval → fill ALL words (covers a dropped trailing word)
        tgt_img = img_all() if is_last else img_for(cnt)
        tgt_key = "sALL" if is_last else f"s{cnt:04d}"
        if (cnt != prev_cnt or is_last) and rmap:      # blend from the previous state into the new one → smooth fade-in
            fd = min(FADE, dur * 0.7); per = fd / STEPS
            for si in range(1, STEPS + 1):
                a = si / (STEPS + 1)
                fp = path_for(f"f{prev_cnt}_{tgt_key}_{si}", Image.blend(img_for(prev_cnt), tgt_img, a))
                lines_txt.append(f"file '{fp.resolve().as_posix()}'"); lines_txt.append(f"duration {per:.3f}")
            dur = max(0.02, dur - fd)
        p = path_for(tgt_key, tgt_img)
        lines_txt.append(f"file '{p.resolve().as_posix()}'"); lines_txt.append(f"duration {dur:.3f}")
        prev_cnt = cnt
    tail_p = path_for("sALL", img_all())
    lines_txt.append(f"file '{tail_p.resolve().as_posix()}'"); lines_txt.append("duration 1.500")   # pad past the scene end so the render's trim (scene dur + xfade overlap) always has footage — otherwise everything after this scene desyncs
    lines_txt.append(f"file '{tail_p.resolve().as_posix()}'")
    listf = fdir / "list.txt"; listf.write_text("\n".join(lines_txt), encoding="utf-8")
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(listf)]
    if audio_path:
        cmd += ["-i", str(audio_path)]
    cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p", "-r", str(int(fps)), "-c:v", "libx264"]
    cmd += (["-c:a", "aac", "-shortest"] if audio_path else ["-an"])
    cmd += ["-movflags", "+faststart", str(out_mp4)]
    try:
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=600)
    except Exception:
        return False
    try:
        base_png.unlink()
    except OSError:
        pass
    shutil.rmtree(fdir, ignore_errors=True)
    return out_mp4.exists() and out_mp4.stat().st_size > 0


def _align_words_to_text(all_words, text, hint_start=None):
    """Sequence-align the card words to the VO word stream (anchored near the scene start): each card word
    gets its real time; VO words the card lacks (a narrator intro) are skipped; card words not in the VO
    (edits/typos) inherit the previous word's time. Returns one timed word per card word. [] if no match."""
    def _n(s):
        return re.sub(r'[^a-z0-9]', '', (s or '').lower())
    cw = [c for c in (_n(t) for t in (text or '').split()) if c]
    if not cw or not all_words:
        return []
    vw = [_n(w.get('w', '')) for w in all_words]
    vi = 0
    if hint_start is not None:
        for i, w in enumerate(all_words):
            if float(w.get('s', 0)) >= hint_start - 0.4:
                vi = i
                break
    out = [None] * len(cw)
    for ci in range(len(cw)):
        hit = -1
        for k in range(0, 9):
            if vi + k < len(vw) and vw[vi + k] == cw[ci]:
                hit = vi + k
                break
        if hit >= 0:
            out[ci] = all_words[hit]
            vi = hit + 1
    last = None
    for ci in range(len(cw)):
        if out[ci]:
            last = out[ci]
        elif last:
            out[ci] = {"s": last["s"], "e": last["e"], "w": cw[ci]}
    first = next((x for x in out if x), None)
    if first:
        for ci in range(len(cw)):
            if not out[ci]:
                out[ci] = {"s": first["s"], "e": first["e"], "w": cw[ci]}
    return [x for x in out if x]


def _apply_custom_testimonial_vo(project, doc, tl):
    """If a written-testimonial scene has its OWN voice-over (card.extra.vo + vo_dur), splice that clip into
    the project VO in place of the original span (so the testimonial's duration = the custom clip's length),
    rebuild the VO audio, and remap every scene/caption/music time so everything after shifts.
    No custom voices → returns tl unchanged (normal projects are untouched). Fail-safe: any error → original tl."""
    try:
        d = tl["dir"]
        cards = {c.get("id"): c for c in doc.get("testimonial_cards", [])}
        dscenes = {s.get("id"): s for s in doc.get("scenes", [])}
        splices = []
        for sc in tl["scenes"]:
            ds = dscenes.get(sc.get("id"))
            if not ds or not ds.get("tcard_id"):
                continue
            card = cards.get(ds["tcard_id"])
            if not card:
                continue
            ex = card.get("extra") or {}
            vo, dur = ex.get("vo"), ex.get("vo_dur")
            if not vo or not dur or float(dur) <= 0.1:
                continue
            p = (d / vo).resolve()
            try:
                p.relative_to(d.resolve())
            except Exception:
                continue
            if not p.exists():
                continue
            splices.append({"id": sc["id"], "s": float(sc["start"]), "e": float(sc["end"]), "dur": float(dur), "audio": p})
        if not splices:
            return tl
        splices.sort(key=lambda x: x["s"])
        total = float(tl["total"])
        src_vo = Path(tl["vo"])
        tmp = d / "export" / "_tvo"
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)

        def _seg(src, ss, to, out, is_clip=False):
            cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
            if is_clip:
                cmd += ["-i", str(src), "-t", f"{to:.3f}"]
            else:
                cmd += ["-ss", f"{ss:.3f}", "-to", f"{to:.3f}", "-i", str(src)]
            cmd += ["-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "192k", str(out)]
            subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=240)
            return out.exists() and out.stat().st_size > 0

        parts, cur = [], 0.0
        for sp in splices:
            if sp["s"] - cur > 0.02:
                kp = tmp / f"p{len(parts):03d}.m4a"
                if _seg(src_vo, cur, sp["s"], kp):
                    parts.append(kp)
            src_clip = sp["audio"]
            try:   # bring the custom testimonial voice to the SAME VSL loudness as the (already-normalized) main VO — cached next to the clip so we only normalize once
                ncache = sp["audio"].with_name(sp["audio"].stem + "_norm.wav")
                if ncache.exists() and ncache.stat().st_mtime >= sp["audio"].stat().st_mtime:
                    src_clip = ncache
                else:
                    nrm = premiere_export.normalize_loudness(sp["audio"], ncache)
                    if nrm:
                        src_clip = nrm
            except Exception:
                pass
            cp = tmp / f"p{len(parts):03d}.m4a"
            if _seg(src_clip, 0, sp["dur"], cp, is_clip=True):
                parts.append(cp)
            cur = sp["e"]
        if total - cur > 0.02:
            kp = tmp / f"p{len(parts):03d}.m4a"
            if _seg(src_vo, cur, total, kp):
                parts.append(kp)
        if not parts:
            return tl
        # concat the audio parts (filter, not demuxer → no aac gap/timestamp issues)
        inputs = []
        for p in parts:
            inputs += ["-i", str(p)]
        fc = "".join(f"[{i}:a]" for i in range(len(parts))) + f"concat=n={len(parts)}:v=0:a=1[a]"
        spliced = d / "export" / "voiceover_tvo.m4a"
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *inputs,
                        "-filter_complex", fc, "-map", "[a]", "-c:a", "aac", "-b:a", "192k", str(spliced)],
                       creationflags=_NO_WINDOW, timeout=600)
        if not (spliced.exists() and spliced.stat().st_size > 0):
            return tl
        # piecewise time map: keep spans map 1:1, each replaced span maps [s,e] → [n, n+dur]
        segmap, cur_o, cur_n = [], 0.0, 0.0
        for sp in splices:
            if sp["s"] > cur_o:
                segmap.append((cur_o, sp["s"], cur_n, cur_n + (sp["s"] - cur_o))); cur_n += (sp["s"] - cur_o)
            segmap.append((sp["s"], sp["e"], cur_n, cur_n + sp["dur"])); cur_n += sp["dur"]
            cur_o = sp["e"]
        tail = total - cur_o
        segmap.append((cur_o, total, cur_n, cur_n + max(0.0, tail)))
        new_total = cur_n + max(0.0, tail)

        def remap(t):
            t = max(0.0, min(float(t), total))
            for (o0, o1, n0, n1) in segmap:
                if t <= o1 + 1e-6:
                    return n0 if (o1 - o0) < 1e-6 else n0 + (t - o0) / (o1 - o0) * (n1 - n0)
            return new_total

        for sc in tl["scenes"]:
            sc["start"], sc["end"] = remap(sc["start"]), remap(sc["end"])
        for c in tl.get("captions", []):
            c["start"], c["end"] = remap(c["start"]), remap(c["end"])
        for mseg in tl.get("music", []):
            mseg["start"], mseg["end"] = remap(mseg["start"]), remap(mseg["end"])
        tl["vo"] = spliced
        tl["total"] = round(new_total, 3)
        tl["_tvo_ids"] = {sp["id"] for sp in splices}   # scenes now driven by a custom clip (karaoke uses the clip's own words)
        tl["_tvo_segmap"] = segmap                       # piecewise time map (for the Premiere XML: remap its SRT + words the same way)
        try:   # remap the ORIGINAL word timings too, so a LATER (non-custom) testimonial's karaoke stays in sync after the shift
            tl["words_remapped"] = [{"s": round(remap(w["s"]), 3), "e": round(remap(w["e"]), 3), "w": w.get("w", "")} for w in _project_words(d)]
        except Exception:
            pass
        return tl
    except Exception:
        return tl


def _seg_remap(segmap, t):
    """Map an original time onto the spliced timeline using the piecewise segmap from _apply_custom_testimonial_vo."""
    if not segmap:
        return float(t)
    t = max(0.0, float(t))
    for (o0, o1, n0, n1) in segmap:
        if t <= o1 + 1e-6:
            return n0 if (o1 - o0) < 1e-6 else n0 + (t - o0) / (o1 - o0) * (n1 - n0)
    return segmap[-1][3]


def _inject_testimonial_karaoke(project, doc, tl, tmp_dir):
    """Before rendering: swap each WRITTEN-testimonial scene's STILL for a same-duration clip with the green
    karaoke burned in (audio stays the main VO track). Fully guarded — any failure leaves the still as-is."""
    try:
        cards = {c.get("id"): c for c in doc.get("testimonial_cards", [])}
        dscenes = {s.get("id"): s for s in doc.get("scenes", [])}
        words_all = tl.get("words_remapped") or _project_words(tl["dir"])   # after a custom-VO splice, use the REMAPPED word times so later testimonials stay in sync
    except Exception:
        return
    if not words_all:
        return
    tmp_dir = Path(tmp_dir); tmp_dir.mkdir(parents=True, exist_ok=True)
    windows = []                                    # (testimonial_body_start, scene_end): drop the burned subtitle here (keep any narrator intro before it)
    for sc in tl.get("scenes", []):
        try:
            ds = dscenes.get(sc.get("id"))
            if not ds or not ds.get("tcard_id"):
                continue
            card = cards.get(ds["tcard_id"])
            if not card or card.get("type") == "video":
                continue
            start, end = float(sc["start"]), float(sc["end"])
            sc["no_zoom"] = True                 # never Ken-Burns-zoom a testimonial card (karaoke clip OR still fallback)
            ex = card.get("extra") or {}
            if sc.get("id") in tl.get("_tvo_ids", set()) and ex.get("words") and ex.get("vo_dur"):
                words = [{"s": start + float(w.get("s", 0)), "e": start + float(w.get("e", 0)), "w": w.get("w", "")} for w in ex["words"]]   # this scene now plays the CUSTOM clip → use its own 0-based alignment, offset to the new scene start
            else:
                words = _align_words_to_text(words_all, card.get("text"), start)   # exact card words from the full stream (correct last-word timing)
                if not words:
                    words = [wd for wd in words_all if wd["s"] >= start - 0.05 and wd["s"] < end + 0.5]
            windows.append((start, end))            # no subtitle at all over a written-testimonial scene
            kara = (card.get("extra") or {}).get("kara") or {}
            html = kara.get("html"); kw = kara.get("w") or 0; kh = kara.get("h") or 0
            if sc.get("kind") == "image" and sc.get("path") and html and kw > 10 and kh > 10:   # skip a broken (0×0) kara → keep the still
                out_mp4 = tmp_dir / f"kara_{sc['id']}.mp4"
                if _karaoke_frames_mp4(tmp_dir, html, kw, kh, words, start, end, out_mp4, audio_path=None,
                                       fps=int(getattr(render_video, "FPS", 30))):   # match the render fps so the fade is smooth (no frame-doubling)
                    sc["kind"] = "video"; sc["path"] = out_mp4
        except Exception:
            continue
    if windows:                                     # strip captions that fall inside the testimonial BODY (keep the intro)
        def _in_win(c):
            cs, ce = float(c.get("start", 0)), float(c.get("end", 0))
            return any(cs < we and ce > ws - 0.05 for (ws, we) in windows)
        tl["captions"] = [c for c in tl.get("captions", []) if not _in_win(c)]


@app.route("/api/testimonial-cards/<project>/<cid>/video", methods=["POST"])
def api_tcard_video(project, cid):
    """Render a testimonial card to an MP4 with the word-level GREEN karaoke burned in + the voice-over.
    Client sends the card HTML (words wrapped in .kw[data-i] + a measuring script that writes each word's
    box into #__rects), the word timings [{s,e}] (absolute VO seconds), and the [start,end] VO slice."""
    import json as _json, math as _math
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    html = (body.get("html") or "").strip()
    if not html:
        return jsonify({"error": "no card html"}), 400
    try:
        w = max(64, min(4096, int(body.get("w") or 1080)))
        h = max(64, min(8192, int(body.get("h") or 1080)))
    except Exception:
        w, h = 1080, 1080
    words = body.get("words") or []                     # [{s,e}] absolute VO seconds, index-aligned to .kw[data-i]
    try:
        start = float(body.get("start")); end = float(body.get("end"))
    except Exception:
        return jsonify({"error": "missing segment times"}), 400
    if end <= start:
        return jsonify({"error": "bad segment"}), 400
    scale = 2
    (d / "cards").mkdir(parents=True, exist_ok=True)
    ts = int(time.time() * 1000)
    base_png = d / f"cards/vid_{ts}_base.png"
    ok, err = _render_html_png(html, base_png, w, h, scale=scale)
    if not ok:
        return jsonify({"error": err or "render failed"}), 502
    # measure the word boxes (may be empty → video still renders, just without the highlight)
    dom, _derr = _render_html_domdump(html, w, h, scale=scale)
    rmap = {}
    if dom:
        m = re.search(r'id="__rects"[^>]*>(.*?)</div>', dom, re.S)
        if m:
            try:
                for rr in _json.loads(m.group(1).strip() or "[]"):
                    rmap[int(rr["i"])] = (float(rr["x"]) * scale, float(rr["y"]) * scale,
                                          float(rr["w"]) * scale, float(rr["h"]) * scale)
            except Exception:
                rmap = {}
    # audio source: a card's CUSTOM voice-over if given (whole clip, 0-based times), else the ORIGINAL
    # project VO (its word times are aligned to it), sliced to [start,end]
    audio_rel = (body.get("audio") or "").strip()
    if audio_rel:
        src_vo = (d / audio_rel).resolve()
        try:
            src_vo.relative_to(d.resolve())
        except Exception:
            return jsonify({"error": "bad audio path"}), 400
        if not src_vo.exists():
            return jsonify({"error": "voice-over file not found"}), 400
    else:
        src_vo = _find_vo_audio(d)
        if not src_vo:
            return jsonify({"error": "no voice-over found — generate the SRT first"}), 400
    seg_audio = d / f"cards/vid_{ts}_a.m4a"
    try:
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}",
                        "-to", f"{end:.3f}", "-i", str(src_vo), "-c:a", "aac", "-b:a", "160k", str(seg_audio)],
                       creationflags=_NO_WINDOW, timeout=120)
    except Exception as e:
        return jsonify({"error": "audio extract failed: " + str(e)}), 502
    # build ONE frame per cumulative-green state (word onset) — few images, exact timing via the concat demuxer
    from PIL import Image, ImageDraw, ImageChops
    base = Image.open(base_png).convert("RGB")
    GREEN = (143, 227, 106)
    green_full = Image.new("RGB", base.size, GREEN)
    pad = int(2 * scale)
    onsets = sorted([(wi, min(max(float(wd.get("s", 0.0)), start), end)) for wi, wd in enumerate(words)
                     if float(wd.get("s", 1e9)) < end], key=lambda x: x[1])
    fdir = d / f"cards/vid_{ts}_f"; fdir.mkdir(parents=True, exist_ok=True)
    img_cache = {}

    def frame_for(cnt):
        """Image with the first `cnt` onset-words highlighted (green, merged per line = continuous)."""
        if cnt in img_cache:
            return img_cache[cnt]
        frame = base
        if cnt > 0 and rmap:
            mask = Image.new("L", base.size, 0); dr = ImageDraw.Draw(mask)
            lines = {}
            for k in range(cnt):
                rc = rmap.get(onsets[k][0])
                if not rc:
                    continue
                x0, y0, x1, y1 = rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3]
                key = round(y0 / (6 * scale))                # bucket words on the same line
                if key in lines:
                    a = lines[key]; lines[key] = (min(a[0], x0), min(a[1], y0), max(a[2], x1), max(a[3], y1))
                else:
                    lines[key] = (x0, y0, x1, y1)
            for (x0, y0, x1, y1) in lines.values():
                dr.rectangle([x0 - pad, y0 - pad, x1 + pad, y1 + pad], fill=255)
            # MULTIPLY blend inside the mask: white paper turns green, but DARK text stays dark (real highlighter look)
            frame = Image.composite(ImageChops.multiply(base, green_full), base, mask)
        p = fdir / f"s{cnt:04d}.png"; frame.save(p)
        img_cache[cnt] = p
        return p

    # timeline: intervals between [start, each onset..., end]; green count during an interval = onsets started by then
    bounds = [start] + [o[1] for o in onsets] + [end]
    seen, uniq = set(), []
    for b in bounds:                                        # keep strictly increasing
        if not uniq or b > uniq[-1] + 1e-4:
            uniq.append(min(max(b, start), end))
    if uniq[-1] < end - 1e-4:
        uniq.append(end)
    lines_txt = []
    for k in range(len(uniq) - 1):
        b0, b1 = uniq[k], uniq[k + 1]
        dur = max(0.02, b1 - b0)
        cnt = sum(1 for o in onsets if o[1] <= b0 + 1e-4)   # words already started at b0
        p = frame_for(cnt)
        lines_txt.append(f"file '{p.resolve().as_posix()}'")
        lines_txt.append(f"duration {dur:.3f}")
    last_p = frame_for(len(onsets))
    lines_txt.append(f"file '{last_p.resolve().as_posix()}'")   # concat demuxer needs the last file repeated
    listf = fdir / "list.txt"; listf.write_text("\n".join(lines_txt), encoding="utf-8")
    out_mp4 = d / f"cards/testimonial_{ts}.mp4"
    try:
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0",
                        "-i", str(listf), "-i", str(seg_audio),
                        "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p", "-r", "30",
                        "-c:v", "libx264", "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(out_mp4)],
                       creationflags=_NO_WINDOW, timeout=300)
    except Exception as e:
        return jsonify({"error": "video mux failed: " + str(e)}), 502
    for p in (base_png, seg_audio):
        try: p.unlink()
        except OSError: pass
    shutil.rmtree(fdir, ignore_errors=True)
    if not out_mp4.exists() or out_mp4.stat().st_size == 0:
        return jsonify({"error": "video not produced"}), 502
    return jsonify({"ok": True, "url": f"cards/testimonial_{ts}.mp4"})


@app.route("/api/testimonial-cards/<project>/<cid>/align", methods=["POST"])
def api_tcard_align(project, cid):
    """Forced-align a card's CUSTOM voice-over (card.extra.vo) to its text → 0-based word timings stored
    on the card (card.extra.words + vo_dur). Lets the karaoke sync to a user-supplied voice without
    re-running the whole VSL SRT. Runs the same stable-ts aligner as the SRT job, on just this clip."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    card = next((c for c in doc.get("testimonial_cards", []) if c.get("id") == cid), None)
    if card is None:
        return jsonify({"error": "card not found"}), 404
    body = request.get_json(silent=True) or {}
    ex = card.get("extra") or {}
    # prefer the client-supplied vo/text (the voiceover endpoint doesn't persist them server-side yet, so the
    # saved doc may still be catching up) — fall back to whatever is on the card
    vo = (body.get("vo") or ex.get("vo") or "").strip()
    text = (body.get("text") or card.get("text") or "").strip()
    if not vo:
        return jsonify({"error": "no custom voice-over on this card"}), 400
    if not text:
        return jsonify({"error": "the testimonial has no text to align"}), 400
    d, safe = proj_dir(project)
    audio = (d / vo).resolve()
    try:
        audio.relative_to(d.resolve())
    except Exception:
        return jsonify({"error": "bad audio path"}), 400
    if not audio.exists():
        return jsonify({"error": "voice-over file not found"}), 400
    wd = d / "subtitle"; wd.mkdir(parents=True, exist_ok=True)
    tf = wd / f"clip_{cid}.txt"; tf.write_text(text, encoding="utf-8")
    of = wd / f"clip_{cid}.json"
    try:
        if of.exists():
            of.unlink()
    except OSError:
        pass
    script = BASE.parent / "subtitle" / "align_clip.py"
    if not script.exists():
        return jsonify({"error": "aligner not found"}), 500
    env = dict(os.environ, VSL_CLIP_AUDIO=str(audio), VSL_CLIP_TEXT=str(tf),
               VSL_CLIP_OUT=str(of), VSL_CLIP_MODEL="small.en")
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_c):
                exe = _c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    try:
        r = subprocess.run([exe, str(script)], env=env, cwd=str(wd), startupinfo=si, creationflags=cf,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=900)
    except Exception as e:
        return jsonify({"error": "alignment failed: " + str(e)}), 502
    if not of.exists():
        tail = (r.stdout.decode("utf-8", "replace")[-400:] if (r and r.stdout) else "")
        return jsonify({"error": "alignment produced no timings. " + tail}), 502
    try:
        words = json.loads(of.read_text(encoding="utf-8"))
    except Exception:
        return jsonify({"error": "could not read alignment output"}), 502
    dur = round(max([float(w.get("e", 0)) for w in words], default=0.0), 3)
    card.setdefault("extra", {})["words"] = words
    card["extra"]["vo_dur"] = dur
    save_doc(project, doc)
    try:
        tf.unlink(); of.unlink()
    except OSError:
        pass
    return jsonify({"ok": True, "words": words, "dur": dur, "count": len(words)})


@app.route("/api/testimonial-cards/<project>/<cid>/to-scene", methods=["POST"])
@_locked
def api_tcard_to_scene(project, cid):
    """Mirror a produced written-testimonial PNG into its linked VSL scene's image (Scenes & Images).
    The testimonial page is the source of truth; re-producing overwrites the scene's shown image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    card = next((c for c in doc.get("testimonial_cards", []) if c.get("id") == cid), None)
    if card is None:
        return jsonify({"error": "card not found"}), 404
    rel = (request.get_json(force=True) or {}).get("url") or ""
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    try:
        src.relative_to(d.resolve())            # keep the path inside the project
    except Exception:
        return jsonify({"error": "bad path"}), 400
    if not src.exists():
        return jsonify({"error": "rendered image not found"}), 400
    scene = next((s for s in doc.get("scenes", []) if s.get("tcard_id") == cid), None)
    if scene is None and card.get("sceneUid"):
        scene = next((s for s in doc.get("scenes", []) if s.get("uid") == card.get("sceneUid")), None)
    if scene is None:
        return jsonify({"error": "no VSL scene is linked to this testimonial"}), 400
    (d / "images").mkdir(parents=True, exist_ok=True)
    dest_rel = f"images/{scene['uid']}_tc_{int(time.time() * 1000)}.png"
    shutil.copyfile(src, d / dest_rel)
    img = scene.setdefault("image", {})
    vers = img.setdefault("versions", [])
    # SYNC in place: if this scene already shows a testimonial-sourced image ("_tc_" file), REPLACE that
    # version instead of piling up a new one — so editing the card (format/text) UPDATES the scene image
    # rather than adding a new version. Only the first produce appends.
    tc_idx = next((k for k, v in enumerate(vers) if "_tc_" in v), None)
    if tc_idx is not None:
        old_tc = vers[tc_idx]
        vers[tc_idx] = dest_rel
        idx = tc_idx
        if old_tc != dest_rel:
            try: (d / old_tc).unlink()
            except OSError: pass
    else:
        vers.append(dest_rel)
        idx = len(vers) - 1
    vm = img.setdefault("version_models", [])
    while len(vm) < len(vers):
        vm.append(scene.get("model") or IMAGE_MODEL)
    img["current"] = idx
    img["approved_version"] = idx
    img["status"] = "ready"
    img["taskId"] = None
    img["error"] = None
    scene["approved"] = True                     # the produced testimonial image is the final for this scene
    norm_scene(scene)                            # recompute file/approved_file
    save_doc(project, doc)
    return jsonify({"ok": True, "sceneId": scene["id"], "url": dest_rel})


@app.route("/api/testimonial-cards/<project>/save", methods=["POST"])
@_locked
def api_save_testimonial_cards(project):
    """Persist the written-testimonial card drafts (the whole list) for this project."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    cards = (request.get_json(force=True) or {}).get("cards")
    if not isinstance(cards, list):
        return jsonify({"error": "cards must be a list"}), 400
    clean = []
    for c in cards[:200]:
        if not isinstance(c, dict):
            continue
        clean.append({
            "id": str(c.get("id") or new_uid()),
            "type": str(c.get("type") or "written"),
            "format": str(c.get("format") or "facebook"),
            "charId": str(c.get("charId") or ""),
            "text": str(c.get("text") or "")[:5000],
            "extra": c.get("extra") if isinstance(c.get("extra"), dict) else {},
            "auto": bool(c.get("auto")),          # created automatically from a script testimonial line
            "sceneUid": str(c.get("sceneUid") or ""),   # the scene this card's image mirrors into
        })
    doc["testimonial_cards"] = clean
    save_doc(project, doc)
    return jsonify({"ok": True, "cards": clean})


# ---- routes: VIDEO testimonial (image with the person's face + environment, then voiceover) ----
def _tv_image_prompt(env):
    env = (env or "").strip()
    base = ("A candid AMATEUR selfie-style video still of the SAME single person shown in the reference photo, "
            "keeping their exact face and identity. They are filming THEMSELVES on a phone front camera "
            "(UGC talking-to-camera selfie), head-and-shoulders, looking into the lens with a warm natural "
            "expression. Casual slightly imperfect handheld framing, natural available lighting, a believable "
            "real person — not a model, not a studio shot, not stock. No text, no logos, no watermark.")
    if env:
        base += f" Setting / background: {env}."
    return base


@app.route("/api/testimonial-cards/<project>/<cid>/gen-image", methods=["POST"])
def api_tv_gen_image(project, cid):
    """Generate the video-testimonial IMAGE: the chosen character's face (i2i reference) placed in the
    described environment, selfie/UGC style, at the chosen dimension (horizontal / square / vertical)."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    char = next((c for c in doc.get("testimonials", []) if c.get("id") == (body.get("charId") or "")), None)
    if char is None:
        return jsonify({"error": "pick a character first"}), 400
    urls = char.get("urls") or []
    if not urls:
        return jsonify({"error": "this character has no photo yet — generate or upload one first"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    src = (d / urls[-1]).resolve()
    if not src.exists():
        return jsonify({"error": "character photo file is missing"}), 400
    base_url = cloudinary_upload(src, f"{safe}/tvface/{cid}")
    if not base_url:
        return jsonify({"error": "could not upload the face reference"}), 500
    aspect = {"horizontal": "16:9", "square": "1:1", "vertical": "9:16"}.get(body.get("dim"), "9:16")
    env = (body.get("env") or "").strip()
    if env and looks_turkish(env):
        try: env = translate_to_english(env)
        except Exception: pass
    for p in d.glob(f"refs/tvcand_{cid}_*"):   # fresh each time
        try: p.unlink()
        except Exception: pass
    rel, cerr = _run_char_candidate(d, cid, _tv_image_prompt(env), [base_url], prefix="tvcand", family="nano-banana-2", aspect=aspect)
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/voiceover", methods=["POST"])
def api_tv_voiceover(project, cid):
    """Generate an ElevenLabs voice-over for ONE video-testimonial card (saved per-card)."""
    err = _keys_ok(("eleven",))
    if err:
        return err
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    body = request.get_json(force=True) or {}
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": ELEVEN_KEY, "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL, "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": f"request failed: {e}"}), 502
    if r.status_code != 200:
        return jsonify({"error": f"ElevenLabs {r.status_code}"}), 502
    (d / "cards").mkdir(parents=True, exist_ok=True)
    rel = f"cards/vo_{cid}_{int(time.time() * 1000)}.mp3"
    (d / rel).write_bytes(r.content)
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/upload-audio", methods=["POST"])
def api_tv_upload_audio(project, cid):
    """Save a user-uploaded voice-over audio file for ONE video-testimonial card."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    (d / "cards").mkdir(parents=True, exist_ok=True)
    ext = os.path.splitext(f.filename)[1].lower() or ".mp3"
    rel = f"cards/vo_{cid}_up_{int(time.time() * 1000)}{ext}"
    f.save(d / rel)
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/gen-video", methods=["POST"])
def api_tv_gen_video(project, cid):
    """Lip-sync testimonial video via Kie 'infinitalk/from-audio': the approved image + the voiceover
    audio + a prompt → talking-head MP4. (Audio must be <= 15s per the model.)"""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    img_rel = (body.get("image") or "").strip()
    vo_rel = (body.get("vo") or "").strip()
    prompt = (body.get("prompt") or "").strip() or "A person speaking naturally to the camera in a casual selfie video."
    resolution = body.get("resolution") if body.get("resolution") in ("480p", "720p") else "720p"
    ip = (d / img_rel).resolve()
    ap = (d / vo_rel).resolve()
    if not (img_rel and str(ip).startswith(str(d.resolve())) and ip.exists()):
        return jsonify({"error": "approve an image first"}), 400
    if not (vo_rel and str(ap).startswith(str(d.resolve())) and ap.exists()):
        return jsonify({"error": "add a voiceover first"}), 400
    image_url = cloudinary_upload(ip, f"{safe}/tvvidimg/{cid}")
    if not image_url:
        return jsonify({"error": "could not upload the image"}), 500
    audio_url = cloudinary_upload_audio(ap, f"{safe}/tvvidaud/{cid}")
    if not audio_url:
        return jsonify({"error": "could not upload the voiceover"}), 500
    if looks_turkish(prompt):
        try: prompt = translate_to_english(prompt)
        except Exception: pass
    inp = {"image_url": image_url, "audio_url": audio_url, "prompt": prompt, "resolution": resolution}
    tid, cerr = kie_create("infinitalk/from-audio", inp)
    if not tid:
        return jsonify({"error": cerr or "could not start video generation"}), 502
    url = fail = None
    for _ in range(180):                       # poll up to ~6 minutes
        time.sleep(2)
        try:
            rec = kie_record(tid)
        except Exception:
            rec = {}
        st = (rec.get("data") or {}).get("state")
        if st == "success":
            url = result_url(rec); break
        if st == "fail":
            fail = (rec.get("data") or {}).get("failMsg", "generation failed"); break
    if fail:
        return jsonify({"error": fail}), 502
    if not url:
        return jsonify({"error": "video generation timed out"}), 504
    (d / "cards").mkdir(parents=True, exist_ok=True)
    rel = f"cards/tvvideo_{cid}_{int(time.time() * 1000)}.mp4"
    try:
        rr = requests.get(url, timeout=300); rr.raise_for_status()
        (d / rel).write_bytes(rr.content)
    except Exception as e:
        return jsonify({"error": f"download failed: {e}"}), 502
    return jsonify({"ok": True, "url": rel})

# ---- routes: image edit / versions / downloads -----------------------------
def _find_scene(doc, sid):
    return next((s for s in doc["scenes"] if s["id"] == sid), None)

@app.route("/api/scenes/<project>/<int:sid>/preview-prompt", methods=["GET"])
def api_preview_prompt(project, sid):
    """Dry-run: return the EXACT final image prompt this scene would send (+ a summary of the reference
    images that would attach), WITHOUT generating. Lets the user catch conflicts before spending a job."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    d, _safe = proj_dir(project)
    if not (s.get("prompt") or "").strip():
        return jsonify({"prompt": "", "info": ["This scene has no prompt yet — Generate or type one first."]})
    prompt, _cont_rel, info = assemble_image_prompt(s, doc, d)
    return jsonify({"prompt": prompt, "info": info, "raw": bool(s.get("no_cast"))})

@app.route("/api/scenes/<project>/<int:sid>/edit", methods=["POST"])
def api_edit_image(project, sid):
    """Edit the CURRENT version using it as the reference (image-to-image), keep history."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    instr = (request.get_json(force=True).get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    img = s["image"]
    vs, cur = img.get("versions", []), img.get("current", -1)
    if not vs or not (0 <= cur < len(vs)):
        return jsonify({"error": "generate an image first"}), 400
    d, safe = proj_dir(project)
    # Stable public_id per scene (no timestamp) so re-editing OVERWRITES the same Cloudinary asset
    # instead of piling up a new permanent one every edit. Signed uploads overwrite by default, and
    # Cloudinary returns a version-busted secure_url so Kie always fetches the fresh base — one
    # edit-base asset per scene, ever. (frames/ and refs/ were already stable-id, so only edits leaked.)
    base_url = cloudinary_upload(d / vs[cur], f"{safe}/edits/s{sid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    # Build an EDIT command, not a scene description. Do NOT prepend the big style preset here:
    # the base image already carries the style, and dumping ~150 words of "keep this exact look"
    # in front of a one-line instruction buries the edit — the model just reproduces the same
    # image. Make the change DOMINANT and forceful; over-preserving "the same subject" is what
    # blocks appearance edits (e.g. "make them thinner"), so we only protect the setting/style/faces
    # and explicitly ALLOW the subject's body/appearance to change to satisfy the instruction.
    # If the instruction is written in Turkish, translate ONLY the user's words to English first,
    # so the forceful English directives below reach the model verbatim. (Running the whole prompt
    # through the translator, as localize_prompt would, could soften the "apply it strongly" wording.)
    instr_en = instr
    if looks_turkish(instr):
        try:
            instr_en = translate_to_english(instr)
        except Exception:
            instr_en = instr
    # RAW edit: send ONLY the user's instruction to the image-to-image edit — nothing added, exactly what
    # they typed (translated to English if written in Turkish, since the model reads English best). The
    # current image is the base, so the model edits it directly.
    p = instr_en
    # Edit ALWAYS uses NanoBanana image-to-image. Feed ONLY the current image as the base — adding the
    # scene's cast reference photos here over-anchors each person's identity so hard that appearance
    # edits (body shape, etc.) can't take, making the result look identical. Prompt is already English.
    image_input = [base_url]
    model_id, inp = build_kie_image_request("nano-banana-2", p, image_input)
    tid, err = kie_create(model_id, inp)
    if tid:
        img.update(status="generating", taskId=tid, error=None, gen_started=time.time())
    else:
        img.update(status="error", error=err)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/current", methods=["POST"])
@_locked
def api_set_current(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    idx = request.get_json(force=True).get("index")
    vs = s["image"].get("versions", [])
    if isinstance(idx, int) and 0 <= idx < len(vs):
        s["image"]["current"] = idx
        save_doc(project, doc)
    return jsonify(s["image"])

@app.route("/api/scenes/<project>/sync-approved-current", methods=["POST"])
@_locked
def api_sync_approved_current(project):
    """On (re)opening a project, snap every APPROVED scene's shown version back to its APPROVED version —
    so flipping through versions and then leaving doesn't leave a non-approved frame showing next time.
    Persisted so a later poll can't snap it forward again."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    changed = False
    for s in doc.get("scenes", []):
        im = s.get("image") or {}
        av = im.get("approved_version")
        vers = im.get("versions") or []
        if s.get("approved") and isinstance(av, int) and 0 <= av < len(vers) and im.get("current") != av:
            im["current"] = av
            im["file"] = vers[av]
            changed = True
    if changed:
        save_doc(project, doc)
        doc = load_doc(project)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-image", methods=["POST"])
@_locked
def api_reset_image(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["image"] = {"status": "empty", "taskId": None, "error": None, "versions": [], "current": -1, "file": None}
    s["approved"] = False
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-image", methods=["POST"])
def api_cancel_image(project, sid):
    """Stop an in-progress (queued OR generating) image generation for ONE scene.
    Keeps any existing versions — we just abandon the new task so poll/queue ignore it.
    A Kie task already submitted keeps running on their side; we simply stop tracking it."""
    with _project_lock(project):     # same atomic load→modify→save as generate/poll so we don't race the 6s poll
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        img = s["image"]
        if img.get("status") in ("queued", "generating"):
            vs = img.get("versions", [])
            if vs:                                            # regen over an existing image → keep the old one
                cur = img.get("current", len(vs) - 1)
                cur = cur if 0 <= cur < len(vs) else len(vs) - 1
                img.update(status="ready", taskId=None, error=None, file=vs[cur])
            else:                                             # first-time generation → back to empty
                img.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-video", methods=["POST"])
def api_cancel_video(project, sid):
    """Stop an in-progress (queued OR generating) VIDEO generation for ONE scene. Keeps any existing
    video; we just abandon the new task so poll/queue ignore it (the Kie task, if already sent, keeps
    running on their side — we simply stop tracking it)."""
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        v = s.get("video") or {}
        if v.get("status") in ("queued", "generating"):
            if v.get("file"):                         # regen over an existing video → keep the old one
                v.update(status="ready", taskId=None, error=None)
            else:
                v.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)


@app.route("/api/scenes/<project>/<int:sid>/delete-version", methods=["POST"])
@_locked
def api_delete_version(project, sid):
    """Delete ONLY the shown image version (not all). The file is left on disk so Undo can restore it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    img = s["image"]
    vs = img.get("versions", [])
    idx = request.get_json(force=True).get("index", img.get("current", -1))
    if not (0 <= idx < len(vs)):
        return jsonify(doc)
    vs.pop(idx)
    vm = img.get("version_models")               # keep the per-version model list aligned
    if isinstance(vm, list) and 0 <= idx < len(vm):
        vm.pop(idx)
    av = img.get("approved_version")
    if isinstance(av, int):
        if av == idx:
            img["approved_version"] = None
            s["approved"] = False
        elif av > idx:
            img["approved_version"] = av - 1
    if not vs:
        s["image"] = {"status": "empty", "taskId": None, "error": None,
                      "versions": [], "current": -1, "file": None, "approved_version": None}
        s["approved"] = False
    else:
        img["versions"] = vs
        img["current"] = min(img.get("current", 0), len(vs) - 1)
    norm_scene(s)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/approve", methods=["POST"])
@_locked
def api_approve(project, sid):
    """Approve/unapprove the scene. On approve, LOCK the currently-shown version."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    body = request.get_json(force=True)
    approved = bool(body.get("approved"))
    s["approved"] = approved
    if approved:
        # optional explicit version to approve (from the lightbox) — set it as current too,
        # so approving is atomic and race-free regardless of pending setCurrent calls.
        ver = body.get("version")
        vs = s["image"].get("versions", [])
        if isinstance(ver, int) and 0 <= ver < len(vs):
            s["image"]["current"] = ver
        s["image"]["approved_version"] = s["image"].get("current", len(vs) - 1)
    norm_scene(s)   # recompute approved_file so the response is current
    if approved:
        _auto_anchor(doc, s)   # photo-less recurring character → adopt this frame as their face-lock for later scenes
        _learn_log("approved", project, doc, [s])   # passive: capture the vetted (vo → prompt + settings) pair
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-video", methods=["POST"])
@_locked
def api_reset_video(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"] = {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False}
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/video-approve", methods=["POST"])
@_locked
def api_video_approve(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"]["approved"] = bool(request.get_json(force=True).get("approved"))
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/zip-images")
def api_zip_images(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            if not s.get("approved"):
                continue
            f = s["image"].get("approved_file") or s["image"].get("file")
            if f and (d / f).exists():
                z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-images.zip")

@app.route("/api/scenes/<project>/zip-videos")
def api_zip_videos(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-videos.zip")

# ---- routes: media serving --------------------------------------------------
@app.route("/api/subtitle/<project>", methods=["GET"])
def api_subtitle_status(project):
    return jsonify(get_sub_status(project))

@app.route("/api/subtitle/<project>/cancel", methods=["POST"])
def api_subtitle_cancel(project):
    """Stop a running subtitle job: flag it, then kill the live aligner subprocess tree so it halts
    at once. run_subtitle_job sees the flag between passes and finishes as 'idle' (not error)."""
    _SUB_CANCEL.add(project)
    _kill_proc_tree(_SUB_PROCS.get(project))
    set_sub_status(project, status="idle", step="", error=None, srt=None)
    return jsonify({"ok": True})

def text_to_docx(text, path):
    """Wrap plain UI script text as a minimal .docx (one paragraph per non-empty line) so the
    aligner's docx reader consumes it through the exact same code path as an uploaded .docx."""
    import xml.sax.saxutils as sx
    paras = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{sx.escape(ln.strip())}</w:t></w:r></w:p>'
        for ln in text.splitlines() if ln.strip())
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           '<w:body>' + paras + '</w:body></w:document>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)

@app.route("/api/subtitle/<project>", methods=["POST"])
def api_subtitle_run(project):
    doc = load_doc(project)
    if not doc:
        return jsonify({"error": "unknown project"}), 404
    st = get_sub_status(project)
    if st.get("status") == "running":
        return jsonify({"error": "a subtitle job is already running"}), 409
    d, safe = proj_dir(project)
    def truthy(v): return str(v).lower() in ("1", "true", "on", "yes")
    use_gen_vo = truthy(request.form.get("use_generated_vo"))
    use_script = truthy(request.form.get("use_script"))
    trim = truthy(request.form.get("trim"))
    trim_mode = request.form.get("trim_mode") or "natural"
    trimmed_rel = None
    audio = request.files.get("audio")
    docx = request.files.get("docx")
    src_dir = d / "srt_src"            # PERSISTENT last-used source files (survive the wd wipe) so a re-run can reuse them
    # fresh workdir each run so stale alignment caches never leak into a new job
    wd = sub_dir(project)
    if wd.exists():
        shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True, exist_ok=True)
    docx_path = wd / "script.docx"

    audio_name = None   # what to remember + show in the UI for the voice-over source
    docx_name = None    # ... and for the script source

    # ---- audio source (accepts any common audio type; ffmpeg/whisper sniff by content) ----
    if use_gen_vo:
        gen = d / "voiceover" / "voiceover.mp3"
        if not gen.exists():
            return jsonify({"error": "no generated voice-over yet - generate it above first"}), 400
        audio_path = wd / "audio.mp3"
        shutil.copyfile(gen, audio_path)
        audio_name = "Generated voice-over"
    else:
        if audio and audio.filename:
            ext = (Path(audio.filename).suffix or ".mp3").lower()
            src_dir.mkdir(parents=True, exist_ok=True)
            for old in src_dir.glob("audio.*"):
                try: old.unlink()
                except OSError: pass
            src_audio = src_dir / ("audio" + ext)
            audio.save(str(src_audio))
            (src_dir / "audio_name.txt").write_text(audio.filename, encoding="utf-8")
            audio_name = audio.filename
        else:
            # no new file picked -> reuse the last uploaded voice-over if we still have it
            prev = sorted(src_dir.glob("audio.*")) if src_dir.exists() else []
            if not prev:
                return jsonify({"error": "a voice-over audio file is required"}), 400
            src_audio = prev[0]
            try: audio_name = (src_dir / "audio_name.txt").read_text(encoding="utf-8").strip() or src_audio.name
            except Exception: audio_name = src_audio.name
        audio_path = wd / ("audio" + src_audio.suffix.lower())
        shutil.copyfile(src_audio, audio_path)
        # trim silences on the uploaded audio, then align to the TRIMMED audio + offer it for download
        if trim:
            trimmed = wd / "voiceover_trimmed.mp3"
            if trim_silences(audio_path, trimmed, trim_mode):
                audio_path = trimmed
                trimmed_rel = f"subtitle/{trimmed.name}"

    # ---- script source (.docx or plain-text .txt) ----
    if use_script:
        script_text = (request.form.get("script_text") or "").strip()
        if not script_text:
            return jsonify({"error": "the script box on the left is empty"}), 400
        text_to_docx(script_text, docx_path)
    else:
        if docx and docx.filename:
            fn = docx.filename.lower()
            if fn.endswith(".txt"):
                text_to_docx(docx.read().decode("utf-8", "ignore"), docx_path)
            elif fn.endswith(".docx"):
                docx.save(str(docx_path))
            else:
                return jsonify({"error": "script must be a .docx or .txt file"}), 400
            src_dir.mkdir(parents=True, exist_ok=True)
            for old in src_dir.glob("script.*"):
                try: old.unlink()
                except OSError: pass
            shutil.copyfile(docx_path, src_dir / ("script" + (Path(fn).suffix or ".docx")))
            (src_dir / "docx_name.txt").write_text(docx.filename, encoding="utf-8")
            docx_name = docx.filename
        else:
            # no new file picked -> reuse the last uploaded script if we still have it
            prev = sorted(src_dir.glob("script.*")) if src_dir.exists() else []
            if not prev:
                return jsonify({"error": "a script file (.docx or .txt) is required"}), 400
            src_docx = prev[0]
            if src_docx.suffix.lower() == ".txt":
                text_to_docx(src_docx.read_text(encoding="utf-8", errors="ignore"), docx_path)
            else:
                shutil.copyfile(src_docx, docx_path)
            try: docx_name = (src_dir / "docx_name.txt").read_text(encoding="utf-8").strip() or src_docx.name
            except Exception: docx_name = src_docx.name

    proj = fname_slug(doc.get("title") or project)
    date = today_ddmmyyyy()
    out_path = wd / f"{proj}_Subtitle_{date}.srt"
    trimmed_name = f"{proj}_Voiceover_Trimmed_{date}.mp3" if trimmed_rel else None
    set_sub_status(project, status="running", step="Starting…", srt=None,
                   trimmed=None, trimmed_name=trimmed_name, error=None,
                   audio_name=audio_name, docx_name=docx_name,
                   use_gen_vo=use_gen_vo, use_script=use_script)
    lang = audience_lang(doc.get("audience"))   # French/German/… audio → multilingual aligner + correct language
    threading.Thread(target=run_subtitle_job,
                     args=(project, audio_path, docx_path, out_path, trimmed_rel, lang), daemon=True).start()
    return jsonify({"status": "running"})

# ---- routes: voice-over (ElevenLabs) ---------------------------------------
DEFAULT_VOICES = [
    {"name": "Loretta Jophlin", "voice_id": "DiWaolzR7aFbwU2MJGyD"},
    {"name": "Daniel Sandrin", "voice_id": "EC7t0LPc9MtRU1r33xNj"},
]
def load_voices():
    if VOICES_PATH.exists():
        try:
            return json.loads(VOICES_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    VOICES_PATH.write_text(json.dumps(DEFAULT_VOICES, indent=2), encoding="utf-8")
    return list(DEFAULT_VOICES)

def save_voices(voices):
    VOICES_PATH.write_text(json.dumps(voices, indent=2, ensure_ascii=False), encoding="utf-8")

@app.route("/api/ost-presets", methods=["GET"])
def api_get_ost_presets():
    if OST_PRESETS_PATH.exists():
        try:
            return jsonify(json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8")))
        except Exception:
            return jsonify([])
    return jsonify([])

@app.route("/api/ost-presets", methods=["POST"])
def api_save_ost_presets():
    data = request.get_json(force=True)
    if not isinstance(data, list):
        return jsonify({"error": "expected a list"}), 400
    OST_PRESETS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"ok": True})

@app.route("/api/voices", methods=["GET"])
def api_voices():
    return jsonify(load_voices())

@app.route("/api/voices", methods=["POST"])
def api_voices_add():
    body = request.get_json(force=True)
    name = (body.get("name") or "").strip()
    vid = (body.get("voice_id") or "").strip()
    if not name or not vid:
        return jsonify({"error": "name and voice_id required"}), 400
    voices = load_voices()
    for v in voices:              # update if the name already exists
        if v.get("name", "").lower() == name.lower():
            v["voice_id"] = vid
            break
    else:
        voices.append({"name": name, "voice_id": vid})
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voices/<name>", methods=["DELETE"])
def api_voices_del(name):
    voices = [v for v in load_voices() if v.get("name", "").lower() != name.lower()]
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voiceover/<project>", methods=["POST"])
def api_voiceover(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    err = _keys_ok(("eleven",))
    if err:
        return err
    doc = load_doc(project)
    body = request.get_json(force=True)
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": ELEVEN_KEY, "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL,
                  "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": f"request failed: {e}"}), 502
    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("detail", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except Exception:
            msg = r.text[:300]
        return jsonify({"error": f"ElevenLabs {r.status_code}: {msg}"}), 502
    (d / "voiceover").mkdir(exist_ok=True)
    out = d / "voiceover" / "voiceover.mp3"
    # trim silences between sentences if requested (the saved voiceover.mp3 becomes the trimmed one,
    # so "use the voice-over generated above" in subtitles picks up the trimmed audio)
    if body.get("trim"):
        raw = d / "voiceover" / "voiceover_raw.mp3"
        raw.write_bytes(r.content)
        if not trim_silences(raw, out, body.get("trim_mode") or "natural"):
            out.write_bytes(r.content)   # fall back to untrimmed on ffmpeg failure
    else:
        out.write_bytes(r.content)
    proj = fname_slug((doc or {}).get("title") or project)
    spk = speaker_slug(voice_id)
    name = f"{proj}_{spk + '_' if spk else ''}Voiceover_{today_ddmmyyyy()}.mp3"
    return jsonify({"ok": True, "file": "voiceover/voiceover.mp3", "name": name})

# ---- routes: Premiere project export (FCP7 XML) ----------------------------
def _find_srt(d):
    """Locate the project's SRT: the one the subtitle job produced, else any *.srt."""
    sd = d / "subtitle"
    if not sd.exists():
        return None
    named = sorted(sd.glob("*_Subtitle_*.srt"))
    if named:
        return named[-1]
    any_srt = sorted(sd.glob("*.srt"))
    return any_srt[-1] if any_srt else None


def _find_vo_audio(d):
    """The audio the SRT was aligned to: prefer the trimmed take, then the subtitle-job
    audio, then the generated voice-over."""
    sd = d / "subtitle"
    cand = [sd / "voiceover_trimmed.mp3"]
    if sd.exists():
        cand += sorted(sd.glob("audio.*"))
    cand.append(d / "voiceover" / "voiceover.mp3")
    for p in cand:
        if p.exists():
            return p
    return None


def _normalized_vo(d):
    """The voice-over loudness-normalized to a consistent VSL level (cached in export/;
    rebuilt only when the source changes). Falls back to the raw VO if ffmpeg fails."""
    src = _find_vo_audio(d)
    if not src:
        return None
    dst = d / "export" / "voiceover_norm_mono.mp3"       # _mono suffix busts old stereo caches (VO is now mono)
    try:
        fresh = dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime
    except Exception:
        fresh = False
    if fresh:
        return dst
    return premiere_export.normalize_loudness(src, dst, mono=True) or src


def _build_premiere_xml_full(project, doc, d, srt_text, vo):
    """build_premiere_xml WITH custom testimonial voices spliced in (VO + karaoke clips + no zoom).
    Guarded + fail-safe: no custom voices / any error → the normal XML. Used by all three export paths."""
    words_override = None
    scene_video_override = None
    _tl = None
    try:
        _tl = _apply_custom_testimonial_vo(project, doc, _build_timeline(project, doc))
        sm = _tl.get("_tvo_segmap")
        if sm:
            cues = premiere_export.parse_srt(srt_text)
            for c in cues:
                c["start"], c["end"] = _seg_remap(sm, c["start"]), _seg_remap(sm, c["end"])
            srt_text = premiere_export.caps_to_srt(cues)
            wa = premiere_export.load_word_tsv(d / "subtitle") or []
            words_override = [(_seg_remap(sm, s), _seg_remap(sm, e), w) for (s, e, w) in wa]
            vo = _tl["vo"]
    except Exception:
        words_override = None
    try:
        if _tl is not None:
            _inject_testimonial_karaoke(project, doc, _tl, d / "export" / "_xml_kara")
            scene_video_override = {s["id"]: str(s["path"]) for s in _tl.get("scenes", [])
                                    if s.get("no_zoom") and s.get("kind") == "video" and s.get("path")}
    except Exception:
        scene_video_override = None
    xml, info = premiere_export.build_premiere_xml(
        doc.get("title") or project, d, doc, srt_text, vo, BGM_ROOT,
        claude_fn=_claude_text, music_segments=_export_music(project, doc, srt_text, vo),
        words_override=words_override, scene_video_override=scene_video_override)
    # extra media the XML now references (so the .zip can bundle them): the spliced VO + karaoke clips
    extra = []
    try:
        if _tl is not None and _tl.get("_tvo_segmap"):
            extra.append(str(_tl["vo"]))
        extra += [str(p) for p in (scene_video_override or {}).values()]
    except Exception:
        pass
    info["_tvo_media"] = [p for p in extra if p and Path(p).exists()]
    info["_tvo_vo"] = str(_tl["vo"]) if (_tl is not None and _tl.get("_tvo_segmap")) else None
    return xml, info


@app.route("/api/export-premiere/<project>", methods=["POST"])
def api_export_premiere(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt:
        return jsonify({"error": "No subtitle (.srt) found — generate subtitles first "
                                 "(the timeline is timed from the SRT)."}), 400
    if not _find_vo_audio(d):
        return jsonify({"error": "No voice-over audio found — generate or upload the voice-over first."}), 400
    vo = _normalized_vo(d)                     # loudness-normalized VO for a consistent VSL level
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = _build_premiere_xml_full(project, doc, d, _srt_text, vo)   # testimonials: custom voice + karaoke clips + no zoom (guarded)
    except Exception as e:
        return jsonify({"error": f"Export failed: {e}"}), 500
    out_name = f"{fname_slug(doc.get('title') or project)}_Premiere_{today_ddmmyyyy()}.xml"
    (d / "export").mkdir(parents=True, exist_ok=True)
    (d / "export" / out_name).write_text(xml, encoding="utf-8")
    info.pop("_tvo_media", None); info.pop("_tvo_vo", None)
    return jsonify({"ok": True, "file": f"export/{out_name}", "name": out_name, "info": info})


# ---- routes: named downloads (Export tab) ----------------------------------
def _vsl_name(doc, project, typ, ext):
    """Filename convention: <Project>_VSL_<Type>_<DDMMYYYY>.<ext>."""
    return f"{fname_slug(doc.get('title') or project)}_VSL_{typ}_{today_ddmmyyyy()}.{ext}"


def _used_bgm_paths(info):
    """Reconstruct the on-disk paths of the background-music tracks the export actually used."""
    out = []
    for m in (info or {}).get("music", []):
        if m.get("track"):
            p = BGM_ROOT / m["emotion"] / m["track"]
            if p.exists():
                out.append(p)
    return out


def _ost_words(text):
    """Unicode word list (keeps French accents + digits), lower-cased."""
    return re.findall(r"[^\W_]+", (text or "").lower(), re.UNICODE)


def _seq_find(hay, needle):
    """Start index of the word-sequence `needle` inside `hay` (both lists of normalized words), or -1."""
    if not needle or len(needle) > len(hay):
        return -1
    for i in range(len(hay) - len(needle) + 1):
        if hay[i:i + len(needle)] == needle:
            return i
    return -1


def _ost_aware_srt(project, doc, srt_text):
    """SPLIT each caption around any on-screen-text overlay: the words shown as on-screen text are removed, the
    caption plays UP TO the moment the overlay appears, then RESUMES after it. e.g. VO "baran ... très effrayant
    ... quelque chose", overlay "très effrayant" -> caption1 "baran ..." (ends before the overlay) / [overlay]
    / caption2 "quelque chose" (starts after it). A lone leftover word (e.g. "une" when the overlay is "vision
    plus claire" but the line is "une vision plus claire") is DROPPED so it doesn't flash for a fraction of a
    second. Falls back to the full SRT on any error."""
    try:
        tl = _build_timeline(project, doc)
    except Exception:
        return srt_text
    wins = []                                        # (ost_start, ost_end, [normalized words])
    for s in tl.get("scenes", []):
        dur = max(0.001, (s.get("end") or 0) - (s.get("start") or 0))
        for tx in (s.get("texts") or []):
            words = _ost_words(tx.get("text") or "")
            if not words:
                continue
            a = s["start"] + dur * float(tx.get("text_in", 0) or 0)
            b = s["start"] + dur * float(tx.get("text_out", 1) or 1)
            wins.append((a, b, words))
    if not wins:
        return srt_text
    try:
        cues = premiere_export.parse_srt(srt_text)
        out = []
        for c in cues:
            toks = (c["text"] or "").split()
            norm = [re.sub(r"[^\w]", "", t.lower(), flags=re.UNICODE) for t in toks]   # per-token normalized form
            cs, ce = c["start"], c["end"]
            # first on-screen-text window that overlaps this caption in TIME and whose words appear in it (in order)
            hit = None
            for (wa, wb, words) in wins:
                if ce <= wa or cs >= wb:
                    continue
                idx = _seq_find(norm, words)
                if idx >= 0:
                    hit = (wa, wb, idx, len(words)); break
            if hit is None:
                if (c["text"] or "").strip():
                    out.append({"start": cs, "end": ce, "text": c["text"]})
                continue
            wa, wb, idx, wl = hit
            before, after = toks[:idx], toks[idx + wl:]
            if len(before) > 1:                      # keep the run BEFORE the overlay (drop a lone orphan word)
                out.append({"start": cs, "end": max(cs + 0.2, wa - 0.03), "text": " ".join(before)})
            if len(after) > 1:                       # keep the run AFTER the overlay (drop a lone orphan word)
                out.append({"start": min(wb + 0.03, ce - 0.2), "end": ce, "text": " ".join(after)})
        out.sort(key=lambda x: x["start"])
        return premiere_export.caps_to_srt(out)
    except Exception:
        return srt_text


@app.route("/api/download/<project>/<kind>")
def api_download(project, kind):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    if kind == "subtitle":
        srt = _find_srt(d)
        if not srt:
            return jsonify({"error": "No subtitle (.srt) yet — generate it in the Script & Voiceover tab."}), 404
        # split at scene boundaries + frame-quantize so captions and clips switch together in Premiere
        q = _delivery_srt(d, doc, srt)
        if request.args.get("ost") == "strip":       # OST-aware version: don't repeat on-screen-text words
            q = _ost_aware_srt(project, doc, q)
        return send_file(io.BytesIO(q.encode("utf-8")), mimetype="application/x-subrip",
                         as_attachment=True, download_name=_vsl_name(doc, project, "Subtitle", "srt"))
    if kind == "voiceover":
        if not _find_vo_audio(d):
            return jsonify({"error": "No voice-over yet — generate it in the Script & Voiceover tab."}), 404
        vo = _normalized_vo(d)                  # deliver the level-normalized voice-over
        return send_file(vo, as_attachment=True, download_name=_vsl_name(doc, project, "Voiceover", "mp3"))
    if kind == "script":
        txt = (doc.get("script") or "").strip()
        if not txt:
            return jsonify({"error": "No script yet — paste it in the Script & Voiceover tab."}), 404
        (d / "export").mkdir(parents=True, exist_ok=True)
        p = d / "export" / "_script.docx"
        text_to_docx(txt, p)
        return send_file(p, as_attachment=True, download_name=_vsl_name(doc, project, "Script", "docx"))
    if kind == "premiere":
        srt = _find_srt(d)
        if not srt or not _find_vo_audio(d):
            return jsonify({"error": "Need a subtitle (.srt) and a voice-over first."}), 400
        vo = _normalized_vo(d)
        try:
            _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
            xml, _info = _build_premiere_xml_full(project, doc, d, _srt_text, vo)   # testimonials: custom voice + karaoke clips + no zoom
        except Exception as e:
            return jsonify({"error": f"Assembly failed: {e}"}), 500
        out_name = _vsl_name(doc, project, "Premiere_Project", "xml")
        (d / "export").mkdir(parents=True, exist_ok=True)
        (d / "export" / out_name).write_text(xml, encoding="utf-8")
        return send_file(d / "export" / out_name, as_attachment=True, download_name=out_name)
    if kind in ("images", "videos"):
        # skip phantom scenes (manual lines not in the voice-over) when an SRT exists to detect them
        srtp = _find_srt(d)
        phantom = premiere_export.excluded_scene_ids(
            doc["scenes"], premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))) if srtp else set()
        buf = io.BytesIO()
        n = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for s in doc["scenes"]:
                if s.get("id") in phantom:
                    continue
                if kind == "images":
                    if not s.get("approved"):
                        continue
                    f = s["image"].get("approved_file") or s["image"].get("file")
                    if f and (d / f).exists():
                        z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png"); n += 1
                else:
                    v = s.get("video", {})
                    if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                        z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4"); n += 1
        if not n:
            return jsonify({"error": f"No approved {kind} to download."}), 404
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name=_vsl_name(doc, project, kind.capitalize(), "zip"))
    abort(404)


@app.route("/api/download/<project>/all")
def api_download_all(project):
    """One ZIP with the whole deliverable: Premiere .xml, SRT, voice-over, script .docx, each
    scene's approved video (or its approved image where no video), and the used music tracks."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt or not _find_vo_audio(d):
        return jsonify({"error": "Need at least a subtitle (.srt) and a voice-over first."}), 400
    vo = _normalized_vo(d)                      # level-normalized VO (same file the timeline uses)
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = _build_premiere_xml_full(project, doc, d, _srt_text, vo)   # testimonials: custom voice + karaoke clips + no zoom
    except Exception as e:
        return jsonify({"error": f"Assembly failed: {e}"}), 500
    # the XML may reference a SPLICED VO (custom testimonial voices) + karaoke clips — bundle THOSE so the zip is self-contained
    _tvo_vo = info.get("_tvo_vo")
    vo_zip = Path(_tvo_vo) if (_tvo_vo and Path(_tvo_vo).exists()) else vo
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(_vsl_name(doc, project, "Premiere_Project", "xml"), xml)
        # SRT split at scene boundaries + frame-quantized so captions/clips switch together in Premiere
        z.writestr(_vsl_name(doc, project, "Subtitle", "srt"), _delivery_srt(d, doc, srt))
        z.write(vo_zip, _vsl_name(doc, project, "Voiceover", vo_zip.suffix.lstrip(".") or "mp3"))
        for _p in (info.get("_tvo_media") or []):       # testimonial karaoke clips (+ the spliced VO is already the Voiceover above)
            _pp = Path(_p)
            if _pp.exists() and _pp != vo_zip:
                z.write(_pp, f"testimonials/{_pp.name}")
        txt = (doc.get("script") or "").strip()
        if txt:
            sp = d / "export" / "_script.docx"
            (d / "export").mkdir(parents=True, exist_ok=True)
            text_to_docx(txt, sp)
            z.write(sp, _vsl_name(doc, project, "Script", "docx"))
        # per scene: approved video, else approved image (only for approved scenes). Phantom scenes
        # (manual lines not in the voice-over) are skipped so the bundle matches the timeline.
        phantom = premiere_export.excluded_scene_ids(doc["scenes"],
                                                     premiere_export.parse_srt(srt.read_text(encoding="utf-8", errors="ignore")))
        dl_video = dl_image = 0
        for s in doc["scenes"]:
            if s.get("id") in phantom:
                continue
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
                dl_video += 1
            elif s.get("approved"):
                f = s["image"].get("approved_file") or s["image"].get("file")
                if f and (d / f).exists():
                    z.write(d / f, f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.png")
                    dl_image += 1
        for p in _used_bgm_paths(info):
            z.write(p, f"music/{p.name}")
    # counts of what was ACTUALLY put in the zip (video where approved, else approved image)
    info["dl_video"] = dl_video
    info["dl_image"] = dl_image
    info.pop("_tvo_media", None); info.pop("_tvo_vo", None)   # internal-only (don't leak paths into the response header)
    buf.seek(0)
    resp = send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=_vsl_name(doc, project, "All_Files", "zip"))
    resp.headers["X-Export-Info"] = _urlquote(json.dumps(info))   # content summary for the UI
    resp.headers["Access-Control-Expose-Headers"] = "X-Export-Info"
    return resp


@app.route("/media/<project>/<path:relpath>")
def api_media(project, relpath):
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not str(fp).startswith(str(d.resolve())) or not fp.exists():
        abort(404)
    dl = request.args.get("dl")
    if dl:  # force a download with a specific filename
        return send_file(fp, as_attachment=True, download_name=dl)
    return send_file(fp)


MEDIA_THUMB_MAX = 1000   # px on the long edge — 2x+ the on-screen scene-card size, so it looks pixel-identical

@app.route("/media-thumb/<project>/<path:relpath>")
def api_media_thumb(project, relpath):
    """A light, cached preview of a generated image for the Scenes cards ONLY. The full 2K PNG is kept
    untouched (export / download / video / lightbox all still use /media). Loading a ~90KB WebP instead
    of a 5-7MB PNG in dozens of cards is what keeps the tab smooth. Generated on first view, then cached;
    falls back to the original if PIL can't read it (so the card can never end up blank)."""
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not str(fp).startswith(str(d.resolve())) or not fp.exists():
        abort(404)
    tdir = d / ".thumbs" / "media"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(relpath.encode("utf-8")).hexdigest() + ".webp")
    if not thumb.exists() or thumb.stat().st_mtime < fp.stat().st_mtime:
        try:
            im = Image.open(fp).convert("RGB")
            im.thumbnail((MEDIA_THUMB_MAX, MEDIA_THUMB_MAX))
            im.save(thumb, "WEBP", quality=88, method=5)
        except Exception:
            return send_file(fp)   # unreadable → hand over the original (never a blank card)
    return send_file(thumb, mimetype="image/webp")


@app.route("/bgm/<path:relpath>")
def api_bgm(relpath):
    """Serve a background-music track (lives outside any project, under BGM_ROOT) for the preview."""
    fp = (BGM_ROOT / relpath).resolve()
    if not str(fp).startswith(str(BGM_ROOT.resolve())) or not fp.exists():
        abort(404)
    return send_file(fp)


def _delivery_srt(d, doc, srt_path):
    """The SRT we hand to the user: captions split at scene boundaries + frame-quantized (matches the
    exported clip cuts and the preview). Falls back to the plain quantized SRT on any problem."""
    srt_text = srt_path.read_text(encoding="utf-8", errors="ignore")
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return premiere_export.quantize_srt_to_frames(srt_text)
        vo = _find_vo_audio(d)
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        words = premiere_export.load_word_tsv(d / "subtitle")
        return premiere_export.delivery_srt(doc.get("scenes", []), cues, total, words)
    except Exception:
        return premiere_export.quantize_srt_to_frames(srt_text)


def _ensure_suno_lib():
    """Ensure the mood folders exist under BGM_ROOT. The music library is CURATED BY THE USER (they drop their
    own level-matched tracks into each mood folder) — so we ONLY create the folders if missing and NEVER copy
    anything in (no bundled seed, no generation). Touching the user's files would pollute their curation."""
    try:
        for mood in suno_music.MOOD_NAMES:
            (BGM_ROOT / mood).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def _suno_lib_tracks(mood):
    """Sorted audio files currently in a mood's Suno library folder (newest last)."""
    folder = BGM_ROOT / mood
    if not folder.exists():
        return []
    return sorted((p for p in folder.iterdir() if p.suffix.lower() in (".mp3", ".wav")),
                  key=lambda p: p.stat().st_mtime)


def _coalesce_sections(plan, min_sec=45.0):
    """Clean up the LLM's segmentation WITHOUT flattening genuine mood variety (the old version merged purely by
    duration to hit a fixed count, which ATE distinct short moods like a 40s reassurance or a 60s CTA and left
    the video sounding all-one-mood). Two safe passes only:
      1. Collapse ADJACENT SAME-MOOD sections into one block — no mood is lost, and _split_long_sections later
         re-splits an over-long block into different-track pieces so a long act still refreshes its music.
      2. Absorb any remaining too-SHORT section (< min_sec — a stray blip; the user dislikes 30-40s changes)
         into a neighbour, PREFERRING a same-mood neighbour, else the LONGER one (whose mood it adopts).
    No fixed target count: a distinct, long-enough mood is KEPT, never merged away just to reach a number."""
    plan = [dict(s) for s in plan]
    if len(plan) <= 1:
        return plan
    def _collapse(p):
        out = [dict(p[0])]
        for s in p[1:]:
            if s["emotion"] == out[-1]["emotion"]:
                out[-1]["end"] = s["end"]
            else:
                out.append(dict(s))
        return out
    plan = _collapse(plan)
    while len(plan) > 1:
        i = min(range(len(plan)), key=lambda k: plan[k]["end"] - plan[k]["start"])
        if (plan[i]["end"] - plan[i]["start"]) >= min_sec:
            break                                            # even the shortest section is long enough → done
        left = plan[i - 1] if i > 0 else None
        right = plan[i + 1] if i < len(plan) - 1 else None
        if left and left["emotion"] == plan[i]["emotion"]:          j = i - 1
        elif right and right["emotion"] == plan[i]["emotion"]:      j = i + 1
        elif left and right:
            j = i - 1 if (left["end"] - left["start"]) >= (right["end"] - right["start"]) else i + 1
        else:
            j = i - 1 if left else i + 1
        lo, hi = min(i, j), max(i, j)
        plan[lo] = {"start": plan[lo]["start"], "end": plan[hi]["end"],
                    "emotion": plan[j]["emotion"], "track": None}   # merged block adopts the neighbour's mood
        del plan[lo + 1:hi + 1]
        plan = _collapse(plan)
    return plan


def _split_long_sections(plan, max_sec=270, target_sec=240):
    """HARD guarantee (not left to the LLM): no music section runs longer than max_sec. An over-long section is
    split into equal ADJACENT same-mood pieces (~target_sec each); adjacent same-mood pieces then get DIFFERENT
    tracks (never-reuse), so a long act refreshes its music instead of one track droning for many minutes."""
    out = []
    for seg in plan:
        dur = (seg.get("end") or 0) - (seg.get("start") or 0)
        if dur <= max_sec:
            out.append(seg); continue
        n = max(2, int(round(dur / target_sec)))
        s0, s1 = seg["start"], seg["end"]
        for i in range(n):
            a = s0 + (s1 - s0) * i / n
            b = s1 if i == n - 1 else s0 + (s1 - s0) * (i + 1) / n
            out.append({"start": round(a, 3), "end": round(b, 3), "emotion": seg["emotion"], "track": None})
    return out


def _assign_section_tracks(plan):
    """Assign each section a library track for its mood, CYCLING through the mood's tracks so EVERY successive
    section of the same mood uses a DIFFERENT file — not just adjacent ones (so the same audio isn't reused
    across the video while other tracks sit unused). If a mood has more sections than tracks it wraps around
    (adjacent are still kept different). A section the user manually locked (dropdown / reroll) keeps its track."""
    idx = {}
    prev_mood, prev_track = None, None
    for seg in plan:
        mood = seg.get("emotion")
        libs = [p.name for p in _suno_lib_tracks(mood)]
        if seg.get("locked") and seg.get("track") in libs:      # respect a manual pick / reroll
            prev_mood, prev_track = mood, seg["track"]; continue
        if not libs:
            seg["track"] = None; prev_mood, prev_track = mood, None; continue
        i = idx.get(mood, 0)
        cur = libs[i % len(libs)]
        if mood == prev_mood and cur == prev_track and len(libs) > 1:   # never repeat the immediate neighbour
            i += 1; cur = libs[i % len(libs)]
        idx[mood] = i + 1
        seg["track"] = cur
        prev_mood, prev_track = mood, cur


def _emotion_tracks():
    """{MOOD: [track filenames]} across the 6 Suno mood folders (the override dropdown menu)."""
    _ensure_suno_lib()
    out = {}
    for mood in suno_music.MOOD_NAMES:
        out[mood] = [p.name for p in _suno_lib_tracks(mood)]
    return out


def _resolve_music(project, doc, cues, total, save=True):
    """Build-ready music segments honoring the SAVED plan + per-segment overrides. The plan (Claude
    emotion-segmentation over the SUNO 6-mood palette + a library track per section) is computed ONCE and
    cached in doc.music_plan. A section whose mood has NO library track yet gets path=None — the music
    generation job (api_music_generate) fills those in with Suno, then they're reused."""
    _ensure_suno_lib()
    moods = suno_music.MOOD_NAMES
    plan = doc.get("music_plan")
    valid = (isinstance(plan, list) and plan and abs((plan[-1].get("end") or 0) - total) < 4.0
             and doc.get("music_plan_v") == SUNO_PLAN_VERSION           # old-logic/Envato plan → re-segment
             and all((seg.get("emotion") in moods) for seg in plan))
    if not valid:
        segs = premiere_export.segment_emotions(cues, total, _claude_text, moods, humanize=suno_music.humanize)
        plan = [{"start": round(s["start"], 3), "end": round(s["end"], 3), "emotion": s["emotion"], "track": None}
                for s in segs]
        plan = _coalesce_sections(plan)                    # ~4–5 blocks by dominant mood (stops over-frequent changes)
        plan = _split_long_sections(plan)                  # HARD cap: no section over ~4 min (splits long acts)
    _assign_section_tracks(plan)                            # each section gets a DIFFERENT track (never reused)
    doc["music_plan"] = plan
    doc["music_plan_v"] = SUNO_PLAN_VERSION
    if save:
        save_doc(project, doc)
    cache_path = BGM_ROOT / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    out = []
    for seg in plan:
        emo, track = seg.get("emotion"), seg.get("track")
        # Use the library track EXACTLY as provided — the user curates + level-matches the pool themselves, so
        # no auto-processing (no leveller/limiter, no fade-trim); the files play as-is.
        path = (BGM_ROOT / emo / track) if (track and (BGM_ROOT / emo / track).exists()) else None
        lufs, tp = premiere_export.measure_lufs(path, cache) if path else (None, None)
        out.append({"start": seg["start"], "end": seg["end"], "emotion": emo, "path": path,
                    "src_dur": premiere_export.audio_duration(path) if path else None, "lufs": lufs, "tp": tp})
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception:
        pass
    # Push every music transition LATER by a fixed offset: the new track was entering slightly before the scene
    # it changes on. Shift the INTERNAL boundaries only (first start=0 and last end=total stay put); each
    # consumer (preview mix, Premiere XML, MP4 render) keeps its own crossfade SHAPE around the shifted boundary.
    if len(out) > 1:
        orig = [(s["start"], s["end"]) for s in out]
        for i in range(1, len(out)):
            nb = min(orig[i][0] + MUSIC_SHIFT_SEC, orig[i][1] - 0.5)   # never cross this section's own end
            out[i - 1]["end"] = nb
            out[i]["start"] = nb
    return out


# ---- Suno background-music generation jobs ---------------------------------
SUNO_JOBS = {}
_SUNO_JOB_LOCK = threading.Lock()


def _project_kie_key(d):
    """The Kie key for THIS project (its own keys.json), falling back to the active global key."""
    try:
        keys = json.loads((d / "keys.json").read_text(encoding="utf-8"))
        return (keys.get("KIE_API_KEY") or "").strip() or KIE_KEY
    except Exception:
        return KIE_KEY


def _suno_new_path(mood):
    return BGM_ROOT / mood / f"suno_{mood.lower()}_{int(time.time()*1000)}.mp3"


def _music_cues_total(d):
    srtp = _find_srt(d); vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
    return cues, total


@app.route("/api/music-generate/<project>", methods=["POST"])
def api_music_generate(project):
    """Resolve the music plan (segment the script into moods + assign a DISTINCT library track per section). There
    is NO generation anymore — the library is user-curated, so this only PLANS. `need` is always 0 (kept for the
    frontend's existing shape). Re-segment the whole plan first with ?resegment=1."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _ = proj_dir(project)
    if request.args.get("resegment") or (request.get_json(silent=True) or {}).get("resegment"):
        doc["music_plan"] = []
        save_doc(project, doc)
    try:
        cues, total = _music_cues_total(d)
        _resolve_music(project, doc, cues, total)            # segment + assign distinct library tracks
        plan = doc.get("music_plan") or []
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "music planning failed: " + str(e)}), 500
    reused = sum(1 for seg in plan if seg.get("track"))
    return jsonify({"job": None, "need": 0, "reused": reused, "segments": len(plan)})


@app.route("/api/music-cancel/<job>", methods=["POST"])
def api_music_cancel(job):
    with _SUNO_JOB_LOCK:
        if job in SUNO_JOBS:
            SUNO_JOBS[job]["cancel"] = True
    return jsonify({"ok": True})


@app.route("/api/music-job/<job>")
def api_music_job(job):
    with _SUNO_JOB_LOCK:
        st = SUNO_JOBS.get(job)
    if not st:
        return jsonify({"error": "no such job"}), 404
    return jsonify(st)


@app.route("/api/music-reroll/<project>", methods=["POST"])
def api_music_reroll(project):
    """Swap one section to a DIFFERENT library track of the same mood (no generation) — prefer one not used by any
    other section, else just a different one. Locks the pick. Returns the new track immediately (no job)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx = body.get("index")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    mood = plan[idx].get("emotion")
    cur = plan[idx].get("track")
    libs = [p.name for p in _suno_lib_tracks(mood)]
    if not libs:
        return jsonify({"error": f"No tracks in the '{mood}' folder yet."}), 400
    used = {s.get("track") for i, s in enumerate(plan) if i != idx and s.get("track")}
    choices = [t for t in libs if t != cur and t not in used] or [t for t in libs if t != cur] or libs
    pick = choices[0]
    plan[idx]["track"] = pick
    plan[idx]["locked"] = True                                # reroll = an explicit pick for this section
    save_doc(project, doc)
    path = BGM_ROOT / mood / pick
    url = ("/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()) if path.exists() else None
    lufs, tp = premiere_export.measure_lufs(path, {}) if path.exists() else (None, None)
    return jsonify({"job": None, "track": pick, "url": url,
                    "level": round(premiere_export.music_level(lufs, tp), 3), "options": libs})


def _export_music(project, doc, srt_text, vo):
    """The music segments (saved/overridable plan) for the Premiere export — same plan as the preview."""
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return None
        total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
        return _resolve_music(project, doc, cues, total)
    except Exception:
        return None


@app.route("/api/music-tracks")
def api_music_tracks(project=None):
    return jsonify(_emotion_tracks())


@app.route("/api/music-override/<project>", methods=["POST"])
def api_music_override(project):
    """Set a specific segment's track (index into doc.music_plan)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx, track = body.get("index"), body.get("track")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    emo = plan[idx].get("emotion")
    if track and not (BGM_ROOT / emo / track).exists():
        return jsonify({"error": "track not found in that mood folder"}), 400
    plan[idx]["track"] = track
    plan[idx]["locked"] = bool(track)                        # manual pick → don't let auto-assign overwrite it
    save_doc(project, doc)
    resp = {"ok": True, "url": None, "level": None}
    if track:
        path = BGM_ROOT / emo / track
        cache_path = BGM_ROOT / ".loudness_cache.json"
        try:
            cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
        except Exception:
            cache = {}
        lufs, tp = premiere_export.measure_lufs(path, cache)
        try:
            cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
        except Exception:
            pass
        resp["level"] = round(premiere_export.music_level(lufs, tp), 3)
        resp["url"] = "/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()
    return jsonify(resp)


@app.route("/api/music-resegment/<project>", methods=["POST"])
def api_music_resegment(project):
    """Forget the cached plan so the next build re-segments the music from scratch."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["music_plan"] = []
    save_doc(project, doc)
    return jsonify({"ok": True})


def _build_timeline(project, doc):
    """The single source of truth for 'the assembled VSL': each scene's media + audio-driven
    time range, the scene-split caption cues, the normalized voice-over, and the emotion-
    segmented music with per-segment levels. Uses the SAME timing/music logic as the Premiere
    export, so preview == rendered MP4 == exported timeline.

    Media are LOCAL PATHS here; api_preview maps them to /media URLs for the browser and
    render_video feeds them straight to ffmpeg. Raises ValueError if the inputs aren't ready.
    """
    d, _ = proj_dir(project)
    srtp = _find_srt(d)
    vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    vo_dur = premiere_export.audio_duration(vo) or 0.0
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # accurate spoken-word onsets for mid-cue scenes (same as the export uses)
    words = premiere_export.load_word_tsv(d / "subtitle")
    word_starts = premiere_export.word_scene_starts(scenes, words) if words else None
    ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
    cue_tok_times = premiere_export.accurate_cue_token_times(cues, words) if words else None

    # Snap every boundary to a whole video frame. Both scene starts and caption starts get the
    # SAME quantizer, so a scene and its caption switch on the exact same frame in the preview,
    # AND the rendered clip durations become integer frames (no ffmpeg cumulative-rounding drift).
    _FPS = premiere_export.FPS
    def qf(t):
        return round(round(t * _FPS) / _FPS, 5)   # 5 dp keeps the exact frame value (frame/60 repeats)

    out_scenes = []
    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc or t1 <= t0:
            continue
        vid = s.get("video") or {}
        img = s.get("image") or {}
        item = {"id": s.get("id"), "start": qf(t0), "end": qf(t1),
                "label": premiere_export.scene_label(s), "kind": "blank", "path": None, "img": None,
                # on-screen text overlays (burned onto the video, shown in preview + render)
                "texts": _scene_overlays(s),
                # overlay icons (X / arrow / pain-burst) — shown as a static preview of their XML placement
                "icons": (s.get("icons") or []) if s.get("style") != "2d" else [],
                "transition": s.get("transition") or "none"}   # how this scene hands off to the next
        # the approved still image (if any) — the smooth fallback for the "images only" toggle
        imgf = (img.get("approved_file") or img.get("file")) if s.get("approved") else None
        if imgf and (d / imgf).exists():
            item["img"] = d / imgf
        if vid.get("approved") and vid.get("status") == "ready" and vid.get("file") and (d / vid["file"]).exists():
            item.update(kind="video", path=d / vid["file"])
        elif item["img"]:
            item.update(kind="image", path=item["img"])
        out_scenes.append(item)

    # split captions at scene boundaries so a caption and its scene switch together
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    caps = premiere_export.split_captions_at_scenes(cues, scene_starts, cue_tok_times)
    # same frame-quantizer as the scenes → caption starts land on the exact scene-start frame
    captions = [{"start": qf(c["start"]), "end": qf(c["end"]), "text": c["text"]}
                for c in caps if qf(c["end"]) > qf(c["start"])]

    music = []
    tracks_by_emotion = _emotion_tracks()
    try:
        segs = _resolve_music(project, doc, cues, total)     # saved/overridable plan
    except Exception:
        segs = []
    for i, seg in enumerate(segs):
        p = seg.get("path")
        emo = seg["emotion"]
        music.append({"index": i, "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                      "emotion": emo, "track": (Path(p).name if p else None),
                      "path": Path(p) if p else None,
                      "level": round(premiere_export.music_level(seg.get("lufs"), seg.get("tp")), 3),
                      "options": tracks_by_emotion.get(emo, [])})

    return {"total": round(total, 3), "vo": vo, "dir": d,
            "scenes": out_scenes, "captions": captions, "music": music,
            "sub_style": doc.get("subtitle_style") or None}


@app.route("/api/preview/<project>")
def api_preview(project):
    """Manifest for the in-dashboard rough-cut player. The client plays it synced — no
    server-side render (that's /api/render, which consumes the same timeline)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    try:
        tl = _build_timeline(project, doc)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    try:
        tl = _apply_custom_testimonial_vo(project, doc, tl)   # preview plays the same spliced VO the render will
    except Exception:
        pass
    d = tl["dir"]

    # Remember that this project has a watchable preview, so re-opening it later can
    # restore the player without the user clicking Build Preview again. Re-read right before
    # writing so this GET can't clobber a concurrent scene edit (e.g. on-screen text just added)
    # that was saved between our load_doc above and here — only the flag is persisted.
    if not doc.get("preview_built"):
        fresh = load_doc(project) or doc
        fresh["preview_built"] = True
        save_doc(project, fresh)
        doc["preview_built"] = True

    def murl(p):
        return f"/media/{project}/{Path(p).relative_to(d).as_posix()}"

    out_scenes = []
    for s in tl["scenes"]:
        item = {"id": s["id"], "start": s["start"], "end": s["end"], "label": s["label"],
                "type": s["kind"],
                "url": murl(s["path"]) if s["path"] else None,
                "img": murl(s["img"]) if s["img"] else None}
        item["texts"] = s.get("texts") or []   # on-screen text overlays for this scene
        item["icons"] = s.get("icons") or []   # overlay icons (static preview of their XML placement)
        item["transition"] = s.get("transition") or "none"
        out_scenes.append(item)
    music = []
    for m in tl["music"]:
        e = {k: m[k] for k in ("index", "start", "end", "emotion", "track", "level", "options")}
        e["url"] = ("/bgm/" + m["path"].resolve().relative_to(BGM_ROOT.resolve()).as_posix()
                    ) if m["path"] else None
        music.append(e)

    return jsonify({"duration": tl["total"], "vo": murl(tl["vo"]),
                    "scenes": out_scenes, "captions": tl["captions"], "music": music,
                    "custom_vo": sorted(tl.get("_tvo_ids") or []),   # scenes whose VO was spliced to a custom clip → client karaoke uses the clip's words
                    "words": tl.get("words_remapped")})              # REMAPPED word times (present only after a splice) so client karaoke stays synced past the shift


@app.route("/api/words/<project>")
def api_words(project):
    """Word-level forced-alignment timings [{s,e,w}] cached by the subtitle aligner (words_*.tsv,
    each line 'start<TAB>end<TAB>word'). Powers the karaoke highlight in the testimonial cards and
    the Assemble preview. Returns {"words": []} if no alignment has been run yet."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _safe = proj_dir(project)
    sd = d / "subtitle"
    words = []
    if sd.exists():
        # prefer the medium-model VAD cache (the one the final SRT is built from), then any words_*.tsv
        cands = [sd / "words_medium_en_vad.tsv", sd / "words_medium_en.tsv"] + sorted(sd.glob("words_*.tsv"))
        wp = next((p for p in cands if p.exists()), None)
        if wp:
            try:
                for ln in wp.read_text(encoding="utf-8").splitlines():
                    if not ln.strip():
                        continue
                    parts = ln.split("\t", 2)
                    if len(parts) >= 3:
                        words.append({"s": float(parts[0]), "e": float(parts[1]), "w": parts[2]})
            except Exception:
                words = []
    return jsonify({"words": words})


# ---- routes: server-side MP4 render ----------------------------------------
RENDER_STATUS, RENDER_LOCK = {}, threading.Lock()
RENDER_PROCS = {}                 # project -> the running ffmpeg Popen (so a cancel can kill it)
RENDER_CANCEL = set()             # projects whose current render was cancelled by the user


def set_render_status(project, **kw):
    with RENDER_LOCK:
        st = RENDER_STATUS.get(project, {})
        st.update(kw); st["updated"] = time.time()
        RENDER_STATUS[project] = st
    return st


RENDER_HISTORY_KEEP = 8

def _archive_render(out_path, fast, doc, project, dur):
    """Keep a named copy of a finished render so it isn't lost when the next render overwrites
    render.mp4 / render_test.mp4. Real renders go to export/renders/, quick test renders to
    export/test-renders/. Filenames carry the project + date; test renders also carry their length in
    seconds (e.g. MyVSL_VSL_Test_26072026-143512_30s.mp4). Each folder is pruned to RENDER_HISTORY_KEEP."""
    try:
        export = Path(out_path).parent
        slug = fname_slug((doc or {}).get("title") or project)
        stamp, clock = today_ddmmyyyy(), time.strftime("%H%M%S")
        if fast:
            hist = export / "test-renders"
            fname = f"{slug}_VSL_Test_{stamp}-{clock}_{max(1, int(round(dur or 0)))}s.mp4"
        else:
            hist = export / "renders"
            fname = f"{slug}_VSL_Video_{stamp}-{clock}.mp4"
        hist.mkdir(exist_ok=True)
        shutil.copy2(out_path, hist / fname)
        files = sorted(hist.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[RENDER_HISTORY_KEEP:]:
            try:
                old.unlink()
            except OSError:
                pass
    except Exception:
        pass

def run_render_job(project, doc, out_path, name, opts):
    """Background thread: build the timeline, hand it to ffmpeg, track progress."""
    with RENDER_LOCK:
        RENDER_CANCEL.discard(project)          # fresh run — clear any stale cancel flag
    try:
        set_render_status(project, status="running", pct=0, step="Preparing timeline…", error=None)
        tl = _build_timeline(project, doc)
        try:
            tl = _apply_custom_testimonial_vo(project, doc, tl)   # splice any custom testimonial voice-overs into the VO + reflow times (guarded; no-op without custom voices)
        except Exception:
            pass
        try:
            set_render_status(project, step="Rendering testimonial karaoke…")
            _inject_testimonial_karaoke(project, doc, tl, out_path.parent / "_render_tmp")   # burn karaoke into written-testimonial scenes (guarded)
        except Exception:
            pass
        set_render_status(project, step="Rendering video…", duration=tl["total"])

        def on_progress(pct, done):
            set_render_status(project, pct=pct, step="Rendering video…")

        def on_status(text):
            set_render_status(project, step=text)

        def on_proc(p):
            with RENDER_LOCK:
                RENDER_PROCS[project] = p
                cancel_now = project in RENDER_CANCEL   # cancel arrived before ffmpeg started
            if cancel_now:
                try: p.terminate()
                except Exception: pass

        def should_cancel():
            with RENDER_LOCK:
                return project in RENDER_CANCEL

        render_video.render(tl, out_path, out_path.parent / "_render_tmp", opts,
                            on_progress, on_proc, on_status, should_cancel)
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL        # cancel that raced past the kill
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
            return
        size = out_path.stat().st_size
        _rng = opts.get("range")
        _rendered_dur = (_rng[1] - _rng[0]) if _rng else float(tl.get("total") or 0)
        _archive_render(out_path, bool(opts.get("fast")), doc, project, _rendered_dur)   # named copy in the render history
        set_render_status(project, status="done", pct=100, step="Done",
                          file=f"export/{out_path.name}", name=name, size=size,
                          subs=opts.get("burnsubs", True), fast=bool(opts.get("fast")), error=None)
    except Exception as e:
        # a cancel kills ffmpeg -> render() raises; report that as "cancelled", not an error
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()               # drop the half-written file
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
        else:
            set_render_status(project, status="error", error=str(e))
    finally:
        with RENDER_LOCK:
            RENDER_PROCS.pop(project, None)


@app.route("/api/render/<project>", methods=["POST"])
def api_render_start(project):
    """Kick off the MP4 render (captions burned in, voice-over + music mixed)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if get_render_status(project).get("status") == "running":
        return jsonify({"error": "A render is already running for this project."}), 409
    d, _ = proj_dir(project)
    try:
        _build_timeline(project, doc)          # fail fast with a clear message
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    body = request.get_json(silent=True) or {}
    fast = bool(body.get("fast"))          # quick low-res test render (720p30, ultrafast) to check sync/timing
    music = body.get("music", True) is not False
    opts = {"kenburns": bool(body.get("kenburns")),
            "music": music,
            "crossfade": music,          # cross-fade only matters when music is present
            "burnsubs": body.get("burnsubs", True) is not False,
            "onscreentext": body.get("onscreentext", True) is not False,
            "transitions": body.get("transitions", True) is not False,
            "gpu": bool(body.get("gpu")),                 # encode with the GPU (NVENC) if available
            "low_priority": bool(body.get("low_priority")),  # run ffmpeg below-normal + fewer threads
            "fast": fast}
    # optional partial render: only encode [range_start, range_end] seconds of the timeline
    try:
        rs, re_ = body.get("range_start"), body.get("range_end")
        if rs is not None and re_ is not None and float(re_) > float(rs):
            opts["range"] = (float(rs), float(re_))
    except (TypeError, ValueError):
        pass
    name = _vsl_name(doc, project, "Test-Video" if fast else "Video", "mp4")
    out = d / "export" / ("render_test.mp4" if fast else "render.mp4")
    set_render_status(project, status="running", pct=0, step="Queued…", file=None, error=None)
    threading.Thread(target=run_render_job, args=(project, doc, out, name, opts), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/renders/<project>")
def api_list_renders(project):
    """List the timestamped render-history files (newest first)."""
    d, _ = proj_dir(project)
    out = []
    for sub, is_test in (("renders", False), ("test-renders", True)):
        hist = d / "export" / sub
        if not hist.exists():
            continue
        for p in hist.glob("*.mp4"):
            st = p.stat()
            out.append({"name": p.name, "file": f"export/{sub}/{p.name}",
                        "size": st.st_size, "mtime": st.st_mtime, "test": is_test})
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return jsonify({"renders": out})

@app.route("/api/renders/<project>/<name>/delete", methods=["POST"])
def api_delete_render(project, name):
    """Delete one render-history file (guarded to the project's renders/ + test-renders/ folders)."""
    d, _ = proj_dir(project)
    for sub in ("renders", "test-renders"):
        hist = (d / "export" / sub).resolve()
        p = (hist / name).resolve()
        if p.suffix == ".mp4" and p.parent == hist and p.exists():
            try:
                p.unlink()
            except OSError:
                pass
            break
    return jsonify({"ok": True})

@app.route("/api/reveal/<project>", methods=["POST"])
def api_reveal(project):
    """Open the folder containing a render (in Explorer, file selected). Local desktop use — the server
    runs on the same machine as the window. Guarded to files under the project's export/ folder."""
    d, _ = proj_dir(project)
    rel = (request.get_json(silent=True) or {}).get("file") or ""
    p = (d / rel).resolve()
    ok = False
    try:
        if d.resolve() in p.parents and p.exists():
            subprocess.Popen(["explorer", "/select,", str(p)])   # explorer returns 1 even on success — don't check
            ok = True
    except Exception:
        pass
    return jsonify({"ok": ok})


@app.route("/api/render/<project>/cancel", methods=["POST"])
def api_render_cancel(project):
    """Stop an in-progress render: mark it cancelled and kill the ffmpeg process."""
    if get_render_status(project).get("status") != "running":
        return jsonify({"error": "No render is running for this project."}), 409
    with RENDER_LOCK:
        RENDER_CANCEL.add(project)
        proc = RENDER_PROCS.get(project)
    if proc and proc.poll() is None:
        try:
            proc.terminate()                     # ends ffmpeg -> the render thread finishes as "cancelled"
        except Exception:
            pass
    set_render_status(project, step="Cancelling…")
    return jsonify({"ok": True})


def get_render_status(project):
    with RENDER_LOCK:
        return dict(RENDER_STATUS.get(project) or {"status": "idle"})


@app.route("/api/render/<project>")
def api_render_status(project):
    return jsonify(get_render_status(project))

# ================= STUDIO: project-independent + per-project image workshop =================
# Scope: "_global" (used with NO project open) or a project name. Data is fully isolated per scope:
# global work never shows inside a project and vice-versa. Reuses the same Kie image pipeline as scenes.
STUDIO_JOBS = {}
_STUDIO_JLOCK = threading.Lock()

# varied product-mockup placements (each one is one generated image, i2i on the uploaded product)
MOCKUP_SETTINGS = [
    "arranged as a clean product line-up of several identical units in a neat row on a bright seamless studio backdrop, premium packaging shot",
    "held in a scientist's blue-gloved hand inside a clinical research laboratory, white coat and lab equipment softly blurred behind",
    "in a modern laboratory with the bottle open and supplement capsules being carefully placed inside it, gloved hands, clean clinical lighting",
    "held naturally in an ordinary woman's hand, close and clear, soft home background",
    "standing on a clean wooden kitchen table in soft natural daylight",
    "outdoors among green trees and lush foliage, dappled natural sunlight, fresh organic feel",
    "styled as a polished 3D-rendered social-media product post on a clean colourful gradient background, product floating with soft studio shadows and subtle highlights (absolutely NO text, NO captions, NO price and NO logos added)",
    "held naturally in a man's hand",
    "on a clean marble surface with soft premium studio lighting",
    "surrounded by fresh natural ingredients (citrus fruit and green leaves)",
    "held up to the camera by an ordinary person, casual UGC selfie style",
    "on a tidy bathroom shelf beside a glass of water",
    "resting on a gym bag with a towel, active-lifestyle feel",
    "on a cafe table beside a coffee cup",
    "on a sunny windowsill with small plants",
    "resting on an open, upturned palm",
    "in a supermarket shopping basket",
    "on a bedside table in warm morning light",
    "nestled in an opened cardboard delivery box with packaging",
    "on a small stack of books on a desk beside a green plant",
]

def _studio_scope_project(scope):
    return None if (not scope or scope == "_global") else scope

def _studio_dir(scope):
    project = _studio_scope_project(scope)
    if project:
        d, _ = proj_dir(project)
        base = d / "studio"
    else:
        base = PROJECTS.parent / "studio"       # the active user's global studio (sibling of projects/)
    (base / "refs").mkdir(parents=True, exist_ok=True)
    return base

def _studio_items(scope):
    p = _studio_dir(scope) / "studio.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8")).get("items", [])
        except Exception:
            pass
    return []

def _studio_write(scope, items):
    (_studio_dir(scope) / "studio.json").write_text(json.dumps({"items": items}, ensure_ascii=False), encoding="utf-8")

def _studio_pub(base, rel):
    """Upload a local studio ref to Cloudinary -> public URL for i2i. None on failure."""
    try:
        fp = (base / rel).resolve()
        if not str(fp).startswith(str(base.resolve())) or not fp.exists():
            return None
        return cloudinary_upload(fp, f"studio/{fp.stem}")
    except Exception:
        return None

def _studio_worker(job_id, scope, tasks):
    base = _studio_dir(scope)
    job = STUDIO_JOBS[job_id]
    for t in tasks:
        if job.get("cancel"):
            break
        try:
            refs = []
            for rel in (t.get("inputs") or []):
                u = _studio_pub(base, rel)
                if u:
                    refs.append(u)
            rel, err = _run_char_candidate(base, job_id[3:11], t["prompt"], refs, prefix="studio",
                                           family=t.get("model") or IMAGE_MODEL, aspect=t.get("aspect", "16:9"),
                                           resolution=t.get("resolution", "2K"),
                                           cancel_check=lambda: job.get("cancel"))
        except Exception as e:
            rel, err = None, str(e)
        with _STUDIO_JLOCK:
            if rel:
                item = {"id": hashlib.md5(rel.encode()).hexdigest()[:10], "kind": t.get("kind", "gen"),
                        "prompt": (t.get("label") or t["prompt"])[:400], "file": rel,
                        "aspect": t.get("aspect", "16:9"), "ts": time.time()}
                if t.get("kind") != "mockup":       # mockups are CANDIDATES -> only reach the gallery when the user approves one
                    items = _studio_items(scope); items.insert(0, item); _studio_write(scope, items)
                job["items"].append(item)
            else:
                job["errors"].append(err or "failed")
            job["done"] += 1
    with _STUDIO_JLOCK:
        job["status"] = "cancelled" if job.get("cancel") else "done"

def _studio_start(scope, tasks, kind):
    job_id = "sj_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    STUDIO_JOBS[job_id] = {"status": "running", "total": len(tasks), "done": 0, "items": [], "errors": [], "kind": kind, "ts": time.time()}
    threading.Thread(target=_studio_worker, args=(job_id, scope, tasks), daemon=True).start()
    return job_id

def _studio_video_worker(job_id, scope, task):
    base = _studio_dir(scope); job = STUDIO_JOBS[job_id]
    try:
        if job.get("cancel"):
            raise RuntimeError("cancelled")
        img_url = _studio_pub(base, task["input"])
        if not img_url:
            raise RuntimeError("input image upload failed (check Cloudinary keys / quota)")
        api, mid, payload = build_video_request(task["model"], img_url, task.get("prompt", ""),
                                                task["duration"], task["resolution"])
        tid, cerr = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
        if not tid:
            raise RuntimeError(cerr or "could not start the video")
        url = None
        for _ in range(210):                     # poll up to ~7 minutes
            if job.get("cancel"):
                raise RuntimeError("cancelled")
            time.sleep(2)
            try:
                rec = kie_veo_record(tid) if api == "veo" else kie_record(tid)
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec); break
            if state == "fail":
                raise RuntimeError((rec.get("data") or {}).get("failMsg", "video generation failed"))
        if not url:
            raise RuntimeError("video generation timed out")
        (base / "refs").mkdir(parents=True, exist_ok=True)
        fname = f"studio_vid_{job_id[3:11]}_{int(time.time() * 1000)}.mp4"
        download_as_mp4(url, base / "refs" / fname)
        rel = f"refs/{fname}"
        with _STUDIO_JLOCK:
            item = {"id": hashlib.md5(rel.encode()).hexdigest()[:10], "kind": "video",
                    "prompt": task.get("label") or "Image to Video", "file": rel,
                    "aspect": "16:9", "ts": time.time()}
            items = _studio_items(scope); items.insert(0, item); _studio_write(scope, items)
            job["items"].append(item); job["done"] = 1; job["status"] = "done"
    except Exception as e:
        with _STUDIO_JLOCK:
            job["done"] = 1
            if str(e) == "cancelled":
                job["status"] = "cancelled"
            else:
                job["errors"].append(str(e)); job["status"] = "done"

def _studio_start_video(scope, task):
    job_id = "sj_" + hashlib.md5(f"{scope}v{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    STUDIO_JOBS[job_id] = {"status": "running", "total": 1, "done": 0, "items": [], "errors": [], "kind": "video", "ts": time.time()}
    threading.Thread(target=_studio_video_worker, args=(job_id, scope, task), daemon=True).start()
    return job_id

def _studio_safe(name):
    return re.sub(r"[^A-Za-z0-9._-]", "_", (name or "img"))[:48]

@app.route("/api/studio/upload/<scope>", methods=["POST"])
def api_studio_upload(scope):
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "no file"}), 400
    base = _studio_dir(scope)
    ext = (Path(f.filename).suffix or ".png").lower()
    fname = f"in_{int(time.time() * 1000)}_{_studio_safe(Path(f.filename).stem)}{ext}"
    f.save(base / "refs" / fname)
    return jsonify({"ref": f"refs/{fname}"})

@app.route("/api/studio/generate", methods=["POST"])
def api_studio_generate():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    prompt = (b.get("prompt") or "").strip()
    inputs = [r for r in (b.get("inputs") or []) if r]
    if not prompt and not inputs:
        return jsonify({"error": "write a prompt or add an image"}), 400
    need = ("kie", "cloud") if inputs else ("kie",)
    err = _keys_ok(need)
    if err:
        return err
    aspect = b.get("aspect") or "16:9"
    resolution = "4K" if b.get("quality") == "4K" else "2K"
    mode = b.get("mode") or ("i2i" if inputs else "text")
    model = b.get("model") if b.get("model") in IMAGE_MODEL_KEYS else IMAGE_MODEL
    if mode == "edit":
        model = "nano-banana-2"                          # edit = NanoBanana edit (cheap, ref-based)
    n = max(1, min(int(b.get("count") or 1), 8))         # optional N variations of the same prompt
    p = prompt or "Recreate and refine the attached reference image faithfully."
    if inputs:
        p += ("\nUse the attached reference image(s) faithfully: combine / place / edit them exactly as described, "
              "keeping the objects, screens, labels and text they show accurate.")
    tasks = [{"prompt": p, "label": prompt or "(from image)", "inputs": inputs, "aspect": aspect,
              "model": model, "resolution": resolution, "kind": "gen"} for _ in range(n)]
    return jsonify({"job": _studio_start(scope, tasks, "gen")})

@app.route("/api/studio/mockup", methods=["POST"])
def api_studio_mockup():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    product = (b.get("product") or "").strip()
    if not product:
        return jsonify({"error": "upload a product image first"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    count = max(1, min(int(b.get("count") or 5), 20))
    aspect = b.get("aspect") or "1:1"
    resolution = "4K" if b.get("quality") == "4K" else "2K"
    model = b.get("model") if b.get("model") in IMAGE_MODEL_KEYS else IMAGE_MODEL
    tasks = []
    for i in range(count):
        setting = MOCKUP_SETTINGS[i % len(MOCKUP_SETTINGS)]
        p = (f"A realistic product photo of the EXACT product shown in the attached reference image, {setting}. "
             "Reproduce the product's label, wording, colours, shape and number of units EXACTLY as in the reference "
             "(do NOT redesign, rename or restyle it). Natural real-world lighting and a believable size; a clean, "
             "appealing, authentic photo. No added text, captions or watermarks.")
        tasks.append({"prompt": p, "label": f"Mockup: {setting}", "inputs": [product], "aspect": aspect,
                      "model": model, "resolution": resolution, "kind": "mockup"})
    return jsonify({"job": _studio_start(scope, tasks, "mockup")})

@app.route("/api/studio/edit", methods=["POST"])
def api_studio_edit():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    ref = (b.get("ref") or "").strip()
    instr = (b.get("instruction") or "").strip()
    if not ref or not instr:
        return jsonify({"error": "need an image and an instruction"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    if looks_turkish(instr):
        try: instr = translate_to_english(instr)
        except Exception: pass
    aspect = b.get("aspect") or "16:9"
    tasks = [{"prompt": instr, "label": instr[:120], "inputs": [ref], "aspect": aspect, "kind": "edit"}]
    return jsonify({"job": _studio_start(scope, tasks, "edit")})

@app.route("/api/studio/video", methods=["POST"])
def api_studio_video():
    """Image to Video — turn one uploaded image into a short clip (Seedance / Veo / Grok)."""
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    inp = (b.get("input") or "").strip()
    if not inp:
        return jsonify({"error": "upload an image first"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    mkey = b.get("model") if b.get("model") in VIDEO_MODEL_BY_KEY else DEFAULT_VIDEO_MODEL
    cfg = VIDEO_MODEL_BY_KEY[mkey]
    try:
        dur = int(b.get("duration"))
    except Exception:
        dur = cfg["defaultDur"]
    res = b.get("quality") or cfg["defaultRes"]
    prompt = (b.get("prompt") or "").strip()
    task = {"input": inp, "prompt": prompt, "label": prompt[:120] or "Image to Video",
            "model": mkey, "duration": dur, "resolution": res}
    return jsonify({"job": _studio_start_video(scope, task)})

@app.route("/api/studio/job/<jid>")
def api_studio_job(jid):
    j = STUDIO_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _STUDIO_JLOCK:
        return jsonify({"status": j["status"], "total": j["total"], "done": j["done"],
                        "items": list(j["items"]), "errors": list(j["errors"]), "kind": j["kind"]})

@app.route("/api/studio/cancel/<jid>", methods=["POST"])
def api_studio_cancel(jid):
    """Stop a running Studio job — the worker breaks out of its loop before the next candidate."""
    j = STUDIO_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _STUDIO_JLOCK:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/studio/save/<scope>", methods=["POST"])
def api_studio_save(scope):
    """Approve a candidate (e.g. a mockup) into the gallery — insert it at the front of the index."""
    item = (request.get_json(force=True) or {}).get("item")
    if not isinstance(item, dict) or not item.get("id") or not item.get("file"):
        return jsonify({"error": "bad item"}), 400
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        if not any(it.get("id") == item["id"] for it in items):
            items.insert(0, item); _studio_write(scope, items)
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/gallery/<scope>")
def api_studio_gallery(scope):
    return jsonify({"items": _studio_items(scope)})

@app.route("/api/studio/fav/<scope>", methods=["POST"])
def api_studio_fav(scope):
    """Toggle a gallery item's favourite (Approve = ★) flag; persisted in the index."""
    b = request.get_json(force=True) or {}
    iid = b.get("id"); fav = bool(b.get("fav"))
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        hit = next((it for it in items if it.get("id") == iid), None)
        if not hit:
            return jsonify({"error": "not found"}), 404
        hit["fav"] = fav
        _studio_write(scope, items)
    return jsonify({"ok": True, "fav": fav})

@app.route("/api/studio/delete/<scope>", methods=["POST"])
def api_studio_delete(scope):
    # Remove only from the index — KEEP the file on disk so an Undo can restore it (see /api/studio/restore).
    sid = (request.get_json(force=True) or {}).get("id")
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        _studio_write(scope, [it for it in items if it.get("id") != sid])
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/restore/<scope>", methods=["POST"])
def api_studio_restore(scope):
    """Undo a gallery delete: re-insert a previously-removed item at a given position (its file was kept)."""
    b = request.get_json(force=True) or {}
    item = b.get("item"); at = b.get("at")
    if not isinstance(item, dict) or not item.get("id"):
        return jsonify({"error": "bad item"}), 400
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        if not any(it.get("id") == item["id"] for it in items):   # avoid a dup if it's somehow still there
            idx = at if isinstance(at, int) and 0 <= at <= len(items) else 0
            items.insert(idx, item)
            _studio_write(scope, items)
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/to-scene/<project>", methods=["POST"])
def api_studio_scene_push(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    b = request.get_json(force=True) or {}
    ref = (b.get("ref") or "").strip()           # a studio file rel path, in THIS project's studio
    sid = b.get("sceneId")
    scene = next((s for s in doc.get("scenes", []) if s.get("id") == sid), None)
    if scene is None:
        return jsonify({"error": "scene not found"}), 404
    d, _ = proj_dir(project)
    src = (d / "studio" / ref).resolve()
    if not str(src).startswith(str((d / "studio").resolve())) or not src.exists():
        return jsonify({"error": "image not found"}), 400
    (d / "images").mkdir(parents=True, exist_ok=True)
    dest_rel = f"images/sc_{scene['uid']}_studio{int(time.time()*1000)}.png"
    shutil.copyfile(src, d / dest_rel)
    img = scene.setdefault("image", {})
    vers = img.setdefault("versions", [])
    vers.append(dest_rel)
    img.setdefault("version_models", []).append(scene.get("model") or IMAGE_MODEL)
    img["current"] = len(vers) - 1
    norm_scene(scene)
    save_doc(project, doc)
    return jsonify({"ok": True, "sceneId": scene["id"], "url": dest_rel})

@app.route("/api/studio/to-new-scene", methods=["POST"])
def api_studio_to_new_scene():
    """Append a NEW blank scene (empty vo/prompt) to ANY target project, with its image set to a studio
    image. Source comes from the current studio SCOPE; destination is the chosen project."""
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    ref = (b.get("ref") or "").strip()
    project = (b.get("project") or "").strip()
    if not project:
        return jsonify({"error": "no project chosen"}), 400
    base = _studio_dir(scope)
    src = (base / ref).resolve()
    if not str(src).startswith(str(base.resolve())) or not src.exists():
        return jsonify({"error": "image not found"}), 400
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            return jsonify({"error": "project not found"}), 404
        scenes = doc.setdefault("scenes", [])
        sc = new_scene(len(scenes) + 1)
        d, _ = proj_dir(project)
        (d / "images").mkdir(parents=True, exist_ok=True)
        dest_rel = f"images/sc_{sc['uid']}_studio{int(time.time() * 1000)}.png"
        shutil.copyfile(src, d / dest_rel)
        img = sc.setdefault("image", {})
        img["versions"] = [dest_rel]
        img["version_models"] = [sc.get("model") or IMAGE_MODEL]
        img["current"] = 0
        img["status"] = "ready"
        scenes.append(sc)
        for i, s in enumerate(scenes, 1):
            s["id"] = i
        norm_scene(sc)
        save_doc(project, doc)
        return jsonify({"ok": True, "sceneId": len(scenes), "title": doc.get("title") or project})

# -------- FAQ: white-bg, centred, VO-synced captions with red keywords (Studio-scoped) --------
FAQ_JOBS = {}
FAQ_RENDER_JOBS = {}
_FAQ_LOCK = threading.Lock()

def _probe_dur(path):
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                              "-of", "default=nw=1:nk=1", str(path)],
                             capture_output=True, text=True, creationflags=_NO_WINDOW, timeout=30).stdout.strip()
        return float(out)
    except Exception:
        return 0.0

def _faq_word_core(seg):
    """The click-key for a token: lowercased, edge punctuation stripped (keep % $ £ € and internal - so
    'non-GMO'/'180-day'/'100%' stay one unit). Mirrors the client faqWordCore EXACTLY."""
    s = (seg or "").lower()
    s = re.sub(r"^[^a-z0-9%$£€]+", "", s)
    s = re.sub(r"[^a-z0-9%$£€]+$", "", s)
    return s

def _faq_highlight(text, kws, reds=None, blacks=None):
    """Server mirror of the client faqHighlight — WORD-LEVEL so it honours the user's manual clicks:
    a word is red if it's a manual red, or covered by an auto keyword phrase and NOT a manual black.
    Wraps red words in <span class='faq-kw'>. `reds`/`blacks` are lowercased word cores."""
    import html as _h
    text = text or ""
    reds = set(reds or []); blacks = set(blacks or [])
    ks = sorted([str(k) for k in (kws or []) if k and str(k).strip()], key=lambda s: -len(s))
    cover = [False] * len(text)
    for k in ks:   # mark each keyword INDEPENDENTLY so overlapping phrases (e.g. "96,400 men and women"
        for m in re.finditer(re.escape(k), text, flags=re.I):   # vs "over 96,400 men") both fully colour
            for i in range(m.start(), m.end()):
                cover[i] = True
    out = []
    for m in re.finditer(r"\s+|\S+", text):
        seg = m.group(0)
        if not seg.strip():
            out.append(_h.escape(seg)); continue
        c = _faq_word_core(seg)
        if not c:
            red = False
        elif c in blacks:
            red = False
        elif c in reds:
            red = True
        else:
            red = any(cover[i] for i in range(m.start(), m.end()))
        out.append(('<span class="faq-kw">' + _h.escape(seg) + "</span>") if red else _h.escape(seg))
    return "".join(out)

_FAQ_NUTRIENTS = [
    "vitamin a", "vitamin b", "vitamin b3", "vitamin b6", "vitamin b12", "vitamin c", "vitamin d", "vitamin d3",
    "vitamin e", "vitamin k", "magnesium", "zinc", "calcium", "iron", "potassium", "selenium", "chromium", "iodine",
    "copper", "manganese", "phosphorus", "omega-3", "omega 3", "folate", "folic acid", "biotin", "collagen",
    "probiotics", "prebiotics", "caffeine", "l-carnitine", "green tea extract", "green tea", "cayenne", "capsaicin",
    "garcinia", "garcinia cambogia", "glucomannan", "chromium picolinate", "ashwagandha", "berberine", "resveratrol",
    "coenzyme q10", "coq10", "turmeric", "curcumin", "guarana", "chlorogenic acid", "ketones", "electrolytes",
]
_FAQ_KW_PATTERNS = [
    r"[£$€]\s?\d[\d.,]*",                                              # money / prices
    r"\b\d+%(?:\s+[a-z]+){0,2}",                                       # 100% natural formula (up to 2 following words)
    r"\brisk[- ]free\b",
    r"\b(?:money[- ]back|satisfaction|lifetime|100%\s+satisfaction)\s+guarantee\b",
    r"\b\d+[- ]day(?:\s+money[- ]back\s+guarantee)?\b",
    r"\b\d+[- ]day supply\b",
    r"\bcompletely free\b", r"\bfree shipping\b", r"\bfree delivery\b",
    # packs / supply — ANY unit (bottle / month / day / week), any count word
    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve)[- ](?:bottle|month|day|week)\s+(?:pack|packs|package|packages|supply|bundle)\b",
    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve)[- ](?:bottle|month|day|week)\b",
    # certifications / dietary claims
    r"\bISO\s?\d{3,}\b", r"\bEcocert(?:\s+standards)?\b", r"\bGMP(?:[- ]certified)?\b", r"\bFDA[- ]approved\b",
    r"\bnon[- ]?GMO\b", r"\bplant[- ]based\b", r"\bdairy[- ]free\b", r"\bgluten[- ]free\b", r"\bsugar[- ]free\b",
    r"\bsoy[- ]free\b", r"\bcruelty[- ]free\b", r"\bvegan\b",
    # calls-to-action / punchy answers
    r"\b(?:order now|order today|try it today|get started(?:\s+today)?|claim your[a-z ]{0,20}|buy now|act now|don'?t wait|add to cart)\b",
    r"\bclick (?:below|here|the (?:button|link)(?:\s+below)?)\b", r"\btap (?:below|here)\b",
    r"\b(?:get|grab|reserve|secure|order) your[a-z ]{0,20}\b", r"\bselect your (?:package|plan|pack)\b",
    r"\babsolutely\s+(?:yes|not)\b",
    # science: receptors / mechanisms
    r"\bbeta-?\d+\s+receptors?\b", r"\b[a-z]*thermogenesis\b", r"\b\w+(?:genesis|lysis)\b", r"\bmetabolism\b",
    # punchy weight-loss topic phrases
    r"\bstubborn\s+(?:body\s+)?(?:belly\s+fat|body\s+weight|body\s+fat|fat|weight)\b",
    # impressive statistics WITH their noun (53,000 men and women / over 10,000 customers / 2 stone lost)
    r"\b\d[\d,\.]*\+?\s+(?:men and women|men|women|people|customers|clients|users|adults|patients|reviews|"
    r"happy customers|five[- ]star reviews|countries|pounds|lbs|kg|kilos|stone)\b",
    r"\b(?:over|more than|nearly|up to|almost|around)\s+[\d,\.]+(?:\s+[a-z]+){0,2}\b",
]

# connectives / filler that must NEVER be red-bold on their own, and are trimmed from phrase edges
_FAQ_STOP = {"is", "and", "or", "but", "so", "yet", "nor", "for", "if", "of", "the", "a", "an", "to", "our",
             "your", "with", "that", "this", "it", "are", "you", "we", "in", "on", "at", "as", "by", "be",
             "then", "than", "when", "while", "because", "also", "however", "therefore", "from", "into",
             "very", "just", "really", "actually", "course", "am", "was", "were", "will", "can", "do", "does"}

# capitalised words that are NOT proper nouns — never treat a mid-sentence one of these as a location/brand
_FAQ_PN_SKIP = {"The", "This", "That", "These", "Those", "Our", "Your", "You", "We", "They", "It", "He",
                "She", "And", "But", "Or", "So", "If", "When", "While", "Then", "Now", "Here", "There",
                "Also", "However", "Yes", "No", "Not", "Why", "How", "What", "Who", "Whom", "Which",
                "Because", "Since", "After", "Before", "For", "With", "Without", "Every", "Each", "All",
                "Some", "Most", "Many", "More", "Less", "Just", "Only", "Even", "Still", "Well", "Once"}

def _faq_trim_kw(s):
    parts = (s or "").split()
    while parts and parts[0].lower().strip(".,!?;:\"'()") in _FAQ_STOP:
        parts.pop(0)
    while parts and parts[-1].lower().strip(".,!?;:\"'()") in _FAQ_STOP:
        parts.pop()
    return " ".join(parts).strip()

def _faq_clean_kws(kws):
    """Trim connective words off phrase edges, drop pure conjunctions/filler and 1-char tokens, dedup —
    applied to the FULL union (LLM + rules + project) so 'and'/'or'/'of course' never go red."""
    seen, out = set(), []
    for k in kws:
        k = _faq_trim_kw(str(k or ""))
        kl = k.lower()
        if not kl or len(kl) < 2 or kl in _FAQ_STOP or kl in seen:
            continue
        seen.add(kl); out.append(k)
    return out

def _faq_deterministic_kw(text):
    """Rule-based keyword extraction so highlighting is ROBUST regardless of the LLM: offers/guarantees,
    packs (any unit), %/prices, certifications/dietary claims, CTAs, vitamins/minerals/elements/nutrients,
    science terms, and proper nouns (Title-Case runs / CamelCase / ALLCAPS)."""
    T = text or ""
    kws = []
    for p in _FAQ_KW_PATTERNS:
        for m in re.finditer(p, T, flags=re.I):
            kws.append(m.group(0))
    low = T.lower()
    for n in _FAQ_NUTRIENTS:
        i = low.find(n)
        if i >= 0:
            kws.append(T[i:i + len(n)])                                # verbatim slice (preserve casing)
    for m in re.finditer(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", T):  # proper-noun runs: Royal Mail, New York
        kws.append(m.group(1))
    # single-word proper nouns (Sicily, Sweden, Amazon) — a Title-Case word that is NOT at the sentence start
    # (so we don't flag every sentence's first word) and is not a common capitalised function word
    for m in re.finditer(r"[A-Za-z][A-Za-z'’\-]*", T):
        w = m.group(0)
        if not re.match(r"^[A-Z][a-z]{2,}$", w) or w in _FAQ_PN_SKIP:
            continue
        j = m.start() - 1
        while j >= 0 and T[j] in " \t\r\n\"'(“‘":
            j -= 1
        if j < 0 or T[j] in ".!?:;":   # sentence-initial → skip (could just be a capitalised first word)
            continue
        kws.append(w)
    for w in T.split():
        c = w.strip(".,!?;:\"'()[]{}…")                               # trim ENDS only (keep internal, so 'non-GMO' stays)
        if re.search(r"[a-z][A-Z]", c) or re.match(r"^[A-Z]{3,}$", c): # CamelCase / ALLCAPS (CitruSlim, ISO)
            kws.append(c)
    return _faq_clean_kws(kws)

def _faq_render_worker(jid, scope):
    import caption_layer
    j = FAQ_RENDER_JOBS[jid]; wd = _faq_dir(scope)
    try:
        auds = list(wd.glob("audio.*")); audio = auds[0] if auds else None
        if not audio:
            raise RuntimeError("no voice-over uploaded")
        state = {}
        if (wd / "faq.json").exists():
            try: state = json.loads((wd / "faq.json").read_text(encoding="utf-8"))
            except Exception: state = {}
        cues = state.get("cues") or (premiere_export.parse_srt((wd / "faq.srt").read_text(encoding="utf-8")) if (wd / "faq.srt").exists() else [])
        if not cues:
            raise RuntimeError("no captions yet — Analyze & Sync first")
        style = state.get("style") or {}
        # robust keywords: whatever was saved UNION the deterministic pass over the script (so even old
        # builds pick up ingredient/vitamin/element/offer/proper-noun terms without re-Analyzing)
        kws = _faq_clean_kws(list(state.get("keywords") or []) +
                             _faq_deterministic_kw(state.get("script") or " ".join(c.get("text", "") for c in cues)))
        reds = {_faq_word_core(w) for w in (state.get("red_words") or []) if w}
        blacks = {_faq_word_core(w) for w in (state.get("black_words") or []) if w}
        dur = _probe_dur(audio) or (max(float(c["end"]) for c in cues) + 0.5)
        fps, W, H = 30, 1920, 1080
        one = str(style.get("sub_lines") or "auto") == "1"
        items = [{
            "html": _faq_highlight(c.get("text") or "", kws, reds, blacks), "text": c.get("text") or "", "style": style, "kind": "caption",
            "place": style.get("ost_place") or "center", "x": style.get("ost_x", 0), "y": style.get("ost_y", 0),
            "rotation": style.get("ost_rotation", 0), "sub_width": style.get("sub_width", 86), "oneline": one,
            "anim": style.get("ost_anim", "fade"), "out_anim": style.get("ost_out_anim", "none"),
            "start": float(c["start"]), "end": float(c["end"]),
        } for c in cues]
        def prog(done, total):
            with _FAQ_LOCK: j["pct"] = int(done / max(1, total) * 80); j["step"] = f"Rendering captions… {done}/{total}"
        clips = caption_layer.build_clips(items, wd, fps, W, H, progress=prog, should_cancel=lambda: j.get("cancel"))
        if j.get("cancel"):
            with _FAQ_LOCK: j["status"] = "cancelled"
            return
        with _FAQ_LOCK: j["step"] = "Encoding…"; j["pct"] = 88
        out = wd / "faq_video.mp4"
        inp = ["-f", "lavfi", "-i", f"color=c=white:s={W}x{H}:r={fps}:d={dur:.3f}", "-i", str(audio)]
        filt, last, idx = [], "0:v", 2
        for cl in clips:
            if not cl:
                continue
            mov, s, e, x, y = cl
            inp += ["-i", str(mov)]
            # shift each animated clip so ITS t=0 (the fade/pop/slide start) lands at the cue start,
            # then gate visibility to [start,end] (mirrors render_video's caption compositing)
            filt.append(f"[{idx}:v]setpts=PTS-STARTPTS+{float(s):.4f}/TB[cc{idx}]")
            filt.append(f"[{last}][cc{idx}]overlay=x={int(x)}:y={int(y)}:eof_action=pass:enable='between(t,{float(s):.3f},{float(e):.3f})'[v{idx}]")
            last = f"v{idx}"; idx += 1
        cmd = ["ffmpeg", "-y", *inp]
        if filt:
            fscript = wd / "_faq_filter.txt"; fscript.write_text(";".join(filt), encoding="utf-8")
            cmd += ["-filter_complex_script", str(fscript), "-map", f"[{last}]"]
        else:
            cmd += ["-map", "0:v"]
        cmd += ["-map", "1:a", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "veryfast",
                "-c:a", "aac", "-b:a", "192k", "-shortest", str(out)]
        r = subprocess.run(cmd, creationflags=_NO_WINDOW, capture_output=True, timeout=1800)
        if j.get("cancel"):
            with _FAQ_LOCK: j["status"] = "cancelled"
            return
        if r.returncode != 0 or not out.exists():
            (wd / "faq_render.log").write_bytes((r.stderr or b"")[-4000:])
            raise RuntimeError("ffmpeg failed — see faq_render.log")
        with _FAQ_LOCK: j["status"] = "done"; j["pct"] = 100; j["file"] = "faq_video.mp4"
    except Exception as e:
        with _FAQ_LOCK: j["status"] = "error"; j["error"] = str(e)

def _faq_render_start(scope):
    jid = "fr_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    FAQ_RENDER_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting…", "error": None, "file": None, "cancel": False}
    threading.Thread(target=_faq_render_worker, args=(jid, scope), daemon=True).start()
    return jid
FAQ_KEYWORD_SYSTEM = (
    "You choose which words/phrases to show in RED + BOLD in a VSL (video sales letter) FAQ caption. Highlight "
    "GENEROUSLY — every punchy, persuasive or important phrase (aim ~30-40% of the words). Return ONLY a JSON array "
    "of the EXACT substrings AS THEY APPEAR in the script (verbatim, same casing). Return the COMPLETE phrase, "
    "including EVERY number/unit/word that belongs to it (never split a phrase).\n"
    "ALWAYS highlight:\n"
    "- Offers & guarantees, the WHOLE phrase: 'risk-free', 'money-back guarantee', '180-day money-back guarantee', "
    "'100% satisfaction guarantee', 'completely free', 'free'.\n"
    "- Product packs, the WHOLE phrase INCLUDING every option: in 'three or six-month packs' highlight the ENTIRE "
    "'three or six-month packs' (not just 'six-month packs'). Same for 'three-month package', 'six-month package'.\n"
    "- Marketing/benefit phrases as a whole (not just the number): '100% natural formula', 'clinically proven'.\n"
    "- Punchy answer / call-to-action phrases: 'absolutely yes', 'yes', 'try it today', 'order now', 'get started "
    "today', 'claim your', 'don't wait' — every CTA and every emphatic answer.\n"
    "- Impressive STATISTICS / quantities (with their noun): '53,000 men and women', 'over 10,000 customers', "
    "'2 stone', '15 pounds'. (But NOT the FAQ question numbering.)\n"
    "- Certifications / standards / dietary claims: 'ISO 9001', 'Ecocert standards', 'non-GMO', 'plant-based', "
    "'dairy-free', 'gluten-free', 'vegan', 'FDA approved'.\n"
    "- Science / mechanism terms: the hero mechanism ('thermogenesis'), MOLECULE names, receptor/biological targets "
    "('beta-3 receptors'), enzymes, hormones, and every INGREDIENT name.\n"
    "- Proper nouns: the product/brand name, company names ('Royal Mail'), and LOCATIONS — countries, cities, "
    "regions ('Sicily', 'Italy').\n"
    "DO NOT highlight: the FAQ question numbering ('1.', '2.', 'Q1'…) and ordinary filler/connective words. "
    "Everything else that is persuasive or specific SHOULD be highlighted. Return just the JSON array, nothing else.")

def _faq_dir(scope):
    base = _studio_dir(scope) / "faq"
    base.mkdir(parents=True, exist_ok=True)
    return base

@app.route("/api/faq/keywords", methods=["POST"])
def api_faq_keywords():
    b = request.get_json(force=True) or {}
    script = (b.get("script") or "").strip()
    scope = b.get("scope") or "_global"
    if not script:
        return jsonify({"error": "empty script"}), 400
    # The AI (Claude) pass is REQUIRED — the user does NOT want a degraded rules-only result. If Kie is
    # unreachable we FAIL LOUDLY (503) so the client shows an error toast and aborts, rather than saving
    # fragmented keywords. (The deterministic + project layers below only ADD coverage on top of the AI's
    # full phrases — they never fragment, so a whole ingredient like "lemon zest extract" stays whole.)
    err = _keys_ok(("kie",))
    if err:
        return err                                                   # no Kie key → 400 "add API keys"
    try:
        arr = _parse_json_array(_claude_text(FAQ_KEYWORD_SYSTEM, script, max_tokens=2000, model=PROMPT_MODEL, tries=10))
    except Exception as e:
        return jsonify({"error": "ai_unavailable", "detail": str(e)[:200]}), 503
    kws = [str(x).strip() for x in arr if str(x).strip()]
    if not kws:
        return jsonify({"error": "ai_unavailable", "detail": "empty AI result"}), 503
    # deterministic rules (offers/packs/%/certs/CTAs/nutrients/science/proper-nouns) — additive safety net
    kws += _faq_deterministic_kw(script)
    # the project's ingredient / molecule / product names that appear in the script
    proj = _studio_scope_project(scope)
    if proj:
        doc = load_doc(proj) or {}
        extra = [(i.get("name") or "").strip() for i in (doc.get("ingredients") or [])]
        extra += [(doc.get("product") or {}).get("name", ""), doc.get("title", "")]
        low = script.lower()
        for n in extra:
            n = (n or "").strip()
            if n and n.lower() in low:
                kws.append(n)
    return jsonify({"keywords": _faq_clean_kws(kws)})

def _faq_align_pass(wd, audio, docx, out, model, job, lang="en"):
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out), VSL_LANG=lang)
    exe = _sys.executable
    si = None
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(c):
                exe = c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    args = [exe, str(SRT_SCRIPT), model, "--vad"]
    with open(wd / "align.log", "a", encoding="utf-8") as log:
        p = subprocess.Popen(args, cwd=str(wd), env=env, stdout=log, stderr=subprocess.STDOUT, startupinfo=si)
        with _FAQ_LOCK: job["proc"] = p
        p.wait()
        with _FAQ_LOCK: job["proc"] = None
        return p.returncode

def _faq_worker(jid, scope):
    j = FAQ_JOBS[jid]; wd = _faq_dir(scope)
    auds = list(wd.glob("audio.*")); audio = auds[0] if auds else None
    docx = wd / "script.docx"; out = wd / "faq.srt"
    proj = _studio_scope_project(scope)
    lang = audience_lang((load_doc(proj) or {}).get("audience")) if proj else "en"   # French FAQ VO → multilingual aligner
    try:
        for model in _align_models(lang):
            if j.get("cancel"):
                with _FAQ_LOCK: j["status"] = "cancelled"
                return
            with _FAQ_LOCK: j["step"] = f"Syncing captions ({model})…"
            rc = _faq_align_pass(wd, audio, docx, out, model, j, lang)
            if j.get("cancel"):
                with _FAQ_LOCK: j["status"] = "cancelled"
                return
            if rc != 0:
                with _FAQ_LOCK: j["status"] = "error"; j["error"] = f"sync failed (exit {rc}); see align.log"
                return
        if not out.exists():
            with _FAQ_LOCK: j["status"] = "error"; j["error"] = "no captions were produced; see align.log"
            return
        cues = premiere_export.parse_srt(out.read_text(encoding="utf-8"))
        with _FAQ_LOCK: j["status"] = "done"; j["cues"] = cues; j["step"] = "Done"
    except Exception as e:
        with _FAQ_LOCK: j["status"] = "error"; j["error"] = str(e)

@app.route("/api/faq/build", methods=["POST"])
def api_faq_build():
    scope = request.form.get("scope") or "_global"
    script = (request.form.get("script") or "").strip()
    wd = _faq_dir(scope)
    audio = request.files.get("audio")
    if audio and audio.filename:
        for old in wd.glob("audio.*"):
            try: old.unlink()
            except OSError: pass
        audio.save(wd / ("audio" + (Path(audio.filename).suffix or ".mp3").lower()))
    if not list(wd.glob("audio.*")):
        return jsonify({"error": "upload a voice-over first"}), 400
    docx = request.files.get("docx")
    if script:
        text_to_docx(script, wd / "script.docx")
    elif docx and docx.filename:
        fn = docx.filename.lower()
        if fn.endswith(".txt"):
            text_to_docx(docx.read().decode("utf-8", "ignore"), wd / "script.docx")
        else:
            docx.save(wd / "script.docx")
    if not (wd / "script.docx").exists():
        return jsonify({"error": "add a script — type it or upload a file"}), 400
    jid = "fq_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    FAQ_JOBS[jid] = {"status": "running", "step": "Starting…", "cues": [], "error": None, "cancel": False, "proc": None}
    threading.Thread(target=_faq_worker, args=(jid, scope), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/faq/job/<jid>")
def api_faq_job(jid):
    j = FAQ_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        return jsonify({"status": j["status"], "step": j.get("step"), "cues": j.get("cues", []), "error": j.get("error")})

@app.route("/api/faq/cancel/<jid>", methods=["POST"])
def api_faq_cancel(jid):
    """Stop an in-progress FAQ caption sync (kills the alignment subprocess)."""
    j = FAQ_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        j["cancel"] = True
        p = j.get("proc")
    if p:
        try: p.terminate()
        except Exception: pass
    return jsonify({"ok": True})

@app.route("/api/faq/state/<scope>", methods=["GET", "POST"])
def api_faq_state(scope):
    """Persist/restore a scope's FAQ work (script, keywords, caption style, cues) so it survives leaving Studio."""
    wd = _faq_dir(scope); p = wd / "faq.json"
    if request.method == "POST":
        b = request.get_json(force=True) or {}
        keep = {k: b.get(k) for k in ("script", "keywords", "style", "cues", "red_words", "black_words") if k in b}
        p.write_text(json.dumps(keep, ensure_ascii=False), encoding="utf-8")
        return jsonify({"ok": True})
    data = {}
    if p.exists():
        try: data = json.loads(p.read_text(encoding="utf-8"))
        except Exception: data = {}
    if not data.get("cues"):
        srt = wd / "faq.srt"
        if srt.exists():
            try: data["cues"] = premiere_export.parse_srt(srt.read_text(encoding="utf-8"))
            except Exception: pass
    data["hasAudio"] = bool(list(wd.glob("audio.*")))
    return jsonify(data)

@app.route("/api/faq/render/<scope>", methods=["POST"])
def api_faq_render(scope):
    """Render the FAQ preview to an MP4 (white bg + VO-synced captions with red keywords)."""
    return jsonify({"job": _faq_render_start(scope)})

@app.route("/api/faq/render-job/<jid>")
def api_faq_render_job(jid):
    j = FAQ_RENDER_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        return jsonify({k: j.get(k) for k in ("status", "pct", "step", "error", "file")})

@app.route("/api/faq/render-cancel/<jid>", methods=["POST"])
def api_faq_render_cancel(jid):
    j = FAQ_RENDER_JOBS.get(jid)
    if j:
        with _FAQ_LOCK: j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/faq/video/<scope>")
def api_faq_video(scope):
    p = _faq_dir(scope) / "faq_video.mp4"
    if not p.exists():
        abort(404)
    return send_file(p, mimetype="video/mp4", as_attachment=True, download_name="faq.mp4")

@app.route("/api/faq/audio/<scope>")
def api_faq_audio(scope):
    auds = list(_faq_dir(scope).glob("audio.*"))
    if not auds:
        abort(404)
    return send_file(auds[0])

@app.route("/api/studio/img/<scope>/<path:relpath>")
def api_studio_img(scope, relpath):
    base = _studio_dir(scope)
    fp = (base / relpath).resolve()
    if not str(fp).startswith(str(base.resolve())) or not fp.exists():
        abort(404)
    if request.args.get("dl"):
        return send_file(fp, as_attachment=True, download_name=request.args.get("dl"))
    return send_file(fp)

if __name__ == "__main__":
    print(f"KIE key: {'set' if KIE_KEY else 'MISSING'} | projects dir: {PROJECTS}")
    # Prefer port 80 (so the URL needs no ':port' → http://vsldashboard / http://localhost).
    # Fall back to 8000 if 80 is taken, so the dashboard always comes up.
    _port = int(os.environ.get("VSL_PORT", "80"))
    # Bind to 127.0.0.1 (this PC only) by default. Set VSL_HOST=0.0.0.0 to also serve it to other
    # machines on the network / over a Tailscale or tunnel connection. Only do that on a trusted
    # network or behind Tailscale — the dashboard has NO login and holds your API keys.
    _host = os.environ.get("VSL_HOST", "127.0.0.1")
    try:
        print(f"Serving on http://localhost:{_port}/  (http://vsldashboard/ after setup-vsldashboard.bat)")
        app.run(host=_host, port=_port, threaded=True, debug=False)
    except OSError:
        print("port 80 unavailable -- falling back to http://localhost:8000/")
        app.run(host=_host, port=8000, threaded=True, debug=False)
