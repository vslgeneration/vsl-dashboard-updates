"""
VSL Scene Dashboard — local control panel for the script -> prompt -> image -> video pipeline.

Everything is driven by one file per project: projects/<name>/scenes.json
Both this app and Claude Code read/write that file, so prompts authored in Claude Code
show up here instantly, and edits made here are visible to Claude Code.

Run:  python app.py    ->  http://localhost:8000
"""
import os, re, json, time, hashlib, io, threading, shutil, zipfile, subprocess, uuid, tempfile, difflib, bisect
import copy
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote as _urlquote, unquote as _urlunquote, urlparse as _urlparse
from pathlib import Path
from datetime import datetime, timedelta, timezone
import requests
from PIL import Image
from flask import (Flask, request, jsonify, send_file, abort, render_template, session, redirect,
                   url_for, Response, stream_with_context)
from werkzeug.security import generate_password_hash, check_password_hash
import premiere_export
import ai_baran
import youtube
import assets
import suno_music
import render_video

# Every AI system prompt + the word-lists they are built from live in prompts.py — pure text, no logic.
# Imported BY NAME (not *) so underscore-prefixed prompts come across too and it stays obvious
# which names originate there.
from prompts import (
    AUDIENCE_SYSTEM, AUDIT_OUTPUT, AUDIT_SYSTEM, AUDIT_VSL, AUDIT_YOUTUBE, AUTO_TRANS_SYSTEM,
    DIRECTOR_VSL, DIRECTOR_YOUTUBE_DECOR, IMAGE_QA_VSL,
    AVATAR_SYSTEM, CAMERA_ANGLES, CAST_SYSTEM,
    DIRECTOR_SYSTEM, FAQ_KEYWORD_SYSTEM, FAQ_RECONCILE_SYSTEM, IMAGE_QA_SYSTEM, INGREDIENT_SYSTEM,
    BADGE_SYSTEM, MOCKUP_ANGLES, MOCKUP_SETTINGS, OST_SYSTEM, OST_QUOTA_VSL, OST_QUOTA_YOUTUBE, OST_VSL, OVERLAY_SYSTEM, PRODUCT_SYSTEM, PROMPT_SYSTEM, PROMPT_VSL,
    QA_SUGGEST_SYSTEM, SPLIT_CLAUSE, SPLIT_CLAUSE_3, SPLIT_CLAUSE_4, SPLIT_SYSTEM, SPLIT_YOUTUBE,
    SRT_RECONCILE_SYSTEM,
    VIDEO_PROMPT_BASE, VIDEO_CAMERA_FREE, VIDEO_CAMERA_LOCKED, VIDEO_QA_SYSTEM, _CURRENCY_HINT, _ETHNIC_TERMS,
    _ETH_OBJECT_CTX, _FACE_VARIETY, _FACE_VARIETY_MEN, _HAIR_COLOURS, _BUILD_VARIETY, _HOME_LOOKS, _NO_ADDED_TEXT, _OST_STYLE_COPY, _OUTFIT_VARIETY, _SETTING_VARIETY, _STAGING_VARIETY,
    _TP_LOOKS, _TP_SCENES, _TRANSLATE_SYSTEM,
)
from quietlog import quiet

# The dashboard runs windowless (pythonw), so every child process would otherwise pop up
# its own console — a black box flashing over the screen once per ffmpeg/ffprobe call.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ---- bounded parallel runner for AI (Claude vision/text) batches -----------------------------------------------
# Sequential per-image / per-scene AI calls are the slow part (each is a network round-trip). We run them a few at
# a time so a batch finishes far faster WITHOUT overwhelming the CLI or hitting subscription rate limits.
AI_PARALLEL = 5   # max concurrent Claude calls in one batch (safe middle ground; raise cautiously)

# ---- credentials follow the THREAD, not the process ---------------------------------------------
# A request used to write its project's keys into six module globals, and every worker read those
# globals at call time - so a job still running for project A used project B's key the moment the
# browser opened B. Now every read goes through _key(): a request thread carries its own project's
# keys, a worker inherits the keys of the request that started it and keeps them for its whole life,
# and a pool task inherits its submitter's. The globals only hold the last-activated set, as a fallback.
_TLK = threading.local()
_KEY_GLOBALS = {"KIE_API_KEY": "KIE_KEY", "CLOUDINARY_CLOUD_NAME": "CL_CLOUD", "CLOUDINARY_API_KEY": "CL_KEY",
                "CLOUDINARY_API_SECRET": "CL_SECRET", "ELEVENLABS_API_KEY": "ELEVEN_KEY",
                "WAVESPEED_API_KEY": "WAVESPEED_KEY"}


def _key(name):
    """The credential `name` (its env-style name, e.g. KIE_API_KEY) as THIS thread should use it."""
    ks = getattr(_TLK, "keys", None)
    if ks is not None:
        return ks.get(name, "") or ""
    return globals().get(_KEY_GLOBALS[name], "") or ""


def _keys_now():
    """A snapshot of every credential as this thread sees them - what a worker will inherit."""
    return {n: _key(n) for n in _KEY_GLOBALS}


def _use_keys(keys):
    """Pin a credential set to this thread (None = fall back to the globals)."""
    _TLK.keys = dict(keys) if keys is not None else None


class _KeyThread(threading.Thread):
    """A worker that runs with the credentials of the thread that created it."""
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._keys = _keys_now()

    def run(self):
        _use_keys(self._keys)
        super().run()


class _KeyPool(ThreadPoolExecutor):
    """A pool whose tasks run with the credentials of the thread that submits them."""
    def submit(self, fn, *a, **kw):
        keys = _keys_now()

        def _run():
            _use_keys(keys)
            return fn(*a, **kw)
        return super().submit(_run)


def _parallel_map(items, fn, workers=AI_PARALLEL, cancel=None, on_progress=None):
    """Run fn(item) over `items` CONCURRENTLY (at most `workers` at once), returning results IN INPUT ORDER.
    - Each item's exception is CAUGHT and returned as ('__err__', exc), so ONE failure never kills the batch.
    - If cancel() is truthy, queued items short-circuit to ('__cancelled__',) instead of running (responsive stop).
    - on_progress(n_done, total) is called (thread-safe) after each item finishes — for the % progress bar.
    The caller inspects the returned list: real results are its own return values; sentinels are the 2-tuples above."""
    items = list(items)
    total = len(items)
    results = [None] * total
    if not total:
        return results
    w = max(1, min(int(workers or 1), total))
    done = {"n": 0}
    lock = threading.Lock()

    def _run(it):
        if cancel and cancel():
            return ("__cancelled__",)
        try:
            return fn(it)
        except Exception as e:                       # noqa: BLE001 — deliberately swallow so the batch survives
            return ("__err__", e)

    with _KeyPool(max_workers=w) as ex:
        futs = {ex.submit(_run, it): i for i, it in enumerate(items)}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                results[i] = fut.result()
            except Exception as e:                   # a future itself blowing up (shouldn't happen — _run guards)
                results[i] = ("__err__", e)
            with lock:
                done["n"] += 1
                if on_progress:
                    try:
                        on_progress(done["n"], total)
                    except Exception as _qe:
                        quiet(_qe, "_parallel_map")
    return results

BASE = Path(__file__).resolve().parent
def _read_version():
    try: return (BASE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception: return ""
_BOOT_VERSION = _read_version()   # the app-code version this PROCESS loaded at startup (frozen for its lifetime)
# All user-writable data (projects, keys, login, voices) lives under DATA_DIR. It defaults to BASE
# so a plain dev checkout is unchanged; the packaged desktop app sets VSL_DATA_DIR to its portable
# data/ folder so everything the user creates stays in one place next to the .exe.
DATA_DIR = Path(os.environ["VSL_DATA_DIR"]).resolve() if os.environ.get("VSL_DATA_DIR") else BASE
DATA_DIR.mkdir(parents=True, exist_ok=True)
ENV_PATH = (DATA_DIR / ".env") if os.environ.get("VSL_DATA_DIR") else (BASE.parent / ".env")   # API keys
PROJECTS = DATA_DIR / "projects"
PROJECTS.mkdir(exist_ok=True)
# Background music is now the SUNO library (AI-generated instrumentals) — the old Envato "Background Music"
# folder is intentionally NO LONGER USED. This lives under DATA_DIR so it's writable and grows with each
# generation. _ensure_suno_lib() creates the per-mood folders and seeds them from the bundled "Suno Seed/".
BGM_ROOT = DATA_DIR / "Suno Music"
_SUNO_SEED = BASE / "Suno Seed"           # bundled starter tracks copied into the library on first run
SUNO_PLAN_VERSION = 11                    # bump to force old cached music_plans to re-segment with new logic
MUSIC_SHIFT_SEC = 1.783                   # push every music transition LATER by this (1s 47f @60fps); was entering too early

# ---- config / secrets -------------------------------------------------------
def load_env():
    env = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env

ENV = load_env()

# ---- local login (no internet / no domain needed) ---------------------------
# auth.json lives next to the app (part of the copied folder). The admin sets per-person
# credentials by editing it; passwords typed in plaintext are hashed on first load, so the
# file ends up storing only hashes. A random session secret is generated once and persisted
# so logins survive server restarts.
AUTH_PATH = DATA_DIR / "auth.json"

def _is_hashed(v):
    v = str(v)
    return v.startswith("pbkdf2:") or v.startswith("scrypt:") or v.startswith("argon2")

def load_auth():
    if AUTH_PATH.exists():
        try:
            data = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    else:
        data = {}
    users = data.get("users") or {}
    if not users:                                   # first run: seed a default admin/admin
        users = {"admin": "admin"}
        data["users"] = users
    changed = False
    # hash any plaintext passwords the admin typed by hand
    for u, p in list(users.items()):
        if not _is_hashed(p):
            users[u] = generate_password_hash(str(p))
            changed = True
    if not data.get("secret"):                      # persistent session secret
        data["secret"] = os.urandom(24).hex()
        changed = True
    if changed or not AUTH_PATH.exists():
        try:
            AUTH_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as _qe:
            quiet(_qe, "load_auth")
    return data

AUTH = load_auth()

def check_login(username, password):
    h = (AUTH.get("users") or {}).get((username or "").strip())
    if not h:
        return False
    try:
        return check_password_hash(h, password or "")
    except Exception:
        return False

KIE_KEY = ENV.get("KIE_API_KEY", "")
CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
WAVESPEED_KEY = ENV.get("WAVESPEED_API_KEY", "")
ELEVEN_MODEL = "eleven_multilingual_v2"   # good multilingual quality; matches script language automatically
VOICES_PATH = DATA_DIR / "voices.json"    # frequently-used ElevenLabs voices (name -> voice_id); user-editable → data
OST_PRESETS_PATH = DATA_DIR / "ost_presets.json"   # saved on-screen-text style presets (shared across projects)

KIE_BASE = "https://api.kie.ai/api/v1/jobs"
IMAGE_MODEL = "nano-banana-2"
# selectable per-scene image model families (label shown in the UI dropdown). Each family
# auto-resolves to a text-to-image or image-to-image Kie model id depending on whether the
# scene has reference images — see build_kie_image_request().
IMAGE_MODELS = [
    {"key": "nano-banana-2", "label": "NanoBanana 2"},
    {"key": "gpt-image-2", "label": "GPT Image 2"},
    {"key": "seedream-5-pro", "label": "Seedream 5.0 Pro"},
]
IMAGE_MODEL_KEYS = {m["key"] for m in IMAGE_MODELS}
IMAGE_MODELS_READY = IMAGE_MODEL_KEYS     # all wired

def build_kie_image_request(family, prompt, refs, aspect="16:9", resolution="2K"):
    """Map a dropdown model family (+ whether refs exist) to the exact Kie model id and input
    body. Reference images -> image-to-image variant; none -> text-to-image. `aspect` (default 16:9)
    lets callers request 1:1 / 9:16 etc.; `resolution` = "2K" / "4K" (nano & gpt)."""
    refs = refs or []
    has = bool(refs)
    res = resolution if resolution in ("2K", "4K") else "2K"
    if family == "gpt-image-2":
        if has:
            return "gpt-image-2-image-to-image", {"prompt": prompt, "input_urls": refs[:16], "aspect_ratio": aspect, "resolution": res}
        return "gpt-image-2-text-to-image", {"prompt": prompt, "aspect_ratio": aspect, "resolution": res}
    if family == "seedream-5-pro":
        if has:
            return "seedream/5-pro-image-to-image", {"prompt": prompt, "image_urls": refs[:10], "aspect_ratio": aspect, "quality": "high", "output_format": "png"}
        return "seedream/5-pro-text-to-image", {"prompt": prompt, "aspect_ratio": aspect, "quality": "high", "output_format": "png"}
    # default: nano-banana-2 (one model id, optional image_input)
    inp = {"prompt": prompt, "aspect_ratio": aspect, "resolution": res, "output_format": "png"}
    if has:
        inp["image_input"] = refs
    return "nano-banana-2", inp
# ---- video models --------------------------------------------------------
# Each family: durations (seconds the model supports) + resolutions, so the UI can adapt
# the dropdowns per model. `api` = which endpoint/flow to use ("jobs" = unified createTask,
# "veo" = the separate /api/v1/veo endpoint). `id` = the Kie model id (or veo model tier).
VIDEO_MODELS = [
    {"key": "seedance-2-mini", "label": "Seedance 2.0 Mini", "id": "bytedance/seedance-2-mini", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2-fast", "label": "Seedance 2.0 Fast", "id": "bytedance/seedance-2-fast", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2", "label": "Seedance 2.0", "id": "bytedance/seedance-2", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p", "1080p", "4k"], "defaultDur": 5, "defaultRes": "1080p"},
    {"key": "veo-3-1", "label": "Veo 3.1", "id": "veo3_fast", "api": "veo",
     "durations": [4, 6, 8], "resolutions": ["720p", "1080p", "4k"], "defaultDur": 8, "defaultRes": "1080p"},
    {"key": "grok-imagine", "label": "Grok Imagine", "id": "grok-imagine/image-to-video", "api": "jobs",
     "durations": [6, 8, 10, 12, 15, 20, 25, 30], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-1-5-pro", "label": "Seedance 1.5 Pro", "id": "bytedance/seedance-1.5-pro", "api": "jobs",
     "durations": [4, 6, 8, 10, 12], "resolutions": ["480p", "720p", "1080p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "kling-2-1-standard", "label": "Kling 2.1 Standard", "id": "kling/v2-1-standard", "api": "jobs",
     "durations": [5, 10], "resolutions": ["720p"], "defaultDur": 5, "defaultRes": "720p"},
    {"key": "kling-2-6", "label": "Kling 2.6", "id": "kling-2.6/image-to-video", "api": "jobs",
     "durations": [5, 10], "resolutions": ["720p"], "defaultDur": 5, "defaultRes": "720p"},
    {"key": "grok-video-1-5", "label": "Grok Imagine Video 1.5", "id": "grok-imagine-video-1-5-preview", "api": "jobs",
     "durations": [4, 6, 8, 10, 12, 15], "resolutions": ["480p", "720p", "1080p"], "defaultDur": 6, "defaultRes": "1080p"},
]
VIDEO_MODEL_BY_KEY = {m["key"]: m for m in VIDEO_MODELS}
DEFAULT_VIDEO_MODEL = "grok-video-1-5"    # Grok Imagine Video 1.5 @ 1080p, 6s, static camera (user's chosen default)
VIDEO_CONFIGURED = True

def _clamp_video_opts(cfg, duration, resolution):
    dur = duration if duration in cfg["durations"] else cfg["defaultDur"]
    res = resolution if resolution in cfg["resolutions"] else cfg["defaultRes"]
    return dur, res

def build_video_request(model_key, img_url, prompt, duration, resolution):
    """Return (api_type, model_id, payload) for the chosen video model. jobs -> {model,input}
    body for kie_create; veo -> flat body for /api/v1/veo/generate.
    img_url may be a single URL (string) OR a list of URLs — array-input models (Grok, Veo, Kling 2.6,
    Seedance 1.5) accept MULTIPLE reference images; single-input models use just the first."""
    cfg = VIDEO_MODEL_BY_KEY.get(model_key) or VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
    dur, res = _clamp_video_opts(cfg, duration, resolution)
    mid = cfg["id"]
    urls = [u for u in (img_url if isinstance(img_url, (list, tuple)) else [img_url]) if u]
    first = urls[0] if urls else img_url        # single-input models use only the first reference
    if cfg["api"] == "veo":
        return "veo", mid, {"prompt": prompt, "imageUrls": urls, "model": mid,
                            "aspect_ratio": "16:9", "resolution": res, "duration": dur}
    if model_key == "grok-imagine":
        return "jobs", mid, {"prompt": prompt, "image_urls": urls, "mode": "normal",
                             "duration": str(dur), "resolution": res, "aspect_ratio": "16:9"}
    if model_key == "kling-2-1-standard":   # input: image_url (string), duration "5"/"10", no resolution
        return "jobs", mid, {"prompt": prompt, "image_url": first, "duration": str(dur),
                             "negative_prompt": "blur, distort, low quality", "cfg_scale": 0.5}
    if model_key == "kling-2-6":            # input: image_urls (array), sound bool, duration "5"/"10", no resolution
        return "jobs", mid, {"prompt": prompt, "image_urls": urls, "sound": False, "duration": str(dur)}
    if model_key == "seedance-1-5-pro":     # input: input_urls (array), aspect_ratio, resolution 480/720/1080, duration NUMBER
        return "jobs", mid, {"prompt": prompt, "input_urls": urls, "aspect_ratio": "16:9",
                             "resolution": res, "duration": int(dur), "generate_audio": False}
    if model_key == "grok-video-1-5":       # Grok Imagine Video 1.5 preview: image_urls array, resolution, duration NUMBER, no audio
        return "jobs", mid, {"prompt": prompt, "image_urls": urls, "aspect_ratio": "16:9",
                             "resolution": res, "duration": int(dur)}
    # seedance 2.x family (mini / fast / 2) — single start frame
    return "jobs", mid, {"prompt": prompt, "first_frame_url": first, "generate_audio": False,
                         "duration": dur, "resolution": res, "aspect_ratio": "16:9"}

def kie_veo_create(payload):
    def _do():
        r = requests.post("https://api.kie.ai/api/v1/veo/generate",
                          headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}", "Content-Type": "application/json"},
                          json=payload, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"].get("taskId"), None
    return None, d.get("msg", "unknown error")

def kie_veo_record(task_id):
    def _do():
        r = requests.get("https://api.kie.ai/api/v1/veo/record-info", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}"}, timeout=60)
        return r.json()
    return _retry(_do)

# Prompt generation runs through Kie.ai's Anthropic-native Claude endpoint,
# so it uses the SAME KIE_API_KEY — no separate Anthropic key needed.
KIE_CLAUDE_URL = "https://api.kie.ai/claude/v1/messages"
# Model IDs below only matter on the KIE API path (VSL_TEXT_PROVIDER=kie). On the DEFAULT Claude-subscription
# path (VSL_TEXT_PROVIDER=claude) the local CLI maps them by name: anything not "sonnet"/"haiku" -> OPUS (see
# _cli_model). So on the subscription BOTH of these run as OPUS (the CLI's best) — Fable is NOT actually used,
# and the director / split / cast / all analysis already run on Opus. Vision (Check Images/Videos, video prompts)
# also runs on Opus now (max quality). Only "...sonnet..." / "...haiku..." model ids would downgrade.
PROMPT_MODEL = "claude-opus-4-8"
SMART_MODEL = "claude-fable-5"   # subscription: -> OPUS. (Kie path only: Fable for the one whole-script analyze pass.)

# Per-scene visual style. The preset text below is injected into the image prompt as the "how it looks"
# layer (medium + lighting + composition + quality); the scene text stays style-free so they can't conflict.
# The content half of the "avoid" list. Kept here so the image prompts can phrase it as "never depict X"
# instead of the appearance clause's "no ordinary people who look X", which would be nonsense for these.
YT_AVOID = {
    "Blood or gore", "Wounds or injuries", "Weapons aimed at people", "Fighting or physical violence",
    "Corpses or death", "Nudity", "Revealing or suggestive clothing", "Sexualised poses",
    "Surgery or medical gore", "Self-harm", "Disturbing or shocking imagery",
    "Drugs or paraphernalia", "Smoking or vaping", "Alcohol abuse", "Firearms", "Gambling",
    "Hate or extremist symbols", "Dangerous stunts", "Children in unsafe or suggestive situations",
}


def _split_avoid(excl):
    """(looks, content) - the appearance exclusions and the YouTube content rules, told apart."""
    excl = list(excl or [])
    return [x for x in excl if x not in YT_AVOID], [x for x in excl if x in YT_AVOID]


PROJECT_TYPES = ("vsl", "youtube")
# A project is a VSL unless it says otherwise: every project made before this existed keeps behaving
# exactly as it did. The type decides what the app shows AND what the director is allowed to use.
DEFAULT_PTYPE = "vsl"


def proj_type(doc):
    return "youtube" if (doc or {}).get("ptype") == "youtube" else DEFAULT_PTYPE


def is_youtube(doc):
    return proj_type(doc) == "youtube"


STYLE_KEYS = ["natural", "2d", "3d", "scientific"]


_VISUAL_STYLE = {"realistic": "natural", "2d": "2d", "2d_flat": "2d", "2d_mixed": "2d",
                 "3d": "3d", "3d_flat": "3d", "3d_mixed": "3d"}   # plain "mixed" is deliberately absent
# ...and how those drawn frames are composed. Plain "2d"/"3d" means full scenes, which is what a
# video almost always wants; the "_flat" pair is the isolated-on-white explainer framing.
_VISUAL_BG = {"2d": "scene", "3d": "scene", "2d_flat": "flat", "3d_flat": "flat",
              "2d_mixed": "mixed", "3d_mixed": "mixed"}
ANIM_STYLES = ("2d", "3d")      # drawn/rendered scenes: no pasted real faces, no icon or text overlays


def _doc_scene_style(doc):
    """The Visuals picker on the Script tab decides the look of every scene the director writes - but ONLY
    when that panel was actually used. If Title and Idea are both empty the script was typed or uploaded by
    hand, the pickers were never part of it, and the app behaves exactly as it always did: the director
    picks per scene. "Mixed" means the same thing on purpose."""
    o = (doc or {}).get("script_opts") or {}
    if not (str(o.get("title") or "").strip() or str(o.get("idea") or "").strip()):
        return None
    return _VISUAL_STYLE.get(o.get("visual"))


def _doc_scene_bg(doc):
    """Full scenes or isolated-on-white, for the drawn looks. Same rule as the style: it only
    applies when the Script panel was actually used."""
    o = (doc or {}).get("script_opts") or {}
    if not (str(o.get("title") or "").strip() or str(o.get("idea") or "").strip()):
        return None
    return _VISUAL_BG.get(o.get("visual"))

# How a DRAWN frame is composed. Same look, opposite framing: an explainer isolates its subject so the
# eye has one thing to do; a story needs the room, the weather and the light or the moment does not read.
# Kept apart from STYLE_PRESETS because they are independent choices and welding them made one impossible.
BG_PRESETS = {
    "flat": ("COMPOSITION: place the subject on a plain solid WHITE background, centred and isolated, with "
             "ONLY the one or two props essential to the action - NO full detailed room, NO busy scenery, "
             "NO edge-to-edge environment, no floor, wall or furniture filling the frame. Leave generous "
             "empty white space around the subject: a clean, uncluttered explainer frame. The ONLY "
             "exception, where a detailed full-frame illustration may cover the whole background, is "
             "anatomical / inside-the-body / organ / cellular / medical content - draw THOSE as a clean "
             "cross-section in the same style."),
    "scene": ("COMPOSITION: draw the WHOLE scene, edge to edge. The place is part of the story, so build "
              "it: the room or the landscape, the weather, the time of day, what is behind and beside the "
              "subject, and light that comes from somewhere you can point to. Never leave the subject "
              "floating on blank white - the background is filled, and the frame is composed like a shot "
              "from a film, not like a diagram. Depth matters: something near, something far."),
    "mixed": ("COMPOSITION: follow the framing described in the shot above. If it describes a real place "
              "- a room, a deck, a landscape, weather, a time of day - draw that whole scene edge to edge, "
              "composed like a shot from a film, with something near and something far. If instead it "
              "describes an isolated subject, a comparison, a mechanism or a diagram, place that subject "
              "on a plain solid WHITE background with generous empty space and only the props it needs. "
              "One or the other, never half of each."),
}
DEFAULT_BG = "flat"        # what a scene made before this choice existed keeps doing


# "minor blemishes" was meant as "do not airbrush"; the model read it as "add a mark" and put a mole on
# one cheek after another. Pores and fine lines say everything the clause needs to say without it.
_BLEMISH_CLAUSE = ", minor blemishes"


def style_preset(style, bg=None, vsl=False):
    """The look, plus how the frame is composed. A drawn style needs both; a photographic one only ever
    had the first. `vsl` drops the blemish wording that was speckling faces with moles."""
    p = STYLE_PRESETS.get(style or "natural", "")
    if vsl and _BLEMISH_CLAUSE in p:
        p = p.replace(_BLEMISH_CLAUSE, "")
    if style in ANIM_STYLES:
        p = (p + " " + BG_PRESETS.get(bg or DEFAULT_BG, BG_PRESETS[DEFAULT_BG])).strip()
    return p


DEFAULT_STYLE = "natural"   # every new/split scene starts Realistic; the user flips it per scene as needed
STYLE_PRESETS = {
    "natural": "Photorealistic but candid and slightly amateur — like a real everyday photo taken by an ordinary person on a normal phone or consumer camera, NOT a polished stock photo and NOT a studio shot. Natural available light only (window or ordinary room light), soft and a little uneven, no studio lighting or softboxes, gentle real-world shadows. A slightly imperfect, candid feel, as if a quick real snapshot — but FOLLOW whatever shot framing/composition is specified separately (this LOOK does not decide the framing). Natural true-to-life colors, not over-saturated or heavily color-graded. Real ordinary people (not models) with authentic skin texture — visible pores, fine lines, minor blemishes; absolutely no skin smoothing, airbrushing, or retouching. Believable, unposed, documentary/candid snapshot feel. Avoid glossy stock-photo perfection, studio lighting, cinematic color grading, and flawless model faces.",
    "2d": "2D cartoon illustration in a modern Western TV / adult-animation explainer style (a clean, friendly cartoon still). BOLD, clean, evenly-weighted dark outlines around every shape; FLAT colors with simple soft cel-shading (a few gentle gradient bands, NOT realistic rendering); soft glossy highlights on rounded or curved surfaces. Warm, friendly, slightly muted palette. Characters are simplified and expressive with large clear cartoon eyes and clean simple features. Clean hand-drawn / vector cartoon look — NOT photorealistic, NOT a 3D CGI render, NOT a photo.",
    "3d": "3D animated still in a modern feature-animation / CG explainer look (a clean, friendly 3D render). "
          "Stylised rounded forms with soft subsurface-lit skin, gentle global illumination, soft contact shadows "
          "and a shallow depth of field; subtle glossy specular highlights on curved surfaces. Characters are "
          "stylised and appealing rather than photoreal - simplified proportions, large clear expressive eyes, "
          "clean simple features; NEVER photographic skin texture, pores, blemishes or wrinkles. Warm, friendly, "
          "slightly saturated palette. "
          "Clean CG animation look - NOT photorealistic, NOT live-action footage, NOT a "
          "photo, no film grain and no gritty cinematic colour grading.",
    "scientific": "Photorealistic 3D CGI medical / anatomical visualization — the look of a high-end medical stock animation still (a Blender/Cinema-4D render), NOT a diagram, NOT a cartoon, NOT a real photo. Hyper-detailed, realistically 3D-rendered anatomy with glossy, wet, sub-surface-scattering surfaces, realistic materials, soft reflections, and cinematic lighting with a shallow depth of field (background softly blurred). Two typical looks: (1) a specific organ (brain, heart, liver, gut…) glowing luminously inside a translucent, semi-transparent X-RAY-like body silhouette on a dark, moody background; or (2) a rich CLOSE-UP of internal biology — blood vessels / arteries in cross-section, flowing red blood cells, fat cells, cholesterol / plaque, gut bacteria — with translucent membranes, warm golden or clinical-blue tones, and gentle glowing highlights on the area of interest. Deep, dimensional, premium science-documentary feel with soft shadows and depth. NOT flat, NOT hand-drawn, NOT a 2D illustration, NOT a photograph of a real person.",
}

CAMERA_ANGLES_BY_KEY = {c["key"]: c for c in CAMERA_ANGLES}
CAMERA_KEYS = [c["key"] for c in CAMERA_ANGLES]
DEFAULT_CAMERA = "medium"

# Per-scene transition: how this scene hands off to the NEXT one (preview + render + Premiere XML).
# corporate/film/lightleak are USER-supplied transition CLIPS (Transitions/) placed on the overlay track with
# their hit frame aligned to the cut — these carry into the Premiere XML as real clips.
TRANSITIONS = ["none", "crossfade", "dip-black", "dip-white", "film", "lightleak"]
DEFAULT_TRANSITION = "none"

# Country -> language used for any visible text/signage in generated images
COUNTRY_LANG = {
    "United States": "English", "United Kingdom": "English", "Canada": "English", "Australia": "English",
    "Ireland": "English", "New Zealand": "English",
    "France": "French", "Belgium": "French", "Switzerland": "French",
    "Germany": "German", "Austria": "German",
    "Spain": "Spanish", "Mexico": "Spanish", "Argentina": "Spanish",
    "Italy": "Italian", "Portugal": "Portuguese", "Brazil": "Portuguese",
    "Netherlands": "Dutch", "Turkey": "Turkish", "Poland": "Polish", "Sweden": "Swedish",
    "Norway": "Norwegian", "Denmark": "Danish", "Finland": "Finnish", "Russia": "Russian",
    "Japan": "Japanese", "China": "Chinese", "Korea": "Korean",
}
def country_language(aud):
    locs = (aud or {}).get("locations") or []
    return COUNTRY_LANG.get(locs[0], "English") if locs else "English"

# Country -> 2-letter Whisper language code for the subtitle forced-aligner (default English).
LANG_CODE = {
    "United States": "en", "United Kingdom": "en", "Canada": "en", "Australia": "en", "Ireland": "en",
    "New Zealand": "en", "France": "fr", "Belgium": "fr", "Switzerland": "fr", "Germany": "de",
    "Austria": "de", "Spain": "es", "Mexico": "es", "Argentina": "es", "Italy": "it", "Portugal": "pt",
    "Brazil": "pt", "Netherlands": "nl", "Turkey": "tr", "Poland": "pl", "Sweden": "sv", "Norway": "no",
    "Denmark": "da", "Finland": "fi", "Russia": "ru", "Japan": "ja", "China": "zh", "Korea": "ko",
}
def audience_lang(aud):
    """2-letter Whisper language code from the audience's first location (default 'en')."""
    locs = (aud or {}).get("locations") or []
    return LANG_CODE.get(locs[0], "en") if locs else "en"

def _align_models(lang):
    """(small, medium) forced-aligner models for a language. English keeps the tuned .en ensemble; any
    other language uses the multilingual variants (small / medium) so French, German, etc. align correctly."""
    return ("small.en", "medium.en") if (lang or "en") == "en" else ("small", "medium")

def looks_turkish(t):
    return any(ch in "çğıışöüÇĞİÖŞÜ" for ch in (t or ""))

def slugify(t, n=40):
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"

def fname_slug(t):
    """Underscore-joined name for output filenames, e.g. 'CitruSlim VSL' -> 'CitruSlim_VSL'."""
    return re.sub(r"[^A-Za-z0-9]+", "_", (t or "").strip()).strip("_") or "project"

def today_ddmmyyyy():
    return datetime.now().strftime("%d%m%Y")

def speaker_slug(voice_id):
    """Map a voice_id back to a saved voice name (underscored), or '' if not a saved voice."""
    for v in load_voices():
        if v.get("voice_id") == voice_id and v.get("name"):
            return fname_slug(v["name"])
    return ""

app = Flask(__name__)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0   # always serve fresh static assets during dev
app.config["TEMPLATES_AUTO_RELOAD"] = True    # pick up index.html edits without restart
# The desktop "Save As" (save_download in desktop.py) authenticates the local /media request with the
# cookie read from document.cookie — which excludes an HttpOnly session cookie, so the download 401'd
# ("login required") on some machines. This is a localhost-only app, so expose the session cookie to JS.
app.config["SESSION_COOKIE_HTTPONLY"] = False
# VSL_FRESH_SESSION (set by the desktop launcher) → a new key every run, so a previous session
# cookie no longer validates and the login gate always shows on launch. Dev/browser keeps the
# persisted key so it stays logged in across server restarts.
app.secret_key = os.urandom(24).hex() if os.environ.get("VSL_FRESH_SESSION") else (AUTH.get("secret") or os.urandom(24).hex())
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)   # stay logged in for a month

# ---- per-user data isolation ------------------------------------------------
# Each account gets its OWN projects + API keys under data/users/<name>/. One user is "active" per
# running instance (the desktop app signs one person in per launch); before_request re-points the
# project/key globals whenever the signed-in user changes, so baran and merih never see each other's
# projects or keys. voices.json / ost_presets.json stay shared (they hold no per-user secrets).
USERS_ROOT = DATA_DIR / "users"
try:
    USERS_ROOT.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

def _safe_user(u):
    return re.sub(r"[^a-zA-Z0-9_-]", "-", (u or "").strip()).strip("-") or "user"

def user_root(u):
    return USERS_ROOT / _safe_user(u)

_ACTIVE_USER = None
_ACTIVE_GUARD = threading.Lock()

def _activate_user(u):
    """Point PROJECTS/ENV_PATH at this user's private folder and reload their API keys into the
    fallback set; this thread is unpinned so it reads that set until a project is activated."""
    global _ACTIVE_USER, PROJECTS, ENV_PATH, ENV
    root = user_root(u)
    try:
        (root / "projects").mkdir(parents=True, exist_ok=True)
    except Exception as _qe:
        quiet(_qe, "_activate_user")
    PROJECTS = root / "projects"
    ENV_PATH = root / ".env"
    ENV = load_env()
    _set_key_globals({n: ENV.get(n, "") for n in _KEY_GLOBALS})
    _use_keys(None)
    _ACTIVE_USER = u
    global _KEYS_PROJECT
    _KEYS_PROJECT = None                              # force per-project keys to re-activate for the new user

# ---- per-PROJECT API keys ---------------------------------------------------
# Keys live in <project>/keys.json so they travel with export/import — each project carries its own Kie /
# Cloudinary / ElevenLabs credentials, independent of which membership (baran/merih) opens it.
_KEY_ENV_NAMES = ["KIE_API_KEY", "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET", "ELEVENLABS_API_KEY", "WAVESPEED_API_KEY"]
_KEYS_PROJECT = None                                 # name of the project whose keys are currently in the globals


def _set_key_globals(keys):
    """The fallback credential set - what a thread with nothing pinned to it reads."""
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY, WAVESPEED_KEY
    KIE_KEY = keys.get("KIE_API_KEY", "") or ""
    CL_CLOUD = keys.get("CLOUDINARY_CLOUD_NAME", "") or ""
    CL_KEY = keys.get("CLOUDINARY_API_KEY", "") or ""
    CL_SECRET = keys.get("CLOUDINARY_API_SECRET", "") or ""
    ELEVEN_KEY = keys.get("ELEVENLABS_API_KEY", "") or ""
    WAVESPEED_KEY = keys.get("WAVESPEED_API_KEY", "") or ""

def _proj_keys_path(project):
    d, _safe = proj_dir(project)
    return d / "keys.json"

def _read_proj_keys(project):
    p = _proj_keys_path(project)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return None                                      # None = no keys.json yet (legacy project)

def _write_proj_keys(project, keys):
    d, _safe = proj_dir(project)
    d.mkdir(parents=True, exist_ok=True)
    _proj_keys_path(project).write_text(json.dumps(keys, ensure_ascii=False, indent=2), encoding="utf-8")

def _activate_project_keys(project):
    """Pin THIS project's keys.json to the current thread (and any worker it starts). A legacy project
    (no keys.json) is migrated once by seeding from the active user's account keys, so nothing breaks;
    new projects start empty and must be filled in Settings -> API Keys.

    Only a project that exists is activated: a URL naming an unknown project used to get a folder and
    a keys.json full of real keys written for it (projects/null/keys.json was one such)."""
    global _KEYS_PROJECT
    d, _safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        return
    keys = _read_proj_keys(project)
    if keys is None:                                 # migrate legacy project → seed from the user's .env
        keys = {n: ENV.get(n, "") for n in _KEY_ENV_NAMES}
        try:
            _write_proj_keys(project, keys)
        except Exception as _qe:
            quiet(_qe, "_activate_project_keys")
    _use_keys(keys)
    if project != _KEYS_PROJECT:
        _set_key_globals(keys)
        _REF_URL_CACHE.clear()                       # ref URLs are per-Cloudinary-account — drop them when switching project
        _KEYS_PROJECT = project

# The GLOBAL Studio (out-of-project) carries its OWN keys.json next to the global studio folder, so standalone
# image / mockup / FAQ generation works without opening a project. Filled in Studio -> Keys (optionally copied
# from an existing project). Mirrors the per-project keys shape.
def _global_keys_path():
    base = PROJECTS.parent / "studio"
    base.mkdir(parents=True, exist_ok=True)
    return base / "keys.json"

def _read_global_keys():
    p = _global_keys_path()
    if p.exists():
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return {}
    return {}

def _write_global_keys(keys):
    _global_keys_path().write_text(json.dumps(keys, ensure_ascii=False, indent=2), encoding="utf-8")

def _activate_global_keys():
    """Point the key globals at the GLOBAL studio's keys.json for this request (used when a Studio/FAQ route
    runs with no project — the '_global' scope)."""
    global _KEYS_PROJECT
    keys = _read_global_keys()
    _use_keys(keys)
    if _KEYS_PROJECT != "__global__":
        _set_key_globals(keys)
        _REF_URL_CACHE.clear()
        _KEYS_PROJECT = "__global__"

def _keys_ok(need):
    """Guard a generation route: if this project is missing a required key, return a clear error the UI
    turns into a 'add API keys for this project' warning (instead of a confusing provider error later)."""
    miss = []
    if "wavespeed" in need and not _key('WAVESPEED_API_KEY'):
        miss.append("WaveSpeed")
    if "kie" in need and not _key('KIE_API_KEY'):
        miss.append("Kie")
    if "cloud" in need and not (_key('CLOUDINARY_CLOUD_NAME') and _key('CLOUDINARY_API_KEY') and _key('CLOUDINARY_API_SECRET')):
        miss.append("Cloudinary")
    if "eleven" in need and not _key('ELEVENLABS_API_KEY'):
        miss.append("ElevenLabs")
    if miss:
        return jsonify({"error": "This project has no " + " / ".join(miss) + " API key yet. "
                        "Open Settings → API Keys and add it for this project."}), 400
    return None

# Everything requires a local login EXCEPT the login page itself and the static assets it needs
# (CSS/JS/fonts hold no secrets). Page requests redirect to /login; API/media requests get 401.
@app.before_request
def _require_login():
    u = session.get("user")
    if u:
        if u != _ACTIVE_USER:                    # signed-in user changed → point data at their folder
            with _ACTIVE_GUARD:
                if u != _ACTIVE_USER:
                    _activate_user(u)
        proj = (request.view_args or {}).get("project")   # a <project> in the URL → use THAT project's own keys
        if proj:
            try:
                _activate_project_keys(proj)
            except Exception as _qe:
                quiet(_qe, "_require_login")
        elif request.path.startswith("/api/studio/") or request.path.startswith("/api/faq/"):
            # Studio/FAQ routes carry a `scope` (URL or body) instead of a project. Point the keys at the
            # in-project studio's project, or at the GLOBAL studio's own keys.json for the '_global' scope.
            try:
                scope = (request.view_args or {}).get("scope")
                if scope is None:
                    scope = (request.form.get("scope") if request.form else None) or \
                            ((request.get_json(silent=True) or {}).get("scope") if request.is_json else None)
                sp = _studio_scope_project(scope)
                if sp:
                    _activate_project_keys(sp)
                else:
                    _activate_global_keys()
            except Exception as _qe:
                quiet(_qe, "_require_login")
        return None
    # Not logged in: gate only the data endpoints. Pages/static still load so the single-page
    # login gate (rendered inside "/") can show over the home, then reveal it after sign-in.
    if request.path == "/api/ai-baran":
        # The help assistant is reachable from the sign-in screen on purpose - someone who cannot get
        # in is exactly who needs to ask a question. It reads no project here: the route drops the
        # project name when there is no session, so it can only answer from its own manual.
        return None
    if request.path.startswith("/api/") or request.path.startswith("/media/"):
        return ("login required", 401)
    return None

@app.after_request
def _no_cache(resp):
    if request.path == "/" or request.path.startswith("/static/"):
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

_lock = threading.Lock()   # serialize scenes.json writes

# Per-project lock so an endpoint's load→modify→save runs atomically. Without it, the 6s poll
# loop (which does its own load→save) can overwrite a scene that a concurrent Generate just
# marked "generating" with its own stale copy — the second scene appears to start then stop.
_PROJECT_LOCKS = {}
_PROJECT_LOCKS_GUARD = threading.Lock()
def _project_lock(name):
    with _PROJECT_LOCKS_GUARD:
        lk = _PROJECT_LOCKS.get(name)
        if lk is None:
            lk = threading.RLock()
            _PROJECT_LOCKS[name] = lk
        return lk

def _locked(fn):
    """Serialize a route's whole load→modify→save against the 6s poll (which also holds this lock).
    Without it a poll that loaded the doc BEFORE the user's approve/save can write its stale copy back
    afterward and revert the change ('geriye atma'). Applies to every route whose first arg is `project`."""
    import functools
    @functools.wraps(fn)
    def _w(project, *a, **kw):
        with _project_lock(project):
            return fn(project, *a, **kw)
    return _w

# ---- helpers ----------------------------------------------------------------
def proj_dir(name):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", name).strip("-") or "project"
    d = PROJECTS / safe
    return d, safe

def scenes_path(name):
    d, _ = proj_dir(name)
    return d / "scenes.json"

# on-screen text overlay defaults — burned onto preview + render, NOT sent to the image AI.
# Grouped: type / geometry / stroke / background / effects+animation.
# per-overlay style fields (each overlay = onscreen text + these). ost_on is section-level (see norm_scene).
# Default look = the user's saved "Montserrat White" style: Montserrat Extrabold 115px, UPPERCASE,
# centered, white fill, no stroke / no background / no drop shadow, slide-from-bottom in + fade out.
OST_OVERLAY_DEFAULTS = {
    "onscreen": "",
    "ost_fill": True, "ost_color": "#ffffff", "ost_font": "Montserrat", "ost_size": 115, "ost_weight": "800",
    "ost_bold": False, "ost_italic": False, "ost_upper": True, "ost_underline": False,
    "ost_letter": 0, "ost_leading": 0.85,
    "ost_place": "center", "ost_x": 0, "ost_y": 0, "ost_rotation": 0,
    "ost_stroke": False, "ost_stroke_w": 4, "ost_stroke_color": "#000000", "ost_stroke_pos": "outer",
    "ost_bg": False, "ost_bg_color": "#000000", "ost_bg_opacity": 60, "ost_bg_pad": 12, "ost_bg_radius": 8,
    "ost_shadow": False, "ost_shadow_color": "#000000", "ost_shadow_opacity": 80, "ost_shadow_size": 6, "ost_shadow_dir": 135,
    "ost_anim": "slide-bottom", "ost_out_anim": "fade",
    "ost_in": 0.0, "ost_out": 1.0,   # when the text shows, as a fraction of its scene (0=scene start, 1=scene end)
}

def new_overlay():
    return dict(OST_OVERLAY_DEFAULTS)

def _overlay_timeline(ov):
    """Map ONE overlay's ost_* fields to the text_* keys the renderer + preview consume."""
    return {
        "text": (ov.get("onscreen") or "").strip(),
        "text_fill": bool(ov.get("ost_fill", True)),
        "text_color": ov.get("ost_color") or "#ffffff",
        "text_font": ov.get("ost_font") or "Arial",
        "text_size": int(ov.get("ost_size") or 56),
        "text_weight": str(ov.get("ost_weight") or "400"),
        "text_bold": bool(ov.get("ost_bold")),
        "text_italic": bool(ov.get("ost_italic")),
        "text_upper": bool(ov.get("ost_upper")),
        "text_underline": bool(ov.get("ost_underline")),
        "text_letter": int(ov.get("ost_letter") or 0),
        "text_leading": float(ov.get("ost_leading") or 1.15),
        "text_place": ov.get("ost_place") or "top",
        "text_x": int(ov.get("ost_x") or 0),
        "text_y": int(ov.get("ost_y") or 0),
        "text_rotation": int(ov.get("ost_rotation") or 0),
        "text_stroke": bool(ov.get("ost_stroke", True)),
        "text_stroke_w": int(ov.get("ost_stroke_w") or 0),
        "text_stroke_color": ov.get("ost_stroke_color") or "#000000",
        "text_stroke_pos": ov.get("ost_stroke_pos") or "outer",
        "text_bg": bool(ov.get("ost_bg")),
        "text_bg_color": ov.get("ost_bg_color") or "#000000",
        "text_bg_opacity": int(ov.get("ost_bg_opacity") or 0),
        "text_bg_pad": int(ov.get("ost_bg_pad") or 0),
        "text_bg_radius": int(ov.get("ost_bg_radius") or 0),
        "text_shadow": bool(ov.get("ost_shadow", True)),
        "text_shadow_color": ov.get("ost_shadow_color") or "#000000",
        "text_shadow_opacity": int(ov.get("ost_shadow_opacity") or 0),
        "text_shadow_size": int(ov.get("ost_shadow_size") or 0),
        "text_shadow_dir": int(ov.get("ost_shadow_dir") or 0),
        # enforce the on-screen-text animation rule EVERYWHERE (old/manual overlays too): never plain fade-in,
        # never slide-right; the OUT is a FIXED function of the IN (pop->pop, slide-left->slide-left, slide-top/
        # bottom->fade).
        "text_anim": _ost_in_anim(ov.get("ost_anim")),
        "text_out_anim": _OST_OUT_FOR.get(_ost_in_anim(ov.get("ost_anim")), "fade"),
        "text_in": _ost_frac(ov.get("ost_in"), 0.0),      # show window as a fraction of the scene
        "text_out": _ost_frac(ov.get("ost_out"), 1.0),
    }

def _ost_frac(v, default):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, f))

def _scene_overlays(s):
    """List of text_* dicts for a scene's overlays (empty when the section is off)."""
    if not s.get("ost_on"):
        return []
    return [_overlay_timeline(ov) for ov in (s.get("overlays") or []) if (ov.get("onscreen") or "").strip()]

def norm_scene(s):
    """Normalize a scene to the versioned-image model + defaults (backward compatible)."""
    s.setdefault("style", None)
    s.setdefault("no_cast", False)
    s.setdefault("model", IMAGE_MODEL)
    if s.get("model") not in IMAGE_MODEL_KEYS:   # migrate removed/old model keys (e.g. gpt-4o)
        s["model"] = IMAGE_MODEL
    s.setdefault("refs", [])
    s.setdefault("ref_free", [])      # ref paths whose STYLE (clothing/hair) is unlocked (default: locked)
    s.setdefault("cast", [])          # ids of doc.characters present in this scene
    s.setdefault("cont_of", None)     # uid of an earlier scene this one visually continues (same place+people)
    s.setdefault("tcard_id", None)    # id of a linked testimonial_card (this scene mirrors that card's image)
    s.setdefault("camera", DEFAULT_CAMERA)          # camera framing/angle key
    if s.get("camera") not in CAMERA_ANGLES_BY_KEY and s.get("camera") not in ("", None, "none"):
        s["camera"] = DEFAULT_CAMERA   # "none" is a valid choice → no camera-angle text in the prompt
    s.setdefault("transition", DEFAULT_TRANSITION)  # transition into the NEXT scene
    if s.get("transition") not in TRANSITIONS:
        s["transition"] = DEFAULT_TRANSITION
    # on-screen text overlays: migrate legacy flat fields → overlays[0], normalize the list
    fresh = "overlays" not in s
    if fresh:
        s["overlays"] = [{k: s.get(k, OST_OVERLAY_DEFAULTS[k]) for k in OST_OVERLAY_DEFAULTS}]
    if not isinstance(s.get("overlays"), list) or not s["overlays"]:
        s["overlays"] = [new_overlay()]
    for ov in s["overlays"]:
        for k, v in OST_OVERLAY_DEFAULTS.items():
            ov.setdefault(k, v)
        ov["ost_in"] = _ost_frac(ov.get("ost_in"), 0.0)          # show window within the scene, 0..1
        ov["ost_out"] = _ost_frac(ov.get("ost_out"), 1.0)
        if ov["ost_out"] <= ov["ost_in"]:                        # keep at least a sliver visible
            ov["ost_out"] = min(1.0, ov["ost_in"] + 0.05)
    has_text = any((ov.get("onscreen") or "").strip() for ov in s["overlays"])
    if fresh:
        s["ost_on"] = has_text                       # legacy scenes with text migrate to ON
    else:
        s.setdefault("ost_on", has_text)
    for lk in list(OST_OVERLAY_DEFAULTS) + ["onscreen"]:   # drop legacy flat copies (now inside overlays)
        s.pop(lk, None)
    # video model + options (clamp to the selected model's supported values)
    if s.get("video_model") not in VIDEO_MODEL_BY_KEY:
        s["video_model"] = DEFAULT_VIDEO_MODEL
    _vcfg = VIDEO_MODEL_BY_KEY[s["video_model"]]
    if s.get("video_dur") not in _vcfg["durations"]:
        s["video_dur"] = _vcfg["defaultDur"]
    if s.get("video_res") not in _vcfg["resolutions"]:
        s["video_res"] = _vcfg["defaultRes"]
    if s.get("transition") == "corporate":     # retired option - old projects fall back to a plain cut
        s["transition"] = "none"
    s.setdefault("video_cam_lock", False)           # image→video may move the camera a little; the user locks the shots that must sit still
    s.setdefault("video", {"status": "empty", "taskId": None, "file": None, "error": None})
    s["video"].setdefault("approved", False)
    s["video"].setdefault("api", "jobs")
    img = s.setdefault("image", {})
    if "versions" not in img:
        vers = list(img.get("history") or [])
        if img.get("file"):
            vers.append(img["file"])
        img["versions"] = vers
        img["current"] = len(vers) - 1
    img.setdefault("current", len(img.get("versions", [])) - 1)
    for k, dv in (("status", "empty"), ("taskId", None), ("error", None)):
        img.setdefault(k, dv)
    vs, cur = img.get("versions", []), img.get("current", -1)
    img["file"] = vs[cur] if (vs and 0 <= cur < len(vs)) else None   # "file" = current (shown) version
    av = img.get("approved_version")
    img["approved_file"] = vs[av] if (isinstance(av, int) and 0 <= av < len(vs)) else None
    # MODEL PER VERSION: keep version_models aligned with versions (legacy versions → best-guess = last selection).
    # The DROPDOWN is reconciled to the shown image's model on the FRONTEND at project-open (NOT here) — doing it
    # server-side would also clobber the model the user just picked for the NEXT generation.
    vm = img.setdefault("version_models", [])
    while len(vm) < len(vs):
        vm.append(s.get("model") or IMAGE_MODEL)
    if len(vm) > len(vs):
        del vm[len(vs):]
    return s

def new_uid():
    """A short, permanent per-scene identity. Media files are named by this (NOT the 1..N display id),
    so inserting/splitting/deleting/reordering scenes — which renumbers ids — never renames files,
    never collides two scenes on one filename, and never detaches a video from its scene."""
    return hashlib.md5(f"{time.time()}".encode() + os.urandom(6)).hexdigest()[:8]

_KARA_DIR = "testimonials"


def _kara_offload(d, card):
    """Move a written-testimonial card's karaoke HTML out of the document into its own file. That
    HTML carries the card picture and ran to 10 MB a card - kept inline it was parsed on every
    request and sent to the browser on every poll. Returns True when the card changed."""
    kara = (card.get("extra") or {}).get("kara") if isinstance(card, dict) else None
    if not isinstance(kara, dict):
        return False
    html = kara.get("html")
    if not isinstance(html, str) or not html:
        return False
    cid = re.sub(r"[^A-Za-z0-9_-]", "-", str(card.get("id") or "")) or "card"
    rel = f"{_KARA_DIR}/kara_{cid}.html"
    try:
        (d / _KARA_DIR).mkdir(parents=True, exist_ok=True)
        _write_atomic(d / rel, html)
    except OSError:
        return False                              # could not file it: leave the HTML where it is rather than lose it
    kara["file"] = rel
    kara.setdefault("sig", "legacy")              # the browser compares this to decide whether to store a fresh one
    del kara["html"]
    return True


def _kara_html(d, kara):
    """A card's karaoke HTML: inline if it still is, else from its file."""
    if not isinstance(kara, dict):
        return ""
    if kara.get("html"):
        return kara["html"]
    rel = kara.get("file")
    if rel:
        try:
            return (d / rel).read_text(encoding="utf-8")
        except OSError:
            return ""
    return ""


def _read_doc_text(p):
    """The document's text, read under the write lock (never mid-rename), falling back to the .bak the
    writer keeps when the file itself does not parse."""
    with _lock:
        text = p.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except ValueError as e:
        bak = p.with_name(p.name + ".bak")
        if bak.exists():
            quiet(e, "load_doc: scenes.json unreadable, using .bak")
            with _lock:
                return json.loads(bak.read_text(encoding="utf-8"))
        raise


def _peek_doc(path):
    """Read a scenes.json by path, under the write lock, for the few places that look at a project
    without opening it (the project list, export, import, rename, publish slots)."""
    with _lock:
        return json.loads(Path(path).read_text(encoding="utf-8"))


def load_doc(name):
    p = scenes_path(name)
    if not p.exists():
        return None
    doc = _read_doc_text(p)
    doc.setdefault("characters", [])     # per-project cast: [{id, name, url}]
    doc.setdefault("testimonials", [])   # per-project TESTIMONIAL PEOPLE roster (separate pool from cast): [{id, name, desc, urls}]
    doc.setdefault("testimonial_cards", [])   # written testimonial card drafts: [{id, format, charId, text, extra}]
    doc.setdefault("ingredients", [])    # per-project INGREDIENTS: [{id, name, desc, urls}] — the product's real ingredients, attached (i2i) to ingredient shots
    doc.setdefault("product", {"urls": []})   # per-project PRODUCT reference image(s) — attached (i2i) to scenes flagged show-product
    doc.setdefault("brief", "")          # free-text project brief/context fed to the split + prompt LLM passes
    changed = False
    used = set()
    for s in doc.get("scenes", []):
        u = s.get("uid")
        if not u or u in used:           # one-time migration: give every existing scene a stable uid
            u = new_uid(); s["uid"] = u; changed = True
        used.add(u)
        norm_scene(s)
    # one-time migration: adopt the current default video model (Grok Imagine Video 1.5 @ 6s / 1080p) on EVERY
    # existing scene, so pre-existing projects match the chosen default. Runs ONCE per project (flagged) — after
    # this, any per-scene model/duration/resolution the user picks is preserved on later loads.
    _pd, _ = proj_dir(name)
    for _c in doc.get("testimonial_cards") or []:
        if _kara_offload(_pd, _c):        # an older document still carrying karaoke HTML inline
            changed = True
    if not doc.get("_vid_default_grok15"):
        _vd = VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
        for s in doc.get("scenes", []):
            s["video_model"] = DEFAULT_VIDEO_MODEL
            s["video_dur"] = _vd["defaultDur"]
            s["video_res"] = _vd["defaultRes"]
        doc["_vid_default_grok15"] = True
        changed = True
    if changed:
        save_doc(name, doc)              # persist the assigned uids / video-default migration once
    return doc

def _write_atomic(path, text, backup=False):
    """Write `text` so the file on disk is always either the old version or the new one - never half of
    either. The text goes to a sibling .tmp first and is renamed over the target in one step; with
    backup=True the previous version is kept beside it as .bak, the one copy that survives a bad save."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    if backup and path.exists():
        try:
            shutil.copyfile(path, path.with_name(path.name + ".bak"))
        except OSError as _qe:
            quiet(_qe, "_write_atomic")
    for _i in range(40):                 # a reader holding the file open for a moment blocks the rename on Windows
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            time.sleep(0.025)
    path.write_text(text, encoding="utf-8")   # last resort: in place, rather than lose the save
    try:
        tmp.unlink()
    except OSError as _qe:
        quiet(_qe, "_write_atomic")


def save_doc(name, doc):
    d, _ = proj_dir(name)
    (d / "images").mkdir(parents=True, exist_ok=True)
    (d / "videos").mkdir(parents=True, exist_ok=True)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    text = json.dumps(doc, indent=2, ensure_ascii=False)
    with _lock:
        _write_atomic(scenes_path(name), text, backup=True)

_DEL = object()                 # sentinel: pop this key during a merge-save
_merge_lock = threading.Lock()

def merge_save_fields(name, updates):
    """Concurrency-safe PARTIAL save: re-read the doc from disk, apply ONLY the given per-scene fields
    (keyed by scene id) onto the LATEST on-disk version, then write. This stops two long background jobs
    that each loaded the whole doc minutes ago (e.g. Generate Video Prompts + Generate Overlays running at
    the same time) from clobbering each other's whole-file save — each only writes its OWN fields.
    updates = {scene_id: {field: value | _DEL-to-remove}}."""
    if not updates:
        return
    with _project_lock(name), _merge_lock:     # project lock FIRST - the same order every locked route takes
        fresh = load_doc(name)
        if fresh is None:
            return
        by_id = {s.get("id"): s for s in fresh.get("scenes", [])}
        for sid, fields in updates.items():
            t = by_id.get(sid)
            if t is None:
                continue
            for k, v in fields.items():
                if v is _DEL:
                    t.pop(k, None)
                else:
                    t[k] = v
        save_doc(name, fresh)

def new_scene(i):
    return {
        "id": i, "uid": new_uid(), "vo": "", "prompt": "", "refs": [], "cast": [], "ingredients": [], "states": {}, "camera": "none", "transition": DEFAULT_TRANSITION, "style": DEFAULT_STYLE, "no_cast": False, "pure": False, "split": False, "testimonial": False, "testimonial_n": 8, "tcard_id": None, "model": IMAGE_MODEL,
        "bg": DEFAULT_BG,   # how a DRAWN frame is composed: full scene / isolated on white / decide per line
        "ost_on": False, "overlays": [new_overlay()],   # on-screen text (section toggle + overlay list)
        "image": {"status": "empty", "taskId": None, "error": None,
                  "versions": [], "current": -1, "file": None, "approved_version": None},
        "approved": False,
        "video_desc": "", "video_prompt": "", "video_cam_lock": False,
        "video_model": DEFAULT_VIDEO_MODEL,
        "video_dur": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultDur"],
        "video_res": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultRes"],
        "video": {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False, "api": "jobs"},
    }

# ---- Cloudinary (for uploading local refs -> public URL for Kie) ------------
def cloudinary_upload(local_path, public_id):
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{_key('CLOUDINARY_API_SECRET')}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    with open(local_path, "rb") as fh:
        r = requests.post(
            f"https://api.cloudinary.com/v1_1/{_key('CLOUDINARY_CLOUD_NAME')}/image/upload",
            files={"file": fh},
            data={"public_id": public_id, "timestamp": ts, "api_key": _key('CLOUDINARY_API_KEY'), "signature": sig},
            timeout=120,
        )
    d = r.json()
    url = d.get("secure_url")
    # deliver a size-limited PNG so Kie always gets a valid, <25MP image
    if url:
        url = url.replace("/upload/", "/upload/c_limit,w_1600,f_png/")
        url = re.sub(r"\.(webp|jpg|jpeg)$", ".png", url)
    return url

def cloudinary_upload_audio(local_path, public_id):
    """Upload an audio file to Cloudinary (resource_type=video) → public URL Kie can fetch. No transform."""
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{_key('CLOUDINARY_API_SECRET')}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    try:
        with open(local_path, "rb") as fh:
            r = requests.post(
                f"https://api.cloudinary.com/v1_1/{_key('CLOUDINARY_CLOUD_NAME')}/video/upload",
                files={"file": fh},
                data={"public_id": public_id, "timestamp": ts, "api_key": _key('CLOUDINARY_API_KEY'), "signature": sig},
                timeout=120,
            )
        return (r.json() or {}).get("secure_url")
    except Exception:
        return None

# Reference images are stored LOCALLY on add (fast, no network/quota). Only when a scene is
# actually generated do we upload each local ref to Cloudinary to get the public URL Kie fetches.
_REF_URL_CACHE = {}   # (path, mtime_ns) -> cloudinary url, so a ref uploads at most once per session

def ref_public_url(d, safe, ref):
    """Public URL Kie can fetch for a stored reference. A local path ('refs/…') is uploaded to
    Cloudinary now; an http URL passes through — EXCEPT a Cloudinary URL from a different (old)
    account, which Kie can no longer fetch: we re-upload the local copy to the CURRENT account so
    old references self-heal instead of failing with 'image fetch failed'. Returns None if it can't."""
    if not ref:
        return None
    if ref.startswith("http://") or ref.startswith("https://"):
        if _key('CLOUDINARY_CLOUD_NAME') and "res.cloudinary.com/" in ref and f"res.cloudinary.com/{_key('CLOUDINARY_CLOUD_NAME')}/" not in ref:
            local = _local_ref_for_url(d, ref)          # find the on-disk copy by filename
            if local is not None:
                return ref_public_url(d, safe, str(local))   # re-upload it to the new account
        return ref
    p = d / ref
    if not p.is_file():
        p = d / "refs" / Path(ref).name
    if not p.is_file():
        return None
    try:
        key = (str(p), p.stat().st_mtime_ns)
    except OSError:
        key = (str(p), 0)
    if key in _REF_URL_CACHE:
        return _REF_URL_CACHE[key]
    url = cloudinary_upload(p, f"{safe}/refs/{p.stem}")
    if url:
        _REF_URL_CACHE[key] = url
    return url

def resolve_refs(d, safe, refs):
    """Turn stored refs into public URLs for Kie. Raises ValueError if a local ref can't upload
    (e.g. Cloudinary over quota) so generation fails with a clear message instead of silently
    dropping the reference."""
    out = []
    for r in (refs or []):
        u = ref_public_url(d, safe, r)
        if u is None:
            raise ValueError("reference image upload failed (check Cloudinary account)")
        out.append(u)
    return out

# ---- Kie.ai ----------------------------------------------------------------
def _retry(fn, tries=3, base=0.6, cap=5.0):
    """Call fn(); on ANY exception retry up to `tries` times with exponential backoff (capped at `cap`s so a
    high retry count can't explode into minute-long waits). Rides out transient blips / provider 500s.
    Raises the last error only if every attempt fails."""
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            last = e
            if i < tries - 1:
                time.sleep(min(base * (2 ** i), cap))
    raise last

def kie_create(model, inp):
    def _do():
        r = requests.post(f"{KIE_BASE}/createTask",
                          headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}", "Content-Type": "application/json"},
                          json={"model": model, "input": inp}, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"]["taskId"], None
    return None, d.get("msg", "unknown error")

def kie_record(task_id):
    # A status check must stay fast: a hung/slow Kie must not make ONE poll occupy a worker for minutes
    # (that was what made Stop/regenerate feel dead while a scene was stuck). Short timeout, few tries.
    def _do():
        r = requests.get(f"{KIE_BASE}/recordInfo", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}"}, timeout=20)
        return r.json()
    return _retry(_do, tries=2)

def result_url(record):
    try:
        rj = record["data"].get("resultJson") or ""
        if rj:
            urls = json.loads(rj).get("resultUrls") or []
            if urls:
                return urls[0]
    except Exception as _qe:
        quiet(_qe, "result_url")
    return None

def download_as_png(url, dest_path):
    """Download bytes and save as a *real* PNG regardless of what Kie actually returns.
    Retried so a transient blip doesn't discard an image Kie already generated."""
    def _do():
        r = requests.get(url, timeout=180)
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGB")
        img.save(dest_path, "PNG")
    _retry(_do)

def download_as_mp4(url, dest_path):
    def _do():
        r = requests.get(url, timeout=600, stream=True)
        r.raise_for_status()
        with open(dest_path, "wb") as fh:
            for chunk in r.iter_content(65536):
                fh.write(chunk)
    _retry(_do)

# ---- subtitle / SRT (local forced alignment, no API) -----------------------
# Wraps the tested standalone tool subtitle/vsl_align_srt.py. Runs entirely on
# this machine (MMS-FA + ffmpeg) — no Kie.ai, no Claude Code tokens.
import sys as _sys


def _subtitle_tools_dir():
    """Where the aligner scripts live. The update now bundles them, and the zip extracts into app/, so
    an updated install has them at app/subtitle/ — prefer that. A dev checkout, and any install from
    before they were bundled, keeps them one level up beside the app instead."""
    here = BASE / "subtitle"
    return here if (here / "vsl_align_srt.py").exists() else BASE.parent / "subtitle"


SUBTITLE_TOOLS = _subtitle_tools_dir()
SRT_SCRIPT = SUBTITLE_TOOLS / "vsl_align_srt.py"
SUB_STATUS = {}            # {project: {status, step, srt, error, updated}}
SUB_LOCK = threading.Lock()

def sub_dir(name):
    d, _ = proj_dir(name)
    return d / "subtitle"

def sub_status_path(name):
    return sub_dir(name) / "status.json"

def set_sub_status(name, **kw):
    with SUB_LOCK:
        st = SUB_STATUS.get(name, {})
        st.update(kw); st["updated"] = time.time()
        SUB_STATUS[name] = st
    try:
        sub_dir(name).mkdir(parents=True, exist_ok=True)
        sub_status_path(name).write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "set_sub_status")
    return st

def get_sub_status(name):
    with SUB_LOCK:
        if name in SUB_STATUS:
            return dict(SUB_STATUS[name])
    p = sub_status_path(name)
    if p.exists():
        try:
            st = json.loads(p.read_text(encoding="utf-8"))
            # A persisted "running" with no live in-process job = the server was restarted mid-job
            # (which kills it). Report it as stopped so the UI never hangs on a dead job, and clear
            # the stale file so it doesn't resurface.
            if st.get("status") == "running":
                st = {"status": "error", "step": "",
                      "error": "Subtitle generation was interrupted (the server restarted). Please run it again."}
                try:
                    p.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
                except Exception as _qe:
                    quiet(_qe, "get_sub_status")
            return st
        except Exception as _qe:
            quiet(_qe, "get_sub_status")
    return {"status": "idle"}

# ---- shortening the pauses in a voice-over, without ever touching a word --------------------------
# This used to hand the job to ffmpeg's silenceremove at a FIXED -35 dB, BEFORE anything knew where the
# words were. Measured on a real 751 s voice-over that cost 0.68 s of ACTUAL SPEECH in `fast` - tens of
# milliseconds bitten off the ends of words - while `natural` and `slow` removed nothing at all (0.2 s
# out of 751) because their stop_silence was larger than their stop_duration, so the rule cancelled
# itself. The aligner could not complain about any of it: it was handed damaged audio and dutifully
# aligned that, so the subtitles looked perfect while the sound was clipped.
#
# The cut is no longer blind. The forced aligner already runs on this audio to build the subtitles and it
# reports where every word starts and ends, so the pauses are taken from strictly BETWEEN two words.
# That makes a clipped word arithmetically impossible rather than a threshold that might be set wrong.
# The word times are then shifted by however much was removed ahead of them, so the SRT stays exact
# without a second alignment.
TRIM_MODES = {"fast": 0.16, "natural": 0.28, "slow": 0.45}   # seconds of pause to LEAVE between words
TRIM_GUARD = 0.06        # silence always left touching a word, whatever the mode asks for


def _trim_cuts(words, total, mode="natural"):
    """Stretches to remove, every one of them strictly inside a gap between words. [(a, b)] seconds."""
    keep = max(float(TRIM_MODES.get(mode, TRIM_MODES["natural"])), 2 * TRIM_GUARD)
    half = keep / 2.0
    cuts, prev = [], 0.0
    for w in sorted(words, key=lambda x: x[0]):
        s, e = float(w[0]), float(w[1])
        if s > prev:
            a = prev + (half if prev > 0 else 0.0)      # nothing to protect before the first word
            b = s - half
            if b - a > 0.02:
                cuts.append((a, b))
        prev = max(prev, e)
    if total - prev > half + 0.02:                      # the tail after the last word
        cuts.append((prev + half, total))
    return cuts


def _trim_shift(t, cuts):
    """Where timestamp `t` lands once `cuts` are gone."""
    out = float(t)
    for a, b in cuts:
        if t >= b:
            out -= (b - a)
        elif t > a:
            out -= (t - a)
    return max(0.0, round(out, 3))


def apply_word_trim(audio, dst, words, mode="natural"):
    """Cut the pauses out of `audio`, between the aligned words. Returns (cuts, removed_s) or None.

    Fails closed on purpose: the caller keeps the original take whenever this returns None, so a problem
    here costs a shorter file, never a damaged one.
    """
    try:
        import numpy as np
        import wave
    except Exception:
        raise RuntimeError("the pause trim needs numpy, which this install does not have")
    dec, cut_wav = Path(str(dst) + ".dec.wav"), Path(str(dst) + ".cut.wav")
    try:
        total = _audio_dur(audio) or 0.0
        if total <= 0:
            raise RuntimeError("could not read the length of the voice-over")
        if not words:
            raise RuntimeError("the alignment produced no word times, so the pauses cannot be cut safely")
        cuts = _trim_cuts(words, total, mode)
        if not cuts:
            return None                         # genuinely nothing worth removing - not a failure
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(audio), "-c:a", "pcm_s16le", str(dec)],
                       check=True, timeout=900, creationflags=_NO_WINDOW)
        with wave.open(str(dec)) as w:
            ch, sr, n = w.getnchannels(), w.getframerate(), w.getnframes()
            x = np.frombuffer(w.readframes(n), dtype="<i2")
        frames = x.reshape(-1, max(1, ch))
        mask = np.ones(len(frames), dtype=bool)
        for a, b in cuts:
            mask[max(0, int(a * sr)):min(len(frames), int(b * sr))] = False
        kept = frames[mask]
        if len(kept) < sr:                      # a trim that leaves under a second is a bug, not a trim
            raise RuntimeError("the trim would have left almost nothing - refusing to use it")
        with wave.open(str(cut_wav), "wb") as w:
            w.setnchannels(ch); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes(kept.astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(cut_wav), str(dst)],
                       check=True, timeout=900, creationflags=_NO_WINDOW)
        if not (Path(dst).exists() and Path(dst).stat().st_size > 1000):
            raise RuntimeError("the trimmed take could not be written")
        return cuts, sum(b - a for a, b in cuts)
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("the pause trim failed: %s" % (str(e)[:160] or e.__class__.__name__))
    finally:
        for p in (dec, cut_wav):
            try: p.unlink(missing_ok=True)
            except OSError as _qe: quiet(_qe, "apply_word_trim")


def _trim_after_align(wd, audio, srt_out, mode):
    """Shorten the pauses using the word times the alignment just produced, then move the SRT and the
    word list onto the shortened audio. Returns (relative path of the trimmed take, removed_s) or None."""
    words = premiere_export.load_word_tsv(wd)
    if not words:
        raise RuntimeError("no word timings were produced, so the pauses cannot be cut safely")
    trimmed = Path(wd) / "voiceover_trimmed.mp3"
    try:
        res = apply_word_trim(audio, trimmed, words, mode)
    except Exception:
        trimmed.unlink(missing_ok=True)         # never leave half a take on disk for something to find
        raise
    if not res:
        return None                             # nothing worth removing
    cuts, removed = res
    try:                                        # the SRT now describes a shorter recording
        cues = premiere_export.parse_srt(Path(srt_out).read_text(encoding="utf-8-sig"))
        for c in cues:
            c["start"], c["end"] = _trim_shift(c["start"], cuts), _trim_shift(c["end"], cuts)
        cues = [c for c in cues if c["end"] - c["start"] > 0.04]
        Path(srt_out).write_text(premiere_export.caps_to_srt(cues), encoding="utf-8")
    except Exception as e:
        trimmed.unlink(missing_ok=True)
        raise RuntimeError("the audio was trimmed but the subtitles could not be moved onto it "
                           "(%s) - nothing was kept" % (str(e)[:120] or e.__class__.__name__))
    for name in ("words_medium_en_vad.tsv", "words_small_en_vad.tsv",
                 "words_medium_vad.tsv", "words_small_vad.tsv"):
        p = Path(wd) / name
        if not p.exists():
            continue
        try:
            rows = []
            for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                q = line.split("\t")
                if len(q) >= 3:
                    rows.append("%.3f\t%.3f\t%s" % (_trim_shift(float(q[0]), cuts),
                                                    _trim_shift(float(q[1]), cuts), q[2]))
            if rows:
                p.write_text("\n".join(rows) + "\n", encoding="utf-8")
        except Exception as _qe:
            quiet(_qe, "_trim_after_align")
    return f"subtitle/{trimmed.name}", removed


# live subtitle jobs, so the UI's "⏹ Stop" can kill the running aligner subprocess (+ its child
# whisper/ffmpeg tree) immediately. _SUB_PROCS: project → Popen; _SUB_CANCEL: projects asked to stop.
_SUB_PROCS = {}
_SUB_CANCEL = set()

def _kill_proc_tree(proc):
    if not proc or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           creationflags=_NO_WINDOW, capture_output=True)
        else:
            proc.terminate()
    except Exception as _qe:
        quiet(_qe, "_kill_proc_tree")

def _run_align(name, wd, audio, docx, out, model, vad, step, lang="en"):
    """Run one alignment pass of vsl_align_srt.py as a subprocess (its own CWD = wd,
    so all caches — words_*.tsv, silence_all.log — land in the project subtitle dir)."""
    set_sub_status(name, status="running", step=step, error=None)
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out), VSL_LANG=lang)
    # Run under console python inside a HIDDEN console (not CREATE_NO_WINDOW): the aligner's OWN
    # child processes (whisper's ffmpeg) then inherit that hidden console and never pop a black
    # window. CREATE_NO_WINDOW would leave the parent console-less, so each grandchild ffmpeg
    # allocates its own visible console instead.
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _cand = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_cand):
                exe = _cand
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0   # SW_HIDE
    args = [exe, str(SRT_SCRIPT), model]
    if vad:
        args.append("--vad")
    log_path = wd / "align.log"
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"\n===== {step} =====\n"); log.flush()
        # Popen (not run) so a Stop request can kill this + its child whisper/ffmpeg tree mid-pass.
        proc = subprocess.Popen(args, cwd=str(wd), env=env,
                                stdout=log, stderr=subprocess.STDOUT,
                                startupinfo=si, creationflags=cf)
        _SUB_PROCS[name] = proc
        try:
            proc.wait()
        finally:
            _SUB_PROCS.pop(name, None)
    return proc.returncode

def _audio_dur(path):
    """Duration (seconds) of an audio file via ffprobe. 0 on any failure (progress falls back to a fixed ETA)."""
    try:
        p = subprocess.run(["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", str(path)],
                           capture_output=True, text=True, timeout=20, creationflags=_NO_WINDOW)
        return float((p.stdout or "0").strip() or 0)
    except Exception:
        return 0.0

def _srt_pct(st):
    """Estimated % for a running SRT job. The aligner is an opaque subprocess, so we ASYMPTOTICALLY creep the
    bar within each stage's [floor,ceil] band based on elapsed time vs. an ETA (never quite reaching the ceiling
    until the stage actually finishes and the next stage bumps the floor). Feels like real progress, never stalls
    at 100%. Stages: Preparing 2-8, Synchronizing 8-55, Finalizing 55-95, done -> 100 (set by the route)."""
    import math
    try:
        floor = float(st.get("p_floor", 0)); ceil = float(st.get("p_ceil", floor))
        t0 = float(st.get("p_start", 0)); eta = max(3.0, float(st.get("p_eta", 60)))
        if not t0:
            return int(round(floor))
        el = max(0.0, time.time() - t0)
        frac = 1.0 - math.exp(-2.5 * el / eta)           # 0->~0.92 at el==eta, approaches 1 but never hits it
        return int(round(min(ceil - 0.5, floor + (ceil - floor) * frac)))
    except Exception:
        return int(round(float(st.get("p_floor", 0) or 0)))


def _run_transcribe(name, wd, audio, out_txt, model, lang="en"):
    """Aligner in --transcribe mode → plain text of what the VO ACTUALLY says. Mirrors _run_align's hidden-console
    + kill-tree handling so ⏹ Stop can abort it mid-pass."""
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(wd / "script.docx"), VSL_OUT=str(out_txt), VSL_LANG=lang)
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(c):
                exe = c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    args = [exe, str(SRT_SCRIPT), model, "--vad", "--transcribe"]
    with open(wd / "align.log", "a", encoding="utf-8") as log:
        log.write("\n===== Transcribe (reconcile) =====\n"); log.flush()
        proc = subprocess.Popen(args, cwd=str(wd), env=env, stdout=log, stderr=subprocess.STDOUT,
                                startupinfo=si, creationflags=cf)
        _SUB_PROCS[name] = proc
        try:
            proc.wait()
        finally:
            _SUB_PROCS.pop(name, None)
    try:
        return out_txt.read_text(encoding="utf-8").strip() if out_txt.exists() else ""
    except Exception:
        return ""

def _reconcile_script(script, transcription):
    """Claude rewrites the script to match the real voice-over (audio = truth), keeping brand spellings and
    fixing punctuation. Returns '' on any problem so the caller keeps the original script."""
    if not (script and transcription):
        return ""
    try:
        out = _claude_text(SRT_RECONCILE_SYSTEM,
                           f"SCRIPT:\n{script}\n\nVOICE-OVER TRANSCRIPTION (the truth):\n{transcription}",
                           max_tokens=16000)
        return (out or "").strip()
    except Exception:
        return ""

def _reconcile_sane(before, after):
    """Is this a CORRECTION of the script, or a different text? Claude is handed a Whisper transcript that
    can be nonsense — the wrong language, music over the voice, a half-decoded file — and whatever comes
    back used to be written over the user's script regardless. Undo could take it back, but only if they
    noticed the toast and had not reloaded. Two cheap checks: the length has to be in the same ballpark,
    and the words have to be largely the same ones. Returns (ok, reason_if_not)."""
    b, a = (before or "").split(), (after or "").split()
    if len(b) < 20:
        return True, ""                                  # too short to judge — let it through
    if abs(len(a) - len(b)) > 0.25 * len(b):
        return False, ("the corrected script came back %d words against your %d — too far off to be a "
                       "correction, so your script was left as it is" % (len(a), len(b)))
    same = difflib.SequenceMatcher(None, [w.lower() for w in b], [w.lower() for w in a],
                                   autojunk=False).ratio()
    if same < 0.6:
        return False, ("the corrected script only shares %d%% of your wording — that is a rewrite, not a "
                       "correction, so your script was left as it is" % round(same * 100))
    return True, ""


def _reconcile_step(name, wd, audio, docx, small_m, lang, cancelled):
    """Run STEP 0 in-place: transcribe → reconcile → rewrite script.docx + persist the corrected script to the
    project (Script box) with a backup. All best-effort: any failure leaves the user's script untouched.
    Returns the corrected text (already persisted) or '' if nothing changed."""
    try:
        set_sub_status(name, step="Matching the script to the voice-over…",
                       p_floor=2, p_ceil=18, p_start=time.time(),
                       p_eta=max(20.0, (_audio_dur(audio) or 120.0) * 0.7))
        trans = _run_transcribe(name, wd, audio, wd / "_vo_transcript.txt", small_m, lang)
        if cancelled():
            return ""
        if not trans:
            return ""
        try:
            import docx as _docxlib
            cur = " ".join(p.text for p in _docxlib.Document(str(docx)).paragraphs).strip()
        except Exception:
            cur = ""
        corrected = _reconcile_script(cur, trans)
        if not (corrected and len(corrected) >= 20 and corrected.strip() != (cur or "").strip()):
            return ""
        ok, why = _reconcile_sane(cur, corrected)
        if not ok:
            print("[reconcile] rejected — %s" % why, flush=True)
            set_sub_status(name, reconcile_note=why)     # the SRT still gets made, from the ORIGINAL script
            return ""
        text_to_docx(corrected, docx)                       # align the CORRECTED script
        try:                                                # persist so the Script box shows it (survives reload) + backup
            d2 = load_doc(name) or {}
            d2["script_reconcile_backup"] = d2.get("script_draft") or d2.get("script") or cur
            d2["script_draft"] = corrected
            save_doc(name, d2)
        except Exception as _qe:
            quiet(_qe, "_reconcile_step")
        set_sub_status(name, reconciled_script=corrected)
        return corrected
    except Exception:
        return ""

def _file_sig(p):
    """A cheap identity for a media file: its size plus a hash of its first and last 256 KB."""
    try:
        p = Path(p)
        st = p.stat()
        h = hashlib.md5()
        with open(p, "rb") as fh:
            h.update(fh.read(262144))
            if st.st_size > 524288:
                fh.seek(-262144, 2)
                h.update(fh.read(262144))
        return "%d:%s" % (st.st_size, h.hexdigest())
    except OSError:
        return ""


def _note_aligned_vo(name):
    """Remember which voice-over the subtitles were just aligned to - by content, so copying, syncing
    or re-saving the files on another PC can never make them look stale (or fresh) by accident."""
    d, _ = proj_dir(name)
    vo = d / "voiceover" / "voiceover.mp3"
    try:
        _write_atomic(sub_dir(name) / "aligned_vo.json",
                      json.dumps({"vo_sig": _file_sig(vo) if vo.exists() else "", "at": time.time()}))
    except OSError as _qe:
        quiet(_qe, "_note_aligned_vo")


def run_subtitle_job(name, audio, docx, out, trim_mode=None, lang="en", reconcile=False):
    """One forced-alignment pass -> the SRT. When reconcile=True, a STEP 0 first corrects the script to
    the actual voice-over (see _reconcile_step), which is what the small model is still for.

    This used to run TWICE, small then medium, so the second pass could patch the first's alignment
    collapses. That was a Whisper workaround; the merge has been off since the switch to MMS-FA, but the
    second run stayed and re-aligned the whole audio from scratch for nothing. Verified byte-identical
    SRTs before removing it, on a 2.5-minute and a 12.5-minute VSL - only the wall clock changed
    (31s -> 14s on the short one)."""
    wd = sub_dir(name)
    small_m, med_m = _align_models(lang)
    _SUB_CANCEL.discard(name)
    set_sub_status(name, status="running", step="Preparing…", p_floor=2, p_ceil=8,
                   p_start=time.time(), p_eta=8, error=None)
    _est = max(30.0, (_audio_dur(audio) or 120.0) * 1.5)   # rough per-pass ETA; the asymptote handles over/under
    def _cancelled():
        if name in _SUB_CANCEL:
            _SUB_CANCEL.discard(name)
            set_sub_status(name, status="idle", step="", error=None, srt=None)   # user stopped it
            return True
        return False
    try:
        if reconcile and not _cancelled():          # STEP 0 — correct the script to the actual voice-over first
            _reconcile_step(name, wd, audio, docx, small_m, lang, lambda: name in _SUB_CANCEL)
            if _cancelled():
                return
        set_sub_status(name, p_floor=8, p_ceil=95, p_start=time.time(), p_eta=_est)
        rc = _run_align(name, wd, audio, docx, out, med_m, True, "Synchronizing subtitles…", lang)
        if _cancelled():
            return
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed (exit {rc}); see align.log")
            return
        if not Path(out).exists():
            set_sub_status(name, status="error", error="alignment finished but no SRT was produced; see align.log")
            return
        _note_aligned_vo(name)
        # The pauses come out HERE, not before the alignment: only now does anything know where the
        # words are, and a cut placed between two of them cannot damage either.
        trimmed_rel = None
        if trim_mode:
            set_sub_status(name, step="Shortening the pauses…")
            # Deliberately NOT guarded: if the trim cannot be done safely the run stops and says so.
            # Quietly carrying on with the untrimmed take is how a problem reaches the timeline unnoticed.
            got = _trim_after_align(wd, audio, out, trim_mode)
            if got:
                trimmed_rel, _removed = got
        rel = f"subtitle/{Path(out).name}"
        set_sub_status(name, status="done", step="Done", srt=rel,
                       srt_name=Path(out).name, trimmed=trimmed_rel, error=None)
    except Exception as e:
        set_sub_status(name, status="error", error=str(e))

# ---- routes: auth -----------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    # The login UI is now an overlay inside the home page (single page), submitted via fetch.
    if request.method == "GET":
        return redirect(url_for("index"))
    u = request.form.get("username", "").strip()
    p = request.form.get("password", "")
    if check_login(u, p):
        session.permanent = True
        session["user"] = u
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Wrong username or password."}), 401

@app.route("/logout")
def logout():
    session.clear()
    # Redirect straight to "/" (the home shows the login gate when signed out) and forbid caching —
    # a cached 302 was letting a repeat sign-out skip the server, so the session never cleared.
    resp = redirect("/")
    resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

@app.route("/self-test", methods=["POST"])
def self_test():
    """FULL SYSTEM CHECK from the login screen (NO login needed — it lives outside /api/, which is the only
    gated prefix). Runs self_test.py in a SUBPROCESS with this same runtime python (so it tests the exact
    environment the app uses: bundled ffmpeg, torch+CUDA, whisper/LaMa models, media, data, every route).
    Returns the machine-readable summary + the full console text for the modal. Does NOT need Claude connected
    — Claude is just one (optional) line it reports on."""
    import subprocess as _sp, sys as _sys, json as _json
    script = BASE / "self_test.py"
    if not script.exists():
        return jsonify({"ok": False, "error": "self_test.py not found next to the app."}), 500
    try:
        p = _sp.run([_sys.executable, str(script), "--json"],
                    capture_output=True, text=True, timeout=240, cwd=str(BASE))
    except _sp.TimeoutExpired:
        return jsonify({"ok": False, "error": "System check timed out (240s)."}), 504
    except Exception as e:
        return jsonify({"ok": False, "error": repr(e)}), 500
    out = p.stdout or ""
    data = None
    text_lines = []
    for line in out.splitlines():
        if line.startswith("##JSON##"):
            try:
                data = _json.loads(line[len("##JSON##"):].strip())
            except Exception:
                data = None
        else:
            text_lines.append(line)
    text = "\n".join(text_lines).strip()
    if data is None:                                    # parsing the summary failed → still hand back the raw log
        data = {"ok": p.returncode == 0, "summary": {"pass": 0, "warn": 0, "fail": 0}, "results": []}
    data["text"] = text or (p.stderr or "").strip()
    return jsonify(data)

# ---- routes: pages ----------------------------------------------------------
@app.route("/")
def index():
    static = BASE / "static"
    try:
        v = str(int(max((static / "app.js").stat().st_mtime, (static / "style.css").stat().st_mtime)))
    except Exception:
        v = "1"
    try:
        appver = (BASE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        appver = ""
    return render_template("index.html", v=v, authed=bool(session.get("user")), appver=appver)

# ---- routes: API keys (let a new user plug in their own keys from the UI) ----
_KEY_MAP = {   # UI field -> .env variable
    "kie": "KIE_API_KEY", "cloud_name": "CLOUDINARY_CLOUD_NAME",
    "cloud_key": "CLOUDINARY_API_KEY", "cloud_secret": "CLOUDINARY_API_SECRET",
    "elevenlabs": "ELEVENLABS_API_KEY",
    "wavespeed": "WAVESPEED_API_KEY",
}
@app.route("/api/keys/<project>")
def api_get_keys(project):
    # before_request already activated this project's keys into the globals
    return jsonify({"kie": _key('KIE_API_KEY'), "cloud_name": _key('CLOUDINARY_CLOUD_NAME'), "cloud_key": _key('CLOUDINARY_API_KEY'),
                    "cloud_secret": _key('CLOUDINARY_API_SECRET'), "elevenlabs": _key('ELEVENLABS_API_KEY'),
                    "keys_from": (_read_proj_keys(project) or {}).get(_COPIED_FROM, "")})

@app.route("/api/keys/<project>", methods=["POST"])
def api_set_keys(project):
    """Save API keys FOR THIS PROJECT (into <project>/keys.json), so they travel with export/import and
    are used whenever this project is open — regardless of which membership opens it."""
    global _KEYS_PROJECT
    data = request.get_json(force=True) or {}
    updates = {_KEY_MAP[k]: str(data[k]).strip() for k in _KEY_MAP if k in data}
    if not updates:
        return jsonify({"error": "no keys provided"}), 400
    keys = _read_proj_keys(project) or {n: "" for n in _KEY_ENV_NAMES}
    keys.update(updates)
    if "keys_from" in data:                       # remember which project these were copied from (UI only)
        keys[_COPIED_FROM] = str(data.get("keys_from") or "").strip()
    try:
        _write_proj_keys(project, keys)
    except Exception as e:
        return jsonify({"error": f"could not save keys: {e}"}), 500
    _set_key_globals(keys)
    _use_keys(keys)
    _REF_URL_CACHE.clear()
    _KEYS_PROJECT = project
    return jsonify({"ok": True})

# keys.json also remembers WHICH project the keys were copied from (_COPIED_FROM), purely so the
# "Get from a project" dropdown can show that choice again next time. It is not a credential.
_COPIED_FROM = "_COPIED_FROM"

def _keys_to_ui(keys):
    keys = keys or {}
    return {"kie": keys.get("KIE_API_KEY", ""), "cloud_name": keys.get("CLOUDINARY_CLOUD_NAME", ""),
            "cloud_key": keys.get("CLOUDINARY_API_KEY", ""), "cloud_secret": keys.get("CLOUDINARY_API_SECRET", ""),
            "elevenlabs": keys.get("ELEVENLABS_API_KEY", ""), "wavespeed": keys.get("WAVESPEED_API_KEY", ""),
            "keys_from": keys.get(_COPIED_FROM, "")}

@app.route("/api/global-keys")
def api_get_global_keys():
    """The GLOBAL (out-of-project) Studio's own keys — shown in Studio -> Keys."""
    return jsonify(_keys_to_ui(_read_global_keys()))

@app.route("/api/global-keys", methods=["POST"])
def api_set_global_keys():
    data = request.get_json(force=True) or {}
    updates = {_KEY_MAP[k]: str(data[k]).strip() for k in _KEY_MAP if k in data}
    if not updates:
        return jsonify({"error": "no keys provided"}), 400
    keys = _read_global_keys() or {n: "" for n in _KEY_ENV_NAMES}
    keys.update(updates)
    if "keys_from" in data:                       # remember which project these were copied from (UI only)
        keys[_COPIED_FROM] = str(data.get("keys_from") or "").strip()
    try:
        _write_global_keys(keys)
    except Exception as e:
        return jsonify({"error": f"could not save keys: {e}"}), 500
    global _KEYS_PROJECT; _KEYS_PROJECT = None   # force a re-activate on the next request
    return jsonify({"ok": True})

@app.route("/api/project-keys/<project>")
def api_read_project_keys(project):
    """Read a project's keys WITHOUT switching the active key context — powers the 'Get from a project'
    dropdown in the global Studio's Keys panel (copies that project's keys into the form)."""
    return jsonify(_keys_to_ui(_read_proj_keys(project) or {}))

# ---- Kie.ai credit balance + a small spend ledger (real spend = the drop between balance snapshots) ----
KIE_CREDIT_URL = "https://api.kie.ai/api/v1/chat/credit"

def _ledger_path():
    return DATA_DIR / "credit_ledger.json"     # global, shared across users/projects (keyed by the account key)

def _read_ledger():
    p = _ledger_path()
    if p.exists():
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return {}
    return {}

def _write_ledger(d):
    try: _ledger_path().write_text(json.dumps(d), encoding="utf-8")
    except Exception as _qe: quiet(_qe, "_write_ledger")

def _key_hash():
    return hashlib.md5(_key('KIE_API_KEY').encode()).hexdigest()[:10] if _key('KIE_API_KEY') else None

def fetch_kie_balance():
    def _do():
        r = requests.get(KIE_CREDIT_URL, headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}"}, timeout=30)
        d = r.json()
        if d.get("code") == 200 and isinstance(d.get("data"), (int, float)):
            return float(d["data"])
        raise RuntimeError(d.get("msg") or "could not read balance")
    return _retry(_do, tries=3)

@app.route("/api/credits/<project>")
def api_credits(project):
    """Live Kie.ai balance for THIS project's key, plus a spend history derived from balance snapshots.
    Each check appends a {t, balance} snapshot to a per-account ledger; the drop between snapshots = spend."""
    if not _key('KIE_API_KEY'):
        return jsonify({"keyPresent": False})
    try:
        bal = fetch_kie_balance()
    except Exception as e:
        return jsonify({"keyPresent": True, "error": str(e)}), 502
    kh = _key_hash()
    now = int(time.time())
    led = _read_ledger()
    arr = led.get(kh, [])
    # record a snapshot when the balance moved, or the last one is older than 20s (throttle duplicates)
    if not arr or abs(arr[-1].get("balance", -1) - bal) >= 0.001 or (now - arr[-1].get("t", 0)) > 20:
        arr.append({"t": now, "balance": bal})
        arr = arr[-80:]
        led[kh] = arr
        _write_ledger(led)
    spends = []
    for i in range(1, len(arr)):
        drop = arr[i - 1]["balance"] - arr[i]["balance"]     # positive = credits spent
        if drop >= 0.001:
            spends.append({"t": arr[i]["t"], "spent": round(drop, 2), "balance": round(arr[i]["balance"], 2)})
    spends.reverse()                                          # newest first
    total_tracked = round(sum(s["spent"] for s in spends), 2)
    return jsonify({"keyPresent": True, "balance": round(bal, 2), "history": spends[:25],
                    "tracked_spend": total_tracked, "since": (arr[0]["t"] if arr else now)})


@app.route("/api/translate", methods=["POST"])
def api_translate():
    data = request.get_json(force=True) or {}
    texts = data.get("texts") or []
    source = (data.get("source") or "").strip()
    if not isinstance(texts, list) or not texts:
        return jsonify({"translations": []})
    numbered = "\n".join(f"{i+1}. {str(t)}" for i, t in enumerate(texts))
    user = (f"Source language: {source}.\nTranslate to Turkish:\n{numbered}" if source
            else f"Translate to Turkish:\n{numbered}")
    def _batch(items):
        arr = _parse_json_array(_claude_text(_TRANSLATE_SYSTEM, (
            f"Source language: {source}.\nTranslate to Turkish:\n" if source else "Translate to Turkish:\n")
            + "\n".join(f"{i+1}. {str(t)}" for i, t in enumerate(items)), max_tokens=6000))
        out = [str(x) for x in arr][:len(items)]
        while len(out) < len(items):
            out.append("")
        return out

    trs = None
    for _ in range(3):                       # a flaky reply used to lose the whole block of ten
        try:
            trs = _batch(texts)
            break
        except Exception:
            trs = None
    if trs is None:
        # ...and if the block still will not come back, take the lines one at a time so ONE bad line
        # cannot take nine good ones down with it
        trs, any_ok = [], False
        for t in texts:
            try:
                trs.append(_batch([t])[0]); any_ok = True
            except Exception:
                trs.append("")
        if not any_ok:
            return jsonify({"error": "translation service did not respond"}), 500
    return jsonify({"translations": trs})

# ---- routes: sync folder (Google Drive/OneDrive/Dropbox desktop) + export/import ----
# A single machine-level "sync folder" (a folder that a cloud-sync app mirrors between PCs). Export
# writes a project .zip there; the other PC lists + imports those zips. No API keys, no size limits.
APP_CONFIG_PATH = DATA_DIR / "app_config.json"
youtube.CACHE_DIR = DATA_DIR      # topic searches are cached on disk so the same question is free

def _load_config():
    try:
        return json.loads(APP_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_config(cfg):
    try:
        APP_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "_save_config")

def _sync_dir():
    p = (_load_config().get("sync_dir") or "").strip()
    return Path(p) if p else None

@app.route("/api/config")
def api_get_config():
    cfg = _load_config()
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir()),
                    "notif_sound": cfg.get("notif_sound", True)})

@app.route("/api/config", methods=["POST"])
def api_set_config():
    data = request.get_json(force=True) or {}
    cfg = _load_config()
    if "sync_dir" in data:
        cfg["sync_dir"] = str(data["sync_dir"]).strip()
    if "notif_sound" in data:
        cfg["notif_sound"] = bool(data["notif_sound"])
    _save_config(cfg)
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"ok": True, "sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir()),
                    "notif_sound": cfg.get("notif_sound", True)})

_MANIFEST_NAME = "__vsl_manifest__.json"
_MUSIC_PREFIX = "__music__/"            # bundled Background Music tracks live here inside the zip

def _bundled_music(doc):
    """(src_path, arcname) for every Background Music track this project's plan uses — so the export
    is self-contained and plays/renders identically even on a PC that lacks that track."""
    out, seen = [], set()
    for seg in (doc.get("music_plan") or []):
        emo, track = seg.get("emotion"), seg.get("track")
        key = f"{emo}/{track}"
        if emo and track and key not in seen:
            seen.add(key)
            src = BGM_ROOT / emo / track
            if src.exists():
                out.append((src, f"{_MUSIC_PREFIX}{emo}/{track}"))
    return out

_EXPORT_JOBS = {}                        # job_id -> {pct, done, error, file, title, scenes}
_EXPORT_GUARD = threading.Lock()

def _run_export(job_id, d, safe, manifest, sd):
    tmp = sd / (safe + ".zip.part")
    final = sd / (safe + ".zip")
    try:
        files = []                       # (src, arcname) project files under <safe>/…
        for root, _dirs, fns in os.walk(d):
            if "__pycache__" in root:
                continue
            for fn in fns:
                fp = Path(root) / fn
                files.append((fp, str(Path(safe) / fp.relative_to(d))))
        try:
            doc = _peek_doc(d / "scenes.json")
        except Exception:
            doc = {}
        files += _bundled_music(doc)     # self-contained: carry the music too
        total = sum(fp.stat().st_size for fp, _ in files) or 1
        written = 0
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED, allowZip64=True) as z:
            z.writestr(_MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
            for fp, arc in files:
                z.write(fp, arc)
                written += fp.stat().st_size
                _EXPORT_JOBS[job_id]["pct"] = min(99, int(written * 100 / total))
        if final.exists():
            final.unlink()
        tmp.replace(final)
        _EXPORT_JOBS[job_id].update(pct=100, done=True, file=final.name)
    except Exception as e:
        try:
            tmp.unlink()
        except Exception as _qe:
            quiet(_qe, "_run_export")
        _EXPORT_JOBS[job_id].update(done=True, error=str(e))

@app.route("/api/projects/<project>/export", methods=["POST"])
def api_export_project(project):
    """Kick off a background zip of the project folder (+ its music) into the sync folder as <name>.zip
    (stored = fast copy since media is already compressed). Returns a job id to poll for progress."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    sd = _sync_dir()
    if not sd:
        return jsonify({"error": "no-sync-dir"}), 400
    if not sd.is_dir():
        return jsonify({"error": "sync-dir-missing"}), 400
    try:
        doc = _peek_doc(d / "scenes.json")
    except Exception:
        doc = {}
    manifest = {"name": safe, "title": doc.get("title", safe), "scenes": len(doc.get("scenes", [])),
                "exported_by": _ACTIVE_USER or "", "exported_at": datetime.now().isoformat(timespec="seconds")}
    job_id = uuid.uuid4().hex
    _EXPORT_JOBS[job_id] = {"pct": 0, "done": False, "error": None, "file": None, "title": manifest["title"]}
    _KeyThread(target=_run_export, args=(job_id, d, safe, manifest, sd), daemon=True).start()
    return jsonify({"ok": True, "job": job_id, "title": manifest["title"]})

@app.route("/api/export-status/<job>")
def api_export_status(job):
    j = _EXPORT_JOBS.get(job)
    if not j:
        return jsonify({"error": "not-found"}), 404
    return jsonify(j)

def _zip_ready(zp, st=None):
    """True if the export zip is FULLY here locally and safe to import — i.e. NOT a Google-Drive cloud
    placeholder and NOT still downloading. Google Drive for Desktop marks a not-yet-downloaded file with the
    Windows OFFLINE / recall-on-open attributes; a file still being written fails the zip-directory read. We
    check the attributes FIRST, and then validate the zip directory in a worker thread with a HARD TIMEOUT so
    that a placeholder which WOULD block on read (some Drive modes don't set the attribute) can never hang the
    request — if it can't validate quickly, we treat it as still-syncing."""
    try:
        st = st or zp.stat()
        attrs = getattr(st, "st_file_attributes", 0)          # 0 on non-Windows
        # FILE_ATTRIBUTE_OFFLINE 0x1000 | RECALL_ON_OPEN 0x40000 | RECALL_ON_DATA_ACCESS 0x400000
        if attrs & (0x1000 | 0x40000 | 0x400000):
            return False
        if st.st_size < 100:                                  # too small to be a real export → still arriving
            return False
    except Exception:
        return False
    res = {"ok": False}
    def _probe():
        try:
            with zipfile.ZipFile(zp) as z:                    # reads the central directory; partial/truncated zip raises
                z.namelist()
            res["ok"] = True
        except Exception:
            res["ok"] = False
    th = _KeyThread(target=_probe, daemon=True)
    th.start()
    th.join(timeout=2.5)                                      # placeholder read would block here → bail as "still syncing"
    if th.is_alive():
        return False
    return res["ok"]

@app.route("/api/imports")
def api_list_imports():
    """List the project zips sitting in the sync folder (with manifest metadata for the picker). Each item also
    carries `ready`: False while the file is still syncing down from Google Drive (a cloud placeholder or a
    half-downloaded zip) — the UI shows those as 'Syncing…' and only lets you import once ready flips True."""
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"sync_ok": False, "items": []})
    items = []
    for zp in sorted(sd.glob("*.zip")):
        try:
            st = zp.stat()
        except Exception:
            continue
        ready = _zip_ready(zp, st)
        info = {"file": zp.name, "title": zp.stem, "name": zp.stem, "scenes": None,
                "exported_by": "", "exported_at": "", "size": st.st_size, "ready": ready}
        if ready:                                             # only read the manifest once the zip is fully local
            try:
                with zipfile.ZipFile(zp) as z:
                    if _MANIFEST_NAME in z.namelist():
                        m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                        info.update({"title": m.get("title", info["title"]), "name": m.get("name", info["name"]),
                                     "scenes": m.get("scenes"), "exported_by": m.get("exported_by", ""),
                                     "exported_at": m.get("exported_at", "")})
            except Exception:
                info["ready"] = False                         # became unreadable mid-read → treat as still syncing
        items.append(info)
    return jsonify({"sync_ok": True, "items": items})

@app.route("/api/imports/delete", methods=["POST"])
def api_delete_import():
    """Delete one export zip from the sync folder (housekeeping from the import window)."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    try:
        if zp.exists():
            zp.unlink()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True})

@app.route("/api/import", methods=["POST"])
def api_import_project():
    """Pull one zip from the sync folder into THIS user's projects. overwrite=True replaces a project
    of the same name (2-PC round-trip); otherwise it's auto-renamed so nothing is clobbered. Bundled
    music (__music__/…) is restored into the local Background Music folder."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))     # basename → no path traversal
    overwrite = bool(data.get("overwrite"))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    if not zp.exists():
        return jsonify({"error": "not-found"}), 404
    base = zp.stem
    try:
        with zipfile.ZipFile(zp) as z:
            if _MANIFEST_NAME in z.namelist():
                m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                base = m.get("name") or base
    except Exception as _qe:
        quiet(_qe, "api_import_project")
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", base).strip("-") or "project"
    if overwrite and (PROJECTS / safe).exists():
        target = safe                            # replace the existing same-named project
    else:
        target, n = safe, 1
        while (PROJECTS / target).exists():      # never clobber unless explicitly overwriting
            n += 1
            target = f"{safe}-import" + ("" if n == 2 else str(n))
    dest = PROJECTS / target
    tmp = PROJECTS / (target + ".importing")
    try:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(zp) as z:
            for nm in z.namelist():
                if nm == _MANIFEST_NAME:
                    continue
                if nm.startswith(_MUSIC_PREFIX):        # restore bundled music into Background Music/
                    rel = nm[len(_MUSIC_PREFIX):]
                    if not rel or nm.endswith("/"):
                        continue
                    mp = (BGM_ROOT / rel)
                    try:
                        if not mp.exists():             # never overwrite a shipped track
                            mp.parent.mkdir(parents=True, exist_ok=True)
                            with z.open(nm) as src, open(mp, "wb") as f:
                                shutil.copyfileobj(src, f)
                    except Exception as _qe:
                        quiet(_qe, "api_import_project")
                    continue
                rel = nm.split("/", 1)[1] if "/" in nm else nm   # strip the top folder (original name)
                if not rel:
                    continue
                outp = tmp / rel
                if nm.endswith("/"):
                    outp.mkdir(parents=True, exist_ok=True)
                    continue
                outp.parent.mkdir(parents=True, exist_ok=True)
                with z.open(nm) as src, open(outp, "wb") as f:
                    shutil.copyfileobj(src, f)
        sp = tmp / "scenes.json"                 # retarget the project id to its new folder name
        if sp.exists():
            try:
                jdoc = json.loads(sp.read_text(encoding="utf-8"))
                jdoc["name"] = target
                sp.write_text(json.dumps(jdoc, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception as _qe:
                quiet(_qe, "api_import_project")
        if dest.exists():                        # overwrite: swap in the fresh copy atomically-ish
            shutil.rmtree(dest, ignore_errors=True)
        tmp.replace(dest)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({"error": str(e)}), 500
    title = target
    try:
        title = _peek_doc(dest / "scenes.json").get("title", target)
    except Exception as _qe:
        quiet(_qe, "api_import_project")
    return jsonify({"ok": True, "name": target, "title": title, "overwritten": overwrite and dest == PROJECTS / safe})

# ---- routes: projects -------------------------------------------------------
@app.route("/api/projects")
def api_projects():
    out = []
    for d in sorted(PROJECTS.iterdir()):
        if d.name.startswith("_"):
            continue          # internal stores (the global Studio's) are not user projects
        if (d / "scenes.json").exists():
            sj = d / "scenes.json"
            doc = json.loads(sj.read_text(encoding="utf-8"))
            created = doc.get("created")            # written on create; older projects fall back to the folder
            if not created:
                try:
                    created = datetime.fromtimestamp(d.stat().st_ctime).isoformat(timespec="seconds")
                except Exception:
                    created = ""
            out.append({"name": d.name, "title": doc.get("title", d.name), "ptype": proj_type(doc),
                        "scenes": len(doc.get("scenes", [])), "created": created})
    return jsonify(out)


# ---- home-screen project GROUPS -------------------------------------------------------------------
# A display layer only: nothing moves on disk, projects keep their own folders. Deleting a group just
# releases its projects back to the ungrouped list.
def _groups_path():
    return PROJECTS.parent / "project_groups.json"


def _read_groups():
    p = _groups_path()
    if p.exists():
        try:
            g = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(g, dict):
                g.setdefault("groups", []); g.setdefault("assign", {})
                return g
        except Exception as _qe:
            quiet(_qe, "_read_groups")
    return {"groups": [], "assign": {}}


_GROUP_INHERIT = ("channel", "brief", "audience")


def _group_donor(assign, gid, exclude):
    """The project in this group with the most of the shared settings already filled in."""
    best, score = None, -1
    for proj, g in assign.items():
        if g != gid or proj == exclude:
            continue
        d = load_doc(proj)
        if not d:
            continue
        n = sum(1 for k in _GROUP_INHERIT if d.get(k))
        if n > score:
            best, score = d, n
    return best if score > 0 else None


def _inherit_group_settings(old_assign, new_assign):
    """For every project that just joined a group, copy the group's channel settings into its blanks."""
    for proj, gid in new_assign.items():
        if old_assign.get(proj) == gid:
            continue                                  # it was already in this group
        doc = load_doc(proj)
        if doc is None:
            continue
        donor = _group_donor(new_assign, gid, proj)
        if donor is None:
            continue
        wrote = []
        for k in _GROUP_INHERIT:
            if doc.get(k) or not donor.get(k):
                continue                              # never overwrite what the project already says
            doc[k] = copy.deepcopy(donor[k])
            wrote.append(k)
        if wrote:
            save_doc(proj, doc)


@app.route("/api/project-groups")
def api_get_project_groups():
    return jsonify(_read_groups())


@app.route("/api/project-groups", methods=["POST"])
def api_set_project_groups():
    body = request.get_json(force=True) or {}
    groups = [{"id": str(g.get("id") or "").strip(),
               "name": str(g.get("name") or "").strip() or "Group",
               "collapsed": bool(g.get("collapsed"))}
              for g in (body.get("groups") or []) if str(g.get("id") or "").strip()]
    valid = {g["id"] for g in groups}
    assign = {str(k): str(v) for k, v in (body.get("assign") or {}).items() if str(v) in valid}
    # A group IS a channel. Dropping a project into one should hand it the channel's identity - its
    # name, its links, what the channel is about and who watches it - instead of making you retype it.
    # Only ever FILLS BLANKS: anything the project already has is left exactly as it is.
    try:
        _inherit_group_settings(_read_groups().get("assign") or {}, assign)
    except Exception as _qe:
        quiet(_qe, "api_set_project_groups")
    try:
        _groups_path().write_text(json.dumps({"groups": groups, "assign": assign},
                                             ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        return jsonify({"error": f"could not save groups: {e}"}), 500
    return jsonify({"ok": True})

# The global Studio's Testimonials need somewhere to keep their roster, their cards and their media.
# Every testimonial route is already <project>-shaped, so the global Studio gets a project of its own
# rather than a second, parallel implementation of the same feature. It is hidden from the project list.
STUDIO_PROJECT = "_studio"


def _ensure_studio_project():
    doc = load_doc(STUDIO_PROJECT)
    if doc is None:
        doc = {"name": STUDIO_PROJECT, "title": "Studio",
               "created": datetime.now().isoformat(timespec="seconds"),
               "audience": {}, "brief": "", "refs": [], "characters": [], "scenes": [],
               "testimonials": [], "testimonial_cards": []}
        save_doc(STUDIO_PROJECT, doc)
    return doc


@app.route("/api/studio-testimonials")
def api_studio_testimonials():
    """Open (creating on first use) the store behind the global Studio's Testimonials tab."""
    doc = _ensure_studio_project()
    return jsonify({"project": STUDIO_PROJECT,
                    "testimonials": doc.get("testimonials", []),
                    "testimonial_cards": doc.get("testimonial_cards", [])})


@app.route("/api/projects", methods=["POST"])
def api_create_project():
    body = request.get_json(force=True)
    name = body.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    d, safe = proj_dir(name)
    if (d / "scenes.json").exists():
        return jsonify({"error": "project exists", "name": safe}), 409
    doc = {"name": safe, "title": name, "created": datetime.now().isoformat(timespec="seconds"),
           "ptype": "youtube" if str(body.get("ptype")) == "youtube" else DEFAULT_PTYPE,
           "audience": body.get("audience", {}), "brief": body.get("brief", ""), "refs": [], "characters": [], "scenes": []}
    save_doc(safe, doc)
    try:
        _write_proj_keys(safe, {n: "" for n in _KEY_ENV_NAMES})   # start EMPTY (no seeding) → user fills keys per project
    except Exception as _qe:
        quiet(_qe, "api_create_project")
    return jsonify({"name": safe})

@app.route("/api/projects/<project>/rename", methods=["POST"])
@_locked
def api_rename_project(project):
    """Rename a project's display title (the folder / id stays the same)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    title = (request.get_json(force=True).get("title") or "").strip()
    if not title:
        return jsonify({"error": "title required"}), 400
    doc["title"] = title
    save_doc(project, doc)
    return jsonify({"ok": True, "title": title})

def trash_dir():
    """Per-user recycle bin, sibling of the projects folder so it's never listed as a project."""
    return PROJECTS.parent / "_trash"

def _safe_trash_child(tname):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", tname).strip("-") or "project"
    return trash_dir() / safe, safe

@app.route("/api/projects/<project>", methods=["DELETE"])
def api_delete_project(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    mode = (request.args.get("mode") or "disk").lower()
    if mode == "dashboard":
        # SOFT delete — move the folder into _trash (files stay on disk, fully restorable).
        td = trash_dir(); td.mkdir(parents=True, exist_ok=True)
        title = safe
        try:
            title = _peek_doc(d / "scenes.json").get("title", safe)
        except Exception as _qe:
            quiet(_qe, "api_delete_project")
        dest = td / safe
        n = 2
        while dest.exists():
            dest = td / f"{safe}-{n}"; n += 1
        shutil.move(str(d), str(dest))
        try:
            (dest / "__trashinfo__.json").write_text(json.dumps(
                {"orig": safe, "title": title, "deleted": datetime.now().isoformat(timespec="seconds")}),
                encoding="utf-8")
        except Exception as _qe:
            quiet(_qe, "api_delete_project")
        return jsonify({"ok": True, "mode": "dashboard", "trash": dest.name})
    # HARD delete — remove the folder from disk permanently.
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True, "mode": "disk"})

@app.route("/api/trash")
def api_trash():
    out = []
    td = trash_dir()
    if td.exists():
        for d in sorted(td.iterdir()):
            if not d.is_dir() or not (d / "scenes.json").exists():
                continue
            info = {}
            ip = d / "__trashinfo__.json"
            if ip.exists():
                try: info = json.loads(ip.read_text(encoding="utf-8"))
                except Exception: info = {}
            try:
                doc = _peek_doc(d / "scenes.json")
                nsc = len(doc.get("scenes", []))
                title = info.get("title") or doc.get("title", d.name)
            except Exception:
                nsc = 0; title = info.get("title") or d.name
            out.append({"name": d.name, "orig": info.get("orig", d.name),
                        "title": title, "scenes": nsc, "deleted": info.get("deleted", "")})
    out.sort(key=lambda x: x.get("deleted", ""), reverse=True)
    return jsonify(out)

@app.route("/api/trash/<tname>/restore", methods=["POST"])
def api_trash_restore(tname):
    d, safe = _safe_trash_child(tname)
    if not (d / "scenes.json").exists():
        abort(404)
    orig = safe
    ip = d / "__trashinfo__.json"
    if ip.exists():
        try: orig = json.loads(ip.read_text(encoding="utf-8")).get("orig", safe)
        except Exception as _qe: quiet(_qe, "api_trash_restore")
    dest = PROJECTS / (re.sub(r"[^a-zA-Z0-9_-]", "-", orig).strip("-") or "project")
    base = dest
    n = 2
    while dest.exists():
        dest = base.parent / f"{base.name}-{n}"; n += 1
    shutil.move(str(d), str(dest))
    try: (dest / "__trashinfo__.json").unlink()
    except Exception as _qe: quiet(_qe, "api_trash_restore")
    title = dest.name
    try:
        sp = dest / "scenes.json"
        doc = json.loads(sp.read_text(encoding="utf-8"))
        doc["name"] = dest.name
        title = doc.get("title", dest.name)
        sp.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as _qe: quiet(_qe, "api_trash_restore")
    return jsonify({"ok": True, "name": dest.name, "title": title})

@app.route("/api/trash/<tname>", methods=["DELETE"])
def api_trash_delete(tname):
    d, safe = _safe_trash_child(tname)
    if not d.exists():
        abort(404)
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True})

@app.route("/api/projects/<project>/duplicate", methods=["POST"])
def api_duplicate_project(project):
    """Deep-copy a project (all files + scenes.json) into a NEW, fully independent project. The folder
    gets the next -vN version; the display title gets a bumped ' vN'. Editing one never touches the other."""
    src, safe = proj_dir(project)
    if not (src / "scenes.json").exists():
        abort(404)
    doc = load_doc(project)
    # unique folder name: bump a trailing -vN (or add -v2), skipping any that already exist
    m = re.match(r"^(.*?)[-_ ]v(\d+)$", safe, re.I)
    stem, n = (m.group(1), int(m.group(2))) if m else (safe, 1)
    while True:
        n += 1
        new_name = f"{stem}-v{n}"
        if not (PROJECTS / new_name).exists():
            break
    # display title: bump a trailing vN, else append ' v2'
    tm = re.match(r"^(.*?)[-_ ]v(\d+)$", (doc.get("title") or "").strip(), re.I)
    new_title = (f"{tm.group(1).strip()} v{int(tm.group(2)) + 1}" if tm
                 else f"{(doc.get('title') or stem).strip()} v2")
    shutil.copytree(src, PROJECTS / new_name)
    d2 = _peek_doc(PROJECTS / new_name / "scenes.json")
    d2["name"], d2["title"] = new_name, new_title
    (PROJECTS / new_name / "scenes.json").write_text(json.dumps(d2, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"name": new_name, "title": new_title})

# ---- routes: scenes ---------------------------------------------------------
@app.route("/api/scenes/<project>")
def api_get_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    # Opening a YouTube project is the earliest honest moment to start fetching the depth model, so the
    # first render does not stop to wait for 99 MB. Fire and forget; a render that arrives early waits.
    if is_youtube(doc):
        try:
            import parallax as _px
            _px.prefetch()
        except Exception as _qe:
            quiet(_qe, "api_get_scenes")
    return jsonify(doc)

@app.route("/api/scenes/<project>", methods=["PUT"])
@_locked
def api_save_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    # only allow editable fields to be overwritten from the UI
    incoming = {s["id"]: s for s in body.get("scenes", [])}
    for s in doc["scenes"]:
        u = incoming.get(s["id"])
        if not u:
            continue
        # NOTE: "approved" is intentionally NOT here — it's managed only by the /approve endpoint.
        # Including it let a routine full-doc save (from a text edit) with a stale value clobber a
        # concurrent approve, silently un-approving images.
        # NOTE: "refs" and "ref_free" are intentionally NOT here — like "approved", they are managed ONLY by
        # their dedicated endpoints (add / ref-scene / DELETE ref / ref-lock). Leaving them in let a routine
        # full-doc save (or a racing approve that reassigns DOC) write a stale/empty refs list and silently
        # drop a just-added reference image.
        for f in ("vo", "vo_tr", "note", "prompt", "director_prompt", "cast", "cast_locked", "ingredients", "product", "product_suggested", "split", "split_suggested", "testimonial", "testimonial_n", "tcard_id", "states", "camera", "transition", "cont_of", "video_desc", "video_prompt", "video_cam_lock", "style", "bg", "no_cast", "pure", "model", "video_model", "video_dur", "video_res", "ost_on", "overlays", "fx_on", "grain_on", "atmo", "move", "icon", "sfx", "icon_x", "icon_y", "icon_size", "icons", "packs", "card"):
            if f in u:
                s[f] = u[f]
    if "ptype" in body:                       # Settings can switch a project's type at any time
        doc["ptype"] = "youtube" if str(body["ptype"]) == "youtube" else DEFAULT_PTYPE
    if "script_opts" in body and isinstance(body["script_opts"], dict):
        # what the Script tab's pickers are set to. The director reads the Visuals choice, and Analyze Cast
        # reads the Type - otherwise a project switched from VSL to YouTube keeps describing itself as a VSL.
        o = body["script_opts"]
        doc["script_opts"] = {
            "kind": "youtube" if str(o.get("kind")) == "youtube" else "vsl",
            "visual": str(o.get("visual") or "realistic")[:20],
            "format": str(o.get("format") or "")[:20],
            "title": str(o.get("title") or "")[:300],
            "idea": str(o.get("idea") or "")[:4000],
            "aware": str(o.get("aware") or "problem")[:20],
            "tone": str(o.get("tone") or "story")[:20],
            "lang": str(o.get("lang") or "en")[:5],
            "minutes": max(1, min(60, int(o.get("minutes") or 10))) if str(o.get("minutes") or "").isdigit() else 10,
        }
    if "brief" in body and str(body["brief"]) != str(doc.get("brief") or ""):
        doc["brief_auto"] = False        # the user typed it - Analyze Cast must never overwrite it again
    if "title" in body:
        doc["title"] = body["title"]
    if "script" in body:
        doc["script"] = body["script"]
    if "script_draft" in body:
        doc["script_draft"] = body["script_draft"]   # live, unsaved script text (autosaved before Split) so it survives a restart
    if "audience" in body:
        doc["audience"] = body["audience"]
    if "brief" in body:
        doc["brief"] = body["brief"]
    if "channel" in body and isinstance(body["channel"], dict):
        # the channel's name and the contact links that go under every description
        c = body["channel"]
        doc["channel"] = {k: str(c.get(k) or "")[:300] for k in ("name", "mail", "social", "site")}
    if "subtitle_style" in body:
        doc["subtitle_style"] = body["subtitle_style"]   # global caption look (applies to all subtitles)
    if "subtitle_lang" in body:
        doc["subtitle_lang"] = str(body["subtitle_lang"] or "")[:5]   # picked on the Script & Voice-over page; overrides the audience's country
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/app/version")
def api_app_version():
    """running = the code version this live process loaded at startup; disk = the version.txt on disk right now.
    When they differ, newer app code has been copied in (our publish/sync) but isn't active until a restart —
    the Reload button uses this to offer/auto a restart so the backend changes take effect."""
    return jsonify({"running": _BOOT_VERSION, "disk": _read_version()})

@app.route("/api/video-models")
def api_video_models():
    return jsonify(VIDEO_MODELS)

@app.route("/api/scenes/<project>/insert", methods=["POST"])
@_locked
def api_insert_scene(project):
    """Insert a blank scene after the given id (0 = at the start), then renumber."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    after = request.get_json(force=True).get("after", 0)
    scenes = doc["scenes"]
    idx = 0
    for i, s in enumerate(scenes):
        if s["id"] == after:
            idx = i + 1
            break
    scenes.insert(idx, new_scene(0))
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/duplicate", methods=["POST"])
@_locked
def api_duplicate_scene(project, sid):
    """Clone a scene (all settings + overlays; the copy shares the original's image/video file
    references — regenerating either later just writes new files, so they never clash) and insert
    it right after, then renumber 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc["scenes"]
    idx = next((i for i, s in enumerate(scenes) if s["id"] == sid), None)
    if idx is None:
        return jsonify(doc)
    copy = json.loads(json.dumps(scenes[idx]))   # deep copy
    copy["uid"] = new_uid()                       # its OWN identity — so regenerating it can't overwrite the original's files
    scenes.insert(idx + 1, copy)
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/delete-scene", methods=["POST"])
@_locked
def api_delete_scene(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] != sid]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/delete-scenes", methods=["POST"])
@_locked
def api_delete_scenes(project):
    """Delete several scenes at once (multi-select). Removes all given ids, then renumbers 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = set(request.get_json(force=True).get("ids", []) or [])
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] not in ids]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/reorder", methods=["POST"])
@_locked
def api_reorder(project):
    """Reorder scenes to the given list of ids, then RENUMBER 1..N (so output filenames follow)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    order = request.get_json(force=True).get("order", [])
    by_id = {s["id"]: s for s in doc["scenes"]}
    new = [by_id[i] for i in order if i in by_id]
    new += [s for s in doc["scenes"] if s["id"] not in order]   # safety: keep any missing
    for i, s in enumerate(new, 1):
        s["id"] = i
    doc["scenes"] = new
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/restore", methods=["POST"])
@_locked
def api_restore(project):
    """Undo support: replace the editable doc state (scenes/audience/characters/refs/script) from a
    client snapshot and save it wholesale. Keeps name/title/created."""
    cur = load_doc(project)
    if cur is None:
        abort(404)
    snap = request.get_json(force=True) or {}
    for k in ("scenes", "audience", "characters", "product", "refs", "script", "brief"):
        if k in snap:
            cur[k] = snap[k]
    for s in cur.get("scenes", []):
        norm_scene(s)
    save_doc(project, cur)
    return jsonify(cur)


# Where a long line may be cut. Punctuation only - the piece before keeps its comma, the piece after
# starts with whatever followed it, so the two joined back together are the original line character for
# character. The voice-over alignment depends on that being true.
_CLAUSE_RE = re.compile(r"(?<=[,;:])\s+|\s+[-\u2013\u2014]\s+")


def _split_long_lines(parts, max_words=26, min_words=5, rx=None):
    """One sentence can be far too long for one picture - a 43-word line held a single frame for
    seventeen seconds. Cut those at the punctuation nearest the middle, recursively, until every piece
    is a reasonable shot. Nothing is added, removed or reordered."""
    out = []
    stack = list(parts)
    while stack:
        t = stack.pop(0)
        words = t.split()
        if len(words) <= max_words:
            out.append(t)
            continue
        mid = len(t) / 2.0
        best = None
        for m in (rx or _CLAUSE_RE).finditer(t):
            left, right = t[:m.start()].strip(), t[m.end():].strip()
            if len(left.split()) < min_words or len(right.split()) < min_words:
                continue
            d = abs(m.start() - mid)
            if best is None or d < best[0]:
                best = (d, left, right)
        if best is None:
            out.append(t)          # nowhere sensible to cut - leave it whole rather than mangle it
            continue
        stack.insert(0, best[2])
        stack.insert(0, best[1])
    return out


def _merge_tiny_lines(parts, min_words, max_words):
    """A shot too short to register is as bad as one that never changes - it flashes past and the
    viewer sees a stutter, not a picture. The splitter asks for a floor but does not always keep it,
    so fold any runt into whichever neighbour it actually fits. Nothing is reworded or reordered; a
    runt with no legal neighbour is LEFT SHORT rather than forced into an over-long scene."""
    out = list(parts)
    i = 0
    while i < len(out) and len(out) > 1:
        n = len(out[i].split())
        if n >= min_words:
            i += 1
            continue
        prev_fits = i > 0 and len(out[i - 1].split()) + n <= max_words
        next_fits = i + 1 < len(out) and len(out[i + 1].split()) + n <= max_words
        if next_fits and (not prev_fits or len(out[i + 1].split()) <= len(out[i - 1].split())):
            out[i] = out[i] + " " + out[i + 1]
            del out[i + 1]
        elif prev_fits:
            out[i - 1] = out[i - 1] + " " + out[i]
            del out[i]
            i -= 1
        else:
            i += 1
    return out


HOOK_SECONDS = 15.0        # how much of the opening is cut faster than the rest
HOOK_WPS = 2.88            # measured speaking rate, so seconds and words are the same budget
HOOK_MAX = 11              # about four seconds - the ceiling over the opening
HOOK_MIN = 5               # a beat may be shorter here than in the body; a fast open is deliberate
# Over the opening a FULL STOP counts as a seam too. The merge pass fuses short sentences into one shot,
# and the ordinary clause rule cannot pull them apart again because it only knows commas and dashes.
_HOOK_RE = re.compile(r"(?<=[.!?,;:])\s+|\s+[-–—]\s+")


def _tighten_opening(parts):
    """Cut the opening harder than the rest of the episode.

    The first fifteen seconds are where the viewer decides, and they were coming out as the SLOWEST part
    of the video - three shots of five and a half seconds each - because the general cap is seventeen
    words and the model ignored being asked nicely. Only cuts where a real seam exists; a sentence with
    nowhere sensible to break is left alone rather than mangled.
    """
    if not parts:
        return parts
    budget, i, out = HOOK_SECONDS * HOOK_WPS, 0, []
    while i < len(parts) and budget > 0:
        piece = parts[i]
        n = len(piece.split())
        if n > HOOK_MAX:
            cut = _split_long_lines([piece], max_words=HOOK_MAX, min_words=HOOK_MIN, rx=_HOOK_RE)
            out.extend(cut)
        else:
            out.append(piece)
        budget -= n
        i += 1
    return out + parts[i:]


def split_script(script, youtube=False):
    """Split via Claude. Raises on failure — NO naive fallback (bad splits).

    A YouTube episode is cut FASTER than a VSL: the model gets the pacing rules, and the mechanical
    safety net below drops from 26 words (~9 seconds on one picture) to 17 (~6 seconds), because the
    model does occasionally leave one long line behind and on YouTube that is where viewers leave.
    """
    script = (script or "").strip()
    if not script:
        return []
    system = SPLIT_SYSTEM + (SPLIT_YOUTUBE if youtube else "")
    text = _claude_text(system, script, max_tokens=8000)   # may raise
    parts = [re.sub(r"^\s*\d+[\.\)\-:]\s*", "", ln.strip()) for ln in text.splitlines() if ln.strip()]
    parts = [p for p in parts if p]
    if not parts:
        raise RuntimeError("splitter returned no scenes")
    hi, lo = (17, 7) if youtube else (26, 5)
    parts = _merge_tiny_lines(_split_long_lines(parts, max_words=hi, min_words=lo), lo, hi)
    return _tighten_opening(parts) if youtube else parts

def _parse_json_array(text):
    """Best-effort parse of a JSON array from an LLM reply (tolerates ```json fences / stray prose)."""
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("["), t.rfind("]")
    if a < 0 or b < a:
        raise ValueError("no JSON array")
    return json.loads(t[a:b + 1])



def _detect_cast_raw(script, brief=""):
    """Whole-script cast pass. RAISES on an LLM/parse failure so callers can tell a real error apart from a
    genuine 'nobody recurs' ([]). Use detect_cast() where a silent [] fallback is wanted (e.g. split)."""
    script = (script or "").strip()
    if not script:
        return []
    user = script
    if (brief or "").strip():
        user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
    data = _parse_json_array(_claude_text(CAST_SYSTEM, user, max_tokens=4000, model=PROMPT_MODEL))   # Opus 4.8: cast detection is a simple extraction — near-lossless vs Fable 5, and far fewer Kie overloads
    out, seen = [], set()
    for it in data:
        if not isinstance(it, dict):
            continue
        label = str(it.get("label") or "").strip()
        if not label or label.lower() in seen:
            continue
        seen.add(label.lower())
        out.append({"label": label, "role": str(it.get("role") or "").strip(), "desc": str(it.get("desc") or "").strip()})
    return out

def detect_cast(script, brief=""):
    """Whole-script pass → recurring people [{label, role, desc}]. Never raises (returns [] on any problem)."""
    try:
        return _detect_cast_raw(script, brief)
    except Exception:
        return []


def _detect_ingredients_raw(script, brief=""):
    script = (script or "").strip()
    if not script:
        return []
    user = script
    if (brief or "").strip():
        user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
    data = _parse_json_array(_claude_text(INGREDIENT_SYSTEM, user, max_tokens=3000, model=PROMPT_MODEL))
    out, seen = [], set()
    for it in data:
        if not isinstance(it, dict):
            continue
        name = str(it.get("name") or "").strip()
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        row = {"name": name, "desc": str(it.get("desc") or "").strip()}
        if it.get("molecule"):                       # synthesised compound / molecule -> scientific molecule render ([MOLECULE] tag)
            row["scientific"] = True
        out.append(row)
    return out

def detect_ingredients(script, brief=""):
    """Whole-script pass → the product's named ingredients [{name, desc, scientific?}]. Never raises ([] on any problem)."""
    try:
        return _detect_ingredients_raw(script, brief)
    except Exception:
        return []


def detect_product(script, brief=""):
    """Whole-script pass → {"name": <brand str>, "packs": [<bundle labels>]}. Never raises."""
    script = (script or "").strip()
    if not script:
        return {"name": "", "packs": []}
    try:
        user = script
        if (brief or "").strip():
            user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
        obj = _parse_json_obj(_claude_text(PRODUCT_SYSTEM, user, max_tokens=500, model=PROMPT_MODEL)) or {}
        name = str(obj.get("name") or "").strip()
        packs, seen = [], set()
        for p in (obj.get("packs") or []):
            p = str(p).strip()
            if p and p.lower() not in seen:
                seen.add(p.lower()); packs.append(p)
        return {"name": name, "packs": packs[:12]}
    except Exception:
        return ""



def detect_audience(script, brief="", kind="vsl"):
    """Infer {brief, avatar, location, currency, ages, genders, appearance_exclude} from the script, constrained to
    the audience-field options. Feeds the auto-fill in Analyze Cast (only EMPTY fields). Never raises ({} on error)."""
    try:
        script = (script or "").strip()
        if not script:
            return {}
        user = script if not (brief or "").strip() else ("PROJECT CONTEXT:\n" + brief.strip() + "\n\nSCRIPT:\n" + script)
        sysmsg = AUDIENCE_SYSTEM
        if kind == "youtube":
            # AUDIENCE_SYSTEM says "VSL" throughout; without this the brief comes back calling a YouTube
            # script a VSL, which is what the user then reads in Settings.
            sysmsg = ("IMPORTANT OVERRIDE: this script is NOT a VSL. It is a YouTube video script - there is "
                      "no sales offer to infer. Read every mention of a VSL below as 'this YouTube video', and "
                      "write the brief as what the VIDEO is about and who it is for. Never call it a VSL.\n\n"
                      + AUDIENCE_SYSTEM)
        txt = _claude_text(sysmsg, user, max_tokens=400, model=PROMPT_MODEL)
        import re as _re
        m = _re.search(r"\{.*\}", txt or "", _re.S)
        if not m:
            return {}
        d = json.loads(m.group(0))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}




def _audience_note(aud):
    if not aud:
        return "(no specific audience set)"
    bits = []
    for k, lbl in (("genders", "gender(s)"), ("ages", "age(s)"), ("locations", "location/market"), ("currencies", "currency")):
        v = aud.get(k)
        if v:
            bits.append(f"{lbl}: {', '.join(v)}")
    looks, banned = _split_avoid(aud.get("appearance"))
    if looks:
        bits.append("avoid these looks for ordinary people: " + ", ".join(looks))
    if banned:
        bits.append("NEVER depict any of these, in any scene: " + ", ".join(banned))
    av = (aud.get("avatar") or "").strip()
    if av:
        bits.append("TARGET VIEWER (the relatable/ordinary people this ad speaks to) look like: " + av)
    return "; ".join(bits) if bits else "(no specific audience set)"


def _norm_testimonial_person(tp):
    """Normalize the director's extracted written-testimonial customer (name/gender/location/age/text), or None."""
    if not isinstance(tp, dict):
        return None
    name = str(tp.get("name") or "").strip()
    if not name:
        return None
    g = str(tp.get("gender") or "").strip().lower()
    g = g if g in ("male", "female") else ""
    return {
        "name": name[:80],
        "gender": g,
        "location": str(tp.get("location") or "").strip()[:120],
        "age": str(tp.get("age") or "").strip()[:12],
        "text": str(tp.get("text") or "").strip()[:5000],
    }


DIRECTOR_CHUNK = 25   # scenes described per director call — bounds the JSON OUTPUT so a long script never truncates

# A closeup/extreme crop can hold only ONE localized region. When a shot's description asks for BOTH a
# face/expression AND an action lower on the body (waist/belt/trousers/stomach/hips/lap/knees/feet, or
# hands working down there), those two regions sit too far apart vertically for a tight crop — the image
# model collapses them into mangled anatomy (the classic 'face landing on the belly', scene #91). We
# detect that co-occurrence to widen the director's AUTO camera pick to a medium shot. Both cues are
# required, so a plain face closeup (emotional beat) or a single-object detail macro never trips it.
_FRAMING_FACE_CUES = re.compile(
    r"\b(face|smil\w+|grin\w+|laugh\w+|frown\w+|expression|eyes?|cheeks?|mouth|tearful|crying|beaming|wink\w*)\b",
    re.I)
_FRAMING_LOWER_CUES = re.compile(
    r"\b(belt|waist\w*|trousers?|pants|jeans|belly|stomach|tummy|midriff|hips?|buckle|notch|"
    r"lap|knees?|thighs?|shoelaces?|laces|ankles?|hem|crotch|groin)\b",
    re.I)
def _framing_conflict(text):
    """True when a shot demands BOTH a face/expression and a waist-or-lower / hands-down-there action —
    the co-occurrence a tight crop can't hold without distorting anatomy. Used only to widen the
    director's auto camera pick; never touches a camera the user set by hand."""
    t = text or ""
    return bool(_FRAMING_FACE_CUES.search(t) and _FRAMING_LOWER_CUES.search(t))

def direct_scenes(scene_texts, characters, aud=None, brief="", targets=None, split_overrides=None, ingredients=None, product_name="", no_funnel=False, look=None, product_line=""):
    """Whole-script director, processed in CHUNKS. Every call sees the ENTIRE script (so the arc and
    pronoun continuity stay correct) but only OUTPUTS a slice of scenes — that keeps each reply's JSON
    small enough to never truncate, even on a 100-scene VSL. Per scene:
    {cast:[ids], generic, prompt, camera, transition, continues, style, product_suggested, director_failed}.
    director_failed=True means the director could NOT produce that scene — the caller surfaces it instead of
    silently pasting the raw voice-over line into the prompt (the old, invisible failure mode).

    `targets` (0-based indices) → produce output ONLY for those scenes (still with the FULL script as context).
    Used when re-generating a hand-picked subset: ~30× cheaper and seconds instead of a whole-script pass, and
    picking a contiguous set (e.g. one long line the user cut into 3) gets them designed together → distinct."""
    n = len(scene_texts)
    if not n:
        return [], {"model_label": "", "fable_down": False, "fable_err": None}
    chars = [c for c in (characters or []) if c.get("name")]
    id_by_lower = {c["name"].strip().lower(): c.get("id") for c in chars}
    trans_ids = {c.get("id") for c in chars if c.get("transforms")}   # characters whose look changes across the video
    roster = "\n".join(f"- {c['name']}"
                       + (f" ({c.get('role')})" if c.get("role") else "")
                       + (f": {c.get('desc')}" if c.get("desc") else "")
                       + (f" [TRANSFORMS across the video — {(c.get('transform_note') or '').strip() or 'their appearance changes gradually over the script'}; for each shot they appear in, decide their stage: start / mid / end]" if c.get("transforms") else "")
                       for c in chars) or "(none — every scene's people are generic/ordinary)"
    has_transformers = any(c.get("transforms") for c in chars)
    ings = [i for i in (ingredients or []) if i.get("name")]
    ing_id_by_lower = {i["name"].strip().lower(): i.get("id") for i in ings}
    def _ing_tag(i):
        t = []
        if i.get("scientific"): t.append("MOLECULE")
        if i.get("split"): t.append("SPLIT")
        if i.get("use_directly"): t.append("USE-DIRECTLY")
        return (" [" + ", ".join(t) + "]") if t else ""
    ing_roster = "\n".join(f"- {i['name']}{_ing_tag(i)}" + (f": {i.get('desc')}" if i.get("desc") else "") for i in ings)
    numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(scene_texts))
    base = f"CAST roster:\n{roster}\n\nAUDIENCE: {_audience_note(aud)}\n"
    if ings:
        base += ("\nPRODUCT INGREDIENTS roster (the real ingredients of the product — use ONLY these when a shot shows "
                 "ingredients; name the exact ones a scene refers to, never invent others). An ingredient tagged "
                 "[MOLECULE] is NOT a plant/food you show naturally — it is a vitamin/mineral/compound; when such an "
                 "ingredient is shown, describe it as a clean 3D scientific MOLECULE render (glossy glass-like "
                 "ball-and-stick molecular structure on a soft gradient), NOT as a powder, plant, or raw form. "
                 "[SPLIT] means it is several components shown as equal side-by-side molecule panels. "
                 "[USE-DIRECTLY] means the user has ALREADY provided a finished, ready-made image for that ingredient "
                 "(often a combined 'all ingredients' shot). When a scene's line is ABOUT that ingredient — or about the "
                 "product's ingredients COLLECTIVELY (e.g. 'these five ingredients', 'all the ingredients', 'our "
                 "blend/formula', 'by combining the ingredients') and a [USE-DIRECTLY] ingredient covers them — make THAT "
                 "scene a pure INGREDIENTS shot: set \"present\":[] (NO cast person — do NOT invent a doctor / a hand on a "
                 "page / a desk or any other action), put that ingredient's exact name in \"ingredients\", set "
                 "\"product\":false, and keep \"shows\" to a brief mention of those ingredients. We drop the ready image in "
                 "directly, so do NOT design a different scene for such a line:\n" + ing_roster + "\n")
    if (product_name or "").strip():
        _pn = product_name.strip()
        base += (f"\nADVERTISED PRODUCT (brand name): {_pn}. This is the finished product being sold. On a genuine "
                 f"PRODUCT shot, NAME it exactly \"{_pn}\" in \"shows\" and set \"product\":true; NEVER show or name the "
                 f"product on lines that are not about the product itself.\n")
    if (brief or "").strip():
        base += f"\nPROJECT CONTEXT (may be Turkish; use it to understand the product/story, do NOT copy it into scenes):\n{brief.strip()}\n"
    base += f"\nFULL SCRIPT — all {n} scenes in order, for arc & pronoun continuity (CONTEXT ONLY):\n{numbered}\n"
    if has_transformers:
        base += ("\nNOTE: one or more cast are marked [TRANSFORMS …]. For EVERY shot such a character appears in, you MUST set "
                 "\"states\" with their stage (start/mid/end) judged from the arc, and describe that stage in \"shows\".\n")

    # which scenes to actually OUTPUT, grouped into director calls (each call ≤ DIRECTOR_CHUNK scenes)
    if targets is None:
        out_idx = list(range(n))
    else:
        out_idx = sorted({i for i in targets if 0 <= i < n})
    groups = [out_idx[x:x + DIRECTOR_CHUNK] for x in range(0, len(out_idx), DIRECTOR_CHUNK)]

    raw = [None] * n   # parsed director object per scene, or None if that scene wasn't produced / its chunk failed
    # Each chunk is an INDEPENDENT director call → run the chunks a few at a time (bounded) so a long script is
    # directed far faster. Each chunk does its OWN model fallback (on the subscription SMART_MODEL/PROMPT_MODEL are
    # BOTH Opus; on the Kie path: Fable then Opus). Results are written back in the MAIN thread (no shared races).
    def _run_chunk(idxs):
        if not idxs:
            return (idxs, None, None, None)
        nums = [i + 1 for i in idxs]     # 1-based scene numbers this call must output
        k = len(idxs)
        contiguous = (nums == list(range(nums[0], nums[-1] + 1)))
        which = (f"SCENES {nums[0]}–{nums[-1]}" if contiguous else "SCENES " + ", ".join(map(str, nums)))
        ask = base + (f"\nNow write the director objects for {which} ONLY: a JSON array of EXACTLY {k} object(s), "
                      f"in that exact order — the 1st object is scene {nums[0]} and the last is scene {nums[-1]}. "
                      f"Do NOT include any other scene, and do NOT add a scene-number field. JSON array only.")
        if split_overrides:   # the user has forced split on/off for some scenes → the director MUST honour it
            fs = [i + 1 for i in idxs if split_overrides.get(i) is True]
            fo = [i + 1 for i in idxs if split_overrides.get(i) is False]
            notes = []
            if fs:
                notes.append(f"Scene(s) {', '.join(map(str, fs))}: the user REQUIRES a SPLIT here. Writing a single image is FORBIDDEN. "
                             f"You MUST split the line into complementary panels — put the main subject/cause on one side and its "
                             f"effect, result, context or a contrasting view on the other. Use THREE panels only if the line genuinely "
                             f"names three distinct things (three ingredients/steps, before/during/after); otherwise TWO. Write \"shows\" "
                             f"starting EXACTLY with \"LEFT: … RIGHT: …\" (two panels) or \"LEFT: … MIDDLE: … RIGHT: …\" (three panels), "
                             f"stating each panel's look. There is ALWAYS a way to split a line; find it. Set split=true for these.")
            if fo:
                notes.append(f"Scene(s) {', '.join(map(str, fo))} MUST be split=false — a single unified image (no LEFT/RIGHT).")
            if notes:
                ask += "\nUSER OVERRIDES (obey exactly): " + " ".join(notes)
        if no_funnel:
            # a YouTube video has no offer: no product shot, no split panels, no social-proof grid. The
            # caller forces these off too - this line is so the director writes the SHOT for that, rather
            # than composing around a product that will then be stripped.
            ask += ("\nTHIS IS A YOUTUBE VIDEO, NOT A SALES VIDEO. There is no product and no offer. "
                    "Set product=false, split=false and testimonial=false on EVERY scene, and never build a "
                    "shot around showing a product pack or a grid of customer selfies. Every shot is ONE "
                    "single frame: never describe a split screen, two panels, a side-by-side or a "
                    "before-and-after layout - a picture with panels invites the model to label them, and "
                    "words baked into the picture are a defect.")
        if not no_funnel:
            ask += "\n" + DIRECTOR_VSL
            if (look or "") not in ANIM_STYLES and product_line:
                ask += "\n" + product_line
        ask += ("\nPRONOUNS ARE PEOPLE. When a line says he, she, they, him or her and the person meant is "
                "someone on the cast roster - which you can tell from the lines around it - attach THAT "
                "character. Do not fall back to a generic person because the name is not repeated in that "
                "one sentence: the viewer has to keep seeing the same face, and a stranger appearing where "
                "the hero should be is the single most jarring thing a video can do.")
        if look in ANIM_STYLES:
            # The medium is a separate layer, appended after this prompt. Naming one here can only
            # contradict it - and it did: "photorealistic photograph" on a 2D channel.
            ask += ("\nEVERY SCENE IN THIS VIDEO IS %s. Do NOT name a medium anywhere in the shot "
                    "description - no 'photorealistic', no 'photograph', no 'photo', no 'cartoon', no "
                    "'illustration', no 'render', no 'footage'. Describe only WHAT IS IN THE SHOT: the "
                    "subject, the action, the place and the light. The look is applied separately and is "
                    "not yours to set. Set style to \"%s\" on EVERY scene."
                    % ("2D ANIMATION" if look == "2d" else "3D ANIMATION", look))
        budget = min(16000, max(6000, 2500 + 260 * k))
        data = None; model_used = None; ferr = None
        for model in [SMART_MODEL, PROMPT_MODEL]:
            tries = 2 if model == SMART_MODEL else 8   # give flaky Fable only a quick shot, then lean on reliable Opus
            for _attempt in range(2):                  # one clean retry for a garbled/parse reply (model DID respond)
                try:
                    txt = _claude_text(DIRECTOR_SYSTEM + (DIRECTOR_YOUTUBE_DECOR if no_funnel else ""), ask, max_tokens=budget, model=model, tries=tries)
                except Exception as e:                 # the CALL failed (overload / 500 / network) — try the next model
                    if model == SMART_MODEL:
                        ferr = str(e)
                    break
                try:
                    got = _parse_json_array(txt)
                except Exception:
                    continue                           # replied but unparseable → retry once
                if isinstance(got, list) and got:
                    data = got; model_used = model
                    break
            if isinstance(data, list):
                break
        if not isinstance(data, list):
            return (idxs, None, model_used, ferr)
        seg = data
        if len(data) == n and n != k:      # model ignored the slice and returned the WHOLE array → take our window
            seg = [data[i] for i in idxs]
        return (idxs, seg, model_used, ferr)

    chunk_results = _parallel_map(groups, _run_chunk, workers=min(4, max(1, len(groups))))   # director chunks in PARALLEL (bounded)
    used = set(); fable_err = None
    for r in chunk_results:
        if not (isinstance(r, tuple) and len(r) == 4):
            continue                                   # an unexpected chunk crash (a _parallel_map sentinel) → skip
        idxs, seg, model_used, ferr = r
        if ferr and fable_err is None:
            fable_err = ferr
        if model_used:
            used.add(model_used)
        if seg is None:
            continue
        for j, i in enumerate(idxs):
            raw[i] = seg[j] if (j < len(seg) and isinstance(seg[j], dict)) else None

    out = []
    for i in range(n):
        item = raw[i]
        desc = ""
        if isinstance(item, dict):
            desc = str(item.get("shows") or item.get("scene") or item.get("scene_desc") or "").strip()
        tperson = _norm_testimonial_person(item.get("testimonial_person") if isinstance(item, dict) else None)
        if not desc:            # no usable shot description → FAIL LOUD, never fall back to the raw VO line
            out.append({"cast": [], "generic": None, "prompt": "", "camera": DEFAULT_CAMERA,
                        "transition": "none", "continues": 0, "style": DEFAULT_STYLE,
                        "product_suggested": False, "testimonial": False, "testimonial_person": tperson, "director_failed": True})
            continue
        cids = []
        for nm in (item.get("present") or []):
            cid = id_by_lower.get(str(nm).strip().lower())
            if cid is not None and cid not in cids:
                cids.append(cid)
        cam = str(item.get("camera") or "").strip().lower()
        cam = cam if cam in CAMERA_ANGLES_BY_KEY else DEFAULT_CAMERA
        # Safety net for the director's AUTO pick (a user's manual camera is saved on its own path and
        # never reaches here): a closeup/extreme frame holds one region — if the shot needs the face AND
        # a waist/lower-body action, widen to medium so the model doesn't crush them into bad anatomy.
        if cam in ("closeup", "extreme") and _framing_conflict(desc):
            cam = "medium"
        tr = item.get("transition")
        tr = tr if tr in TRANSITIONS else "none"
        try:
            cont = int(item.get("continues") or 0)
        except (TypeError, ValueError):
            cont = 0
        if not (1 <= cont <= i):
            cont = 0
        st = str(item.get("style") or "").strip().lower()
        st = st if st in ("natural", "scientific") else DEFAULT_STYLE
        gen = item.get("generic")
        gen = str(gen).strip() if gen else None
        states = {}                       # per-scene stage (start/mid/end) for any transforming cast present → keyed by char id
        raw_states = item.get("states")
        if trans_ids and isinstance(raw_states, dict):
            for lbl, v in raw_states.items():
                cid = id_by_lower.get(str(lbl).strip().lower())
                v = str(v or "").strip().lower()
                if cid in trans_ids and cid in cids and v in ("start", "mid", "end"):
                    states[cid] = v
        ing_ids = []                       # the product's ingredients shown in this shot → roster ids
        for nm in (item.get("ingredients") or []):
            iid = ing_id_by_lower.get(str(nm).strip().lower())
            if iid is not None and iid not in ing_ids:
                ing_ids.append(iid)
        out.append({"cast": cids, "generic": gen, "prompt": desc, "camera": cam,
                    "transition": tr, "continues": cont, "style": st,
                    "product_suggested": bool(item.get("product")),
                    "packs": _clean_packs(item.get("packs")), "card": _clean_card(item.get("card")),
                    "split": bool(item.get("split")),
                    "testimonial": bool(item.get("testimonial")), "testimonial_person": tperson,
                    "states": states, "ingredients": ing_ids, "director_failed": False})
    if targets is None:
        out[-1]["transition"] = "none"   # last scene of a FULL pass never transitions out (targeted subset leaves others alone)
    # Report the model that ACTUALLY ran. On the Kie path the ids are literal; on the DEFAULT Claude-subscription
    # path `_cli_model` maps every id to opus/sonnet/haiku, so "fable-5" really runs as OPUS — label it truthfully.
    if TEXT_PROVIDER == "kie":
        labels = {SMART_MODEL: "Fable 5", PROMPT_MODEL: "Opus 4.8"}
        model_label = " + ".join(labels[m] for m in (SMART_MODEL, PROMPT_MODEL) if m in used)
    else:
        model_label = " + ".join(sorted({_cli_model(m).capitalize() for m in used})) or "Opus"
    meta = {"model_label": model_label,          # which model(s) actually produced the scenes (for a toast)
            "fable_down": fable_err is not None,  # True if Fable 5 was tried and failed → we fell back to Opus
            "fable_err": fable_err}
    return out, meta


@app.route("/api/scenes/<project>/analyze", methods=["POST"])
def api_analyze(project):
    """Whole-script cast detection → fills the project's character roster (name/role/desc) so the user can
    add a reference photo to each BEFORE splitting. Keeps existing characters + their photos."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = (request.get_json(force=True).get("script") or "").strip()
    if not script:
        return jsonify({"error": "No script to analyze."}), 400
    # Run the 4 INDEPENDENT whole-script detections CONCURRENTLY (each is its own Claude call) — Analyze Cast is
    # ~4x faster than doing them one after another. Cast is the primary (its failure surfaces below); the other
    # three are best-effort. Exiting the `with` waits for all to finish, so every .result() below is ready.
    _brief = doc.get("brief", "")
    with _KeyPool(max_workers=4) as _ex:
        _f_cast = _ex.submit(_detect_cast_raw, script, _brief)
        _f_ing = _ex.submit(detect_ingredients, script, _brief)
        _f_prod = _ex.submit(detect_product, script, _brief)
        _f_aud = _ex.submit(detect_audience, script, _brief,
                            ((doc.get("script_opts") or {}).get("kind") or "vsl"))
    try:
        detected = _f_cast.result()
    except Exception as e:
        # surface the real reason instead of a silent empty roster
        msg = str(e).lower()
        if "internal error" in msg or "try again" in msg or "500" in msg or "timeout" in msg or "timed out" in msg:
            return jsonify({"error": "The AI service (Kie.ai) is temporarily overloaded and returned a server "
                            "error. Nothing is wrong with your script — just click Analyze Cast again in a "
                            "moment."}), 503
        return jsonify({"error": f"Cast analysis failed: {e}. If this keeps happening, check this project's "
                        f"Kie API key and credit balance."}), 502
    chars = doc.setdefault("characters", [])
    by_lower = {c.get("name", "").strip().lower(): c for c in chars}
    added = 0
    for d in detected:
        ex = by_lower.get(d["label"].strip().lower())
        if ex:                                   # keep the user's photos/edits, just refresh role/desc if empty
            ex.setdefault("role", d["role"]); ex.setdefault("desc", d["desc"])
        else:
            chars.append({"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"],
                          "urls": [], "auto": True})
            added += 1
    # ALSO detect the product's ingredients (same analyze pass) → fills the Ingredients roster. Never fails cast.
    ing_added = 0
    try:
        ings = doc.setdefault("ingredients", [])
        i_by_lower = {i.get("name", "").strip().lower(): i for i in ings}
        for d in _f_ing.result():
            if d["name"].strip().lower() in i_by_lower:
                continue
            row = {"id": new_uid(), "name": d["name"], "desc": d["desc"], "urls": [], "auto": True}
            if d.get("scientific"):                  # molecule/compound (SAC, nitric oxide…) -> scientific render
                row["scientific"] = True
            ings.append(row)
            ing_added += 1
    except Exception as _qe:
        quiet(_qe, "api_analyze")
    # ALSO detect the advertised PRODUCT's brand name + its offered PACK sizes (same analyze pass) → fills
    # product.name (so the director names product shots, e.g. "Cardio-360") and product.packs (the bundle sizes
    # the offer sells — 1/3/6/12 bottle — so the user knows which pack images to upload). Never fails cast.
    try:
        prod = doc.setdefault("product", {"urls": []})
        _pd = _f_prod.result() or {}
        if not (prod.get("name") or "").strip() and _pd.get("name"):
            prod["name"] = _pd["name"]
        if not (prod.get("packs")) and _pd.get("packs"):
            prod["packs"] = _pd["packs"]
    except Exception as _qe:
        quiet(_qe, "api_analyze")
    # AUTO project brief + target-viewer avatar + audience targeting from the script. Fills ONLY empty fields
    # (never overwrites what the user set), constrained to the audience-field options; the user reviews it in the
    # Settings → Audience tab that opens after Analyze Cast. Saves the user re-entering this every project.
    auto_aud = []
    try:
        aud = doc.setdefault("audience", {})
        sug = _f_aud.result()
        if sug:
            _stale = doc.get("brief_auto") and (sug.get("brief") or "").strip()
            if (not (doc.get("brief") or "").strip() or _stale) and (sug.get("brief") or "").strip():
                doc["brief"] = sug["brief"].strip()[:600]
                doc["brief_auto"] = True          # ours, so a later format change may refresh it
                auto_aud.append("brief")
            if not (aud.get("avatar") or "").strip() and (sug.get("avatar") or "").strip():
                aud["avatar"] = " ".join(sug["avatar"].split())[:120]; auto_aud.append("target viewer")
            _ALLOWED = {
                "locations": {"United States", "United Kingdom", "France", "Germany"},
                "currencies": {"Dollar", "Pound", "Euro"},
                "ages": {"25-44", "45-65", "50-80"},
                "genders": {"Female", "Male"},
                "appearance": {"Asian", "Black-skinned", "White-skinned", "Indian", "Hispanic / Latino",
                               "Middle Eastern / Arab", "Blonde", "Redhead", "Orange hair", "Brunette",
                               "Black hair", "Gray / white hair"},
            }
            def _fill(key, val, human):
                if aud.get(key):                       # keep the user's own selection
                    return
                if isinstance(val, str):
                    val = [val] if val.strip() else []
                vals = [v for v in (val or []) if v in _ALLOWED[key]]
                if vals:
                    aud[key] = vals; auto_aud.append(human)
            _fill("locations", sug.get("location"), "location")
            _fill("currencies", sug.get("currency"), "currency")
            _fill("ages", sug.get("ages"), "age")
            _fill("genders", sug.get("genders"), "gender")
            _fill("appearance", sug.get("appearance_exclude"), "excluded looks")
    except Exception as _qe:
        quiet(_qe, "api_analyze")
    save_doc(project, doc)
    return jsonify({"doc": doc, "detected": detected, "added": added, "ingredients_added": ing_added,
                    "auto_audience": auto_aud})


def _sync_auto_testimonials(doc, plan):
    """From the director plan, auto-create/refresh testimonial PEOPLE + written FACEBOOK cards for any
    first-person customer-testimonial line, and link each such scene to its card (scene.tcard_id).
    'auto' entries are reconciled on every split (refreshed/pruned); manually-added ones are left alone,
    and an existing auto person keeps its generated photo across re-splits (matched by name)."""
    scenes = doc.get("scenes") or []
    people = doc.setdefault("testimonials", [])
    cards = doc.setdefault("testimonial_cards", [])
    people_by_name = {}
    for p in people:
        nm = str(p.get("name") or "").strip().lower()
        if nm:
            people_by_name.setdefault(nm, p)
    wcard_by_char = {}
    for c in cards:
        if str(c.get("type") or "written") == "written" and c.get("charId"):
            wcard_by_char.setdefault(c.get("charId"), c)
    used_people, used_cards = set(), set()
    for i, sc in enumerate(scenes):
        a = plan[i] if i < len(plan) else {}
        tp = a.get("testimonial_person") if isinstance(a, dict) else None
        if not tp:
            continue
        key = tp["name"].strip().lower()
        person = people_by_name.get(key)
        if person is None:
            person = {"id": new_uid(), "name": tp["name"], "desc": "", "age": tp.get("age", ""),
                      "gender": tp.get("gender", ""), "location": tp.get("location", ""), "urls": [], "auto": True}
            people.append(person); people_by_name[key] = person
        elif person.get("auto"):                       # refresh an auto person's meta from the (maybe edited) script; keep its photo
            person["age"] = tp.get("age") or person.get("age", "")
            person["gender"] = tp.get("gender") or person.get("gender", "")
            person["location"] = tp.get("location") or person.get("location", "")
        used_people.add(person["id"])
        card = wcard_by_char.get(person["id"])
        if card is None:
            card = {"id": new_uid(), "type": "written", "format": "facebook", "charId": person["id"],
                    "text": tp.get("text", ""), "extra": {}, "auto": True, "sceneUid": sc["uid"]}
            cards.append(card); wcard_by_char[person["id"]] = card
        elif card.get("auto"):                          # refresh the auto card's wording; keep any produced image in extra
            card["text"] = tp.get("text", "") or card.get("text", "")
            card.setdefault("format", "facebook")
        card["sceneUid"] = sc["uid"]
        used_cards.add(card["id"])
        sc["tcard_id"] = card["id"]
    # prune AUTO entries that no longer match a detected testimonial (manual ones are kept)
    doc["testimonial_cards"] = [c for c in cards if (not c.get("auto")) or c["id"] in used_cards]
    referenced = {c.get("charId") for c in doc["testimonial_cards"]}
    doc["testimonials"] = [p for p in people if (not p.get("auto")) or p["id"] in used_people or p["id"] in referenced]


@app.route("/api/scenes/<project>/split", methods=["POST"])
def api_split(project):
    """Split the script into meaningful scenes via Claude (Kie.ai). Surfaces errors; no fallback.
    Then a whole-script director pass auto-assigns camera framing, transitions, cast, and continuity."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = request.get_json(force=True).get("script", "")
    try:
        parts = split_script(script, youtube=is_youtube(doc))
    except Exception as e:
        return jsonify({"error": f"Split failed: {e}"}), 502
    # Make sure a cast roster exists so the director can keep recurring people consistent. If the user
    # already ran "Analyze Script" (and maybe added photos) we KEEP that roster; otherwise detect now.
    if not [c for c in (doc.get("characters") or []) if c.get("name")]:
        for d in detect_cast(script, doc.get("brief", "")):
            doc.setdefault("characters", []).append(
                {"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"], "urls": [], "auto": True})
    if not [i for i in (doc.get("ingredients") or []) if i.get("name")]:   # also seed the product's ingredient roster
        try:
            for d in detect_ingredients(script, doc.get("brief", "")):
                doc.setdefault("ingredients", []).append(
                    {"id": new_uid(), "name": d["name"], "desc": d["desc"], "urls": [], "auto": True})
        except Exception as _qe:
            quiet(_qe, "api_split")
    # ONE whole-script director pass: who's present, generic person, on-screen content, camera, transition,
    # continuity, style — all resolved together so nothing conflicts and identity stays consistent.
    plan, dmeta = direct_scenes(parts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""), ingredients=doc.get("ingredients"), product_name=(doc.get("product") or {}).get("name", ""), no_funnel=is_youtube(doc), product_line=product_form_line(doc, proj_dir(project)[0]))
    doc["scenes"] = []
    _run_pack = None                   # the bundle the offer has escalated to, as we walk the script
    for i, sent in enumerate(parts, 1):
        sc = new_scene(i)
        sc["vo"] = sent
        a = plan[i - 1] if i - 1 < len(plan) else {}
        sc["prompt"] = a.get("prompt") or ""          # the director already wrote the on-screen content
        sc["cast"] = a.get("cast") or []
        sc["generic"] = a.get("generic")              # a non-roster ordinary person for this shot (or None)
        sc["camera"] = a.get("camera") or DEFAULT_CAMERA
        sc["transition"] = a.get("transition") or DEFAULT_TRANSITION
        sc["style"] = _doc_scene_style(doc) or a.get("style") or DEFAULT_STYLE
        sc["bg"] = _doc_scene_bg(doc) or DEFAULT_BG   # composition, same as the look - Auto Episode set
        _yt = is_youtube(doc)                                        # a YouTube project has no offer to sell
        sc["product_suggested"] = (not _yt) and bool(a.get("product_suggested"))
        # Which BUNDLE this line puts on offer ("6 boites" -> [6]; "6 mois" is a duration -> []). A line
        # naming two options at once keeps both, and the showcase shows them side by side.
        sc["packs"] = [] if _yt else _clean_packs(a.get("packs"))
        sc["card"] = "" if _yt else _clean_card(a.get("card"))    # a full-frame graphic card instead of a photo
        if sc["product_suggested"] and sc.get("product") is None:    # auto-select ONLY if the user has NEVER touched product (None); an explicit "" (cleared) is respected
            # the pack the LINE asks for beats the default single bottle; an unuploaded size falls back
            # rather than silently showing the wrong box
            _pu = _pick_pack_url(doc, sc["packs"], _run_pack)
            if _pu: sc["product"] = _pu
        _run_pack = _advance_pack(_run_pack, sc["packs"])
        sc["split"] = (not _yt) and bool(a.get("split"))             # two-panel/diptych composition (director decided)
        sc["split_suggested"] = bool(a.get("split"))                 # director chose split here → pulse the button green until the user touches it
        sc["testimonial"] = (not _yt) and bool(a.get("testimonial"))   # social-proof crowd line → grid of real-customer selfies
        if sc["testimonial"]:
            # a testimonial shot is a grid of real-customer selfies — it must NOT carry the product bottle
            # or any roster cast; keep it purely social-proof (the director/audit sometimes over-attach both).
            sc["cast"] = []; sc["generic"] = None
            sc["product_suggested"] = False
            if sc.get("product") is None: sc["product"] = ""
        sc["states"] = a.get("states") or {}                         # transforming cast → stage (start/mid/end) at this scene
        sc["ingredients"] = a.get("ingredients") or []                # the product's ingredients shown in this shot (roster ids)
        if not sc["testimonial"]:
            bind_named_cast(sc, doc)                                 # any roster character NAMED in the prompt → face-lock them too
        sc["_cont"] = a.get("continues") or 0        # temp: 1-based source scene #, resolved to a uid below
        doc["scenes"].append(sc)
    for sc in doc["scenes"]:                          # resolve continuity #→uid now that every scene has a uid
        c = sc.pop("_cont", 0)
        sc["cont_of"] = doc["scenes"][c - 1]["uid"] if 1 <= c <= len(doc["scenes"]) else None
    _sync_auto_testimonials(doc, plan)                # auto-build testimonial people + FB cards from first-person testimonial lines, and link their scenes
    save_doc(project, doc)
    _stamp_director_prompt(doc.get("scenes"))                 # baseline for the later edit-delta
    _learn_log("director", project, doc, doc.get("scenes"))   # passive: capture the director's fresh (vo → prompt) pairs
    failed = [i + 1 for i, a in enumerate(plan) if a.get("director_failed")]   # never silently ship raw-VO prompts
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)                              # which model actually ran (toast)
    if failed:
        resp["director_warning"] = (f"The director could not write a shot description for {len(failed)} scene(s): "
                                    f"{', '.join(map(str, failed))}. Their prompts are left empty — use “Re-run "
                                    f"director” or write/Generate a prompt for those scenes.")
    return jsonify(resp)

def _looks_multi(vo):
    """Cheap check: does this voice-over hold more than one sentence? (a sentence-ender with more text after
    it). Lets re-split skip single-sentence scenes entirely — no LLM call, nothing touched."""
    return bool(re.search(r"[.!?…]['\"”’)]?\s+\S", (vo or "").strip()))

@app.route("/api/scenes/<project>/resplit", methods=["POST"])
@_locked
def api_resplit_scenes(project):
    """WORK-PRESERVING re-split: break only the scenes whose voice-over holds several sentences into one
    sentence each. Single-sentence scenes are left 100% untouched (prompt, image, cast, approval all kept).
    For a multi-sentence scene, the FIRST sentence stays on the original scene (keeping its media/prompt);
    the extra sentences become NEW blank scenes right after it. Fixes old 3-4-sentence scenes without
    rebuilding the whole project. (New splits already follow the one-sentence rule, so this is a one-off tidy.)"""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    out, split_count, added, kept_approved = [], 0, 0, 0
    for s in scenes:
        vo = (s.get("vo") or "").strip()
        if s.get("approved"):                 # finalized scene → NEVER disturb it (unapprove first if you want it re-split)
            out.append(s)
            if _looks_multi(vo):
                kept_approved += 1
            continue
        if not _looks_multi(vo):
            out.append(s)                     # single sentence → untouched
            continue
        try:
            parts = [p for p in split_script(vo, youtube=is_youtube(doc)) if p.strip()]
        except Exception:
            out.append(s)                     # splitter hiccup → leave this scene as-is
            continue
        if len(parts) <= 1:
            out.append(s)
            continue
        s["vo"] = parts[0]                    # first sentence stays on THIS scene (keeps its image/prompt/cast)
        out.append(s)
        for extra in parts[1:]:
            ns = new_scene(0)
            ns["vo"] = extra
            ns["uid"] = new_uid()
            out.append(ns)
            added += 1
        split_count += 1
    for i, s in enumerate(out, 1):
        s["id"] = i
    doc["scenes"] = out
    save_doc(project, doc)
    resp = dict(doc)
    resp["resplit"] = {"split": split_count, "added": added, "total": len(out), "kept_approved": kept_approved}
    return jsonify(resp)


AUDIT_JOBS = {}
_AUDIT_LOCK = threading.Lock()

def _audit_norm(s):
    return " ".join((s or "").split())

def _audit_batch(payload, doc, _aud_project=None):
    """One LLM call over a batch of scene dicts -> list of verdicts. Retries a few times so a flaky/partial Kie
    response doesn't kill the whole audit; raises if it still can't get a valid non-empty JSON array (every model
    down or garbled), so the worker aborts atomically and saves nothing."""
    user = ("Review these scenes IN ORDER (one JSON per line). Return the JSON array of verdicts:\n"
            + "\n".join(json.dumps(p, ensure_ascii=False) for p in payload))
    last = None
    for _ in range(3):
        try:
            # Shared rules, then the block for THIS kind of video, then the style lock, then the JSON
            # contract last. A YouTube episode used to get the sales-video brief with a correction
            # bolted on the end; half of what it was being told to enforce (the offer, the product
            # reveal, the ingredient rules) does not exist there, and none of what actually matters on
            # YouTube - the cutting rhythm, the opening, earning the next second - was mentioned at all.
            _pf = "" if is_youtube(doc) else product_form_line(doc, proj_dir(_aud_project)[0])
            _audit_sys = AUDIT_SYSTEM + (AUDIT_YOUTUBE if is_youtube(doc) else AUDIT_VSL) + (
                ("\n\n" + _pf) if _pf else "") + (
                "\n\nTHE LOOK IS ALREADY DECIDED. Each scene carries its own style and you cannot change it: "
                "write the improved prompt FOR THE STYLE THAT SCENE ALREADY HAS. On a '2d' scene keep it a flat "
                "cartoon and on a '3d' scene keep it a stylised CG render - never describe photographic detail, "
                "real skin texture, film grain or live-action footage on those, and never turn them into a "
                "'natural' photo scene. On a 'natural' scene do not turn it into an illustration.") + AUDIT_OUTPUT
            arr = _parse_json_array(_claude_text(_audit_sys, user, max_tokens=8000))
            if isinstance(arr, list) and arr:
                return arr
            last = ValueError("empty audit result")
        except Exception as e:
            last = e
    raise last or RuntimeError("audit failed")

def _audit_worker(jid, project):
    j = AUDIT_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _AUDIT_LOCK: j.update(status="error", error="project not found")
            return
        scenes = doc.get("scenes") or []
        alang = country_language(doc.get("audience")) or ""   # any on-image text must be in this language (not English)
        # testimonial scenes are an auto-composed selfie grid (own prompt, no bottle/cast) — never audit them
        auditable = [s for s in scenes if not s.get("approved") and (s.get("vo") or "").strip() and not s.get("testimonial")]
        if not auditable:
            with _AUDIT_LOCK: j.update(status="error", error="No scenes to audit (all approved or empty).")
            return
        B = 16
        batches = [auditable[i:i + B] for i in range(0, len(auditable), B)]
        def _do_batch(batch):                        # one LLM call over 16 scenes; independent of the others
            if j.get("cancel"):
                return None
            payload = [{"id": s.get("id"), "vo": s.get("vo") or "", "current_prompt": s.get("prompt") or "",
                        "style": s.get("style") or "natural", "camera": s.get("camera") or "",
                        "narrator_or_named_cast_present": bool(s.get("cast")),
                        "audience_language": alang,
                        "ingredients_shown": s.get("ingredients") or []} for s in batch]
            return _audit_batch(payload, doc, project)   # doc: the YouTube/VSL rule below needs it, and a bare
                                                     # global here was a NameError the moment Audit ran
        def _prog(dn, tot):
            with _AUDIT_LOCK: j.update(step=f"Auditing… batch {dn}/{tot} ({len(auditable)} scenes)", pct=int(dn / max(1, tot) * 90))
        results = _parallel_map(batches, _do_batch, cancel=lambda: j.get("cancel"), on_progress=_prog)   # batches in PARALLEL (bounded)
        if j.get("cancel"):
            with _AUDIT_LOCK: j.update(status="cancelled")
            return
        verdicts = {}
        for r in results:
            if isinstance(r, tuple):                 # ('__err__', exc) or ('__cancelled__',)
                if r and r[0] == "__err__":          # any batch failed -> abort ATOMICALLY, save nothing (same as before)
                    with _AUDIT_LOCK: j.update(status="error", error=str(r[1])[:200])
                    return
                continue
            for v in (r or []):
                try:
                    verdicts[int(v.get("id"))] = v
                except Exception:
                    continue
        # APPLY atomically (only now that every batch succeeded)
        out, fixed, split_n, added, changes = [], 0, 0, 0, []
        for s in scenes:
            v = verdicts.get(s.get("id"))
            if s.get("approved") or not v:
                out.append(s); continue
            vo = s.get("vo") or ""
            beats = v.get("split") if isinstance(v.get("split"), list) else None
            if beats and len(beats) >= 2 and _audit_norm(" ".join(b.get("vo", "") for b in beats)) == _audit_norm(vo):
                for k, b in enumerate(beats):
                    ns = json.loads(json.dumps(s))          # deep clone -> keeps all fields/blocks
                    ns["vo"] = b.get("vo") or ""
                    ns["prompt"] = (b.get("prompt") or s.get("prompt") or "").strip()
                    if b.get("style"): ns["style"] = b["style"]
                    if b.get("camera"): ns["camera"] = b["camera"]
                    if k > 0:
                        ns["uid"] = new_uid()               # fresh beats get their own uid
                    out.append(ns)
                split_n += 1; added += len(beats) - 1
                changes.append({"id": s.get("id"), "issue": v.get("issue") or "split into visual beats"})
                continue
            np = (v.get("prompt") or "").strip()
            if np and _audit_norm(np) != _audit_norm(s.get("prompt") or ""):
                s["prompt"] = np
                if v.get("style"): s["style"] = v["style"]
                if v.get("camera"): s["camera"] = v["camera"]
                fixed += 1
                changes.append({"id": s.get("id"), "issue": v.get("issue") or "prompt improved"})
            out.append(s)
        for i, s in enumerate(out, 1):
            s["id"] = i
        doc["scenes"] = out
        save_doc(project, doc)
        report = {"audited": len(auditable), "fixed": fixed, "split": split_n, "added": added,
                  "total": len(out), "changes": changes[:150]}
        with _AUDIT_LOCK: j.update(status="done", pct=100, step="Done", report=report, scenes=out)
    except Exception as e:
        with _AUDIT_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/audit", methods=["POST"])
@_locked
def api_audit_scenes(project):
    """Start a prompt-audit job (best model -> fallback -> error; atomic; skips approved scenes)."""
    err = _keys_ok(("kie",))
    if err:
        return err
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    AUDIT_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_audit_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/audit-job/<jid>")
def api_audit_job(jid):
    j = AUDIT_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/audit-cancel/<jid>", methods=["POST"])
def api_audit_cancel(jid):
    j = AUDIT_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

def _director_note(meta):
    """One-line 'which model ran the director' message for a toast (e.g. 'Director: Opus 4.8 — Fable 5 was
    unavailable (Resources are tight)'). Returns '' if the director produced nothing."""
    meta = meta or {}
    label = meta.get("model_label") or ""
    if not label:
        return ""
    note = f"Director: {label}"
    if meta.get("fable_down"):
        err = (meta.get("fable_err") or "").strip()
        note += " — Fable 5 was unavailable" + (f" ({err})" if err else "") + ", used Opus 4.8"
    return note

@app.route("/api/scenes/<project>/redirect", methods=["POST"])
def api_redirect_scenes(project):
    """Re-run the whole-script director over the EXISTING scenes.
    - No selection (whole-doc): REPAIR only — rewrite prompts that are empty or just the raw voice-over line,
      and KEEP any prompt you wrote yourself. Voice-over, images and order are always preserved.
    - With `ids` (a selection): a FULL redo of just those scenes — the director re-decides EVERYTHING
      (prompt, cast, camera, transition, style, product/split hints, transformation stage), overwriting them.
      RAW ("My prompt") scenes are still left untouched."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    body = request.get_json(silent=True) or {}
    ids = body.get("ids")
    if not ids and body.get("unapproved"):     # one-click: FULL re-direct of every UNAPPROVED (non-RAW) scene,
        ids = [s.get("id") for s in scenes if not s.get("approved") and not s.get("no_cast")]   # approved stay untouched
    sel = set(ids) if ids else None            # a selection → FULL redo of those scenes; else whole-doc repair
    texts = [(s.get("vo") or "") for s in scenes]
    if sel is not None:
        # NEVER re-direct an APPROVED scene, even if it's in the selection (select-all is safe) — same rule as Audit
        targets = {i for i, s in enumerate(scenes) if s.get("id") in sel and not s.get("approved")}
        split_overrides = {i: bool(scenes[i].get("split")) for i in targets if not scenes[i].get("no_cast")}
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides, ingredients=doc.get("ingredients"), product_name=(doc.get("product") or {}).get("name", ""))
    else:
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""), ingredients=doc.get("ingredients"), product_name=(doc.get("product") or {}).get("name", ""), no_funnel=is_youtube(doc), product_line=product_form_line(doc, proj_dir(project)[0]))
    fixed, failed, kept = 0, [], 0
    _redone = []
    for i, s in enumerate(scenes):
        a = plan[i] if i < len(plan) else {}
        if s.get("approved"):            # finalized scene → NEVER touched by Re-Director (select-all can't harm it)
            kept += 1
            continue
        if sel is not None:
            if s.get("id") not in sel:
                continue
            if s.get("no_cast"):               # RAW scene → the user's own prompt; never overwrite it
                kept += 1
                continue
        else:
            vo = (s.get("vo") or "").strip()
            cur = (s.get("prompt") or "").strip()
            broken = (cur == "" or cur == vo)  # empty, or the raw VO pasted in by the old fallback
            if not broken:
                kept += 1                      # a real, hand-written/earlier-good prompt → never touch it
                continue
        if a.get("director_failed"):
            failed.append(i + 1)
            continue
        s["prompt"] = a.get("prompt") or ""
        s["cast"] = a.get("cast") or []
        s["cast_locked"] = []   # Re-run Director is a fresh full decision → clear the user's earlier removals (it may re-add; the user can remove again and it stays removed)
        s["generic"] = a.get("generic")
        s["camera"] = a.get("camera") or DEFAULT_CAMERA
        s["transition"] = a.get("transition") or DEFAULT_TRANSITION
        s["style"] = _doc_scene_style(doc) or a.get("style") or DEFAULT_STYLE
        s["bg"] = _doc_scene_bg(doc) or DEFAULT_BG    # ...this one and the hand split did not
        _yt = is_youtube(doc)
        s["product_suggested"] = (not _yt) and bool(a.get("product_suggested"))
        if s["product_suggested"] and s.get("product") is None:   # auto-select ONLY if never touched; a cleared "" (user set None) is respected on re-run
            _pu = _default_product_url(doc)
            if _pu: s["product"] = _pu
        # The offer fields, on the SAME terms as the split: VSL only, empty on a YouTube episode.
        # They were missing here entirely, so a showcase or a card the director had not picked up could
        # never be recovered - Re-Director is exactly the button for that, and it was not setting them.
        s["packs"] = [] if _yt else _clean_packs(a.get("packs"))
        s["card"] = "" if _yt else _clean_card(a.get("card"))
        s["split"] = (not _yt) and bool(a.get("split"))
        s["split_suggested"] = bool(a.get("split"))
        s["testimonial"] = (not _yt) and bool(a.get("testimonial"))   # social-proof crowd → grid of selfies
        s["states"] = a.get("states") or {}
        s["ingredients"] = a.get("ingredients") or []
        if s["testimonial"]:
            # testimonial = a grid of real-customer selfies: never the product bottle or roster cast
            s["cast"] = []; s["generic"] = None; s["product_suggested"] = False
            if s.get("product") is None: s["product"] = ""
        else:
            bind_named_cast(s, doc)                 # face-lock any roster character the prompt names
        s["_cont"] = a.get("continues") or 0
        fixed += 1
        _redone.append(s)
    for s in scenes:                           # resolve continuity #→uid for the scenes we rewrote
        c = s.pop("_cont", 0)
        if c:
            s["cont_of"] = scenes[c - 1]["uid"] if 1 <= c <= len(scenes) else None
    save_doc(project, doc)
    _stamp_director_prompt(_redone)                  # baseline for the later edit-delta
    _learn_log("director", project, doc, _redone)   # passive: capture re-directed (vo → prompt) pairs
    return jsonify({"fixed": fixed, "kept": kept, "failed": failed, "total": len(scenes),
                    "note": _director_note(dmeta)})


def char_has_photo(c):
    """A USER-provided reference photo exists (not the auto-anchor)."""
    return bool((c.get("urls") and any(c.get("urls"))) or c.get("url"))

def char_urls(c):
    """Every reference image used to keep a character's face consistent: user-provided photos PLUS the
    auto-anchor (the first approved frame we adopted for a photo-less recurring person). New characters
    store `urls` (a list); legacy ones a single `url` — normalise both to a list."""
    urls = [u for u in (c.get("urls") or []) if u]
    if not urls and c.get("url"):
        urls = [c["url"]]
    if c.get("anchor"):
        urls = urls + [c["anchor"]]
    return urls

def scene_characters(scene, doc):
    """Resolve a scene's `cast` (character ids) against doc.characters → list of character dicts."""
    by_id = {c.get("id"): c for c in (doc.get("characters") or [])}
    return [by_id[cid] for cid in (scene.get("cast") or []) if cid in by_id]

# Broad "is there a person in this shot?" cues (deliberately generous → we only DROP a face-lock when there is
# ZERO human signal, so we never strip a legitimately-present person). Excludes 'human/body' (anatomy uses those).
_PERSON_CUES = re.compile(
    r"\b(he|she|him|her|his|hers|they|them|their|man|men|woman|women|boy|girl|kid|kids|child|children|baby|"
    r"person|people|folks|someone|somebody|everyone|doctor|nurse|patient|patients|expert|scientist|husband|"
    r"wife|mother|father|mom|mum|dad|parent|parents|family|friend|friends|couple|crowd|lady|gentleman|guy|"
    r"hand|hands|arm|arms|finger|fingers|holds?|holding|hold|wearing|wears|face|faces|head|smil\w+|frown\w*|"
    r"sits?|sitting|sat|stands?|standing|stood|walk\w*|runs?|running|looks?|looking|reach\w*|points?|pointing|"
    r"talk\w*|speak\w*|eat\w*|drink\w*|sleep\w*|cry\w*|laugh\w*|hug\w*|portrait|selfie)\b", re.I)

_NAME_TITLES = {"dr", "dr.", "mr", "mr.", "mrs", "mrs.", "ms", "ms.", "miss", "prof", "prof.", "sir", "madam", "the"}

def _char_name_tokens(name):
    """A character's matchable name forms: the FULL name plus each significant token (first name / surname),
    dropping titles (Dr, Mr…) and tokens shorter than 3 chars. So 'Dr Stefan Müller' → ['dr stefan müller',
    'stefan', 'müller'] — the person is recognised whether the prompt says the full name, 'Stefan' or 'Müller'."""
    nm = (name or "").strip().lower()
    if not nm:
        return []
    toks = [t for t in re.split(r"[\s/]+", nm) if len(t) >= 3 and t not in _NAME_TITLES]
    seen, out = set(), []
    for t in [nm] + toks:
        if t not in seen:
            seen.add(t); out.append(t)
    return out

def _text_has_word(word, low):
    return bool(re.search(r"(?<![a-z])" + re.escape(word) + r"(?![a-z])", low))

def _shot_has_people(scene, doc):
    """True if this shot plausibly contains a PERSON — a named roster character in the prompt, a director-set
    generic person, a split, or any generic person cue. False ONLY for pure object/product/anatomy shots with
    no human signal at all (where attaching a face reference just grafts it onto the object → 'head on belly')."""
    if scene.get("split") or scene.get("generic"):
        return True
    low = (scene.get("prompt") or "").lower()
    for c in (doc.get("characters") or []):
        # a character named in the prompt by full name OR any first-name/surname token → a person is present
        if any(_text_has_word(t, low) for t in _char_name_tokens(c.get("name"))):
            return True
    return bool(_PERSON_CUES.search(scene.get("prompt") or ""))

def scene_face_chars(scene, doc):
    """The cast (with photos) to FACE-LOCK for this shot. Empty when the shot has no person at all — so a face
    reference is never pasted onto an object/product/anatomy. Single source of truth for assemble + submit."""
    chars = [c for c in scene_characters(scene, doc) if char_urls(c)]
    if chars and not _shot_has_people(scene, doc):
        return []
    return chars

def scene_ingredients(scene, doc):
    """Resolve a scene's `ingredients` (roster ids) → ingredient dicts (the product's real ingredients shown here)."""
    by_id = {i.get("id"): i for i in (doc.get("ingredients") or [])}
    return [by_id[iid] for iid in (scene.get("ingredients") or []) if iid in by_id]

def scene_ingredient_refs(scene, doc):
    """Ingredients IN this shot that carry a reference image → attached (i2i) so the on-screen ingredient
    matches the approved look."""
    return [i for i in scene_ingredients(scene, doc) if [u for u in (i.get("urls") or []) if u]]

# --- transforming characters (e.g. someone who slims down across the video) ------------------------
# A character marked `transforms` has TWO reference buckets: `urls` = START look (e.g. heavier) and
# `urls_end` = END look (e.g. slim). The director tags each scene with the character's STAGE at that
# point (start / mid / end); we then attach the matching photo(s) and word the face-lock accordingly,
# so the SAME face stays consistent while the body changes gradually over the script.
def _char_state(c, s):
    """This transforming character's stage in THIS scene: 'start' | 'mid' | 'end' (None if not transforming)."""
    if not c.get("transforms"):
        return None
    v = str((s.get("states") or {}).get(c.get("id")) or "").strip().lower()
    return v if v in ("start", "mid", "end") else "start"   # default to START (the original reference)

def char_end_urls(c):
    return [u for u in (c.get("urls_end") or []) if u]

def char_urls_for(c, s):
    """The reference image(s) to attach for this character IN THIS scene. Normal characters → all their
    photos. A transforming character → the photo(s) for their stage here (start / mid=both / end)."""
    base = char_urls(c)
    if not c.get("transforms"):
        return base
    end = char_end_urls(c)
    if not end:                       # slim photo not uploaded yet → behave like a normal character
        return base
    st = _char_state(c, s)
    if st == "end":
        return end or base
    if st == "mid":
        return base + end             # both looks → the model interpolates a believable in-between
    return base                       # start

def _transform_who(c, s):
    """Face-lock wording for a transforming character at its current stage: keep the SAME face, but let the
    BODY match this scene's stage (so a single set of photos still yields a gradual, on-model transformation)."""
    name = c.get("name") or "the character"
    st = _char_state(c, s)
    has_end = bool(char_end_urls(c))
    if st == "end":
        return (f"{name}: depict her EXACTLY as in the slim reference image — same face, hair, identity AND the SAME slim, "
                f"lean, fit body shown there. This is her AFTER / transformed look; do NOT make her heavier or fuller than "
                f"the slim reference, and do NOT blend in any earlier heavier look. Match the slim reference faithfully.")
    if st == "mid" and has_end:
        return (f"{name}: keep the EXACT SAME face, hair and identity as in the reference images. Her body is MID-transformation "
                f"— clearly and noticeably slimmer than the heavier (start) reference, but not yet as lean as the slim (end) reference. "
                f"Render a believable in-between weight. Only the body changes, never the face.")
    if st == "mid":
        return (f"{name}: keep the EXACT SAME face and hair as in the reference; her body is MID-transformation — clearly and "
                f"noticeably slimmer than in the reference (do NOT copy the reference's fuller body). Only the body changes, never the face.")
    return (f"{name}: depict with the SAME face and overall appearance as in the reference — she is at the START, before her transformation.")

def _auto_anchor(doc, s, provisional=False):
    """AUTO-ANCHOR: adopt this scene's frame as the face-lock for a recurring character who has no
    reference photo, so later scenes with that person keep the same face. Ambiguous shots (2+ un-anchored
    photo-less people) are skipped - we cannot attribute a single face.

    provisional=True is the bulk case: forty scenes are generated in one go and nobody is there to
    approve anything mid-run, so the FIRST frame that shows the character is adopted straight away and
    the rest of the run follows it. A frame the user later APPROVES outranks that guess and replaces it.
    """
    frame = (s.get("image") or {}).get("approved_file") or (s.get("image") or {}).get("file")
    if not frame:
        return
    fresh = [c for c in scene_characters(s, doc)
             if not char_has_photo(c)
             and (not c.get("anchor") or (not provisional and c.get("anchor_auto")))]
    if len(fresh) == 1:
        fresh[0]["anchor"] = frame
        if provisional:
            fresh[0]["anchor_auto"] = True          # a guess, replaceable by an approval
        else:
            fresh[0].pop("anchor_auto", None)       # chosen by a person; settled

def _cont_source(scene, doc):
    """The earlier scene this one visually continues (same place + people), by stable uid, or None."""
    u = scene.get("cont_of")
    return next((x for x in doc.get("scenes", []) if x.get("uid") == u), None) if u else None


# When Kie breaks a SPECIFIC model (opus/sonnet return an `error` event "Server exception" at HTTP 200 while
# another model still streams fine — observed 2026-08-08), fall through to the next model instead of failing the
# whole step. Order = requested model first, then these, deduped. fable-5 is the most reliable fallback.
_CLAUDE_FALLBACKS = ["claude-sonnet-5", "claude-fable-5"]

def _claude_stream_once(system, user, max_tokens, model):
    # Kie's NON-streaming /claude/v1/messages path returns HTTP 500 "Server exception" in bursts while the
    # STREAMING path keeps working (it's what Kie's own playground uses). So we STREAM and accumulate the text
    # deltas. Read raw bytes + decode UTF-8 ourselves — iter_lines(decode_unicode=True) uses latin-1 and mangles
    # em-dashes / £ / accented names. Raises on an error event / empty stream so _retry + fallback can act.
    with requests.post(KIE_CLAUDE_URL,
                       headers={"Authorization": f"Bearer {_key('KIE_API_KEY')}", "Content-Type": "application/json"},
                       json={"model": model, "max_tokens": max_tokens, "system": system,
                             "messages": [{"role": "user", "content": user}], "stream": True},
                       stream=True, timeout=120) as r:
        parts, err = [], None
        for raw in r.iter_lines():
            if not raw:
                continue
            line = raw.decode("utf-8", "ignore")
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                ev = json.loads(payload)
            except Exception:
                continue
            et = ev.get("type")
            if et == "content_block_delta":
                parts.append((ev.get("delta") or {}).get("text", ""))
            elif et == "error":
                e = ev.get("error") or {}
                err = e.get("message") or e.get("type") or "stream error"
        text = "".join(parts).strip()
        if text:
            return text
        raise RuntimeError(err or f"HTTP {r.status_code} (empty stream)")

_MODEL_COOLDOWN = {}      # model -> time.time() of its last failure; skip re-hammering a model Kie just broke

def _claude_text_kie(system, user, max_tokens=1024, model=None, tries=8):
    """[KIE PROVIDER] Stream a completion from Kie, ALWAYS starting with the best (requested) model and only
    falling through to the next when it errors — so a Kie per-model outage (opus down but fable up) degrades
    gracefully. A model that just failed is briefly tried only ONCE (cooldown) so we reach the working model
    fast during an outage, then go back to the best model once it recovers."""
    primary = model or PROMPT_MODEL
    chain, seen = [], set()
    for m in [primary, *_CLAUDE_FALLBACKS]:
        if m and m not in seen:
            seen.add(m); chain.append(m)
    now = time.time()
    last = None
    for i, mdl in enumerate(chain):
        recent_fail = (now - _MODEL_COOLDOWN.get(mdl, 0)) < 90     # Kie broke this model in the last 90s
        t = 1 if recent_fail else (tries if i == 0 else 3)         # full budget for the best model; probe others briefly
        try:
            r = _retry(lambda mdl=mdl: _claude_stream_once(system, user, max_tokens, mdl), tries=t, base=0.8)
            _MODEL_COOLDOWN.pop(mdl, None)                          # recovered → best model is preferred again
            return r
        except Exception as e:
            _MODEL_COOLDOWN[mdl] = time.time()
            last = e
    raise last if last else RuntimeError("no model available")

# ---- TEXT PROVIDER: the user's Claude subscription via the local Claude Code CLI (no API key, no per-token cost) ----
# EVERY text/script LLM call funnels through _claude_text. Default provider = the local `claude` CLI (subscription).
# Set VSL_TEXT_PROVIDER=kie to route every text step back to the Kie.ai API. Images/video ALWAYS use Kie regardless.
TEXT_PROVIDER = (os.environ.get("VSL_TEXT_PROVIDER") or "claude").strip().lower()
_CLAUDE_EXE_CACHE = None

class ClaudeNotLoggedIn(RuntimeError):
    pass

def _find_claude_exe():
    """Locate the installed Claude Code CLI (winget/native/PATH). Cached. None if not installed."""
    global _CLAUDE_EXE_CACHE
    if _CLAUDE_EXE_CACHE is not None:
        return _CLAUDE_EXE_CACHE or None
    import shutil, glob as _glob
    cands = []
    la = os.environ.get("LOCALAPPDATA", "")
    if la:
        cands.append(os.path.join(la, "Microsoft", "WinGet", "Links", "claude.exe"))
        cands += _glob.glob(os.path.join(la, "Microsoft", "WinGet", "Packages", "Anthropic.ClaudeCode*", "claude.exe"))
        cands.append(os.path.join(la, "Programs", "claude.exe"))
    w = shutil.which("claude")
    if w:
        cands.append(w)
    for c in cands:
        if c and os.path.exists(c):
            _CLAUDE_EXE_CACHE = c
            return c
    _CLAUDE_EXE_CACHE = ""
    return None

def _cli_model(model):
    m = (model or "").lower()
    if "sonnet" in m: return "sonnet"
    if "haiku" in m: return "haiku"
    return "opus"                       # default (and fable/opus) -> the subscription's best

def _claude_cwd():
    """A PER-THREAD empty working dir for a `claude -p` call. When we run several Claude calls in parallel
    (Check Images, Analyze Cast, director chunks…) each thread gets its OWN cwd, so the CLI's per-project session
    state can never collide between concurrent calls. Falls back to the system temp dir if creation fails."""
    d = os.path.join(tempfile.gettempdir(), "vsl_claude", str(threading.get_ident()))
    try:
        os.makedirs(d, exist_ok=True)
        return d
    except Exception:
        return tempfile.gettempdir()

def _claude_cli_web(system, user, model=None, timeout=240):
    """The same subscription call, but allowed to SEARCH. Used only where the answer depends on what
    happened this week - the model's own knowledge has a cutoff and would quietly invent a plausible
    week. Everything else stays on the plain, tool-free call."""
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed on this PC.")
    args = [exe, "-p", "--model", _cli_model(model), "--fallback-model", "sonnet",
            "--allowedTools", "WebSearch", "--system-prompt", system, "--output-format", "text"]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    p = subprocess.run(args, input=(user or "").encode("utf-8"), stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, cwd=_claude_cwd(), startupinfo=si, timeout=timeout)
    out = (p.stdout or b"").decode("utf-8", "ignore").strip()
    if not out:
        raise RuntimeError((p.stderr or b"").decode("utf-8", "ignore").strip()[:200] or "no answer")
    return out


def _claude_cli_text(system, user, model=None, no_tools=False):
    """One text completion through the local Claude Code CLI = the user's SUBSCRIPTION (no API key/cost).
    Raises ClaudeNotLoggedIn if the CLI is missing or not logged in so the UI can warn (NO Kie fallback)."""
    import tempfile
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed on this PC. Install it (winget install Anthropic.ClaudeCode) and run 'claude' to log in.")
    prim = _cli_model(model)
    fb = "sonnet" if prim != "sonnet" else "haiku"
    cwd = _claude_cwd()                          # PER-THREAD empty dir → concurrent claude calls never share session state
    args = [exe, "-p", "--model", prim, "--fallback-model", fb,
            "--system-prompt", system, "--output-format", "text"]
    if no_tools:
        # `--tools ""` disables the whole built-in set. Checked against a canary file: asked to read a
        # file in its own working directory, the reply is a refusal and the file's contents never
        # appear. This is what makes the help assistant structurally unable to touch anything - the
        # empty cwd alone was never a guarantee.
        args += ["--tools", ""]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    def _do():
        p = subprocess.run(args, input=(user or "").encode("utf-8"),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           cwd=cwd, startupinfo=si, timeout=300)
        out = (p.stdout or b"").decode("utf-8", "ignore").strip()
        err = (p.stderr or b"").decode("utf-8", "ignore").strip()
        if "Not logged in" in out or "Please run /login" in out or "Not logged in" in err:
            raise ClaudeNotLoggedIn("Your Claude subscription is not logged in on this PC. Open a terminal, run 'claude', and log in — then try again.")
        if not out:
            raise RuntimeError(err or "empty response from Claude CLI")
        return out
    return _retry(_do, tries=3, base=0.8)

def _claude_text(system, user, max_tokens=1024, model=None, tries=8):
    """Single entry point for ALL text/script LLM calls (split, director, cast, ingredients, avatar, prompt,
    still-image, translate, FAQ keywords, audit). Default provider = the local Claude Code CLI (the user's
    subscription, no API cost); set VSL_TEXT_PROVIDER=kie to route every text step back to Kie.ai. Images/video
    always use Kie regardless. On the CLI provider there is NO silent Kie fallback — a clear ClaudeNotLoggedIn
    error surfaces so the user knows to log in on this machine."""
    if TEXT_PROVIDER == "kie":
        return _claude_text_kie(system, user, max_tokens=max_tokens, model=model, tries=tries)
    return _claude_cli_text(system, user, model=model)

def _claude_cli_stream(system, user, model=None):
    """Yield the answer in pieces as Claude writes it. NO tools, same as _claude_cli_text.

    Measured on a real question: the first words arrive at 1.5 s where the finished answer takes 14 s,
    in 227 pieces. Waiting 14 seconds at three dots reads as broken to someone who did not build the
    app, which is the whole audience for this.

    `--output-format stream-json` alone is not enough - it emits one complete assistant message at the
    end. `--include-partial-messages` is what adds the content_block_delta events this reads.
    """
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed on this PC. Install it (winget install Anthropic.ClaudeCode) and run 'claude' to log in.")
    prim = _cli_model(model)
    args = [exe, "-p", "--model", prim, "--fallback-model", ("sonnet" if prim != "sonnet" else "haiku"),
            "--system-prompt", system, "--tools", "",
            "--output-format", "stream-json", "--include-partial-messages", "--verbose"]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    p = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         cwd=_claude_cwd(), startupinfo=si)
    try:
        p.stdin.write((user or "").encode("utf-8"))
        p.stdin.close()
        got = False
        for raw in io.TextIOWrapper(p.stdout, encoding="utf-8", errors="ignore"):
            raw = raw.strip()
            if not raw:
                continue
            try:
                o = json.loads(raw)
            except Exception:
                continue
            if o.get("type") == "stream_event":
                ev = o.get("event") or {}
                if ev.get("type") == "content_block_delta":
                    piece = (ev.get("delta") or {}).get("text")
                    if piece:
                        got = True
                        yield piece
            elif o.get("type") == "result" and not got:
                # nothing streamed (a very short reply can land whole) - fall back to the final text
                fin = o.get("result")
                if fin:
                    got = True
                    yield fin
        p.wait(timeout=30)
        if not got:
            err = (p.stderr.read() or b"").decode("utf-8", "ignore")[:200]
            if "Not logged in" in err or "Please run /login" in err:
                raise ClaudeNotLoggedIn("Your Claude subscription is not logged in on this PC. Open a terminal, run 'claude', and log in - then try again.")
            raise RuntimeError(err or "no answer came back")
    finally:
        try:
            if p.poll() is None:
                p.kill()
        except Exception as _qe:
            quiet(_qe, "_claude_cli_stream")


@app.route("/api/ai-baran", methods=["POST"])
def api_ai_baran():
    """The help assistant. Takes a question (and optionally the project the user is looking at) and
    returns an answer. Reads nothing, writes nothing, changes nothing - see ai_baran.py."""
    body = request.get_json(force=True, silent=True) or {}
    q = (body.get("q") or "").strip()
    if not q:
        return jsonify({"error": "ask me something"}), 400
    project = (body.get("project") or "").strip()
    if not session.get("user"):
        project = ""          # not signed in -> general help only, never a project's contents
    doc, media = None, None
    if project:
        try:
            doc = load_doc(project)
        except Exception:
            doc = None
        try:
            # the voice-over and the subtitles are FILES, not fields in scenes.json
            sd = sub_dir(project)
            srts = sorted(sd.glob("*.srt")) if sd.exists() else []
            media = {"voiceover": (sd / "audio.mp3").exists(),
                     "trimmed": (sd / "voiceover_trimmed.mp3").exists(),
                     "srt": bool(srts)}
        except Exception:
            media = None
    system = ai_baran.build_system(doc, project or None, media, body.get("last_error"))
    user = ai_baran.build_user(q, body.get("history"))
    if not _find_claude_exe():                   # fail BEFORE the stream opens, so the 428 still works
        raise ClaudeNotLoggedIn("Claude Code is not installed on this PC. Install it (winget install Anthropic.ClaudeCode) and run 'claude' to log in.")

    def _pieces():
        """NDJSON: {"t": "..."} for text, {"error": "..."} if it breaks, {"done": true} at the end.
        Once the first byte is out the status line is fixed, so an error has to travel in the body."""
        whole = []
        try:
            for piece in _claude_cli_stream(system, user):
                whole.append(piece)
                yield json.dumps({"t": piece}, ensure_ascii=False) + "\n"
        except ClaudeNotLoggedIn as e:
            yield json.dumps({"error": str(e), "claude_auth": True}, ensure_ascii=False) + "\n"
            return
        except Exception as e:
            yield json.dumps({"error": "I could not reach Claude just now (%s). Try again in a moment."
                              % (str(e)[:120])}, ensure_ascii=False) + "\n"
            return
        answer = "".join(whole)
        _ai_baran_log(project, q, answer)
        yield json.dumps({"done": True, "kb_version": ai_baran.KB_VERSION}) + "\n"

    # nosniff is NOT optional here: without it Chromium holds the first 1024 bytes back to sniff the
    # MIME type, and a short answer arrives in one lump at the end - the server streams perfectly and
    # the window still sits there showing dots. Measured both ways.
    return Response(stream_with_context(_pieces()), mimetype="application/x-ndjson",
                    headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no",
                             "X-Content-Type-Options": "nosniff"})


def _ai_baran_log(project, q, answer):
    """Keep the questions locally so the knowledge can be refreshed against what people actually ask -
    especially the ones it had to turn away. Never leaves this machine; failure is never fatal."""
    try:
        p = DATA_DIR / "ai_baran_log.jsonl"
        row = {"t": int(time.time()), "project": project or "", "q": q[:500],
               "unanswered": ("ask Baran" in answer or "sor" in answer[-160:].lower()),
               "a": answer[:400]}
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception as _qe:
        quiet(_qe, "_ai_baran_log")


# ---- Claude account connection (Settings -> Keys) --------------------------
_CLAUDE_LOGIN_OK = [False]      # session cache: once a test call succeeds, don't re-test on every status poll

@app.errorhandler(ClaudeNotLoggedIn)
def _handle_claude_not_logged_in(e):
    """Any route that lets a ClaudeNotLoggedIn propagate returns a flagged JSON so the UI shows Connect-Claude."""
    return jsonify({"error": str(e), "claude_auth": True}), 428

@app.route("/api/claude/status")
def api_claude_status():
    """{installed, logged_in} for the Connect-Claude UI. Re-detects the CLI (may have just been installed) and,
    if found, does ONE tiny test completion to confirm the subscription is logged in (cached once true)."""
    global _CLAUDE_EXE_CACHE
    _CLAUDE_EXE_CACHE = None
    if not _find_claude_exe():
        return jsonify({"installed": False, "logged_in": False})
    if _CLAUDE_LOGIN_OK[0]:
        return jsonify({"installed": True, "logged_in": True})
    try:
        _claude_cli_text("Reply with exactly: ok", "ok")
        _CLAUDE_LOGIN_OK[0] = True
        return jsonify({"installed": True, "logged_in": True})
    except ClaudeNotLoggedIn:
        return jsonify({"installed": True, "logged_in": False})
    except Exception:
        return jsonify({"installed": True, "logged_in": True})     # transient (timeout/network): don't nag

@app.route("/api/claude/login", methods=["POST"])
def api_claude_login():
    """Open the Claude Code CLI in its own console so the user completes the browser login there, then returns
    and clicks 'Check again'. If the CLI isn't installed, hand back the one-line install command."""
    global _CLAUDE_EXE_CACHE
    _CLAUDE_EXE_CACHE = None
    exe = _find_claude_exe()
    if not exe:
        return jsonify({"ok": False, "installed": False,
                        "error": "Claude Code isn't installed on this PC yet.",
                        "install_cmd": "winget install --id Anthropic.ClaudeCode"})
    try:
        if os.name == "nt":
            subprocess.Popen([exe], creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        else:
            subprocess.Popen([exe])
        _CLAUDE_LOGIN_OK[0] = False
        return jsonify({"ok": True, "installed": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})

def _claude_vision(system, user, image_path, model=None):
    """One VISION completion via the local Claude Code CLI (the user's SUBSCRIPTION): it opens the image file
    and answers based on what is ACTUALLY in it. Used for image-aware video-prompt generation / QA. Uses OPUS by
    default (maximum quality — the user prioritises quality; the parallel batch runner keeps it fast). Raises
    ClaudeNotLoggedIn if the CLI is missing or not logged in."""
    import tempfile
    exe = _find_claude_exe()
    if not exe:
        raise ClaudeNotLoggedIn("Claude Code is not installed / not logged in on this PC.")
    prim = _cli_model(model or PROMPT_MODEL)          # OPUS by default (was Sonnet) — max-quality vision QA
    imgdir = os.path.dirname(image_path)
    args = [exe, "-p", "--model", prim, "--system-prompt", system, "--output-format", "text",
            "--allowedTools", "Read", "--add-dir", imgdir]
    si = None
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    full = f"{user}\n\nOpen and LOOK AT this image file, then answer: {image_path}"
    def _do():
        p = subprocess.run(args, input=full.encode("utf-8"), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           cwd=_claude_cwd(), startupinfo=si, timeout=180)   # per-thread cwd; image read via --add-dir + abs path
        out = (p.stdout or b"").decode("utf-8", "ignore").strip()
        err = (p.stderr or b"").decode("utf-8", "ignore").strip()
        if "Not logged in" in out or "Please run /login" in out or "Not logged in" in err:
            raise ClaudeNotLoggedIn("Your Claude subscription is not logged in on this PC. Run 'claude' and log in.")
        if not out:
            raise RuntimeError(err or "empty vision response")
        return out
    return _retry(_do, tries=2, base=0.8)

def claude_prompt(vo, onscreen, aud=None, forced_style=None, cast_names=None, brief="", vsl=False):
    """Ask Claude for (image_prompt, style_key) for ONE scene. `vsl` appends the sales-video notes; the
    audience's age range rides along so any age band the prompt writes sits inside it."""
    user = f"VO sentence: {vo}"
    if onscreen:
        user += f"\nOn-screen note: {onscreen}"
    _ages = [str(a).strip() for a in ((aud or {}).get("ages") or []) if str(a).strip()]
    if _ages:
        user += (f"\nAUDIENCE: ordinary/relatable people are adults in the {' or '.join(_ages)} age range - any age band "
                 f"you write sits inside it.")
    if (brief or "").strip():
        user += (f"\n\nPROJECT CONTEXT (background about the whole project — may be in Turkish; for CONSISTENCY only): "
                 f"{brief.strip()}\nUse it to keep people, places, product and style consistent across scenes, but depict "
                 f"ONLY what THIS scene's VO describes — do NOT add the product, characters, or details the VO doesn't "
                 f"mention. Always write the final description in English.")
    if cast_names:
        user += (f"\nNamed characters present in THIS scene: {', '.join(cast_names)}. "
                 "When one of them appears, refer to them by their name (e.g. write the name, not "
                 "'a woman' / 'a man'). Do NOT invent characters who aren't in the sentence.")
    if forced_style:
        user += f"\nRequired STYLE: {forced_style}"
        if forced_style in ANIM_STYLES:
            _medium = "SIMPLE flat 2D cartoon" if forced_style == "2d" else "stylised 3D animation render"
            user += (f"\nThis scene will be drawn as a {_medium}, so describe it simply and iconically: "
                     "the key subject(s), their action, and only the one or two essential objects. Do NOT pile on fine "
                     "realistic micro-detail, intricate textures, or photographic specifics — those don't suit it.")
        elif forced_style == "scientific":
            user += ("\nThis scene is a medical / scientific visualization (inside the body, an organ, cells, etc.), so "
                     "describe the anatomical subject and what it shows clearly and specifically.")
    text = _claude_text(PROMPT_SYSTEM + (PROMPT_VSL if vsl else ""), user)
    style = None
    m = re.match(r"\s*STYLE:\s*([a-zA-Z0-9]+)", text)
    if m:
        k = m.group(1).lower()
        if k in STYLE_KEYS:
            style = k
        text = text[m.end():].lstrip("\n").strip()
    if forced_style:
        style = forced_style
    return text, style

def translate_to_english(text):
    return _claude_text(
        "Translate the user's image-generation prompt into natural English. "
        "Keep it as one single prompt with the same meaning. Output ONLY the translation.",
        text)

def localize_prompt(prompt, aud, translate=True, signage=False):
    """Translate Turkish prompts to English. `translate=False` keeps the user's exact wording.
    `signage=True` also requires any on-image text to be in the country's language — OFF by default
    because image prompts end with 'No text.', so a signage-language clause would only contradict it."""
    p = prompt or ""
    if translate and looks_turkish(p):
        try:
            p = translate_to_english(p)
        except Exception as _qe:
            quiet(_qe, "localize_prompt")
    if signage:
        lang = country_language(aud)
        if lang and lang != "English":
            p = p.rstrip() + f" If any text, signage, or packaging appears, it must be written in {lang}."
    return p

# Money/price cues (English + Turkish). The currency directive below is emitted ONLY when the shot
# actually depicts money — so its "£ symbol" tokens can't leak onto money-less scenes. Image models
# ignore the "if any money appears" conditional and would otherwise sprinkle a £ into e.g. a phone-call
# shot (scene #58). Precision-tuned: 'sipariş'/'al'/'öde-'stem excluded so 'paragraf','ödev' don't trip it.
_MONEY_CUES = re.compile(
    r"[£$€₺]"
    r"|\b(money|cash|price[ds]?|pricing|cost|costs|costly|pay|paying|payment|payments|paid"
    r"|buy|buying|bought|purchas\w+|checkout|check-out|receipt|invoice|wallet|coin|coins"
    r"|dollar|dollars|euro|euros|currency|discount|discounts|afford|affordable|budget"
    r"|fee|fees|subscription|refund|refunds|coupon|price[- ]?tag|banknotes?|bills?|quid|spend|spent|spending|savings?)\b"
    r"|\bpara(lar|m|n|sı|yı|ya|yla|nın)?\b"
    r"|\bfiyat\w*|\bücret\w*|\bödeme\b|\bsatın\b|\balışveriş\w*"
    r"|\bsepet\w*|\bfatura\w*|\bmakbuz\w*|\bcüzdan\w*|\bnakit\b|\blira\b|\bsterlin\b"
    r"|\bkuruş\b|\bindirim\w*|\btaksit\w*|\bbütçe\w*|\bpahalı\b|\bucuz\b",
    re.I)
# "pound(s)" is ambiguous — MONEY (£) vs WEIGHT (lbs). Only treat it as money when it's clearly not weight.
_WEIGHT_CUES = re.compile(r"\b(weigh\w*|weight|lost|lose|losing|los[et]|shed\w*|dropp\w*|lighter|slim\w*|"
                          r"leaner|thinner|fatter|overweight|obese|scales?|kg|kilo\w*|lbs|belly|body ?weight)\b", re.I)
def _mentions_money(text):
    """True if the shot description plausibly depicts money/prices (English or Turkish)."""
    t = text or ""
    if _MONEY_CUES.search(t):
        return True
    # a NUMBER + "pound(s)" reads as money ONLY when the shot isn't clearly about weight (lost/weigh/slim…)
    if re.search(r"\b\d[\d,.]*\s*pounds?\b", t, re.I) and not _WEIGHT_CUES.search(t):
        return True
    return False

def _currency_clause(aud, text=""):
    """Currency directive for the final image prompt — emitted ONLY when `text` (the shot description)
    actually shows money/prices. Gating on money content stops the "£ symbol" tokens leaking onto
    money-less scenes. Fixes the model defaulting to US dollars when the audience is e.g. UK/£."""
    curs = [str(c).strip() for c in ((aud or {}).get("currencies") or []) if str(c).strip()]
    if not curs or not _mentions_money(text):
        return ""
    hint = _CURRENCY_HINT.get(curs[0].lower(), curs[0])
    clause = (f"Any money, cash, banknotes, prices or price tags anywhere in the image MUST be {hint} — the correct "
              f"real banknotes/coins and symbol for that currency. Do NOT show US dollars, dollar bills or the $ "
              f"symbol (unless that IS the currency above), and do not mix currencies.")
    if curs[0].lower() in ("pound", "gbp", "sterling"):
        clause += " Here 'pounds' means British MONEY (£ sterling banknotes), not a unit of weight."
    return clause

def _raw_audience_note(aud, text=""):
    """Compact Target-Audience reminder appended to a RAW (user-written) prompt: market/location, age band,
    excluded looks, and currency. Kept short so it never rewrites the user's own wording — used ONLY in raw mode.
    `text` is the shot description; the currency line is added only if it actually depicts money/prices."""
    if not aud:
        return ""
    bits = []
    locs = [str(x).strip() for x in (aud.get("locations") or []) if str(x).strip()]
    if locs:
        bits.append(f"Set it in a {', '.join(locs)} context — signage, packaging, products and surroundings "
                    f"appropriate to {', '.join(locs)}.")
    ages = [str(a).strip() for a in (aud.get("ages") or []) if str(a).strip()]
    if ages:
        bits.append(f"Any ordinary people shown should be adults roughly in the {' or '.join(ages)} age range.")
    av = (aud.get("avatar") or "").strip()
    if av:
        bits.append(f"Any ordinary/relatable person shown is the target viewer — they look like: {av} (match this to the "
                    f"before/after state your prompt describes).")
    looks, banned = _split_avoid(aud.get("appearance"))
    if looks:
        bits.append("Do NOT depict ordinary people who look " + ", ".join(looks) + ".")
    if banned:
        bits.append("NEVER depict, imply or hint at any of these anywhere in the image: "
                    + ", ".join(banned) + ".")
    cc = _currency_clause(aud, text)
    if cc:
        bits.append(cc)
    return " ".join(bits)

def bind_named_cast(s, doc):
    """Ensure every roster character NAMED in the scene's prompt is in the scene's cast, so their reference
    face actually attaches (fixes e.g. a split's LEFT half naming 'Dr Carbonell' but her not being cast).
    Additive only — never removes a cast the user picked. Skipped for RAW scenes. Returns True if it changed."""
    if s.get("no_cast"):
        return False
    prompt = (s.get("prompt") or "")
    if not prompt.strip():
        return False
    low = prompt.lower()
    chars = doc.get("characters") or []
    # How many characters own each name token → a token shared by 2+ people (e.g. two "Dr Stefan"s) is AMBIGUOUS
    # and must NOT auto-bind, so we never attach the wrong face. A unique token (surname/first name) binds fine.
    owners = {}
    char_toks = {}
    for c in chars:
        toks = _char_name_tokens(c.get("name"))
        char_toks[c.get("id")] = toks
        for t in toks:
            owners[t] = owners.get(t, 0) + 1
    cast = s.setdefault("cast", [])
    locked = set(s.get("cast_locked") or [])   # ids the user explicitly removed → never silently re-add them
    changed = False
    for c in chars:
        cid = c.get("id")
        name = (c.get("name") or "").strip()
        if not cid or not name or cid in cast or cid in locked:
            continue
        # match on the full name, or on any name token that is UNIQUE to this character
        if any(owners.get(t, 0) == 1 and _text_has_word(t, low) for t in char_toks.get(cid, [])):
            cast.append(cid)
            changed = True
    return changed

def _rebind_all_cast(doc):
    """Re-run bind_named_cast over every NON-APPROVED scene. Called after a cast member is added or gets a new
    reference photo, so a character the director already wrote into scene prompts (e.g. a late-detected Narrator)
    gets attached to those scenes' cast the moment their photo exists — no manual re-director needed. Additive
    only (respects cast_locked, never touches approved scenes). Returns the number of scenes changed."""
    n = 0
    for s in doc.get("scenes") or []:
        if s.get("approved"):
            continue
        if bind_named_cast(s, doc):
            n += 1
    return n



# A panel marker is the label word (left/middle/right) optionally followed by its inline look, then a colon —
# e.g. "LEFT:" OR "LEFT, photorealistic:" OR "RIGHT, scientific 3D medical illustration:".
def _panel_mark_re(key):
    return r"(?<![a-z])" + key + r"\b[^:\n]{0,40}:"


def _prompt_names_panels(prompt_text):
    """Does this description actually lay out panels? Same markers _split_clause reads, so the flag and
    the clause can never disagree about what the prompt says."""
    low = (prompt_text or "").lower()
    return bool(re.search(r"(?<![a-z])(?:top|bottom)[ -](?:left|right)\b[^:\n]{0,40}:", low)
                or re.search(_panel_mark_re("left"), low)
                or re.search(_panel_mark_re("right"), low)
                or re.search(_panel_mark_re("middle"), low)
                or re.search(r"\bpanel\s*\d\s*:", low))


def _split_clause(prompt_text):
    """Pick two-/three-/four-panel wording from what the prompt actually describes (a MIDDLE panel → triptych; a
    TOP-LEFT/BOTTOM-… panel → 2x2 quad)."""
    low = (prompt_text or "").lower()
    if re.search(r"(?<![a-z])(?:top|bottom)[ -](?:left|right)\b[^:\n]{0,40}:", low):
        return SPLIT_CLAUSE_4
    return SPLIT_CLAUSE_3 if re.search(_panel_mark_re("middle"), low) else SPLIT_CLAUSE

def _split_default_look(style):
    """A split skips the single global STYLE preset (each panel can state its own look). But the bare word
    'photorealistic' in a panel is a WEAK anchor — the model drifts to a glossy CGI/stock look. So re-apply
    the chosen style's FULL guidance as the DEFAULT look for any panel that doesn't explicitly call for a
    different medium. This is what pulls a 'photorealistic' panel back to a real, candid photo."""
    preset = STYLE_PRESETS.get(style or "natural", "")
    if not preset:
        return ""
    return ("DEFAULT LOOK — apply this to EVERY panel whose own description does not explicitly call for a "
            "different medium (a panel that literally says it is a 2D cartoon, or a scientific 3D medical "
            "illustration, keeps that): " + preset.strip())

def _panel_side_of(prompt_text, name):
    """Which panel (LEFT / MIDDLE / RIGHT) a named person is described in, by reading the split prompt. None
    if it can't be determined."""
    low = (prompt_text or "").lower()
    marks = []
    for key, disp in (("left", "LEFT"), ("middle", "MIDDLE"), ("right", "RIGHT")):
        m = re.search(_panel_mark_re(key), low)
        if m:
            marks.append((m.start(), disp))
    marks.sort()
    idx = low.find((name or "").lower())
    if idx < 0 or not marks:
        return None
    cur = None
    for p, disp in marks:
        if p <= idx:
            cur = disp
        else:
            break
    return cur

def _split_who(scene, chars):
    """WHO wording for a SPLIT with named cast: bind EACH person to their OWN reference face and their OWN
    panel, and forbid duplicating one face across panels. Fixes the bug where two different people (each with
    a photo) collapsed to the same face in both halves."""
    prompt = scene.get("prompt") or ""
    bits = []
    for c in chars:
        nm = c.get("name")
        if not nm:
            continue
        sd = _panel_side_of(prompt, nm)
        bits.append(f"{nm} (the {sd} panel)" if sd else nm)
    who = "; ".join(bits)
    return ("The reference images show DIFFERENT people, one per panel: " + who + ". Give EACH named person "
            "their OWN face and appearance from their OWN reference image — they are DISTINCT individuals and "
            "MUST look clearly different. Do NOT reuse or duplicate the same face across panels: the person in "
            "one panel must NOT also appear in another panel.")

def _multi_who(chars):
    """WHO wording for a NON-split scene with 2+ named cast that have photos: bind each face to the right
    person (photos are provided in cast order) and forbid blending/swapping. The single-frame cousin of
    _split_who — fixes two different people collapsing into one face when several references are attached."""
    names = [c.get("name") for c in chars if c.get("name")]
    order = ", then ".join(names)
    joined = ", ".join(names)
    return (f"The reference photos of these DIFFERENT people are provided in this order: {order}. Give EACH person "
            f"their OWN face and appearance from their OWN photo — {joined} are DISTINCT individuals; do NOT blend, "
            f"swap or merge their faces. (Any other reference image is a prop/product or a previous frame, not these people.)")

# A shot whose only human is "a technician", "blurred workers", "a pharmacist" describes a PERSON just as
# surely as one that says "a man" - but none of these words was in the list below, so the whole audience
# layer was skipped for those scenes and the model drew whoever it liked. On a French 50-80 audience that
# excludes five looks, a lab bench came back with an East Asian technician and nothing had been sent to
# prevent it. Applies to BOTH project types: the audience setting is the same setting on either side,
# and a person named by their job is a person in a YouTube episode too.
_ORDINARY_JOBS = re.compile(
    r"\b(technicians?|workers?|scientists?|researchers?|doctors?|nurses?|pharmacists?|chemists?|"
    r"operators?|employees?|couriers?|drivers?|farmers?|growers?|analysts?|specialists?|surgeons?|"
    r"therapists?|assistants?|inspectors?|packers?|labourers?|laborers?|staff|crew)\b", re.I)


# Does the scene already dress its people? Then the outfit nudge has nothing to add and everything to
# break - it put a striped tee on a farmer the prompt had already put in a canvas jacket.
_GARMENT = re.compile(
    r"(?i)\b(hi-?vis|vest|jacket|coat|shirt|t-?shirts?|tee|blouse|dress|jumper|sweater|cardigan|polo|"
    r"uniform|scrubs|hairnet|apron|overalls?|gown|suit|anorak|fleece|hoodie|tunic|headscarf|pyjamas)\b")
# Two or more people described in the scene and "the main ordinary person" no longer points at anybody -
# the nudge lands on whichever one the model feels like, and on a different one each attempt.
# A plural noun says "several people" outright.
_PEOPLE_PLURAL = re.compile(
    r"(?i)\b(men|women|people|workers|technicians|researchers|scientists|farmers|friends|colleagues|"
    r"customers|patients|couple|crowd|team|group|others|everyone)\b")
# ...otherwise count separate SUBJECTS. The generic words person/people are deliberately NOT here:
# "she is the only person in the picture" is one person, and counting bare nouns read it as two.
_PERSON_SUBJ = re.compile(
    r"(?i)\b(?:a|an|the)\s+(?:[a-z-]+\s+){0,3}?"
    r"(man|woman|worker|technician|farmer|buyer|pharmacist|doctor|nurse|scientist|operator|courier|"
    r"husband|wife|lady|guy|boy|girl)\b")
# A forced mole or scattering of freckles is not variety, it is a blemish the user then has to edit out.
_BLEMISH = re.compile(r"(?i)\s+and\s+(?:a small mole on one cheek|a light scatter of freckles)")


# Which staging positions FIGHT an explicitly chosen camera. Looking straight down is not a wide
# establishing shot; hands-only is not a wide shot either; standing far back is not a close-up. When the
# user has picked a framing, only offer the positions that can live with it.
_STAGING_CONFLICTS = {
    "wide":    ("from directly above", "with ONLY their hands", "very close on their face", "low and tight"),
    "medium":  ("from directly above", "with ONLY their hands", "very close on their face"),
    "closeup": ("from directly above", "far back, the person small"),
    "extreme": ("from directly above", "far back, the person small", "framed through a doorway"),
    "ots":     ("from directly above", "as a reflection", "with ONLY their hands", "far back, the person small"),
    "side":    ("from directly above", "from behind them", "as a reflection"),
    "top":     ("at eye level", "from one side in profile", "from down near the floor", "from behind them",
                "very close on their face", "as a reflection"),
}


def _staging_choices(camera, vsl):
    """The staging positions that do not contradict the chosen camera."""
    if not vsl:
        return list(_STAGING_VARIETY)
    bad = _STAGING_CONFLICTS.get((camera or "").strip().lower())
    if not bad:
        return list(_STAGING_VARIETY)
    keep = [t for t in _STAGING_VARIETY if not any(b in t for b in bad)]
    return keep or list(_STAGING_VARIETY)


def _face_variety_list(vsl, men=False):
    src = _FACE_VARIETY_MEN if (vsl and men) else _FACE_VARIETY
    return [_BLEMISH.sub("", x) for x in src] if vsl else list(src)


# Does the scene's own wording make the ordinary person a man, or a woman? Both, or neither -> the neutral list.
_MAN_WORD = re.compile(r"(?i)\b(man|men|husband|father|dad|grandfather|grandpa|gentleman|guy|boy|he|his|him)\b")
_WOMAN_WORD = re.compile(r"(?i)\b(woman|women|wife|mother|mum|mom|grandmother|grandma|lady|girl|she|her|hers)\b")
# The avatar fixes the body ("overweight, tired women") - then the build never rotates, the before/after owns it.
_AVATAR_BODY = re.compile(r"(?i)\b(overweight|obese|heavy|heavier|slim|slimmer|thin|lean|fat|weight|belly|curvy|"
                          r"plump|stone|kilos?|pounds|lbs)\b")
# ...and so does a scene that already says what shape its person is.
_BUILD_WORDS = re.compile(r"(?i)\b(slim|stocky|heavy-?set|thin|lean|overweight|obese|plump|petite|broad-shouldered|"
                          r"wiry|muscular|athletic|frail|chubby|skinny|burly|portly|well-built|curvy|big-boned)\b")


def _hair_choices(ages, excl):
    """The hair colours an ordinary person may have in THIS project: the shades that fit the audience's age
    band, minus whatever its excluded-looks list rules out. Empty when nothing fits (then no colour is named)."""
    starts = []
    for a in (ages or []):
        m = re.match(r"\s*(\d+)", str(a))
        if m:
            starts.append(int(m.group(1)))
    older = (not starts) or all(x >= 45 for x in starts)
    ex = " ".join(str(x) for x in (excl or [])).lower()
    out = []
    for shade, band in _HAIR_COLOURS:
        if band == "older" and not older:
            continue
        if "blonde" in ex and shade in ("ash blonde", "sandy"):
            continue
        if ("redhead" in ex or "orange" in ex) and shade in ("dyed auburn", "chestnut"):
            continue
        if "brunette" in ex and shade in ("light brown", "dark brown", "chestnut", "grey-streaked dark"):
            continue
        if "black hair" in ex and shade == "black":
            continue
        out.append(shade)
    return out


# A shot set in a home, and a home that is already described (then the rotating look stays out of it).
_HOME_ROOM = re.compile(r"\b(kitchen|living[- ]room|lounge|bedroom|dining|hallway|flat|apartment|home office|"
                        r"at home|in (his|her|their) home|house|sitting room|study|bathroom)\b", re.I)
_HOME_DETAIL = re.compile(r"\b(cabinet|cupboard|worktop|countertop|counter|walnut|oak|marble|granite|laminate|"
                          r"wallpaper|tiles?|tiled|sofa|armchair|curtain|sideboard|island|pendant|floorboards|"
                          r"terracotta|conservatory|patio)\b", re.I)


def _scene_has_ordinary(s):
    """Does this scene plausibly contain ORDINARY (non-cast) people? True if the director flagged a generic
    person, there is no named cast, or the prompt implies bystanders/crowd. Used to add the diversity /
    excluded-looks guidance ONLY when it's relevant (skips the noise on pure single-cast shots).

People named only by their OCCUPATION count too - see _ORDINARY_JOBS above."""
    if s.get("generic"):
        return True
    if _ORDINARY_JOBS.search(s.get("prompt") or ""):
        return True
    # NB: a scene with NO cast is NOT automatically "has ordinary people" — a product/object/anatomy shot has
    # no person, and injecting the target-viewer avatar there spawned a spurious (overweight) person. Require an
    # actual person cue in the prompt instead.
    p = (s.get("prompt") or "").lower()
    return bool(re.search(r"\b(people|crowd|everyone|others|family|friends|group|passers?-?by|bystander|audience|"
                          r"patients|customers|shoppers|colleagues|team|neighbou?rs|kids|children|"
                          r"woman|women|man|men|person|lady|guy|mother|father|mom|mum|dad|husband|wife|"
                          r"another (?:man|woman|person)|other (?:men|women|people))\b", p))


def _scene_ethnicity(s):
    """If the scene's OWN wording explicitly names a nationality/ethnicity for the PEOPLE in the shot (e.g.
    'des Japonais', 'Japanese people'), return the English label; else None. Does NOT fire when the nationality
    merely describes an OBJECT or a STUDY ('condiment japonais', 'étude coréenne') — that must not turn the
    on-screen VIEWER into that ethnicity (bug: an Asian French viewer for a 'condiment japonais' line)."""
    blob = " ".join(str(s.get(k) or "") for k in ("text", "vo", "vo_tr", "prompt", "shows"))
    low = blob.lower()
    for term, label in _ETHNIC_TERMS.items():
        for m in re.finditer(r"(?<![\w])" + re.escape(term) + r"(?![\w])", low):
            pre = low[max(0, m.start() - 30):m.start()]           # is it "<object> <nationality>"?
            if any(w in pre for w in _ETH_OBJECT_CTX):
                continue                                          # describes the condiment/study, not a person
            return label
    return None

def _gender_word(desc):
    """Confidently read a person's gender from their roster description, or None if unclear. Used only to
    ADD a gender anchor so a cast member keeps their gender even when the face is turned away / seen from
    behind (a reference photo can't lock gender when the face isn't visible). Never guesses when ambiguous."""
    d = " " + (desc or "").lower() + " "
    fem = bool(re.search(r"\b(woman|women|female|lady|girl|mother|wife|daughter|actress|businesswoman|grandmother|mom|mum)\b", d))
    masc = bool(re.search(r"\b(man|men|male|boy|father|husband|son|gentleman|businessman|grandfather|dad)\b", d))
    if fem and not masc:
        return "a woman"
    if masc and not fem:
        return "a man"
    return None

def _wants_text(prompt):
    """True if the prompt explicitly asks for specific text/numbers to be SHOWN in the image (a quoted phrase,
    a screen/label/sign reading something, 'show this number', etc.). Used to relax the blanket 'No text.' rule
    so the requested text survives while stray captions/watermarks are still blocked."""
    p = prompt or ""
    if re.search(r"[\"'“”‘’][^\"'“”‘’\n]{1,60}[\"'“”‘’]", p):   # any quoted phrase → they want it shown
        return True
    return bool(re.search(r"(reads?|reading|it says|that says|labell?ed|caption|on (the|its|her|his) screen|screen (show|display|read)|display(s|ing)?|billboard|headline|"
                          r"show(s|ing)? (this|these|the) (number|numbers|text|word|words|price|label|message|time|date))", p, re.I))

# ── Passive learning capture — records how sentences become prompts, changes NOTHING about generation ──
# Silently appends (voice-over line → the prompt + settings the director wrote, and the prompt finally
# APPROVED) to a log so we can LATER distil sentence→visual techniques into generalised director rules.
# Nothing is read back during normal use; every call is wrapped so it can never break a request. Turn off
# with env VSL_LEARN_CAPTURE=0.
LEARN_LOG = DATA_DIR / "learn" / "learn_log.jsonl"

def _stamp_director_prompt(scenes):
    """Remember the director's fresh prompt as a baseline on the scene, so when the user later hand-edits
    the prompt (even in Turkish) and approves, the (director original -> user final) delta is captured in
    one record — we can see exactly how the user rewrote the director's prompt for that sentence."""
    for sc in (scenes or []):
        try:
            if (sc.get("prompt") or "").strip():
                sc["director_prompt"] = sc["prompt"]
        except Exception as _qe:
            quiet(_qe, "_stamp_director_prompt")

def _learn_record(scene, doc):
    try:
        cast_names = [c.get("name") for c in scene_characters(scene, doc)] if doc else []
    except Exception:
        cast_names = []
    return {
        "ts": time.time(), "scene_id": scene.get("id"), "uid": scene.get("uid"),
        "vo": scene.get("vo") or "", "prompt": scene.get("prompt") or "",
        "director_prompt": scene.get("director_prompt") or "",   # what the director wrote before the user edited it
        "style": scene.get("style"), "camera": scene.get("camera"),
        "split": bool(scene.get("split")), "product": bool(scene.get("product")),
        "testimonial": bool(scene.get("testimonial")), "no_cast": bool(scene.get("no_cast")),
        "pure": bool(scene.get("pure")), "generic": scene.get("generic"),
        "ingredients": scene.get("ingredients") or [], "cast": cast_names,
    }

def _learn_log(event, project, doc, scenes):
    """event = 'director' (a prompt the director just wrote) or 'approved' (prompt on the approved version).
    Append-only, passive, best-effort — NEVER raises, NEVER affects the response."""
    try:
        if os.environ.get("VSL_LEARN_CAPTURE", "1") == "0":
            return
        aud = (doc or {}).get("audience") or {}
        aud_slim = {k: aud.get(k) for k in ("genders", "ages", "locations", "avatar", "appearance")}
        LEARN_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(LEARN_LOG, "a", encoding="utf-8") as f:
            for sc in (scenes or []):
                if (sc.get("note") or "").strip():
                    continue   # user left a NOTE on this scene → they plan to do something different in Premiere; exclude it from the learn data
                rec = _learn_record(sc, doc)
                if not (rec["prompt"].strip() or rec["testimonial"]):
                    continue
                rec.update(event=event, project=project, audience=aud_slim)
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception as _qe:
        quiet(_qe, "_learn_log")


def _grid_dims(n):
    """Rows/cols for a testimonial grid of n cells — landscape-biased (wider than tall), for 16:9."""
    layouts = {4: (2, 2), 6: (3, 2), 8: (4, 2), 9: (3, 3), 10: (5, 2), 12: (4, 3), 15: (5, 3), 16: (4, 4)}
    if n in layouts:
        return layouts[n]
    cols = max(2, round((n * 16 / 9) ** 0.5))
    rows = (n + cols - 1) // cols
    return cols, rows


def _testimonial_prompt(scene, aud):
    """Social-proof shot: ONE image laid out as an even grid of many SEPARATE amateur customer selfies, each an
    ordinary, SLIM, happy person holding the product. Built deterministically (ignores the written prompt) so it
    is consistent; the product reference attaches downstream so every bottle is the real product."""
    try:
        n = int(scene.get("testimonial_n") or 8)
    except (TypeError, ValueError):
        n = 8
    n = max(4, min(n, 16))
    cols, rows = _grid_dims(n)
    aud = aud or {}
    ages = [str(a).strip() for a in (aud.get("ages") or []) if str(a).strip()]
    age_phrase = " or ".join(ages) if ages else None
    excl = aud.get("appearance") or []
    parts = [
        f"One single photograph laid out as a STRICT grid of EXACTLY {cols} columns and {rows} rows — that is EXACTLY "
        f"{n} equal rectangular cells / {n} people IN TOTAL, no more and no fewer. Do NOT add any extra rows, columns, "
        f"cells or people beyond {rows} rows of {cols}. Equal-size cells separated by thin uniform white gaps, edge to "
        f"edge, filling the whole 16:9 frame.",
        f"Each of the {n} cells is a SEPARATE, authentic user-generated testimonial selfie of a DIFFERENT ordinary, "
        "real-looking, SLIM and happy person, each smiling warmly straight at the camera and holding the SAME product "
        "up toward the camera with one hand.",
        "Shoot every cell like a genuine phone snapshot in a DIFFERENT real place and pose — e.g. some SITTING on a "
        "sofa or at a table, some STANDING in a kitchen, some OUTDOORS in a garden / on a street / in a park, some in "
        "an office, a car or a cafe. Vary the background, lighting and time of day per cell. Real amateur UGC (a quick "
        "phone photo), NOT polished studio work, NOT stock photography, NOT professional models — ordinary, believable, "
        "genuinely happy satisfied customers.",
        "CRITICAL — every person is a COMPLETELY DIFFERENT, UNRELATED real stranger, like a collage of unrelated people; "
        "NEVER repeat a face and they must NOT look like siblings or the same person. Give them clearly different FACE "
        "SHAPES (round, oval, long, square, heart), different facial features, different HAIR (short, long, curly, "
        "straight, wavy, tied up, loose — and different natural shades within the allowed look), a real spread of AGES "
        "across the range (some in their late 40s, some in their 60s), and different expressions, glasses/no-glasses, "
        "clothing colours, settings and poses. No two cells should look alike. (Do NOT vary ethnicity — see the audience limit below.)",
        "AMATEUR QUALITY (very important — must NOT look like stock photography): each cell looks like a real customer's "
        "own phone snapshot — uneven / harsh available light (a touch of on-phone flash, mixed warm-and-cool indoor "
        "light, mild over- or under-exposure, some shadow on the face), slightly soft focus or minor motion blur, faint "
        "sensor noise/grain, imperfect white balance, a slightly awkward hand-held selfie angle and off-centre framing, "
        "and mundane, a little cluttered real backgrounds. The people are ORDINARY, plain, average-looking (NOT attractive "
        "models) with real UNRETOUCHED skin — visible pores, wrinkles, blemishes, redness, flyaway hair, some looking "
        "tired or plain. Absolutely NO studio lighting, NO softboxes, NO airbrushing/retouching, NO glossy stock-photo "
        "polish, NO perfect model faces.",
    ]
    who = []
    if age_phrase:
        who.append(f"adults roughly in the {age_phrase} age range (not younger or older)")
    if who:
        parts.append("The people are " + "; ".join(who) + ".")
    if excl:
        parts.append("STRICT audience limit — EVERY single person in the grid must fit the target audience: do NOT "
                     "include ANYONE who looks " + ", ".join(excl) + ". Keep all of them within the allowed look.")
    parts.append("The product every person holds is IDENTICAL to the product reference image — the SAME bottle/package "
                 "shape, label, wording and colours; do NOT redesign, rename or restyle it.")
    parts.append(_NO_ADDED_TEXT)
    return "\n".join(parts)



def build_image_prompt(scene, aud, chars=None, chars_desc=None, vsl=False):
    """Assemble the final Nano Banana prompt from NON-OVERLAPPING layers, each owning ONE thing so they
    can't conflict:  STYLE (how it looks) + SCENE (what's shown) + CAMERA (framing) + WHO (identity of
    recurring characters, via their reference image) + "No text".

    Audience gender/age/appearance is NOT bolted on here anymore (that collapsed everyone to one look and
    flipped genders scene-to-scene). Recurring people get their identity from the roster/reference; any
    ordinary/one-off person is already described (audience-appropriate) inside the scene text by the
    director. `chars` = the roster characters present in this scene that carry a reference image.
    The per-scene "no_cast" toggle = "MY PROMPT — raw": generate from the user's exact words like a direct
    manual generation. It drops the automatic layers the user did not ask for — the style preset, the
    photo-less roster cast, auto-translate, and the full-screen CARD (a card used to win over RAW, so
    whatever the user typed they got the word-art back). What RAW KEEPS is what the user set themselves:
    the camera angle from the dropdown, any reference image attached to the scene, a face-locked cast
    member who has a photo, and the audience's excluded looks — those must hold everywhere."""
    chars = chars or []
    if scene.get("testimonial"):
        # Social-proof crowd: a grid of many separate amateur customer selfies, each holding the product.
        return _testimonial_prompt(scene, aud)
    if scene.get("pure"):
        # PURE mode: your exact prompt + the camera framing, and ONLY the references YOU explicitly attached
        # (cast picked in In-scene, a chosen Product, ingredient chips, images you uploaded). No auto layers —
        # no style preset, no audience, no diversity, no "No text", no continuity, no binding verbiage.
        parts = [(scene.get("prompt") or "").strip()]
        if scene.get("split"):
            parts.append(_split_clause(scene.get("prompt")))
        pcam = None if scene.get("split") else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))
        if pcam:
            parts.append(pcam["prompt"])
        # You explicitly attached something → tell the model to actually USE it (a single vague "use the
        # references" line was too weak; the product/cast you picked was being ignored). Still NO style /
        # audience / no-text / continuity — only the identity of what YOU attached.
        refbits = []
        if chars:
            names = ", ".join(c.get("name", "?") for c in chars if c.get("name"))
            if names:
                refbits.append(f"The attached reference photo(s) show {names} — depict each with the SAME face and overall appearance as in their own photo.")
        if scene.get("product"):
            refbits.append("One of the attached reference images is the PRODUCT — depict it EXACTLY as shown (the SAME bottle/package shape, label, wording, colours and number of units — do NOT redesign or add/remove units) and place it naturally in the scene.")
        if scene.get("ingredients"):
            refbits.append("Some attached reference images are the product's INGREDIENTS — depict each exactly as in its own image, and only these.")
        if scene.get("refs"):
            refbits.append("The attached reference image(s) are the VISUAL BASIS for this shot — faithfully reproduce the "
                           "specific object(s), place, layout, product or style they show and keep them accurate; they are "
                           "there to be USED, do NOT ignore them or treat them as loose inspiration.")
        if refbits:
            parts.append(" ".join(refbits))
        # NO "no added text" clause in PURE (nor in RAW): these are your-exact-words modes, and the user may
        # deliberately want on-image text — a title card, a research-paper page, a labelled document, etc.
        return "\n".join(p for p in parts if p and p.strip())
    hand = bool(scene.get("no_cast"))
    if hand:
        # RAW mode ("My prompt"): send the user's prompt VERBATIM (their words, their language — not
        # translated, no style preset / camera / audience-diversity / "No text" layers). We add only:
        #   (a) FACE-LOCK for any cast in this scene that HAS a reference photo → the person still looks right,
        #   (b) a short AUDIENCE reminder (market/location, age band, excluded looks).
        # Any reference image the user attached is still sent as i2i.
        parts = [(scene.get("prompt") or "").strip()]
        if scene.get("split"):
            parts.append(_split_clause(scene.get("prompt")))
        # Honour the camera angle in RAW too (user asked) - but NOT on an anatomy render. Every preset is
        # written around "a PERSON shown from roughly the waist up", and read over a cross-section of an
        # artery that sentence is simply an instruction to add somebody.
        _sci = vsl and (scene.get("style") or "natural") == "scientific"
        rcam = None if (scene.get("split") or _sci) else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))
        if rcam:
            parts.append(rcam["prompt"])
        if chars:
            normal = [c for c in chars if not c.get("transforms")]
            trans = [c for c in chars if c.get("transforms")]
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference PHOTOS of {names} show those exact people — depict each with the SAME "
                             "face and overall appearance as in their OWN reference photo.")
            for c in trans:
                parts.append(_transform_who(c, scene))
        # The audience reminder is three sentences about what PEOPLE should look like. On a scientific
        # shot there are none, and describing them invites them in.
        extra = "" if _sci else _raw_audience_note(aud, scene.get("prompt"))
        if extra:
            parts.append(extra)
        return "\n".join(p for p in parts if p and p.strip())   # RAW stays VERBATIM (the user's exact words + only face/audience)
    parts = []
    split = bool(scene.get("split"))
    style = scene.get("style") or "natural"
    preset = style_preset(style, scene.get("bg"), vsl=vsl)
    if preset and not split:   # a SPLIT styles each half from the prompt (director writes each half's look, possibly DIFFERENT) → no single global style preset
        parts.append(preset.strip())
        if scene.get("product") and style == "natural":
            _has_person = bool(chars) or bool(chars_desc) or scene.get("generic") or _PERSON_CUES.search(scene.get("prompt") or "")
            if _has_person:
                # product WITHIN a lifestyle scene → keep it small & natural; the giant-bottle problem comes from
                # copying the reference's studio scale, so pin it to real-world/hand size and ignore the ref's framing.
                parts.append("The product appears in a real-life scene WITH a person: keep it CLEAN and label-accurate, but "
                             "at a NATURAL, SMALL real-world size — a normal ~10 cm supplement bottle that fits in one hand "
                             "(smaller than the person's forearm), held naturally or resting on a surface and occupying only "
                             "a SMALL part of the frame. Do NOT enlarge it or make it a giant/floating hero, and do NOT copy "
                             "the scale or framing of the product reference image (use that ONLY for its label/design/colours). "
                             "It sits in the same lighting as the scene. IMPORTANT: the product must still be in SHARP FOCUS "
                             "with its LABEL crisp and clearly readable — natural does NOT mean blurry; if the shot has a soft "
                             "background, the held bottle is on the SAME focal plane as the person (both sharp), never soft or "
                             "out of focus.")
            else:
                # dedicated product-hero shot (no people) → clean & premium, may be prominent
                parts.append("This is a dedicated PRODUCT hero shot (no people): render the product CLEAN, sharp, in crisp "
                             "focus and nicely lit so it looks appealing and premium — this overrides the casual/amateur feel "
                             "above for the product itself. Keep it believable and real (not a fake glossy render).")
    if split:
        parts.append(_split_clause(scene.get("prompt")))
        dl = _split_default_look(scene.get("style"))   # top style = DEFAULT look for the panels (so "photorealistic" = a real candid photo, not stock 3D)
        if dl:
            parts.append(dl)
    # SCENE content. Auto-translate Turkish → English (this is not the raw/hand path).
    parts.append(localize_prompt(scene.get("prompt") or "", aud, translate=True))
    # A split/diptych composition owns its own framing, and an anatomy render has no person for a camera
    # preset to frame - every preset is phrased around "a PERSON shown from the waist up".
    cam = (None if (split or (vsl and style == "scientific"))
           else CAMERA_ANGLES_BY_KEY.get(scene.get("camera")))
    if cam:
        parts.append(cam["prompt"])
    # WHO (identity). Reference images are attached as i2i inputs elsewhere; name them so each maps right.
    if chars:
        normal = [c for c in chars if not c.get("transforms")]
        trans = [c for c in chars if c.get("transforms")]
        if split and len(normal) >= 2:        # a split with 2+ named people → bind each to their OWN panel + face (no face-mixing)
            parts.append(_split_who(scene, normal))
        elif len(normal) >= 2:                # a single frame with 2+ named people → bind each face in order, no blending
            parts.append(_multi_who(normal))
        else:
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference PHOTOS of {names} show those exact people — depict each with the SAME "
                             "face and overall appearance as in their OWN reference photo. (Any other reference image "
                             "is a prop/product or a previous frame, NOT one of these people.)")
        # Gender anchor (additive): a reference photo can't lock gender when the face is turned away / seen from
        # behind (e.g. an over-the-shoulder shot), so state it in text for any cast whose gender is CLEAR from
        # their roster description. Only fires when confident — otherwise nothing is added (no behaviour change).
        gnotes = [f"{c['name']} is {_gender_word(c.get('desc'))}" for c in normal
                  if c.get("name") and _gender_word(c.get("desc"))]
        if gnotes:
            parts.append("Keep each person's gender correct even if their face is turned away or seen from behind: "
                         + "; ".join(gnotes) + ".")
        for c in trans:                       # a person mid-transformation: same face, body per this scene's stage
            parts.append(_transform_who(c, scene))
        if style in ANIM_STYLES + ("scientific",):   # the reference photos are photographic → tell the model to RE-DRAW the person in this medium, not paste a real face
            who_names = ", ".join(c["name"] for c in (normal + trans) if c.get("name"))
            medium = {"2d": "2D cartoon style (bold outlines, flat cel-shading)",
                      "3d": "stylised 3D animation style (soft CG render, appealing and NOT photoreal)"}.get(style, "3D CGI style")
            if who_names:
                parts.append(f"Use the reference photo(s) ONLY for {who_names}'s identity/likeness — RE-DRAW them fully "
                             f"in the {medium}; do NOT paste a photographic/real face into the image.")
    elif scene.get("refs"):
        refs = scene.get("refs") or []
        free = set(scene.get("ref_free") or [])
        if free & set(refs):
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face and identity faithful to the reference; their hairstyle may stay the same, "
                         "but they MUST wear DIFFERENT clothing/outfit that fits THIS scene — do NOT reuse "
                         "the same clothes as in the reference image.")
        else:
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face, hair, clothing/outfit and overall appearance faithful to the reference.")
    # recurring people WITHOUT a reference photo → inject their fixed roster description so they at least
    # stay look-consistent scene to scene (adding a reference photo later gives the exact same face).
    if chars_desc:
        who = "; ".join(f"{c['name']} ({c['desc']})" for c in chars_desc if c.get("name") and c.get("desc"))
        if who:
            parts.append("Keep these recurring people's appearance consistent every time: " + who + ".")
    # ORDINARY / one-off / background people: keep them a believable, DIVERSE mix so the video doesn't
    # show the same repeated face. This targets ONLY unnamed everyday people, never the referenced cast
    # above (whose look comes from their reference/description). Realistic style only. Also carries the
    # audience's "appearance to exclude" so unwanted looks are actually kept out at the image level (the
    # director alone can't enforce it — its scene text is barred from naming ethnicity/skin).
    # ORDINARY / one-off / background people: a DIVERSE mix (varied so the video doesn't repeat one face),
    # constrained to the audience AGE band, honouring the audience's excluded looks. Applies to people
    # styles (photoreal + 2D cartoon) — NOT scientific (inside-the-body anatomy has no ordinary people).
    # Targets only unnamed everyday people, never the named/recurring cast (whose look comes from their reference).
    if (scene.get("style") or "natural") != "scientific":
        excl = (aud or {}).get("appearance") if aud else None
        ages = [str(a).strip() for a in ((aud or {}).get("ages") or []) if str(a).strip()]
        age_phrase = " or ".join(ages) if ages else None
        # HARD rule (ALWAYS): never invent people.
        line = ("Include ONLY the people the scene describes. Do NOT add any extra, background, bystander or random "
                "person who is not explicitly called for — no filling the scene with incidental people.")
        # The age-band / diversity / excluded-looks guidance only matters when ORDINARY people actually appear —
        # skip it on a pure named-cast shot (there it's just noise, and a long exclusion list can bias the image).
        avatar = ((aud or {}).get("avatar") or "").strip()
        if _scene_has_ordinary(scene):
            age_bit = f" adults roughly in the {age_phrase} age range — not younger or older —" if age_phrase else ""
            sid = scene.get("id") or 0
            # Keyed to the scene number alone, the same look came back on every attempt - five re-rolls of
            # one scene all wore the same tee and the same odd haircut. Salting it with how many versions
            # the scene already has means a re-roll actually rolls.
            _att = len(((scene.get("image") or {}).get("versions") or [])) if vsl else 0
            _txt = scene.get("prompt") or ""
            _men = vsl and bool(_MAN_WORD.search(_txt)) and not _WOMAN_WORD.search(_txt)
            _faces = _face_variety_list(vsl, men=_men)
            fv = _faces[(sid + _att) % len(_faces)]   # per-scene look so identical subjects aren't the SAME face
            _crowd = vsl and (bool(_PEOPLE_PLURAL.search(_txt))
                              or len(_PERSON_SUBJ.findall(_txt)) >= 2
                              or _prompt_names_panels(_txt))
            _dressed = vsl and bool(_GARMENT.search(_txt))
            # The richer person (VSL): a hair colour the audience allows and, when nothing fixes the body, a
            # build - the two things whose absence made every scene the same person. Never ethnicity or skin.
            _hair = _hair_choices(ages, excl) if vsl else []
            _look = ""
            if vsl:
                if _hair:
                    _look += f", {_hair[(sid * 7 + 5 + _att) % len(_hair)]} hair"
                if not _AVATAR_BODY.search(avatar or "") and not _BUILD_WORDS.search(_txt):
                    _look += f", {_BUILD_VARIETY[(sid * 5 + 3 + _att) % len(_BUILD_VARIETY)]}"
            if avatar:
                # target-viewer VSL avatar: ordinary/relatable people embody the target's BUILD/CONDITION, following
                # whatever before/after state the scene text already describes (do NOT randomise body type here).
                line += (f" Any ordinary/relatable people (NOT the named/recurring character(s) above) are the TARGET "
                         f"VIEWER — depict them{age_bit} in the spirit of: {avatar}. The avatar sets their age and "
                         f"relatable vibe, but THIS scene's own words decide their BODY/BUILD and MOOD: if the scene "
                         f"describes them as slim / lean / energetic / transformed, depict them SLIM and happy and IGNORE "
                         f"any 'overweight' in the avatar; if the scene describes a 'before' / struggling moment, depict "
                         f"the heavier starting body. Make each ordinary person a DIFFERENT individual — vary their FACE "
                         f"shape, facial features, hairstyle and exact age; do NOT change their body/build (that is set by "
                         f"the scene's before/after above).")
            else:
                if age_phrase:
                    line += (f" Any ordinary/background people (NOT the named/recurring character(s) above) should be adults "
                             f"roughly in the {age_phrase} age range — not younger or older — and look like DIFFERENT "
                             f"individuals, varied in face, hairstyle and exact age (not all the same look).")
                else:
                    line += (" Any ordinary/background people (NOT the named/recurring character(s) above) should look like "
                             "DIFFERENT individuals — varied in face, hairstyle and age.")
            # deterministic per-scene look → consecutive scenes with the SAME subject description aren't the same woman.
            # Skipped once the scene describes several people: "the main ordinary person" then points at nobody, and
            # the look attaches to whichever figure the model picks - a different one on every attempt.
            if not _crowd:
                line += (f" For the main ordinary/relatable person in THIS specific scene, lean toward: {fv}{_look} — a clearly "
                         f"different individual from other scenes (keep within the allowed look; if the scene itself states a "
                         f"body or build, that wins). Keep the hairstyle plausible for who the scene says this person is.")
            elif vsl:
                # a crowd got only "different individuals" before, and came back as a row of the same person
                _shades = ", ".join(_hair[:4]) if _hair else "light and dark"
                line += (f" The people in this shot are visibly different from one another - a mix of builds and heights, "
                         f"hair colours ({_shades}) and clothing colours, each face its own; nobody appears twice.")
            # per-scene OUTFIT/COLOUR (fallback): different clothes & colour each scene. "Unless the scene fixes them" was
            # only ever a polite sentence inside the prompt, and the model ignored it - now the scene really does win.
            if not _dressed:
                ov = _OUTFIT_VARIETY[(sid * 5 + 2 + _att) % len(_OUTFIT_VARIETY)]
                line += (f" If the scene does not already specify their clothing, dress the main ordinary/relatable person in "
                         f"{ov} — vary the outfit and colour from other scenes; ordinary, everyday clothing.")
            # per-scene STAGING: where the CAMERA stands. Varying face, clothes and room was not enough -
            # five person shots came back as the same medium side-on view of somebody kneeling beside a
            # bath. This is the one that actually changes the picture, so it applies to continuations too.
            _stg = _staging_choices(scene.get("camera"), vsl)
            tv = _stg[(sid * 7 + 3 + _att) % len(_stg)]
            # The director is forbidden from naming a camera at all, so the old "unless the scene fixes the
            # camera" escape could only ever misfire - it deferred to staging the director had written as
            # ACTION, which is exactly the thing that kept repeating.
            line += (f" Stage this shot {tv}. Do NOT default to a medium side-on view of a person beside the "
                     f"object; that framing repeats across a video and reads as the same picture each time. "
                     f"Keep whatever the scene says is HAPPENING - only where the camera stands is yours.")
            # per-scene SETTING nudge (fallback only): defers to a place the scene already names, and is skipped for a
            # continuation shot (same place carries over) so we don't fight deliberate continuity.
            if not scene.get("cont_of"):
                sv = _SETTING_VARIETY[(scene.get("id") or 0) % len(_SETTING_VARIETY)]
                line += (f" If the scene text does NOT already fix a specific place, set this shot in {sv}, and in general "
                         f"VARY the location from the other scenes — do NOT default to the same kitchen/home every time. "
                         f"If the scene already names a place, keep that place.")
            # A HOME that the prompt names but does not describe gets ONE short look, rotated per scene and per
            # re-roll, so the video is never the same kitchen ten times - the reason the user once asked the
            # director for decor. A prompt that already carries its own detail is left alone.
            if vsl and not scene.get("cont_of") and _HOME_ROOM.search(_txt) and not _HOME_DETAIL.search(_txt):
                hl = _HOME_LOOKS[(sid * 3 + 1 + _att) % len(_HOME_LOOKS)]
                line += (f" The home in this shot is {hl} - a visibly different house from the other scenes.")
            # If the SCRIPT itself calls for a specific nationality/ethnicity (e.g. "des Japonais"), that look is
            # essential — depict it and OVERRIDE the audience default/excluded-looks for THIS scene only.
            ethnicity = _scene_ethnicity(scene)
            if ethnicity:
                line += (f" IMPORTANT: the script explicitly makes the people in THIS scene {ethnicity} — depict them "
                         f"as {ethnicity} people. This is REQUIRED and OVERRIDES the target-audience appearance and any "
                         f"excluded-looks for this scene (do NOT restyle them to match the audience).")
            elif excl:
                line += " Do NOT depict ordinary people who look " + ", ".join(excl) + "."
        parts.append(line)
    # CLEAN & PROFESSIONAL by default — the candid/amateur LOOK must not become a shabby SUBJECT. Unless the
    # scene text explicitly calls for it, everything is clean, tidy and in good condition.
    parts.append("Unless the scene explicitly calls for it, keep everything CLEAN, tidy and in good condition: no "
                 "stains, dirt, grime, spills, damage, scratches, rust, wear or mess. Settings look ordinary, everyday "
                 "and relatable — clean and neat but NOT ultra-modern, luxury or showroom-like. Clothing and uniforms "
                 "(e.g. a doctor's white coat) are clean and neat; desks, rooms and equipment look well-kept.")
    # Fill the whole frame — nano sometimes pads a portrait subject with blurred side bars (a fake letterbox).
    parts.append("Fill the ENTIRE 16:9 frame edge to edge — no blurred side bars, black bars, borders, letterboxing, "
                 "vignette frames or split-screen panels (unless a side-by-side split is explicitly described).")
    # Product house style: capsules are white opaque.
    parts.append("Any capsule or pill shown is a plain WHITE OPAQUE capsule unless the scene explicitly says otherwise.")
    # Don't let the model sneak the finished/branded PRODUCT into a shot that isn't a product shot — the pack must
    # not appear before it's introduced / unless this scene is flagged as a product shot. Raw ingredients are fine.
    if not scene.get("product"):
        parts.append("Do NOT show the finished BRANDED PRODUCT in this shot — no supplement bottle, pill jar, tube, "
                     "box, sachet or product packaging of any kind, and no person holding such a product. (Raw "
                     "ingredients like the black garlic itself, ordinary food and everyday objects are fine.)")
    if (scene.get("style") or "natural") == "natural":
        parts.append("This is a REAL photograph: do NOT add any magical glow, radiant aura, halo, light rays, "
                     "sparkles, or 'energy/vitality' glow effects to people or objects.")
    cc = _currency_clause(aud, scene.get("prompt"))   # emitted only if the shot itself shows money/prices (e.g. UK → £, not $)
    if cc:
        parts.append(cc)
    # "No text" normally keeps out stray captions/watermarks — but if the prompt asks for specific text/numbers
    # (a scale reading "9 st 6 lb", a sign, a screen), a blanket "No text" fights it. In that case, allow the
    # requested text and block only the rest.
    if _wants_text(scene.get("prompt")):
        txt = ("Render the specific text/numbers described above ACCURATELY and legibly. Do NOT add any OTHER "
               "text, captions, watermarks, logos or UI beyond what is explicitly described.")
        # any words shown in the image must be in the audience's language, not English (French project -> French text)
        lang = country_language(aud)
        if lang and lang != "English":
            txt += (f" Any words, signage, labels, screen or document text visible in the image MUST be written in "
                    f"correct {lang}, not English.")
        parts.append(txt)
    else:
        parts.append(_NO_ADDED_TEXT)
    return "\n".join(p for p in parts if p and p.strip())

@app.route("/api/scenes/<project>/genprompt", methods=["POST"])
def api_genprompt(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    scenes = doc.get("scenes", [])
    target_ids = None if ids == "all" else set(ids)
    # Re-generate uses the SAME whole-script director as Split (arc-aware, reads every scene together) —
    # not the old single-sentence pass — then applies ONLY the image prompt (+ style) to the target
    # scene(s). The user's camera / cast / transition / continuity are left exactly as they set them.
    scene_texts = [(s.get("vo") or "").strip() for s in scenes]
    # only the TARGETED scenes need director output — pass their indices so we don't burn a whole-script pass
    # (and ~30× the credits) to regenerate a handful. Full script still travels as context. "all" → whole pass.
    targets = None if target_ids is None else {i for i, s in enumerate(scenes) if s.get("id") in target_ids}
    # honour the user's SPLIT toggle when re-generating: force the director to write the target scene as two
    # halves (split on) or a single image (split off), so a manual Split choice actually shapes the prompt.
    tset = set(range(len(scenes))) if targets is None else targets
    split_overrides = {i: bool(scenes[i].get("split")) for i in tset if not scenes[i].get("no_cast")}
    dmeta = None
    _gp_touched = []
    try:
        plan, dmeta = direct_scenes(scene_texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides, ingredients=doc.get("ingredients"), product_name=(doc.get("product") or {}).get("name", ""))
    except Exception:
        plan = None                                            # director failed → per-scene fallback below
    for i, s in enumerate(scenes):
        if target_ids is not None and s["id"] not in target_ids:
            continue
        if s.get("no_cast"):          # RAW ("My prompt") scene → it's the user's own text; never overwrite it
            continue
        vo = (s.get("vo") or "").strip()
        if not vo:
            continue
        try:
            if plan and i < len(plan) and (plan[i].get("prompt") or "").strip():
                s["prompt"] = plan[i]["prompt"]               # ONLY the image content — KEEP the user's chosen style
                # (style is a separate layer the user controls; re-generating the prompt must not revert it)
                # bind the recurring characters the director detected — but ONLY when the scene has no cast yet
                # (never overwrite a cast the user picked). Fixes manually-added scenes whose face wasn't locked.
                if not s.get("no_cast") and not (s.get("cast") or []):
                    _locked = set(s.get("cast_locked") or [])   # don't re-bind a cast the user explicitly removed
                    if plan[i].get("cast"):
                        s["cast"] = [cid for cid in plan[i]["cast"] if cid not in _locked]
                    if plan[i].get("generic") and not s.get("generic"):
                        s["generic"] = plan[i]["generic"]
                if plan[i].get("states"):                      # transforming cast → their stage at this scene
                    s["states"] = plan[i]["states"]
                s["ingredients"] = plan[i].get("ingredients") or []   # ingredients shown in this shot (roster ids)
            else:
                # fallback: the old single-sentence pass, so the button still works if the director errors
                cast_names = [c["name"] for c in scene_characters(s, doc) if c.get("name")]
                prompt, style = claude_prompt(vo, "", doc.get("audience"), s.get("style"), cast_names, doc.get("brief", ""),
                                              vsl=not is_youtube(doc))
                s["prompt"] = prompt
                if style:
                    s["style"] = style
            bind_named_cast(s, doc)   # ADD (never remove) any roster character the new prompt names — e.g. a split's
                                      # LEFT half names Dr Carbonell while the existing cast only had Dr Vasquez
            s["prompt_error"] = None
            _gp_touched.append(s)
        except Exception as e:
            s["prompt_error"] = str(e)
    save_doc(project, doc)
    _stamp_director_prompt(_gp_touched)                 # baseline for the later edit-delta
    _learn_log("director", project, doc, _gp_touched)   # passive: capture re-generated (vo → prompt) pairs
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)   # which model ran (toast) — Fable 5 / Opus 4.8
    return jsonify(resp)



_CAM_WORDS = ("camera", "zoom", "pan ", "push-in", "push in", "dolly", "tilt", "tracking", "parallax",
              "crane", "handheld", "orbit", "pull back", "pull-back", "kamera", "yakınlaş", "uzaklaş")


def _mentions_camera(text):
    t = (text or "").lower()
    return any(w in t for w in _CAM_WORDS)


def _apply_cam_lock(prompt, scene):
    """If this scene's camera is locked (default) AND the motion text doesn't already talk about the
    camera, spell out a completely static camera so the video model doesn't drift/zoom on its own."""
    if scene.get("video_cam_lock", False) and not _mentions_camera(prompt):
        prompt = (prompt or "").rstrip()
        prompt += (" " if prompt else "") + "The camera stays completely still (locked-off tripod): no camera movement, no zoom, no pan, no push-in."
    return prompt


# The ambient clause names leaves and steam as examples, and the model then puts them in a bathroom, an
# office, a close-up of a jar. Ambient motion may only animate what is ALREADY visible in the still.
_AMBIENT_FREE = ("ambient motion (steam/liquid/light/particles drifting, leaves) — all at\nreal-time speed.")
_AMBIENT_VSL = (
    "all at real-time speed.\n\n"
    "AMBIENT MOTION ONLY ANIMATES WHAT IS ALREADY IN THE PICTURE. If steam, liquid, smoke, dust, foliage "
    "or moving light is visibly THERE in the still, it may move. If it is not there, do not invent it: "
    "never add drifting leaves, rising steam, floating dust or blowing curtains to a frame that has none "
    "- a bathroom shelf, an office desk or a close-up of a jar has no weather in it. When the frame holds "
    "nothing ambient, animate only the subject, and let the shot be almost still if that is all it needs.")


def _video_sys(scene, vsl):
    """The motion-prompt system for this scene: one template, the camera paragraph filled in - locked off
    when the scene says so, one small move otherwise. On VSL the ambient wording is replaced so nothing is
    invented into the frame."""
    locked = bool(scene.get("video_cam_lock", False))
    base = (VIDEO_PROMPT_BASE
            .replace("__CAMERA__", VIDEO_CAMERA_LOCKED if locked else VIDEO_CAMERA_FREE)
            .replace("__NO_CAMERA_LINE__", "\n- move the camera in any way" if locked else "")
            .replace("__NO_CAMERA_TAIL__", ", and never move the camera" if locked else ""))
    if vsl and _AMBIENT_FREE in base:
        base = base.replace(_AMBIENT_FREE, _AMBIENT_VSL, 1)
    return base


def video_prompt_for(scene, project=None, vsl=False):
    """Generate a subtle, image-consistent motion prompt. When the scene's generated IMAGE exists we LOOK at it
    (vision) so the motion suits WHAT IS ACTUALLY in the frame and won't distort it (faces/hands/text/product);
    otherwise fall back to the image-prompt/VO text. Camera-locked (static) by default."""
    sys = _video_sys(scene, vsl)
    vo = (scene.get("vo") or "").strip()
    im = scene.get("image") or {}
    f = im.get("approved_file") or im.get("file")
    if project and f:
        d, _ = proj_dir(project)
        img_path = str(d / f)
        if os.path.exists(img_path):
            user = ("This still is the FIRST FRAME of the video clip. Look at WHAT IS ACTUALLY IN THE IMAGE and write "
                    "the motion prompt for THIS exact image: only animate what can move naturally, and avoid ANY motion "
                    "that would warp or distort faces, hands, bodies, text, logos or the product. "
                    + (f"Script line (voice-over spoken over this shot): {vo}" if vo else ""))
            return _apply_cam_lock(_claude_vision(sys, user, img_path), scene)   # ClaudeNotLoggedIn propagates
    desc = (scene.get("prompt") or "").strip()
    user = f"Still image: {desc or vo}"
    if vo and desc:
        user += f"\nScript line (voice-over spoken over this shot): {vo}"
    return _apply_cam_lock(_claude_text(sys, user), scene)

@app.route("/api/scenes/<project>/gen-video-prompt", methods=["POST"])
def api_gen_video_prompt(project):
    """Write an AI motion prompt into each eligible scene's video_desc (the Videos-tab textbox). SYNC — used for
    a single scene / a small selection. The 'all' button uses the background job below (vision over many scenes)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = request.get_json(force=True).get("ids", "all")
    def eligible(s):
        return s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))
    targets = [s for s in doc["scenes"] if eligible(s) and (ids == "all" or s["id"] in ids)]
    for s in targets:
        try:
            s["video_desc"] = video_prompt_for(s, project, vsl=not is_youtube(doc))
            s["video_prompt_error"] = None
        except Exception as e:
            s["video_prompt_error"] = str(e)
    save_doc(project, doc)
    return jsonify(doc)

# ---- video-prompt "generate ALL" as a background JOB (vision over every approved scene → too slow for one
# request). Watches each scene's first frame and writes an image-consistent motion prompt, with progress + report.
VIDPROMPT_JOBS = {}
_VP_LOCK = threading.Lock()

def _vidprompt_worker(jid, project, ids=None):
    j = VIDPROMPT_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _VP_LOCK: j.update(status="error", error="project not found")
            return
        def eligible(s):
            im = s.get("image") or {}
            return s.get("approved") and (im.get("approved_file") or im.get("file"))
        targets = [s for s in doc["scenes"] if eligible(s)]
        if ids:                                          # a selection -> only those scene ids (still must be eligible)
            idset = set(ids)
            targets = [s for s in targets if s.get("id") in idset]
        if not targets:
            with _VP_LOCK: j.update(status="error", error="No approved scenes with an image yet — approve the images first.")
            return
        def _one(s):
            if j.get("cancel"):
                return None
            return video_prompt_for(s, project, vsl=not is_youtube(doc))      # vision call; may raise → caught by _parallel_map
        def _prog(dn, tot):
            with _VP_LOCK: j.update(step=f"Watching image & writing motion prompt {dn}/{tot}…", pct=int(dn / tot * 100))
        res = _parallel_map(targets, _one, cancel=lambda: j.get("cancel"), on_progress=_prog)   # PARALLEL (bounded)
        if j.get("cancel"):
            with _VP_LOCK: j.update(status="cancelled")
            return
        for r in res:                                # not logged in anywhere → abort, tell the user
            if isinstance(r, tuple) and len(r) == 2 and r[0] == "__err__" and isinstance(r[1], ClaudeNotLoggedIn):
                with _VP_LOCK: j.update(status="error", error=str(r[1]))
                return
        written = 0                                  # apply results as a MERGE (only our fields) so a concurrent job survives
        updates = {}
        for s, r in zip(targets, res):
            if isinstance(r, tuple):                 # ('__err__', exc) [non-login] or ('__cancelled__',)
                if r and r[0] == "__err__":
                    updates[s["id"]] = {"video_prompt_error": str(r[1])[:120]}
            elif r is not None:
                updates[s["id"]] = {"video_desc": r, "video_prompt_error": None}; written += 1
        merge_save_fields(project, updates)
        with _VP_LOCK: j.update(status="done", pct=100, report={"written": written, "total": len(targets)})
    except Exception as e:
        with _VP_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/gen-video-prompt-all", methods=["POST"])
@_locked
def api_gen_video_prompt_all(project):
    """Start the background vision video-prompt pass. No body -> every approved scene; {"ids":[...]} -> just those."""
    if load_doc(project) is None:
        abort(404)
    body = request.get_json(silent=True) or {}
    ids = body.get("ids") or None
    jid = new_uid()
    VIDPROMPT_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_vidprompt_worker, args=(jid, project, ids), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/video-prompt-job/<jid>")
def api_video_prompt_job(jid):
    j = VIDPROMPT_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/video-prompt-cancel/<jid>", methods=["POST"])
def api_video_prompt_cancel(jid):
    j = VIDPROMPT_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

# ================= IMAGE QA — LOOK at every generated image and check it against the script =================
# A vision pass (subscription) that opens each scene's image and judges whether it matches the line, the
# audience, and has no defects/artifacts/wrong-ethnicity/stray-product. Background job -> report + flagged ids.
def _parse_json_obj(text):
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        raise ValueError("no JSON object")
    return json.loads(t[a:b + 1])



IMGQA_JOBS = {}
_IMGQA_LOCK = threading.Lock()

def _qa_scene_ctx(s, doc, ing_names):
    """What this particular shot was supposed to be. Without it the reviewer cannot tell a wrong
    ingredient from a right one, or a legitimate product shot from a pack that wandered in."""
    if is_youtube(doc):
        return ""
    bits = []
    ings = [ing_names.get(i) for i in (s.get("ingredients") or []) if ing_names.get(i)]
    if ings:
        bits.append("The ingredients this shot must show, and no others: " + ", ".join(ings) + ".")
    # Whether a divided frame is CORRECT here is not something the picture can tell you - it is a
    # decision recorded on the scene. Say which it is, or every honest diptych gets reported as a fault
    # and every accidental one gets waved through.
    if s.get("split") or _prompt_names_panels(s.get("prompt")):
        bits.append("This scene IS a panel composition: a divided frame is correct here. Check instead "
                    "that each panel shows what its own half of the description says.")
    else:
        bits.append("This scene is ONE continuous frame. A diptych, triptych, collage, inset or two "
                    "scenes meeting at a seam is a fault here.")
    if s.get("packs"):
        bits.append("This is an OFFER SHOWCASE of the product only - no people, no hands, no room.")
    elif (s.get("card") or "").strip():
        bits.append("This is a full-screen graphic CARD. The words on it must read exactly: %r - check the "
                    "spelling letter by letter, including accents, and flag any word that is misspelt, "
                    "repeated or missing." % (s.get("card") or "").strip())
    elif s.get("product"):
        bits.append("The product is meant to appear in this shot.")
    else:
        bits.append("The product is NOT meant to appear in this shot.")
    return ("\n" + " ".join(bits)) if bits else ""


_SHOWCASE_INTRUDER = re.compile(
    r"\b(man|woman|men|women|person|people|couple|hand|hands|finger|kitchen|room|table|sofa|"
    r"counter|bathroom|bedroom|shelf|street|garden|office|technician|doctor|nurse|pharmacist)\b", re.I)


def _qa_reconcile_flags(doc, issues, by_id):
    """Two faults live in the scene's own settings, not in its picture, so no amount of looking finds
    them - and both silently overrule the prompt.

    `split` prepends an order to compose panels. When the QA rewrites a diptych prompt into a single
    shot but the flag stays up, the app keeps commanding the very thing the new prompt describes away,
    and the scene comes back divided however it is worded. Point the flag at what the prompt now says.

    `packs` REPLACES the shot with a composited pack picture, so a scene that carries it and describes a
    person in a room never gets drawn at all - and two scenes carrying the same pack become one identical
    frame. A described person is proof it was never meant to be a bare showcase.
    """
    have = {x["id"] for x in issues}
    n = 0
    for s in (doc.get("scenes") or []):
        if (s.get("card") or "").strip():
            continue
        sid = s.get("id")
        names = _prompt_names_panels(s.get("prompt"))
        if bool(s.get("split")) != names:
            s["split"] = names
            s["split_suggested"] = names
            n += 1
            if sid not in have:
                issues.append({
                    "id": sid, "severity": "high", "regenerate": True, "fixed_prompt": "",
                    "issue": ("The scene was set to a %s but its description is %s, so the composition "
                              "order and the description contradicted each other. Corrected - regenerate "
                              "this scene." % (("panel composition", "one continuous shot") if not names
                                               else ("single frame", "laid out as panels")))})
                have.add(sid)
        if s.get("packs") and _SHOWCASE_INTRUDER.search(s.get("prompt") or ""):
            s["packs"] = []
            n += 1
            if sid not in have:
                issues.append({
                    "id": sid, "severity": "high", "regenerate": True, "fixed_prompt": "",
                    "issue": ("A pack showcase was attached to a scene that describes a real shot, so the "
                              "composited pack picture replaced it and the shot was never drawn. The pack "
                              "is detached - regenerate this scene.")})
                have.add(sid)
    # A SIX-PACK photo handed to a shot that wants ONE jar does not just mislead the model, it invents:
    # asked for a single jar on a coffee table while looking at a group of six, it drew a crowd of jars
    # with made-up labels and put a stranger in the frame. Unless the shot itself asks for that many, a
    # scene that is not a showcase gets the single-container packshot.
    prod = (doc.get("product") or {})
    names = prod.get("names") or {}
    single = _default_product_url(doc)
    for s in (doc.get("scenes") or []):
        if s.get("packs") or not s.get("product") or not single or s.get("product") == single:
            continue
        cnt = _pack_count_of(names.get(_scene_product_url(s, doc)))
        if not cnt or cnt < 2:
            continue
        low = " " + " ".join((s.get("prompt") or "").lower().split()) + " "
        wants = {2: ("two", "2"), 3: ("three", "3"), 4: ("four", "4"), 5: ("five", "5"),
                 6: ("six", "6"), 12: ("twelve", "12")}.get(cnt, ())
        if any((" %s " % w) in low for w in wants):
            continue                                   # the shot really does call for that many
        s["product"] = single
        n += 1
        if s.get("id") not in have:
            issues.append({"id": s.get("id"), "severity": "med", "regenerate": True, "fixed_prompt": "",
                           "issue": ("A %d-pack photo was attached as the reference for a shot that does "
                                     "not call for %d containers, so the model was copying the wrong "
                                     "picture. Swapped to the single pack - regenerate this scene."
                                     % (cnt, cnt))})
            have.add(s.get("id"))

    # Two scenes showcasing the SAME pack come back as the same picture, every time.
    seen = {}
    for s in (doc.get("scenes") or []):
        key = tuple(sorted(s.get("packs") or []))
        if not key:
            continue
        first = seen.setdefault(key, s.get("id"))
        if first != s.get("id") and s.get("id") not in have:
            issues.append({"id": s.get("id"), "severity": "high", "regenerate": False, "fixed_prompt": "",
                           "issue": "Showcases the same pack as scene %s, so both scenes get an identical "
                                    "picture. Give one of them a different shot." % first})
            have.add(s.get("id"))
    return n


def _qa_duplicate_frames(doc, d):
    """Scenes whose pictures came out the SAME. No single image can show this, and it is the fault a
    viewer notices fastest - four scenes of one video shared one identical frame."""
    try:
        import cv2, numpy as np
    except Exception:
        return {}
    sigs = {}
    for s in (doc.get("scenes") or []):
        im = s.get("image") or {}
        rel = im.get("approved_file") or im.get("file")
        if not rel:
            continue
        p = d / rel
        if not p.exists():
            continue
        g = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
        if g is None:
            continue
        sigs[s.get("id")] = cv2.resize(g, (16, 9)).astype("float32").ravel()
    out, ids = {}, sorted(sigs)
    for a_i, a in enumerate(ids):
        for b in ids[a_i + 1:]:
            import numpy as np
            if float(np.abs(sigs[a] - sigs[b]).mean()) < 3.0:
                out.setdefault(b, []).append(a)
    return out


def _qa_context(doc, d):
    """What the image reviewer is told about the PROJECT - built once, shared by Check Images and the
    automatic check that runs when a picture lands."""
    aud = doc.get("audience") or {}
    plang = country_language(aud) or "the project language"   # project language for any on-image text (wrong-language = defect)
    return {
        "excl": ", ".join(aud.get("appearance") or []) or "none",
        "locs": ", ".join(aud.get("locations") or []) or "the project's country",
        "ages": ", ".join(str(a) for a in (aud.get("ages") or []) if str(a).strip()),   # real audience ages (no hardcoded range)
        "plang": plang,
        "no_eng": "" if (plang or "").strip().lower().startswith("english") else ", not English",
        # the project's own look, so a correct cartoon is not reported as a fault
        "look": {'2d': '2D CARTOON ANIMATION', '3d': '3D ANIMATION',
                 'scientific': 'SCIENTIFIC / MEDICAL ILLUSTRATION'}.get(_doc_scene_style(doc), ''),
        # A YouTube episode has no product and no offer, so none of the sales-video checks apply to it.
        "vsl": "" if is_youtube(doc) else (IMAGE_QA_VSL + "\n" + (product_form_line(doc, d) or "")
                                           + "\n" + (_real_pack_sizes(doc) or "")),
        "ing": {i.get("id"): (i.get("name") or "") for i in (doc.get("ingredients") or [])},
    }


def _qa_judge(ctx, s, doc, img_path):
    """ONE picture against its scene: the issue dict Check Images reports, or None when the reviewer says ok.
    Raises on a vision/parse failure (the callers decide what a failure means)."""
    user = (f"VO of this shot ({ctx['plang']}): {s.get('vo') or ''}\n"
            f"Intended shot description: {s.get('prompt') or ''}\n"
            f"Target audience: ordinary/relatable people from {ctx['locs']}"
            + (f", roughly aged {ctx['ages']}" if ctx['ages'] else "")
            + f"; do NOT show these looks for ordinary viewers: {ctx['excl']}.\n"
            f"Project language: {ctx['plang']}. Any words/signage/labels/screen text visible in the image must be written in {ctx['plang']}{ctx['no_eng']}.\n"
            + (f"THE LOOK OF THIS PROJECT IS {ctx['look']}. That is correct and deliberate - do NOT "
               "report it as a fault, and ignore any word in the shot description that names a "
               "different medium.\n" if ctx['look'] else "")
            + "Look at the image and judge it. Return the JSON verdict.")
    v = _parse_json_obj(_claude_vision(IMAGE_QA_SYSTEM + ctx["vsl"], user + _qa_scene_ctx(s, doc, ctx["ing"]), img_path))
    if str(v.get("verdict")).lower() == "issue" and (v.get("issue") or "").strip():
        return {"id": s.get("id"), "issue": v.get("issue").strip(),
                "severity": (v.get("severity") or "med").lower(),
                "regenerate": bool(v.get("regenerate")),
                "fixed_prompt": (v.get("fixed_prompt") or "").strip()}
    return None


def _imgqa_worker(jid, project):
    j = IMGQA_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _IMGQA_LOCK: j.update(status="error", error="project not found")
            return
        d, _ = proj_dir(project)
        ctx = _qa_context(doc, d)
        def imgfile(s):
            im = s.get("image") or {}
            return im.get("approved_file") or im.get("file")
        targets = [s for s in doc["scenes"] if imgfile(s)]
        if not targets:
            with _IMGQA_LOCK: j.update(status="error", error="No generated images to check yet.")
            return
        def _check_one(s):
            if j.get("cancel"):
                return None
            img_path = str(d / imgfile(s))
            if not os.path.exists(img_path):
                return None
            return _qa_judge(ctx, s, doc, img_path)   # may raise → caught by _parallel_map
        def _prog(dn, tot):
            with _IMGQA_LOCK: j.update(step=f"Checking image {dn}/{tot}…", pct=int(dn / tot * 100))
        res = _parallel_map(targets, _check_one, cancel=lambda: j.get("cancel"), on_progress=_prog)   # PARALLEL (bounded)
        if j.get("cancel"):
            with _IMGQA_LOCK: j.update(status="cancelled")
            return
        for r in res:                                # a "not logged in" anywhere → surface it + stop the whole job
            if isinstance(r, tuple) and len(r) == 2 and r[0] == "__err__" and isinstance(r[1], ClaudeNotLoggedIn):
                with _IMGQA_LOCK: j.update(status="error", error=str(r[1]))
                return
        issues = [r for r in res if isinstance(r, dict)]   # input order; per-image parse/vision hiccups were skipped
        if not is_youtube(doc):
            # ...plus the one fault a per-image reviewer structurally cannot see
            dupes = _qa_duplicate_frames(doc, d)
            have = {x["id"] for x in issues}
            for sid, others in dupes.items():
                if sid in have:
                    continue
                issues.append({"id": sid, "severity": "high", "regenerate": True, "fixed_prompt": "",
                               "issue": "Same picture as scene %s - this scene needs its own image."
                                        % ", ".join(str(o) for o in others)})
        regen_ids = [x["id"] for x in issues if x["regenerate"]]
        flagged_ids = [x["id"] for x in issues]
        # Apply the QA's fixes IN PLACE so every flagged scene is ALREADY improved — whether the user then clicks
        # Apply/Regenerate or just Close: (1) write the flag reason into the scene NOTE, (2) replace the image
        # PROMPT with the QA's corrected fixed_prompt. Then a regenerate (all, or one-by-one later) uses good prompts.
        by_id = {s.get("id"): s for s in doc.get("scenes", [])}
        fixed_n = 0
        for it in issues:
            sc = by_id.get(it["id"])
            if not sc:
                continue
            prev = (sc.get("note") or "").strip()
            prev = "\n".join(ln for ln in prev.splitlines() if not ln.startswith("⚠ QA:"))   # drop a stale QA line
            sc["note"] = ("⚠ QA: " + it["issue"] + ("\n" + prev if prev else "")).strip()
            fp = (it.get("fixed_prompt") or "").strip()
            if fp and fp != (sc.get("prompt") or "").strip():
                sc["prompt"] = fp; fixed_n += 1
        if not is_youtube(doc):
            fixed_n += _qa_reconcile_flags(doc, issues, by_id)
        try:
            save_doc(project, doc)
        except Exception as _qe:
            quiet(_qe, "_imgqa_worker")
        suggestions = []
        if len(issues) >= 3:      # only propose a system change when a class of problem RECURS
            try:
                summary = "\n".join(f"#{x['id']} ({x['severity']}): {x['issue']}" for x in issues[:80])
                arr = _parse_json_array(_claude_text(QA_SUGGEST_SYSTEM, summary, max_tokens=800))
                suggestions = [str(a).strip() for a in arr if str(a).strip()][:4]
            except Exception:
                suggestions = []
        report = {"reviewed": len(targets), "flagged": len(issues), "issues": issues[:200],
                  "regen_ids": regen_ids, "flagged_ids": flagged_ids, "system_suggestions": suggestions,
                  "prompts_fixed": fixed_n}   # flagged scenes whose image prompt was auto-corrected in place
        with _IMGQA_LOCK: j.update(status="done", pct=100, report=report)
    except Exception as e:
        with _IMGQA_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/image-qa", methods=["POST"])
@_locked
def api_image_qa(project):
    """Start the background vision QA over every generated image."""
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    IMGQA_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_imgqa_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/image-qa-job/<jid>")
def api_image_qa_job(jid):
    j = IMGQA_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/image-qa-cancel/<jid>", methods=["POST"])
def api_image_qa_cancel(jid):
    j = IMGQA_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

VIDQA_JOBS = {}
_VIDQA_LOCK = threading.Lock()

def _extract_frame(video_path, out_path):
    """Grab THREE frames (~20%, ~50%, ~80%) and stitch them left-to-right into one montage image, so the
    vision QA can judge how the motion evolves (a mid-clip warp a single midpoint frame would miss). Falls
    back to a single midpoint frame if anything goes wrong. Returns True on success."""
    try:
        dur = premiere_export.audio_duration(video_path) or 0.0
        if dur and dur > 0.6:
            outp = str(out_path)
            frames = []
            base = os.path.splitext(outp)[0]
            for k, frac in enumerate((0.2, 0.5, 0.8)):
                fp = f"{base}_p{k}.jpg"
                subprocess.run(["ffmpeg", "-y", "-ss", str(max(0.05, dur * frac)), "-i", str(video_path),
                                "-frames:v", "1", "-q:v", "3", fp], check=True, capture_output=True,
                               timeout=60, creationflags=_NO_WINDOW)
                if os.path.exists(fp): frames.append(fp)
            if len(frames) == 3:
                subprocess.run(["ffmpeg", "-y", "-i", frames[0], "-i", frames[1], "-i", frames[2],
                                "-filter_complex", "[0][1][2]hstack=inputs=3", "-q:v", "3", outp],
                               check=True, capture_output=True, timeout=60, creationflags=_NO_WINDOW)
                for fp in frames:
                    try: os.remove(fp)
                    except OSError as _qe: quiet(_qe, "_extract_frame")
                if os.path.exists(outp): return True
        ts = max(0.1, dur / 2.0) if dur else 0.5           # fallback: single midpoint frame
        subprocess.run(["ffmpeg", "-y", "-ss", str(ts), "-i", str(video_path), "-frames:v", "1",
                        "-q:v", "3", str(out_path)], check=True, capture_output=True, timeout=60,
                       creationflags=_NO_WINDOW)
        return os.path.exists(out_path)
    except Exception:
        return False

def _vidqa_worker(jid, project):
    j = VIDQA_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _VIDQA_LOCK: j.update(status="error", error="project not found")
            return
        d, _ = proj_dir(project)
        vidfile = lambda s: (s.get("video") or {}).get("file")
        targets = [s for s in doc["scenes"] if vidfile(s) and (d / vidfile(s)).exists()]
        if not targets:
            with _VIDQA_LOCK: j.update(status="error", error="No generated videos to check yet.")
            return
        tmp = d / "export" / "_vidqa_tmp"; tmp.mkdir(parents=True, exist_ok=True)
        def _check_one(s):
            if j.get("cancel"):
                return None
            fp = tmp / f"f_{s.get('id')}.jpg"          # unique per scene → parallel frame-grabs never clash
            if not _extract_frame(d / vidfile(s), fp):
                return None
            user = (f"VO of this shot: {s.get('vo') or ''}\n"
                    f"Intended video: {s.get('video_desc') or s.get('prompt') or ''}\n"
                    "The image is 3 frames of the clip stitched left-to-right (early / middle / late). Judge them "
                    "together and return the JSON verdict.")
            v = _parse_json_obj(_claude_vision(VIDEO_QA_SYSTEM, user, str(fp)))   # may raise → caught by _parallel_map
            if str(v.get("verdict")).lower() == "issue" and (v.get("issue") or "").strip():
                return {"id": s.get("id"), "issue": v.get("issue").strip(),
                        "severity": (v.get("severity") or "med").lower()}
            return None
        def _prog(dn, tot):
            with _VIDQA_LOCK: j.update(step=f"Checking video {dn}/{tot}…", pct=int(dn / tot * 100))
        res = _parallel_map(targets, _check_one, cancel=lambda: j.get("cancel"), on_progress=_prog)   # PARALLEL (bounded)
        if j.get("cancel"):
            with _VIDQA_LOCK: j.update(status="cancelled")
            shutil.rmtree(tmp, ignore_errors=True); return
        for r in res:
            if isinstance(r, tuple) and len(r) == 2 and r[0] == "__err__" and isinstance(r[1], ClaudeNotLoggedIn):
                with _VIDQA_LOCK: j.update(status="error", error=str(r[1]))
                shutil.rmtree(tmp, ignore_errors=True); return
        issues = [r for r in res if isinstance(r, dict)]
        shutil.rmtree(tmp, ignore_errors=True)
        report = {"reviewed": len(targets), "flagged": len(issues), "issues": issues[:200],
                  "flagged_ids": [x["id"] for x in issues]}
        with _VIDQA_LOCK: j.update(status="done", pct=100, report=report)
    except Exception as e:
        with _VIDQA_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/video-qa", methods=["POST"])
@_locked
def api_video_qa(project):
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    VIDQA_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_vidqa_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/video-qa-job/<jid>")
def api_video_qa_job(jid):
    j = VIDQA_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/video-qa-cancel/<jid>", methods=["POST"])
def api_video_qa_cancel(jid):
    j = VIDQA_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/preflight/<project>")
def api_preflight(project):
    """Read-only pre-export readiness check: flags anything missing before you render (no SRT/VO, scenes with no
    media or not approved, music sections without a track). Returns items for the report modal."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _ = proj_dir(project)
    items = []
    scenes = doc.get("scenes") or []
    # subtitle + voice-over
    srt = _find_srt(d)
    if not srt:
        items.append({"text": "No subtitle (.srt) found — generate captions before exporting.", "kind": "error"})
    vo = None
    try:
        vo = _normalized_vo(d)
    except Exception:
        vo = None
    if not vo:
        items.append({"text": "No voice-over audio found — the export needs the VO.", "kind": "error"})
    # per-scene media + approval
    no_media, not_approved = [], []
    for s in scenes:
        if s.get("tcard_id"):
            continue                                   # testimonial-card scenes carry their own media
        im = s.get("image") or {}
        has_img = bool(im.get("approved_file") or im.get("file"))
        has_vid = bool((s.get("video") or {}).get("file"))
        if not (has_img or has_vid):
            no_media.append(s.get("id"))
        elif not s.get("approved"):
            not_approved.append(s.get("id"))
    if no_media:
        items.append({"text": f"{len(no_media)} scene(s) have NO image or video: #" + ", #".join(str(i) for i in no_media[:40]), "kind": "error"})
    if not_approved:
        items.append({"text": f"{len(not_approved)} scene(s) have media but are NOT approved: #" + ", #".join(str(i) for i in not_approved[:40]), "kind": "warn"})
    # music plan (if one is saved)
    plan = doc.get("music_plan") or []
    if plan:
        missing = [seg for seg in plan if not seg.get("track")]
        if missing:
            items.append({"text": f"{len(missing)} music section(s) have no track assigned — check the music panel.", "kind": "warn"})
    else:
        items.append({"text": "Music not planned yet — it will be planned on the next Build Preview.", "kind": "info"})
    errors = sum(1 for it in items if it["kind"] == "error")
    warns = sum(1 for it in items if it["kind"] == "warn")
    return jsonify({"items": items, "errors": errors, "warns": warns, "scenes": len(scenes)})


# OUT animation per IN animation (user rule): pop-up -> pop-up, slide-left -> slide-left, slide-top/bottom -> fade.
# On-screen text is NEVER a plain fade-in and NEVER slide-right.
_OST_OUT_FOR = {"popup": "pop", "slide-left": "slide-left", "slide-top": "fade",
                "slide-bottom": "fade", "fade": "fade", "none": "fade"}
_OST_ALLOWED_IN = ("popup", "slide-left", "slide-top", "slide-bottom")   # allowed on-screen-text entrances


def _ost_in_anim(a):
    """Coerce any stored IN animation to an allowed one (never plain fade-in, never slide-right)."""
    a = (a or "").strip()
    return a if a in _OST_ALLOWED_IN else "slide-bottom"
OST_JOBS = {}
_OST_LOCK = threading.Lock()

def _ost_est_dur(vo):
    return len((vo or "").split()) / 2.67          # ~French speaking rate, seconds

# Where a STACK of 2-4 texts stands (pixels from the frame centre, 1920x1080): the editor's own layouts -
# two side by side, three in a row, four as a 2x2.
_OST_STACK_POS = {2: [(-480, 0), (480, 0)],
                  3: [(-620, 0), (0, 0), (620, 0)],
                  4: [(-495, -270), (500, -270), (-495, 270), (500, 270)]}
_OST_STACK_SIZE = 64                                   # a stacked item is set smaller than a lone text


def _ost_request(doc, params, fresh=False):
    """The on-screen-text pass's inputs: the system prompt for THIS kind of video, the request, the eligible
    scenes and the limits. One path, so a dry run over a finished project asks exactly what the button asks.
    `fresh` treats the project as untouched (texts the user typed are not skipped)."""
    maxchars = int(params.get("max_chars") or 20)
    maxlines = int(params.get("max_lines") or 2)
    # only the allowed entrances (never plain fade-in, never slide-right); drop anything else the UI passed
    anims = [a for a in (params.get("anims") or []) if a in _OST_ALLOWED_IN] or list(_OST_ALLOWED_IN)
    min_dur = float(params.get("min_dur") or 3.0)
    scenes = doc["scenes"]
    # testimonial scenes are an auto-composed selfie grid — never put on-screen text on them
    eligible = [s for s in scenes if (s.get("vo") or "").strip() and _ost_est_dur(s.get("vo")) >= min_dur and not s.get("testimonial")]
    _vsl = not is_youtube(doc)
    if _vsl:
        # A card IS the on-screen text of its line, and a badge already shouts there: the reviewer removed every
        # text the pass put on such lines. And a text the user typed by hand (unlocked) is theirs to keep.
        def _has_badge(sc): return any(str((i or {}).get("type") or "").startswith("bdg") for i in (sc.get("icons") or []))
        def _hand_made(sc): return bool(sc.get("ost_on")) and any((o.get("onscreen") or "").strip() and not o.get("ost_locked") for o in (sc.get("overlays") or []))
        eligible = [s for s in eligible if not (s.get("card") or "").strip() and not _has_badge(s) and (fresh or not _hand_made(s))]
    lines = "\n".join(f'{s["id"]}\t{(s.get("vo") or "").strip()}' for s in eligible)
    user = (f"Allowed animations: {', '.join(anims)}. Max {maxlines} lines; each line at most {maxchars} "
            f"characters.\nScenes (id<TAB>voice-over), in order:\n{lines}")
    # The quota is a slot: YouTube keeps its sentence word for word; a sales video gets the editor's rules.
    sysm = OST_SYSTEM.replace("__QUOTA__", OST_QUOTA_VSL if _vsl else OST_QUOTA_YOUTUBE) + (OST_VSL if _vsl else "")
    return sysm, user, eligible, anims, maxchars, maxlines


def _ost_overlay(text, anim, preset):
    ov = new_overlay(); ov["onscreen"] = text
    if preset:
        for k in _OST_STYLE_COPY:
            if k in preset: ov[k] = preset[k]
    ov["ost_anim"] = anim; ov["ost_out_anim"] = _OST_OUT_FOR.get(anim, "fade")
    ov["ost_locked"] = True                           # generated texts arrive LOCKED on the preview (unlock to move)
    return ov


def _ost_worker(jid, project, params):
    j = OST_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _OST_LOCK: j.update(status="error", error="project not found")
            return
        presets = []
        if OST_PRESETS_PATH.exists():
            try: presets = json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8"))
            except Exception: presets = []
        by_name = {p.get("name"): p for p in presets if isinstance(p, dict) and p.get("name")}
        pos = by_name.get(params.get("positive_preset"))
        neg = by_name.get(params.get("negative_preset"))
        scenes = doc["scenes"]
        _vsl = not is_youtube(doc)
        sysm, user, eligible, anims, maxchars, maxlines = _ost_request(doc, params)
        if not eligible:
            with _OST_LOCK: j.update(status="error", error="No scenes long enough for on-screen text.")
            return
        with _OST_LOCK: j.update(step="Claude is choosing punchy keywords…", pct=25)
        arr = _parse_json_array(_claude_text(sysm, user, max_tokens=8000))
        with _OST_LOCK: j.update(step="Applying on-screen text…", pct=85)
        byid = {s["id"]: s for s in scenes}
        added, changes = 0, []
        def _fits(t):
            ls = t.split("\n")
            return bool(t) and len(ls) <= maxlines and all(len(x) <= maxchars + 2 for x in ls)
        for v in (arr or []):
            try: sid = int(v.get("id"))
            except Exception: continue
            s = byid.get(sid)
            if not s: continue
            anim = (v.get("anim") or "").strip()
            if anim not in anims: anim = anims[0]
            preset = neg if str(v.get("sentiment") or "").lower().startswith("neg") else pos
            # A list line comes back as a STACK (VSL): one overlay per item, side by side, each timed to its words.
            items = v.get("texts") if (_vsl and isinstance(v.get("texts"), list)) else None
            if items:
                items = [str(t or "").strip() for t in items if str(t or "").strip()][:4]
            if items and len(items) >= 2:
                if not all(_fits(t) for t in items):
                    continue                                # an item breaks the rule -> skip the scene
                ovs = []
                for k, t in enumerate(items):
                    ov = _ost_overlay(t, anim, preset)
                    ov["ost_x"], ov["ost_y"] = _OST_STACK_POS[len(items)][k]
                    ov["ost_place"] = "center"
                    ov["ost_size"] = min(int(ov.get("ost_size") or _OST_STACK_SIZE), _OST_STACK_SIZE)
                    ovs.append(ov)
                s["overlays"] = ovs; s["ost_on"] = True
                added += 1; changes.append({"id": sid, "text": " | ".join(t.replace("\n", " / ") for t in items)})
                continue
            text = (v.get("text") or "").strip() or (items[0] if items else "")   # a one-item "texts" is just a text
            if not _fits(text):
                continue                                    # doesn't fit the rule -> skip
            s["overlays"] = [_ost_overlay(text, anim, preset)]; s["ost_on"] = True
            added += 1; changes.append({"id": sid, "text": text.replace("\n", " / ")})
        _align_ost_to_vo(project, doc)               # time each OST to WHEN its keyword is actually spoken
        save_doc(project, doc)
        report = {"added": added, "eligible": len(eligible), "changes": changes[:200]}
        with _OST_LOCK: j.update(status="done", pct=100, report=report)
    except ClaudeNotLoggedIn as e:
        with _OST_LOCK: j.update(status="error", error=str(e))
    except Exception as e:
        with _OST_LOCK: j.update(status="error", error=str(e)[:200])


def _ost_norm_w(w):
    """Normalize a word for OST<->voice-over matching: lowercase + drop non-[a-z0-9] (also strips accents
    uniformly on both sides, so 'énergie' and 'ENERGIE' both become 'nergie' and still match)."""
    return re.sub(r"[^a-z0-9]", "", str(w).lower())


def _ost_match_span(ost_text, scene_words):
    """First in-order (subsequence) occurrence of the OST's words within the scene's spoken words. Handles a
    SHORTENED overlay (its words appear in order but not necessarily adjacent). Returns (start_t, end_t) or None."""
    targets = [t for t in (_ost_norm_w(x) for x in re.split(r"\s+", ost_text or "")) if t]
    if not targets:
        return None
    ti, start_t, end_t = 0, None, None
    for ws, we, word in scene_words:            # load_word_tsv items are (start, end, word) tuples
        nw = _ost_norm_w(word)
        if nw and nw == targets[ti]:
            if ti == 0:
                start_t = ws
            end_t = we
            ti += 1
            if ti == len(targets):
                return (start_t, end_t)
    return None


def _align_ost_to_vo(project, doc):
    """Set each on-screen-text overlay's show window (ost_in/ost_out, fractions of the scene) to WHEN its
    keyword is actually SPOKEN, using the word-level alignment. Best-effort — a scene we can't time keeps its
    default full-scene window; NEVER raises."""
    try:
        d, _ = proj_dir(project)
        srtp = _find_srt(d)
        vo = _normalized_vo(d)
        words = premiere_export.load_word_tsv(d / "subtitle") if srtp else None
        if not (srtp and words):
            return
        cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
        if not cues:
            return
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        scenes = doc.get("scenes", [])
        word_starts = premiere_export.word_scene_starts(scenes, words)
        ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
        for s, (t0, t1), inc in zip(scenes, ranges, included):
            if not inc or not s.get("ost_on"):
                continue
            dur = max(0.001, t1 - t0)
            scene_words = [w for w in words if w[0] is not None and (t0 - 0.05) <= w[0] < (t1 + 0.05)]
            if not scene_words:
                continue
            for ov in (s.get("overlays") or []):
                span = _ost_match_span(ov.get("onscreen"), scene_words)
                if not span or span[0] is None or span[1] is None:
                    continue
                a = max(0.0, min(1.0, (span[0] - t0 - 0.10) / dur))   # appear ~0.1s before the keyword
                ov["ost_in"] = round(a, 4)
                ov["ost_out"] = 1.0                                    # then STAY until the scene ends (fades out at the cut)
    except Exception as _qe:
        quiet(_qe, "_align_ost_to_vo")

@app.route("/api/scenes/<project>/gen-ost", methods=["POST"])
@_locked
def api_gen_ost(project):
    if load_doc(project) is None:
        abort(404)
    params = request.get_json(force=True) or {}
    jid = new_uid()
    OST_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_ost_worker, args=(jid, project, params), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/ost-job/<jid>")
def api_ost_job(jid):
    j = OST_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/ost-cancel/<jid>", methods=["POST"])
def api_ost_cancel(jid):
    j = OST_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

OVERLAY_JOBS = {}
_OVERLAY_LOCK = threading.Lock()

def _ov_clamp(v, d=0.5):
    try: return min(1.0, max(0.0, float(v)))
    except Exception: return d

def _ov_size(v):
    try: return min(1.4, max(0.5, float(v)))
    except Exception: return 1.0

def _ov_icon(it):
    """Normalize one vision icon dict -> {type,x,y,size,rot,flip}. For an arrow, the vision x,y is the TARGET the
    tip should touch, so shift the CENTRE off it (the art points right; flip=left)."""
    t = (it.get("type") or it.get("icon") or "").strip().lower()
    if t not in ("x", "arrow", "burst", "check"):
        return None
    x, y, sz = _ov_clamp(it.get("x")), _ov_clamp(it.get("y")), _ov_size(it.get("size"))
    flip = str(it.get("dir", "")).strip().lower() == "left"
    # colour rule (hue 0 == the icon PNG's native RED, 120 == green):
    # - x and pain-burst are ALWAYS red (rejection / pain).
    # - check is ALWAYS GREEN (a tick is inherently positive/confirmed).
    # - arrow is GREEN when it points at something positive/good, RED when negative.
    hue = 0
    if t == "arrow":
        x = _ov_clamp(x + (0.09 if flip else -0.09))
        if it.get("good") is True:
            hue = 120
    elif t == "check":
        hue = 120
    return {"type": t, "x": round(x, 4), "y": round(y, 4), "size": round(sz, 3), "rot": 0, "flip": flip, "hue": hue}

MOVE_MAX_SHARE = 0.55      # no single camera move may own more than this much of an episode
MOVE_MAX_RUN = 3           # ...nor appear more than this many times in a row


def _balance_moves(scenes):
    """Stop every shot drifting the same way.

    The overlay prompt asks for variety in words - "a whole video of pushes is as dull as a whole video
    of holds" - and got 37 pushes out of 45 anyway. Each drift is subtle on its own; forty of them in
    the same direction is a video that never sits still. So the words are backed by a count: break any
    run longer than three, then convert the excess of whichever move dominates. A busy frame becomes a
    HOLD (the viewer needs time to read it), anything else becomes a PULL.
    """
    got = [s for s in scenes if s.get("move") in ("push", "pull", "hold")]
    if len(got) < 6:
        return 0
    busy = lambda s: any(w in (s.get("prompt") or "").lower()
                         for w in ("cutaway", "cross-section", "diagram", "sliced", "exploded",
                                   "laid out", "labelled", "several", "group"))
    changed = 0

    def break_runs():
        n, run, prev = 0, 0, None
        for s in got:
            if s["move"] == prev:
                run += 1
                if run >= MOVE_MAX_RUN:
                    s["move"] = "hold" if busy(s) else ("pull" if prev == "push" else "push")
                    n += 1
                    run = 0
            else:
                run = 0
            prev = s["move"]
        return n

    changed += break_runs()                         # 1. break the long runs
    cap = int(len(got) * MOVE_MAX_SHARE)            # 2. cap whatever still dominates
    for _ in range(3):
        counts = {}
        for s in got:
            counts[s["move"]] = counts.get(s["move"], 0) + 1
        top = max(counts, key=counts.get)
        if counts[top] <= cap:
            break
        # thin the dominant move out evenly rather than in a block
        over = counts[top] - cap
        hits = [s for s in got if s["move"] == top]
        step = max(1, len(hits) // max(1, over))
        for s in hits[::step][:over]:
            s["move"] = "hold" if busy(s) else ("pull" if top != "pull" else "hold")
            changed += 1
    # 3. capping rewrites scenes without looking at their neighbours, so it can hand back a run of its
    #    own. One more pass; it only ever shortens runs, so it cannot undo the cap by much.
    changed += break_runs()
    return changed


BADGE_LANGS = ("en", "fr", "de")            # the badge art that exists in Icons/
BADGE_POS = (0.82, 0.24)                   # default spot: top-right, clear of centred text and the subtitles


def _badge_lang(doc):
    l = str((doc or {}).get("subtitle_lang") or "").strip().lower()[:2]
    if l not in BADGE_LANGS:
        l = str(audience_lang((doc or {}).get("audience")) or "").strip().lower()[:2]
    return l if l in BADGE_LANGS else "en"


def _badge_pass(scenes, doc):
    """Which lines earn a trust badge. Returns {scene id: icon type}. Never raises.

    One call over the WHOLE script, like the on-screen text pass - not the per-scene vision pass. Which
    badge a line deserves is a question about the words, and "never two in a row" is unenforceable by a
    model that only ever sees one scene at a time.
    """
    rows = [(s.get("id"), (s.get("vo") or "").strip()) for s in scenes if (s.get("vo") or "").strip()]
    if not rows:
        return {}
    lang = _badge_lang(doc)
    user = "\n".join("%s\t%s" % (i, v) for i, v in rows)
    try:
        obj = _parse_json_obj(_claude_text(BADGE_SYSTEM, user, max_tokens=1500)) or {}
    except Exception as e:
        # a bare guard here hid a missing import once - say what went wrong, then carry on without badges
        print("badge pass failed: %s: %s" % (type(e).__name__, str(e)[:160]))
        return {}
    kinds = {"guarantee_1year": "bdg1y", "guarantee_360": "bdg360", "money_back": "bdgmb",
             "free_shipping": "bdgship", "limited_stock": "bdgstock"}
    order = [i for i, _v in rows]
    carded = {s.get("id") for s in scenes if (s.get("card") or "").strip()}   # a card already says it - no badge there
    picked = {}
    for it in (obj.get("badges") or []):
        if not isinstance(it, dict):
            continue
        k = kinds.get(str(it.get("badge") or "").strip().lower())
        try:
            sid = int(it.get("id"))
        except (TypeError, ValueError):
            continue
        if k and sid in order and sid not in carded:
            lst = picked.setdefault(sid, [])
            if k + "_" + lang not in lst and len(lst) < 4:  # a recap line may carry up to four, each promise once
                lst.append(k + "_" + lang)
    # The model is told never to badge two scenes running; enforce it here too, because a rule the model
    # is merely ASKED to keep is the one that slips (see _balance_icons).
    out, prev = {}, None
    for sid in order:
        if sid in picked and prev is not None and prev in out:
            prev = sid
            continue                                    # the one right after a badged scene is dropped
        if sid in picked:
            out[sid] = picked[sid]
        prev = sid
    return out


ICON_MAX_SHARE = 0.28      # at most about one scene in four may carry an icon
ICON_MAX_RUN = 2           # ...and never more than this many icon scenes back to back


def _balance_icons(scenes):
    """Stop the icons clustering. Returns how many were cleared.

    The vision pass looks at ONE frame and ONE line at a time, in parallel - it cannot see what the
    neighbouring scenes were given, so the prompt's own rules ("never stamp the same icon scene after
    scene", "about 1 in 4") are wishes it has no way to keep. Exactly the failure the camera moves had
    before _balance_moves: asked in words for variety, returned 37 pushes out of 45. Same cure - count
    them here, where the whole episode is visible at once.

    `scenes` is every scene the icon pass considered, in timeline order.
    """
    _plain = lambda s: [i for i in (s.get("icons") or []) if not str((i or {}).get("type", "")).startswith("bdg")]
    got = [s for s in scenes if _plain(s)]
    if len(scenes) < 6 or not got:
        return 0
    kind = lambda s: ((_plain(s) or [{}])[0]).get("type") or ""
    cleared = 0

    def drop(s):
        nonlocal cleared
        s["icons"] = []
        cleared += 1

    run, prev_kind = 0, None                          # 1. break the clusters and the repeats
    for s in scenes:
        if not s.get("icons"):
            run, prev_kind = 0, None
            continue
        run += 1
        if run > ICON_MAX_RUN or kind(s) == prev_kind:
            drop(s)                                   # a third in a row, or the same icon twice running
            run, prev_kind = 0, None
            continue
        prev_kind = kind(s)

    left = [s for s in scenes if s.get("icons")]      # 2. still too many? thin them out evenly
    cap = max(1, int(len(scenes) * ICON_MAX_SHARE))
    if len(left) > cap:
        over = len(left) - cap
        step = max(1, len(left) // max(1, over))
        for s in left[::step][:over]:
            drop(s)
    return cleared


def _overlay_worker(jid, project, do_icons=True, do_sfx=True, do_fx=True):
    j = OVERLAY_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _OVERLAY_LOCK: j.update(status="error", error="project not found")
            return
        d, _safe = proj_dir(project)
        ov_updates = {}                                   # per-scene field changes -> merged onto the latest doc at the end
        _mv_scenes = []                                   # every scene that got a camera move, for the balance pass
        _ic_scenes = []                                   # ...and every scene the icon pass looked at
        media = []
        for s in doc["scenes"]:
            img = s.get("image") or {}
            ir = img.get("approved_file") or img.get("file")
            _claimed = (not is_youtube(doc)) and ((s.get("card") or "").strip() or any(str((i or {}).get("type") or "").startswith("bdg") for i in (s.get("icons") or [])))
            if s.get("approved") and ir and (d / ir).exists() and not s.get("tcard_id") and not s.get("testimonial") and not _claimed:
                # Every approved shot is LOOKED AT - the film look (dust, grain) belongs on a drawn scene
                # as much as a photographed one. It is only the ICONS that AUTO keeps off drawn scenes,
                # and that is decided per scene below. (Skipping the whole scene here meant a 2D channel
                # got nothing at all out of the effects pass.)
                media.append((s, d / ir))                  # testimonial = auto-composed selfie grid -> never auto-add icons/sfx
        total = len(media)
        if not total:
            with _OVERLAY_LOCK: j.update(status="error", error="No approved images to analyze yet.")
            return
        def _one(item):
            s, ip = item
            if j.get("cancel"):
                return None
            return _parse_json_obj(_claude_vision(OVERLAY_SYSTEM, f"Voice-over: {(s.get('vo') or '').strip()}", str(ip))) or {}
        def _prog(dn, tot):
            with _OVERLAY_LOCK: j.update(step=f"Looking at image {dn}/{tot}…", pct=int(4 + 92 * dn / tot))
        res = _parallel_map(media, _one, cancel=lambda: j.get("cancel"), on_progress=_prog)   # PARALLEL vision (bounded)
        if j.get("cancel"):
            with _OVERLAY_LOCK: j.update(status="cancelled")
            return
        for _r in res:                                   # a "not logged in" anywhere → surface it + stop
            if isinstance(_r, tuple) and len(_r) == 2 and _r[0] == "__err__" and isinstance(_r[1], ClaudeNotLoggedIn):
                with _OVERLAY_LOCK: j.update(status="error", error=str(_r[1]))
                return
        icons = sfxn = fxn = grn = atm = 0
        mvc = {}
        for (s, ip), r in zip(media, res):
            if not isinstance(r, dict):                  # per-image hiccup / cancelled → leave that scene untouched
                continue
            u = ov_updates.setdefault(s["id"], {})
            # fx_on: a dark cinematic atmosphere (effect1/effect2, render + Premiere XML) for a TENSE/serious
            # NEGATIVE realistic beat — decided from the same vision pass, only on realistic (natural) scenes.
            if do_fx:                                    # leave fx_on alone unless it was asked for
                fxv = bool(r.get("fx")) and s.get("style") == "natural"
                s["fx_on"] = fxv; u["fx_on"] = fxv
                if fxv: fxn += 1
                # film grain: old-film texture over historical / archival shots and genuinely grim ones.
                # Unlike fx it is not limited to realistic scenes - a drawn period scene wants it too.
                gv = bool(r.get("grain"))
                s["grain_on"] = gv; u["grain_on"] = gv
                if gv: grn += 1
                # weather laid over the shot - only where the picture already has it
                av = str(r.get("atmo") or "none").strip().lower()
                av = av if av in ("fog", "rain", "snow", "embers") else ""
                s["atmo"] = av; u["atmo"] = av
                if av: atm += 1
                # push / pull / hold - ONE camera move per shot, never a zoom and a wobble together
                mv = str(r.get("move") or "").strip().lower()
                s["move"] = mv if mv in ("push", "pull", "hold") else "hold"
                u["move"] = s["move"]
                mvc[s["move"]] = mvc.get(s["move"], 0) + 1
                _mv_scenes.append(s)
            # AUTO never adds icons to a drawn scene - but LEAVE any the user placed there by hand
            if do_icons and s.get("style") not in ANIM_STYLES:
                built = []
                arr = r.get("icons")
                if isinstance(arr, list):
                    for it in arr:
                        ic = _ov_icon(it) if isinstance(it, dict) else None
                        if ic: built.append(ic)
                if not built:                            # single-icon shape (icon/x/y/size/dir at top level)
                    ic = _ov_icon(r)
                    if ic: built.append(ic)
                s["icons"] = built                       # unified list is the ONE source of truth
                for _lk in ("icon", "icon_x", "icon_y", "icon_size"):
                    s.pop(_lk, None)
                u["icons"] = built
                u["icon"] = _DEL; u["icon_x"] = _DEL; u["icon_y"] = _DEL; u["icon_size"] = _DEL
                _ic_scenes.append(s)
                if built: icons += 1
            if do_sfx:                                   # only (re)place sound effects if the user asked for them
                sx = (r.get("sfx") or "none").strip().lower()
                if sx == "healthmonitor" and s.get("style") != "natural":
                    sx = "hit"                           # monitor only on realistic shots; scientific/abstract -> cinematic hit
                s["sfx"] = sx if sx in ("ambulance", "healthmonitor", "hit", "time") else ""
                u["sfx"] = s["sfx"]
                if s["sfx"]: sfxn += 1
        # Balance the camera moves BEFORE they are written: the model was asked in words to vary them and
        # returned 37 pushes out of 45 anyway, which is a video that drifts the same way for three minutes.
        # TRUST BADGES. One narrow pass over the whole script (see _badge_pass), appended AFTER the vision
        # pass has replaced each scene's icon list, so it is not overwritten. VSL only - a YouTube episode
        # has no offer to guarantee.
        badges = 0
        if do_icons and not is_youtube(doc):
            with _OVERLAY_LOCK: j.update(step="Placing trust badges…")
            try:
                _bmap = _badge_pass(doc.get("scenes") or [], doc)
            except Exception:
                _bmap = {}
            for _s in (doc.get("scenes") or []):
                _bk = _bmap.get(_s.get("id"))
                if not _bk:
                    continue
                _ic = [i for i in (_s.get("icons") or [])
                       if not str((i or {}).get("type") or "").startswith("bdg")]      # replace the badges, keep the rest
                _bks = _bk if isinstance(_bk, list) else [_bk]
                for _n, _b in enumerate(_bks):                # several badges sit in a row across the badge line
                    _ic.append({"type": _b, "x": round(BADGE_POS[0] + (_n - (len(_bks) - 1) / 2.0) * 0.20, 4),
                                "y": BADGE_POS[1], "size": 1.0, "rot": 0, "flip": False, "hue": 0})
                _s["icons"] = _ic
                ov_updates.setdefault(_s.get("id"), {})["icons"] = _ic
                badges += 1

        # Same story for the icons, and for the same reason - see _balance_icons. VSL only for now: a
        # YouTube episode gets no icons at all today, so gating it costs nothing and keeps the two apart.
        if do_icons and not is_youtube(doc):
            n_ic = _balance_icons(_ic_scenes)
            if n_ic:
                for _s in _ic_scenes:
                    ov_updates.setdefault(_s["id"], {})["icons"] = _s.get("icons") or []
                icons = sum(1 for _s in _ic_scenes if _s.get("icons"))
        n_bal = _balance_moves(_mv_scenes)
        if n_bal:
            for _s in _mv_scenes:
                ov_updates.setdefault(_s["id"], {})["move"] = _s["move"]
            mvc = {}
            for _s in _mv_scenes:
                mvc[_s["move"]] = mvc.get(_s["move"], 0) + 1
        merge_save_fields(project, ov_updates)
        if do_fx:
            # Dust is not a per-scene decision - it is a film look that sits over the whole episode.
            # Asking for the effects pass is what turns it on.
            d2 = load_doc(project) or {}
            # the whole-episode look, switched on by asking for the effects pass. Each one is its own
            # flag so any of them can be turned off again without touching the others.
            # cam_float is the handheld wobble. On drawn frames it reads as the DRAWING trembling
            # rather than a camera moving, so it is off: the zoom and the depth drift carry the life.
            want = {"film_dust": True, "film_grade": True}
            if is_youtube(d2):
                want["cam_parallax"] = True      # YouTube only - see _build_timeline
            if d2 and any(not d2.get(k) for k in want):
                d2.update({k: v for k, v in want.items() if not d2.get(k)})
                save_doc(project, d2)
        with _OVERLAY_LOCK: j.update(status="done", pct=100, report={"scenes": total, "icons": icons, "badges": badges, "sfx": sfxn, "fx": fxn, "grain": grn, "atmo": atm, "moves": mvc})
    except Exception as e:
        with _OVERLAY_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/overlays", methods=["POST"])
@_locked
def api_overlays(project):
    if load_doc(project) is None:
        abort(404)
    body = request.get_json(silent=True) or {}
    do_icons = body.get("icons", True) is not False        # default all on; the popup lets the user pick
    do_sfx = body.get("sfx", True) is not False
    do_fx = body.get("fx", True) is not False
    if not (do_icons or do_sfx or do_fx):
        return jsonify({"error": "Pick at least one of visual effects, icons or sound effects."}), 400
    jid = new_uid()
    OVERLAY_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_overlay_worker, args=(jid, project, do_icons, do_sfx, do_fx), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/overlays-job/<jid>")
def api_overlays_job(jid):
    j = OVERLAY_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/overlays-cancel/<jid>", methods=["POST"])
def api_overlays_cancel(jid):
    j = OVERLAY_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})


# 'flash' is the user's Light Leak clip (a bright flash); map it to the lightleak transition key used everywhere else.
_TRANS_SYNONYM = {"flash": "lightleak", "lightleak": "lightleak", "light-leak": "lightleak"}
_TRANS_ALLOWED = {"none", "crossfade", "dip-black", "dip-white", "film", "lightleak"}
TRANS_JOBS = {}
_TRANS_LOCK = threading.Lock()

def _est_scene_secs(s):
    """Rough on-screen seconds from VO word count (~2.67 words/sec) — same basis as OST timing."""
    w = len((s.get("vo") or "").split())
    return (w / 2.67) if w else 0.0

def _thin_transitions(scenes):
    """House rules so Auto Transitions stays tasteful (see memory ost-and-auto-transitions):
    1) NO transition on a very short scene (< 2.5s est) — a transition would eat the whole clip;
    2) crossfade only where it can breathe (>= 3s) and never two within 3 scenes — keeps them rare."""
    for s in scenes:                                        # 1) drop transitions on very short scenes
        if (s.get("transition") or "none") != "none":
            d = _est_scene_secs(s)
            if 0 < d < 2.5:
                s["transition"] = "none"
    last_cf = -99                                           # 3) keep crossfades rare + spread out
    for idx, s in enumerate(scenes):
        if (s.get("transition") or "") == "crossfade":
            d = _est_scene_secs(s)
            if (0 < d < 3.0) or (idx - last_cf < 3):
                s["transition"] = "none"
            else:
                last_cf = idx
    return scenes

def _trans_worker(jid, project):
    j = TRANS_JOBS[jid]
    try:
        doc = load_doc(project)
        if doc is None:
            with _TRANS_LOCK: j.update(status="error", error="project not found")
            return
        scenes = doc.get("scenes") or []
        if not scenes:
            with _TRANS_LOCK: j.update(status="error", error="No scenes yet.")
            return
        with _TRANS_LOCK: j.update(step="Claude is choosing transitions…", pct=30)
        lines = "\n".join(f'{s["id"]}\t{(s.get("vo") or "").strip()}' for s in scenes)
        arr = _parse_json_array(_claude_text(AUTO_TRANS_SYSTEM, "Scenes (id<TAB>voice-over), in order:\n" + lines, max_tokens=8000))
        byid = {s["id"]: s for s in scenes}
        applied, changes = 0, []
        for v in (arr or []):
            try: sid = int(v.get("id"))
            except Exception: continue
            t = (v.get("transition") or "none").strip().lower()
            t = _TRANS_SYNONYM.get(t, t)                 # 'flash' -> 'lightleak' (the user's Light Leak clip)
            if t not in _TRANS_ALLOWED: continue
            s = byid.get(sid)
            if not s: continue
            s["transition"] = t
        if scenes:
            scenes[0]["transition"] = "none"        # nothing precedes the first scene
        _thin_transitions(scenes)                   # enforce house rules (entry+exit slides, no short-clip / rare crossfade)
        changes = [{"id": s["id"], "transition": s["transition"]} for s in scenes if (s.get("transition") or "none") != "none"]
        applied = len(changes)
        save_doc(project, doc)
        report = {"applied": applied, "total": len(scenes), "changes": changes[:300]}
        with _TRANS_LOCK: j.update(status="done", pct=100, report=report)
    except ClaudeNotLoggedIn as e:
        with _TRANS_LOCK: j.update(status="error", error=str(e))
    except Exception as e:
        with _TRANS_LOCK: j.update(status="error", error=str(e)[:200])

@app.route("/api/scenes/<project>/auto-transitions", methods=["POST"])
@_locked
def api_auto_transitions(project):
    if load_doc(project) is None:
        abort(404)
    jid = new_uid()
    TRANS_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 0, "cancel": False}
    _KeyThread(target=_trans_worker, args=(jid, project), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/scenes/transitions-job/<jid>")
def api_transitions_job(jid):
    j = TRANS_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify({k: v for k, v in j.items() if k != "cancel"})

@app.route("/api/scenes/transitions-cancel/<jid>", methods=["POST"])
def api_transitions_cancel(jid):
    j = TRANS_JOBS.get(jid)
    if j:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/qa/system-request/<project>", methods=["POST"])
def api_qa_system_request(project):
    """The user ticked QA-proposed system improvements + OK'd them → queue them (so they can be baked into the
    app's prompts/rules and not recur). Appended to data/learn/qa_system_requests.jsonl for later review."""
    b = request.get_json(force=True) or {}
    reqs = [str(x).strip() for x in (b.get("suggestions") or []) if str(x).strip()]
    if reqs:
        f = DATA_DIR / "learn" / "qa_system_requests.jsonl"
        f.parent.mkdir(parents=True, exist_ok=True)
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"project": project, "suggestions": reqs}, ensure_ascii=False) + "\n")
    return jsonify({"ok": True, "saved": len(reqs)})

# ---- routes: image generation ----------------------------------------------
# ---- generation QUEUE: cap how many jobs are submitted/in-flight at once so a big "Generate All"
# doesn't fire 40+ API calls simultaneously (which the provider rate-limits → failures). Extra
# scenes wait as status "queued" and are submitted by the poll loop as running jobs finish.
IMG_CONCURRENCY = 6
VID_CONCURRENCY = 3
IMG_GEN_TIMEOUT = 300     # seconds: a "generating" image that Kie never finishes is failed (not stuck forever)
VID_GEN_TIMEOUT = 900     # videos legitimately take longer

# Written numbers, in the languages these scripts come in. The user names their product images
# themselves ("3 Bottle", "6 Bottle"), so the count is read straight off that name - no matching of
# free-text phrases against filenames, which is the fragile part.
_PACK_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "nine": 9, "ten": 10, "twelve": 12,
    "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "douze": 12,
    "ein": 1, "eine": 1, "zwei": 2, "drei": 3, "vier": 4, "funf": 5, "sechs": 6, "zwolf": 12,
    "bir": 1, "iki": 2, "uc": 3, "alti": 6, "oniki": 12,
}


PRODUCT_FORM_SYSTEM = (
    "Look at this product photograph and describe the CONTAINER in one short phrase a photographer could "
    "work from: its type, material, colour and closure. Nothing else - no brand name, no marketing, no "
    "ingredients, no sentence. Examples of the right shape of answer: 'an amber glass bottle with a black "
    "screw cap and an orange label'; 'a white plastic tub with a blue lid'; 'a flat cardboard carton'. "
    "If several identical units are shown, describe ONE of them. Answer with the phrase alone.")


def product_form(doc, d, refresh=False):
    """One short phrase describing what the product physically IS, read off the client's own packshot.

    The director only ever knew the brand NAME. On a French script it read 'boites' and wrote 'a box of
    CARDIO-360' into 37 prompts - so 37 pictures drew a carton for a product that is an amber bottle.
    Nothing in the pipeline could catch it, because nothing in the pipeline had ever seen the product.

    Cached in the doc: it costs one vision call per project, and it is wanted by the director, the audit
    and the image QA alike.
    """
    prod = (doc or {}).get("product") or {}
    if not refresh and (prod.get("form") or "").strip():
        return prod["form"].strip()
    urls = prod.get("urls") or []
    if not urls:
        return ""
    src_url = _default_product_url(doc) or urls[0]
    try:
        p = d / src_url
        if not p.exists():
            return ""
        form = (_claude_vision(PRODUCT_FORM_SYSTEM, "Describe the container.", str(p)) or "").strip()
    except Exception:
        return ""
    form = " ".join(form.split()).strip(' "\'.')[:160]
    if not form:
        return ""
    doc.setdefault("product", {})["form"] = form
    return form


def product_form_line(doc, d):
    """The sentence handed to the director / audit / QA. Empty when there is no product image to read."""
    form = product_form(doc, d)
    if not form:
        return ""
    name = ((doc.get("product") or {}).get("name") or "the product").strip()
    return ("THE PRODUCT IS %s: %s. Describe it that way every time it appears and NEVER as anything "
            "else - not a box, carton, blister pack, sachet, tub or pouch - whatever word the script "
            "uses for it in its own language." % (name, form))


def _real_pack_sizes(doc):
    """The pack sizes that actually have a real photo (client-uploaded product images), so the QA can
    tell a genuine size from one the model just free-handed. Empty when only one image is on file - a
    single packshot has no "count" to confuse."""
    names = (doc.get("product") or {}).get("names") or {}
    sizes = sorted({n for n in (_pack_count_of(v) for v in names.values()) if n})
    if len(sizes) < 2:
        return ""
    return ("REAL PACK SIZES ON FILE: %s. A bare product shot naming any other count of containers has "
            "no real photo behind it - the model free-hands it and the label drifts."
            % ", ".join(str(n) for n in sizes))


def _pack_count_of(label):
    """How many containers a product-image NAME describes. '3 Bottle' -> 3, 'Six Bottles' -> 6, else None."""
    t = (label or "").strip().lower()
    if not t:
        return None
    # Every 1-2 digit run, and take the first that could BE a pack. Two real labels used to fail
    # silently: "6er Pack" (a word boundary needs whitespace after the digit, and "er" is not) and
    # "60 Capsules 6 Bottles" (60 matched first, fell outside the range, and the 6 was never reached).
    # The lookarounds still refuse a longer number, so "CARDIO-360" and "Pack 2024 de 6" behave.
    for m in re.finditer(r"(?<!\d)(\d{1,2})(?!\d)", t):
        n = int(m.group(1))
        if 1 <= n <= 24:
            return n
    for w, n in _PACK_WORDS.items():
        if re.search(r"\b%s\b" % w, t):
            return n
    return None


def _clean_packs(v):
    """Whole container counts the director reported for one line, de-duplicated and in order."""
    out = []
    for x in (v or []):
        try:
            n = int(x)
        except (TypeError, ValueError):
            continue
        if 1 <= n <= 24 and n not in out:
            out.append(n)
    return out[:4]


def _product_packs(doc):
    """{count: url} for every product image whose name names a pack size."""
    prod = doc.get("product") or {}
    names = prod.get("names") or {}
    out = {}
    for u in (prod.get("urls") or []):
        n = _pack_count_of(names.get(u))
        if n and n not in out:
            out[n] = u
    return out


def _pack_url(doc, n):
    """The uploaded image for a pack of `n`. None rather than a near miss - the wrong pack is worse
    than no pack, and the caller flags it instead of guessing a neighbour."""
    try:
        return _product_packs(doc).get(int(n))
    except (TypeError, ValueError):
        return None


def _advance_pack(running, scene_packs):
    """The bundle the offer has moved to, after this line.

    A VSL escalates: once it has pitched the 6-pack, every later mention of the brand should show the
    6-pack, not the single bottle it opened with. So the running pack is the LARGEST size named so far.
    """
    return max([running or 0] + list(scene_packs or [])) or None


def _pick_pack_url(doc, scene_packs, running):
    """The product image for one scene: the pack this LINE names, else the pack the offer has already
    moved to, else the plain single bottle. A size the user has not uploaded falls back rather than
    showing the wrong box."""
    n = max(scene_packs) if scene_packs else running
    return (_pack_url(doc, n) if n else None) or _default_product_url(doc)


def _default_product_url(doc):
    """The pack to AUTO-attach when the director flags a scene as showing the product (like it auto-picks
    cast/ingredients). Prefer a single-bottle pack by name, else the first product image. None if no product."""
    prod = doc.get("product") or {}
    urls = prod.get("urls") or []
    if not urls:
        return None
    names = prod.get("names") or {}
    # Read the COUNT first. The keyword scan below cannot see a label that is just "1" - it looks for
    # "1 ", "1x", "single"… - so a user who labelled their packs 1 / 3 / 6 / 12 and happened to upload
    # the 6-pack first got the 6-pack auto-attached to every product shot, including the ones long
    # before the offer. Counting is the same rule the rest of the pack code already uses.
    for u in urls:
        if _pack_count_of(names.get(u)) == 1:
            return u
    for u in urls:
        nm = (names.get(u) or "").lower()
        if any(k in nm for k in ("1 ", "1x", "1-", "single", "one bottle", "tek")):
            return u
    return urls[0]

def _scene_product_url(s, doc):
    """The ONE product image chosen for this scene (e.g. the 1-bottle / 3-pack / 6-pack render), or None.
    scene['product'] holds the chosen url; legacy True means the first product image. Attaches in RAW mode
    too (like a scene reference) — only the extra product WORDING is skipped in raw (see assemble)."""
    prod_urls = (doc.get("product") or {}).get("urls") or []
    if not prod_urls:
        return None
    chosen = s.get("product")
    if not chosen:
        return None
    if chosen is True:
        return prod_urls[0]
    return chosen if chosen in prod_urls else None

CARD_MAX_WORDS = 6          # a full-screen card is a headline, not a sentence


def _clean_card(v):
    """The words for a full-screen card, or "" for an ordinary shot. Long enough to be a phrase, short
    enough to fill a frame - anything longer is the director writing a sentence, and gets dropped."""
    t = " ".join(str(v or "").split())
    if not t or t.lower() in ("null", "none", "false"):
        return ""
    return t if len(t.split()) <= CARD_MAX_WORDS else ""


def _card_prompt(s, doc, has_style_ref=False):
    """The whole prompt for a full-screen card. The picture IS the words, so the normal staging, cast,
    product, style and no-text layers are all skipped - every one of them would fight it, especially the
    no-text rule that keeps stray captions out of ordinary shots."""
    txt = (s.get("card") or "").strip()
    look = (" One attached reference is an EARLIER CARD from this same video: match its lettering, finish, "
            "palette and camera angle so the cards read as one set - only the words differ."
            if has_style_ref else
            " Design it as the first of a set: a look that later cards in this video can be matched to.")
    # The look the user asked for, from their own references: stock-style 3D word art - thick extruded
    # letters with a chrome bevel, shot at a slight angle, filling the frame. A flat designed card was
    # rejected; this is deliberately the loud direct-response look, not a tasteful poster.
    return (
        "A 3D RENDERED WORD-ART graphic in the style of stock 3D typography - the picture IS the words. "
        "NOT a photograph, NOT a scene, NOT a flat poster. The words \"%s\" built as thick extruded "
        "three-dimensional block letters in glossy white with clean bevelled chrome edges, stacked over "
        "two or three lines and filling the frame edge to edge, seen at a slight dramatic perspective so "
        "the letters recede and their extruded sides catch the light. Deep saturated red background with "
        "a soft radial glow behind the lettering. Bold condensed sans-serif, ALL CAPITALS, spelled "
        "EXACTLY as written here, with every accent and diacritic. The words may be in ANY language - "
        "French, German, Spanish, Turkish - reproduce them letter for letter and NEVER translate "
        "them or 'correct' them into English. Crisp studio reflections, high contrast. NO people, "
        "NO faces, NO hands, NO product or packaging, NO photographic scenery, NO other words anywhere, "
        "no logos, no watermark, no borders." % txt) + look


def _card_style_ref(s, doc):
    """The card a later card should MATCH THE LOOK OF - the first one that already has a picture, so every
    card in a video belongs to the same set. Same lazy rule as the showcases."""
    if not (s.get("card") or "").strip():
        return None
    for o in (doc.get("scenes") or []):
        if o.get("id") == s.get("id") or not (o.get("card") or "").strip():
            continue
        im = o.get("image") or {}
        f = im.get("approved_file") or im.get("file")
        if im.get("status") == "ready" and f:
            return f
    return None


def _showcase_style_ref(s, doc):
    """The picture a later showcase should MATCH THE LOOK OF: the first showcase scene that already has one.

    Worked out on the fly rather than stored, so regenerating the first showcase simply moves the reference
    with it. It is attached as a STYLE reference only - the backdrop, surface and lighting - never as the
    contents, or a 6-pack shot would copy the 3-pack it was matching.
    """
    if not (s.get("packs") or []):
        return None
    for o in (doc.get("scenes") or []):
        if o.get("id") == s.get("id") or not (o.get("packs") or []):
            continue
        im = o.get("image") or {}
        f = im.get("approved_file") or im.get("file")
        if im.get("status") == "ready" and f:
            return f
    return None


def _showcase_pack_urls(s, doc):
    """Every pack image this scene needs. A line offering TWO options shows both groups, so both packs are
    attached; a single-pack line is already covered by the normal product reference."""
    packs = s.get("packs") or []
    if len(packs) < 2:
        return []
    out = []
    for n in packs:
        u = _pack_url(doc, n)
        if u and u not in out:
            out.append(u)
    return out


# ---- SHOWCASE: the packs are COMPOSITED, never drawn --------------------------------------------------
# Asking the model for an exact number of bottles does not work. Three tries on one real offer line gave a
# woman in a bedroom, then a vague four-ish group, then FIVE where six were named - with the client's own
# 6-pack photo attached every time. It also mangles the label ("MITAROUSM & BLOOD SUGAR"). So for a
# showcase the AI paints only the SET, and the client's exact transparent pack photo is composited onto
# it: the count becomes arithmetic and the label is the real one, pixel for pixel.
SHOWCASE_SOLID_A  = 200     # the supplied packs carry a baked shadow that peaks at alpha 199; glass is 255
SHOWCASE_HEIGHT   = 0.62    # bottle height as a fraction of frame height, one group
SHOWCASE_PAIR_H   = 0.56    # two options share the frame
SHOWCASE_GAP      = 0.035    # gap between the two groups
SHOWCASE_CENTRE   = 0.50    # where the product's own vertical centre should land in the frame
SHOWCASE_BACK_GAP = 0.02    # the BACK row must clear the seam by at least this much of the height
SHOWCASE_FOOT_MAX = 0.95    # ...but never let the front footing fall off the bottom edge
SHOWCASE_MAX_SEAM = 0.66    # the horizon is forced no lower than this, whatever the plate came back with
SHOWCASE_SEAM_DE  = 26      # least Lab difference allowed between the panel and the floor it stands on


def _sc_prep(rgba):
    """-> (crop WITH its own shadow intact, base row inside it, bottle centre-x, bottle height).

    The supplied packs already carry a properly rendered soft shadow (near-black, mean alpha ~40, in the
    rows below the glass). Two things went wrong before: aligning on the ALPHA box, which includes that
    shadow and runs 42 rows deep under the 3-pack but 72 under the 6-pack - so the two groups floated by
    different amounts and did not share a baseline - and then painting a SECOND synthetic shadow over the
    real one. Keep the artwork's shadow; align on the bottles' real footing.
    """
    import numpy as np
    a = rgba[:, :, 3]
    ys, xs = np.where(a > 8)
    sy, sx = np.where(a > SHOWCASE_SOLID_A)
    if sy.size == 0:
        c = rgba[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        return c, c.shape[0] - 1, c.shape[1] / 2.0, c.shape[0]
    top, base, bot = int(min(ys.min(), sy.min())), int(sy.max()), int(ys.max())
    l, r = int(xs.min()), int(xs.max())
    return (rgba[top:bot + 1, l:r + 1], base - top,
            (int(sx.min()) + int(sx.max())) / 2.0 - l, base - top + 1)


def _sc_raise_floor(bg, target):
    """Move the wall/floor seam UP to `target`, without touching the wall above it.

    The composition is centred only if the horizon is high enough to stand a deep pack on: with a bottle
    height of 0.62 H and a back row 18.4% of that behind the front one, the seam has to sit at or above
    0.676 H or the back-row rule drags the whole group into the bottom half. Asked for a floor over the
    bottom 40%, the model kept returning 0.74-0.76 - the same kind of instruction-following failure as the
    bottle counts, so it is settled here instead of in the prompt.

    Only the FLOOR is resampled, stretched up into the bottom of the wall. The wall itself - pattern,
    arch, metallic rim - keeps its proportions exactly; it simply meets the floor higher up, which is what
    a panel standing on a floor looks like anyway. Squashing the wall instead would flatten the arch.
    """
    import cv2, numpy as np
    H = bg.shape[0]
    seam = _sc_floor(bg)
    if seam <= target + 2:
        return bg, seam
    floor = bg[seam:]
    if floor.shape[0] < 8:
        return bg, seam
    grown = cv2.resize(floor, (bg.shape[1], H - target), interpolation=cv2.INTER_LINEAR)
    out = bg.copy()
    out[target:] = grown
    return out, target


def _sc_separate_floor(bg, seam):
    """Pull the floor's tone away from the panel's when the two meet in the same colour.

    The plate came back with a cream panel (BGR 131,161,182) sitting on a cream floor (151,179,206): two
    brightnesses of one colour, so the panel's foot dissolved into the surface and the arch looked like it
    was melting. Measured in Lab across the seam and pushed apart in the direction they already differ -
    a lighter floor gets lighter, a darker one darker - so the design's own colour choice is respected,
    only the separation is guaranteed.
    """
    import cv2, numpy as np
    H, W = bg.shape[:2]
    band = max(6, int(H * 0.02))
    if seam - band < 0 or seam + 2 + band > H:
        return bg
    mid = slice(int(W * 0.36), int(W * 0.64))
    panel = bg[seam - band:seam, mid].reshape(-1, 3).mean(0)
    floor = bg[seam + 2:seam + 2 + band, mid].reshape(-1, 3).mean(0)

    def _de(a, b):
        lab = cv2.cvtColor(np.array([[a, b]], np.uint8), cv2.COLOR_BGR2LAB)[0].astype(float)
        return float(np.linalg.norm(lab[0] - lab[1]))

    if _de(panel, floor) >= SHOWCASE_SEAM_DE:
        return bg
    up = floor.mean() >= panel.mean()                 # push the way they already lean
    out = bg.astype(np.float32)
    for step in range(1, 13):
        k = 1.0 + 0.03 * step if up else 1.0 - 0.03 * step
        cand = np.clip(floor * k, 0, 255)
        if _de(panel, cand) >= SHOWCASE_SEAM_DE:
            out[seam:] = np.clip(out[seam:] * k, 0, 255)
            break
    else:
        out[seam:] = np.clip(out[seam:] * (1.36 if up else 0.64), 0, 255)
    return out.astype(np.uint8)


def _sc_feather(rgba):
    """Fade out a shadow the SOURCE PNG cut off at its own canvas edge.

    The supplied 6-pack runs to x=0 of its own file and the pixels there still carry alpha 26, so the
    shadow stops dead and every composite shows a hard vertical line beside the bottles. Ramp the alpha
    down over the outer band - but never touch a solid pixel, or the glass itself would go translucent.
    """
    import numpy as np
    a = rgba[:, :, 3].astype(np.float32)
    h, w = a.shape
    solid = a > SHOWCASE_SOLID_A
    band = max(4, int(round(min(h, w) * 0.05)))
    ramp = np.ones((h, w), np.float32)
    lin = np.linspace(0.0, 1.0, band, dtype=np.float32)
    for edge, prof in (("l", a[:, 0]), ("r", a[:, -1]), ("b", a[-1, :]), ("t", a[0, :])):
        if prof.max() <= 8:                     # this edge already fades to nothing - leave it alone
            continue
        if edge == "l":
            ramp[:, :band] = np.minimum(ramp[:, :band], lin[None, :])
        elif edge == "r":
            ramp[:, -band:] = np.minimum(ramp[:, -band:], lin[::-1][None, :])
        elif edge == "b":
            ramp[-band:, :] = np.minimum(ramp[-band:, :], lin[::-1][:, None])
        else:
            ramp[:band, :] = np.minimum(ramp[:band, :], lin[:, None])
    ramp[solid] = 1.0
    out = rgba.copy()
    out[:, :, 3] = np.clip(a * ramp, 0, 255).astype(rgba.dtype)
    return out


def _sc_back_base(rgba, base_off):
    """How far ABOVE the front-most footing the BACK-most bottle stands, in pixels.

    A 6-pack is a deep arrangement: its back row's bases sit 205 px higher than the front bottle's, 18%
    of the bottle height. Ignore that and the back row ends up above the wall/floor seam - standing on
    the wall - which is exactly what it looked like."""
    import numpy as np
    solid = rgba[:, :, 3] > SHOWCASE_SOLID_A
    cols = solid.any(0)
    if not cols.any():
        return 0
    last = solid.shape[0] - 1 - np.argmax(np.flipud(solid), 0)
    # Only columns that really pass through a bottle may speak for the back row. Taking the extreme
    # minimum let the outermost column - the one that grazes a shoulder and nothing else - stand in for
    # it: on this client's 6-pack that read 64% of the bottle height where the truth is nearer 20%, and
    # the back-row rule then shoved the whole group down onto the floor guard, 17% of the frame too low.
    height = solid.sum(0)
    real = cols & (height > max(3, int(0.15 * (base_off + 1))))
    if not real.any():
        real = cols
    return int(base_off - int(np.percentile(last[real], 5)))


def _sc_floor(bg):
    """The wall/surface seam in the plate - the strongest horizontal edge across the lower half."""
    import cv2, numpy as np
    H = bg.shape[0]
    g = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY).astype(np.float32)
    dd = abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)).mean(axis=1)
    lo, hi = int(H * 0.45), int(H * 0.92)
    return lo + int(np.argmax(dd[lo:hi]))


def compose_showcase(plate, pack_files, dest):
    """Stand the given packs on the plate and write `dest`. Every pack is scaled to the SAME bottle height
    - a 3-pack and a 6-pack hold the same bottle, so drawing one smaller would be a lie - and every base
    sits on one line. Raises on failure; the caller makes that a visible error rather than shipping a
    wrong picture."""
    import cv2, numpy as np
    bg = cv2.imread(str(plate), cv2.IMREAD_COLOR)
    if bg is None:
        raise ValueError("backdrop plate unreadable")
    H, W = bg.shape[:2]
    bg, seam = _sc_raise_floor(bg, int(H * SHOWCASE_MAX_SEAM))
    bg = _sc_separate_floor(bg, seam)
    th = int(H * (SHOWCASE_PAIR_H if len(pack_files) > 1 else SHOWCASE_HEIGHT))
    items, back_max = [], 0
    for f in pack_files:
        im = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)
        if im is None or im.ndim != 3 or im.shape[2] != 4:
            raise ValueError("pack image is not a transparent PNG: %s" % f)
        crop, base_off, cx, bh = _sc_prep(im)
        sc = float(th) / bh
        back_max = max(back_max, _sc_back_base(crop, base_off) * sc)
        crop = _sc_feather(crop)
        rs = cv2.resize(crop, (max(1, int(round(crop.shape[1] * sc))), max(1, int(round(crop.shape[0] * sc)))),
                        interpolation=cv2.INTER_AREA)
        items.append({"im": rs, "base": base_off * sc, "cx": cx * sc,
                      "wl": cx * sc, "wr": rs.shape[1] - cx * sc})
    # Aim at the CENTRE of the frame, not at an offset from the seam. Tying the placement to the seam
    # meant a plate that came back with a low horizon dragged the whole composition down with it, and the
    # products sat in the bottom half however the numbers were tuned. Centre first; the seam and the back
    # row only ever push the group DOWN from there, never up into the air.
    base_y = SHOWCASE_CENTRE * H + th / 2.0
    base_y = max(base_y, seam + H * SHOWCASE_BACK_GAP + back_max)      # back row must be on the floor
    base_y = int(min(base_y, H * SHOWCASE_FOOT_MAX))
    out = bg.astype(np.float32)
    # Lay out on the BOTTLES, not on the shadow: the gap the eye judges is the one between the glass.
    gap = SHOWCASE_GAP * W
    cur = (W - (sum(it["wl"] + it["wr"] for it in items) + gap * (len(items) - 1))) / 2.0
    for it in items:
        p = it["im"]
        px, py = int(round(cur + it["wl"] - it["cx"])), int(round(base_y - it["base"]))
        x0, y0 = max(0, px), max(0, py)
        x1, y1 = min(W, px + p.shape[1]), min(H, py + p.shape[0])
        if x1 > x0 and y1 > y0:
            sub = p[y0 - py:y1 - py, x0 - px:x1 - px].astype(np.float32)
            al = sub[:, :, 3:4] / 255.0
            out[y0:y1, x0:x1] = sub[:, :, :3] * al + out[y0:y1, x0:x1] * (1 - al)
        cur += it["wl"] + it["wr"] + gap
    if not cv2.imwrite(str(dest), np.clip(out, 0, 255).astype(np.uint8)):
        raise ValueError("could not write the composed showcase")
    return True


def showcase_pack_files(s, doc, d):
    """The local pack PNGs this scene composites, smaller group first. Empty when the scene is not a
    showcase or a named size was never uploaded - then the shot falls back to ordinary generation rather
    than standing the wrong pack on the shelf."""
    packs = _clean_packs(s.get("packs"))
    if not packs:
        return []
    out = []
    for n in sorted(packs)[:2]:            # two options is the most a frame reads at a glance
        u = _pack_url(doc, n)
        if not u:
            return []
        f = d / u
        if not f.exists():
            return []
        out.append(f)
    return out


# The plate is the only part of a showcase the AI still paints, so it has to be told to DESIGN a set,
# not to light a room. A generic "calm back wall" plus a palette led by the bottle's white plastic came
# back grey and beige - the user's own reference is a deep forest-green field with a cream arch, i.e. the
# brand's accent colour taken dark and saturated.
SHOWCASE_PLATE_PROMPT = (
    "A designed EMPTY studio SET for a premium product commercial, photographed straight on, in the style "
    "of a high-end brand campaign backdrop. %s "
    "Build the back wall from a DEEP, DARK, RICHLY SATURATED version of one of those brand colours, "
    "carrying a subtle tone-on-tone pattern in the same colour - botanical leaves or a soft organic "
    "texture, barely a shade lighter. Centre on it one tall panel with a softly rounded top in a warm "
    "pale cream, outlined by a thin brushed-metallic arc, so the products will read against it - and the "
    "panel must be a CLEARLY DIFFERENT tone from the surface it stands on, never two shades of the same "
    "colour, so its foot stays visible where the two meet. The lower "
    "TWO FIFTHS of the frame is a smooth surface in a muted tone that complements the wall, meeting it "
    "in one clean horizontal line. Soft even studio light, gentle "
    "falloff into the corners, quietly luxurious. "
    "The HORIZON - the line where the surface meets the wall - sits HIGH in the frame: the surface "
    "fills the bottom 40 percent of the picture and the wall only the top 60 percent. This matters: "
    "a low horizon leaves no room to stand anything on. "
    "The backdrop must be COLOURFUL and deliberately designed - NOT grey, NOT beige, NOT a plain neutral "
    "studio cyclorama, and never the same colour as the product itself. "
    "ABSOLUTELY NO products, NO bottles, NO jars, NO boxes, NO people, NO hands, NO real plants, NO "
    "props, NO text and NO logos - the set is completely EMPTY, an unoccupied background plate, and the "
    "middle of the frame is clear.")

_HUE_NAMES = ((8, "red"), (20, "orange"), (33, "golden yellow"), (45, "yellow-green"), (85, "green"),
              (100, "teal"), (128, "blue"), (150, "indigo"), (165, "purple"), (175, "magenta"), (180, "red"))


def _hue_name(h):
    for lim, name in _HUE_NAMES:
        if h <= lim:
            return name
    return "red"


def showcase_plate_path(d):
    """ONE backdrop plate per project, reused by every showcase. The user's own reference set is three
    pictures sharing a single backdrop with different pack counts, which is also why this costs one
    generation for the whole video instead of one per offer shot."""
    return d / "refs" / "showcase_plate.png"


def _showcase_palette(pack_file):
    """A sentence naming the product's BRAND colours - the saturated ones.

    Ranking the k-means clusters by pixel count put the bottle's white plastic first (33.7% + 31.4% of the
    artwork) and the actual brand yellow and green third and fourth, so the model was told the product was
    grey and built a grey set to match. Split on saturation instead: the neutrals are the packaging, the
    saturated clusters are the brand."""
    import cv2, numpy as np
    im = cv2.imread(str(pack_file), cv2.IMREAD_UNCHANGED)
    if im is None or im.ndim != 3 or im.shape[2] != 4:
        return "The product is a white supplement bottle with a warm yellow label."
    px = im[:, :, :3][im[:, :, 3] > 200].reshape(-1, 3).astype(np.float32)
    if px.shape[0] < 256:
        return "The product is a white supplement bottle with a warm yellow label."
    idx = np.random.RandomState(0).choice(px.shape[0], min(20000, px.shape[0]), replace=False)
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    _, lab, cen = cv2.kmeans(px[idx], 6, None, crit, 3, cv2.KMEANS_PP_CENTERS)
    cnt = np.bincount(lab.flatten(), minlength=6).astype(float)
    hsv = cv2.cvtColor(cen.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_BGR2HSV).reshape(-1, 3)
    brand, neutral = [], []
    for i in np.argsort(-cnt):
        hexv = "#%02X%02X%02X" % (int(cen[i][2]), int(cen[i][1]), int(cen[i][0]))
        (brand if hsv[i][1] >= 60 else neutral).append((hexv, _hue_name(int(hsv[i][0])), hsv[i][2]))
    seen, uniq = set(), []                           # three shades of the same yellow is not a palette:
    for h, nm, v in brand:                           # keep one swatch per hue so the accent survives
        if nm in seen:
            continue
        seen.add(nm); uniq.append((h, nm, v))
    brand = uniq
    if not brand:                                    # a genuinely colourless product
        return "The product packaging is neutral - white and grey - so the set must supply all the colour."
    body = ("light" if (neutral and neutral[0][2] > 170) else "dark") if neutral else "light"
    return ("The product is a %s bottle, and its BRAND colours - the ones the set must be built around - "
            "are %s." % (body, ", ".join("%s (%s)" % (h, n) for h, n, _ in brand[:3])))


def showcase_plate_prompt(s, doc, d):
    """The prompt that replaces the scene's own when the packs will be composited: paint the SET only."""
    files = showcase_pack_files(s, doc, d)
    return SHOWCASE_PLATE_PROMPT % (_showcase_palette(files[0]) if files else "a supplement bottle")


def _effective_product_url(s, doc):
    """Product image to attach for this scene. A TESTIMONIAL grid always shows the product (every person holds it),
    so fall back to the default pack even when none was explicitly chosen."""
    u = _scene_product_url(s, doc)
    if u:
        return u
    if s.get("testimonial"):
        return _default_product_url(doc)
    return None

# Things that carry readable words when they are in a shot. When one is named, the image prompt says which
# language that writing is in (see assemble_image_prompt); otherwise the model letters it in English.
_TEXT_PROPS = re.compile(r"\b(screen|laptop|phone|smartphone|tablet|monitor|calendar|label|labels|sign|signage|poster|"
                         r"document|paper|paperwork|receipt|till slip|bill|invoice|board|whiteboard|packaging|carton|"
                         r"notification|button|web ?page|website|newspaper|letter|form|chart|graph|banner|menu|"
                         r"price tag|ticket|display|certificate|report|checkout|order page|offer page)\b", re.I)


def assemble_image_prompt(s, doc, d):
    """SINGLE SOURCE OF TRUTH for the final image prompt text — used by both the real generation
    (_submit_image) and the dry-run preview, so what the user previews is byte-identical to what gets
    sent. No network / no Cloudinary. Returns (prompt, cont_rel, info): `cont_rel` is the continuity
    frame to attach (or None); `info` is a human-readable list of which reference images would attach."""
    all_chars = scene_characters(s, doc)
    # The "In scene:" chips (scene.cast) control who is face-locked in BOTH normal AND raw mode. BUT a face is
    # NEVER attached to a shot with no person in it (scene_face_chars → []), so a reference face can't be grafted
    # onto an object/product/anatomy ("head on belly"). Remove a chip to drop someone from a scene that has people.
    chars_ref = scene_face_chars(s, doc)                                                     # cast WITH a photo, only if the shot has a person
    has_people = bool(chars_ref) or _shot_has_people(s, doc)
    chars_desc = [] if (s.get("no_cast") or not has_people) else [c for c in all_chars if not char_urls(c)]   # photo-less cast: description only in normal mode + when people are present
    # A card replaces the shot entirely - build it and stop here. UNLESS the scene is RAW: "My prompt"
    # means the user's words go through untouched, and a card that overrode them made the toggle a lie -
    # whatever they typed, the word-art came back.
    if (s.get("card") or "").strip() and not s.get("no_cast"):
        _cs = _card_style_ref(s, doc)
        return (_card_prompt(s, doc, bool(_cs)), None,
                ["Full-screen card — the picture IS the words" + ("; matched to the first card" if _cs else "")])
    # A SHOWCASE is composited, not drawn: the model paints an empty set and the client's own pack photo
    # is stood on it afterwards. So the prompt it gets is the plate prompt, and none of the staging,
    # cast, product or no-text layers apply - every one of them would put something on the set.
    _sc_files = showcase_pack_files(s, doc, d)
    if _sc_files and not s.get("pure"):
        _have = showcase_plate_path(d).exists()
        _cnt = " + ".join(str(x) for x in _clean_packs(s.get("packs")))
        return (showcase_plate_prompt(s, doc, d), None,
                ["Product showcase - your %s pack image is composited on the set, so the count and the "
                 "label are exact" % _cnt,
                 ("Reusing this project's backdrop plate - no image credits" if _have
                  else "Painting this project's backdrop plate (once); later showcases reuse it")])
    prompt = build_image_prompt(s, doc.get("audience"), chars_ref, chars_desc,
                                vsl=not is_youtube(doc))
    # Say what the SHOWCASE references are for. Attaching them is not enough - without this the model has no
    # idea the second pack is a second option rather than a redesign, or that the earlier shot is there for
    # its backdrop and not its contents. Skipped in PURE mode, which is the user's prompt and nothing else.
    if not s.get("pure"):
        _sc = []
        if (s.get("packs") or []):
            # The showcase constraints have to live HERE, not only in the director's guidance. The director
            # described the shot correctly and the picture still came back as a woman holding a bottle in a
            # bedroom: the staging stack's own "this is a REAL photograph" layer simply out-shouted it. A
            # rule that never reaches the model is not a rule.
            _pk = s.get("packs") or []
            # Name the COUNTS outright. Image models are weak at exact quantities, and "as many as
            # described" buried in a long prompt was giving four-ish and five-ish groups even with a real
            # 3-pack and 6-pack photo attached.
            _cnt = (("Show EXACTLY %d bottles, no more and no fewer - count them." % _pk[0]) if len(_pk) == 1
                    else ("Show EXACTLY two groups: one of EXACTLY %s bottles and one of EXACTLY %s bottles, "
                          "clearly separated by a gap so each can be counted at a glance. Do not add, remove "
                          "or merge bottles." % (_pk[0], _pk[1])))
            _sc.append("THIS SHOT IS A PRODUCT SHOWCASE, not a lifestyle scene: NO people, NO faces, NO "
                       "hands, NO home or room setting and no household clutter - only the packs on a clean "
                       "surface against an uncluttered backdrop, lit like a commercial product photograph. "
                       + _cnt +
                       " Keep the described area of empty space genuinely EMPTY, and put NO price, NO "
                       "numbers, NO currency, NO percentage and NO promotional wording in the image.")
        if len(s.get("packs") or []) > 1:
            _sc.append("TWO of the attached references are the two PACK SIZES this line offers: show BOTH "
                       "groups side by side, each with exactly the number of units its own reference shows, "
                       "and do not merge them into a single pile.")
        if _showcase_style_ref(s, doc):
            _sc.append("One attached reference is a STYLE reference from an earlier showcase: match its "
                       "backdrop, surface, lighting and mood so the two shots belong together - but do NOT "
                       "copy its contents or its number of units.")
        if _sc:
            prompt = prompt + " " + " ".join(_sc)
    if s.get("pure"):   # PURE: prompt + camera + ONLY the references you explicitly attached (no auto layers, no continuity)
        bits = []
        if chars_ref: bits.append("cast: " + ", ".join(c.get("name", "?") for c in chars_ref))
        if _scene_product_url(s, doc): bits.append("product")
        if scene_ingredient_refs(s, doc): bits.append("ingredients")
        if s.get("refs"): bits.append(f"{len(s.get('refs'))} attached image(s)")
        info = ["PURE mode — your prompt + camera" + (" + " + " + ".join(bits) if bits else "; no references") + " (no style/audience/no-text/continuity)"]
        if s.get("split"):
            info.append("Split composition")
        return prompt, None, info
    info = []
    if s.get("testimonial"):
        _tn = max(4, min(int(s.get("testimonial_n") or 8), 16)) if str(s.get("testimonial_n") or 8).isdigit() else 8
        _c, _r = _grid_dims(_tn)
        info.append(f"Testimonial grid — {_c}×{_r} ({_tn} cells) of separate real-customer selfies holding the product (auto-composed)")
    if s.get("no_cast"):
        n = len(s.get("refs") or [])
        bits = ["your prompt (verbatim)"]
        if chars_ref:
            bits.append("face-locked: " + ", ".join(c.get("name", "?") for c in chars_ref))
        bits.append("Target Audience reminder (location / age / excluded looks)")
        if n:
            bits.append(f"{n} reference image(s) you attached")
        info.append("RAW mode — " + " + ".join(bits))
    else:
        if chars_ref:
            _fl = []
            for c in chars_ref:
                nm = c.get("name", "?")
                if c.get("transforms") and char_end_urls(c):
                    _fl.append(f"{nm} [transform: {_char_state(c, s)}]")
                else:
                    _fl.append(nm)
            info.append("Face-locked (reference photo): " + ", ".join(_fl))
        if chars_desc:
            info.append("Kept consistent by description: " + ", ".join(c.get("name", "?") for c in chars_desc))
        # cast chip(s) set but NOT attached because this shot has no person → avoids grafting a face onto an object
        _dropped = [c.get("name", "?") for c in all_chars if char_urls(c)] if not chars_ref else []
        if _dropped:
            info.append("In-scene cast NOT attached (no person in this shot): " + ", ".join(_dropped))
        if s.get("refs"):
            info.append(f"{len(s.get('refs'))} scene reference image(s)")
    # scene-continuity: if this scene continues an earlier one (same place + people) whose image exists,
    # feed that frame as an extra reference. Skipped entirely in raw mode.
    cont_rel = None
    if not s.get("no_cast") and not s.get("testimonial"):   # a testimonial grid is standalone → no continuity frame
        cont = _cont_source(s, doc)
        if cont is not None:
            rel = (cont.get("image") or {}).get("approved_file") or (cont.get("image") or {}).get("file")
            if rel and (d / rel).exists():
                cont_rel = rel
                prompt += ("\nOne of the reference images is a frame from the PREVIOUS moment in this SAME "
                           "scene — keep the same location, background, lighting and the same people's "
                           "appearance for visual continuity; only the action and framing change as described."
                           "\nThis frame must NOT come out looking like a copy of that reference. It is a "
                           "DIFFERENT SHOT of the same place: the camera has moved to a clearly different "
                           "position, distance or angle, and what fills the frame is what THIS shot describes, "
                           "not what the reference showed. Reproducing the reference with small changes is a "
                           "failure — the viewer sees the same picture twice and thinks the video is stuck.")
                info.append(f"Continuity frame from scene {cont.get('id')}")
    # INGREDIENTS: real ingredient reference images attached → depict each exactly as its reference, and ONLY these.
    ing_ref = scene_ingredient_refs(s, doc)
    if ing_ref:
        ing_names = ", ".join(i.get("name", "?") for i in ing_ref)
        if not s.get("no_cast"):
            prompt += (f"\nSome of the reference images are the product's INGREDIENTS: {ing_names}. Depict each ingredient "
                       f"EXACTLY as in its own reference image (same real ingredient, colour and form) — show ONLY these "
                       f"ingredients, do NOT invent or add other/unnamed ingredients.")
        info.append("Ingredient reference(s): " + ing_names)
    # PRODUCT: this scene is flagged to show the product → attach the product image (i2i) and demand an
    # exact, label-accurate depiction (this is what makes clean mockup / product-in-use shots).
    prod_url = _effective_product_url(s, doc)
    if prod_url:
        if not s.get("no_cast"):   # normal mode → add the label-accuracy wording; RAW stays verbatim (image still attaches as a reference)
            plabel = ((doc.get("product") or {}).get("names") or {}).get(prod_url, "").strip()
            pack = f" (this is the '{plabel}' pack)" if plabel else ""
            prompt += ("\nOne of the reference images is the PRODUCT" + pack + ". Use that reference ONLY for the product's "
                       "label, wording, colours and shape — copy the SAME bottle/package shape, label, wording, colours and "
                       "the SAME number of bottles/units; do NOT redesign, rename or restyle it, and do NOT add or remove "
                       "bottles. Do NOT copy the reference's SIZE, framing or studio lighting. Render the product at a "
                       "BELIEVABLE real-world size and position for THIS scene (held in a hand, on a surface, or in use) — "
                       "never a giant, oversized or floating hero. Give it a NATURAL, everyday look: lit by the SAME ordinary "
                       "light as the rest of the scene, with soft real shadows and only gentle, realistic highlights — NOT "
                       "glossy, NOT shiny/plasticky, NOT a studio product render; it should look like a real bottle sitting in "
                       "the room, with a matching contact shadow so it isn't pasted/cut-out on top. It must still be in SHARP "
                       "FOCUS with its label crisp and clearly readable (natural, NOT blurry or out of focus). The 'No text' rule above "
                       "applies ONLY to added captions/watermarks — the product's OWN printed label and text MUST stay exactly "
                       "as in the reference.")
            _pf = product_form(doc, d)
            if _pf:
                prompt += (" The product is %s - that very container, as in the reference. Keep it that kind of "
                           "container in this scene, whatever word the script uses for it." % _pf)
        info.append("Product reference" + (" (raw: image only)" if s.get("no_cast") else ""))
    # Writing in shot comes back in English unless told otherwise. VSL only; not on a scientific render (a
    # diagram must carry no words at all, and inviting "writing" onto it would invite labels).
    if not is_youtube(doc) and not s.get("no_cast") and (s.get("style") or "natural") != "scientific":
        _tl = country_language(doc.get("audience"))
        if _tl and _tl != "English" and _TEXT_PROPS.search(prompt) and ("in %s" % _tl) not in prompt:
            prompt += (" Any writing that can be read in the picture - on a screen, a label, a sign, a document, a "
                       "calendar, a receipt, a card, a notification or packaging - is in %s." % _tl)
            info.append("On-image text in " + _tl)
    # USER-ATTACHED scene references: they ARE sent as i2i inputs, but with no wording the model often ignores an
    # unexplained image → tell it these are references to honour (this is why a manually-added reference "wasn't used").
    if s.get("refs"):
        prompt += ("\nAdditional reference image(s) were attached for THIS shot — treat them as accurate VISUAL REFERENCES: "
                   "faithfully reproduce the specific object(s), place, layout, product or style they show, and keep them "
                   "consistent in this image (they are there to be USED, not ignored or treated as mere inspiration).")
    if s.get("split"):
        _low = (s.get("prompt") or "").lower()
        if re.search(r"(?<![a-z])(?:top|bottom)[ -](?:left|right)\b[^:\n]{0,40}:", _low):
            n = "four (2x2)"
        elif re.search(_panel_mark_re("middle"), _low):
            n = "three"
        else:
            n = "two"
        info.append(f"Split composition — {n} panels (no divider); camera framing disabled")
    return prompt, cont_rel, info

def _cover_crop(im, cw, ch):
    """Scale + centre-crop `im` to exactly cw×ch (fills the box, no letterbox)."""
    im = im.convert("RGB")
    scale = max(cw / im.width, ch / im.height)
    nw, nh = max(cw, round(im.width * scale)), max(ch, round(im.height * scale))
    im = im.resize((nw, nh))
    left, top = (nw - cw) // 2, (nh - ch) // 2
    return im.crop((left, top, left + cw, top + ch))


def _ingredient_panels(ings, d):
    """One PIL image per PANEL. A split ingredient (name has '/', k parts) whose reference image is itself a
    k-way strip is SLICED back into its k parts, so e.g. pepper + Chromium/Zinc/B → 4 panels."""
    panels = []
    for ing in ings:
        u = next((x for x in (ing.get("urls") or []) if x), None)
        if not u or not (d / u).exists():
            continue
        try:
            im = Image.open(d / u).convert("RGB")
        except Exception:
            continue
        # A "/"-joined name (e.g. "Chromium/Zinc/B Vitamins") declares its components — its reference image is a
        # k-panel strip, so slice it back into k equal parts. "/" is the explicit component delimiter in the UI,
        # so this does not depend on the Split toggle being on.
        parts = [p for p in (ing.get("name") or "").split("/") if p.strip()]
        k = len(parts) if len(parts) >= 2 else 1
        if k >= 2:
            sw = im.width // k
            for j in range(k):
                x0 = j * sw
                x1 = im.width if j == k - 1 else (j + 1) * sw
                panels.append(im.crop((x0, 0, x1, im.height)))
        else:
            panels.append(im)
    return panels


def _compose_ingredient_image(panels, dest):
    """Lay panels out as N EQUAL side-by-side columns, each cover-filled (cropped, NO white letterbox)."""
    try:
        panels = [p for p in panels if p is not None]
        if not panels:
            return False
        W, H = 2560, 1440
        n = len(panels)
        canvas = Image.new("RGB", (W, H), (10, 15, 12))
        x = 0
        for i, im in enumerate(panels):
            cw = (W - x) if i == n - 1 else (round(W * (i + 1) / n) - round(W * i / n))
            canvas.paste(_cover_crop(im, cw, H), (x, 0))
            x += cw
        canvas.save(dest, "PNG")
        return True
    except Exception:
        return False


def _ingredient_direct_image(s, doc, d, safe):
    """For an ingredient-only shot, build the image straight from the ingredients' OWN reference images
    (no AI, no cost): N equal side-by-side panels (a split ingredient contributes its sub-parts), or the
    single image for a 'use directly' ingredient. Returns a local 'images/…png' rel path or None → normal
    generation. Skipped when the scene shows people or a product (those are real generated shots)."""
    if s.get("pure"):
        # PURE = "use my exact prompt": never silently replace it with an auto ingredient montage.
        # The scene proceeds to real generation; any ingredient images still attach as i2i references
        # (exactly what the PURE preview promises). Remove the ingredient from the scene to drop it entirely.
        return None
    if s.get("testimonial"):          # a testimonial grid is a real generated shot, never an ingredient montage
        return None
    if s.get("product"):
        return None
    # Only real PEOPLE block the montage — cast assigned to the shot, or a director-set ordinary person.
    # (Do NOT scan the prompt text: an ingredient line like "their ground spice" falsely reads as a person and
    #  the montage ignores the written prompt anyway.)
    if scene_face_chars(s, doc) or s.get("generic"):
        return None
    ings = scene_ingredient_refs(s, doc)                      # only ingredients that carry an image
    panels = _ingredient_panels(ings, d)
    if not panels:
        return None
    # RAW ("My prompt") + an ingredient selected = "just drop this ingredient's existing image in, no AI".
    # So in RAW mode a single ingredient is ALSO used directly (like 'use directly'), no regeneration.
    if len(panels) == 1 and not (s.get("no_cast") or (ings and ings[0].get("use_directly"))):
        return None                                          # single, non-direct ingredient → generate a fresh/varied look
    (d / "images").mkdir(parents=True, exist_ok=True)
    ver = len(s["image"].get("versions", [])) + 1
    out = f"images/sc_{s.get('uid', 'x')}_v{ver}.png"
    return out if _compose_ingredient_image(panels, d / out) else None


def _submit_image(s, doc, d, safe):
    # Ingredient-combo (or 'use directly') shot → compose from the ingredients' own reference images, no AI.
    try:
        direct = _ingredient_direct_image(s, doc, d, safe)
    except Exception:
        direct = None
    if direct:
        img = s["image"]
        img.setdefault("versions", []).append(direct)
        vm = img.setdefault("version_models", [])
        while len(vm) < len(img["versions"]) - 1:
            vm.append(s.get("model") or IMAGE_MODEL)
        vm.append(s.get("model") or IMAGE_MODEL)
        img["current"] = len(img["versions"]) - 1
        img.update(status="ready", file=direct, error=None, taskId=None)
        return
    # SHOWCASE with the plate already painted -> compose it here and now, no AI and no credits.
    _sc_files = [] if s.get("pure") else showcase_pack_files(s, doc, d)
    if _sc_files and showcase_plate_path(d).exists():
        img = s["image"]
        (d / "images").mkdir(parents=True, exist_ok=True)
        rel = "images/sc_%s_v%d.png" % (s.get("uid", "x"), len(img.get("versions", [])) + 1)
        try:
            compose_showcase(showcase_plate_path(d), _sc_files, d / rel)
        except Exception as e:
            # Fail LOUD. A showcase that quietly falls back to a drawn picture is exactly the bug this
            # replaces - the wrong number of bottles, shipped without anyone noticing.
            img.update(status="error", error="showcase compose failed: %s" % e)
            return
        img.setdefault("versions", []).append(rel)
        vm = img.setdefault("version_models", [])
        while len(vm) < len(img["versions"]) - 1:
            vm.append(s.get("model") or IMAGE_MODEL)
        vm.append("composed")
        img["current"] = len(img["versions"]) - 1
        img.update(status="ready", file=rel, error=None, taskId=None)
        return
    if not s.get("prompt") and not s.get("testimonial"):   # a testimonial grid builds its own prompt (no written prompt needed)
        s["image"].update(status="error", error="no prompt")
        return
    family = s.get("model") or IMAGE_MODEL
    if family not in IMAGE_MODELS_READY:
        family = IMAGE_MODEL
    s["image"]["pending_model"] = family   # remember which model THIS generation uses → recorded per version on completion
    pure = bool(s.get("pure"))             # PURE → prompt+camera + ONLY the refs the user explicitly attached (no continuity)
    chars_ref = scene_face_chars(s, doc)   # In-scene chips (honoured in pure too), only when the shot has a person
    prompt, cont_rel, _info = assemble_image_prompt(s, doc, d)   # same text the preview shows
    if pure:
        cont_rel = None                    # continuity is AUTO (not user-attached) → never in pure
    try:
        # scene refs AND every character image are stored locally now; upload each to Cloudinary here
        refs = resolve_refs(d, safe, s.get("refs")) + resolve_refs(d, safe, [u for c in chars_ref for u in char_urls_for(c, s)])
    except ValueError as e:
        s["image"].update(status="error", error=str(e))
        return
    ing_urls = [u for i in scene_ingredient_refs(s, doc) for u in (i.get("urls") or []) if u]   # ingredient reference images (i2i)
    # HOW MANY reference pictures go in decides the LAYOUT that comes out: hand nano-banana two and it
    # lays them side by side, three and it draws three panels - however plainly the prompt asks for one
    # continuous shot. On a scene that is not a panel composition, one reference is the most it can take.
    if ing_urls and not is_youtube(doc) and not (s.get("split") or _prompt_names_panels(s.get("prompt"))):
        ing_urls = ing_urls[:1]
    if ing_urls:
        try:
            refs = refs + resolve_refs(d, safe, ing_urls)
        except ValueError as _qe:
            quiet(_qe, "_submit_image")
    prod_url = _effective_product_url(s, doc)   # the ONE PRODUCT image (chosen pack, or default for a testimonial grid) as an i2i input
    if prod_url:
        try:
            refs = refs + resolve_refs(d, safe, [prod_url])
        except ValueError as _qe:
            quiet(_qe, "_submit_image")
    if (s.get("card") or "").strip() and not s.get("no_cast"):   # a card is pure design: no cast, no product, no continuity
        _cs = _card_style_ref(s, doc)
        refs = []
        if _cs:
            try:
                refs = resolve_refs(d, safe, [_cs])
            except ValueError:
                refs = []
    if _sc_files:                    # painting an EMPTY set: every reference here would populate it
        refs = []
        s["image"]["compose_packs"] = True                 # compose once the plate lands
    _sc_packs = [] if _sc_files else [u for u in _showcase_pack_urls(s, doc) if u != prod_url]
    if _sc_packs:
        try:
            refs = refs + resolve_refs(d, safe, _sc_packs)
        except ValueError as _qe:
            quiet(_qe, "_submit_image")
    _sc_style = _showcase_style_ref(s, doc)      # later showcases match the first one's backdrop
    if _sc_style:
        try:
            refs = refs + resolve_refs(d, safe, [_sc_style])
        except ValueError as _qe:
            quiet(_qe, "_submit_image")
    if cont_rel:                                                 # continuity frame is optional — never fail the gen for it
        try:
            refs = refs + resolve_refs(d, safe, [cont_rel])
        except ValueError as _qe:
            quiet(_qe, "_submit_image")
    try:
        model_id, inp = build_kie_image_request(family, prompt, refs)
        tid, err = kie_create(model_id, inp)
        if tid:
            s["image"].update(status="generating", taskId=tid, error=None, gen_started=time.time())
        else:
            s["image"].update(status="error", error=err)
    except Exception as e:                                  # any unexpected failure → visible error, never a silent 500
        s["image"].update(status="error", error=f"image submit failed: {e}")

# ---- a failed image tries again by itself ---------------------------------------------------------
# Forty-five images went out and two came back broken: one timed out, one was refused by Google's
# content filter on a prompt about a damp patch on a ceiling. Both are ordinary and both used to sit
# there red until somebody noticed. An unattended run cannot rely on somebody noticing.
IMG_RETRIES = 2            # one more go, then one more with the wording changed

_ERR_BLOCKED = ("prohibited", "policy", "filtered", "safety", "blocked", "content violat",
                "flagged", "not allowed")
_ERR_FATAL = ("credit", "balance", "insufficient", "quota", "unauthor", "api key", "invalid key",
              "forbidden", "expired")


def _img_error_kind(err):
    """Blocked -> the words have to change. Fatal -> trying again cannot help. Otherwise transient."""
    e = (err or "").lower()
    if any(k in e for k in _ERR_FATAL):
        return "fatal"
    if any(k in e for k in _ERR_BLOCKED):
        return "blocked"
    return "transient"


REWORD_SYSTEM = (
    "An image generator refused to draw a shot because its safety filter objected to the wording. The "
    "shot itself is harmless - it is one frame of an explainer video. Rewrite the description so the "
    "filter has nothing to catch on.\n"
    "Keep the SAME shot: the same place, the same objects, the same people doing the same thing, the "
    "same framing and the same moment. Change only the words most likely to have tripped a filter - "
    "anything that reads as damage, decay, injury, bodily fluid, a stain or a substance when read out "
    "of context - and say the same thing plainly instead. A brown stain becomes a damp patch; paint "
    "bubbling becomes paint lifting.\n"
    "Do NOT describe an art style, a medium, colours of the drawing, camera gear or quality words. The "
    "style is added separately and your words would fight it.\n"
    "Reply with ONLY a JSON object: {\"prompt\":\"the rewritten shot\"}")


def _reword_blocked_prompt(prompt, vo=""):
    """The same shot, said in words a safety filter will not object to. Empty string if it fails."""
    if not (prompt or "").strip():
        return ""
    try:
        out = _ask_json(REWORD_SYSTEM,
                        "WHAT THE NARRATION SAYS HERE: %s\n\nTHE SHOT THAT WAS REFUSED:\n%s"
                        % (vo or "(nothing)", prompt),
                        want=lambda v: isinstance(v.get("prompt"), str) and len(v["prompt"].split()) >= 8)
    except Exception:
        return ""
    return " ".join(out["prompt"].split())[:1200]


CARD_TEXT_RETRIES = 2            # a misspelt card is regenerated this many times on its own before a note is left
CARD_READ_SYSTEM = ("You read the LARGE lettering in a 3D word-art graphic. Reply with ONLY the words you can "
                    "read, in reading order, exactly as lettered (keep accents if you can see them), on one line. "
                    "No commentary, no quotes.")


def _card_text_norm(t):
    """Accents, case, spaces and punctuation aside - so a right card matches and a wrong LETTER does not."""
    import unicodedata
    t = unicodedata.normalize("NFKD", str(t or ""))
    return "".join(ch for ch in t if ch.isalnum()).lower()


def _card_text_check(project, sid, rel, expected, vidx):
    """Read the lettering the model drew on a card; when it is not the phrase asked for, send the card round
    again on its own (up to CARD_TEXT_RETRIES). Runs in a worker after the picture has landed; it re-reads
    the document under the project lock and does nothing if the scene has moved on since."""
    try:
        d, safe = proj_dir(project)
        p = d / rel
        if not p.exists():
            return
        seen = (_claude_vision(CARD_READ_SYSTEM, "Read the words.", str(p)) or "").strip()
        ok = _card_text_norm(seen) == _card_text_norm(expected)
        with _project_lock(project):
            doc = load_doc(project)
            if doc is None:
                return
            s = next((x for x in doc.get("scenes") or [] if x.get("id") == sid), None)
            if not s:
                return
            img = s.get("image") or {}
            vers = img.get("versions") or []
            if not vers or vidx >= len(vers) or vers[vidx] != rel or img.get("status") != "ready":
                return                                   # a newer version, a reset or a regeneration got there first
            if ok:
                img["card_ok"] = rel
                save_doc(project, doc)
                return
            n = int(img.get("card_retries") or 0)
            if n >= CARD_TEXT_RETRIES or s.get("approved"):
                old = (s.get("note") or "").strip()
                s["note"] = (old + ("\n" if old else "") +
                             "⚠ Card lettering came back as '%s' (wanted '%s') after %d tries - check it."
                             % (seen[:60], expected, n + 1))
                save_doc(project, doc)
                return
            img["card_retries"] = n + 1
            img.update(status="queued", error=None, taskId=None,
                       last_error="card lettering read as '%s' - regenerating" % seen[:80])
            _drain_image_queue(doc, d, safe)             # go now, not at the next poll
            save_doc(project, doc)
    except Exception as e:
        quiet(e, "_card_text_check")


AUTO_QA_RETRIES = 1              # a plainly wrong picture is regenerated this many times by itself, then left with a note
_AUTO_QA_SEM = threading.BoundedSemaphore(3)   # at most this many vision checks at once (each is a CLI process)


def _auto_qa_wanted(doc, s):
    """Which landed pictures the automatic reviewer looks at: a sales video's ordinary scenes. A card has its
    own lettering check, a showcase is composited, a testimonial grid is built, an approved scene is the
    user's word; a project can switch the whole thing off with auto_qa=false."""
    if is_youtube(doc) or doc.get("auto_qa") is False:
        return False
    if s.get("approved") or s.get("testimonial") or s.get("packs") or (s.get("card") or "").strip():
        return False
    return True


def _auto_qa_check(project, sid, rel, vidx):
    """Judge the picture that just landed for scene `sid`; on a high-confidence fault apply the reviewer's
    corrected prompt (unless the prompt is the user's own RAW/PURE words) and send the scene round once more.
    Runs in a worker after the picture is saved; re-reads the document under the project lock and does nothing
    if the scene has moved on since. Never raises."""
    try:
        with _AUTO_QA_SEM:
            d, safe = proj_dir(project)
            p = d / rel
            if not p.exists():
                return
            doc = load_doc(project)
            if doc is None:
                return
            s = next((x for x in doc.get("scenes") or [] if x.get("id") == sid), None)
            if not s or not _auto_qa_wanted(doc, s):
                return
            img = s.get("image") or {}
            vers = img.get("versions") or []
            if not vers or vidx >= len(vers) or vers[vidx] != rel:
                return
            issue = _qa_judge(_qa_context(doc, d), s, doc, str(p))
        with _project_lock(project):
            doc = load_doc(project)
            if doc is None:
                return
            s = next((x for x in doc.get("scenes") or [] if x.get("id") == sid), None)
            if not s or not _auto_qa_wanted(doc, s):
                return
            img = s.get("image") or {}
            vers = img.get("versions") or []
            if not vers or vidx >= len(vers) or vers[vidx] != rel or img.get("status") != "ready":
                return                                   # a newer version, a reset or a regeneration got there first
            prev = "\n".join(ln for ln in (s.get("note") or "").strip().splitlines() if not ln.startswith("⚠ QA:"))
            n = int(img.get("qa_retries") or 0)
            if issue is None:
                img["qa_ok"] = rel
                if n:
                    s["note"] = prev                     # the retry passed: the earlier QA line comes off
                    img["qa_retries"] = 0                # ...and a later bad roll may be retried once again
                save_doc(project, doc)
                return
            if not issue.get("regenerate") or n >= AUTO_QA_RETRIES:
                s["note"] = ("⚠ QA: " + issue["issue"]
                             + (" (still there after %d automatic retry - check it)" % n if n else "")
                             + ("\n" + prev if prev else "")).strip()
                save_doc(project, doc)
                return
            fp = (issue.get("fixed_prompt") or "").strip()
            if fp and not s.get("pure") and not s.get("no_cast") and fp != (s.get("prompt") or "").strip():
                s["prompt"] = fp                         # the reviewer's corrected prompt, as Check Images applies it
            img["qa_retries"] = n + 1
            s["note"] = ("⚠ QA: " + issue["issue"] + " - regenerated once by itself" + ("\n" + prev if prev else "")).strip()
            img.update(status="queued", error=None, taskId=None,
                       last_error="QA: %s - regenerating" % issue["issue"][:80])
            _drain_image_queue(doc, d, safe)             # go now, not at the next poll
            save_doc(project, doc)
    except Exception as e:
        quiet(e, "_auto_qa_check")


def _image_failed(s, doc, err, log=None):
    """Send a failed image round again instead of leaving it red. Returns True if it was requeued.

    A content refusal is not retried as-is: the filter is reading the same words and will say the same
    thing, so that attempt would cost a credit to learn nothing. Those go straight to a reword. Anything
    that merely broke - a timeout, a 5xx, a dropped connection - gets one more go exactly as written.
    """
    img = s.setdefault("image", {})
    n = int(img.get("retries") or 0)
    kind = _img_error_kind(err)
    if kind == "fatal" or n >= IMG_RETRIES:
        img.update(status="error", error=err)
        return False
    img["retries"] = n + 1
    if kind == "blocked" or n + 1 >= IMG_RETRIES:
        new = _reword_blocked_prompt(s.get("prompt") or "", s.get("vo") or "")
        if not new:
            img.update(status="error", error=err)
            return False
        img["reworded_from"] = s.get("prompt")
        s["prompt"] = new
        if log:
            log("Scene %s was refused, so it was reworded and sent again." % s.get("id"))
    elif log:
        log("Scene %s failed (%s) - trying again." % (s.get("id"), str(err)[:70]))
    img.update(status="queued", error=None, taskId=None, last_error=str(err)[:300])
    return True


def _drain_image_queue(doc, d, safe):
    """Submit queued image jobs up to IMG_CONCURRENCY. Returns True if anything was submitted."""
    gen = sum(1 for s in doc["scenes"] if s["image"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= IMG_CONCURRENCY:
            break
        if s["image"]["status"] != "queued":
            continue
        # A continuation shot is drawn FROM the frame it continues, so submitting it before that frame
        # exists throws the continuity away in silence - and six go out at once, so a run of shots that
        # must share one cutaway would each invent their own. Hold it back; the next drain picks it up.
        # If the source has failed or is not coming, go ahead - a frame without continuity beats none.
        cont = _cont_source(s, doc)
        if cont is not None:
            ci = cont.get("image") or {}
            if not (ci.get("approved_file") or ci.get("file")) and ci.get("status") in ("queued", "generating"):
                continue
        _submit_image(s, doc, d, safe)
        changed = True
        if s["image"]["status"] == "generating":
            gen += 1
    return changed

def _submit_video(s, d, safe, doc):
    # Never let an exception escape: any failure becomes a VISIBLE "error" on the video card with the
    # reason. Otherwise a raise here (missing frame file after import, Cloudinary/Kie network error…)
    # would 500 the request and the UI would show nothing at all ("clicked, nothing happened").
    try:
        frame = s["image"].get("approved_file") or s["image"].get("file")
        if not frame:
            s["video"].update(status="error", error="approve an image version first")
            return
        if not (d / frame).exists():                       # e.g. an imported project whose image file didn't come across
            s["video"].update(status="error", error="image file missing on disk — re-generate this image, then retry")
            return
        img_url = cloudinary_upload(d / frame, f"{safe}/frames/{s.setdefault('uid', new_uid())}")
        if not img_url:
            s["video"].update(status="error", error="frame upload failed (check Cloudinary keys / quota)")
            return
        prompt = s.get("video_prompt") or s.get("video_desc") or ""
        prompt = _apply_cam_lock(prompt, s)   # keep the camera static by default (lock on) unless off / user asked for movement
        api, mid, payload = build_video_request(s.get("video_model") or DEFAULT_VIDEO_MODEL, img_url,
                                                prompt, s.get("video_dur"), s.get("video_res"))
        tid, err = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
        if tid:
            # remember WHICH approved image this video is being made from, so the Videos tab can flag a
            # video as stale once the scene's approved image is changed/re-approved to a different one.
            s["video"].update(status="generating", taskId=tid, error=None, api=api, source=frame, gen_started=time.time())
        else:
            s["video"].update(status="error", error=err)
    except Exception as e:
        s["video"].update(status="error", error=f"video submit failed: {e}")

def _drain_video_queue(doc, d, safe):
    gen = sum(1 for s in doc["scenes"] if s["video"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= VID_CONCURRENCY:
            break
        if s["video"]["status"] != "queued":
            continue
        _submit_video(s, d, safe, doc)
        changed = True
        if s["video"]["status"] == "generating":
            gen += 1
    return changed

@app.route("/api/scenes/<project>/generate", methods=["POST"])
def api_generate(project):
    with _project_lock(project):
        return _api_generate(project)


def _api_generate(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    targets = doc["scenes"] if ids == "all" else [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        if not s.get("prompt"):
            s["image"].update(status="error", error="no prompt")
        else:
            s["image"].update(status="queued", error=None, taskId=None, retries=0)   # enter the queue
    _drain_image_queue(doc, d, safe)                                       # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/poll", methods=["POST"])
def api_poll(project):
    return _api_poll(project)


def _api_poll(project):
    # Phase 1 — Kie polling + downloads run WITHOUT the project lock, so a concurrent approve/save
    # never waits on Kie network I/O (this was the "freeze while generating" cause). We only collect
    # results here; nothing shared is mutated. Phase 2 then reloads a fresh doc under the lock and
    # applies the results atomically (so a stale poll can never revert a just-made change).
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    updates = {}   # sid -> {"image": {...}, "video": {...}}, each tagged with its taskId

    def _img_result(img, uid):
        try:
            rec = kie_record(img["taskId"])
        except Exception:
            rec = {}                                    # transient poll failure → treat as still running (may time out below)
        state = (rec.get("data") or {}).get("state")
        if state == "success":
            url = result_url(rec)
            if not url:
                return {"ok": False, "error": "no result url"}
            ver = len(img.get("versions", [])) + 1
            fname = f"sc_{uid}_v{ver}.png"
            try:
                download_as_png(url, d / "images" / fname)
                return {"ok": True, "path": f"images/{fname}"}
            except Exception as e:
                return {"ok": False, "error": f"download: {e}"}
        elif state == "fail":
            return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
        started = img.get("gen_started")                # stuck task safety-net: never spin "generating" forever
        if started and (time.time() - started) > IMG_GEN_TIMEOUT:
            return {"ok": False, "error": f"timed out after {IMG_GEN_TIMEOUT // 60} min — the image service did not finish; please try again"}
        return None   # still running

    def _vid_result(v, uid):
        fname = f"sc_{uid}.mp4"
        def _timed_out():
            started = v.get("gen_started")
            if started and (time.time() - started) > VID_GEN_TIMEOUT:
                return {"ok": False, "error": f"timed out after {VID_GEN_TIMEOUT // 60} min — the video service did not finish; please try again"}
            return None
        if v.get("api") == "veo":
            try:
                rec = kie_veo_record(v["taskId"])
            except Exception:
                rec = {}
            data = rec.get("data") or {}
            sf = data.get("successFlag")
            if sf == 1:
                resp = data.get("response") or {}
                urls = resp.get("fullResultUrls") or resp.get("resultUrls") or resp.get("originUrls") or []
                url = urls[0] if urls else None
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif sf in (2, 3):
                return {"ok": False, "error": data.get("errorMessage") or "generation failed"}
            return _timed_out()
        else:
            try:
                rec = kie_record(v["taskId"])
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec)
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif state == "fail":
                return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
            return _timed_out()

    for s in doc["scenes"]:
        uid = s.setdefault("uid", new_uid())
        img = s["image"]
        if img["status"] == "generating" and img.get("taskId"):
            r = _img_result(img, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["image"] = {"taskId": img["taskId"], **r}
        v = s["video"]
        if v["status"] == "generating" and v.get("taskId"):
            r = _vid_result(v, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["video"] = {"taskId": v["taskId"], **r}

    # Phase 2 — apply atomically under the lock (reload fresh so we merge onto the current truth).
    _card_checks = []                                      # cards that just landed -> lettering read back after the lock
    _qa_checks = []                                        # other pictures that just landed -> judged after the lock
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        changed = False
        for s in doc["scenes"]:
            u = updates.get(s["id"])
            if not u:
                continue
            iu = u.get("image")
            # only apply if the scene is STILL awaiting the SAME task (user didn't cancel/reset meanwhile)
            if iu and s["image"].get("status") == "generating" and s["image"].get("taskId") == iu["taskId"]:
                if iu["ok"] and s["image"].pop("compose_packs", None):
                    # The plate has landed. Keep it as THE project's plate, then stand the packs on it.
                    try:
                        files = showcase_pack_files(s, doc, d)
                        if not files:
                            raise ValueError("pack images missing")
                        plate = showcase_plate_path(d)
                        plate.parent.mkdir(parents=True, exist_ok=True)
                        # Generate All Images submits every showcase at once, so they all found no plate
                        # and all painted one; the last to finish overwrote the rest and one scene in five
                        # ended up on a different floor. Whoever gets there FIRST owns the backdrop - the
                        # others throw their own away and compose onto it, so the set always matches.
                        if not plate.exists():
                            shutil.copy2(d / iu["path"], plate)
                        compose_showcase(plate, files, d / iu["path"])
                    except Exception as e:
                        iu = {"ok": False, "error": "showcase compose failed: %s" % e}
                if iu["ok"]:
                    s["image"].setdefault("versions", []).append(iu["path"])
                    vm = s["image"].setdefault("version_models", [])   # keep aligned with versions
                    while len(vm) < len(s["image"]["versions"]) - 1:    # backfill any legacy versions with no recorded model
                        vm.append(s.get("model") or IMAGE_MODEL)
                    vm.append(s["image"].get("pending_model") or s.get("model") or IMAGE_MODEL)   # the model that made THIS version
                    s["image"]["current"] = len(s["image"]["versions"]) - 1
                    s["image"].update(status="ready", file=iu["path"], error=None)
                    # bulk run: nobody is here to approve, so the first frame showing a photo-less
                    # recurring person becomes their face-lock for the rest of the batch
                    _auto_anchor(doc, s, provisional=True)
                    if (s.get("card") or "").strip() and not is_youtube(doc):   # a card: read its lettering back
                        _card_checks.append((s["id"], iu["path"], s["card"].strip(), len(s["image"]["versions"]) - 1))
                    elif _auto_qa_wanted(doc, s):                                # anything else: the reviewer looks now
                        _qa_checks.append((s["id"], iu["path"], len(s["image"]["versions"]) - 1))
                else:
                    _image_failed(s, doc, iu["error"])   # try again, reword if it was refused
                changed = True
            vu = u.get("video")
            if vu and s["video"].get("status") == "generating" and s["video"].get("taskId") == vu["taskId"]:
                if vu["ok"]:
                    s["video"].update(status="ready", file=vu["path"], error=None)
                else:
                    s["video"].update(status="error", error=vu["error"])
                changed = True
        # a running job finished → submit the next queued image/video jobs (keeps in-flight ≤ the limit)
        if _drain_image_queue(doc, d, safe):
            changed = True
        if _drain_video_queue(doc, d, safe):
            changed = True
        if changed:
            save_doc(project, doc)
        for _cc in _card_checks:
            _KeyThread(target=_card_text_check, daemon=True, args=(project,) + _cc).start()
        for _qc in _qa_checks:
            _KeyThread(target=_auto_qa_check, daemon=True, args=(project,) + _qc).start()
        return jsonify(doc)

# ---- routes: video generation ----------------------------------------------
@app.route("/api/scenes/<project>/generate-video", methods=["POST"])
def api_generate_video(project):
    with _project_lock(project):
        return _api_generate_video(project)


def _api_generate_video(project):
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if not VIDEO_CONFIGURED:
        return jsonify({"error": "Seedance video model not configured yet (need exact model id/params)."}), 503
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", [])
    if ids == "all":
        targets = [s for s in doc["scenes"] if s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))]
    else:
        targets = [s for s in doc["scenes"] if s["id"] in ids]
    # A scene with no motion prompt would go out with an EMPTY instruction and the model would animate
    # whatever it felt like - a paid-for clip nobody directed. Skip those and say how many.
    def _has_motion(s):
        return bool((s.get("video_prompt") or "").strip() or (s.get("video_desc") or "").strip())
    no_prompt = [s.get("id") for s in targets if not _has_motion(s)]
    targets = [s for s in targets if _has_motion(s)]
    for s in targets:
        s["video"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_video_queue(doc, d, safe)                                   # submit up to the limit now
    save_doc(project, doc)
    out = dict(doc)
    out["skipped_no_prompt"] = no_prompt          # the UI names these instead of failing quietly
    return jsonify(out)

# ---- local thumbnails for reference images ---------------------------------
# Every reference image exists twice: on disk under projects/<name>/refs/ (the original
# upload) and on Cloudinary (the public URL Kie fetches at generation time). Drawing the
# panel straight from Cloudinary re-downloaded every full-size ref on each render, which
# is what exhausted the account's bandwidth quota. The UI now asks for the local copy and
# only falls back to the remote URL when the file is missing.
def _norm_stem(s):
    """Loose filename key: scene refs are 's1-0-name' on Cloudinary but 's1_0_name' on disk."""
    return re.sub(r"[-_\s]+", " ", s).strip().lower()

def _local_ref_for_url(d, url):
    """Find the on-disk file a reference points to, or None."""
    refs = d / "refs"
    if not url or not refs.is_dir():
        return None
    # new-style refs are a local relative path stored directly (e.g. "refs/s1_0_name.png")
    if not url.startswith("http://") and not url.startswith("https://"):
        p = d / _urlunquote(url)
        if p.is_file():
            return p
        p = refs / Path(_urlunquote(url)).name
        return p if p.is_file() else None
    # old-style refs are a Cloudinary URL → match the local file by filename stem
    path = _urlunquote(_urlparse(url).path)
    stem = Path(path).stem
    # characters upload as <safe>/characters/<cid>, but are stored as char_<cid>_<original>
    if "/characters/" in path:
        hit = next((p for p in sorted(refs.glob(f"char_{stem}_*")) if p.is_file()), None)
        if hit:
            return hit
    want = _norm_stem(stem)
    for p in sorted(refs.iterdir()):
        if p.is_file() and _norm_stem(p.stem) == want:
            return p
    return None

@app.route("/api/ref-thumb/<project>")
def api_ref_thumb(project):
    """Serve a small cached thumbnail of a reference image straight from local disk."""
    d, safe = proj_dir(project)
    src = _local_ref_for_url(d, request.args.get("u", ""))
    if src is None:
        abort(404)                      # the UI falls back to the remote URL
    tdir = d / ".thumbs"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(src.name.encode("utf-8")).hexdigest() + ".jpg")
    if not thumb.exists() or thumb.stat().st_mtime < src.stat().st_mtime:
        try:
            im = Image.open(src)
            im = im.convert("RGB")
            im.thumbnail((360, 360))
            im.save(thumb, "JPEG", quality=82)
        except Exception:
            return send_file(src)       # not readable by PIL -> hand over the original
    return send_file(thumb, mimetype="image/jpeg")

@app.route("/icons/<name>")
def serve_icon(name):
    """Serve an overlay icon PNG (X / arrow / ring) from the Icons folder next to this module — used by the
    scene-card icon editor to preview icons on the image thumbnails."""
    if "/" in name or "\\" in name or ".." in name:
        abort(404)
    p = Path(__file__).resolve().parent / "Icons" / name
    if not p.is_file():
        abort(404)
    ext = p.suffix.lower()
    if ext in (".mp4", ".mov", ".webm"):         # video EFFECT overlays (e.g. a hand-drawn arrow clip)
        return send_file(p, mimetype={"mp4": "video/mp4", "mov": "video/quicktime", "webm": "video/webm"}[ext[1:]])
    h = request.args.get("h", type=int)          # ?h=<hue> -> recolour to that absolute hue (same PNG the XML export uses)
    if h:
        try:
            p = premiere_export._icon_hue_file(p, h)
        except Exception as _qe:
            quiet(_qe, "serve_icon")
    return send_file(p, mimetype="image/png")

# ---- routes: refs -----------------------------------------------------------
# ---- routes: per-scene reference images ------------------------------------

@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["POST"])
@_locked
def api_scene_ref(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    idx = len(scene.get("refs", []))
    fname = f"s{sid}_{idx}_{int(time.time())}_{f.filename}"
    f.save(d / "refs" / fname)
    # store the LOCAL path only — the Cloudinary upload is deferred to generation time (see
    # ref_public_url), so adding references never needs the network or the Cloudinary quota
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"]})

@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["DELETE"])
@_locked
def api_scene_ref_delete(project, sid):
    """Remove ONE reference image from a scene by index. Dedicated endpoint (refs are NOT in the
    save-scenes whitelist) so a routine full-doc save / a racing approve can never clobber a scene's
    references — this is what silently dropped a just-added reference."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    idx = (request.get_json(silent=True) or {}).get("index")
    refs = scene.get("refs") or []
    if not isinstance(idx, int) or idx < 0 or idx >= len(refs):
        return jsonify({"error": "bad index"}), 400
    url = refs.pop(idx)
    if scene.get("ref_free"):
        scene["ref_free"] = [u for u in scene["ref_free"] if u != url]
    scene["refs"] = refs
    save_doc(project, doc)
    return jsonify({"refs": scene["refs"], "ref_free": scene.get("ref_free", [])})


@app.route("/api/scenes/<project>/<int:sid>/ref-lock", methods=["POST"])
@_locked
def api_scene_ref_lock(project, sid):
    """Toggle a reference's outfit-lock (ref_free membership). Dedicated endpoint so a full-doc save
    can't clobber it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    body = request.get_json(force=True) or {}
    url = (body.get("url") or "").strip()
    if not url:
        return jsonify({"error": "no url"}), 400
    free = [u for u in (scene.get("ref_free") or []) if u != url]
    if not bool(body.get("locked")):      # unlocked → the ref's outfit is FREE → add to ref_free
        free.append(url)
    scene["ref_free"] = free
    save_doc(project, doc)
    return jsonify({"ref_free": scene["ref_free"]})


@app.route("/api/scenes/<project>/<int:sid>/ref-scene", methods=["POST"])
@_locked
def api_scene_ref_scene(project, sid):
    """Add another scene's APPROVED image as a reference on scene <sid> — a snapshot copy into refs/.
    The filename carries the source scene number (sceneref-<N>-…) so the UI can badge it 'Scene N'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    from_id = (request.get_json(force=True) or {}).get("from")
    src_scene = next((s for s in doc["scenes"] if s["id"] == from_id), None)
    if src_scene is None:
        return jsonify({"error": "scene not found"}), 404
    im = src_scene.get("image", {}) or {}
    rel = im.get("approved_file") or im.get("file")     # prefer the approved image
    if not rel:
        return jsonify({"error": "that scene has no image yet"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not src.exists():
        return jsonify({"error": "source image missing"}), 400
    (d / "refs").mkdir(parents=True, exist_ok=True)
    fname = f"sceneref-{from_id}-{int(time.time())}{src.suffix or '.png'}"
    shutil.copy2(src, d / "refs" / fname)
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"], "doc": doc})

@app.route("/api/scenes/<project>/<int:sid>/copy-image", methods=["POST"])
@_locked
def api_scene_copy_image(project, sid):
    """Copy ANOTHER scene's generated image DIRECTLY into scene <sid> as a new image version (made current).
    Unlike ref-scene (adds a reference), this drops the actual picture in as this scene's own image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    from_id = (request.get_json(force=True) or {}).get("from")
    src_scene = next((s for s in doc["scenes"] if s["id"] == from_id), None)
    if src_scene is None:
        return jsonify({"error": "scene not found"}), 404
    sim = src_scene.get("image", {}) or {}
    rel = sim.get("approved_file") or sim.get("file")            # prefer the approved image
    if not rel:
        return jsonify({"error": "that scene has no image yet"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not src.exists():
        return jsonify({"error": "source image missing"}), 400
    (d / "images").mkdir(parents=True, exist_ok=True)
    img = scene.setdefault("image", {})
    img.setdefault("versions", [])
    ver = len(img["versions"]) + 1
    fname = f"images/sc_{scene.get('uid', 'x')}_v{ver}_from{from_id}{src.suffix or '.png'}"
    shutil.copy2(src, d / fname)
    img["versions"].append(fname)
    # carry the source version's model label if we can, else this scene's default
    try:
        svm = sim.get("version_models") or []
        scur = sim.get("approved_version"); scur = scur if isinstance(scur, int) else sim.get("current", -1)
        src_model = svm[scur] if (0 <= (scur or -1) < len(svm)) else (scene.get("model") or IMAGE_MODEL)
    except Exception:
        src_model = scene.get("model") or IMAGE_MODEL
    vm = img.setdefault("version_models", [])
    while len(vm) < len(img["versions"]) - 1:
        vm.append(scene.get("model") or IMAGE_MODEL)
    vm.append(src_model)
    img["current"] = len(img["versions"]) - 1
    img.update(status="ready", file=fname, error=None, taskId=None)
    save_doc(project, doc)
    return jsonify({"doc": doc, "file": fname})

# ---- routes: PRODUCT reference image (per-project) --------------------------
@app.route("/api/product/<project>", methods=["POST"])
@_locked
def api_add_product(project):
    """Add product reference image(s) for THIS project (saved locally; Cloudinary upload deferred to
    generation). These get attached (i2i) to any scene flagged show-product, keeping the real label/design."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a product image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    prod = doc.setdefault("product", {"urls": []})
    prod.setdefault("urls", [])
    prod.setdefault("names", {})
    for i, f in enumerate(files):
        fname = f"product_{int(time.time() * 1000)}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        rel = f"refs/{fname}"
        prod["urls"].append(rel)
        prod["names"][rel] = _product_default_name(f.filename)   # seed a label from the file name ("3 bottle.png" -> "3 bottle")
    save_doc(project, doc)
    return jsonify(prod)

def _product_default_name(filename):
    """A friendly default label from the uploaded file name — the user usually names the file by pack
    size ('3 bottle.png'), so that becomes the dropdown label right away, still editable in the panel."""
    stem = os.path.splitext(os.path.basename(filename or ""))[0]
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    return stem[:40] or "Product"

@app.route("/api/product/<project>/rename", methods=["POST"])
@_locked
def api_rename_product(project):
    """Set the human label for one product image (e.g. '1 bottle', '3 bottle') — shown in the per-scene
    Product dropdown so the user picks the right pack by name instead of 'Product 1 / 2 / 3'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    url = (body.get("url") or "").strip()
    name = (body.get("name") or "").strip()[:40]
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod.setdefault("names", {})[url] = name or "Product"
    save_doc(project, doc)
    return jsonify(prod)

@app.route("/api/product/<project>/name", methods=["POST"])
@_locked
def api_set_product_name(project):
    """Set the advertised product's BRAND name (e.g. 'Cardio-360'). Auto-filled by Analyze Cast; shown + editable
    in the Product panel; passed to the director so product shots are named correctly."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    prod = doc.setdefault("product", {"urls": []})
    prod["name"] = (body.get("name") or "").strip()[:80]
    save_doc(project, doc)
    return jsonify(prod)

@app.route("/api/product/<project>/remove", methods=["POST"])
@_locked
def api_remove_product(project):
    """Drop one product reference image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    url = ((request.get_json(force=True) or {}).get("url") or "").strip()
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod["urls"].remove(url)
    (prod.get("names") or {}).pop(url, None)
    save_doc(project, doc)
    return jsonify(prod)

# ---- routes: product INGREDIENTS (per-project) — mirror characters (upload reference images) --------
@app.route("/api/ingredients/<project>", methods=["POST"])
@_locked
def api_add_ingredient(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "ingredient name is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    iid = hashlib.md5(f"ing{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"ing_{iid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ing = {"id": iid, "name": name, "desc": (request.form.get("desc") or "").strip(), "urls": urls,
           "scientific": False, "split": False, "use_directly": False}
    doc.setdefault("ingredients", []).append(ing)
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>", methods=["POST"])
@_locked
def api_update_ingredient(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    if (request.form.get("name") or "").strip():
        ing["name"] = request.form.get("name").strip()
    if "desc" in request.form:
        ing["desc"] = (request.form.get("desc") or "").strip()
    if "scientific" in request.form:
        ing["scientific"] = request.form.get("scientific") == "true"
    if "split" in request.form:
        ing["split"] = request.form.get("split") == "true"
    if "use_directly" in request.form:
        ing["use_directly"] = request.form.get("use_directly") == "true"
    ing.setdefault("urls", [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"ing_{iid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ing["urls"].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>/remove-image", methods=["POST"])
@_locked
def api_remove_ingredient_image(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    url = (request.get_json(force=True) or {}).get("url")
    lst = ing.setdefault("urls", [])
    if url in lst:
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception as _qe:
            quiet(_qe, "api_remove_ingredient_image")
    save_doc(project, doc)
    return jsonify(ing)

@app.route("/api/ingredients/<project>/<iid>", methods=["DELETE"])
@_locked
def api_del_ingredient(project, iid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["ingredients"] = [x for x in doc.get("ingredients", []) if x.get("id") != iid]
    for s in doc.get("scenes", []):                 # also drop it from any scene that referenced it
        if s.get("ingredients"):
            s["ingredients"] = [v for v in s["ingredients"] if v != iid]
    save_doc(project, doc)
    return jsonify({"ingredients": doc["ingredients"]})

def _ingredient_portrait_prompt(ing):
    """Reference-image prompt for ONE ingredient.
      default    → the real ingredient in its NATURAL setting (fruit on the tree, root in the soil…).
      scientific → a clean 3D molecular / scientific render instead (for complexes like a vitamin/mineral).
      split      → the name split on '/' into 2-4 items shown as EQUAL side-by-side vertical panels
                   (one item per panel); combines with scientific (each panel a molecule)."""
    name = (ing.get("name") or "an ingredient").strip()
    sci = bool(ing.get("scientific"))
    split = bool(ing.get("split"))

    _tones = ["soft glowing blue", "deep navy blue", "dark teal", "deep blue-violet"]
    _frames = [                                     # same MEDIUM distance in every panel (NO extreme close-ups) —
        "a hero molecule centred and tilted, seen from a slightly low angle, others drifting far behind",
        "an off-centre molecule seen from above at a diagonal, a looser scattered cluster around it",
        "a molecule slightly right of centre seen from a gentle side angle, a balanced cluster around it",
        "a molecule upper-left with a soft downward tilt, evenly spaced molecules behind",
    ]
    _mols = [                                       # tint the molecules differently per panel so they don't all look alike
        "clear glass-like spheres with a subtle cool blue tint",
        "warm amber / golden translucent glass spheres",
        "emerald-green translucent glass spheres",
        "soft violet-magenta tinted glass spheres",
    ]
    _NO_TEXT = ("Absolutely NO text, NO letters, NO numbers, NO chemical symbols, formulae, element abbreviations "
                "or labels of any kind anywhere in the image; no packaging, no captions, no hands.")

    def look(item, idx=0):
        if sci:
            # vary the backdrop PER MOLECULE (hash the name) so different molecules never share one look; the atom
            # colours + real structure already differ by molecule, so each render comes out distinct.
            k = idx + sum(ord(c) for c in (item or "x"))
            bg = _tones[k % len(_tones)]
            return (f"a premium cinematic 3D scientific render of the {item} molecule — depict {item}'s OWN correct "
                    f"ball-and-stick molecular structure (its real atoms, bonds and shape, specific to {item}, NOT a "
                    f"generic blob), with the atoms coloured by element in the realistic CPK convention (oxygen red, "
                    f"nitrogen blue, carbon dark grey, hydrogen white, sulphur yellow, phosphorus orange) as glossy "
                    f"glass-like spheres and rods with liquid-glass reflections and bright specular highlights; the "
                    f"molecule sits DEAD-CENTRE of the frame at a medium distance (not an extreme close-up), a few "
                    f"smaller molecules softly out of focus behind it, shallow depth-of-field with soft bokeh and "
                    f"tiny glowing dust particles, soft cinematic studio lighting, on a smooth {bg} gradient background")
        return (f"{item} in its NATURAL SETTING where it grows or is found (the fruit on its tree/branch, the "
                f"herb/leaves in a field, the root in the soil, or the spice as whole fresh pods/seeds), beautiful "
                f"natural light, fresh, vivid, sharp focus")

    parts = [p.strip() for p in name.split("/") if p.strip()] if split else []
    if split and len(parts) >= 2:
        n = min(len(parts), 4)
        parts = parts[:n]
        word = {2: "two", 3: "three", 4: "four"}[n]
        panels = "; ".join(f"panel {i + 1} shows {look(p, i)}" for i, p in enumerate(parts))
        if sci:
            panels += (" — make EACH panel clearly DIFFERENT via its own background tone, molecule colour and "
                       "angle/composition, BUT keep the molecules a similar MEDIUM size/distance in every panel "
                       "(all panels equally zoomed, NO extreme close-ups)")
        return (f"A single image divided into {word} EQUAL side-by-side vertical panels of the SAME width — a clean "
                f"{word}-way split screen with a thin or no divider, each panel showing ONE ingredient: {panels}. "
                f"Keep all panels equal-sized and balanced. {_NO_TEXT}")
    return (f"A photorealistic image showing {look(name)}. {_NO_TEXT}")

@app.route("/api/ingredients/<project>/<iid>/generate", methods=["POST"])
def api_generate_ingredient(project, iid):
    """Generate a reference-image CANDIDATE for an ingredient (text-to-image, natural setting) — reviewed in the
    same candidate window as cast (edit / regenerate / accept). Synchronous poll, like the cast portrait."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    body = request.get_json(silent=True) or {}
    if body.get("fresh"):
        for p in d.glob(f"refs/ingcand_{iid}_*"):
            try: p.unlink()
            except Exception as _qe: quiet(_qe, "api_generate_ingredient")
    custom = (body.get("prompt") or "").strip()   # user's OWN prompt from the candidate window → overrides the auto prompt
    if custom:
        prompt = custom
        if looks_turkish(custom):
            try: prompt = translate_to_english(custom)
            except Exception: prompt = custom
    else:
        prompt = _ingredient_portrait_prompt(ing)
    rel, cerr = _run_char_candidate(d, iid, prompt, [], prefix="ingcand")   # nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})

@app.route("/api/ingredients/<project>/<iid>/edit-candidate", methods=["POST"])
def api_edit_ingredient_candidate(project, iid):
    """Edit an ingredient candidate with a typed instruction (image-to-image) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    # accept any existing image of this project as the edit base (a candidate OR an already-committed thumbnail)
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/ingedit/{iid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, iid, instr_en, [base_url], prefix="ingcand", family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})

@app.route("/api/ingredients/<project>/<iid>/use-candidate", methods=["POST"])
@_locked
def api_use_ingredient_candidate(project, iid):
    """Accept an ingredient candidate → commit it as a reference image, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ing = next((x for x in doc.get("ingredients", []) if x.get("id") == iid), None)
    if ing is None:
        return jsonify({"error": "ingredient not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"ingcand_{iid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"ing_{iid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception as _qe: quiet(_qe, "api_use_ingredient_candidate")
    for p in d.glob(f"refs/ingcand_{iid}_*"):
        try: p.unlink()
        except Exception as _qe: quiet(_qe, "api_use_ingredient_candidate")
    ing.setdefault("urls", []).append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(ing)

def _discard_candidates(d, tag, ident, body):
    """Throw away un-accepted candidate pictures under refs/<tag>_<ident>_*. `all` clears every one of
    them (Cancel); otherwise only the one whose relative url is given."""
    if body.get("all"):
        for p in d.glob(f"refs/{tag}_{ident}_*"):
            try: p.unlink()
            except Exception as _qe: quiet(_qe, "_discard_candidates")
    else:
        rel = (body.get("url") or "").strip()
        if rel.startswith("refs/") and f"{tag}_{ident}_" in rel:
            try: (d / rel).unlink()
            except Exception as _qe: quiet(_qe, "_discard_candidates")


@app.route("/api/ingredients/<project>/<iid>/discard-candidate", methods=["POST"])
def api_discard_ingredient_candidate(project, iid):
    d, _safe = proj_dir(project)
    _discard_candidates(d, "ingcand", iid, request.get_json(silent=True) or {})
    return jsonify({"ok": True})

# ---- routes: named characters (per-project cast) ---------------------------
@app.route("/api/characters/<project>", methods=["POST"])
@_locked
def api_add_character(project):
    """Add a named character: form fields `name` + `file` (reference image). The image is saved
    LOCALLY; the upload to Cloudinary (needed as an i2i reference for Kie) is deferred to image
    generation — so adding a character never needs the network or the Cloudinary quota."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "character name is required"}), 400
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a reference image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    cid = hashlib.md5(f"{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate(files):
        fname = f"char_{cid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ch = {"id": cid, "name": name, "urls": urls}   # local paths; Cloudinary upload happens at generation
    doc.setdefault("characters", []).append(ch)
    _rebind_all_cast(doc)                          # a new named cast binds into any scene whose prompt names it
    save_doc(project, doc)
    return jsonify({**ch, "_characters": doc.get("characters") or [], "_scenes": doc.get("scenes") or []})


def _norm_char(ch):
    """Migrate a legacy single-`url` character to the multi-image `urls` shape in place."""
    if "urls" not in ch:
        ch["urls"] = [ch["url"]] if ch.get("url") else []
    ch.pop("url", None)
    return ch


def _role_outfit(name, role):
    """Map a character's role/name to a specific, unambiguous outfit so the profession reads at a glance —
    a 'Dr' or a doctor gets a WHITE COAT, not a suit. Returns a phrase or None."""
    r = (role or "").lower()
    n = (name or "").lower()
    is_dr = n.startswith("dr ") or n.startswith("dr.") or (" dr " in f" {n} ")
    if is_dr or any(k in r for k in ("doctor", "physician", "surgeon", "medical", "clinician", "gp")):
        return "a white medical doctor's coat worn over their clothes (a stethoscope is fine) — clearly a doctor"
    if "nurse" in r:
        return "medical nurse scrubs"
    if any(k in r for k in ("research", "scientist", "biolog", "botan", "chemist", "lab", "professor")):
        return "a white lab coat — clearly a scientist/researcher"
    if any(k in r for k in ("chef", "cook")):
        return "a chef's white uniform"
    if any(k in r for k in ("farmer", "grower")):
        return "practical rustic outdoor work clothes"
    return None

def _char_portrait_prompt(ch, aud, style=None):
    """Text-to-image prompt for a clean, reusable casting portrait of ONE character, built from the
    character's fixed description (falling back to name/role) + a role-appropriate outfit + a location hint.

    `style` is the project's look. It matters more here than anywhere else: this portrait is the reference
    every scene featuring the character is generated against, so a photoreal portrait on a 2D project asks
    each scene to be a cartoon AND to match a photograph. Defaults to natural, as it always did."""
    desc = (ch.get("desc") or "").strip()
    role = (ch.get("role") or "").strip()
    name = (ch.get("name") or "a person").strip()
    who = desc or (name + (f", {role}" if role else ""))
    style = style if style in STYLE_PRESETS else "natural"
    drawn = style in ANIM_STYLES          # 2d / 3d - a drawn character sheet, not a photograph
    parts = [(f"A clean character-design reference of ONE single character: {who}."
              if drawn else f"A clean casting reference portrait of ONE single person: {who}.")]
    outfit = _role_outfit(name, role)
    if outfit:
        # forceful, specific — don't bury it in a menu of examples, or the model defaults to a generic suit
        parts.append(f"IMPORTANT: they MUST be clearly shown wearing {outfit}, so their profession is obvious at a glance.")
    elif role:
        parts.append(f"Dress them in clothing appropriate for their role ({role}).")
    loc = None
    try:
        locs = (aud or {}).get("locations")
        if isinstance(locs, list) and locs:
            loc = str(locs[0])
        elif isinstance(locs, str) and locs.strip():
            loc = locs.strip()
    except Exception:
        loc = None
    if loc:
        parts.append(f"If the appearance above doesn't already fix it, make them look like an ordinary person from {loc}.")
    parts.append("Waist-up, facing the camera, calm friendly neutral expression, plain uncluttered light-grey "
                 "background, only this one %s in the frame and nothing else, no other %s, no props, no "
                 "logos. This is a face/appearance reference to reuse across scenes — keep it simple and clear."
                 % (("character", "characters") if drawn else ("person", "people")))
    parts.append(STYLE_PRESETS.get(style, STYLE_PRESETS.get("natural", "")))
    return "\n".join(p for p in parts if p and p.strip())


def _run_char_candidate(d, cid, prompt, refs, prefix="charcand", family=None, aspect="16:9", resolution="2K", cancel_check=None):
    """Generate ONE candidate PNG: build the request, create a Kie task, poll to completion, download.
    If the primary model fails/times out, AUTOMATICALLY retry with GPT Image (nano-banana has been flaky).
    Returns (rel_url, None) on success or (None, error_message). prefix = charcand (cast) / ingcand (ingredient).
    cancel_check: optional callable → if it returns truthy, abort ASAP with (None, 'cancelled')."""
    families = [family or IMAGE_MODEL]
    if "gpt-image-2" not in families:
        families.append("gpt-image-2")               # fallback model when the primary fails
    last_err = "could not start generation"
    for fam in families:
        if cancel_check and cancel_check():
            return None, "cancelled"
        try:
            model_id, inp = build_kie_image_request(fam, prompt, refs or [], aspect=aspect, resolution=resolution)
            tid, cerr = kie_create(model_id, inp)
        except Exception as e:
            last_err = str(e); continue
        if not tid:
            last_err = cerr or last_err; continue
        url = fail = None
        for _ in range(60):                          # poll up to ~2 minutes
            if cancel_check and cancel_check():
                return None, "cancelled"             # user pressed Stop → abort the in-flight poll
            time.sleep(2)
            try:
                rec = kie_record(tid)
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec); break
            if state == "fail":
                fail = (rec.get("data") or {}).get("failMsg", "generation failed"); break
        if fail:
            last_err = fail; continue                 # primary failed → try the fallback family
        if not url:
            last_err = "generation timed out"; continue
        fname = f"{prefix}_{cid}_{int(time.time() * 1000)}.png"   # ms so rapid regen/edit never collide
        try:
            download_as_png(url, d / "refs" / fname)
        except Exception as e:
            last_err = f"download failed: {e}"; continue
        return f"refs/{fname}", None
    return None, last_err


@app.route("/api/characters/<project>/<cid>/generate", methods=["POST"])
def api_generate_character(project, cid):
    """Generate a portrait CANDIDATE (never auto-committed). `fresh` (first open) clears old candidates;
    a regenerate keeps them so the user can flip between versions. Same model/resolution as scene images."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    body = request.get_json(silent=True) or {}
    if body.get("fresh"):
        for p in d.glob(f"refs/charcand_{cid}_*"):
            try: p.unlink()
            except Exception as _qe: quiet(_qe, "api_generate_character")
    custom = (body.get("prompt") or "").strip()   # user's OWN prompt from the candidate window → overrides the auto prompt
    if custom:
        prompt = custom
        if looks_turkish(custom):
            try: prompt = translate_to_english(custom)
            except Exception: prompt = custom
    else:
        prompt = _char_portrait_prompt(ch, doc.get("audience"), _doc_scene_style(doc))
    rel, cerr = _run_char_candidate(d, cid, prompt, [])   # nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/characters/<project>/<cid>/edit-candidate", methods=["POST"])
def api_edit_char_candidate(project, cid):
    """Edit a candidate with a typed instruction (image-to-image, NanoBanana) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    # accept any existing image of this project as the edit base (a candidate OR an already-committed thumbnail)
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/charedit/{cid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, cid, instr_en, [base_url], family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})


@app.route("/api/characters/<project>/<cid>/use-candidate", methods=["POST"])
@_locked
def api_use_char_candidate(project, cid):
    """Accept a candidate → rename it into a normal character image, add to roster, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"charcand_{cid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"char_{cid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception as _qe: quiet(_qe, "api_use_char_candidate")
    for p in d.glob(f"refs/charcand_{cid}_*"):          # committed one → drop the rest
        try: p.unlink()
        except Exception as _qe: quiet(_qe, "api_use_char_candidate")
    _norm_char(ch)
    ch["urls"].append(f"refs/{newname}")
    _rebind_all_cast(doc)                    # a just-photographed character binds into any scene that names it
    save_doc(project, doc)
    return jsonify({**ch, "_characters": doc.get("characters") or [], "_scenes": doc.get("scenes") or []})


@app.route("/api/characters/<project>/<cid>/discard-candidate", methods=["POST"])
def api_discard_char_candidate(project, cid):
    """Throw away un-accepted candidate(s). `all` clears every candidate for this character (on Cancel)."""
    d, _safe = proj_dir(project)
    _discard_candidates(d, "charcand", cid, request.get_json(silent=True) or {})
    return jsonify({"ok": True})


@app.route("/api/characters/<project>/<cid>", methods=["POST"])
@_locked
def api_update_character(project, cid):
    """Edit a character: optional rename (form `name`) and/or append reference image(s) (form `file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    name = (request.form.get("name") or "").strip()
    if name:
        ch["name"] = name
    # transforming character (e.g. slims down across the video): a flag + an optional note + a SECOND photo
    # bucket (`urls_end` = the END look). `bucket=end` routes uploads to that bucket; default is the start bucket.
    if "transforms" in request.form:
        ch["transforms"] = request.form.get("transforms") in ("1", "true", "on", "yes")
    if "transform_note" in request.form:
        ch["transform_note"] = (request.form.get("transform_note") or "").strip()
    bucket = "urls_end" if (request.form.get("bucket") == "end") else "urls"
    ch.setdefault(bucket, [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"char_{cid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ch[bucket].append(f"refs/{fname}")
    _rebind_all_cast(doc)                    # newly-photographed / renamed cast binds into scenes that name it
    save_doc(project, doc)
    return jsonify({**ch, "_characters": doc.get("characters") or [], "_scenes": doc.get("scenes") or []})


@app.route("/api/characters/<project>/<cid>/remove-image", methods=["POST"])
@_locked
def api_remove_character_image(project, cid):
    """Drop one reference image from a character (keeps at least one)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    body = request.get_json(force=True) or {}
    url = body.get("url")
    bucket = "urls_end" if (body.get("bucket") == "end") else "urls"
    lst = ch.setdefault(bucket, [])
    # start bucket must keep at least one photo; the END bucket is optional so it may go empty
    if url in lst and (bucket == "urls_end" or len(lst) > 1):
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception as _qe:
            quiet(_qe, "api_remove_character_image")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>", methods=["DELETE"])
@_locked
def api_del_character(project, cid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["characters"] = [c for c in doc.get("characters", []) if c.get("id") != cid]
    for s in doc.get("scenes", []):        # remove it from every scene's cast
        if cid in (s.get("cast") or []):
            s["cast"] = [x for x in s["cast"] if x != cid]
    save_doc(project, doc)
    return jsonify({"ok": True, "characters": doc["characters"]})



def _tp_portrait_prompt(person, aud, variety_idx=None):
    """Text-to-image prompt for an authentic, relatable everyday-person portrait — a believable real
    customer look for testimonials, built from the person's age / location / appearance note.
    `variety_idx` (when given) forces a SPECIFIC distinct setting + outfit so a batch of people vary."""
    desc = (person.get("desc") or "").strip()
    age = str(person.get("age") or "").strip()
    gender = (person.get("gender") or "").strip()
    loc = (person.get("location") or "").strip()
    bits = []
    if age:
        bits.append(f"around {age} years old")
    if gender:
        bits.append(gender.lower())
    if desc:
        bits.append(desc)
    who = ", ".join(bits) if bits else "an ordinary, relatable everyday person"
    parts = [f"A candid, authentic AMATEUR photo of ONE single real-looking ordinary person: {who}."]
    if not desc and variety_idx is not None:
        # no explicit appearance for this person -> give them a DISTINCT look so a batch doesn't all share one face
        parts.append(f"Their appearance: {_TP_LOOKS[variety_idx % len(_TP_LOOKS)]}. Make this person clearly look "
                     f"like a DIFFERENT individual — a unique face, hair and build, not a generic template.")
    if not loc:
        # fall back to the project's audience locations when the person has none of their own
        try:
            locs = (aud or {}).get("locations")
            if isinstance(locs, list) and locs:
                loc = str(locs[0]).strip()
            elif isinstance(locs, str) and locs.strip():
                loc = locs.strip()
        except Exception:
            loc = ""
    if loc:
        parts.append(f"They look like an ordinary person from {loc}.")
    if variety_idx is not None:
        setting, outfit = _TP_SCENES[variety_idx % len(_TP_SCENES)]
        bg = (f"Set specifically {setting}, visible and MOSTLY IN FOCUS behind them like a normal phone snapshot "
              f"(NOT a blurred portrait-mode / shallow-depth background) — this exact setting is REQUIRED, do NOT "
              f"default to a kitchen. They are wearing {outfit}. ")
    else:
        bg = ("Set in a NATURAL EVERYDAY BACKGROUND (at home, in the kitchen, at work, in a car, a cafe, a park or "
              "an ordinary street), visible and mostly in focus behind them like a normal phone snapshot (NOT a "
              "blurred portrait-mode background). ")
    # alternate selfie vs an ordinary snapshot taken by someone else, so a batch of portraits isn't ALL selfies
    is_selfie = (variety_idx % 2 == 0) if variety_idx is not None else True
    shot = ("a real AMATEUR front-facing phone SELFIE the person snapped of themselves at arm's length (slight "
            "selfie front-camera look)" if is_selfie else
            "a casual AMATEUR snapshot an ordinary person took of them on a phone (NOT a selfie)")
    parts.append(f"This MUST look like {shot}, used as a social-media PROFILE PICTURE - absolutely NOT a studio shot, "
                 "NOT a professional headshot, NOT a polished stock photo, and NOT a model. Compose it like a profile "
                 "photo: the person CENTRED in the frame and facing the camera, framed CLOSE - a tight head-and-"
                 "shoulders crop where the FACE is large and fills much of the frame (top of the head near the top "
                 "edge). Warm, genuine, natural expression; relaxed and a little imperfect, but CENTRED and upright "
                 "(do not tilt or push them to a corner). " + bg +
                 "Shot on an ORDINARY, cheap / older smartphone camera - modest everyday quality, mixed available "
                 "lighting (a little uneven, maybe slightly over-exposed near a window or a hint of on-phone flash), "
                 "visible sensor noise/grain, a bit soft and NOT razor-sharp, plain UNRETOUCHED skin with real texture "
                 "and pores. Only this one ordinary person in the frame, no other people, no logos, no text, no "
                 "watermark. A believable real customer's profile photo - authentic, relatable and a little rough, "
                 "never glossy, sharp, cinematic or stock-looking.")
    parts.append(STYLE_PRESETS.get("natural", ""))
    return "\n".join(p for p in parts if p and p.strip())


@app.route("/api/testimonial-people/<project>", methods=["POST"])
@_locked
def api_add_tperson(project):
    """Add a testimonial person: form `name` (required), optional `desc`, optional `file`(s).
    Unlike cast, no reference image is required — a portrait can be generated from the description."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip() or "New character"   # name-less add is fine; filled in on the card
    desc = (request.form.get("desc") or "").strip()
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    pid = hashlib.md5(f"tp{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"tp_{pid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    person = {"id": pid, "name": name, "desc": desc,
              "age": (request.form.get("age") or "").strip(),
              "gender": (request.form.get("gender") or "").strip(),
              "location": (request.form.get("location") or "").strip(), "urls": urls}
    doc.setdefault("testimonials", []).append(person)
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>", methods=["POST"])
@_locked
def api_update_tperson(project, pid):
    """Edit a testimonial person: optional rename (`name`), appearance note (`desc`), and/or append image(s) (`file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    name = (request.form.get("name") or "").strip()
    if name:
        person["name"] = name
    if "desc" in request.form:
        person["desc"] = (request.form.get("desc") or "").strip()
    if "age" in request.form:
        person["age"] = (request.form.get("age") or "").strip()
    if "gender" in request.form:
        person["gender"] = (request.form.get("gender") or "").strip()
    if "location" in request.form:
        person["location"] = (request.form.get("location") or "").strip()
    person.setdefault("urls", [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"tp_{pid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        person["urls"].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>/remove-image", methods=["POST"])
@_locked
def api_remove_tperson_image(project, pid):
    """Drop one image from a testimonial person (may go empty — a portrait can be regenerated later)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    url = (request.get_json(force=True) or {}).get("url")
    lst = person.setdefault("urls", [])
    if url in lst:
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception as _qe:
            quiet(_qe, "api_remove_tperson_image")
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>", methods=["DELETE"])
@_locked
def api_del_tperson(project, pid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["testimonials"] = [c for c in doc.get("testimonials", []) if c.get("id") != pid]
    save_doc(project, doc)
    return jsonify({"ok": True, "testimonials": doc["testimonials"]})


@app.route("/api/testimonial-people/<project>/<pid>/generate", methods=["POST"])
def api_generate_tperson(project, pid):
    """Generate a portrait CANDIDATE for a testimonial person (never auto-committed). `fresh` clears old candidates."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    if (request.get_json(silent=True) or {}).get("fresh"):
        for p in d.glob(f"refs/tpcand_{pid}_*"):
            try: p.unlink()
            except Exception as _qe: quiet(_qe, "api_generate_tperson")
    # give each person a DISTINCT setting/outfit (index among the roster) and rotate on every regenerate
    # (count of remaining candidates) so re-rolls also change the scene instead of another kitchen.
    people = doc.get("testimonials", [])
    base_idx = next((i for i, c in enumerate(people) if c.get("id") == pid), 0)
    rot = len(list(d.glob(f"refs/tpcand_{pid}_*")))
    prompt = _tp_portrait_prompt(person, doc.get("audience"), variety_idx=base_idx + rot)
    rel, cerr = _run_char_candidate(d, pid, prompt, [], prefix="tpcand", aspect="1:1")   # square selfie/profile look; nano-banana → GPT fallback inside
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-people/<project>/<pid>/edit-candidate", methods=["POST"])
def api_edit_tperson_candidate(project, pid):
    """Edit a candidate with a typed instruction (image-to-image, NanoBanana) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    if not (rel.startswith("refs/") and str(src).startswith(str((d / "refs").resolve())) and src.exists()):
        return jsonify({"error": "image not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/tpedit/{pid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    rel2, cerr = _run_char_candidate(d, pid, instr_en, [base_url], prefix="tpcand", family="nano-banana-2")
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})


@app.route("/api/testimonial-people/<project>/<pid>/use-candidate", methods=["POST"])
@_locked
def api_use_tperson_candidate(project, pid):
    """Accept a candidate → rename it into a normal image, add to the person, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    person = next((c for c in doc.get("testimonials", []) if c.get("id") == pid), None)
    if person is None:
        return jsonify({"error": "person not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"tpcand_{pid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"tp_{pid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception as _qe: quiet(_qe, "api_use_tperson_candidate")
    for p in d.glob(f"refs/tpcand_{pid}_*"):          # committed one → drop the rest
        try: p.unlink()
        except Exception as _qe: quiet(_qe, "api_use_tperson_candidate")
    person.setdefault("urls", []).append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(person)


@app.route("/api/testimonial-people/<project>/<pid>/discard-candidate", methods=["POST"])
def api_discard_tperson_candidate(project, pid):
    """Throw away un-accepted candidate(s). `all` clears every candidate for this person (on Cancel)."""
    d, _safe = proj_dir(project)
    _discard_candidates(d, "tpcand", pid, request.get_json(silent=True) or {})
    return jsonify({"ok": True})


# ---- routes: written testimonial cards (HTML -> PNG) ------------------------
# The card DESIGN lives entirely in the frontend (single source of truth = the live preview). To export,
# the browser sends the card's self-contained HTML (inline styles + the portrait embedded as a data-URI)
# and we screenshot it with the SAME headless-browser engine as the caption/OST render — so the downloaded
# PNG is pixel-identical to what the user saw.
_TC_RENDER_LOCK = threading.Lock()

def _render_html_png(html, out_png, w, h, scale=2):
    edge = None
    try:
        from caption_layer import edge_exe
        edge = edge_exe()
    except Exception:
        edge = None
    if not edge:
        return False, "no headless browser (Edge/Chrome) found"
    out_png.parent.mkdir(parents=True, exist_ok=True)
    hp = out_png.with_suffix(".html")
    hp.write_text(html, encoding="utf-8")
    # isolated profile: without it, a headless launch hands off to an already-running Edge and never
    # writes the screenshot (produces no image).
    prof = tempfile.mkdtemp(prefix="tcedge_")
    if out_png.exists():
        try: out_png.unlink()
        except Exception as _qe: quiet(_qe, "_render_html_png")
    cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
           "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}",
           f"--force-device-scale-factor={scale}", "--allow-file-access-from-files",
           f"--window-size={int(w)},{int(h)}", f"--screenshot={out_png.resolve()}", hp.resolve().as_uri()]
    err = None
    with _TC_RENDER_LOCK:                                  # serialise renders (one headless Edge at a time)
        try:
            subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=120,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            err = str(e)
        # the headless parent can return BEFORE the screenshot child finishes writing the PNG — wait for the
        # file to appear and its size to settle. The source HTML must stay on disk until then, so we only
        # delete it AFTER (a premature delete makes Edge screenshot an "ERR_FILE_NOT_FOUND" page instead).
        if err is None:
            last = -1
            for _ in range(60):                           # up to ~18s
                if out_png.exists():
                    sz = out_png.stat().st_size
                    if sz > 0 and sz == last:
                        break
                    last = sz
                time.sleep(0.3)
    try: hp.unlink()
    except Exception as _qe: quiet(_qe, "_render_html_png")
    shutil.rmtree(prof, ignore_errors=True)
    if err:
        return False, err
    return (True, None) if (out_png.exists() and out_png.stat().st_size > 0) else (False, "render produced no image")


def _render_html_domdump(html, w, h, scale=2):
    """Run headless Edge on HTML and capture the post-script DOM (--dump-dom). An in-page script
    measures each word's box and writes it into the DOM, so we can read the laid-out word rects for
    the karaoke video. Returns (dom_string, err)."""
    try:
        from caption_layer import edge_exe
        edge = edge_exe()
    except Exception:
        edge = None
    if not edge:
        return None, "no headless browser found"
    prof = tempfile.mkdtemp(prefix="tcdom_")
    hp = Path(prof) / "page.html"
    hp.write_text(html, encoding="utf-8")
    cmd = [edge, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
           "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}",
           f"--force-device-scale-factor={scale}", "--allow-file-access-from-files",
           "--virtual-time-budget=2000", f"--window-size={int(w)},{int(h)}", "--dump-dom",
           hp.resolve().as_uri()]
    out, err = None, None
    with _TC_RENDER_LOCK:
        try:
            r = subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=60,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            out = r.stdout.decode("utf-8", "replace")
        except Exception as e:
            err = str(e)
    shutil.rmtree(prof, ignore_errors=True)
    return (out, None) if err is None else (None, err)


CARD_OUT_W, CARD_OUT_H = 1920, 1080      # every produced testimonial card is delivered at 1080p


def _render_card_1080(html, out_png, w, h, ss=2):
    """Render a 16:9 card layout to EXACTLY 1920x1080. The layout is authored at whatever width the card
    happens to be (1680 normally, more when a long one grows its frame), so it is rasterised at ss times
    the target — supersampling keeps the text edges clean — and resampled down. Returns
    (ok, err, sx, sy): the layout-px to output-px factors, which the karaoke word boxes also need."""
    dsf = (CARD_OUT_W * float(ss)) / float(w)
    ok, err = _render_html_png(html, out_png, w, h, scale=dsf)
    if not ok:
        return False, err, 1.0, 1.0
    try:
        im = Image.open(out_png)
        if im.size != (CARD_OUT_W, CARD_OUT_H):
            im.convert("RGB").resize((CARD_OUT_W, CARD_OUT_H), Image.LANCZOS).save(out_png)
    except Exception as e:
        return False, str(e), 1.0, 1.0
    return True, None, CARD_OUT_W / float(w), CARD_OUT_H / float(h)


@app.route("/api/testimonial-cards/<project>/render", methods=["POST"])
def api_render_testimonial_card(project):
    """Render a written-testimonial card (self-contained HTML from the browser) to a PNG under cards/."""
    if load_doc(project) is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    html = (body.get("html") or "").strip()
    if not html:
        return jsonify({"error": "no card html"}), 400
    try:
        w = max(64, min(4096, int(body.get("w") or 1080)))
        h = max(64, min(8192, int(body.get("h") or 1080)))
    except Exception:
        w, h = 1080, 1080
    (d / "cards").mkdir(parents=True, exist_ok=True)
    fname = f"cards/card_{int(time.time() * 1000)}.png"
    ok, err, _sx, _sy = _render_card_1080(html, d / fname, w, h)
    if not ok:
        return jsonify({"error": err or "render failed"}), 502
    return jsonify({"ok": True, "url": fname})


def _project_words(d):
    """Word-level timings [{s,e,w}] from the aligner's words_*.tsv cache (empty if none)."""
    sd = d / "subtitle"
    out = []
    if not sd.exists():
        return out
    cands = [sd / "words_medium_en_vad.tsv", sd / "words_medium_en.tsv"] + sorted(sd.glob("words_*.tsv"))
    wp = next((p for p in cands if p.exists()), None)
    if not wp:
        return out
    try:
        for ln in wp.read_text(encoding="utf-8").splitlines():
            if not ln.strip():
                continue
            parts = ln.split("\t", 2)
            if len(parts) >= 3:
                out.append({"s": float(parts[0]), "e": float(parts[1]), "w": parts[2]})
    except Exception:
        return []
    return out


def _karaoke_frames_mp4(tmp_dir, html, w, h, words, seg_start, seg_end, out_mp4, audio_path=None, fps=60,
                        rects=None, card_box=None):
    """Render a card HTML (with .kw[data-i] spans + a #__rects measuring script) to an MP4 with the
    cumulative GREEN karaoke burned in (multiply blend → paper turns green, text stays black). words=[{s,e}]
    are on the SAME timeline as seg_start/seg_end. audio_path=None → silent clip. Returns True on success."""
    import json as _json
    tmp_dir.mkdir(parents=True, exist_ok=True)
    stem = out_mp4.stem
    base_png = tmp_dir / f"{stem}_base.png"
    ok, _e, sx, sy = _render_card_1080(html, base_png, int(w), int(h))    # frames are 1920x1080
    if not ok:
        return False
    scale = sx                                       # layout px -> output px, for the word boxes below
    rmap = {}
    # Boxes measured by the browser that drew the card, in CARD coordinates. Preferred over asking a
    # headless Edge, which stopped answering --dump-dom in v151 and returned an empty list — the karaoke
    # then rendered with no green whatsoever and said nothing about it.
    if rects and card_box:
        try:
            ox = (float(w) - float(card_box[0])) / 2.0      # .tc-pad16 centres the card in the 16:9 frame
            oy = (float(h) - float(card_box[1])) / 2.0
            for rr in rects:
                rmap[int(rr["i"])] = ((float(rr["x"]) + ox) * sx, (float(rr["y"]) + oy) * sy,
                                      float(rr["w"]) * sx, float(rr["h"]) * sy)
        except Exception:
            rmap = {}
    if not rmap:                                     # older cards, saved before the browser measured them
        dom, _d = _render_html_domdump(html, int(w), int(h), scale=1)
        if dom:
            m = re.search(r'id="__rects"[^>]*>(.*?)</div>', dom, re.S)
            if m:
                try:
                    for rr in _json.loads(m.group(1).strip() or "[]"):
                        rmap[int(rr["i"])] = (float(rr["x"]) * sx, float(rr["y"]) * sy,
                                              float(rr["w"]) * sx, float(rr["h"]) * sy)
                except Exception:
                    rmap = {}
    from PIL import Image, ImageDraw, ImageChops
    base = Image.open(base_png).convert("RGB")
    green_full = Image.new("RGB", base.size, (143, 227, 106))
    pad = int(2 * scale)
    # Precomputed once: the fully-green version of the card. The mask decides how much of it shows, so
    # the expensive multiply does not run per frame.
    green_base = ImageChops.multiply(base, green_full)
    # How finely the edge is redrawn. It MUST be finer than the distance the edge covers in one frame,
    # or frames come out identical and the motion stalls — that is the same trap twice: 12px was too
    # coarse at 30fps, and 3px became too coarse again at 60fps. So it is derived, not guessed.
    SWEEP_PX = 3.0             # replaced below once the total distance is known
    GLIDE = 0.15               # absorb gaps up to this into the sweep so the edge keeps moving between
                               # words; a longer pause still holds, which is what a pause should do
    fdir = tmp_dir / f"{stem}_f"; fdir.mkdir(parents=True, exist_ok=True)
    saved = {}

    # Words in speaking order, each with a real duration. The green sweeps ACROSS a word over that word's
    # own span instead of the whole word snapping on: stepping block by block is what read as "pop, pop,
    # pop". No anticipation is needed any more — the leading edge IS where the voice is.
    wt = []
    for _wi, _wd in enumerate(words):
        _s = float(_wd.get("s", 0.0)); _e = float(_wd.get("e", _s))
        if _s >= seg_end:
            continue
        wt.append((_wi, max(seg_start, _s), max(_s + 0.06, _e)))
    wt.sort(key=lambda x: x[1])

    def _lines_union(parts):
        """Merge word rectangles into one bar per text line (a line's words are adjacent, so the union
        reads as a single continuous highlight rather than separate blocks)."""
        lines = {}
        for (x0, y0, x1, y1) in parts:
            k = round(y0 / (6 * scale))
            if k in lines:
                a = lines[k]; lines[k] = (min(a[0], x0), min(a[1], y0), max(a[2], x1), max(a[3], y1))
            else:
                lines[k] = (x0, y0, x1, y1)
        return lines

    def _compose(parts):
        if not parts:
            return base
        mask = Image.new("L", base.size, 0); dr = ImageDraw.Draw(mask)
        for (x0, y0, x1, y1) in _lines_union(parts).values():
            dr.rectangle([x0 - pad, y0 - pad, x1 + pad, y1 + pad], fill=255)
        return Image.composite(green_base, base, mask)

    def path_for(key, img):
        if key in saved:
            return saved[key]
        p = fdir / f"{key}.png"
        img.save(p, compress_level=1)      # thousands of these get written; level 1 is ~3x faster and
        saved[key] = p                     # they are deleted as soon as ffmpeg has read them
        return p

    def img_all():                                     # every card word green — the final held frame, so a last word the aligner dropped still lights
        return _compose([(rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3]) for rc in rmap.values()])

    # The edge's position is one number: how far it has travelled along the text, in reading order. Word
    # onsets are ANCHORS on that curve — at word k's onset the edge is exactly at word k's left edge, which
    # is what keeps the right word lit at the right moment. Between anchors the curve is a MONOTONE CUBIC
    # (Fritsch-Carlson), not a straight line: straight lines meet at an angle, so the edge changed speed
    # abruptly at every single word and that is what still felt jerky. A cubic changes speed gradually and
    # never goes backwards.
    pieces = []                                      # (x0, y0, x1, y1) in reading order
    at_word = []                                     # distance along `pieces` where each word starts
    run = 0.0
    for _i, (_wi, _s0, _e0) in enumerate(wt):
        rc = rmap.get(_wi)
        if not rc:
            at_word.append(None); continue
        at_word.append(run)
        pieces.append((rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3])); run += rc[2]
        if _i + 1 < len(wt):
            nxt = rmap.get(wt[_i + 1][0])
            if nxt and abs(nxt[1] - rc[1]) < 6 * scale and nxt[0] > rc[0] + rc[2]:
                pieces.append((rc[0] + rc[2], rc[1], nxt[0], rc[1] + rc[3])); run += nxt[0] - (rc[0] + rc[2])
    total_px = run
    _travel = total_px / max(0.5, (seg_end - seg_start) * float(fps))   # px the edge covers in one frame
    SWEEP_PX = max(1.0, min(4.0, _travel / 1.6))

    anchors = []                                     # (time, distance) strictly increasing in both
    for _i, (_wi, _s0, _e0) in enumerate(wt):
        if at_word[_i] is None:
            continue
        if anchors and _s0 <= anchors[-1][0] + 1e-3:
            continue
        anchors.append((_s0, at_word[_i]))
    if anchors:
        anchors.append((max(anchors[-1][0] + 0.06, wt[-1][2]), total_px))

    # Some onsets are 20ms apart. That is not speech — it is the aligner's monotonicity floor, applied
    # when it cannot separate two words, and following it literally made the edge cover a whole word in
    # one frame: 5800 px/s against a 289 px/s median. Anchors that would demand more than CAP are pulled
    # EARLIER so the edge has time to get there. Borrowing only from the interval immediately before was
    # not enough — several 20ms onsets in a row leave that one neighbour with nothing to give — so the
    # pass runs BACKWARDS and cascades. Measured cost on a real card: no anchor moves more than 0.14s,
    # which is well under what reads as early, and the top speed halves.
    if len(anchors) > 3:
        _t = [a[0] for a in anchors]; _d = [a[1] for a in anchors]
        _sp = sorted((_d[i + 1] - _d[i]) / max(1e-3, _t[i + 1] - _t[i]) for i in range(len(_t) - 1))
        _cap = 2.5 * max(1.0, _sp[len(_sp) // 2])
        _orig = list(_t)
        for i in range(len(_t) - 2, -1, -1):          # BACKWARDS, so the fix cascades: making room for one
            need = (_d[i + 1] - _d[i]) / _cap         # interval can starve the one before it, and the next
            if _t[i + 1] - _t[i] < need:              # step of the same loop then fixes that one too.
                _t[i] = max(seg_start, min(_t[i], _t[i + 1] - need))
        for i in range(len(_t)):                      # never drag a word more than this far ahead of its
            _t[i] = max(_t[i], _orig[i] - 0.18)       # own onset, whatever a pathological card asks for
        for i in range(1, len(_t)):
            if _t[i] <= _t[i - 1]:
                _t[i] = _t[i - 1] + 1e-3
        anchors = [(_t[i], _d[i]) for i in range(len(_t))]

    # LINEAR between anchors, not a cubic. A monotone cubic was the obvious idea and it measured worse:
    # it keeps changing speed INSIDE each interval, while a straight line holds one speed all the way from
    # one word to the next and only changes at the handover. Per-frame speed variation went 3.26 -> 3.90px
    # when I tried the cubic, so the straight line stays.
    _ts = [a[0] for a in anchors]; _ds = [a[1] for a in anchors]

    def dist_at(t):
        if not anchors or t <= _ts[0]:
            return 0.0
        if t >= _ts[-1]:
            return total_px
        k = bisect.bisect_right(_ts, t) - 1
        h = _ts[k + 1] - _ts[k]
        return _ds[k] + (_ds[k + 1] - _ds[k]) * ((t - _ts[k]) / h)

    def state_at(t):
        return (int(dist_at(t) / SWEEP_PX),)

    def frame_for(st):
        key = "d%d" % st[0]
        if key in saved:
            return saved[key]
        left = st[0] * SWEEP_PX
        parts = []
        for (x0, y0, x1, y1) in pieces:
            if left <= 0:
                break
            take = min(x1 - x0, left)
            parts.append((x0, y0, x0 + take, y1)); left -= take
        return path_for(key, _compose(parts))

    lines_txt = []
    if pieces and anchors:
        step = 1.0 / float(fps)
        cur_st, run, t = None, 0.0, seg_start
        while t < seg_end - 1e-6:
            st = state_at(t)
            if cur_st is None:
                cur_st, run = st, step
            elif st == cur_st:
                run += step
            else:
                fp = frame_for(cur_st)
                lines_txt.append(f"file '{fp.resolve().as_posix()}'"); lines_txt.append(f"duration {run:.6f}")
                cur_st, run = st, step
            t += step
        if cur_st is not None:
            fp = frame_for(cur_st)
            lines_txt.append(f"file '{fp.resolve().as_posix()}'"); lines_txt.append(f"duration {run:.6f}")
    else:                                              # no word boxes → hold the plain card
        p0 = path_for("plain", base)
        lines_txt.append(f"file '{p0.resolve().as_posix()}'")
        lines_txt.append(f"duration {max(0.04, seg_end - seg_start):.3f}")
    tail_p = path_for("sALL", img_all())
    lines_txt.append(f"file '{tail_p.resolve().as_posix()}'"); lines_txt.append("duration 1.500")   # pad past the scene end so the render's trim (scene dur + xfade overlap) always has footage — otherwise everything after this scene desyncs
    lines_txt.append(f"file '{tail_p.resolve().as_posix()}'")
    listf = fdir / "list.txt"; listf.write_text("\n".join(lines_txt), encoding="utf-8")
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(listf)]
    if audio_path:
        cmd += ["-i", str(audio_path)]
    cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p", "-r", str(int(fps)), "-c:v", "libx264"]
    cmd += (["-c:a", "aac", "-shortest"] if audio_path else ["-an"])
    cmd += ["-movflags", "+faststart", str(out_mp4)]
    try:
        subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=600)
    except Exception:
        return False
    try:
        base_png.unlink()
    except OSError as _qe:
        quiet(_qe, "_karaoke_frames_mp4")
    shutil.rmtree(fdir, ignore_errors=True)
    return out_mp4.exists() and out_mp4.stat().st_size > 0


def _align_words_to_text(all_words, text, hint_start=None):
    """Sequence-align the card words to the VO word stream (anchored near the scene start): each card word
    gets its real time; VO words the card lacks (a narrator intro) are skipped; card words not in the VO
    (edits/typos) inherit the previous word's time. Returns one timed word per card word. [] if no match."""
    def _n(s):
        return re.sub(r'[^a-z0-9]', '', (s or '').lower())
    cw = [c for c in (_n(t) for t in (text or '').split()) if c]
    if not cw or not all_words:
        return []
    vw = [_n(w.get('w', '')) for w in all_words]
    vi = 0
    if hint_start is not None:
        for i, w in enumerate(all_words):
            if float(w.get('s', 0)) >= hint_start - 0.4:
                vi = i
                break
    out = [None] * len(cw)
    for ci in range(len(cw)):
        hit = -1
        for k in range(0, 9):
            if vi + k < len(vw) and vw[vi + k] == cw[ci]:
                hit = vi + k
                break
        if hit >= 0:
            out[ci] = all_words[hit]
            vi = hit + 1
    last = None
    for ci in range(len(cw)):
        if out[ci]:
            last = out[ci]
        elif last:
            out[ci] = {"s": last["s"], "e": last["e"], "w": cw[ci]}
    first = next((x for x in out if x), None)
    if first:
        for ci in range(len(cw)):
            if not out[ci]:
                out[ci] = {"s": first["s"], "e": first["e"], "w": cw[ci]}
    return [x for x in out if x]


def _apply_custom_testimonial_vo(project, doc, tl):
    """If a written-testimonial scene has its OWN voice-over (card.extra.vo + vo_dur), splice that clip into
    the project VO in place of the original span (so the testimonial's duration = the custom clip's length),
    rebuild the VO audio, and remap every scene/caption/music time so everything after shifts.
    No custom voices → returns tl unchanged (normal projects are untouched). Fail-safe: any error → original tl."""
    try:
        d = tl["dir"]
        cards = {c.get("id"): c for c in doc.get("testimonial_cards", [])}
        dscenes = {s.get("id"): s for s in doc.get("scenes", [])}
        splices = []
        for sc in tl["scenes"]:
            ds = dscenes.get(sc.get("id"))
            if not ds or not ds.get("tcard_id"):
                continue
            card = cards.get(ds["tcard_id"])
            if not card:
                continue
            ex = card.get("extra") or {}
            vo, dur = ex.get("vo"), ex.get("vo_dur")
            if not vo or not dur or float(dur) <= 0.1:
                continue
            p = (d / vo).resolve()
            try:
                p.relative_to(d.resolve())
            except Exception:
                continue
            if not p.exists():
                continue
            splices.append({"id": sc["id"], "s": float(sc["start"]), "e": float(sc["end"]), "dur": float(dur), "audio": p})
        if not splices:
            return tl
        splices.sort(key=lambda x: x["s"])
        total = float(tl["total"])
        src_vo = Path(tl["vo"])
        tmp = d / "export" / "_tvo"
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)

        def _seg(src, ss, to, out, is_clip=False):
            cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
            if is_clip:
                cmd += ["-i", str(src), "-t", f"{to:.3f}"]
            else:
                cmd += ["-ss", f"{ss:.3f}", "-to", f"{to:.3f}", "-i", str(src)]
            cmd += ["-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "192k", str(out)]
            subprocess.run(cmd, creationflags=_NO_WINDOW, timeout=240)
            return out.exists() and out.stat().st_size > 0

        parts, cur = [], 0.0
        for sp in splices:
            if sp["s"] - cur > 0.02:
                kp = tmp / f"p{len(parts):03d}.m4a"
                if _seg(src_vo, cur, sp["s"], kp):
                    parts.append(kp)
            src_clip = sp["audio"]
            try:   # bring the custom testimonial voice to the SAME VSL loudness as the (already-normalized) main VO — cached next to the clip so we only normalize once
                ncache = sp["audio"].with_name(sp["audio"].stem + "_norm.wav")
                if ncache.exists() and ncache.stat().st_mtime >= sp["audio"].stat().st_mtime:
                    src_clip = ncache
                else:
                    nrm = premiere_export.normalize_loudness(sp["audio"], ncache)
                    if nrm:
                        src_clip = nrm
            except Exception as _qe:
                quiet(_qe, "_apply_custom_testimonial_vo")
            cp = tmp / f"p{len(parts):03d}.m4a"
            if _seg(src_clip, 0, sp["dur"], cp, is_clip=True):
                parts.append(cp)
            cur = sp["e"]
        if total - cur > 0.02:
            kp = tmp / f"p{len(parts):03d}.m4a"
            if _seg(src_vo, cur, total, kp):
                parts.append(kp)
        if not parts:
            return tl
        # concat the audio parts (filter, not demuxer → no aac gap/timestamp issues)
        inputs = []
        for p in parts:
            inputs += ["-i", str(p)]
        fc = "".join(f"[{i}:a]" for i in range(len(parts))) + f"concat=n={len(parts)}:v=0:a=1[a]"
        spliced = d / "export" / "voiceover_tvo.m4a"
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *inputs,
                        "-filter_complex", fc, "-map", "[a]", "-c:a", "aac", "-b:a", "192k", str(spliced)],
                       creationflags=_NO_WINDOW, timeout=600)
        if not (spliced.exists() and spliced.stat().st_size > 0):
            return tl
        # piecewise time map: keep spans map 1:1, each replaced span maps [s,e] → [n, n+dur]
        segmap, cur_o, cur_n = [], 0.0, 0.0
        for sp in splices:
            if sp["s"] > cur_o:
                segmap.append((cur_o, sp["s"], cur_n, cur_n + (sp["s"] - cur_o))); cur_n += (sp["s"] - cur_o)
            segmap.append((sp["s"], sp["e"], cur_n, cur_n + sp["dur"])); cur_n += sp["dur"]
            cur_o = sp["e"]
        tail = total - cur_o
        segmap.append((cur_o, total, cur_n, cur_n + max(0.0, tail)))
        new_total = cur_n + max(0.0, tail)

        def remap(t):
            t = max(0.0, min(float(t), total))
            for (o0, o1, n0, n1) in segmap:
                if t <= o1 + 1e-6:
                    return n0 if (o1 - o0) < 1e-6 else n0 + (t - o0) / (o1 - o0) * (n1 - n0)
            return new_total

        for sc in tl["scenes"]:
            sc["start"], sc["end"] = remap(sc["start"]), remap(sc["end"])
        for c in tl.get("captions", []):
            c["start"], c["end"] = remap(c["start"]), remap(c["end"])
        for mseg in tl.get("music", []):
            mseg["start"], mseg["end"] = remap(mseg["start"]), remap(mseg["end"])
        tl["vo"] = spliced
        tl["total"] = round(new_total, 3)
        tl["_tvo_ids"] = {sp["id"] for sp in splices}   # scenes now driven by a custom clip (karaoke uses the clip's own words)
        tl["_tvo_segmap"] = segmap                       # piecewise time map (for the Premiere XML: remap its SRT + words the same way)
        try:   # remap the ORIGINAL word timings too, so a LATER (non-custom) testimonial's karaoke stays in sync after the shift
            tl["words_remapped"] = [{"s": round(remap(w["s"]), 3), "e": round(remap(w["e"]), 3), "w": w.get("w", "")} for w in _project_words(d)]
        except Exception as _qe:
            quiet(_qe, "_apply_custom_testimonial_vo")
        return tl
    except Exception:
        return tl


def _seg_remap(segmap, t):
    """Map an original time onto the spliced timeline using the piecewise segmap from _apply_custom_testimonial_vo."""
    if not segmap:
        return float(t)
    t = max(0.0, float(t))
    for (o0, o1, n0, n1) in segmap:
        if t <= o1 + 1e-6:
            return n0 if (o1 - o0) < 1e-6 else n0 + (t - o0) / (o1 - o0) * (n1 - n0)
    return segmap[-1][3]


def _inject_testimonial_karaoke(project, doc, tl, tmp_dir):
    """Before rendering: swap each WRITTEN-testimonial scene's STILL for a same-duration clip with the green
    karaoke burned in (audio stays the main VO track). Fully guarded — any failure leaves the still as-is."""
    try:
        cards = {c.get("id"): c for c in doc.get("testimonial_cards", [])}
        dscenes = {s.get("id"): s for s in doc.get("scenes", [])}
        words_all = tl.get("words_remapped") or _project_words(tl["dir"])   # after a custom-VO splice, use the REMAPPED word times so later testimonials stay in sync
    except Exception:
        return
    if not words_all:
        return
    tmp_dir = Path(tmp_dir); tmp_dir.mkdir(parents=True, exist_ok=True)
    windows = []                                    # (testimonial_body_start, scene_end): drop the burned subtitle here (keep any narrator intro before it)
    for sc in tl.get("scenes", []):
        try:
            ds = dscenes.get(sc.get("id"))
            if not ds or not ds.get("tcard_id"):
                continue
            card = cards.get(ds["tcard_id"])
            if not card or card.get("type") == "video":
                continue
            start, end = float(sc["start"]), float(sc["end"])
            sc["no_zoom"] = True                 # never Ken-Burns-zoom a testimonial card (karaoke clip OR still fallback)
            ex = card.get("extra") or {}
            if sc.get("id") in tl.get("_tvo_ids", set()) and ex.get("words") and ex.get("vo_dur"):
                words = [{"s": start + float(w.get("s", 0)), "e": start + float(w.get("e", 0)), "w": w.get("w", "")} for w in ex["words"]]   # this scene now plays the CUSTOM clip → use its own 0-based alignment, offset to the new scene start
            else:
                words = _align_words_to_text(words_all, card.get("text"), start)   # exact card words from the full stream (correct last-word timing)
                if not words:
                    words = [wd for wd in words_all if wd["s"] >= start - 0.05 and wd["s"] < end + 0.5]
            windows.append((start, end))            # no subtitle at all over a written-testimonial scene
            kara = (card.get("extra") or {}).get("kara") or {}
            html = _kara_html(proj_dir(project)[0], kara); kw = kara.get("w") or 0; kh = kara.get("h") or 0
            if sc.get("kind") == "image" and sc.get("path") and html and kw > 10 and kh > 10:   # skip a broken (0×0) kara → keep the still
                out_mp4 = tmp_dir / f"kara_{sc['id']}.mp4"
                if _karaoke_frames_mp4(tmp_dir, html, kw, kh, words, start, end, out_mp4, audio_path=None,
                                       fps=int(getattr(render_video, "FPS", 30)),     # match the render fps so the fade is smooth (no frame-doubling)
                                       rects=kara.get("rects"),
                                       card_box=((kara.get("cw"), kara.get("ch")) if kara.get("cw") and kara.get("ch") else None)):
                    sc["kind"] = "video"; sc["path"] = out_mp4
        except Exception:
            continue
    if windows:                                     # strip captions that fall inside the testimonial BODY (keep the intro)
        def _in_win(c):
            cs, ce = float(c.get("start", 0)), float(c.get("end", 0))
            return any(cs < we and ce > ws - 0.05 for (ws, we) in windows)
        tl["captions"] = [c for c in tl.get("captions", []) if not _in_win(c)]


@app.route("/api/testimonial-cards/<project>/<cid>/video", methods=["POST"])
def api_tcard_video(project, cid):
    """Render a testimonial card to an MP4 with the word-level GREEN karaoke burned in + the voice-over.
    Client sends the card HTML (words wrapped in .kw[data-i] + a measuring script that writes each word's
    box into #__rects), the word timings [{s,e}] (absolute VO seconds), and the [start,end] VO slice."""
    import json as _json, math as _math
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    html = (body.get("html") or "").strip()
    if not html:
        return jsonify({"error": "no card html"}), 400
    try:
        w = max(64, min(4096, int(body.get("w") or 1080)))
        h = max(64, min(8192, int(body.get("h") or 1080)))
    except Exception:
        w, h = 1080, 1080
    words = body.get("words") or []                     # [{s,e}] absolute VO seconds, index-aligned to .kw[data-i]
    try:
        start = float(body.get("start")); end = float(body.get("end"))
    except Exception:
        return jsonify({"error": "missing segment times"}), 400
    if end <= start:
        return jsonify({"error": "bad segment"}), 400
    (d / "cards").mkdir(parents=True, exist_ok=True)
    ts = int(time.time() * 1000)
    # audio source: a card's CUSTOM voice-over if given (whole clip, 0-based times), else the ORIGINAL
    # project VO (its word times are aligned to it), sliced to [start,end]
    audio_rel = (body.get("audio") or "").strip()
    if audio_rel:
        src_vo = (d / audio_rel).resolve()
        try:
            src_vo.relative_to(d.resolve())
        except Exception:
            return jsonify({"error": "bad audio path"}), 400
        if not src_vo.exists():
            return jsonify({"error": "voice-over file not found"}), 400
    else:
        src_vo = _find_vo_audio(d)
        if not src_vo:
            return jsonify({"error": "no voice-over found — generate the SRT first"}), 400
    seg_audio = d / f"cards/vid_{ts}_a.m4a"
    try:
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}",
                        "-to", f"{end:.3f}", "-i", str(src_vo), "-c:a", "aac", "-b:a", "160k", str(seg_audio)],
                       creationflags=_NO_WINDOW, timeout=120)
    except Exception as e:
        return jsonify({"error": "audio extract failed: " + str(e)}), 502

    # ONE painter for the karaoke, shared with the render and the Premiere export. This endpoint used to
    # carry its own copy — a cumulative frame per word onset — so the download kept stepping block by
    # block long after the preview and the render had been changed to a continuous sweep.
    out_mp4 = d / f"cards/testimonial_{ts}.mp4"
    tmpd = d / f"cards/_tv_{ts}"
    okv = _karaoke_frames_mp4(tmpd, html, w, h, words, start, end, out_mp4, audio_path=seg_audio, fps=60,
                              rects=body.get("rects"), card_box=(body.get("cw"), body.get("ch"))
                              if body.get("cw") and body.get("ch") else None)
    for _p in (seg_audio,):
        try: _p.unlink()
        except OSError as _qe: quiet(_qe, "api_tcard_video")
    shutil.rmtree(tmpd, ignore_errors=True)
    if not okv or not out_mp4.exists() or out_mp4.stat().st_size == 0:
        return jsonify({"error": "video not produced"}), 502
    return jsonify({"ok": True, "url": f"cards/testimonial_{ts}.mp4"})


def _tcard_align(project, cid, body, on_step=None):
    """Forced-align a card's CUSTOM voice-over (card.extra.vo) to its text → 0-based word timings stored
    on the card (card.extra.words + vo_dur). Lets the karaoke sync to a user-supplied voice without
    re-running the whole VSL SRT. Runs the same MMS-FA aligner as the SRT job, on just this clip.

    Returns (result_dict, None) or (None, (error_message, http_code)). on_step(pct, label) is called as
    the aligner reports its stages, so the caller can drive a progress bar; it runs off the request
    thread in the job variant, hence body is passed in rather than read from `request` here."""
    doc = load_doc(project)
    if doc is None:
        return None, ("project not found", 404)
    card = next((c for c in doc.get("testimonial_cards", []) if c.get("id") == cid), None)
    if card is None:
        return None, ("card not found", 404)
    ex = card.get("extra") or {}
    # prefer the client-supplied vo/text (the voiceover endpoint doesn't persist them server-side yet, so the
    # saved doc may still be catching up) — fall back to whatever is on the card
    vo = (body.get("vo") or ex.get("vo") or "").strip()
    text = (body.get("text") or card.get("text") or "").strip()
    if not vo:
        return None, ("no custom voice-over on this card", 400)
    if not text:
        return None, ("the testimonial has no text to align", 400)
    d, safe = proj_dir(project)
    audio = (d / vo).resolve()
    try:
        audio.relative_to(d.resolve())
    except Exception:
        return None, ("bad audio path", 400)
    if not audio.exists():
        return None, ("voice-over file not found", 400)
    wd = d / "subtitle"; wd.mkdir(parents=True, exist_ok=True)
    tf = wd / f"clip_{cid}.txt"; tf.write_text(text, encoding="utf-8")
    of = wd / f"clip_{cid}.json"
    try:
        if of.exists():
            of.unlink()
    except OSError as _qe:
        quiet(_qe, "_tcard_align")
    script = SUBTITLE_TOOLS / "align_clip.py"
    if not script.exists():
        return None, ("aligner not found", 500)
    # Align in the PROJECT's language. This was pinned to the English model, so a German or French
    # testimonial voice-over was force-aligned as English: the words landed in roughly the right region but
    # not on the right syllables, which is why the karaoke crawled to a word, skipped several, then caught up.
    _lang = audience_lang(doc.get("audience")) or "en"
    env = dict(os.environ, VSL_CLIP_AUDIO=str(audio), VSL_CLIP_TEXT=str(tf),
               VSL_CLIP_OUT=str(of), VSL_CLIP_MODEL=_align_models(_lang)[0], VSL_CLIP_LANG=_lang)
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_c):
                exe = _c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    # Popen, not run(): the aligner prints "[clip] PROGRESS <pct> <label>" as it goes, and reading those
    # lines as they arrive is what lets the UI show a real bar instead of a spinner. Loading the model is
    # most of the wall time, so without the stages the toast would sit at 0 for almost the whole job.
    out_lines = []
    try:
        proc = subprocess.Popen([exe, str(script)], env=env, cwd=str(wd), startupinfo=si, creationflags=cf,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        deadline = time.time() + 900
        for raw in iter(proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line:
                out_lines.append(line)
            m = re.match(r"\[clip\] PROGRESS (\d+) (.+)", line)
            if m and on_step:
                try:
                    on_step(int(m.group(1)), m.group(2))
                except Exception as _qe:
                    quiet(_qe, "_tcard_align")
            if time.time() > deadline:
                proc.kill()
                return None, ("alignment timed out", 502)
        proc.stdout.close()
        proc.wait(timeout=30)
    except Exception as e:
        return None, ("alignment failed: " + str(e), 502)
    if not of.exists():
        return None, ("alignment produced no timings. " + "\n".join(out_lines)[-400:], 502)
    try:
        words = json.loads(of.read_text(encoding="utf-8"))
    except Exception:
        return None, ("could not read alignment output", 502)
    dur = round(max([float(w.get("e", 0)) for w in words], default=0.0), 3)
    card.setdefault("extra", {})["words"] = words
    card["extra"]["vo_dur"] = dur
    card["extra"]["words_lang"] = _lang        # stamp it: Reload re-aligns cards timed in another language
    save_doc(project, doc)
    try:
        tf.unlink(); of.unlink()
    except OSError as _qe:
        quiet(_qe, "_tcard_align")
    return {"ok": True, "words": words, "dur": dur, "count": len(words), "lang": _lang}, None


@app.route("/api/testimonial-cards/<project>/<cid>/align", methods=["POST"])
def api_tcard_align(project, cid):
    """Blocking align — used where the caller drives its own progress (the Reload re-align sweep)."""
    res, err = _tcard_align(project, cid, request.get_json(silent=True) or {})
    if err:
        return jsonify({"error": err[0]}), err[1]
    return jsonify(res)


# ---------- the same align as a JOB, so a single card's upload can show a real progress bar ----------
_TCA_JOBS = {}
_TCA_LOCK = threading.Lock()


@app.route("/api/testimonial-cards/<project>/<cid>/align-job", methods=["POST"])
def api_tcard_align_job(project, cid):
    body = request.get_json(silent=True) or {}
    jid = "tca-%d" % int(time.time() * 1000)
    with _TCA_LOCK:
        _TCA_JOBS[jid] = {"status": "running", "pct": 2, "step": "Preparing…", "error": None, "result": None}

    def on_step(pct, label):
        with _TCA_LOCK:
            j = _TCA_JOBS.get(jid)
            if j:
                j.update(pct=pct, step=label)

    def run():
        try:
            res, err = _tcard_align(project, cid, body, on_step)
        except Exception as e:                      # never leave the toast spinning on an unexpected fault
            res, err = None, (str(e), 500)
        with _TCA_LOCK:
            j = _TCA_JOBS.get(jid)
            if not j:
                return
            if err:
                j.update(status="error", error=err[0])
            else:
                j.update(status="done", pct=100, step="Done", result=res)

    _KeyThread(target=run, daemon=True).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/tcard-align-job/<jid>")
def api_tcard_align_job_status(jid):
    with _TCA_LOCK:
        j = _TCA_JOBS.get(jid)
        if not j:
            return jsonify({"status": "error", "error": "unknown job", "pct": 0, "step": ""})
        out = dict(j)
        if out["status"] in ("done", "error"):
            _TCA_JOBS.pop(jid, None)                # one-shot: the client has it now, don't leak the words
    return jsonify(out)



# ================================ UPSELL & DOWNSELL ==============================================
# A Studio view for the short lip-synced videos that follow the VSL: one card per offer, each holding a
# still of the presenter, a voice-over (uploaded or generated), a prompt and a seed, and the video the
# lip-sync model returns. Data lives beside the FAQ's, in the same per-scope studio folder, so a
# project's upsells travel with the project and the global Studio keeps its own.
UD_MODEL = "wavespeed-ai/infinitetalk"       # placeholder until the real model id is confirmed
_UD_JOBS = {}
_UD_LOCK = threading.Lock()


def _ud_dir(scope):
    base = _studio_dir(scope) / "upsell"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _ud_clean_cues(v):
    """Cues are stored on the card so the preview can paint captions without re-reading the .srt."""
    out = []
    if not isinstance(v, list):
        return out
    for c in v[:2000]:
        if not isinstance(c, dict):
            continue
        try:
            out.append({"start": round(float(c.get("start") or 0), 3),
                        "end": round(float(c.get("end") or 0), 3),
                        "text": str(c.get("text") or "")[:400]})
        except Exception:
            continue
    return out


def _ud_load(scope):
    p = _ud_dir(scope) / "upsell.json"
    if not p.exists():
        return {"cards": []}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {"cards": []}
    except Exception:
        return {"cards": []}


def _ud_save(scope, state):
    (_ud_dir(scope) / "upsell.json").write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


@app.route("/api/upsell/state/<scope>")
def api_ud_state(scope):
    return jsonify(_ud_load(scope))


@app.route("/api/upsell/state/<scope>", methods=["POST"])
def api_ud_state_save(scope):
    body = request.get_json(force=True) or {}
    cards = body.get("cards")
    if not isinstance(cards, list):
        return jsonify({"error": "cards must be a list"}), 400
    clean = []
    for c in cards[:50]:
        if not isinstance(c, dict):
            continue
        clean.append({
            "id": str(c.get("id") or new_uid()),
            "kind": "downsell" if str(c.get("kind")) == "downsell" else "upsell",
            "title": str(c.get("title") or "")[:120],
            "image": str(c.get("image") or "")[:300],
            "vo": str(c.get("vo") or "")[:300],
            "script": str(c.get("script") or "")[:8000],
            "prompt": str(c.get("prompt") or "")[:4000],
            "seed": str(c.get("seed") or "")[:20],
            "voice_id": str(c.get("voice_id") or "")[:80],
            "lang": str(c.get("lang") or "en")[:5],
            "video": str(c.get("video") or "")[:300],
            "srt": str(c.get("srt") or "")[:300],
            # --- the lip-sync section keeps its own voice-over, so a card can speak one take and
            # lip-sync another; use_vo_above says which one Generate Video actually sends.
            "vo2": str(c.get("vo2") or "")[:300],
            "use_vo_above": bool(c.get("use_vo_above", True)),
            "quality": "480p" if str(c.get("quality")) == "480p" else "720p",
            "caplang": str(c.get("caplang") or c.get("lang") or "en")[:5],
            "cues": _ud_clean_cues(c.get("cues")),
            "style": c.get("style") if isinstance(c.get("style"), dict) else {},
        })
    st = _ud_load(scope)
    st["cards"] = clean
    _ud_save(scope, st)
    return jsonify({"ok": True, "count": len(clean)})


@app.route("/api/upsell/upload/<scope>/<cid>/<kind>", methods=["POST"])
def api_ud_upload(scope, cid, kind):
    """One endpoint for both the presenter still and the voice-over - same checks, same folder."""
    if kind not in ("image", "vo"):
        return jsonify({"error": "bad kind"}), 400
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    ext = os.path.splitext(f.filename)[1].lower()
    ok_ext = ({".png", ".jpg", ".jpeg", ".webp"} if kind == "image"
              else {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus"})
    if ext not in ok_ext:
        return jsonify({"error": "unsupported file type " + ext}), 400
    safe = re.sub(r"[^A-Za-z0-9_-]", "", str(cid))[:40] or "card"
    name = "%s_%s_%d%s" % (kind, safe, int(time.time() * 1000), ext)
    (_ud_dir(scope) / name).write_bytes(f.read())
    return jsonify({"ok": True, "url": name})


@app.route("/api/upsell/file/<scope>/<path:name>")
def api_ud_file(scope, name):
    base = _ud_dir(scope).resolve()
    p = (base / name).resolve()
    try:
        p.relative_to(base)
    except Exception:
        abort(404)
    if not p.exists():
        abort(404)
    return send_file(str(p))


@app.route("/api/upsell/voiceover/<scope>/<cid>", methods=["POST"])
def api_ud_voiceover(scope, cid):
    """Generate the voice-over through ElevenLabs - the same call the VSL voice-over makes, so a voice
    that works there works here."""
    err = _keys_ok(("elevenlabs",))
    if err:
        return err
    body = request.get_json(force=True) or {}
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            "https://api.elevenlabs.io/v1/text-to-speech/" + voice_id,
            headers={"xi-api-key": _key('ELEVENLABS_API_KEY'), "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL,
                  "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": "request failed: %s" % e}), 502
    if r.status_code != 200:
        return jsonify({"error": "ElevenLabs %s" % r.status_code}), 502
    safe = re.sub(r"[^A-Za-z0-9_-]", "", str(cid))[:40] or "card"
    name = "vo_%s_%d.mp3" % (safe, int(time.time() * 1000))
    (_ud_dir(scope) / name).write_bytes(r.content)
    return jsonify({"ok": True, "url": name})


def _ud_video_worker(jid, scope, cid, image, vo, prompt, seed, quality):
    j = _UD_JOBS[jid]
    try:
        with _UD_LOCK:
            j.update(status="running", pct=5, step="Preparing the still and the voice-over...")
        key = (_key('WAVESPEED_API_KEY') or "").strip()
        if not key:
            with _UD_LOCK:
                j.update(status="error", error="Add your WaveSpeed API key in Settings, Keys.")
            return
        # The submit/poll against UD_MODEL goes here once the key and the model's documentation are in.
        # Everything around it - the job, the progress the UI polls, where the finished file lands - is
        # already the shape the real call needs, so wiring it is one function body.
        with _UD_LOCK:
            j.update(status="error",
                     error="The lip-sync model is not connected yet - waiting on the API key and the model docs.")
    except Exception as e:
        with _UD_LOCK:
            j.update(status="error", error=str(e)[:300])


@app.route("/api/upsell/video/<scope>/<cid>", methods=["POST"])
def api_ud_video(scope, cid):
    body = request.get_json(force=True) or {}
    image = (body.get("image") or "").strip()
    vo = (body.get("vo") or "").strip()
    if not image:
        return jsonify({"error": "add a presenter image first"}), 400
    if not vo:
        return jsonify({"error": "add or generate a voice-over first"}), 400
    jid = "ud-%d" % int(time.time() * 1000)
    with _UD_LOCK:
        _UD_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None, "url": None}
    quality = "480p" if str(body.get("quality")) == "480p" else "720p"
    _KeyThread(target=_ud_video_worker, daemon=True,
                     args=(jid, scope, cid, image, vo, (body.get("prompt") or "").strip(),
                           (body.get("seed") or "").strip(), quality)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/upsell/video-job/<jid>")
def api_ud_video_job(jid):
    with _UD_LOCK:
        j = _UD_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


def _docx_to_text(raw, filename):
    """Plain text out of an uploaded script file. python-docx when it is importable, otherwise the
    document.xml straight out of the zip - the app must not depend on an optional package to read a
    file the user just picked."""
    if filename.lower().endswith(".txt"):
        return raw.decode("utf-8", "ignore")
    import io
    try:
        import docx as _docxlib
        d = _docxlib.Document(io.BytesIO(raw))
        return "\n".join(p.text for p in d.paragraphs)
    except Exception as _qe:
        quiet(_qe, "_docx_to_text")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            xml = z.read("word/document.xml").decode("utf-8", "ignore")
        xml = re.sub(r"</w:p>", "\n", xml)
        xml = re.sub(r"<w:tab[^>]*/>", "\t", xml)
        xml = re.sub(r"<[^>]+>", "", xml)
        import html as _html
        return _html.unescape(xml)
    except Exception:
        return ""


@app.route("/api/script-file/<project>", methods=["POST"])
def api_script_file(project):
    """Read an uploaded .docx/.txt into TEXT for the main script box.

    Analyze Cast and Split both read the textarea and nothing else, so a script that only ever exists
    as a file on disk is invisible to them - this is what puts it where they look."""
    if load_doc(project) is None:
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    if os.path.splitext(f.filename)[1].lower() not in (".docx", ".txt"):
        return jsonify({"error": "Pick a .docx or .txt file."}), 400
    try:
        text = _docx_to_text(f.read(), f.filename)
    except Exception as e:
        return jsonify({"error": "could not read that file (%s)" % (str(e)[:80])}), 400
    text = "\n".join(ln.rstrip() for ln in (text or "").splitlines()).strip()
    if not text:
        return jsonify({"error": "that file had no text in it"}), 400
    return jsonify({"text": text, "name": f.filename})


@app.route("/api/upsell/script-file/<scope>/<cid>", methods=["POST"])
def api_ud_script_file(scope, cid):
    """Read an uploaded .docx/.txt straight into the card's script box - the text is what drives both
    the voice-over and the caption alignment, so it has to land in the textarea, not just on disk."""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in (".docx", ".txt"):
        return jsonify({"error": "script must be a .docx or .txt file"}), 400
    text = _docx_to_text(f.read(), f.filename)
    text = "\n".join(ln.rstrip() for ln in (text or "").splitlines())
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        return jsonify({"error": "that file has no readable text"}), 400
    return jsonify({"ok": True, "text": text[:8000]})


_UD_SRT_JOBS = {}


def _ud_align(scope, cid, vo, script, lang, job=None):
    """Captions for an upsell video: the same forced aligner the VSL and the FAQ use, so the cue rules,
    the language handling and the timing are identical - this is not a second implementation.
    Returns (cues, srt_name, error)."""
    def step(pct, label):
        if job is not None:
            with _UD_LOCK:
                job.update(pct=pct, step=label)
    wd = _ud_dir(scope)
    audio = (wd / vo).resolve()
    try:
        audio.relative_to(wd.resolve())
    except Exception:
        return None, None, "bad audio path"
    if not audio.exists():
        return None, None, "voice-over file not found"
    safe = re.sub(r"[^A-Za-z0-9_-]", "", str(cid))[:40] or "card"
    docx = wd / ("srt_%s.docx" % safe)
    out = wd / ("captions_%s.srt" % safe)
    step(8, "Preparing the script...")
    text_to_docx(script, docx)
    exe = _sys.executable
    si = None
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(c):
                exe = c
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out), VSL_LANG=lang)
    step(18, "Aligning the voice-over to the script...")
    try:
        with open(wd / "align.log", "a", encoding="utf-8") as log:
            log.write("\n===== upsell %s =====\n" % safe)
            log.flush()
            rc = subprocess.run([exe, str(SRT_SCRIPT), _align_models(lang)[1], "--vad"], cwd=str(wd),
                                env=env, stdout=log, stderr=subprocess.STDOUT,
                                startupinfo=si, timeout=1800).returncode
    except Exception as e:
        return None, None, "caption run failed: %s" % e
    if rc != 0 or not out.exists():
        return None, None, "captions were not produced; see align.log"
    try:
        docx.unlink()
    except OSError as _qe:
        quiet(_qe, "_ud_align")
    step(92, "Building the cues...")
    cues = premiere_export.parse_srt(out.read_text(encoding="utf-8"))
    clean = [{"start": round(float(c["start"]), 3), "end": round(float(c["end"]), 3),
              "text": str(c.get("text") or "")} for c in cues]
    return clean, out.name, None


def _ud_srt_worker(jid, scope, cid, vo, script, lang):
    j = _UD_SRT_JOBS[jid]
    try:
        cues, name, err = _ud_align(scope, cid, vo, script, lang, job=j)
        with _UD_LOCK:
            if err:
                j.update(status="error", error=err)
            else:
                j.update(status="done", pct=100, step="Done", url=name, cues=cues)
    except Exception as e:
        with _UD_LOCK:
            j.update(status="error", error=str(e)[:300])


@app.route("/api/upsell/srt-job/<scope>/<cid>", methods=["POST"])
def api_ud_srt_job(scope, cid):
    body = request.get_json(force=True) or {}
    vo = (body.get("vo") or "").strip()
    script = (body.get("script") or "").strip()
    lang = (body.get("lang") or "en").strip().lower()[:5] or "en"
    if not vo:
        return jsonify({"error": "no voice-over on this card"}), 400
    if not script:
        return jsonify({"error": "write the script first - the captions are aligned to it"}), 400
    jid = "udsrt-%d" % int(time.time() * 1000)
    with _UD_LOCK:
        _UD_SRT_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...",
                             "error": None, "url": None, "cues": []}
    _KeyThread(target=_ud_srt_worker, daemon=True,
                     args=(jid, scope, cid, vo, script, lang)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/upsell/srt-job/<jid>")
def api_ud_srt_job_poll(jid):
    with _UD_LOCK:
        j = _UD_SRT_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


# ---------- write a script from a title + an idea ---------------------------------------------------
# A 60-minute script is ~9000 words: one call cannot hold that length without drifting or stopping short,
# so this plans the beats first and then writes them section by section, feeding each section the tail of
# what is already written. That also gives the UI something real to show progress against.
_GS_JOBS = {}
_GS_LOCK = threading.Lock()
_GS_LANGS = {"tr": "Turkish", "en": "English", "fr": "French", "de": "German", "it": "Italian"}
_GS_WPM = 150            # read-aloud pace; 150 words a minute is the middle of a VSL/YouTube narration

_GS_SHAPE = {
    "vsl": ("A VSL earns attention before it sells: open on a hook the viewer cannot walk away from, name "
            "the problem and why the usual answers failed them, tell the discovery story with a mechanism "
            "the viewer can believe, back it with proof and specifics, then present the offer, the risk "
            "reversal and a close that gives a real reason to act now."),
    "youtube": ("A YouTube script keeps a viewer watching: open with the promise and the reason to stay, "
                "deliver genuine value in ordered sections with concrete examples, re-hook at every "
                "transition so nobody drifts off, and close with the takeaway and one clear call to action. "
                "Write it to be PICTURED - every abstract idea gets a concrete metaphor or a comparison the "
                "viewer can see, because each line has to become a shot."),
}

# How the script opens and how much it has to explain is decided almost entirely by what the viewer
# already knows. This is the single biggest lever on a VSL, so it is a choice, not a guess.
_GS_AWARE = {
    "unaware": ("The viewer does not yet know they have this problem. Open on a moment from their own life "
                "or an observation they will recognise, name the problem for them, and only then move "
                "towards a solution. Never lead with the product."),
    "problem": ("The viewer knows the problem and is tired of it. Open inside that frustration in their own "
                "words, show why everything they already tried was always going to fail, and let the "
                "mechanism be the answer to that failure."),
    "solution": ("The viewer already knows solutions like this exist. Spend little time on the problem: open "
                 "on why this category works but the usual versions fall short, and make the mechanism the "
                 "reason this one is different."),
    "product": ("The viewer already knows this product. Go light on the problem and heavy on proof, on what "
                "makes this offer different or urgent right now, and on removing the last objection."),
    "most": ("The viewer is ready to buy and only needs a reason to act now. Keep the setup very short and "
             "spend the script on the offer, the proof, the guarantee and the deadline."),
}

# On a YouTube video there is no offer to be aware of - what matters is how much of the SUBJECT the viewer
# already has, which decides where the video starts and how much it stops to explain.
_GS_AWARE_YT = {
    # what the viewer already knows about the SUBJECT - the content-video reading of awareness
    "none": ("The viewer has never thought about this subject. Define every term the first time it appears "
             "and assume nothing at all."),
    "little": ("The viewer has heard of this but could not explain it. Reintroduce the basics briefly, then "
               "go straight past them."),
    "basics": ("The viewer knows the basics already. Skip the introduction and spend the time on the part "
               "they cannot easily find elsewhere."),
    "lots": ("The viewer knows this subject well. No basics at all - go straight to the nuance, the "
             "exception, or the evidence they have not seen."),
    "unaware": ("The viewer has never thought about this topic. Open on something from their own life they "
                "will recognise, build the idea from zero, and define every term the first time you use it."),
    "problem": ("The viewer has noticed this problem but has never had it named. Name it precisely in the "
                "opening - being understood is the hook - then explain why it happens."),
    "solution": ("The viewer already knows the usual advice on this. Get through the basics fast and spend "
                 "the video on why the usual advice falls short and what actually works instead."),
    "product": ("The viewer already knows this method or tool. Assume the fundamentals and go deep: the "
                "details, the edge cases and the parts nobody else covers."),
    "most": ("The viewer follows this subject closely. No introduction, no basics - open at the advanced "
             "end, stay specific and dense, and respect what they already know."),
}

_GS_TONE = {
    "story": ("Tell it as a story: a person, a turning point, a discovery. Scenes and moments, not claims. "
              "The selling happens because the story earns it."),
    "direct": ("Direct response. Short punchy sentences, one idea per line, bold specific claims, constant "
               "forward pull, speak to the viewer as you throughout."),
    "documentary": ("Calm authority. Evidence, mechanism, named studies and researchers, measured language "
                    "that earns trust instead of demanding it. No hype words."),
    "conversational": ("One person talking to one person. Plain words, contractions, small asides, the way "
                       "a friend who knows this stuff would explain it over coffee."),
}

# "Type" used to mean VSL-or-YouTube. The project itself says that now, so the picker asks the question
# that actually shapes the script: on YouTube what KIND of video this is, on a VSL what is being sold.
_GS_FORMAT = {
    "explainer": ("An explainer: one question, answered properly. Open on the question in the viewer's own "
                  "words, build the answer one step at a time so each step earns the next, and land on what "
                  "it actually means for them."),
    "listicle": ("A list video: say up front how many items there are and why they are worth staying for. "
                 "Give every item the same shape - name it, show it, say why it matters - keep them moving, "
                 "and save the strongest for last."),
    "story": ("A story or case study: one subject, a turning point, and what changed. Facts arrive because "
              "the story needs them at that moment, never as a lecture."),
    "tutorial": ("A how-to: the viewer should be able to do the thing by the end. Say what they will be able "
                 "to do, what they need, then ordered steps - and at each step the mistake to avoid."),
    "documentary": ("A deep dive: evidence, chronology and named sources. Build the case, show the strongest "
                    "counter-argument honestly, and let the conclusion be earned rather than announced."),
    "review": ("A review or comparison: give the verdict early, then the evidence for it. Be specific about "
               "what is good, what is not, and who it is actually for - and who it is not."),
}

_GS_OFFER = {
    "supplement": ("A supplement or health product. Proof means ingredients, mechanism and studies; the "
                   "objection to answer is 'why has nothing else worked for me'."),
    "digital": ("A digital product or course. Proof means results and the method behind them; the objection "
                "is 'can I actually do this myself'."),
    "software": ("Software or an app. Proof means the thing working on screen and time saved; the objection "
                 "is 'is this one more tool I will stop using'."),
    "coaching": ("Coaching or a done-with-you service. Proof means the people who went through it; the "
                 "objection is 'will this work for MY situation'."),
    "physical": ("A physical product. Proof means it in use, the build and the guarantee; the objection is "
                 "'is it worth this much'."),
    "service": ("A done-for-you service. Proof means outcomes and the process; the objection is 'why you'."),
}

# The same four words mean different things on a video nobody is being sold anything on.
_GS_TONE_YT = {
    "story": ("Tell it as a story: a person, a turning point, what changed. Scenes and moments, not a "
              "lecture - the viewer stays because they want to know what happens next."),
    "direct": ("Fast and punchy. Short sentences, no throat-clearing, no wasted words, one idea per line. "
               "Cut anything that does not earn its seconds on screen."),
    "documentary": ("Video-essay authority. Evidence, mechanism, named studies and researchers, measured "
                    "language that earns trust instead of demanding it. No hype."),
    "conversational": ("One person talking to one person, straight to camera. Plain words, contractions, "
                       "small asides, the way you would explain it to a friend who asked."),
}

# Every line of this script has to end up on screen, so what CAN be shown changes how it should be written.
_GS_VISUAL = {
    "realistic": ("This will be shot with real people and real places. Write lines that are filmable: a "
                  "kitchen at six in the morning, a doctor's office, a hand on a bottle. Prefer concrete "
                  "scenes over abstractions."),
    "2d": ("This will be animated in flat 2D. Write so every idea has a simple picture behind it: personify "
           "the process, use one clear metaphor at a time, prefer characters and objects over statistics, "
           "and avoid describing anything that would need photographic detail."),
    "3d": ("This will be built in 3D animation. Favour things that can be shown in space and cut away to: "
           "inside the body, a switch turning on, a molecule reaching a cell, a factory line of a process."),
    "mixed": ("This will mix real footage with animation. Alternate deliberately: a real human scene for the "
              "emotional moments, an animated metaphor whenever you explain a mechanism."),
}


def _gs_audience(project):
    """The project's own Audience settings, so the writer does not have to be told again who this is for."""
    if not project:
        return ""
    try:
        doc = load_doc(project) or {}
    except Exception:
        return ""
    aud = doc.get("audience") or {}

    def val(k):
        v = aud.get(k)
        if isinstance(v, (list, tuple)):
            v = ", ".join(str(x) for x in v if x)
        return str(v or "").strip()

    bits = []
    if (doc.get("brief") or "").strip():
        bits.append("Project brief: " + " ".join(doc["brief"].split())[:600])
    if val("avatar"):
        bits.append("Target viewer: " + val("avatar"))
    who = ", ".join(x for x in (val("genders"), val("ages")) if x)
    if who:
        bits.append("Who they are: " + who)
    if val("locations"):
        bits.append("Where they live: " + val("locations"))
    if val("currencies"):
        bits.append("Currency to use for any price: " + val("currencies"))
    return ("\n\nWHO THIS IS FOR (from the project's Audience settings - write to this person):\n- "
            + "\n- ".join(bits)) if bits else ""


_GS_OUTLINE_SYSTEM = """You plan the beats of a script that will be read aloud.

THE LANGUAGE OF THE BRIEFING IS NOT THE LANGUAGE OF THE SCRIPT. The title and the idea you are given are
briefing material only and may be written in any language. Everything you produce is in %s.

The FIRST line of your answer must be exactly "TITLE: " followed by the title, written in %s. If the title
you were given is in another language, write the title this script deserves in %s - a real title, not a
word-for-word translation.

Then a numbered outline of exactly %d consecutive beats for a script of about %d minutes (%d words).
Each line: the number, a short beat name, then one sentence saying what that beat has to achieve and
roughly what it says. Write the outline in %s.

%s

The DIRECTION block in the briefing is not a suggestion: it decides how this script opens, how it
sounds and what it is allowed to show. Plan the beats around it.

EVERY BEAT BECOMES A PICTURE, so plan where the pictures are. When the whole episode is about one
object or one place, a script that never leaves it produces forty shots of the same thing from
slightly different angles, and the viewer feels the repetition even when every line is interesting.
So at least two or three of these beats must take the camera SOMEWHERE ELSE - a different place, a
different time, a different scale, or the same thing seen through somebody else's day: where it is
made, who first needed it, what it looks like from the room next door, what happens when it is
missing, the same object multiplied a thousand times. Do not invent facts to get there; find the
places the true story already reaches. Beats that all sit in the same room are a planning failure.

Return only the TITLE line and the numbered lines. No preamble, no headings, no markdown."""

_GS_SECTION_SYSTEM = """You are writing one section of a script that will be read aloud by a voice-over.

RULES:
- Write ONLY the spoken narration. No headings, no beat names, no numbering, no speaker labels, no stage
  directions, no markdown, no emoji, no notes to the reader, no "Section 3" - nothing a voice would not say.
- One sentence per line. No blank lines.
- Write in natural spoken %s. It must read as if it were written in %s, not translated into it.
- The title and the idea you are given are briefing material and may be in a different language.
  That changes nothing: every word you write is in %s. Never carry a phrase over in its original
  language, and never mention the briefing.
- LENGTH: between %d and %d words, and never past %d. This script has a running time to hit, and a
  section that overruns pushes the whole video past it. Do not stop early either, and do not pad.
- Continue seamlessly from the text you are given. Never repeat a sentence that is already there and never
  re-introduce something already introduced.
- Follow the DIRECTION block in the briefing exactly - the voice, the viewer's awareness and how this
  will be shown on screen are already decided, and every line has to fit all three.
- %s

Return only the narration."""


def _gs_clean(t):
    """Strip anything a voice would not say: fences, headings, bold beat names, list bullets."""
    t = _punct_strip_fence(t or "")
    out = []
    for ln in t.split("\n"):
        ln = ln.strip()
        if not ln:
            continue
        if ln.startswith("#"):
            continue
        if re.fullmatch(r"[*_\s]*\[?[^*_\[\]]{0,60}\]?[*_\s]*", ln) and re.match(r"^\*\*|^__", ln):
            continue                                   # a bold-only line is a heading, not narration
        ln = re.sub(r"^[-*\u2022]\s+", "", ln)
        ln = re.sub(r"^\d+[.)]\s+", "", ln)
        ln = ln.replace("**", "").replace("__", "")
        if ln:
            out.append(ln)
    return "\n".join(out)


def _gs_worker(jid, title, idea, minutes, kind, lang, aware, tone, visual, project, fmt=""):
    j = _GS_JOBS[jid]

    def cancelled():
        with _GS_LOCK:
            return bool(j.get("cancel"))

    try:
        language = _GS_LANGS.get(lang, "English")
        words = max(120, int(minutes) * _GS_WPM)
        # Passes exist to keep a LONG script coherent; a script a single answer can hold well is better
        # written in one go. The three-pass floor stays for everything above that.
        n = 1 if words <= 700 else max(3, min(20, int(round(words / 550.0))))
        # ...but a short script still deserves a shape, so the outline plans several beats and the single
        # pass writes all of them.
        beats_n = n if n > 1 else max(3, min(6, int(round(words / 60.0))))
        per = int(round(words / float(n)))
        shape = _GS_SHAPE.get(kind, _GS_SHAPE["vsl"])
        label = "VSL" if kind == "vsl" else "YouTube video"

        brief = "TITLE: %s\n\nIDEA / WHAT IT MUST BE:\n%s\n\nFORMAT: %s\nTARGET LENGTH: %d minutes (%d words)" % (
            title or "(untitled)", idea or "(no extra direction - work from the title)", label, minutes, words)
        _shape = _GS_FORMAT.get(fmt) if kind == "youtube" else _GS_OFFER.get(fmt)
        if _shape:
            brief += ("\n\nWHAT KIND OF VIDEO THIS IS: %s" if kind == "youtube"
                      else "\n\nWHAT IS BEING SOLD: %s") % _shape
        brief += ("\n\nDIRECTION (this decides how the script opens, how it sounds and what it can show):"
                  "\n- WHAT THE VIEWER ALREADY KNOWS: %s\n- VOICE: %s\n- HOW IT WILL BE SHOWN: %s"
                  % ((_GS_AWARE_YT if kind == "youtube" else _GS_AWARE).get(aware, _GS_AWARE["problem"]),
                     (_GS_TONE_YT if kind == "youtube" else _GS_TONE).get(tone, _GS_TONE["story"]),
                     _GS_VISUAL.get(visual, _GS_VISUAL["realistic"])))
        brief += _gs_audience(project)

        with _GS_LOCK:
            j.update(pct=4, step="Planning the beats...")
        outline = _claude_text(_GS_OUTLINE_SYSTEM % (language, language, language, beats_n, minutes, words,
                                                    language, shape), brief, max_tokens=2500)
        outline = _punct_strip_fence(outline).strip()
        if cancelled():
            raise RuntimeError("cancelled")

        lines = [ln.strip() for ln in outline.split("\n") if ln.strip()]
        out_title = title
        if lines and lines[0].upper().startswith("TITLE:"):
            out_title = lines.pop(0).split(":", 1)[1].strip().strip('"') or title
            outline = "\n".join(lines)
        # from here on the script is briefed with its OWN title, in its own language
        brief = brief.replace("TITLE: %s" % (title or "(untitled)"), "TITLE: %s" % out_title, 1)
        beats = lines
        parts = []
        written = 0
        t0 = time.time()
        for i in range(n):
            if cancelled():
                raise RuntimeError("cancelled")
            with _GS_LOCK:
                j.update(pct=int(6 + 92.0 * i / n),
                         step="Writing section %d of %d%s" % (i + 1, n, _eta_text(i, n, t0)))
            # one pass writes the whole outline; several passes take a beat each
            beat = ("\n".join(beats) if n == 1 else
                    (beats[i] if i < len(beats) else "(continue the outline)")) or "(continue the outline)"
            tail = "\n".join("\n".join(parts).split("\n")[-8:]) if parts else ""
            left = n - i
            per_i = int(round(max(0, words - written) / float(left))) if left else per
            # the floor can never exceed the whole target - that is what made a 150-word script impossible
            per_i = max(min(120, words), min(per_i, int(per * 1.6)))   # a short pass grows the next one
            closing = ("This is the FINAL section - land the ending and the call to action."
                       if i == n - 1 else
                       "This is NOT the final section - do not write a closing line or a call to action.")
            if i == 0 and kind == "youtube":
                # The opening is cut faster than the rest, and a picture cannot be cut out of a sentence
                # that has no seam: a sixteen-word first line becomes one still held for six seconds,
                # which is exactly where people leave. Fix it in the writing, not in the splitter.
                closing += (" This section OPENS the video. Write the first five or six sentences SHORT -"
                            " six to ten words each, ONE thought per sentence, and do not stack clauses"
                            " with commas. They will be cut fast, one picture each, so each sentence has"
                            " to hold a picture on its own. Longer sentences are fine once the opening"
                            " has done its work.")
            user = ("%s\n\nTHE FULL OUTLINE:\n%s\n\nWRITE THESE BEATS NOW:\n%s\n\n%s" % (
                brief, outline, beat,
                ("THE LAST LINES ALREADY WRITTEN (continue straight on from them):\n" + tail)
                if tail else "This is the opening - nothing has been written yet."))
            txt = _claude_text(_GS_SECTION_SYSTEM % (language, language, language, int(per_i * 0.85), per_i,
                                                     int(per_i * 1.1), closing), user,
                               max_tokens=max(1500, per_i * 4))
            txt = _gs_clean(txt)
            if txt:
                parts.append(txt)
                written += len(re.findall(r"[^\W_]+", txt, re.UNICODE))

        script = "\n".join(parts).strip()
        if not script:
            raise RuntimeError("the model returned nothing")
        with _GS_LOCK:
            j.update(status="done", pct=100, step="Done", script=script, title=out_title,
                     words=len(re.findall(r"[^\W_]+", script, re.UNICODE)))
    except Exception as e:
        msg = "cancelled" if str(e) == "cancelled" else str(e)[:300]
        with _GS_LOCK:
            j.update(status="error", error=msg)


@app.route("/api/genscript", methods=["POST"])
def api_genscript():
    body = request.get_json(force=True) or {}
    title = str(body.get("title") or "").strip()[:300]
    idea = str(body.get("idea") or "").strip()[:4000]
    if not title and not idea:
        return jsonify({"error": "give it a title or an idea to work from"}), 400
    try:
        minutes = int(body.get("minutes") or 10)
    except Exception:
        minutes = 10
    minutes = max(1, min(60, minutes))
    kind = "youtube" if str(body.get("kind")) == "youtube" else "vsl"
    lang = str(body.get("lang") or "en")[:5]
    if lang not in _GS_LANGS:
        lang = "en"
    jid = "gs-%d" % int(time.time() * 1000)
    with _GS_LOCK:
        _GS_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                         "script": "", "title": "", "words": 0, "cancel": False}
    aware = str(body.get("aware") or "problem")
    tone = str(body.get("tone") or "story")
    visual = str(body.get("visual") or "realistic")
    project = str(body.get("project") or "")[:200]
    _KeyThread(target=_gs_worker, daemon=True,
                     args=(jid, title, idea, minutes, kind, lang, aware, tone, visual, project,
                           str(body.get("format") or ""))).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/genscript-job/<jid>")
def api_genscript_job(jid):
    with _GS_LOCK:
        j = _GS_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


@app.route("/api/genscript-cancel/<jid>", methods=["POST"])
def api_genscript_cancel(jid):
    with _GS_LOCK:
        j = _GS_JOBS.get(jid)
        if j:
            j["cancel"] = True
    return jsonify({"ok": True})


# ---------- write the idea, and score the finished script -------------------------------------------
# Both run on the same subscription as everything else. The review is pinned to opus explicitly rather
# than left on the default: it is the hardest judgement call in the app and the one place where a
# cheaper model would quietly cost you a worse script.
_RS_JOBS = {}
_RS_LOCK = threading.Lock()

_GI_SYSTEM = """You turn a title into the brief for a script that has not been written yet.

You are given a title and the exact settings the script will be written with. Write the IDEA: what this
video is really about, the angle it takes, who it is for, and the spine of the story or the argument.

RULES:
- Write it in %s, as one flowing paragraph of 70-120 words. No bullet points, no headings, no labels.
- It is a brief for a writer, not the script itself. Never write narration lines or a hook.
- It must fit the settings you are given: the format, how much the viewer already knows, the voice and
  the way it will be shown on screen. Say something concrete about each of those where it matters.
- If the format is a VSL, include what the product or the offer actually is - invent something specific
  and plausible from the title rather than staying vague.
- Be specific. "A video about weight loss" is useless; name the mechanism, the person, the turn.

Return only the paragraph."""

_RS_RUBRIC = {
    "vsl": [("Hook", 20, "the first 15 seconds: does it stop someone who was about to leave, and does it "
                         "promise something specific enough to be worth staying for"),
            ("Problem & Agitation", 15, "is the pain named in the viewer's own words, and is the failure of "
                                        "everything they already tried made their fault or the method's"),
            ("Mechanism & Credibility", 20, "is there a specific, believable reason-why - a named mechanism, "
                                            "not just claims - and does it hold together"),
            ("Proof & Specificity", 15, "numbers, names, studies, scenes, dates: concrete detail versus "
                                        "generic assertion"),
            ("Offer & Close", 15, "is the offer clear, is the risk reversed, and is there a real reason to "
                                  "act now rather than later"),
            ("Delivery", 15, "does it read aloud well: sentence rhythm, one idea per line, no jargon or "
                             "tongue-twisters, no repetition")],
    "youtube": [("Hook & Promise", 20, "the first 15 seconds: the reason to keep watching, and how specific "
                                       "the promise is"),
                ("Value Delivered", 20, "does the viewer actually leave knowing or able to do something, or "
                                        "is it padding around one thin idea"),
                ("Structure & Re-hooks", 15, "ordered sections, clean transitions, and a reason to stay at "
                                             "each one"),
                ("Specificity & Examples", 15, "concrete examples and detail versus generic advice"),
                ("Delivery", 15, "does it read aloud well: rhythm, one idea per line, natural spoken language"),
                ("Ending & CTA", 15, "does it land the takeaway and ask for one clear thing")],
}

_RS_SYSTEM = """You are a hard-to-please direct-response editor scoring a script that is about to be
produced. You have seen thousands of these. You are fair but you do not give marks for effort.

Score it against exactly these criteria, out of the maximum shown:
%s

HOW TO SCORE: full marks means you would run this as-is. Around 70%% of a criterion means it works but a
good editor would still change something. Below half means it would cost real money to shoot as it is.
Do not cluster everything in the middle, and do not be kind - a vague hook is a vague hook.

THE BRIEF IS NOT ALWAYS THE SCRIPT'S BRIEF. The settings you are shown are simply what is selected in
the app right now; the script may have been written somewhere else and pasted in. So: score the script on
its own merits first. Only if it is clear the script WAS written to this brief should you weigh how well
it matches it. If it plainly was not, do not mark it down for that - say so in one short line in the
summary and judge it as what it is.

Return ONLY a JSON object, no prose and no code fence:
{"score": <0-100, the sum of the section scores>,
 "verdict": "<four words or fewer, e.g. Strong, needs a sharper close>",
 "summary": "<two sentences: what this script does well and the one thing holding it back>",
 "sections": [{"name": "<criterion>", "score": <int>, "max": <int>, "note": "<one sentence, concrete, "
               "quoting the script where it helps>"}],
 "fixes": ["<a specific change, naming the line or the moment>", ...]}
Give between three and six fixes, ordered by how much they would raise the score.

TWO RULES ABOUT THE JSON ITSELF, because a broken object means the whole review is thrown away:
- The object is the entire answer. Nothing before it, nothing after it - no note, no explanation, no
  apology about the brief. Anything you want to say goes inside "summary".
- When you quote the script inside a value, wrap the quote in SINGLE quotes ('like this'). Never put a
  double quote inside a string."""


def _gi_worker(jid, title, minutes, kind, lang, aware, tone, visual, project, fmt="", avoid=None):
    j = _RS_JOBS[jid]
    try:
        language = _GS_LANGS.get(lang, "English")
        label = "VSL" if kind == "vsl" else "YouTube video"
        aw = (_GS_AWARE_YT if kind == "youtube" else _GS_AWARE).get(aware, _GS_AWARE["problem"])
        with _RS_LOCK:
            j.update(pct=20, step="Working out the angle...")
        user = ("TITLE: %s\n\nSETTINGS THE SCRIPT WILL BE WRITTEN WITH:\n- FORMAT: %s\n- LENGTH: %d minutes\n"
                "- LANGUAGE: %s\n- WHAT THE VIEWER ALREADY KNOWS: %s\n- VOICE: %s\n- HOW IT WILL BE SHOWN: %s"
                % (title or "(untitled)", label, minutes, language, aw,
                   (_GS_TONE_YT if kind == "youtube" else _GS_TONE).get(tone, _GS_TONE["story"]),
                   _GS_VISUAL.get(visual, _GS_VISUAL["realistic"])))
        # pressing Generate Idea again must not hand back what was just rejected
        _prev = [" ".join(str(t).split())[:400] for t in (avoid or []) if str(t).strip()][:6]
        if _prev:
            user += (chr(10) + chr(10) + "ALREADY OFFERED FOR THIS TITLE AND REJECTED - take a "
                     "genuinely different angle on the same subject, not a rewording:" + chr(10)
                     + chr(10).join("- " + t for t in _prev))
        # the channel must not cover the same ground twice - show it what it has already published
        try:
            _hist, _ = _channel_history(project, load_doc(project) or {})
        except Exception:
            _hist = ""
        if _hist:
            user += chr(10) + chr(10) + _hist + (
                "Take the channel somewhere it has not been. If the title overlaps one of those, find "
                "the angle inside it that is genuinely new, and say plainly what makes it different.")
        _shape = _GS_FORMAT.get(fmt) if kind == "youtube" else _GS_OFFER.get(fmt)
        if _shape:
            user += ("\n- WHAT KIND OF VIDEO: %s" if kind == "youtube" else "\n- WHAT IS BEING SOLD: %s") % _shape
        user += _gs_audience(project)
        out = _claude_text(_GI_SYSTEM % language, user, max_tokens=1200)
        idea = " ".join(_punct_strip_fence(out).split())
        if not idea:
            raise RuntimeError("the model returned nothing")
        with _RS_LOCK:
            j.update(status="done", pct=100, step="Done", idea=idea)
    except Exception as e:
        with _RS_LOCK:
            j.update(status="error", error=str(e)[:300])


def _ask_json(system, user, model="opus", max_tokens=6000, tries=3, want=None):
    """Ask for a JSON object and insist on getting one. Models occasionally slide an unescaped quote into
    a note, or add a line of prose after the object; handing the parser's own complaint back and asking
    once more costs one call and saves the whole run."""
    last = ""
    for i in range(max(1, tries)):
        u = user if not i else (user + "\n\nYour last answer was not valid JSON (%s). Send the object "
                                       "again - nothing before it, nothing after it, and every quotation "
                                       "inside a value written with single quotes." % last)
        try:
            d = _parse_json_obj(_claude_text(system, u, max_tokens=max_tokens, model=model))
            if want and not want(d):
                raise ValueError("the object was there but the part we need was missing")
            return d
        except Exception as e:
            last = str(e)[:140]
    raise RuntimeError("came back as broken JSON (%s)" % last)


def _rs_worker(jid, script, title, idea, minutes, kind, lang, aware, tone, visual, fmt=""):
    j = _RS_JOBS[jid]
    try:
        language = _GS_LANGS.get(lang, "English")
        label = "VSL" if kind == "vsl" else "YouTube video"
        rub = _RS_RUBRIC.get(kind, _RS_RUBRIC["vsl"])
        rub_txt = "\n".join("- %s (out of %d): %s" % r for r in rub)
        aw = (_GS_AWARE_YT if kind == "youtube" else _GS_AWARE).get(aware, _GS_AWARE["problem"])
        words = len(re.findall(r"[^\W_]+", script, re.UNICODE))
        brief = ("THE BRIEF THIS SCRIPT WAS WRITTEN TO:\n- TITLE: %s\n- FORMAT: %s\n- TARGET LENGTH: %d minutes"
                 " (it is %d words, about %d minutes read aloud)\n- LANGUAGE: %s\n"
                 "- WHAT THE VIEWER ALREADY KNOWS: %s\n- VOICE: %s\n- HOW IT WILL BE SHOWN: %s%s\n\n"
                 % (title or "(untitled)", label, minutes, words, max(1, round(words / 150.0)), language, aw,
                    (_GS_TONE_YT if kind == "youtube" else _GS_TONE).get(tone, _GS_TONE["story"]),
                    _GS_VISUAL.get(visual, _GS_VISUAL["realistic"]),
                    ("\n- THE IDEA IT WAS BRIEFED WITH: " + " ".join(idea.split())[:1500]) if idea else ""))
        with _RS_LOCK:
            j.update(pct=15, step="Reading the script...")
        with _RS_LOCK:
            j.update(pct=45, step="Scoring it against the rubric...")
        data = _ask_json(_RS_SYSTEM % rub_txt, brief + "THE SCRIPT:\n" + script,
                         model="opus", max_tokens=6000,
                         want=lambda d: isinstance(d.get("sections"), list) and len(d["sections"]) > 0) or {}
        with _RS_LOCK:
            j.update(pct=90, step="Writing it up...")
        secs = []
        for sec in (data.get("sections") or []):
            if not isinstance(sec, dict):
                continue
            try:
                secs.append({"name": str(sec.get("name") or "")[:60],
                             "score": int(round(float(sec.get("score") or 0))),
                             "max": int(round(float(sec.get("max") or 0))) or 10,
                             "note": str(sec.get("note") or "")[:400]})
            except Exception:
                continue
        if not secs:
            raise RuntimeError("the review came back unreadable")
        total = sum(x["score"] for x in secs)
        out_of = sum(x["max"] for x in secs) or 100
        score = int(round(total * 100.0 / out_of))     # trust the sections, not a total the model typed
        with _RS_LOCK:
            j.update(status="done", pct=100, step="Done", score=score,
                     verdict=str(data.get("verdict") or "")[:80],
                     summary=str(data.get("summary") or "")[:600],
                     sections=secs,
                     fixes=[str(f)[:400] for f in (data.get("fixes") or []) if str(f).strip()][:6],
                     words=words)
    except Exception as e:
        with _RS_LOCK:
            j.update(status="error", error=str(e)[:300])


def _rs_common(body):
    try:
        minutes = int(body.get("minutes") or 10)
    except Exception:
        minutes = 10
    lang = str(body.get("lang") or "en")[:5]
    return (max(1, min(60, minutes)),
            "youtube" if str(body.get("kind")) == "youtube" else "vsl",
            lang if lang in _GS_LANGS else "en",
            str(body.get("aware") or "problem"), str(body.get("tone") or "story"),
            str(body.get("visual") or "realistic"))


def _st_worker(jid, project, avoid, minutes, kind, lang, fmt):
    """Name one episode the way Run Auto Episode does: several angles, each checked against what
    YouTube already rewards, and the best one returned."""
    j = _RS_JOBS[jid]
    try:
        doc = load_doc(project) or {}
        with _RS_LOCK:
            j.update(pct=15, step="Thinking of angles...")
        cands = _auto_title_options(project, doc, kind, lang, minutes, fmt, n=4, avoid=avoid)
        low = {" ".join(str(t).split()).lower() for t in (avoid or [])}
        cands = [c for c in cands if c.get("title", "").strip().lower() not in low]
        if not cands:
            raise RuntimeError("could not think of a new angle - write the channel brief and the target "
                               "viewer in Settings, or clear some of the ideas already tried")
        picked = None
        if kind == "youtube":
            with _RS_LOCK:
                j.update(pct=55, step="Checking them against YouTube...")
            try:
                picked, _sc = _demand_pick(project, doc, cands, minutes)
            except Exception:
                picked = None
        best = picked or cands[0]
        with _RS_LOCK:
            j.update(status="done", pct=100, step="Done",
                     title=best.get("title", ""), idea=best.get("idea", ""),
                     demand=(best.get("demand") or {}) if isinstance(best, dict) else {})
    except Exception as e:
        with _RS_LOCK:
            j.update(status="error", error=str(e)[:300])


@app.route("/api/suggest-title", methods=["POST"])
def api_suggest_title():
    """One researched episode title, the same way Run Auto Episode picks one. Press again for another."""
    body = request.get_json(force=True) or {}
    project = str(body.get("project") or "")[:200]
    if not project:
        return jsonify({"error": "open a project first"}), 400
    minutes, kind, lang, _aware, _tone, _visual = _rs_common(body)
    avoid = [str(t)[:200] for t in (body.get("avoid") or []) if str(t).strip()][:12]
    jid = "st-%d" % int(time.time() * 1000)
    with _RS_LOCK:
        _RS_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                         "title": "", "idea": ""}
    _KeyThread(target=_st_worker, daemon=True,
                     args=(jid, project, avoid, minutes, kind, lang,
                           str(body.get("format") or ""))).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/genidea", methods=["POST"])
def api_genidea():
    body = request.get_json(force=True) or {}
    title = str(body.get("title") or "").strip()[:300]
    if not title:
        return jsonify({"error": "write a title first - the idea is built from it"}), 400
    minutes, kind, lang, aware, tone, visual = _rs_common(body)
    jid = "gi-%d" % int(time.time() * 1000)
    with _RS_LOCK:
        _RS_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None, "idea": ""}
    _KeyThread(target=_gi_worker, daemon=True,
                     args=(jid, title, minutes, kind, lang, aware, tone, visual,
                           str(body.get("project") or "")[:200], str(body.get("format") or ""),
                           [str(t)[:400] for t in (body.get("avoid") or []) if str(t).strip()][:6])).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/reviewscript", methods=["POST"])
def api_reviewscript():
    body = request.get_json(force=True) or {}
    script = str(body.get("script") or "")
    if not script.strip():
        return jsonify({"error": "there is no script to review yet"}), 400
    if len(script) > 120000:
        return jsonify({"error": "that script is too long to review in one go"}), 400
    minutes, kind, lang, aware, tone, visual = _rs_common(body)
    jid = "rs-%d" % int(time.time() * 1000)
    with _RS_LOCK:
        _RS_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                         "score": 0, "verdict": "", "summary": "", "sections": [], "fixes": [], "words": 0}
    _KeyThread(target=_rs_worker, daemon=True,
                     args=(jid, script, str(body.get("title") or "")[:300],
                           str(body.get("idea") or "")[:4000], minutes, kind, lang,
                           aware, tone, visual, str(body.get("format") or ""))).start()
    return jsonify({"ok": True, "job": jid})


_AF_SYSTEM = """You are rewriting a script that is about to be produced, applying a specific list of
changes an editor asked for. Nothing else.

RULES:
- Apply EVERY change on the list, and only those changes. Leave every other line exactly as it is - if a
  line is not touched by one of the changes, it must come back character for character identical.
- Keep the same language, the same voice and the same format: one sentence per line, no blank lines, no
  headings, no speaker labels, no markdown, no notes to the reader.
- Keep the length within about ten percent of what you were given. A fix is a rewrite, not an expansion.
- Do not renumber, reorder or merge the parts of the script that the changes do not mention.

Return only the rewritten script."""


def _af_count(t):
    return len(re.findall(r"[^\W_]+", t or "", re.UNICODE))


def _af_worker(jid, script, fixes, lang, target_words=0):
    j = _RS_JOBS[jid]
    try:
        language = _GS_LANGS.get(lang, "English")
        with _RS_LOCK:
            j.update(pct=20, step="Applying %d change%s..." % (len(fixes), "" if len(fixes) == 1 else "s"))
        have = _af_count(script)
        want = int(target_words) if target_words else have
        lo, hi = int(want * 0.90), int(want * 1.15)
        user = ("THE CHANGES TO APPLY:\n" + "\n".join("%d. %s" % (i + 1, f) for i, f in enumerate(fixes))
                + ("\n\nLENGTH - THIS IS NOT NEGOTIABLE: what you were given is %d words and what you send "
                   "back must be between %d and %d. Applying a change means REWRITING lines, not adding "
                   "more of them. If a change asks for something the script does not have yet, make room "
                   "for it by cutting something weaker - the running time is fixed.\n\n" % (have, lo, hi))
                + "THE SCRIPT (in %s):\n" % language + script)
        out = _gs_clean(_claude_text(_AF_SYSTEM, user, max_tokens=max(2000, len(script)), model="opus"))
        if out and _af_count(out) > hi:
            # one firm retry, told exactly how far over it went
            with _RS_LOCK:
                j.update(pct=60, step="Trimming it back to length...")
            out2 = _gs_clean(_claude_text(
                _AF_SYSTEM,
                user + ("\n\nYour last answer was %d words - too long. Send it again at %d to %d words, "
                        "keeping every change. Cut, do not add." % (_af_count(out), lo, hi)),
                max_tokens=max(2000, len(script)), model="opus"))
            if out2 and abs(_af_count(out2) - want) < abs(_af_count(out) - want):
                out = out2
        if out and _af_count(out) > int(want * 1.35):
            # still runaway: the right length unfixed beats the wrong length fixed
            raise RuntimeError("the changes kept coming back %d%% too long"
                               % int(100.0 * _af_count(out) / max(1, want) - 100))
        if not out:
            raise RuntimeError("the model returned nothing")
        with _RS_LOCK:
            j.update(status="done", pct=100, step="Done", script=out,
                     words=len(re.findall(r"[^\W_]+", out, re.UNICODE)))
    except Exception as e:
        with _RS_LOCK:
            j.update(status="error", error=str(e)[:300])


@app.route("/api/applyfixes", methods=["POST"])
def api_applyfixes():
    body = request.get_json(force=True) or {}
    script = str(body.get("script") or "")
    fixes = [str(f).strip()[:400] for f in (body.get("fixes") or []) if str(f).strip()][:6]
    if not script.strip():
        return jsonify({"error": "there is no script to change"}), 400
    if not fixes:
        return jsonify({"error": "tick at least one change to apply"}), 400
    lang = str(body.get("lang") or "en")[:5]
    jid = "af-%d" % int(time.time() * 1000)
    with _RS_LOCK:
        _RS_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                         "script": "", "words": 0}
    try:
        _tw = max(0, int(body.get("minutes") or 0)) * _GS_WPM
    except (TypeError, ValueError):
        _tw = 0
    _KeyThread(target=_af_worker, daemon=True,
                     args=(jid, script, fixes, lang if lang in _GS_LANGS else "en", _tw)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/review-job/<jid>")
def api_review_job(jid):
    with _RS_LOCK:
        j = _RS_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


# ---------- punctuation fix for hand-written scripts ------------------------------------------------
# One button on every script box. It may only touch punctuation, capitalisation and spacing - never a
# word - because these scripts are copy-approved and go straight to ElevenLabs. The model is told that,
# but a model promise is not a guarantee: every block is verified here by comparing the word tokens
# before and after, and a block that fails is returned unchanged.
_PUNCT_JOBS = {}
_PUNCT_LOCK = threading.Lock()


def _eta_text(done, total, started):
    """'- about 1m 20s left', from the blocks finished so far. Empty until one block is done, because an
    estimate off zero samples is worse than none."""
    if done <= 0 or done >= total:
        return ""
    left = (time.time() - started) / float(done) * (total - done)
    if left < 5:
        return " - almost done"
    if left < 60:
        return " - about %ds left" % max(5, int(round(left / 5.0) * 5))
    m, sec = divmod(int(left), 60)
    return " - about %dm %02ds left" % (m, sec) if sec else " - about %dm left" % m

_PUNCT_SYSTEM = """You fix ONLY the punctuation, capitalisation and spacing of a script that is about to be
read aloud by a text-to-speech voice.

ABSOLUTE RULES - breaking any one of them makes your answer useless:
- Never add, delete, replace, translate or reorder a single word. Every word must come back exactly as it
  went in, in the same order, with the same letters.
- Never merge or split lines. Return exactly as many lines as you were given, in the same order. An empty
  line stays an empty line.
- Do not spell out numbers, do not expand abbreviations, do not "improve" any wording.

WHAT YOU DO CHANGE, following the standard orthography of the language the text is actually written in -
detect that language from the text itself, it can be any language, and apply THAT language's rules:
- add the sentence-ending mark where it is missing (. ? !) and the commas the language's rules require
- fix capitalisation at the start of sentences and where the language's rules demand it, including the
  pronouns a language always capitalises (English "I", the polite German "Sie") and nouns in German
- changing a letter is NOT capitalisation: never add or remove an accent or a diacritic, never respell a
  word. A script written without diacritics stays without them.
- add the apostrophes the language requires (e.g. Turkish suffixes on proper nouns, English contractions
  that are already written as contractions)
- fix the spacing around punctuation the way that language does it, and collapse repeated spaces
- remove duplicated or plainly wrong punctuation (,, .. ,. ?. )

THREE FIXES THE VOICE MODEL NEEDS - they make it hesitate or trail off, so always apply them:
- curly quotes and curly apostrophes become straight ones
- an ellipsis (... or the single character) becomes a comma if the sentence continues, a full stop if it ends
- a dash used as a mid-sentence pause becomes a comma

Return ONLY the corrected text. No preamble, no explanation, no code fences."""

_PUNCT_APOS = "'\u2018\u2019\u201b\u02bc\u00b4`"


def _punct_safe_pass(text):
    """Deterministic cleanups that cannot change a word in any language. Deliberately does NOT touch the
    space before ?!;: - French requires one there, so that call belongs to the model."""
    t = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u00a0", " ")
    for ch in "\u2018\u2019\u201b\u02bc":
        t = t.replace(ch, "'")
    for ch in "\u201c\u201d\u201e\u00ab\u00bb":
        t = t.replace(ch, '"')
    t = re.sub(r"[ \t]+", " ", t)
    t = "\n".join(ln.rstrip() for ln in t.split("\n"))
    return t


def _punct_tokens(text):
    """Word tokens per line, ignoring case, apostrophes and every punctuation mark. Two texts with the
    same token lists say exactly the same words in the same order."""
    out = []
    for ln in text.split("\n"):
        for ch in _PUNCT_APOS:
            ln = ln.replace(ch, "")
        out.append(re.findall(r"[^\W_]+", ln.lower(), re.UNICODE))
    return out


def _punct_chunks(text, size=6000):
    """Split on line boundaries only, so joining with \\n restores the line structure byte for byte."""
    chunks, cur, n = [], [], 0
    for ln in text.split("\n"):
        if cur and n + len(ln) + 1 > size:
            chunks.append("\n".join(cur))
            cur, n = [], 0
        cur.append(ln)
        n += len(ln) + 1
    if cur:
        chunks.append("\n".join(cur))
    return chunks or [text]


def _punct_strip_fence(t):
    t = (t or "").strip("\n")
    if t.startswith("```"):
        t = re.sub(r"^```[^\n]*\n", "", t)
        t = re.sub(r"\n```\s*$", "", t)
    return t.strip("\n")


def _punct_one(chunk):
    """Returns the corrected chunk, or None if the model could not keep every word intact."""
    want = _punct_tokens(chunk)
    for attempt in range(2):
        extra = ("" if not attempt else
                 "\n\nYour previous answer changed, dropped or added a word. Send back the SAME words in "
                 "the same order and the same number of lines - only the punctuation may differ.")
        try:
            got = _claude_text(_PUNCT_SYSTEM + extra, chunk,
                               max_tokens=max(1500, min(16000, len(chunk))))
        except Exception:
            continue
        got = _punct_safe_pass(_punct_strip_fence(got))
        if got and _punct_tokens(got) == want:
            return got
    return None


def _punct_worker(jid, text):
    j = _PUNCT_JOBS[jid]
    try:
        base = _punct_safe_pass(text)
        chunks = _punct_chunks(base)
        out, skipped = [], 0
        t0 = time.time()
        for i, ch in enumerate(chunks):
            with _PUNCT_LOCK:
                j.update(pct=int(i * 100 / max(1, len(chunks))),
                         step="Checking block %d of %d%s" % (i + 1, len(chunks),
                                                             _eta_text(i, len(chunks), t0)))
            if not ch.strip():
                out.append(ch)
                continue
            fixed = _punct_one(ch)
            if fixed is None:
                out.append(ch)
                skipped += 1
            else:
                out.append(fixed)
        res = "\n".join(out)
        with _PUNCT_LOCK:
            j.update(status="done", pct=100, step="Done", text=res,
                     changed=(res != text), skipped=skipped)
    except Exception as e:
        with _PUNCT_LOCK:
            j.update(status="error", error=str(e)[:300])


@app.route("/api/punctuate", methods=["POST"])
def api_punctuate():
    body = request.get_json(force=True) or {}
    text = body.get("text") or ""
    if not str(text).strip():
        return jsonify({"error": "there is no text to fix yet"}), 400
    if len(text) > 120000:
        return jsonify({"error": "that script is too long to check in one go"}), 400
    jid = "punct-%d" % int(time.time() * 1000)
    with _PUNCT_LOCK:
        _PUNCT_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                            "text": "", "changed": False, "skipped": 0}
    _KeyThread(target=_punct_worker, daemon=True, args=(jid, text)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/punctuate-job/<jid>")
def api_punctuate_job(jid):
    with _PUNCT_LOCK:
        j = _PUNCT_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


# ---------- Auto Episode: one button, title -> a fully directed scene list ---------------------------
# Every step here is the SAME call the buttons make; nothing is reimplemented. What is new is the running
# of them in order, unattended, and the GATE: the run stops before it can spend a single image credit and
# shows you what it is about to cost. Nothing past that gate happens without you saying so.
_AUTO_JOBS = {}
_AUTO_LOCK = threading.Lock()
_AUTO_STEPS = ["Idea", "Script", "Review", "Punctuation", "Scenes", "Estimate"]
_AUTO_POLICY = {"ost": False, "icons": False, "sfx": False, "fx": True}


def _channel_of(project):
    """The project group the user filed this project under. That group IS the channel."""
    try:
        g = _read_groups() or {}
        gid = (g.get("assign") or {}).get(project)
        if not gid:
            return None, []
        name = next((x.get("name") for x in (g.get("groups") or []) if x.get("id") == gid), None)
        return name, [p for p, v in (g.get("assign") or {}).items() if v == gid and p != project]
    except Exception:
        return None, []


def _channel_history(project, doc, limit=40):
    """What this channel has already published: every sibling project's title and the subject it covered.
    Handed to whatever is about to invent a new one, so episode two never re-runs episode one.
    Falls back to same-type projects when the user has not grouped anything yet."""
    name, sibs = _channel_of(project)
    if not sibs:
        try:
            sibs = [p.name for p in sorted(PROJECTS.iterdir())
                    if p.is_dir() and p.name != project and (p / "scenes.json").exists()]
        except Exception:
            sibs = []
        same_type_only = True
    else:
        same_type_only = False
    done = []
    for pn in sibs:
        try:
            d0 = _peek_doc(PROJECTS / pn / "scenes.json") or {}
        except Exception:
            continue
        if same_type_only and proj_type(d0) != proj_type(doc):
            continue
        so = d0.get("script_opts") or {}
        t = (so.get("title") or d0.get("title") or "").strip()
        if not t:
            continue
        topic = " ".join((so.get("idea") or "").split())[:260]
        done.append("- %s%s" % (t, ("  |  " + topic) if topic else ""))
    if not done:
        return "", name
    head = ("ALREADY PUBLISHED ON %s - do not repeat, re-angle or lightly reword any of these subjects:\n"
            % ("THIS CHANNEL (%s)" % name if name else "THIS CHANNEL"))
    return head + "\n".join(done[-limit:]) + "\n", name


_AT_SYSTEM = """You name the next episode of an existing channel. You are given what the channel is
about, who watches it, and the titles it has already published.

Give back ONE title and nothing else - no quotation marks, no numbering, no explanation.

What makes it the right title:
- It belongs on THIS channel. Same subject area, same level, same kind of promise as the ones already
  published - a viewer who liked those should recognise it as more of what they came for.
- It is about ONE specific thing, not a survey. "Why your legs give out before your heart does" beats
  "Everything you need to know about ageing".
- It says what the viewer gets, in their own words, without hype, clickbait punctuation or ALL CAPS.
- It is genuinely NEW. Do not restate, re-angle or lightly reword anything on the published list.
- Ten words at most."""


def _auto_title_ctx(project, doc, kind, lang, minutes, fmt, event=None):
    """Everything the model needs before it names an episode for this channel. Shared, so a single
    title and a set of competing angles are chosen from exactly the same brief."""
    language = _GS_LANGS.get(lang, "English")
    hist, _chan = _channel_history(project, doc)
    shape = (_GS_FORMAT.get(fmt) if kind == "youtube" else _GS_OFFER.get(fmt)) or ""
    user = ("WHAT THE CHANNEL IS ABOUT:\n%s\n\n%s\nTHIS EPISODE: about %d minutes%s.\nWRITE THE TITLE IN: %s\n"
            % ((doc.get("brief") or "").strip() or "(nothing written yet - work from the target viewer alone)",
               _gs_audience(project).strip() or "TARGET VIEWER: (not set)",
               minutes, (" - a %s" % shape) if shape else "", language))
    if hist:
        user += chr(10) + hist
    if event:
        # The episode is NOT about the news item; it is about the older story the news made people
        # curious about. Say so plainly or the title comes back reading like a headline.
        user += ("\n\nTHIS EPISODE COMES FROM SOMETHING IN THE NEWS RIGHT NOW:\n"
                 "- what happened: %s\n- the story it opens: %s\n\n"
                 "Title the OLDER STORY, not the news item. Someone who just read the headline should "
                 "see this title and realise there is a bigger story behind it. Do not date it, do not "
                 "say 'in the news' or 'right now', and do not name the current event unless the older "
                 "story genuinely shares its name (a place, a ship, a mountain)."
                 % (str(event.get("event"))[:300], str(event.get("bridge"))[:400]))
    return user


def _auto_title(project, doc, kind, lang, minutes, fmt, event=None):
    """Name the next episode from the channel brief and the target viewer in Settings - the case
    where the user pressed the button with everything empty and expects the app to decide."""
    user = _auto_title_ctx(project, doc, kind, lang, minutes, fmt, event)
    out = _claude_text(_AT_SYSTEM, user, max_tokens=200, model="opus")
    t = " ".join((out or "").strip().splitlines()[0].split()).strip(' "\'')
    return t[:200]


_ANGLES_SYSTEM = (
    "You propose several DIFFERENT episodes this channel could make next - different subjects, "
    "not rewordings of one idea. Each is a title a viewer would click and a two-sentence idea of "
    "what the episode actually shows.\n"
    "Favour a story most people believe they already know and have slightly WRONG, or a detail "
    "hiding in something they see constantly. Avoid the obvious famous-trivia subject every "
    "channel has already made; that is where a new channel disappears.\n"
    "Reply with ONLY a JSON object: "
    '{"episodes":[{"title":"...","idea":"..."}]} - nothing else.')


def _auto_title_options(project, doc, kind, lang, minutes, fmt, event=None, n=4, avoid=None):
    """Several DIFFERENT angles for the next episode, so their real YouTube demand can be compared.
    `avoid` are titles already offered in this sitting - pressing Suggest again must not repeat one."""
    user = _auto_title_ctx(project, doc, kind, lang, minutes, fmt, event)
    seen = [" ".join(str(t).split())[:200] for t in (avoid or []) if str(t).strip()][:12]
    if seen:
        user += ("\n\nALREADY OFFERED AND REJECTED - do not repeat these, and do not offer a near-"
                 "rewording of one either; go somewhere genuinely different:\n"
                 + "\n".join("- " + t for t in seen))
    user += "\n\nGIVE %d DIFFERENT EPISODES." % n
    try:
        out = _ask_json(_ANGLES_SYSTEM, user,
                        want=lambda v: isinstance(v.get("episodes"), list) and len(v["episodes"]) >= 2
                        and all(isinstance(x, dict) and x.get("title") for x in v["episodes"]))
    except Exception:
        return []
    return [{"title": " ".join(str(c.get("title", "")).split())[:200],
             "idea": " ".join(str(c.get("idea", "")).split())[:900]} for c in out["episodes"]][:n]


_NEWS_SYSTEM = """You find what the world is paying attention to right now, and then you find the
STORY behind it that a history channel can actually tell.

STEP 1 - search. What is genuinely big at this moment? Look worldwide first; if nothing worldwide stands
out, take Europe or the United States. Only things happening now or in the last few days.

WHAT COUNTS AS BIG, and this matters: not the news bulletin's idea of big. Take what people are actually
talking about and searching for - a disaster, a discovery, a record broken, a wreck or a tomb found, a
strange natural event, a rescue, a big cultural moment, a technology that suddenly appeared, an
anniversary everyone noticed.

WHAT TO LEAVE ALONE:
- Party politics, elections, campaigns, legislation, court cases, who said what about whom. Dry, dated
  within a week, and it splits an audience for nothing.
- Anything where the interest is purely financial: markets, currencies, quarterly results.
- Ongoing situations where people are in danger right now. There is no respectful history angle while it
  is still happening.

STEP 2 - the bridge. For each event, ask: what happened BEFORE that explains this, or rhymes with it?
The channel does not report the news; it tells the older story the news just made everyone curious
about. An earthquake somewhere becomes the earthquake that hit the same valley ninety years ago and what
it taught us. A wreck found becomes the night it sank. A record broken becomes the one it beat.

The bridge must be a REAL, FINISHED story with known facts - not speculation about the current event.

Return ONLY a JSON object:
{"events": [{"event": "<what happened, one line>", "where": "<region>", "when": "<date or 'this week'>",
             "bridge": "<the historical story it opens, one line>",
             "why": "<why someone searching the news would click this instead, one line>"}],
 "pick": <0-based index of the strongest one for this channel>}
Give three to five events, strongest first. If a search turns up nothing usable, return {"events": [], "pick": -1}."""


def _news_cache_get(maxage=3 * 3600):
    """One search per few hours, shared by every project. Ten runs in an evening must not mean ten
    searches - and the news does not change that fast anyway."""
    try:
        p = DATA_DIR / "news_cache.json"
        d = json.loads(p.read_text(encoding="utf-8"))
        if time.time() - float(d.get("t") or 0) < maxage and d.get("events"):
            return d
    except Exception as _qe:
        quiet(_qe, "_news_cache_get")
    return None


def _news_cache_put(d):
    try:
        d = dict(d); d["t"] = time.time()
        (DATA_DIR / "news_cache.json").write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "_news_cache_put")


def _trending_events(doc, lang="en", force=False):
    """What is happening, and the historical story each thing opens. Cached for a few hours."""
    if not force:
        c = _news_cache_get()
        if c:
            return c.get("events") or [], int(c.get("pick", 0)), True
    brief = " ".join((doc.get("brief") or "").split())[:600]
    user = ("THE CHANNEL:\n%s\n\nToday is %s. Search, then answer."
            % (brief or "(a channel that tells stories from the past)", today_ddmmyyyy()))
    try:
        out = _claude_cli_web(_NEWS_SYSTEM, user, model="opus")
    except Exception as e:
        raise RuntimeError("could not check the news (%s)" % str(e)[:120])
    d = _parse_json_obj(out) or {}
    evs = [e for e in (d.get("events") or []) if isinstance(e, dict) and e.get("event")]
    pick = int(d.get("pick", 0) or 0)
    if evs:
        _news_cache_put({"events": evs, "pick": pick})
    return evs, pick, False


def _auto_video_count(n_images, mode, ratio=0.5):
    """How many of the stills the run will turn into video, for the estimate and for the run itself."""
    if mode == "none" or n_images <= 0:
        return 0
    if mode == "all":
        return n_images
    return max(1, int(round(n_images * max(0.05, min(0.95, ratio)))))


def _auto_set(j, **kw):
    with _AUTO_LOCK:
        j.update(kw)


def _auto_log(j, msg):
    with _AUTO_LOCK:
        j.setdefault("log", []).append(msg)


def _auto_cancelled(j):
    with _AUTO_LOCK:
        return bool(j.get("cancel"))


def _auto_worker(jid, project, opts):
    j = _AUTO_JOBS[jid]
    t0 = time.time()
    try:
        doc = load_doc(project)
        if doc is None:
            raise RuntimeError("that project is gone")
        so = dict(doc.get("script_opts") or {})
        # the pickers as they are on screen RIGHT NOW beat the last-saved copy - a change made a second
        # before pressing Run must not be silently ignored because the debounced save had not landed yet
        so.update({k: v for k, v in (opts.get("opts") or {}).items() if v not in (None, "")})
        kind = "youtube" if is_youtube(doc) else "vsl"
        lang = so.get("lang") or "en"
        minutes = int(so.get("minutes") or 10)
        aware, tone, visual = so.get("aware") or "problem", so.get("tone") or "story", so.get("visual") or "realistic"
        fmt = so.get("format") or ""
        title = (opts.get("title") or so.get("title") or "").strip()
        idea = (opts.get("idea") or so.get("idea") or "").strip()
        typed_title = bool(title)          # a title the USER wrote is never renamed by the script writer

        # ---- 1. the title and the idea - only the ones that are not already there
        _auto_set(j, step="Idea", pct=2)
        _event = None
        if not title and not idea and (opts.get("topic") or "") == "news":
            try:
                _evs, _pick, _cached = _trending_events(doc, lang)
            except Exception as e:
                _evs, _pick, _cached = [], 0, False
                _auto_log(j, "Could not check the news (%s) - naming it from the channel instead."
                          % str(e)[:110])
            _seen = {str((load_doc(p) or {}).get("episode_source", {}).get("event", ""))[:80]
                     for p in (_channel_of(project)[1] or [])}
            _fresh = [e for e in _evs if str(e.get("event", ""))[:80] not in _seen] or _evs
            if _fresh:
                _event = _fresh[0] if _pick >= len(_evs) else (
                    _evs[_pick] if _evs[_pick] in _fresh else _fresh[0])
                _auto_log(j, "In the news: %s" % str(_event.get("event"))[:150])
                _auto_log(j, "The story it opens: %s" % str(_event.get("bridge"))[:190])
                if _cached:
                    _auto_log(j, "(from the last news check, less than three hours old)")
        if not title and not idea:
            # Nothing to go on: name the episode from the channel brief and the target viewer in
            # Settings - but do not name it blind. Ask for several DIFFERENT angles, look each one up
            # on YouTube, and take the one real numbers say has a chance. A topic where every small
            # channel sank is sixty images spent on a video nobody will find.
            picked = None
            if kind == "youtube":
                try:
                    cands = _auto_title_options(project, doc, kind, lang, minutes, fmt, event=_event)
                except Exception:
                    cands = []
                if cands:
                    _auto_log(j, "Checking %d angles against what YouTube already rewards..." % len(cands))
                    picked, _scored = _demand_pick(project, doc, cands, minutes,
                                                   log=lambda m: _auto_log(j, "   " + m))
            if picked:
                title, idea = picked["title"], picked.get("idea") or ""
                _auto_log(j, "Chose: %s" % title)
                doc["episode_demand"] = picked.get("demand") or {}
            else:
                title = _auto_title(project, doc, kind, lang, minutes, fmt, event=_event)
            if _event:
                idea = " ".join(("%s %s" % (_event.get("bridge") or "",
                                            _event.get("why") or "")).split())[:1200]
            if not title:
                raise RuntimeError("could not name an episode - write a title, or fill in the channel "
                                   "brief and target viewer in Settings")
            _auto_log(j, "Named the episode from the channel: %s" % title)
        elif typed_title:
            _auto_log(j, "Used the title already written.")
            if kind == "youtube":
                try:
                    cfg = _load_config()
                    if (cfg.get("youtube_token") or {}).get("refresh_token"):
                        d = youtube.demand(cfg, _demand_queries(title, idea), our_minutes=minutes,
                                           keep=_demand_filter(title, idea),
                                           note=lambda m: _auto_log(j, m))
                        _save_config(cfg)
                        doc["episode_demand"] = d
                        _auto_log(j, "YouTube says this topic looks %s. %s" % (d["verdict"].upper(), d["why"]))
                except Exception as _qe:
                    quiet(_qe, "_auto_worker")                      # a demand check is never a reason to stop the run
        _auto_set(j, pct=4)
        if not idea:
            gi = "auto-gi-%s" % jid
            _RS_JOBS[gi] = {"status": "running", "pct": 0, "step": "", "error": None, "idea": ""}
            _gi_worker(gi, title, minutes, kind, lang, aware, tone, visual, project, fmt)
            if _RS_JOBS[gi]["status"] == "error":
                raise RuntimeError("idea: " + (_RS_JOBS[gi].get("error") or "failed"))
            idea = _RS_JOBS[gi]["idea"]
            _auto_log(j, "Wrote the idea (%d words)." % len(idea.split()))
        else:
            _auto_log(j, "Used the idea already written.")
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")

        # ---- 2. the script
        _auto_set(j, step="Script", pct=12)
        gs = "auto-gs-%s" % jid
        _GS_JOBS[gs] = {"status": "running", "pct": 0, "step": "", "error": None,
                        "script": "", "title": "", "words": 0, "cancel": False}
        _gs_worker(gs, title, idea, minutes, kind, lang, aware, tone, visual, project, fmt)
        if _GS_JOBS[gs]["status"] != "done":
            raise RuntimeError("script: " + (_GS_JOBS[gs].get("error") or "failed"))
        script = _GS_JOBS[gs]["script"]
        if not typed_title:                # only fill a title in; never overwrite one that already existed
            title = _GS_JOBS[gs].get("title") or title
        _auto_log(j, "Wrote the script - %d words, about %d min."
                  % (_GS_JOBS[gs]["words"], max(1, round(_GS_JOBS[gs]["words"] / 150.0))))
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")

        # ---- 3. review it, and apply what it asks for
        _auto_set(j, step="Review", pct=42)
        rs = "auto-rs-%s" % jid
        _RS_JOBS[rs] = {"status": "running", "pct": 0, "step": "", "error": None, "score": 0,
                        "verdict": "", "summary": "", "sections": [], "fixes": [], "words": 0}
        _rs_worker(rs, script, title, idea, minutes, kind, lang, aware, tone, visual, fmt)
        score_before = None
        if _RS_JOBS[rs]["status"] == "done":
            score_before = _RS_JOBS[rs]["score"]
            fixes = _RS_JOBS[rs].get("fixes") or []
            _auto_log(j, "Reviewed it: %d/100 - %s" % (score_before, _RS_JOBS[rs].get("verdict") or ""))
            if fixes and opts.get("apply_fixes", True):
                af = "auto-af-%s" % jid
                _RS_JOBS[af] = {"status": "running", "pct": 0, "step": "", "error": None, "script": "", "words": 0}
                _af_worker(af, script, fixes, lang, target_words=minutes * _GS_WPM)
                if _RS_JOBS[af]["status"] == "done" and _RS_JOBS[af]["script"]:
                    # Score it AGAIN. "Applied 3 changes" says nothing about whether the script got
                    # better, and a rewrite can just as easily lose what was working. Measure, say the
                    # number out loud, and keep whichever version actually scored higher.
                    cand = _RS_JOBS[af]["script"]
                    rs2 = "auto-rs2-%s" % jid
                    _RS_JOBS[rs2] = {"status": "running", "pct": 0, "step": "", "error": None,
                                     "score": 0, "verdict": "", "fixes": []}
                    try:
                        _rs_worker(rs2, cand, title, idea, minutes, kind, lang, aware, tone, visual, fmt)
                    except Exception as _qe:
                        quiet(_qe, "_auto_worker")
                    after = _RS_JOBS[rs2].get("score") if _RS_JOBS[rs2].get("status") == "done" else None
                    if after is None:
                        script = cand
                        _auto_log(j, "Applied %d change(s) the review asked for (could not re-score)."
                                  % len(fixes))
                    elif score_before is not None and after < score_before:
                        _auto_log(j, "Applied the review's %d change(s) and the script scored WORSE "
                                     "(%d/100 against %d) - kept the original."
                                  % (len(fixes), after, score_before))
                    else:
                        script = cand
                        _auto_log(j, "Applied %d change(s): %s/100 -> %d/100. %s"
                                  % (len(fixes), score_before, after,
                                     _RS_JOBS[rs2].get("verdict") or ""))
                        j["score_after"] = after
                else:
                    _auto_log(j, "Could not apply the review's changes - kept the script as written.")
        else:
            _auto_log(j, "The review did not come back (%s) - carried on with the script as written."
                      % (_RS_JOBS[rs].get("error") or "no reason given"))
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")

        # ---- 2b. is any of it untrue?
        # The review above scores structure and pace; it has no opinion on whether a sentence is TRUE.
        # That gap let a script say a bath overflow joins the drain BELOW the trap - which would vent
        # the sewer into the bathroom - because the brief said so and nobody asked. Definite errors are
        # corrected here and every correction is written into the log; judgement calls are carried to
        # the money gate, where somebody is already reading, rather than quietly rewritten.
        soft = []
        try:
            issues = factcheck_script(script, title, idea)
        except Exception as e:
            issues = []
            _auto_log(j, "Could not fact-check the script (%s) - carried on." % str(e)[:90])
        if issues:
            script, fixed = apply_factchecks(script, issues)
            soft = [i for i in issues if i["severity"] != "wrong"]
            for i in fixed:
                _auto_log(j, "Fact-check corrected: %s" % i["problem"][:190])
            if soft:
                _auto_log(j, "%d claim(s) are arguable rather than wrong - listed before the images."
                          % len(soft))
        j["factcheck"] = {"fixed": [i["problem"] for i in issues if i["severity"] == "wrong"],
                          "soft": [{"quote": i["quote"], "problem": i["problem"]} for i in soft]}
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")

        # ---- 4. punctuation, so the voice-over reads it cleanly
        _auto_set(j, step="Punctuation", pct=58)
        pj = "auto-pu-%s" % jid
        _PUNCT_JOBS[pj] = {"status": "running", "pct": 0, "step": "", "error": None,
                           "text": "", "changed": False, "skipped": 0}
        _punct_worker(pj, script)
        if _PUNCT_JOBS[pj]["status"] == "done" and _PUNCT_JOBS[pj]["text"]:
            script = _PUNCT_JOBS[pj]["text"]
            _auto_log(j, "Fixed the punctuation%s."
                      % ("" if not _PUNCT_JOBS[pj]["skipped"] else " (%d block(s) left as-is)" % _PUNCT_JOBS[pj]["skipped"]))
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")

        # the script is the project's now, whatever happens next
        doc = load_doc(project) or doc
        doc["script"] = script
        doc["script_draft"] = script
        so.update({"title": title, "idea": idea})
        doc["script_opts"] = so
        if _event:
            doc["episode_source"] = {"event": _event.get("event"), "when": _event.get("when"),
                                     "bridge": _event.get("bridge")}
        doc["auto_opts"] = dict(_AUTO_POLICY, **{k: bool(v) for k, v in (opts.get("policy") or {}).items()
                                                 if k in _AUTO_POLICY})
        save_doc(project, doc)

        # ---- 5. split + direct
        _auto_set(j, step="Scenes", pct=66)
        parts = split_script(script, youtube=is_youtube(doc))
        _auto_log(j, "Split into %d scenes." % len(parts))
        if not [c for c in (doc.get("characters") or []) if c.get("name")]:
            for d in detect_cast(script, doc.get("brief", "")):
                doc.setdefault("characters", []).append(
                    {"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"],
                     "urls": [], "auto": True})
            _auto_log(j, "Found %d recurring people." % len(doc.get("characters") or []))
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")
        _auto_set(j, pct=72, step="Scenes")
        plan, _meta = direct_scenes(parts, doc.get("characters"), doc.get("audience"),
                                    doc.get("brief", ""), ingredients=doc.get("ingredients"),
                                    product_name=(doc.get("product") or {}).get("name", ""),
                                    no_funnel=is_youtube(doc), look=_doc_scene_style(doc))
        doc["scenes"] = []
        for i, (vo, a) in enumerate(zip(parts, plan), 1):
            sc = new_scene(i)
            sc["vo"] = vo
            sc["prompt"] = a.get("prompt") or ""
            sc["cast"] = a.get("cast") or []
            sc["generic"] = a.get("generic")
            sc["camera"] = a.get("camera") or DEFAULT_CAMERA
            sc["transition"] = a.get("transition") or DEFAULT_TRANSITION
            sc["style"] = _doc_scene_style(doc) or a.get("style") or DEFAULT_STYLE
            sc["bg"] = _doc_scene_bg(doc) or DEFAULT_BG
            # a YouTube episode wants a living camera; a VSL keeps the locked-off default it always had
            sc["video_cam_lock"] = False
            _yt = is_youtube(doc)
            sc["product_suggested"] = (not _yt) and bool(a.get("product_suggested"))
            sc["split"] = (not _yt) and bool(a.get("split"))
            sc["testimonial"] = (not _yt) and bool(a.get("testimonial"))
            doc["scenes"].append(sc)
        save_doc(project, doc)
        failed = sum(1 for a in plan if a.get("director_failed"))
        _auto_log(j, "Directed every scene%s." % ("" if not failed else " (%d could not be written)" % failed))

        # ---- 6. the gate: what the next step would cost, before it costs it
        _auto_set(j, step="Estimate", pct=100)
        need = [s for s in doc["scenes"] if (s.get("prompt") or "").strip()]
        _vok, _vmsg = _eleven_check(opts.get("voice_id") or doc.get("voice_id") or "")
        if not _vok:
            _auto_log(j, "Heads up - no narration yet: %s." % _vmsg)
        bal = None
        try:
            bal = fetch_kie_balance() if _key('KIE_API_KEY') else None
        except Exception:
            bal = None
        _vmode = (opts.get("video_mode") or "all")
        _vids = _auto_video_count(len(need), _vmode, float(opts.get("video_ratio") or 0.5))
        est = {"scenes": len(doc["scenes"]), "images": len(need), "failed": failed,
               "videos": _vids, "video_mode": _vmode,
               "words": len(re.findall(r"[^\W_]+", script, re.UNICODE)),
               "minutes_written": max(1, round(len(script.split()) / 150.0)),
               "balance": bal, "elapsed": int(time.time() - t0), "concurrency": IMG_CONCURRENCY,
               "voice_ok": _vok, "voice_msg": _vmsg,
               "from_news": (_event or {}).get("event") if _event else "",
               "policy": doc.get("auto_opts") or dict(_AUTO_POLICY),
               "factcheck": j.get("factcheck") or {},
               "will_pause": bool(opts.get("review_images") and not opts.get("reviewed")),
               "eta_images_min": max(1, int(round(
                   ((len(need) + IMG_CONCURRENCY - 1) // IMG_CONCURRENCY) * 45 / 60.0)))}
        with _AUTO_LOCK:
            j.update(status="awaiting", estimate=est, title=title)
        _auto_log(j, "Ready. %d scenes, %d images to generate." % (len(doc["scenes"]), len(need)))
    except Exception as e:
        msg = "cancelled" if str(e) == "cancelled" else str(e)[:300]
        with _AUTO_LOCK:
            j.update(status="error", error=msg)


@app.route("/api/auto/start/<project>", methods=["POST"])
def api_auto_start(project):
    if load_doc(project) is None:
        abort(404)
    b = request.get_json(silent=True) or {}
    jid = "auto-%d" % int(time.time() * 1000)
    with _AUTO_LOCK:
        _AUTO_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None,
                           "log": [], "estimate": None, "title": "", "cancel": False,
                           "steps": list(_AUTO_STEPS)}
    _KeyThread(target=_auto_worker, daemon=True, args=(jid, project, b)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/auto/job/<jid>")
def api_auto_job(jid):
    with _AUTO_LOCK:
        j = _AUTO_JOBS.get(jid)
        return jsonify(dict(j) if j else {"status": "error", "error": "unknown job", "pct": 0, "step": ""})


@app.route("/api/auto/cancel/<jid>", methods=["POST"])
def api_auto_cancel(jid):
    with _AUTO_LOCK:
        j = _AUTO_JOBS.get(jid)
        if j:
            j["cancel"] = True
    return jsonify({"ok": True})


# ---------- Auto Episode, the second half: past the gate, unattended, all the way to the render -------
# Everything here is the same call a button makes. The two things that are genuinely new are (a) the
# polling: images and videos are normally driven by the open browser, and nobody is watching now, so the
# server pumps its own queue; and (b) the rule about what an unattended run may add - _AUTO_POLICY.
_AUTO2_STEPS = ["Voice-over", "Subtitles", "Cast", "Images", "Check Images",
                "Transitions", "Approve", "Effects", "Videos", "Music", "Render", "Publish"]
_AUTO_PUMP_SEC = 6          # how often the server collects finished Kie tasks
_AUTO_STALL_MIN = 25        # give up on a queue that has not moved at all for this long


def _auto_run_record(project):
    """The last run's own account of itself, as left on disk."""
    try:
        d, _ = proj_dir(project)
        return json.loads((d / "auto_run.json").read_text(encoding="utf-8"))
    except Exception:
        return None


def _auto_mark_interrupted():
    """A run still saying 'running' at start-up died with the process it was in. Say so on disk, so the
    project can offer to pick it up instead of showing a record that claims to be live."""
    n = 0
    try:
        for p in PROJECTS.iterdir():
            f = p / "auto_run.json"
            if not (p.is_dir() and f.exists()):
                continue
            try:
                rec = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            if rec.get("status") == "running":
                rec["status"] = "interrupted"
                rec.setdefault("log", []).append("The app closed while this was running.")
                f.write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
                n += 1
    except Exception as _qe:
        quiet(_qe, "_auto_mark_interrupted")
    return n


def _auto_save_run(project, j):
    """Keep the run on disk. A run is now hours long; if the app restarts we must still be able to say
    what it was doing and how far it got, instead of the job vanishing with the process."""
    try:
        d, _ = proj_dir(project)
        (d / "auto_run.json").write_text(
            json.dumps({k: v for k, v in j.items() if k != "cancel"}, ensure_ascii=False), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "_auto_save_run")


def _auto_pump(j, project, kind, step, pct_from, pct_to, expect):
    """Drive the Kie queue for `kind` ("image"/"video") until nothing is queued or generating any more.
    Returns (done, failed). The browser's poll loop does exactly this; here the server does it."""
    t0 = last_change = time.time()
    seen_done = -1
    while True:
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")
        try:
            with app.test_request_context():
                _api_poll(project)                      # collects finished tasks AND submits the next batch
        except Exception as _qe:
            quiet(_qe, "_auto_pump")                                        # a transient Kie/network blip must not end the run
        doc = load_doc(project) or {}
        scenes = doc.get("scenes") or []
        busy = sum(1 for s in scenes if (s.get(kind) or {}).get("status") in ("queued", "generating"))
        done = sum(1 for s in scenes if (s.get(kind) or {}).get("status") == "ready")
        failed = sum(1 for s in scenes if (s.get(kind) or {}).get("status") == "error")
        if done != seen_done:
            seen_done, last_change = done, time.time()
        span = max(1, expect)
        _auto_set(j, step=step, pct=int(pct_from + (pct_to - pct_from) * min(1.0, (done + failed) / float(span))),
                  detail="%d of %d done%s" % (done, span, "" if not failed else ", %d failed" % failed))
        _auto_save_run(project, j)
        if not busy:
            return done, failed
        if (time.time() - last_change) > _AUTO_STALL_MIN * 60:
            _auto_log(j, "%s stopped moving for %d min - carried on with what finished."
                      % (step, _AUTO_STALL_MIN))
            return done, failed
        time.sleep(_AUTO_PUMP_SEC)


def _auto_queue(project, ids, kind):
    """Put scenes into the generation queue and submit the first batch, without the HTTP route."""
    doc = load_doc(project)
    if doc is None:
        return 0
    d, safe = proj_dir(project)
    want = set(ids)
    n = 0
    for s in doc["scenes"]:
        if s["id"] not in want:
            continue
        if kind == "image" and not (s.get("prompt") or "").strip():
            s["image"].update(status="error", error="no prompt")
            continue
        s[kind].update(status="queued", error=None, taskId=None)
        n += 1
    if kind == "image":
        _drain_image_queue(doc, d, safe)
    else:
        _drain_video_queue(doc, d, safe)
    save_doc(project, doc)
    return n


def _approve_ready_images(project):
    """Approve every scene that actually has an image, locking the version on screen. Same rules as the
    Approve All button - a scene with no image is skipped, never force-approved."""
    doc = load_doc(project)
    if doc is None:
        return 0, []
    ok, skipped = 0, []
    for s in doc.get("scenes") or []:
        img = s.get("image") or {}
        vs = img.get("versions", [])
        if not vs:
            skipped.append(s["id"])
            continue
        s["approved"] = True
        img["approved_version"] = img.get("current", len(vs) - 1)
        norm_scene(s)
        _auto_anchor(doc, s)
        ok += 1
    save_doc(project, doc)
    return ok, skipped


def _eleven_usable_voices(limit=5):
    """The voices this account is actually allowed to speak with, for when the chosen one is refused."""
    try:
        r = requests.get("https://api.elevenlabs.io/v1/voices",
                         headers={"xi-api-key": _key('ELEVENLABS_API_KEY')}, timeout=20)
        if r.status_code != 200:
            return []
        return [v.get("name") for v in ((r.json() or {}).get("voices") or []) if v.get("name")][:limit]
    except Exception:
        return []


def _eleven_check(voice_id=""):
    """Can this project actually SPEAK? Asked by doing it - two characters, with the exact voice the run
    will use. A valid key is not the question: a key can be perfectly good and still be refused for a
    particular voice, which is how a run once got three minutes in before finding out."""
    if not _key('ELEVENLABS_API_KEY'):
        return False, "there is no ElevenLabs key in this project's Settings"
    if not (voice_id or "").strip():
        return False, "no voice has been chosen - set a Voice ID on the Script tab"
    try:
        r = requests.post(
            "https://api.elevenlabs.io/v1/text-to-speech/%s" % voice_id.strip(),
            headers={"xi-api-key": _key('ELEVENLABS_API_KEY'), "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": "Hi.", "model_id": ELEVEN_MODEL}, timeout=60)
    except Exception as e:
        return False, "could not reach ElevenLabs (%s)" % str(e)[:90]
    if r.status_code == 200 and r.content:
        return True, ""
    msg = ""
    try:
        det = (r.json() or {}).get("detail") or {}
        msg = det.get("message") if isinstance(det, dict) else str(det)
    except Exception:
        msg = (r.text or "")[:160]
    if r.status_code == 402:
        # the usual one: a Voice Library voice on a free plan. Name what WOULD work instead of just refusing
        have = _eleven_usable_voices()
        extra = ("  Voices you can use on this plan: %s." % ", ".join(have)) if have else ""
        return False, ("ElevenLabs will not use that voice on this plan (%s).%s"
                       % ((msg or "payment required")[:150], extra))
    if r.status_code in (401, 403):
        return False, ("ElevenLabs rejected the key (%s)" % (msg or ("HTTP %d" % r.status_code))[:150])
    return False, ("ElevenLabs said no (%s)" % (msg or ("HTTP %d" % r.status_code))[:160])


def _auto_voiceover(project, doc, voice_id, text):
    """The ElevenLabs call the Generate Voiceover button makes, without the route."""
    if not _key('ELEVENLABS_API_KEY'):
        return False, "no ElevenLabs key in Settings"
    if not voice_id:
        return False, "no voice ID chosen"
    d, _ = proj_dir(project)
    try:
        r = requests.post(
            "https://api.elevenlabs.io/v1/text-to-speech/%s" % voice_id,
            headers={"xi-api-key": _key('ELEVENLABS_API_KEY'), "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL,
                  "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=900)
    except Exception as e:
        return False, "request failed: %s" % e
    if r.status_code != 200:
        return False, "ElevenLabs %d: %s" % (r.status_code, r.text[:200])
    (d / "voiceover").mkdir(exist_ok=True)
    (d / "voiceover" / "voiceover.mp3").write_bytes(r.content)
    return True, None


def _auto_srt(project, doc):
    """Align the generated voice-over against the script, exactly as the Generate SRT button does with
    'use the voice-over above' + 'use the script from the left' ticked."""
    d, _ = proj_dir(project)
    gen = d / "voiceover" / "voiceover.mp3"
    if not gen.exists():
        return False, "there is no voice-over to align to"
    wd = sub_dir(project)
    if wd.exists():
        shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True, exist_ok=True)
    audio_path = wd / "audio.mp3"
    shutil.copyfile(gen, audio_path)
    docx_path = wd / "script.docx"
    text_to_docx(doc.get("script") or doc.get("script_draft") or "", docx_path)
    proj = fname_slug(doc.get("title") or project)
    out_path = wd / ("%s_Subtitle_%s.srt" % (proj, today_ddmmyyyy()))
    lang = (doc.get("subtitle_lang") or "").strip() or audience_lang(doc.get("audience"))
    set_sub_status(project, status="running", step="Starting...", srt=None, trimmed=None,
                   trimmed_name=None, error=None, audio_name="Generated voice-over",
                   docx_name="Script", use_gen_vo=True, use_script=True)
    # reconcile=False: the audio was spoken FROM this script, so the words already match
    _KeyThread(target=run_subtitle_job, daemon=True,
                     args=(project, audio_path, docx_path, out_path, None, lang),
                     kwargs={"reconcile": False}).start()
    return True, None


def _auto_cast_portraits(j, project):
    """Give every named character without a photo one generated portrait, and commit it. Scene images
    reference these, so they have to exist first."""
    doc = load_doc(project)
    made, failed = 0, []
    chars = [c for c in (doc.get("characters") or []) if c.get("name") and not (c.get("urls") or [])]
    for i, ch in enumerate(chars, 1):
        if _auto_cancelled(j):
            raise RuntimeError("cancelled")
        _auto_set(j, detail="%s (%d of %d)" % (ch.get("name") or "character", i, len(chars)))
        d, _ = proj_dir(project)
        (d / "refs").mkdir(parents=True, exist_ok=True)
        try:
            rel, cerr = _run_char_candidate(
                d, ch["id"], _char_portrait_prompt(ch, doc.get("audience"), _doc_scene_style(doc)), [])
        except Exception as e:
            rel, cerr = None, str(e)[:120]
        if cerr or not rel:
            failed.append(ch.get("name") or ch["id"])
            continue
        newname = "char_%s_%d_gen.png" % (ch["id"], int(time.time() * 1000))
        try:
            (d / rel).rename(d / "refs" / newname)
        except Exception:
            try:
                shutil.copyfile(d / rel, d / "refs" / newname)
                (d / rel).unlink()
            except Exception:
                failed.append(ch.get("name") or ch["id"])
                continue
        doc = load_doc(project)                       # reload: the candidate call wrote to disk
        live = next((c for c in (doc.get("characters") or []) if c.get("id") == ch["id"]), None)
        if live is None:
            continue
        _norm_char(live)
        live["urls"].append("refs/%s" % newname)
        _rebind_all_cast(doc)
        save_doc(project, doc)
        made += 1
    return made, failed


def _auto_settled(s, kind):
    """True when this scene needs nothing more from us for `kind`: either it is finished, or it is
    already out at Kie under a task id we have paid for and the pump will collect."""
    m = s.get(kind) or {}
    return m.get("status") == "ready" or (m.get("status") in ("generating", "queued") and m.get("taskId"))


def _auto_video_ids(doc, mode, ratio=0.5):
    """Which approved scenes become video. 'all' = every one, 'none' = stills only, 'mix' = an even
    spread across the episode so the motion is distributed instead of bunched at the front."""
    ready = [s for s in (doc.get("scenes") or [])
             if s.get("approved") and ((s.get("image") or {}).get("approved_file") or (s.get("image") or {}).get("file"))
             and not _auto_settled(s, "video")]
    if mode == "none" or not ready:
        return []
    if mode == "all":
        return [s["id"] for s in ready]
    keep = max(1, int(round(len(ready) * max(0.05, min(0.95, ratio)))))
    step = len(ready) / float(keep)
    picked = {ready[min(len(ready) - 1, int(round(i * step)))]["id"] for i in range(keep)}
    return sorted(picked)


# Every episode ends on a held shot that dips away instead of stopping dead. A still can simply be held
# for the extra seconds; a clip cannot, so the LAST clip is asked for long enough to cover the hold.
OUTRO_FADE_SEC = 4.5
DEFAULT_PUBLISH_SLOTS = [{"dow": 2, "time": "20:00"}, {"dow": 5, "time": "20:00"}]   # Wed + Sat, 20:00


def _auto_fit_video_durations(j, project, vids):
    """Order every clip at the length of the line it has to cover.

    The renderer fills a slot longer than its clip by SLOWING the clip - a 6 s shot stretched over a 10 s
    line is visibly slow motion. Asking for the right length in the first place removes that entirely, and
    costs nothing extra to decide: the subtitle alignment already knows how long each line takes to say.

    The last shot's slot already includes the closing fade (see _build_timeline), so it is covered here
    too without any special case. Models only offer a fixed ladder of lengths, so each scene gets the
    shortest one that still covers its line - never a shorter one, which would mean slow motion again."""
    doc = load_doc(project)
    if doc is None or not vids:
        return
    try:
        tl = _build_timeline(project, doc)
    except Exception as e:
        _auto_log(j, "Could not measure the lines (%s) - clips keep their default length." % str(e)[:90])
        return
    span = {it.get("id"): float(it["end"]) - float(it["start"]) for it in (tl.get("scenes") or [])}
    want = set(vids)
    tally, over = {}, []
    for s in doc.get("scenes") or []:
        need = span.get(s.get("id"))
        if s.get("id") not in want or not need:
            continue
        cfg = VIDEO_MODEL_BY_KEY.get(s.get("video_model") or DEFAULT_VIDEO_MODEL) or {}
        durs = sorted(cfg.get("durations") or [6])
        whole = int(need) + (1 if need > int(need) + 0.01 else 0)      # never round DOWN past the line
        pick = next((d for d in durs if d >= whole), durs[-1])
        if pick < whole:
            over.append(s["id"])          # the line is longer than the model will make in one clip
        s["video_dur"] = pick
        tally[pick] = tally.get(pick, 0) + 1
    save_doc(project, doc)
    if tally:
        _auto_log(j, "Ordered each clip at the length of its line (%s)."
                  % ", ".join("%ds x%d" % (k, tally[k]) for k in sorted(tally)))
    if over:
        # say it out loud: these are the only ones the renderer will still have to stretch
        _auto_log(j, "%d line(s) run longer than the %ds this model will make in one go - those clips "
                     "get slowed to fill their slot. Split those scenes if it shows."
                  % (len(over), durs[-1]))


def _next_publish_slot(slots, taken, now=None):
    """The next free slot on the channel's calendar. `taken` are ISO times other episodes already hold,
    so two finished episodes never land on the same evening."""
    now = now or datetime.now()
    busy = set()
    for t in taken or []:
        try:
            busy.add(datetime.fromisoformat(t).replace(second=0, microsecond=0))
        except Exception as _qe:
            quiet(_qe, "_next_publish_slot")
    for day in range(0, 120):
        d = (now + timedelta(days=day)).date()
        for sl in sorted(slots, key=lambda x: str(x.get("time"))):
            try:
                hh, mm = [int(x) for x in str(sl.get("time") or "20:00").split(":")[:2]]
            except Exception:
                hh, mm = 20, 0
            if int(sl.get("dow", 5)) != d.weekday():
                continue
            when = datetime(d.year, d.month, d.day, hh, mm)
            if when <= now + timedelta(minutes=10) or when in busy:
                continue
            return when
    return None


def _publish_taken(exclude=None):
    out = []
    try:
        for p in PROJECTS.iterdir():
            if not p.is_dir() or p.name == exclude:
                continue
            try:
                pub = (_peek_doc(p / "scenes.json") or {}).get("publish") or {}
            except Exception:
                continue
            if pub.get("scheduled_for") and pub.get("status") in ("pending", "scheduled"):
                out.append(pub["scheduled_for"])
    except Exception as _qe:
        quiet(_qe, "_publish_taken")
    return out


def _auto_schedule_publish(project, doc, opts):
    """Book the episode onto the channel's calendar. The upload itself needs the user's Google sign-in,
    which does not exist yet - so the slot is reserved and the state says plainly what is missing."""
    cfg = _load_config()
    slots = opts.get("slots") or cfg.get("publish_slots") or DEFAULT_PUBLISH_SLOTS
    when = _next_publish_slot(slots, _publish_taken(exclude=project))
    connected = bool(cfg.get("youtube_token"))
    pub = {"scheduled_for": when.isoformat(timespec="minutes") if when else None,
           "privacy": opts.get("privacy") or cfg.get("publish_privacy") or "private",
           "status": "scheduled" if connected else "pending",
           "title": (doc.get("script_opts") or {}).get("title") or doc.get("title") or project}
    # whatever the user set by hand on the Publish panel outlives an automatic run
    prev = dict(doc.get("publish") or {})
    for k in ("thumb", "thumb_ts", "thumb_bench", "description", "tags"):
        if prev.get(k):
            pub[k] = prev[k]
    # nothing written by hand? then write it now, from this episode - an unattended run should not leave
    # the description and the tags empty. A failure here must not take the run down with it.
    if not (pub.get("description") and pub.get("tags")):
        try:
            with app.test_request_context(json={"title": pub.get("title")}):
                doc["publish"] = pub
                save_doc(project, doc)
                r = api_publish_meta(project)
                m = r.get_json() if hasattr(r, "get_json") else (r[0].get_json() if isinstance(r, tuple) else {})
            doc = load_doc(project) or doc
            pub = dict(doc.get("publish") or pub)
            if m and not m.get("error"):
                pub.setdefault("description", "")
                pub.setdefault("tags", "")
                if not pub["description"]:
                    pub["description"] = m.get("description") or ""
                if not pub["tags"]:
                    pub["tags"] = m.get("tags") or ""
        except Exception as _qe:
            quiet(_qe, "_auto_schedule_publish")          # the run must not fall over because a description could not be written
    if prev.get("slot_manual") and prev.get("scheduled_for"):
        # somebody already said when this one goes out; do not move it
        for k in ("scheduled_for", "date", "time", "slot_manual"):
            if prev.get(k) is not None:
                pub[k] = prev[k]
        try:
            when = datetime.fromisoformat(prev["scheduled_for"])
        except Exception as _qe:
            quiet(_qe, "_auto_schedule_publish")
    doc["publish"] = pub
    save_doc(project, doc)
    d, _ = proj_dir(project)
    cover = "" if (pub.get("thumb") and (d / pub["thumb"]).exists()) else (
        " There is no thumbnail on it yet - make one in Studio and press Use As Episode Thumbnail.")
    if not when:
        return "The episode is rendered, but there is no publishing slot set up yet." + cover
    nice = when.strftime("%a %d %b, %H:%M")
    head = ("Booked to go out %s." % nice) if connected else (
        "Held for %s. Nothing was uploaded - YouTube still needs your Google sign-in." % nice)
    return head + cover


def _auto2_worker(jid, project, opts):
    j = _AUTO_JOBS[jid]
    t0 = time.time()
    try:
        doc = load_doc(project)
        if doc is None:
            raise RuntimeError("that project is gone")
        pol = dict(_AUTO_POLICY, **(doc.get("auto_opts") or {}))
        script = doc.get("script") or doc.get("script_draft") or ""
        scenes = doc.get("scenes") or []
        if not scenes:
            raise RuntimeError("there are no scenes yet - run the first half first")
        _auto_set(j, steps=list(_AUTO2_STEPS), status="running")

        # Nothing downstream survives a missing voice-over: no narration means no subtitle, and no
        # subtitle means no render. Find that out now, while the only thing spent is a few seconds.
        _vo_have = (proj_dir(project)[0] / "voiceover" / "voiceover.mp3").exists()
        if not _vo_have:
            _vok, _vmsg = _eleven_check(opts.get("voice_id") or doc.get("voice_id") or "")
            if not _vok:
                raise RuntimeError("cannot start: %s. Fix that and press Run again - nothing was spent."
                                   % _vmsg)

        # ---- 1. voice-over
        _auto_set(j, step="Voice-over", pct=2, detail="")
        vid = (opts.get("voice_id") or doc.get("voice_id") or "").strip()
        _vo_file = proj_dir(project)[0] / "voiceover" / "voiceover.mp3"
        if opts.get("resume") and _vo_file.exists():
            # picking a run back up: the recording is already bought and paid for
            ok, err = True, None
            _auto_log(j, "The voice-over was already recorded - kept it.")
        else:
            ok, err = _auto_voiceover(project, doc, vid, script)
            if ok:
                _auto_log(j, "Recorded the voice-over.")
        if ok:
            doc = load_doc(project); doc["voice_id"] = vid; save_doc(project, doc)
        else:
            _auto_log(j, "No voice-over (%s) - carried on; the render will have no narration." % err)
        if _auto_cancelled(j): raise RuntimeError("cancelled")

        # ---- 2. subtitles from that voice-over
        _auto_set(j, step="Subtitles", pct=8, detail="")
        if opts.get("resume") and _find_srt(proj_dir(project)[0]):
            _auto_log(j, "The subtitles were already aligned - kept them.")
        elif ok:
            sok, serr = _auto_srt(project, load_doc(project))
            if sok:
                while True:
                    st = get_sub_status(project) or {}
                    if st.get("status") != "running":
                        break
                    if _auto_cancelled(j): raise RuntimeError("cancelled")
                    _auto_set(j, detail=st.get("step") or "aligning...")
                    time.sleep(4)
                st = get_sub_status(project) or {}
                _auto_log(j, "Subtitles aligned." if st.get("srt")
                          else "Subtitles did not come out (%s)." % (st.get("error") or "unknown"))
            else:
                _auto_log(j, "Subtitles skipped: %s" % serr)
        else:
            _auto_log(j, "Subtitles skipped - there is no voice-over to align to.")
        if _auto_cancelled(j): raise RuntimeError("cancelled")

        # ---- 3. cast portraits (scene images reference them, so they come first)
        _auto_set(j, step="Cast", pct=14, detail="")
        made, cfailed = _auto_cast_portraits(j, project)
        if made or cfailed:
            _auto_log(j, "Photographed %d character(s)%s."
                      % (made, "" if not cfailed else "; could not do %s" % ", ".join(cfailed[:4])))

        # ---- 4. scene images
        _auto_set(j, step="Images", pct=18, detail="")
        doc = load_doc(project)
        need = [s["id"] for s in doc["scenes"]
                if (s.get("prompt") or "").strip() and not _auto_settled(s, "image")]
        if need:
            _auto_queue(project, need, "image")
            d1, f1 = _auto_pump(j, project, "image", "Images", 18, 42, len(need))
            _auto_log(j, "Generated %d image(s)%s." % (d1, "" if not f1 else ", %d failed" % f1))
        else:
            _auto_log(j, "Every scene already had an image.")

        # ---- 5. Check Images, then one capped round of regeneration
        _auto_set(j, step="Check Images", pct=44, detail="")
        if opts.get("reviewed"):
            # They stopped the run, went through every picture themselves and approved what they wanted.
            # Re-checking that by machine is the one thing this step must not do.
            _auto_log(j, "You checked the pictures yourself - skipped the automatic check.")
            qj = None
        else:
            qj = "auto-qa-%s" % jid
        if qj:
            IMGQA_JOBS[qj] = {"status": "running", "pct": 0, "step": "", "error": None, "report": None}
            try:
                _imgqa_worker(qj, project)
            except Exception as e:
                IMGQA_JOBS[qj].update(status="error", error=str(e)[:200])
        rep = ((IMGQA_JOBS.get(qj) or {}).get("report") or {}) if qj else {}
        regen = [i for i in (rep.get("regen_ids") or [])][:400]
        if not qj:
            pass
        elif IMGQA_JOBS[qj].get("status") != "done":
            _auto_log(j, "The image check did not finish (%s) - kept every image."
                      % (IMGQA_JOBS[qj].get("error") or "no reason given"))
        elif regen:
            # ONE retry only. A scene that fails twice is left for a human; an uncapped loop would
            # quietly burn credits all night on the same bad prompt.
            _auto_log(j, "The check flagged %d image(s); their prompts were fixed - regenerating once."
                      % len(regen))
            _auto_queue(project, regen, "image")
            _auto_pump(j, project, "image", "Check Images", 48, 56, len(regen))
        else:
            _auto_log(j, "Checked every image - nothing flagged.")
        if _auto_cancelled(j): raise RuntimeError("cancelled")

        # ---- 6. transitions
        _auto_set(j, step="Transitions", pct=58, detail="")
        if opts.get("reviewed"):
            # The stop comes AFTER this step, so on a continue they are already in the project. Running
            # it again would also overwrite any transition changed by hand during the stop.
            _auto_log(j, "The transitions were already placed - kept them.")
            tj = None
        else:
            tj = "auto-tr-%s" % jid
        if tj:
            TRANS_JOBS[tj] = {"status": "running", "step": "", "pct": 0, "cancel": False}
            try:
                _trans_worker(tj, project)
            except Exception as e:
                TRANS_JOBS[tj].update(status="error", error=str(e)[:200])
            _auto_log(j, "Placed the transitions." if TRANS_JOBS[tj].get("status") == "done"
                      else "Transitions did not run (%s)." % (TRANS_JOBS[tj].get("error") or "unknown"))

        # ---- 6b. the optional look-at-the-pictures stop. Everything expensive is still ahead (the
        # video credits, the render), so this is the last honest moment to change your mind. The run
        # ENDS here and /api/auto/continue starts a fresh one that skips straight past this point.
        if opts.get("review_images") and not opts.get("reviewed"):
            with _AUTO_LOCK:
                j.update(status="review", pct=62, step="Your turn", detail="",
                         review={"scenes": len(load_doc(project).get("scenes") or [])})
            _auto_log(j, "Every picture is made. Look through them, regenerate what you do not like and "
                         "approve the ones you want, then press Continue.")
            _auto_save_run(project, j)
            return

        # ---- 7. approve what has an image. This comes BEFORE the effects pass on purpose: the
        # effects pass only looks at approved images, so the other way round it silently did nothing.
        _auto_set(j, step="Approve", pct=62, detail="")
        _already = sum(1 for s in (load_doc(project) or {}).get("scenes") or [] if s.get("approved"))
        if opts.get("reviewed") and _already:
            # They used the stop to approve. Approving the rest would overrule the ones they deliberately
            # left out - an unapproved scene gets no effects and never reaches the render, and that may
            # be exactly what they meant.
            _auto_log(j, "You approved %d scene(s) yourself - left the rest as you set them." % _already)
        else:
            napp, skipped = _approve_ready_images(project)
            _auto_log(j, "Approved %d image(s)%s." % (napp, "" if not skipped
                                                      else "; %d scene(s) still have none" % len(skipped)))

        # ---- 8. overlays - VISUAL EFFECTS ONLY (the standing rule for an unattended run)
        _auto_set(j, step="Effects", pct=66, detail="")
        if pol.get("fx", True):
            oj = "auto-ov-%s" % jid
            OVERLAY_JOBS[oj] = {"status": "running", "step": "", "pct": 0, "cancel": False}
            try:
                _overlay_worker(oj, project, do_icons=bool(pol.get("icons")),
                                do_sfx=bool(pol.get("sfx")), do_fx=True)
            except Exception as e:
                OVERLAY_JOBS[oj].update(status="error", error=str(e)[:200])
            orep = OVERLAY_JOBS[oj].get("report") or {}
            _auto_log(j, "Graded %d scene(s) with the cinematic treatment." % (orep.get("fx") or 0)
                      if OVERLAY_JOBS[oj].get("status") == "done"
                      else "The effects pass did not run (%s)." % (OVERLAY_JOBS[oj].get("error") or "unknown"))
        else:
            _auto_log(j, "Visual effects are switched off for automatic runs - skipped.")
        if _auto_cancelled(j): raise RuntimeError("cancelled")


        # ---- 9. videos
        _auto_set(j, step="Videos", pct=68, detail="")
        doc = load_doc(project)
        vids = _auto_video_ids(doc, opts.get("video_mode") or "all", float(opts.get("video_ratio") or 0.5))
        if vids and not VIDEO_CONFIGURED:
            _auto_log(j, "The video model is not configured - the episode stays as stills.")
            vids = []
        if vids:
            # each clip is ordered at the length of the line it covers - including the last one, whose
            # slot already carries the closing fade
            _auto_fit_video_durations(j, project, vids)
            _auto_queue(project, vids, "video")
            d2, f2 = _auto_pump(j, project, "video", "Videos", 68, 84, len(vids))
            _auto_log(j, "Made %d video(s)%s." % (d2, "" if not f2 else ", %d failed" % f2))
            doc = load_doc(project)
            for s in doc["scenes"]:
                if (s.get("video") or {}).get("status") == "ready":
                    s["video"]["approved"] = True
            save_doc(project, doc)
        else:
            _auto_log(j, "No videos wanted - the episode stays as stills.")
        if _auto_cancelled(j): raise RuntimeError("cancelled")

        # ---- 10. music: chosen from YOUR library by mood at build time; never generated
        _auto_set(j, step="Music", pct=86, detail="")
        empty = [m for m in suno_music.MOOD_NAMES if not _suno_lib_tracks(m)]
        _auto_log(j, "Music comes from your library by mood."
                  + ("" if not empty else " Nothing in: %s - those stretches will be silent."
                     % ", ".join(empty)))

        # ---- 11. render
        _auto_set(j, step="Render", pct=88, detail="")
        doc = load_doc(project)
        try:
            _build_timeline(project, doc)                 # fail fast with a readable reason
        except ValueError as e:
            raise RuntimeError("cannot render yet: %s" % e)
        d, _ = proj_dir(project)
        out = d / "export" / "render.mp4"
        opts_r = {"kenburns": True,             # a slow push on the stills, so they do not read as a slideshow
                  "kenburns_video": False,      # ...but never on the clips: the model already moved the camera
                  "music": True, "crossfade": True, "burnsubs": True,
                  "onscreentext": bool(pol.get("ost")), "transitions": True,
                  "gpu": False, "low_priority": False, "fast": False,
                  "outro_fade": float(opts.get("outro_fade") or OUTRO_FADE_SEC)}
        set_render_status(project, status="running", pct=0, step="Queued...", file=None, error=None)
        _KeyThread(target=run_render_job, daemon=True,
                         args=(project, doc, out, _vsl_name(doc, project, "Video", "mp4"), opts_r)).start()
        while True:
            st = get_render_status(project) or {}
            if st.get("status") != "running":
                break
            if _auto_cancelled(j): raise RuntimeError("cancelled")
            _auto_set(j, detail=st.get("step") or "rendering...",
                      pct=88 + int(0.08 * (st.get("pct") or 0)))
            _auto_save_run(project, j)
            time.sleep(5)
        st = get_render_status(project) or {}
        if not st.get("file"):
            raise RuntimeError("the render failed: %s" % (st.get("error") or "no reason given"))
        _auto_log(j, "Rendered the episode.")

        # ---- 12. publish
        _auto_set(j, step="Publish", pct=98, detail="")
        pub = _auto_schedule_publish(project, load_doc(project), opts)
        _auto_log(j, pub)
        _p = (load_doc(project) or {}).get("publish") or {}
        if _p.get("description") and _p.get("tags"):
            _auto_log(j, "Wrote the description and %d tags from the episode."
                      % len([t for t in _p["tags"].split(",") if t.strip()]))
        else:
            _auto_log(j, "Could not write the description automatically - press Write It on the Publish panel.")
        with _AUTO_LOCK:
            j.update(status="done", pct=100, step="Publish", detail="",
                     result={"render": st.get("file"), "elapsed": int(time.time() - t0)})
        _auto_save_run(project, j)
    except Exception as e:
        msg = "cancelled" if str(e) == "cancelled" else str(e)[:300]
        with _AUTO_LOCK:
            j.update(status="error", error=msg)
        _auto_save_run(project, j)


# ---------- the publish record: real data now, the upload itself still waits on Google ---------------
# Everything the YouTube upload will need lives on the project from the moment it is decided - the
# thumbnail, the title, the description, the slot. Nothing here talks to YouTube; when the channel is
# authorised the uploader reads this and has nothing left to ask.
_PUB_FIELDS = ("title", "description", "tags", "privacy", "kids", "date", "time", "playlist")


def _pub_get(doc):
    p = dict(doc.get("publish") or {})
    so = doc.get("script_opts") or {}
    p.setdefault("title", so.get("title") or doc.get("title") or "")
    for k in ("description", "tags"):
        p.setdefault(k, "")
    p.setdefault("privacy", "schedule")
    p.setdefault("kids", "notkids")
    # a slot Auto Episode already booked shows up as the date and time, rather than sitting in a
    # separate field the user cannot see
    if p.get("scheduled_for") and not p.get("date"):
        try:
            dt = datetime.fromisoformat(p["scheduled_for"])
            p["date"], p["time"] = dt.strftime("%Y-%m-%d"), dt.strftime("%H:%M")
        except Exception as _qe:
            quiet(_qe, "_pub_get")
    p.setdefault("date", "")
    p.setdefault("time", "20:00")
    p.setdefault("playlist", "")
    return p


@app.route("/api/publish/<project>")
def api_publish_get(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    p = _pub_get(doc)
    d, _ = proj_dir(project)
    p["thumb_exists"] = bool(p.get("thumb")) and (d / p["thumb"]).exists()
    return jsonify(p)


@app.route("/api/publish/<project>", methods=["POST"])
@_locked
def api_publish_set(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    b = request.get_json(silent=True) or {}
    p = _pub_get(doc)
    for k in _PUB_FIELDS:
        if k in b:
            p[k] = str(b[k])[:5000]
    # the date and time the user types ARE the slot; keep the machine-readable copy in step
    if "date" in b or "time" in b:
        p["slot_manual"] = bool((p.get("date") or "").strip())
    if p.get("date"):
        try:
            hh, mm = (p.get("time") or "20:00").split(":")[:2]
            p["scheduled_for"] = "%sT%02d:%02d" % (p["date"], int(hh), int(mm))
        except Exception as _qe:
            quiet(_qe, "api_publish_set")
    doc["publish"] = p
    save_doc(project, doc)
    return jsonify({"ok": True, "publish": p})


@app.route("/api/publish/<project>/thumb", methods=["POST"])
@_locked
def api_publish_thumb(project):
    """Attach a thumbnail to the episode. The picture is COPIED into the project's own export folder, so
    clearing the Studio gallery later cannot silently detach the thumbnail from a scheduled upload."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _ = proj_dir(project)
    (d / "export").mkdir(parents=True, exist_ok=True)
    dest = d / "export" / "thumbnail.png"
    f = request.files.get("file")
    if f and f.filename:
        try:
            Image.open(f.stream).convert("RGB").save(dest, "PNG")
        except Exception as e:
            return jsonify({"error": "could not read that image: %s" % str(e)[:120]}), 400
    else:
        b = request.get_json(silent=True) or {}
        scope = (b.get("scope") or "").strip()
        ref = (b.get("ref") or "").strip()
        if not (scope and ref):
            return jsonify({"error": "no picture given"}), 400
        base = _studio_dir(scope)
        src = (base / ref).resolve()
        try:
            src.relative_to(base.resolve())
        except Exception:
            return jsonify({"error": "bad image path"}), 400
        if not src.exists():
            return jsonify({"error": "that image is not there any more"}), 400
        try:
            Image.open(src).convert("RGB").save(dest, "PNG")
        except Exception:
            shutil.copyfile(src, dest)
    p = _pub_get(doc)
    p["thumb"] = "export/thumbnail.png"
    p["thumb_ts"] = int(time.time())
    # Remember whether this came from the Thumbnail bench. If it did, re-drawing the words there should
    # update the episode's thumbnail on its own - nobody wants to press Use again after every tweak.
    p["thumb_bench"] = not (f and f.filename)
    doc["publish"] = p
    save_doc(project, doc)
    return jsonify({"ok": True, "thumb": p["thumb"], "ts": p["thumb_ts"], "bench": p["thumb_bench"]})


@app.route("/api/publish/<project>/thumb", methods=["DELETE"])
@_locked
def api_publish_thumb_clear(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    p = _pub_get(doc)
    p.pop("thumb", None); p.pop("thumb_ts", None)
    doc["publish"] = p
    save_doc(project, doc)
    return jsonify({"ok": True})


@app.route("/api/auto/last/<project>")
def api_auto_last(project):
    """What the last run did, and whether it is worth offering to finish. Used when a project opens."""
    rec = _auto_run_record(project)
    if not rec:
        return jsonify({"none": True})
    doc = load_doc(project) or {}
    scenes = doc.get("scenes") or []
    rec["left"] = {
        "scenes": len(scenes),
        "images": sum(1 for s in scenes if (s.get("image") or {}).get("status") == "ready"),
        "videos": sum(1 for s in scenes if (s.get("video") or {}).get("status") == "ready"),
        "in_flight": sum(1 for s in scenes
                         if (s.get("image") or {}).get("status") in ("queued", "generating")
                         or (s.get("video") or {}).get("status") in ("queued", "generating")),
    }
    return jsonify(rec)


@app.route("/api/auto/dismiss/<project>", methods=["POST"])
def api_auto_dismiss(project):
    """Stop offering to finish it. The record stays as a log; it just no longer asks."""
    rec = _auto_run_record(project)
    if rec:
        rec["status"] = "abandoned"
        try:
            d, _ = proj_dir(project)
            (d / "auto_run.json").write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
        except Exception as _qe:
            quiet(_qe, "api_auto_dismiss")
    return jsonify({"ok": True})


@app.route("/api/auto/resume/<project>", methods=["POST"])
def api_auto_resume(project):
    """Carry on from where the interrupted run stopped, with the SAME choices it was started with."""
    if load_doc(project) is None:
        abort(404)
    rec = _auto_run_record(project) or {}
    if rec.get("status") not in ("interrupted", "error"):
        return jsonify({"error": "there is no unfinished run to pick up"}), 400
    opts = dict(rec.get("opts") or {})
    opts.update(request.get_json(silent=True) or {})
    opts["resume"] = True
    jid = "auto2r-%d" % int(time.time() * 1000)
    with _AUTO_LOCK:
        _AUTO_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "detail": "", "error": None,
                           "log": list(rec.get("log") or [])[-6:] + ["Picking the run back up."],
                           "cancel": False, "steps": list(_AUTO2_STEPS), "phase": 2, "opts": opts}
    _KeyThread(target=_auto2_worker, daemon=True, args=(jid, project, opts)).start()
    return jsonify({"ok": True, "job": jid})


@app.route("/api/auto/continue/<project>", methods=["POST"])
def api_auto_continue(project):
    if load_doc(project) is None:
        abort(404)
    b = request.get_json(silent=True) or {}
    # Continuing after the look-at-the-pictures stop is a RESUME: the voice-over, the subtitles and the
    # images are already made and paid for. Without this the fresh worker treated them as missing.
    b["resume"] = True
    jid = "auto2-%d" % int(time.time() * 1000)
    with _AUTO_LOCK:
        _AUTO_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "detail": "", "error": None,
                           "log": [], "cancel": False, "steps": list(_AUTO2_STEPS), "phase": 2,
                           "opts": dict(b)}   # a resume has to be able to honour the same choices
    _KeyThread(target=_auto2_worker, daemon=True, args=(jid, project, b)).start()
    return jsonify({"ok": True, "job": jid})


# ---------- one-time model assets (fetched on first launch, with a % progress bar) ----------
@app.route("/api/assets/status")
def api_assets_status():
    """What large model files the app still needs. The UI polls this on boot and, if anything is
    missing, kicks off /api/assets/fetch and shows a progress toast."""
    try:
        st = assets.status()
        return jsonify({"ok": True, "assets": st, "ready": all(a["ready"] for a in st)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "assets": [], "ready": True}), 200


@app.route("/api/assets/fetch", methods=["POST"])
def api_assets_fetch():
    if assets.ready():
        return jsonify({"ok": True, "job": None, "ready": True})
    return jsonify({"ok": True, "job": assets.start_fetch(), "ready": False})


@app.route("/api/assets/job/<jid>")
def api_assets_job(jid):
    return jsonify(assets.job(jid))


@app.route("/api/align-lang/<project>")
def api_align_lang(project):
    """The language this project force-aligns in. The UI compares it with each card extra.words_lang to spot
    timings produced in another language (a card aligned as English before the language fix)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    return jsonify({"lang": audience_lang(doc.get("audience")) or "en"})


@app.route("/api/testimonial-cards/<project>/<cid>/to-scene", methods=["POST"])
@_locked
def api_tcard_to_scene(project, cid):
    """Mirror a produced written-testimonial PNG into its linked VSL scene's image (Scenes & Images).
    The testimonial page is the source of truth; re-producing overwrites the scene's shown image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    card = next((c for c in doc.get("testimonial_cards", []) if c.get("id") == cid), None)
    if card is None:
        return jsonify({"error": "card not found"}), 404
    rel = (request.get_json(force=True) or {}).get("url") or ""
    d, safe = proj_dir(project)
    src = (d / rel).resolve()
    try:
        src.relative_to(d.resolve())            # keep the path inside the project
    except Exception:
        return jsonify({"error": "bad path"}), 400
    if not src.exists():
        return jsonify({"error": "rendered image not found"}), 400
    scene = next((s for s in doc.get("scenes", []) if s.get("tcard_id") == cid), None)
    if scene is None and card.get("sceneUid"):
        scene = next((s for s in doc.get("scenes", []) if s.get("uid") == card.get("sceneUid")), None)
    if scene is None:
        return jsonify({"error": "no VSL scene is linked to this testimonial"}), 400
    (d / "images").mkdir(parents=True, exist_ok=True)
    dest_rel = f"images/{scene['uid']}_tc_{int(time.time() * 1000)}.png"
    shutil.copyfile(src, d / dest_rel)
    img = scene.setdefault("image", {})
    vers = img.setdefault("versions", [])
    # SYNC in place: if this scene already shows a testimonial-sourced image ("_tc_" file), REPLACE that
    # version instead of piling up a new one — so editing the card (format/text) UPDATES the scene image
    # rather than adding a new version. Only the first produce appends.
    tc_idx = next((k for k, v in enumerate(vers) if "_tc_" in v), None)
    if tc_idx is not None:
        old_tc = vers[tc_idx]
        vers[tc_idx] = dest_rel
        idx = tc_idx
        if old_tc != dest_rel:
            try: (d / old_tc).unlink()
            except OSError as _qe: quiet(_qe, "api_tcard_to_scene")
    else:
        vers.append(dest_rel)
        idx = len(vers) - 1
    vm = img.setdefault("version_models", [])
    while len(vm) < len(vers):
        vm.append(scene.get("model") or IMAGE_MODEL)
    img["current"] = idx
    img["approved_version"] = idx
    img["status"] = "ready"
    img["taskId"] = None
    img["error"] = None
    scene["approved"] = True                     # the produced testimonial image is the final for this scene
    norm_scene(scene)                            # recompute file/approved_file
    save_doc(project, doc)
    return jsonify({"ok": True, "sceneId": scene["id"], "url": dest_rel})


@app.route("/api/testimonial-cards/<project>/save", methods=["POST"])
@_locked
def api_save_testimonial_cards(project):
    """Persist the written-testimonial card drafts (the whole list) for this project."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    cards = (request.get_json(force=True) or {}).get("cards")
    if not isinstance(cards, list):
        return jsonify({"error": "cards must be a list"}), 400
    clean = []
    for c in cards[:200]:
        if not isinstance(c, dict):
            continue
        clean.append({
            "id": str(c.get("id") or new_uid()),
            "type": str(c.get("type") or "written"),
            "format": str(c.get("format") or "facebook"),
            "charId": str(c.get("charId") or ""),
            "text": str(c.get("text") or "")[:5000],
            "extra": c.get("extra") if isinstance(c.get("extra"), dict) else {},
            "auto": bool(c.get("auto")),          # created automatically from a script testimonial line
            "sceneUid": str(c.get("sceneUid") or ""),   # the scene this card's image mirrors into
        })
    _pd, _ = proj_dir(project)
    for c in clean:
        _kara_offload(_pd, c)
    doc["testimonial_cards"] = clean
    save_doc(project, doc)
    return jsonify({"ok": True, "cards": clean})


@app.route("/api/testimonials/<project>/restore", methods=["POST"])
@_locked
def api_restore_testimonials(project):
    """Undo/redo for the Testimonials page: put the roster AND the cards back in one write.

    Two separate saves would race - the second one's load_doc could read the doc before the first one
    wrote, and silently drop half the step. Deleting a person never removes their portrait files, so a
    restored entry still points at pictures that are on disk."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    b = request.get_json(force=True) or {}
    people, cards = b.get("people"), b.get("cards")
    if not isinstance(people, list) or not isinstance(cards, list):
        return jsonify({"error": "people and cards must both be lists"}), 400
    doc["testimonials"] = [p for p in people[:200] if isinstance(p, dict) and p.get("id")]
    doc["testimonial_cards"] = [c for c in cards[:200] if isinstance(c, dict) and c.get("id")]
    _pd, _ = proj_dir(project)
    for c in doc["testimonial_cards"]:
        _kara_offload(_pd, c)
    save_doc(project, doc)
    return jsonify({"ok": True, "testimonials": doc["testimonials"],
                    "testimonial_cards": doc["testimonial_cards"]})


# ---- routes: VIDEO testimonial (image with the person's face + environment, then voiceover) ----
def _tv_image_prompt(env):
    env = (env or "").strip()
    base = ("A candid AMATEUR selfie-style video still of the SAME single person shown in the reference photo, "
            "keeping their exact face and identity. They are filming THEMSELVES on a phone front camera "
            "(UGC talking-to-camera selfie), head-and-shoulders, looking into the lens with a warm natural "
            "expression. Casual slightly imperfect handheld framing, natural available lighting, a believable "
            "real person — not a model, not a studio shot, not stock. No text, no logos, no watermark.")
    if env:
        base += f" Setting / background: {env}."
    return base


@app.route("/api/testimonial-cards/<project>/<cid>/gen-image", methods=["POST"])
def api_tv_gen_image(project, cid):
    """Generate the video-testimonial IMAGE: the chosen character's face (i2i reference) placed in the
    described environment, selfie/UGC style, at the chosen dimension (horizontal / square / vertical)."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    char = next((c for c in doc.get("testimonials", []) if c.get("id") == (body.get("charId") or "")), None)
    if char is None:
        return jsonify({"error": "pick a character first"}), 400
    urls = char.get("urls") or []
    if not urls:
        return jsonify({"error": "this character has no photo yet — generate or upload one first"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    src = (d / urls[-1]).resolve()
    if not src.exists():
        return jsonify({"error": "character photo file is missing"}), 400
    base_url = cloudinary_upload(src, f"{safe}/tvface/{cid}")
    if not base_url:
        return jsonify({"error": "could not upload the face reference"}), 500
    aspect = {"horizontal": "16:9", "square": "1:1", "vertical": "9:16"}.get(body.get("dim"), "9:16")
    env = (body.get("env") or "").strip()
    if env and looks_turkish(env):
        try: env = translate_to_english(env)
        except Exception as _qe: quiet(_qe, "api_tv_gen_image")
    for p in d.glob(f"refs/tvcand_{cid}_*"):   # fresh each time
        try: p.unlink()
        except Exception as _qe: quiet(_qe, "api_tv_gen_image")
    rel, cerr = _run_char_candidate(d, cid, _tv_image_prompt(env), [base_url], prefix="tvcand", family="nano-banana-2", aspect=aspect)
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/voiceover", methods=["POST"])
def api_tv_voiceover(project, cid):
    """Generate an ElevenLabs voice-over for ONE video-testimonial card (saved per-card)."""
    err = _keys_ok(("eleven",))
    if err:
        return err
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    body = request.get_json(force=True) or {}
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": _key('ELEVENLABS_API_KEY'), "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL, "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": f"request failed: {e}"}), 502
    if r.status_code != 200:
        return jsonify({"error": f"ElevenLabs {r.status_code}"}), 502
    (d / "cards").mkdir(parents=True, exist_ok=True)
    rel = f"cards/vo_{cid}_{int(time.time() * 1000)}.mp3"
    (d / rel).write_bytes(r.content)
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/upload-audio", methods=["POST"])
def api_tv_upload_audio(project, cid):
    """Save a user-uploaded voice-over audio file for ONE video-testimonial card."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file"}), 400
    (d / "cards").mkdir(parents=True, exist_ok=True)
    ext = os.path.splitext(f.filename)[1].lower() or ".mp3"
    rel = f"cards/vo_{cid}_up_{int(time.time() * 1000)}{ext}"
    f.save(d / rel)
    return jsonify({"ok": True, "url": rel})


@app.route("/api/testimonial-cards/<project>/<cid>/gen-video", methods=["POST"])
def api_tv_gen_video(project, cid):
    """Lip-sync testimonial video via Kie 'infinitalk/from-audio': the approved image + the voiceover
    audio + a prompt → talking-head MP4. (Audio must be <= 15s per the model.)"""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True) or {}
    img_rel = (body.get("image") or "").strip()
    vo_rel = (body.get("vo") or "").strip()
    prompt = (body.get("prompt") or "").strip() or "A person speaking naturally to the camera in a casual selfie video."
    resolution = body.get("resolution") if body.get("resolution") in ("480p", "720p") else "720p"
    ip = (d / img_rel).resolve()
    ap = (d / vo_rel).resolve()
    if not (img_rel and str(ip).startswith(str(d.resolve())) and ip.exists()):
        return jsonify({"error": "approve an image first"}), 400
    if not (vo_rel and str(ap).startswith(str(d.resolve())) and ap.exists()):
        return jsonify({"error": "add a voiceover first"}), 400
    image_url = cloudinary_upload(ip, f"{safe}/tvvidimg/{cid}")
    if not image_url:
        return jsonify({"error": "could not upload the image"}), 500
    audio_url = cloudinary_upload_audio(ap, f"{safe}/tvvidaud/{cid}")
    if not audio_url:
        return jsonify({"error": "could not upload the voiceover"}), 500
    if looks_turkish(prompt):
        try: prompt = translate_to_english(prompt)
        except Exception as _qe: quiet(_qe, "api_tv_gen_video")
    inp = {"image_url": image_url, "audio_url": audio_url, "prompt": prompt, "resolution": resolution}
    tid, cerr = kie_create("infinitalk/from-audio", inp)
    if not tid:
        return jsonify({"error": cerr or "could not start video generation"}), 502
    url = fail = None
    for _ in range(180):                       # poll up to ~6 minutes
        time.sleep(2)
        try:
            rec = kie_record(tid)
        except Exception:
            rec = {}
        st = (rec.get("data") or {}).get("state")
        if st == "success":
            url = result_url(rec); break
        if st == "fail":
            fail = (rec.get("data") or {}).get("failMsg", "generation failed"); break
    if fail:
        return jsonify({"error": fail}), 502
    if not url:
        return jsonify({"error": "video generation timed out"}), 504
    (d / "cards").mkdir(parents=True, exist_ok=True)
    rel = f"cards/tvvideo_{cid}_{int(time.time() * 1000)}.mp4"
    try:
        rr = requests.get(url, timeout=300); rr.raise_for_status()
        (d / rel).write_bytes(rr.content)
    except Exception as e:
        return jsonify({"error": f"download failed: {e}"}), 502
    return jsonify({"ok": True, "url": rel})

# ---- routes: image edit / versions / downloads -----------------------------
def _find_scene(doc, sid):
    return next((s for s in doc["scenes"] if s["id"] == sid), None)

@app.route("/api/scenes/<project>/<int:sid>/preview-prompt", methods=["GET"])
def api_preview_prompt(project, sid):
    """Dry-run: return the EXACT final image prompt this scene would send (+ a summary of the reference
    images that would attach), WITHOUT generating. Lets the user catch conflicts before spending a job."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    d, _safe = proj_dir(project)
    if not (s.get("prompt") or "").strip():
        return jsonify({"prompt": "", "info": ["This scene has no prompt yet — Generate or type one first."]})
    prompt, _cont_rel, info = assemble_image_prompt(s, doc, d)
    return jsonify({"prompt": prompt, "info": info, "raw": bool(s.get("no_cast"))})

@app.route("/api/scenes/<project>/<int:sid>/edit", methods=["POST"])
def api_edit_image(project, sid):
    """Edit the CURRENT version using it as the reference (image-to-image), keep history."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    instr = (request.get_json(force=True).get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    img = s["image"]
    vs, cur = img.get("versions", []), img.get("current", -1)
    if not vs or not (0 <= cur < len(vs)):
        return jsonify({"error": "generate an image first"}), 400
    d, safe = proj_dir(project)
    # Stable public_id per scene (no timestamp) so re-editing OVERWRITES the same Cloudinary asset
    # instead of piling up a new permanent one every edit. Signed uploads overwrite by default, and
    # Cloudinary returns a version-busted secure_url so Kie always fetches the fresh base — one
    # edit-base asset per scene, ever. (frames/ and refs/ were already stable-id, so only edits leaked.)
    base_url = cloudinary_upload(d / vs[cur], f"{safe}/edits/s{sid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    # Build an EDIT command, not a scene description. Do NOT prepend the big style preset here:
    # the base image already carries the style, and dumping ~150 words of "keep this exact look"
    # in front of a one-line instruction buries the edit — the model just reproduces the same
    # image. Make the change DOMINANT and forceful; over-preserving "the same subject" is what
    # blocks appearance edits (e.g. "make them thinner"), so we only protect the setting/style/faces
    # and explicitly ALLOW the subject's body/appearance to change to satisfy the instruction.
    # If the instruction is written in Turkish, translate ONLY the user's words to English first,
    # so the forceful English directives below reach the model verbatim. (Running the whole prompt
    # through the translator, as localize_prompt would, could soften the "apply it strongly" wording.)
    instr_en = instr
    if looks_turkish(instr):
        try:
            instr_en = translate_to_english(instr)
        except Exception:
            instr_en = instr
    # Edit ALWAYS uses NanoBanana image-to-image, with the current frame as the base.
    image_input = [base_url]
    # The + tile under the preview puts the user's OWN pictures on the scene, and an edit that ignored
    # them threw away the very thing they had just handed over: they attach the look they want, type
    # "use this", and the model never saw it. Those references now travel WITH the edit. (The scene's
    # CAST photos are still kept out - see below - because anchoring a face that hard is what stops an
    # appearance edit from taking. s["refs"] is the user's own uploads, not the roster.)
    try:
        extra = resolve_refs(d, safe, s.get("refs"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 500
    image_input += extra
    # RAW edit: send ONLY the user's instruction — nothing added, exactly what they typed (translated to
    # English if written in Turkish, since the model reads English best). Adding the style preset here
    # buried the edit and the model just reproduced the same image. The ONE exception is the line below,
    # added only when references are attached: without it the model cannot tell which image it is meant
    # to be editing and which it is meant to be copying from. The user's words still come last, where
    # they carry the most weight.
    p = instr_en
    if extra:
        p = ("The first image is the picture to EDIT - it stays the base and only what is asked below "
             "changes. The %s image%s after it %s reference%s supplied for this edit: take what is "
             "needed from %s and work it into the first image, matching its lighting, perspective and "
             "scale rather than pasting it in flat.\n\n"
             % ("next" if len(extra) == 1 else "%d" % len(extra),
                "" if len(extra) == 1 else "s",
                "is a" if len(extra) == 1 else "are",
                "" if len(extra) == 1 else "s",
                "it" if len(extra) == 1 else "them")) + instr_en
    model_id, inp = build_kie_image_request("nano-banana-2", p, image_input)
    tid, err = kie_create(model_id, inp)
    if tid:
        img.update(status="generating", taskId=tid, error=None, gen_started=time.time())
    else:
        img.update(status="error", error=err)
    save_doc(project, doc)
    return jsonify(doc)

# ---------- ERASE: LOCAL (this machine's GPU, free) or CLOUD (Kie Ideogram V3 Edit, mask inpaint) ----------
INPAINT_JOBS = {}

def _cloud_erase(j, d, safe, sid, base, mask):
    """CLOUD erase via Kie **Ideogram V3 Edit** — a true mask-based inpainting model (image_url + mask_url).
    Uploads the current image + the painted mask (white = the region to erase), asks the model to rebuild that
    region to match the surroundings, then composites ONLY the masked area back so the rest stays pixel-identical.
    Best for realistic photos where local LaMa leaves a haze. Ideogram mask convention: WHITE = inpaint."""
    import inpaint as _ip
    from PIL import Image, ImageFilter
    if not _key('KIE_API_KEY'):
        raise RuntimeError("Kie API key not set — add it in Settings to use Cloud erase.")
    (d / "frames").mkdir(parents=True, exist_ok=True)
    m = mask.point(lambda v: 255 if v > 40 else 0)
    try:
        m = _ip._dilate(m)                       # grow so the whole object + edge is covered
    except Exception as _qe:
        quiet(_qe, "_cloud_erase")
    base_p = d / "frames" / f"_cloudbase_s{sid}.png"; base.save(base_p, "PNG")
    mask_p = d / "frames" / f"_cloudmask_s{sid}.png"; m.convert("RGB").save(mask_p, "PNG")
    j.update(step="Uploading…", pct=20)
    image_url = cloudinary_upload(base_p, f"{safe}/cloudfill/base_s{sid}")
    mask_url = cloudinary_upload(mask_p, f"{safe}/cloudfill/mask_s{sid}")
    if not image_url or not mask_url:
        raise RuntimeError("could not upload image/mask to Cloudinary")
    j.update(step="Cloud erasing…", pct=45)
    prompt = ("empty background that seamlessly continues the surrounding area; remove the object entirely; "
              "photorealistic, natural, consistent lighting and texture; no object, no text")
    tid, err = kie_create("ideogram/v3-edit", {"prompt": prompt, "image_url": image_url, "mask_url": mask_url,
                                               "rendering_speed": "QUALITY", "expand_prompt": False})
    if not tid:
        raise RuntimeError(err or "cloud task could not be created")
    url = None
    for _ in range(120):                          # poll up to ~4 min
        time.sleep(2)
        try:
            rec = kie_record(tid)
        except Exception:
            rec = {}
        st = (rec.get("data") or {}).get("state")
        if st == "success":
            url = result_url(rec); break
        if st == "fail":
            fm = (rec.get("data") or {}).get("failMsg", "") or ""
            if "internal error" in fm.lower() or "try again" in fm.lower():
                raise RuntimeError("Cloud erase is temporarily unavailable (Kie server error). Try again later, or use Local.")
            raise RuntimeError(fm or "cloud erase failed")
    if not url:
        raise RuntimeError("cloud erase timed out")
    j.update(step="Downloading…", pct=85)
    out_p = d / "frames" / f"_cloudout_s{sid}.png"
    download_as_png(url, out_p)
    res = Image.open(out_p).convert("RGB")
    if res.size != base.size:
        res = res.resize(base.size, Image.LANCZOS)
    hard = m.filter(ImageFilter.GaussianBlur(3))  # keep everything outside the mask exactly as the original
    return Image.composite(res, base, hard)

def _inpaint_worker(jid, project, sid, mask_b64, prompt, steps, engine="local"):
    j = INPAINT_JOBS[jid]
    try:
        import inpaint as _ip, base64, io
        from PIL import Image
        doc = load_doc(project); s = _find_scene(doc, sid)
        if s is None:
            j.update(status="error", error="scene not found"); return
        img = s["image"]; vs, cur = img.get("versions", []), img.get("current", -1)
        d, safe = proj_dir(project)
        base = Image.open(d / vs[cur]).convert("RGB")
        mb = base64.b64decode((mask_b64 or "").split(",")[-1])
        mask = Image.open(io.BytesIO(mb)).convert("L").resize(base.size, Image.LANCZOS)
        if engine == "cloud":                     # Kie Ideogram V3 Edit (mask inpaint) — realistic photos
            out = _cloud_erase(j, d, safe, sid, base, mask)
        else:                                     # LOCAL: uniform backdrop -> Telea, textured -> LaMa (free)
            j.update(step="Erasing…", pct=45)
            out = _ip.erase(base, mask)
        j.update(step="Saving…", pct=90)
        (d / "frames").mkdir(parents=True, exist_ok=True)
        rel = f"frames/s{sid}_fill_{new_uid()}.png"
        out.save(d / rel)
        doc = load_doc(project); s = _find_scene(doc, sid); img = s["image"]   # reload fresh (async)
        img.setdefault("versions", []).append(rel)
        tag = "cloud-erase" if engine == "cloud" else "erase"
        vm = img.setdefault("version_models", [])
        while len(vm) < len(img["versions"]) - 1:
            vm.append("erase")
        vm.append(tag)
        img["current"] = len(img["versions"]) - 1
        img.update(status="ready", file=rel, error=None, taskId=None)
        # If the scene is already APPROVED, move the approved version to this erased result too — otherwise the
        # "snap approved scenes back to approved_version on reopen" logic would revert the erase on next launch,
        # and export/approve would keep using the old image. This makes the erase persist and become what's used.
        if s.get("approved"):
            img["approved_version"] = img["current"]
        save_doc(project, doc)
        j.update(status="done", pct=100, version=img["current"])
    except Exception as e:
        import traceback
        traceback.print_exc()
        j.update(status="error", error=str(e))

@app.route("/api/inpaint/<project>/<int:sid>", methods=["POST"])
def api_inpaint(project, sid):
    """Erase (empty prompt) or generatively FILL the masked region of the scene's current image -> new version."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    vs, cur = s["image"].get("versions", []), s["image"].get("current", -1)
    if not vs or not (0 <= cur < len(vs)):
        return jsonify({"error": "generate an image first"}), 400
    body = request.get_json(force=True) or {}
    if not body.get("mask"):
        return jsonify({"error": "no mask drawn"}), 400
    engine = "cloud" if body.get("engine") == "cloud" else "local"
    jid = new_uid()
    INPAINT_JOBS[jid] = {"status": "running", "step": "Starting…", "pct": 5, "error": None}
    _KeyThread(target=_inpaint_worker,
                     args=(jid, project, sid, body.get("mask"), (body.get("prompt") or "").strip(),
                           int(body.get("steps") or 30), engine), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/inpaint-job/<jid>")
def api_inpaint_job(jid):
    j = INPAINT_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    return jsonify(j)

@app.route("/api/scenes/<project>/<int:sid>/current", methods=["POST"])
@_locked
def api_set_current(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    idx = request.get_json(force=True).get("index")
    vs = s["image"].get("versions", [])
    if isinstance(idx, int) and 0 <= idx < len(vs):
        s["image"]["current"] = idx
        save_doc(project, doc)
    return jsonify(s["image"])

@app.route("/api/scenes/<project>/sync-approved-current", methods=["POST"])
@_locked
def api_sync_approved_current(project):
    """On (re)opening a project, snap every APPROVED scene's shown version back to its APPROVED version —
    so flipping through versions and then leaving doesn't leave a non-approved frame showing next time.
    Persisted so a later poll can't snap it forward again."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    changed = False
    for s in doc.get("scenes", []):
        im = s.get("image") or {}
        av = im.get("approved_version")
        vers = im.get("versions") or []
        if s.get("approved") and isinstance(av, int) and 0 <= av < len(vers) and im.get("current") != av:
            im["current"] = av
            im["file"] = vers[av]
            changed = True
    if changed:
        save_doc(project, doc)
        doc = load_doc(project)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-image", methods=["POST"])
@_locked
def api_reset_image(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["image"] = {"status": "empty", "taskId": None, "error": None, "versions": [], "current": -1, "file": None}
    s["approved"] = False
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-image", methods=["POST"])
@_locked
def api_cancel_image(project, sid):
    """Stop an in-progress (queued OR generating) image generation for ONE scene.
    Keeps any existing versions — we just abandon the new task so poll/queue ignore it.
    A Kie task already submitted keeps running on their side; we simply stop tracking it."""
    with _project_lock(project):     # same atomic load→modify→save as generate/poll so we don't race the 6s poll
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        img = s["image"]
        if img.get("status") in ("queued", "generating"):
            vs = img.get("versions", [])
            if vs:                                            # regen over an existing image → keep the old one
                cur = img.get("current", len(vs) - 1)
                cur = cur if 0 <= cur < len(vs) else len(vs) - 1
                img.update(status="ready", taskId=None, error=None, file=vs[cur])
            else:                                             # first-time generation → back to empty
                img.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-video", methods=["POST"])
@_locked
def api_cancel_video(project, sid):
    """Stop an in-progress (queued OR generating) VIDEO generation for ONE scene. Keeps any existing
    video; we just abandon the new task so poll/queue ignore it (the Kie task, if already sent, keeps
    running on their side — we simply stop tracking it)."""
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        v = s.get("video") or {}
        if v.get("status") in ("queued", "generating"):
            if v.get("file"):                         # regen over an existing video → keep the old one
                v.update(status="ready", taskId=None, error=None)
            else:
                v.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)


@app.route("/api/scenes/<project>/<int:sid>/delete-version", methods=["POST"])
@_locked
def api_delete_version(project, sid):
    """Delete ONLY the shown image version (not all). The file is left on disk so Undo can restore it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    img = s["image"]
    vs = img.get("versions", [])
    idx = request.get_json(force=True).get("index", img.get("current", -1))
    if not (0 <= idx < len(vs)):
        return jsonify(doc)
    vs.pop(idx)
    vm = img.get("version_models")               # keep the per-version model list aligned
    if isinstance(vm, list) and 0 <= idx < len(vm):
        vm.pop(idx)
    av = img.get("approved_version")
    if isinstance(av, int):
        if av == idx:
            img["approved_version"] = None
            s["approved"] = False
        elif av > idx:
            img["approved_version"] = av - 1
    if not vs:
        s["image"] = {"status": "empty", "taskId": None, "error": None,
                      "versions": [], "current": -1, "file": None, "approved_version": None}
        s["approved"] = False
    else:
        img["versions"] = vs
        img["current"] = min(img.get("current", 0), len(vs) - 1)
    norm_scene(s)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/approve", methods=["POST"])
@_locked
def api_approve(project, sid):
    """Approve/unapprove the scene. On approve, LOCK the currently-shown version."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    body = request.get_json(force=True)
    approved = bool(body.get("approved"))
    s["approved"] = approved
    if approved:
        # optional explicit version to approve (from the lightbox) — set it as current too,
        # so approving is atomic and race-free regardless of pending setCurrent calls.
        ver = body.get("version")
        vs = s["image"].get("versions", [])
        if isinstance(ver, int) and 0 <= ver < len(vs):
            s["image"]["current"] = ver
        s["image"]["approved_version"] = s["image"].get("current", len(vs) - 1)
    norm_scene(s)   # recompute approved_file so the response is current
    if approved:
        # An approved scene is about to become a video. Fit its clip length to the line under it now, so
        # the Videos tab never opens on a duration the render would have to slow the clip down to fill.
        autofit_video_durations(project, doc)
    if approved:
        _auto_anchor(doc, s)   # photo-less recurring character → adopt this frame as their face-lock for later scenes
        _learn_log("approved", project, doc, [s])   # passive: capture the vetted (vo → prompt + settings) pair
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/approve-batch", methods=["POST"])
@_locked
def api_approve_batch(project):
    """Approve/unapprove MANY scenes at once (Select All -> Approve All / Unapprove All). On approve, locks each
    scene's currently-shown image version; scenes without a generated image are skipped. Returns the doc once."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    approved = bool(body.get("approved"))
    ids = set(int(i) for i in (body.get("ids") or []) if str(i).strip().lstrip("-").isdigit())
    n = 0
    _fit_after = False
    for s in doc.get("scenes") or []:
        if s.get("id") not in ids:
            continue
        img = s.get("image") or {}
        vs = img.get("versions", [])
        if approved and not vs:
            continue                      # nothing to lock yet -> skip (can't approve an image-less scene)
        s["approved"] = approved
        if approved:
            img["approved_version"] = img.get("current", len(vs) - 1)
        norm_scene(s)
        if approved:
            _auto_anchor(doc, s); _learn_log("approved", project, doc, [s])
            _fit_after = True
        n += 1
    if _fit_after:
        # One pass after the whole batch - the timing map is read once, not once per scene.
        autofit_video_durations(project, doc)
    save_doc(project, doc)
    return jsonify({"doc": doc, "changed": n})

@app.route("/api/scenes/<project>/<int:sid>/reset-video", methods=["POST"])
@_locked
def api_reset_video(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"] = {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False}
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/video-approve", methods=["POST"])
@_locked
def api_video_approve(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"]["approved"] = bool(request.get_json(force=True).get("approved"))
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/zip-images")
def api_zip_images(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            if not s.get("approved"):
                continue
            f = s["image"].get("approved_file") or s["image"].get("file")
            if f and (d / f).exists():
                z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-images.zip")

@app.route("/api/scenes/<project>/zip-videos")
def api_zip_videos(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-videos.zip")

# ---- routes: media serving --------------------------------------------------
# Function words carry a language far more reliably than letters do, and they cost nothing to count.
_LANG_WORDS = {
    "en": "the and of to in that is for with you your this are have it was but not on as at",
    "de": "der die das und ist sie nicht ein eine mit für auch auf dass sich haben wird von den dem im",
    "fr": "le la les de des et un une est vous pour que dans pas sur avec plus qui au ce nous",
    "es": "el la los las de y que en un una es para con por su no más como pero este",
    "it": "il la le di che un una per con non in del sono più anche come questo dei",
    "tr": "bir ve bu için ile de da olarak daha çok gibi olan var değil ama sonra kadar her",
    "nl": "de het een en van is dat niet in je met voor op zijn ook maar aan die",
    "pt": "o a os as de e que um uma para com por não mais em do da se",
}
_LANG_WORDS = {k: set(v.split()) for k, v in _LANG_WORDS.items()}
_LANG_NAMES = {"en": "English", "de": "German", "fr": "French", "es": "Spanish",
               "it": "Italian", "tr": "Turkish", "nl": "Dutch", "pt": "Portuguese"}
# Letters that only a few of these languages use at all.
_LANG_CHARS = {"de": "ßäöü", "tr": "ığşçöü", "fr": "éèêàçùû", "es": "ñ¿¡", "pt": "ãõç", "it": "àèìòù"}


def guess_text_language(text):
    """(code, score, runner_up_score) for the language this text is written in, or None when there is
    not enough to judge. Score is the share of words that are that language's function words."""
    words = re.findall(r"[^\W\d_]+", (text or "").lower(), re.UNICODE)
    if len(words) < 40:
        return None                      # too little to be sure of anything
    total = float(len(words))
    scored = []
    for code, stop in _LANG_WORDS.items():
        hits = sum(1 for w in words if w in stop)
        s = hits / total
        chars = _LANG_CHARS.get(code, "")
        if chars and any(c in text.lower() for c in chars):
            s += 0.02                    # a nudge, never enough to win on its own
        scored.append((s, code))
    scored.sort(reverse=True)
    return (scored[0][1], scored[0][0], scored[1][0])


def subtitle_language_warning(script_text, chosen):
    """A sentence to show the user when the script is plainly not in the chosen language, else ''."""
    chosen = (chosen or "").strip().lower()[:2]
    if chosen not in _LANG_WORDS:
        return ""                        # a language we cannot judge - say nothing
    g = guess_text_language(script_text)
    if not g:
        return ""
    code, best, second = g
    if code == chosen:
        return ""
    mine = 0.0
    words = re.findall(r"[^\W\d_]+", (script_text or "").lower(), re.UNICODE)
    if words:
        mine = sum(1 for w in words if w in _LANG_WORDS[chosen]) / float(len(words))
    # Only speak on a clear win: a real share of function words, and well clear of the chosen language.
    if best < 0.08 or best < mine * 2.0 or (best - second) < 0.02:
        return ""
    return ("The script looks like %s, but the subtitle language is set to %s. "
            "Running it as %s loads the English-only transcriber and the timings come out poor - "
            "the language picker sits beside the subtitle options."
            % (_LANG_NAMES.get(code, code), _LANG_NAMES.get(chosen, chosen),
               _LANG_NAMES.get(chosen, chosen)))


@app.route("/api/subtitle/<project>", methods=["GET"])
def api_subtitle_status(project):
    st = get_sub_status(project)
    if st.get("status") == "running":
        st["pct"] = _srt_pct(st)                      # estimated % (asymptotic per-stage) for the progress toast
    elif st.get("status") == "done":
        st["pct"] = 100
    return jsonify(st)

@app.route("/api/subtitle/<project>/cancel", methods=["POST"])
def api_subtitle_cancel(project):
    """Stop a running subtitle job: flag it, then kill the live aligner subprocess tree so it halts
    at once. run_subtitle_job sees the flag between passes and finishes as 'idle' (not error)."""
    _SUB_CANCEL.add(project)
    _kill_proc_tree(_SUB_PROCS.get(project))
    set_sub_status(project, status="idle", step="", error=None, srt=None)
    return jsonify({"ok": True})

def text_to_docx(text, path):
    """Wrap plain UI script text as a minimal .docx (one paragraph per non-empty line) so the
    aligner's docx reader consumes it through the exact same code path as an uploaded .docx."""
    import xml.sax.saxutils as sx
    paras = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{sx.escape(ln.strip())}</w:t></w:r></w:p>'
        for ln in text.splitlines() if ln.strip())
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           '<w:body>' + paras + '</w:body></w:document>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)

@app.route("/api/subtitle/<project>", methods=["POST"])
def api_subtitle_run(project):
    doc = load_doc(project)
    if not doc:
        return jsonify({"error": "unknown project"}), 404
    st = get_sub_status(project)
    if st.get("status") == "running":
        return jsonify({"error": "a subtitle job is already running"}), 409
    d, safe = proj_dir(project)
    def truthy(v): return str(v).lower() in ("1", "true", "on", "yes")
    use_gen_vo = truthy(request.form.get("use_generated_vo"))
    use_script = truthy(request.form.get("use_script"))
    trim = truthy(request.form.get("trim"))
    trim_mode = request.form.get("trim_mode") or "natural"
    audio = request.files.get("audio")
    docx = request.files.get("docx")
    src_dir = d / "srt_src"            # PERSISTENT last-used source files (survive the wd wipe) so a re-run can reuse them
    # fresh workdir each run so stale alignment caches never leak into a new job
    wd = sub_dir(project)
    if wd.exists():
        shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True, exist_ok=True)
    docx_path = wd / "script.docx"

    audio_name = None   # what to remember + show in the UI for the voice-over source
    docx_name = None    # ... and for the script source

    # ---- audio source (accepts any common audio type; ffmpeg/whisper sniff by content) ----
    if use_gen_vo:
        gen = d / "voiceover" / "voiceover.mp3"
        if not gen.exists():
            return jsonify({"error": "no generated voice-over yet - generate it above first"}), 400
        audio_path = wd / "audio.mp3"
        shutil.copyfile(gen, audio_path)
        audio_name = "Generated voice-over"
    else:
        if audio and audio.filename:
            ext = (Path(audio.filename).suffix or ".mp3").lower()
            src_dir.mkdir(parents=True, exist_ok=True)
            for old in src_dir.glob("audio.*"):
                try: old.unlink()
                except OSError as _qe: quiet(_qe, "api_subtitle_run")
            src_audio = src_dir / ("audio" + ext)
            audio.save(str(src_audio))
            (src_dir / "audio_name.txt").write_text(audio.filename, encoding="utf-8")
            audio_name = audio.filename
        else:
            # no new file picked -> reuse the last uploaded voice-over if we still have it
            prev = sorted(src_dir.glob("audio.*")) if src_dir.exists() else []
            if not prev:
                return jsonify({"error": "a voice-over audio file is required"}), 400
            src_audio = prev[0]
            try: audio_name = (src_dir / "audio_name.txt").read_text(encoding="utf-8").strip() or src_audio.name
            except Exception: audio_name = src_audio.name
        audio_path = wd / ("audio" + src_audio.suffix.lower())
        shutil.copyfile(src_audio, audio_path)
        # NOT trimmed here. The pauses are cut inside run_subtitle_job, AFTER the alignment, so the
        # cuts can be placed between words instead of at a level threshold that does not know about them.

    # ---- script source (.docx or plain-text .txt) ----
    if use_script:
        script_text = (request.form.get("script_text") or "").strip()
        if not script_text:
            return jsonify({"error": "the script box on the left is empty"}), 400
        text_to_docx(script_text, docx_path)
    else:
        if docx and docx.filename:
            fn = docx.filename.lower()
            if fn.endswith(".txt"):
                text_to_docx(docx.read().decode("utf-8", "ignore"), docx_path)
            elif fn.endswith(".docx"):
                docx.save(str(docx_path))
            else:
                return jsonify({"error": "script must be a .docx or .txt file"}), 400
            src_dir.mkdir(parents=True, exist_ok=True)
            for old in src_dir.glob("script.*"):
                try: old.unlink()
                except OSError as _qe: quiet(_qe, "api_subtitle_run")
            shutil.copyfile(docx_path, src_dir / ("script" + (Path(fn).suffix or ".docx")))
            (src_dir / "docx_name.txt").write_text(docx.filename, encoding="utf-8")
            docx_name = docx.filename
        else:
            # no new file picked -> reuse the last uploaded script if we still have it
            prev = sorted(src_dir.glob("script.*")) if src_dir.exists() else []
            if not prev:
                return jsonify({"error": "a script file (.docx or .txt) is required"}), 400
            src_docx = prev[0]
            if src_docx.suffix.lower() == ".txt":
                text_to_docx(src_docx.read_text(encoding="utf-8", errors="ignore"), docx_path)
            else:
                shutil.copyfile(src_docx, docx_path)
            try: docx_name = (src_dir / "docx_name.txt").read_text(encoding="utf-8").strip() or src_docx.name
            except Exception: docx_name = src_docx.name

    proj = fname_slug(doc.get("title") or project)
    date = today_ddmmyyyy()
    out_path = wd / f"{proj}_Subtitle_{date}.srt"
    trimmed_name = f"{proj}_Voiceover_Trimmed_{date}.mp3" if trim else None
    set_sub_status(project, status="running", step="Starting…", srt=None,
                   trimmed=None, trimmed_name=trimmed_name, error=None,
                   audio_name=audio_name, docx_name=docx_name,
                   use_gen_vo=use_gen_vo, use_script=use_script)
    # The Language picker beside the subtitle options wins; without one, fall back to the audience's
    # country. The picker exists because that country lives in Settings, and a German script uploaded to
    # a project still set to the US would silently be transcribed by the English-only model.
    lang = (doc.get("subtitle_lang") or "").strip() or audience_lang(doc.get("audience"))
    # The wrong language is not an error the run reports - it finishes and writes a subtitle that is
    # simply badly timed. Say so BEFORE the five minutes, unless they have already said to go ahead.
    if not str(request.form.get("force") or "").strip():
        try:
            _txt = (request.form.get("script_text") or "")
            if not _txt.strip() and docx_path and Path(docx_path).exists():
                # _docx_to_text takes the BYTES and the name, not a path
                _txt = _docx_to_text(Path(docx_path).read_bytes(), Path(docx_path).name) or ""
            _warn = subtitle_language_warning(_txt, lang)
        except Exception:
            _warn = ""
        if _warn:
            set_sub_status(project, status="idle", step="", error=None)
            return jsonify({"lang_mismatch": _warn}), 200
    # Always match the script to the ACTUAL voice-over first — EXCEPT when the audio was generated in-app from
    # this very script (use_gen_vo), where the wording is guaranteed to match already, so reconciliation is a waste.
    reconcile = not use_gen_vo
    _KeyThread(target=run_subtitle_job,
                     args=(project, audio_path, docx_path, out_path,
                           (trim_mode if trim else None), lang),
                     kwargs={"reconcile": reconcile}, daemon=True).start()
    return jsonify({"status": "running"})

# ---- routes: voice-over (ElevenLabs) ---------------------------------------
DEFAULT_VOICES = [
    {"name": "Loretta Jophlin", "voice_id": "DiWaolzR7aFbwU2MJGyD"},
    {"name": "Daniel Sandrin", "voice_id": "EC7t0LPc9MtRU1r33xNj"},
]
def load_voices():
    if VOICES_PATH.exists():
        try:
            return json.loads(VOICES_PATH.read_text(encoding="utf-8"))
        except Exception as _qe:
            quiet(_qe, "load_voices")
    VOICES_PATH.write_text(json.dumps(DEFAULT_VOICES, indent=2), encoding="utf-8")
    return list(DEFAULT_VOICES)

def save_voices(voices):
    VOICES_PATH.write_text(json.dumps(voices, indent=2, ensure_ascii=False), encoding="utf-8")

@app.route("/api/ost-presets", methods=["GET"])
def api_get_ost_presets():
    if OST_PRESETS_PATH.exists():
        try:
            return jsonify(json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8")))
        except Exception:
            return jsonify([])
    return jsonify([])

@app.route("/api/ost-presets", methods=["POST"])
def api_save_ost_presets():
    data = request.get_json(force=True)
    if not isinstance(data, list):
        return jsonify({"error": "expected a list"}), 400
    OST_PRESETS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"ok": True})

@app.route("/api/voices", methods=["GET"])
def api_voices():
    return jsonify(load_voices())

@app.route("/api/voices", methods=["POST"])
def api_voices_add():
    body = request.get_json(force=True)
    name = (body.get("name") or "").strip()
    vid = (body.get("voice_id") or "").strip()
    if not name or not vid:
        return jsonify({"error": "name and voice_id required"}), 400
    voices = load_voices()
    for v in voices:              # update if the name already exists
        if v.get("name", "").lower() == name.lower():
            v["voice_id"] = vid
            break
    else:
        voices.append({"name": name, "voice_id": vid})
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voices/<name>", methods=["DELETE"])
def api_voices_del(name):
    voices = [v for v in load_voices() if v.get("name", "").lower() != name.lower()]
    save_voices(voices)
    return jsonify(voices)

# ---- voice-over in pieces, at one steady level -----------------------------------------------------
# A 516-word script sent as ONE request came back fading away: -20.8 LUFS at the start and -48 by the
# end, a 27 dB collapse the render then faithfully reproduced. The model loses energy over a long
# generation. Cutting the script into pieces and asking for each on its own keeps every piece fresh,
# and matching their levels before they are joined keeps the whole thing even.
VO_CHUNK_CHARS = 700           # about 25 seconds of speech; short enough that no piece drifts
VO_TARGET_LUFS = -19.0         # each piece is brought to this before joining
VO_CONTEXT = 300               # characters of neighbouring text sent for prosody, never spoken


def _vo_chunks(text, size=VO_CHUNK_CHARS):
    """Split on sentence ends, never mid-sentence, packing up to `size` characters per piece."""
    parts = re.split(r"(?<=[.!?])\s+", " ".join((text or "").split()))
    out, cur = [], ""
    for p in parts:
        if not p:
            continue
        if cur and len(cur) + 1 + len(p) > size:
            out.append(cur)
            cur = p
        else:
            cur = (cur + " " + p).strip()
    if cur:
        out.append(cur)
    return out or [text]


def _vo_loudness(path):
    """Integrated loudness of a file, or None."""
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
                            "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                           capture_output=True, text=True, timeout=120, creationflags=_NO_WINDOW)
        hits = re.findall(r"I:\s*(-?[\d.]+)\s*LUFS", r.stderr)
        return float(hits[-1]) if hits else None
    except Exception:
        return None


def _eleven_tts(voice_id, text, prev="", nxt=""):
    """One piece. prev/nxt give the model the surrounding words so the joins do not sound stitched."""
    body = {"text": text, "model_id": ELEVEN_MODEL,
            "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}}
    if prev:
        body["previous_text"] = prev[-VO_CONTEXT:]
    if nxt:
        body["next_text"] = nxt[:VO_CONTEXT]
    r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
                      headers={"xi-api-key": _key('ELEVENLABS_API_KEY'), "Content-Type": "application/json",
                               "Accept": "audio/mpeg"},
                      params={"output_format": "mp3_44100_128"}, json=body, timeout=300)
    if r.status_code != 200:
        msg = ""
        try:
            m = r.json().get("detail", {})
            msg = m.get("message") if isinstance(m, dict) else str(m)
        except Exception:
            msg = r.text[:300]
        raise RuntimeError("ElevenLabs %s: %s" % (r.status_code, msg))
    return r.content


VO_LEVEL_WINDOW = 6.0          # seconds; wide enough that words and emphasis pass through untouched
VO_LEVEL_MAX_DB = 9.0          # the most the envelope pass will lift or duck a stretch


def _flatten_envelope(src, dst, window_s=VO_LEVEL_WINDOW, max_db=VO_LEVEL_MAX_DB):
    """Take the SLOW drift out of a speech recording. Gain only - not one sample moves in time.

    Chunking fixed the big fade (the whole file now measures flat end to end), but each generated
    piece still sags by a couple of dB over its own half-minute, and because the pieces are matched on
    their AVERAGE that leaves every join stepping up by about 3 dB. Rather than model that, measure
    what the level actually does over six-second windows and apply the inverse. Pauses are excluded
    from the measurement and the curve is carried across them, so a breath cannot drag a whole
    sentence up. Syllable-to-syllable dynamics are far faster than the window and survive intact.

    Returns True if it ran; False if numpy is unavailable, in which case the caller's ffmpeg chain
    still does most of the work.
    """
    try:
        import numpy as np
    except Exception:
        return False
    import wave
    sr = 44100
    tmp = Path(str(dst) + ".dec.wav")
    try:
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-ar", str(sr), "-ac", "1",
                        "-c:a", "pcm_s16le", str(tmp)], check=True, timeout=600,
                       creationflags=_NO_WINDOW)
        with wave.open(str(tmp)) as w:
            x = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float32) / 32768.0
        hop = int(0.2 * sr)
        n = len(x) // hop
        if n < 40:
            return False
        db = 10 * np.log10(np.maximum((x[:n * hop].reshape(n, hop) ** 2).mean(1), 1e-12))
        speech = db > (np.percentile(db, 95) - 25)
        if speech.sum() < 8:
            return False
        idx = np.arange(n)
        curve = np.interp(idx, idx[speech], db[speech])          # carry the level across every pause
        k = max(3, int(window_s / 0.2)) | 1
        g = np.exp(-0.5 * ((np.arange(k) - k // 2) / (k / 6.0)) ** 2)
        curve = np.convolve(np.pad(curve, k // 2, mode="edge"), g / g.sum(), mode="valid")[:n]
        gain = np.clip(np.median(db[speech]) - curve, -max_db, max_db)
        y = np.clip(x * (10 ** (np.interp(np.arange(len(x)), (idx + 0.5) * hop, gain) / 20.0)), -1, 1)
        with wave.open(str(dst), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
            w.writeframes((y * 32767).astype("<i2").tobytes())
        return True
    except Exception:
        return False
    finally:
        try: tmp.unlink()
        except OSError as _qe: quiet(_qe, "_flatten_envelope")


# After the envelope pass a gentle compressor evens out what is left inside a sentence, and loudnorm
# sets the absolute level. Measured on a 188 s narration: the gap between its quietest and loudest
# speech fell from 17.8 dB to 9.9, and the step at each join from up to 5.7 dB to 3.2 - inside the
# range that ordinary sentence breaks in the same recording already reach.
VO_LEVEL_TAIL = ("acompressor=threshold=-24dB:ratio=3:attack=15:release=200,"
                 "loudnorm=I=%.1f:TP=-1.5:LRA=7" % VO_TARGET_LUFS)
VO_LEVEL_TAIL_NO_NUMPY = "dynaudnorm=f=500:g=31:p=0.9:m=12:s=0," + VO_LEVEL_TAIL


def _level_voice(src, out_path):
    """Even out a finished voice-over and write it to out_path. Timing is preserved exactly."""
    src = Path(src)
    flat = src.with_name(src.stem + "_flat.wav")
    ok = _flatten_envelope(src, flat)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(flat if ok else src),
                    "-af", VO_LEVEL_TAIL if ok else VO_LEVEL_TAIL_NO_NUMPY,
                    "-c:a", "libmp3lame", "-b:a", "128k", str(out_path)],
                   check=True, timeout=600, creationflags=_NO_WINDOW)
    try: flat.unlink()
    except OSError as _qe: quiet(_qe, "_level_voice")
    return ok


def _voiceover_even(voice_id, text, out_path, on_step=None):
    """Generate the whole script piece by piece and join them at one level.

    Each piece is measured and gain-matched to VO_TARGET_LUFS before the join, so the finished file does
    not drift the way one long request does. Falls back to a single request if there is only one piece.
    """
    chunks = _vo_chunks(text)
    tmp = Path(tempfile.mkdtemp(prefix="vo_"))
    try:
        pieces = []
        for i, ch in enumerate(chunks):
            if on_step:
                on_step(i, len(chunks))
            audio = _eleven_tts(voice_id, ch,
                                prev=chunks[i - 1] if i else "",
                                nxt=chunks[i + 1] if i + 1 < len(chunks) else "")
            raw = tmp / ("p%02d.mp3" % i)
            raw.write_bytes(audio)
            lu = _vo_loudness(raw)
            fixed = tmp / ("n%02d.wav" % i)
            gain = "" if lu is None else "volume=%.2fdB," % (VO_TARGET_LUFS - lu)
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-af",
                            gain + "aresample=44100", "-ac", "1", str(fixed)],
                           check=True, timeout=180, creationflags=_NO_WINDOW)
            pieces.append(fixed)
        lst = tmp / "list.txt"
        lst.write_text("".join("file '%s'\n" % p.as_posix() for p in pieces), encoding="utf-8")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        joined = tmp / "joined.wav"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                        "-ar", "44100", "-ac", "1", str(joined)],
                       check=True, timeout=300, creationflags=_NO_WINDOW)
        _level_voice(joined, out_path)      # one steady level end to end; joins stop showing
        return len(chunks)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@app.route("/api/voiceover/<project>", methods=["POST"])
def api_voiceover(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    err = _keys_ok(("eleven",))
    if err:
        return err
    doc = load_doc(project)
    body = request.get_json(force=True)
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    (d / "voiceover").mkdir(exist_ok=True)
    out = d / "voiceover" / "voiceover.mp3"
    try:
        n_parts = _voiceover_even(voice_id, text, out)
    except Exception as e:
        return jsonify({"error": str(e)[:300]}), 502
    # The pauses are NOT cut here. At this moment nothing knows where the words are, and cutting on a
    # level threshold is what used to bite the ends off them. The trim now happens once, in the subtitle
    # step, where the alignment has just reported every word's start and end.
    proj = fname_slug((doc or {}).get("title") or project)
    spk = speaker_slug(voice_id)
    name = f"{proj}_{spk + '_' if spk else ''}Voiceover_{today_ddmmyyyy()}.mp3"
    return jsonify({"ok": True, "file": "voiceover/voiceover.mp3", "name": name})

# ---- routes: Premiere project export (FCP7 XML) ----------------------------
def _find_srt(d):
    """Locate the project's SRT: the one the subtitle job produced, else any *.srt."""
    sd = d / "subtitle"
    if not sd.exists():
        return None
    named = sorted(sd.glob("*_Subtitle_*.srt"))
    if named:
        return named[-1]
    any_srt = sorted(sd.glob("*.srt"))
    return any_srt[-1] if any_srt else None


def _vo_is_stale(d):
    """True when the voice-over has been regenerated since the subtitles were aligned to it.

    The render deliberately uses the audio the SRT was aligned to - any other take and the subtitles
    drift. So making a new voice-over silently invalidates the subtitles, and rendering anyway plays
    the OLD audio while looking like it worked. Better to say so.
    """
    vo = d / "voiceover" / "voiceover.mp3"
    if not vo.exists():
        return False
    sd = d / "subtitle"
    note = sd / "aligned_vo.json"
    if note.exists():                    # aligned since the signature was introduced: compare content
        try:
            want = json.loads(note.read_text(encoding="utf-8")).get("vo_sig")
            if want is not None:
                return _file_sig(vo) != want
        except Exception as _qe:
            quiet(_qe, "_vo_is_stale")
    aligned = [sd / "voiceover_trimmed.mp3"] + (sorted(sd.glob("audio.*")) if sd.exists() else [])
    for a in aligned:
        if a.exists():
            try:
                return vo.stat().st_mtime > a.stat().st_mtime + 2
            except OSError:
                return False
    return False


def _find_vo_audio(d):
    """The audio the SRT was aligned to: prefer the trimmed take, then the subtitle-job
    audio, then the generated voice-over."""
    sd = d / "subtitle"
    cand = [sd / "voiceover_trimmed.mp3"]
    if sd.exists():
        cand += sorted(sd.glob("audio.*"))
    cand.append(d / "voiceover" / "voiceover.mp3")
    for p in cand:
        if p.exists():
            return p
    return None


def _normalized_vo(d):
    """The voice-over loudness-normalized to a consistent VSL level (cached in export/;
    rebuilt only when the source changes). Falls back to the raw VO if ffmpeg fails."""
    src = _find_vo_audio(d)
    if not src:
        return None
    # Name it after the PROJECT. Every project used to export "voiceover_norm_mono.mp3", so a Premiere bin
    # holding two of them showed two identically-named clips and could relink the timeline to the wrong one.
    # The folder name is used almost verbatim (only characters Windows forbids in a filename are replaced):
    # folder names are unique by definition, whereas fname_slug collapses punctuation and would map
    # "Cardio-360" and "Cardio 360" onto one name — putting two projects back in collision.
    dst = d / "export" / (re.sub(r'[\\/:*?"<>|]+', "_", d.name).strip() + "_voiceover.mp3")
    try:
        fresh = dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime
    except Exception:
        fresh = False
    if fresh:
        return dst
    return premiere_export.normalize_loudness(src, dst, mono=True) or src


def _build_premiere_xml_full(project, doc, d, srt_text, vo):
    """build_premiere_xml WITH custom testimonial voices spliced in (VO + karaoke clips + no zoom).
    Guarded + fail-safe: no custom voices / any error → the normal XML. Used by all three export paths."""
    words_override = None
    scene_video_override = None
    _tl = None
    try:
        _tl = _apply_custom_testimonial_vo(project, doc, _build_timeline(project, doc))
        sm = _tl.get("_tvo_segmap")
        if sm:
            cues = premiere_export.parse_srt(srt_text)
            for c in cues:
                c["start"], c["end"] = _seg_remap(sm, c["start"]), _seg_remap(sm, c["end"])
            srt_text = premiere_export.caps_to_srt(cues)
            wa = premiere_export.load_word_tsv(d / "subtitle") or []
            words_override = [(_seg_remap(sm, s), _seg_remap(sm, e), w) for (s, e, w) in wa]
            vo = _tl["vo"]
    except Exception:
        words_override = None
    try:
        if _tl is not None:
            _inject_testimonial_karaoke(project, doc, _tl, d / "export" / "_xml_kara")
            scene_video_override = {s["id"]: str(s["path"]) for s in _tl.get("scenes", [])
                                    if s.get("no_zoom") and s.get("kind") == "video" and s.get("path")}
    except Exception:
        scene_video_override = None
    xml, info = premiere_export.build_premiere_xml(
        doc.get("title") or project, d, doc, srt_text, vo, BGM_ROOT,
        claude_fn=_claude_text, music_segments=_export_music(project, doc, srt_text, vo),
        words_override=words_override, scene_video_override=scene_video_override)
    # extra media the XML now references (so the .zip can bundle them): the spliced VO + karaoke clips
    extra = []
    try:
        if _tl is not None and _tl.get("_tvo_segmap"):
            extra.append(str(_tl["vo"]))
        extra += [str(p) for p in (scene_video_override or {}).values()]
    except Exception as _qe:
        quiet(_qe, "_build_premiere_xml_full")
    info["_tvo_media"] = [p for p in extra if p and Path(p).exists()]
    info["_tvo_vo"] = str(_tl["vo"]) if (_tl is not None and _tl.get("_tvo_segmap")) else None
    return xml, info


# ---- routes: named downloads (Export tab) ----------------------------------
def _kind_tag(doc):
    """The word a downloaded file carries. A YouTube project must not hand back something called VSL."""
    return "YouTube" if is_youtube(doc) else "VSL"


def _vsl_name(doc, project, typ, ext):
    """Filename convention: <Project>_<VSL|YouTube>_<Type>_<DDMMYYYY>.<ext>."""
    return f"{fname_slug(doc.get('title') or project)}_{_kind_tag(doc)}_{typ}_{today_ddmmyyyy()}.{ext}"


def _used_bgm_paths(info):
    """Reconstruct the on-disk paths of the background-music tracks the export actually used."""
    out = []
    for m in (info or {}).get("music", []):
        if m.get("track"):
            p = BGM_ROOT / m["emotion"] / m["track"]
            if p.exists():
                out.append(p)
    return out


def _ost_words(text):
    """Unicode word list (keeps French accents + digits), lower-cased."""
    return re.findall(r"[^\W_]+", (text or "").lower(), re.UNICODE)


def _seq_find(hay, needle):
    """Start index of the word-sequence `needle` inside `hay` (both lists of normalized words), or -1."""
    if not needle or len(needle) > len(hay):
        return -1
    for i in range(len(hay) - len(needle) + 1):
        if hay[i:i + len(needle)] == needle:
            return i
    return -1


def _ost_aware_srt(project, doc, srt_text):
    """SPLIT each caption around any on-screen-text overlay: the words shown as on-screen text are removed, the
    caption plays UP TO the moment the overlay appears, then RESUMES after it. e.g. VO "baran ... très effrayant
    ... quelque chose", overlay "très effrayant" -> caption1 "baran ..." (ends before the overlay) / [overlay]
    / caption2 "quelque chose" (starts after it). A lone leftover word (e.g. "une" when the overlay is "vision
    plus claire" but the line is "une vision plus claire") is DROPPED so it doesn't flash for a fraction of a
    second. Falls back to the full SRT on any error."""
    try:
        tl = _build_timeline(project, doc)
    except Exception:
        return srt_text
    wins = []                                        # (ost_start, ost_end, [normalized words])
    for s in tl.get("scenes", []):
        dur = max(0.001, (s.get("end") or 0) - (s.get("start") or 0))
        for tx in (s.get("texts") or []):
            words = _ost_words(tx.get("text") or "")
            if not words:
                continue
            a = s["start"] + dur * float(tx.get("text_in", 0) or 0)
            b = s["start"] + dur * float(tx.get("text_out", 1) or 1)
            wins.append((a, b, words))
    if not wins:
        return srt_text
    try:
        cues = premiere_export.parse_srt(srt_text)
        out = []
        for c in cues:
            toks = (c["text"] or "").split()
            norm = [re.sub(r"[^\w]", "", t.lower(), flags=re.UNICODE) for t in toks]   # per-token normalized form
            cs, ce = c["start"], c["end"]
            # first on-screen-text window that overlaps this caption in TIME and whose words appear in it (in order)
            hit = None
            for (wa, wb, words) in wins:
                if ce <= wa or cs >= wb:
                    continue
                idx = _seq_find(norm, words)
                if idx >= 0:
                    hit = (wa, wb, idx, len(words)); break
            if hit is None:
                if (c["text"] or "").strip():
                    out.append({"start": cs, "end": ce, "text": c["text"]})
                continue
            wa, wb, idx, wl = hit
            before, after = toks[:idx], toks[idx + wl:]
            if len(before) > 1:                      # keep the run BEFORE the overlay (drop a lone orphan word)
                out.append({"start": cs, "end": max(cs + 0.2, wa - 0.03), "text": " ".join(before)})
            if len(after) > 1:                       # keep the run AFTER the overlay (drop a lone orphan word)
                out.append({"start": min(wb + 0.03, ce - 0.2), "end": ce, "text": " ".join(after)})
        out.sort(key=lambda x: x["start"])
        return premiere_export.caps_to_srt(out)
    except Exception:
        return srt_text


@app.route("/api/export-notes/<project>")
def api_export_notes(project):
    """The warnings of this project's LAST Premiere export - a file download cannot carry them, so the page
    asks for them right after the XML has been saved."""
    n = _EXPORT_NOTES.get(project)
    return jsonify(n if isinstance(n, dict) else {"warnings": []})


@app.route("/api/download/<project>/<kind>")
def api_download(project, kind):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    if kind == "subtitle":
        srt = _find_srt(d)
        if not srt:
            return jsonify({"error": "No subtitle (.srt) yet — generate it in the Script & Voiceover tab."}), 404
        # split at scene boundaries + frame-quantize so captions and clips switch together in Premiere
        q = _delivery_srt(d, doc, srt)
        if request.args.get("ost") == "strip":       # OST-aware version: don't repeat on-screen-text words
            q = _ost_aware_srt(project, doc, q)
        return send_file(io.BytesIO(q.encode("utf-8")), mimetype="application/x-subrip",
                         as_attachment=True, download_name=_vsl_name(doc, project, "Subtitle", "srt"))
    if kind == "voiceover":
        if not _find_vo_audio(d):
            return jsonify({"error": "No voice-over yet — generate it in the Script & Voiceover tab."}), 404
        vo = _normalized_vo(d)                  # deliver the level-normalized voice-over
        return send_file(vo, as_attachment=True, download_name=_vsl_name(doc, project, "Voiceover", "mp3"))
    if kind == "script":
        txt = (doc.get("script") or "").strip()
        if not txt:
            return jsonify({"error": "No script yet — paste it in the Script & Voiceover tab."}), 404
        (d / "export").mkdir(parents=True, exist_ok=True)
        p = d / "export" / "_script.docx"
        text_to_docx(txt, p)
        return send_file(p, as_attachment=True, download_name=_vsl_name(doc, project, "Script", "docx"))
    if kind == "premiere":
        srt = _find_srt(d)
        if not srt or not _find_vo_audio(d):
            return jsonify({"error": "Need a subtitle (.srt) and a voice-over first."}), 400
        vo = _normalized_vo(d)
        try:
            _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
            xml, _info = _build_premiere_xml_full(project, doc, d, _srt_text, vo)   # testimonials: custom voice + karaoke clips + no zoom
        except Exception as e:
            return jsonify({"error": f"Assembly failed: {e}"}), 500
        out_name = _vsl_name(doc, project, "Premiere_Project", "xml")
        (d / "export").mkdir(parents=True, exist_ok=True)
        (d / "export" / out_name).write_text(xml, encoding="utf-8")
        _w = list((_info or {}).get("warnings") or [])
        if isinstance(_EXPORT_NOTES.get(project), str):
            _w.append(_EXPORT_NOTES.pop(project))
        _EXPORT_NOTES[project] = {"warnings": _w, "at": time.time()}
        return send_file(d / "export" / out_name, as_attachment=True, download_name=out_name)
    if kind in ("images", "videos"):
        # skip phantom scenes (manual lines not in the voice-over) when an SRT exists to detect them
        srtp = _find_srt(d)
        phantom = premiere_export.excluded_scene_ids(
            doc["scenes"], premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))) if srtp else set()
        buf = io.BytesIO()
        n = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for s in doc["scenes"]:
                if s.get("id") in phantom:
                    continue
                if kind == "images":
                    if not s.get("approved"):
                        continue
                    f = s["image"].get("approved_file") or s["image"].get("file")
                    if f and (d / f).exists():
                        z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png"); n += 1
                else:
                    v = s.get("video", {})
                    if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                        z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4"); n += 1
        if not n:
            return jsonify({"error": f"No approved {kind} to download."}), 404
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name=_vsl_name(doc, project, kind.capitalize(), "zip"))
    abort(404)


@app.route("/api/download/<project>/all")
def api_download_all(project):
    """One ZIP with the whole deliverable: Premiere .xml, SRT, voice-over, script .docx, each
    scene's approved video (or its approved image where no video), and the used music tracks."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt or not _find_vo_audio(d):
        return jsonify({"error": "Need at least a subtitle (.srt) and a voice-over first."}), 400
    vo = _normalized_vo(d)                      # level-normalized VO (same file the timeline uses)
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = _build_premiere_xml_full(project, doc, d, _srt_text, vo)   # testimonials: custom voice + karaoke clips + no zoom
    except Exception as e:
        return jsonify({"error": f"Assembly failed: {e}"}), 500
    # the XML may reference a SPLICED VO (custom testimonial voices) + karaoke clips — bundle THOSE so the zip is self-contained
    _tvo_vo = info.get("_tvo_vo")
    vo_zip = Path(_tvo_vo) if (_tvo_vo and Path(_tvo_vo).exists()) else vo
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(_vsl_name(doc, project, "Premiere_Project", "xml"), xml)
        # SRT split at scene boundaries + frame-quantized so captions/clips switch together in Premiere
        z.writestr(_vsl_name(doc, project, "Subtitle", "srt"), _delivery_srt(d, doc, srt))
        z.write(vo_zip, _vsl_name(doc, project, "Voiceover", vo_zip.suffix.lstrip(".") or "mp3"))
        for _p in (info.get("_tvo_media") or []):       # testimonial karaoke clips (+ the spliced VO is already the Voiceover above)
            _pp = Path(_p)
            if _pp.exists() and _pp != vo_zip:
                z.write(_pp, f"testimonials/{_pp.name}")
        txt = (doc.get("script") or "").strip()
        if txt:
            sp = d / "export" / "_script.docx"
            (d / "export").mkdir(parents=True, exist_ok=True)
            text_to_docx(txt, sp)
            z.write(sp, _vsl_name(doc, project, "Script", "docx"))
        # per scene: approved video, else approved image (only for approved scenes). Phantom scenes
        # (manual lines not in the voice-over) are skipped so the bundle matches the timeline.
        phantom = premiere_export.excluded_scene_ids(doc["scenes"],
                                                     premiere_export.parse_srt(srt.read_text(encoding="utf-8", errors="ignore")))
        dl_video = dl_image = 0
        for s in doc["scenes"]:
            if s.get("id") in phantom:
                continue
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
                dl_video += 1
            elif s.get("approved"):
                f = s["image"].get("approved_file") or s["image"].get("file")
                if f and (d / f).exists():
                    z.write(d / f, f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.png")
                    dl_image += 1
        for p in _used_bgm_paths(info):
            z.write(p, f"music/{p.name}")
    # counts of what was ACTUALLY put in the zip (video where approved, else approved image)
    info["dl_video"] = dl_video
    info["dl_image"] = dl_image
    info.pop("_tvo_media", None); info.pop("_tvo_vo", None)   # internal-only (don't leak paths into the response header)
    buf.seek(0)
    resp = send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=_vsl_name(doc, project, "All_Files", "zip"))
    resp.headers["X-Export-Info"] = _urlquote(json.dumps(info))   # content summary for the UI
    resp.headers["Access-Control-Expose-Headers"] = "X-Export-Info"
    return resp


def _inside(fp, d):
    """True when the resolved file really sits under the project folder. A string-prefix test let
    Cardio-360 reach into Cardio-360_Merih; comparing path components does not."""
    try:
        Path(fp).resolve().relative_to(Path(d).resolve())
        return True
    except ValueError:
        return False


@app.route("/media/<project>/<path:relpath>")
def api_media(project, relpath):
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not _inside(fp, d) or not fp.exists():
        abort(404)
    dl = request.args.get("dl")
    if dl:  # force a download with a specific filename
        return send_file(fp, as_attachment=True, download_name=dl)
    return send_file(fp)


MEDIA_THUMB_MAX = 1000   # px on the long edge — 2x+ the on-screen scene-card size, so it looks pixel-identical

@app.route("/media-thumb/<project>/<path:relpath>")
def api_media_thumb(project, relpath):
    """A light, cached preview of a generated image for the Scenes cards ONLY. The full 2K PNG is kept
    untouched (export / download / video / lightbox all still use /media). Loading a ~90KB WebP instead
    of a 5-7MB PNG in dozens of cards is what keeps the tab smooth. Generated on first view, then cached;
    falls back to the original if PIL can't read it (so the card can never end up blank)."""
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not _inside(fp, d) or not fp.exists():
        abort(404)
    tdir = d / ".thumbs" / "media"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(relpath.encode("utf-8")).hexdigest() + ".webp")
    if not thumb.exists() or thumb.stat().st_mtime < fp.stat().st_mtime:
        try:
            im = Image.open(fp).convert("RGB")
            im.thumbnail((MEDIA_THUMB_MAX, MEDIA_THUMB_MAX))
            im.save(thumb, "WEBP", quality=88, method=5)
        except Exception:
            return send_file(fp)   # unreadable → hand over the original (never a blank card)
    return send_file(thumb, mimetype="image/webp")


@app.route("/bgm/<path:relpath>")
def api_bgm(relpath):
    """Serve a background-music track (lives outside any project, under BGM_ROOT) for the preview."""
    fp = (BGM_ROOT / relpath).resolve()
    if not str(fp).startswith(str(BGM_ROOT.resolve())) or not fp.exists():
        abort(404)
    return send_file(fp)


def _delivery_srt(d, doc, srt_path):
    """The SRT we hand to the user: captions split at scene boundaries + frame-quantized (matches the
    exported clip cuts and the preview). Falls back to the plain quantized SRT on any problem."""
    srt_text = srt_path.read_text(encoding="utf-8", errors="ignore")
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return premiere_export.quantize_srt_to_frames(srt_text)
        vo = _find_vo_audio(d)
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        words = premiere_export.load_word_tsv(d / "subtitle")
        return premiere_export.delivery_srt(doc.get("scenes", []), cues, total, words)
    except Exception:
        return premiere_export.quantize_srt_to_frames(srt_text)


def _ensure_suno_lib():
    """Ensure the mood folders exist under BGM_ROOT. The music library is CURATED BY THE USER (they drop their
    own level-matched tracks into each mood folder) — so we ONLY create the folders if missing and NEVER copy
    anything in (no bundled seed, no generation). Touching the user's files would pollute their curation."""
    try:
        for mood in suno_music.MOOD_NAMES:
            (BGM_ROOT / mood).mkdir(parents=True, exist_ok=True)
    except Exception as _qe:
        quiet(_qe, "_ensure_suno_lib")


def _suno_lib_tracks(mood):
    """Sorted audio files currently in a mood's Suno library folder (newest last)."""
    folder = BGM_ROOT / mood
    if not folder.exists():
        return []
    return sorted((p for p in folder.iterdir() if p.suffix.lower() in (".mp3", ".wav")),
                  key=lambda p: p.stat().st_mtime)


def _coalesce_sections(plan, min_sec=45.0):
    """Clean up the LLM's segmentation WITHOUT flattening genuine mood variety (the old version merged purely by
    duration to hit a fixed count, which ATE distinct short moods like a 40s reassurance or a 60s CTA and left
    the video sounding all-one-mood). Two safe passes only:
      1. Collapse ADJACENT SAME-MOOD sections into one block — no mood is lost, and _split_long_sections later
         re-splits an over-long block into different-track pieces so a long act still refreshes its music.
      2. Absorb any remaining too-SHORT section (< min_sec — a stray blip; the user dislikes 30-40s changes)
         into a neighbour, PREFERRING a same-mood neighbour, else the LONGER one (whose mood it adopts).
    No fixed target count: a distinct, long-enough mood is KEPT, never merged away just to reach a number."""
    plan = [dict(s) for s in plan]
    if len(plan) <= 1:
        return plan
    def _collapse(p):
        out = [dict(p[0])]
        for s in p[1:]:
            if s["emotion"] == out[-1]["emotion"]:
                out[-1]["end"] = s["end"]
            else:
                out.append(dict(s))
        return out
    plan = _collapse(plan)
    while len(plan) > 1:
        i = min(range(len(plan)), key=lambda k: plan[k]["end"] - plan[k]["start"])
        if (plan[i]["end"] - plan[i]["start"]) >= min_sec:
            break                                            # even the shortest section is long enough → done
        left = plan[i - 1] if i > 0 else None
        right = plan[i + 1] if i < len(plan) - 1 else None
        if left and left["emotion"] == plan[i]["emotion"]:          j = i - 1
        elif right and right["emotion"] == plan[i]["emotion"]:      j = i + 1
        elif left and right:
            j = i - 1 if (left["end"] - left["start"]) >= (right["end"] - right["start"]) else i + 1
        else:
            j = i - 1 if left else i + 1
        lo, hi = min(i, j), max(i, j)
        plan[lo] = {"start": plan[lo]["start"], "end": plan[hi]["end"],
                    "emotion": plan[j]["emotion"], "track": None}   # merged block adopts the neighbour's mood
        del plan[lo + 1:hi + 1]
        plan = _collapse(plan)
    return plan


def _split_long_sections(plan, max_sec=270, target_sec=240):
    """HARD guarantee (not left to the LLM): no music section runs longer than max_sec. An over-long section is
    split into equal ADJACENT same-mood pieces (~target_sec each); adjacent same-mood pieces then get DIFFERENT
    tracks (never-reuse), so a long act refreshes its music instead of one track droning for many minutes."""
    out = []
    for seg in plan:
        dur = (seg.get("end") or 0) - (seg.get("start") or 0)
        if dur <= max_sec:
            out.append(seg); continue
        n = max(2, int(round(dur / target_sec)))
        s0, s1 = seg["start"], seg["end"]
        for i in range(n):
            a = s0 + (s1 - s0) * i / n
            b = s1 if i == n - 1 else s0 + (s1 - s0) * (i + 1) / n
            out.append({"start": round(a, 3), "end": round(b, 3), "emotion": seg["emotion"], "track": None})
    return out


def _assign_section_tracks(plan, seed=""):
    """Assign each section a library track for its mood, CYCLING through the mood's tracks so EVERY successive
    section of the same mood uses a DIFFERENT file — not just adjacent ones (so the same audio isn't reused
    across the video while other tracks sit unused). If a mood has more sections than tracks it wraps around
    (adjacent are still kept different). A section the user manually locked (dropdown / reroll) keeps its track.
    `seed` (the project) decides WHERE in each mood's list the walk starts: every project used to start at
    the first file, so two videos that both open on Corporate opened on the same track. The start is fixed
    per project, so re-planning the same project lands on the same choices."""
    idx = {}
    prev_mood, prev_track = None, None
    for seg in plan:
        mood = seg.get("emotion")
        libs = [p.name for p in _suno_lib_tracks(mood)]
        if seg.get("locked") and seg.get("track") in libs:      # respect a manual pick / reroll
            prev_mood, prev_track = mood, seg["track"]; continue
        if not libs:
            seg["track"] = None; prev_mood, prev_track = mood, None; continue
        if mood not in idx:
            idx[mood] = int(hashlib.md5(("%s|%s" % (seed, mood)).encode("utf-8")).hexdigest(), 16) % len(libs)
        i = idx.get(mood, 0)
        cur = libs[i % len(libs)]
        if mood == prev_mood and cur == prev_track and len(libs) > 1:   # never repeat the immediate neighbour
            i += 1; cur = libs[i % len(libs)]
        idx[mood] = i + 1
        seg["track"] = cur
        prev_mood, prev_track = mood, cur


def _emotion_tracks():
    """{MOOD: [track filenames]} across the 6 Suno mood folders (the override dropdown menu)."""
    _ensure_suno_lib()
    out = {}
    for mood in suno_music.MOOD_NAMES:
        out[mood] = [p.name for p in _suno_lib_tracks(mood)]
    return out


def _resolve_music(project, doc, cues, total, save=True):
    """Build-ready music segments honoring the SAVED plan + per-segment overrides. The plan (Claude
    emotion-segmentation over the SUNO 6-mood palette + a library track per section) is computed ONCE and
    cached in doc.music_plan. A section whose mood has NO library track yet gets path=None — the music
    generation job (api_music_generate) fills those in with Suno, then they're reused."""
    _ensure_suno_lib()
    moods = suno_music.MOOD_NAMES
    plan = doc.get("music_plan")
    # The plan is anchored to the SCRIPT's end - the same number for every caller. The preview timeline adds
    # a 4.5 s outro to its total and the export does not, so a plan judged against the caller's total was
    # 4.5 s "wrong" for whichever side had not made it: each Build Preview and each export re-segmented the
    # music (a Claude call) and the preview's tracks never matched the XML's. Each caller now stretches the
    # LAST section to its own end instead (below).
    plan_end = round(float(cues[-1]["end"]), 3)
    valid = (isinstance(plan, list) and plan and abs((plan[-1].get("end") or 0) - plan_end) < 4.0
             and doc.get("music_plan_v") == SUNO_PLAN_VERSION           # old-logic/Envato plan → re-segment
             and all((seg.get("emotion") in moods) for seg in plan))
    if not valid:
        segs = premiere_export.segment_emotions(cues, plan_end, _claude_text, moods, humanize=suno_music.humanize)
        plan = [{"start": round(s["start"], 3), "end": round(s["end"], 3), "emotion": s["emotion"], "track": None}
                for s in segs]
        plan = _coalesce_sections(plan)                    # ~4–5 blocks by dominant mood (stops over-frequent changes)
        plan = _split_long_sections(plan)                  # HARD cap: no section over ~4 min (splits long acts)
    _assign_section_tracks(plan, seed=project)              # each section a DIFFERENT track; the walk starts where THIS project's seed says
    doc["music_plan"] = plan
    doc["music_plan_v"] = SUNO_PLAN_VERSION
    if save:
        save_doc(project, doc)
    cache_path = BGM_ROOT / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    out = []
    for seg in plan:
        emo, track = seg.get("emotion"), seg.get("track")
        # Use the library track EXACTLY as provided — the user curates + level-matches the pool themselves, so
        # no auto-processing (no leveller/limiter, no fade-trim); the files play as-is.
        path = (BGM_ROOT / emo / track) if (track and (BGM_ROOT / emo / track).exists()) else None
        lufs, tp = premiere_export.measure_lufs(path, cache) if path else (None, None)
        out.append({"start": seg["start"], "end": seg["end"], "emotion": emo, "path": path,
                    "src_dur": premiere_export.audio_duration(path) if path else None, "lufs": lufs, "tp": tp})
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception as _qe:
        quiet(_qe, "_resolve_music")
    if out and float(total) > out[-1]["end"]:
        out[-1]["end"] = round(float(total), 3)               # the music runs to THIS caller's end (the preview's outro tail)
    # Push every music transition LATER by a fixed offset: the new track was entering slightly before the scene
    # it changes on. Shift the INTERNAL boundaries only (first start=0 and last end=total stay put); each
    # consumer (preview mix, Premiere XML, MP4 render) keeps its own crossfade SHAPE around the shifted boundary.
    if len(out) > 1:
        orig = [(s["start"], s["end"]) for s in out]
        for i in range(1, len(out)):
            nb = min(orig[i][0] + MUSIC_SHIFT_SEC, orig[i][1] - 0.5)   # never cross this section's own end
            out[i - 1]["end"] = nb
            out[i]["start"] = nb
    return out


# ---- Suno background-music generation jobs ---------------------------------
SUNO_JOBS = {}
_SUNO_JOB_LOCK = threading.Lock()


def _music_cues_total(d):
    srtp = _find_srt(d); vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    if _vo_is_stale(d):
        raise ValueError("The voice-over has been regenerated since the subtitles were made, so the "
                         "subtitles no longer match it. Generate the subtitles again, then render.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
    return cues, total


@app.route("/api/music-generate/<project>", methods=["POST"])
def api_music_generate(project):
    """Resolve the music plan (segment the script into moods + assign a DISTINCT library track per section). There
    is NO generation anymore — the library is user-curated, so this only PLANS. `need` is always 0 (kept for the
    frontend's existing shape). Re-segment the whole plan first with ?resegment=1."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _ = proj_dir(project)
    if request.args.get("resegment") or (request.get_json(silent=True) or {}).get("resegment"):
        doc["music_plan"] = []
        save_doc(project, doc)
    try:
        cues, total = _music_cues_total(d)
        _resolve_music(project, doc, cues, total)            # segment + assign distinct library tracks
        plan = doc.get("music_plan") or []
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "music planning failed: " + str(e)}), 500
    reused = sum(1 for seg in plan if seg.get("track"))
    return jsonify({"job": None, "need": 0, "reused": reused, "segments": len(plan)})


@app.route("/api/music-cancel/<job>", methods=["POST"])
def api_music_cancel(job):
    with _SUNO_JOB_LOCK:
        if job in SUNO_JOBS:
            SUNO_JOBS[job]["cancel"] = True
    return jsonify({"ok": True})


@app.route("/api/music-job/<job>")
def api_music_job(job):
    with _SUNO_JOB_LOCK:
        st = SUNO_JOBS.get(job)
    if not st:
        return jsonify({"error": "no such job"}), 404
    return jsonify(st)


@app.route("/api/music-reroll/<project>", methods=["POST"])
def api_music_reroll(project):
    """Swap one section to a DIFFERENT library track of the same mood (no generation) — prefer one not used by any
    other section, else just a different one. Locks the pick. Returns the new track immediately (no job)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx = body.get("index")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    mood = plan[idx].get("emotion")
    cur = plan[idx].get("track")
    libs = [p.name for p in _suno_lib_tracks(mood)]
    if not libs:
        return jsonify({"error": f"No tracks in the '{mood}' folder yet."}), 400
    used = {s.get("track") for i, s in enumerate(plan) if i != idx and s.get("track")}
    choices = [t for t in libs if t != cur and t not in used] or [t for t in libs if t != cur] or libs
    pick = choices[0]
    plan[idx]["track"] = pick
    plan[idx]["locked"] = True                                # reroll = an explicit pick for this section
    save_doc(project, doc)
    path = BGM_ROOT / mood / pick
    url = ("/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()) if path.exists() else None
    lufs, tp = premiere_export.measure_lufs(path, {}) if path.exists() else (None, None)
    return jsonify({"job": None, "track": pick, "url": url,
                    "level": round(premiere_export.music_level(lufs, tp, youtube=is_youtube(doc)), 3), "options": libs})


def _export_music(project, doc, srt_text, vo):
    """The music segments (saved/overridable plan) for the Premiere export — same plan as the preview.
    None when the plan could not be made even on a second try (the XML then says so in its warnings)."""
    cues = premiere_export.parse_srt(srt_text)
    if not cues:
        return None
    total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
    last = None
    for attempt in range(2):                 # the planner asks Claude to segment the script; one blip must not
        try:                                 # cost the whole timeline its music
            segs = _resolve_music(project, doc, cues, total)
            if segs:
                return segs
        except Exception as e:
            last = e
            quiet(e, "_export_music attempt %d" % (attempt + 1))
    _EXPORT_NOTES[project] = "music plan failed: %s" % (str(last)[:160] if last else "no segments came back")
    return None


_EXPORT_NOTES = {}                           # project -> the last export's warnings, for the download button's toast


@app.route("/api/music-override/<project>", methods=["POST"])
def api_music_override(project):
    """Set a specific segment's track (index into doc.music_plan)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx, track = body.get("index"), body.get("track")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    emo = plan[idx].get("emotion")
    if track and not (BGM_ROOT / emo / track).exists():
        return jsonify({"error": "track not found in that mood folder"}), 400
    plan[idx]["track"] = track
    plan[idx]["locked"] = bool(track)                        # manual pick → don't let auto-assign overwrite it
    save_doc(project, doc)
    resp = {"ok": True, "url": None, "level": None}
    if track:
        path = BGM_ROOT / emo / track
        cache_path = BGM_ROOT / ".loudness_cache.json"
        try:
            cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
        except Exception:
            cache = {}
        lufs, tp = premiere_export.measure_lufs(path, cache)
        try:
            cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
        except Exception as _qe:
            quiet(_qe, "api_music_override")
        resp["level"] = round(premiere_export.music_level(lufs, tp, youtube=is_youtube(doc)), 3)
        resp["url"] = "/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()
    return jsonify(resp)


_VID_TX_PAD = 0.4      # render_video.TX_SEC - the longest overlap a transition eats from the outgoing clip


def scene_vo_seconds(project, doc):
    """{scene id: seconds of voice-over under it}, or {} when the subtitles are not ready yet.
    Same mapping the timeline, the render and the Premiere export all use, so the numbers agree."""
    try:
        d, _ = proj_dir(project)
        srtp = _find_srt(d)
        vo = _normalized_vo(d)
        if not srtp or not vo:
            return {}
        cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
        if not cues:
            return {}
        scenes = doc.get("scenes") or []
        words = premiere_export.load_word_tsv(d / "subtitle")
        word_starts = premiere_export.word_scene_starts(scenes, words) if words else None
        total = max(premiere_export.audio_duration(vo) or 0.0, cues[-1]["end"])
        ranges, _inc = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
        out = {}
        for sc, rg in zip(scenes, ranges):
            if rg:
                out[sc.get("id")] = max(0.0, float(rg[1]) - float(rg[0]))
        return out
    except Exception:
        return {}      # never let a timing hiccup block approving or loading a project


def autofit_video_durations(project, doc):
    """Fit every APPROVED scene's clip length to its own voice-over. Returns how many changed.
    Runs on BOTH product types - a YouTube episode is cut to its narration the same way a VSL is."""
    secs = scene_vo_seconds(project, doc)
    if not secs:
        return 0
    by_model = {m["key"]: m for m in VIDEO_MODELS}
    n = 0
    for s in doc.get("scenes") or []:
        if not s.get("approved"):
            continue
        need = secs.get(s.get("id"))
        if not need:
            continue
        m = by_model.get(s.get("video_model") or "")
        if not m:
            continue
        opts = sorted(m["durations"])
        want = next((x for x in opts if x >= need + _VID_TX_PAD - 1e-6), opts[-1])
        cur = s.get("video_dur")
        # Only shrink a value the user never touched; always raise one that would be slowed.
        if cur == want:
            continue
        if want < (cur or 0) and cur != m.get("defaultDur"):
            continue
        s["video_dur"] = want
        n += 1
    return n


def _build_timeline(project, doc):
    """The single source of truth for 'the assembled VSL': each scene's media + audio-driven
    time range, the scene-split caption cues, the normalized voice-over, and the emotion-
    segmented music with per-segment levels. Uses the SAME timing/music logic as the Premiere
    export, so preview == rendered MP4 == exported timeline.

    Media are LOCAL PATHS here; api_preview maps them to /media URLs for the browser and
    render_video feeds them straight to ffmpeg. Raises ValueError if the inputs aren't ready.
    """
    d, _ = proj_dir(project)
    srtp = _find_srt(d)
    vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    if _vo_is_stale(d):
        raise ValueError("The voice-over has been regenerated since the subtitles were made, so the "
                         "subtitles no longer match it. Generate the subtitles again, then render.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    vo_dur = premiere_export.audio_duration(vo) or 0.0
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # accurate spoken-word onsets for mid-cue scenes (same as the export uses)
    words = premiere_export.load_word_tsv(d / "subtitle")
    word_starts = premiere_export.word_scene_starts(scenes, words) if words else None
    ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
    cue_tok_times = premiere_export.accurate_cue_token_times(cues, words) if words else None

    # Snap every boundary to a whole video frame. Both scene starts and caption starts get the
    # SAME quantizer, so a scene and its caption switch on the exact same frame in the preview,
    # AND the rendered clip durations become integer frames (no ffmpeg cumulative-rounding drift).
    _FPS = premiere_export.FPS
    def qf(t):
        return round(round(t * _FPS) / _FPS, 5)   # 5 dp keeps the exact frame value (frame/60 repeats)

    out_scenes = []
    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc or t1 <= t0:
            continue
        vid = s.get("video") or {}
        img = s.get("image") or {}
        item = {"id": s.get("id"), "start": qf(t0), "end": qf(t1),
                "label": premiere_export.scene_label(s), "kind": "blank", "path": None, "img": None,
                # on-screen text overlays (burned onto the video, shown in preview + render)
                "texts": _scene_overlays(s),
                # overlay icons (X / arrow / pain-burst) — shown as a static preview of their XML placement
                "icons": (s.get("icons") or []) if s.get("style") not in ANIM_STYLES else [],
                "transition": s.get("transition") or "none",   # how this scene hands off to the next
                "grain": bool(s.get("grain_on")),             # old-film grain over this shot
                "atmo": s.get("atmo") or "",                  # fog / rain / snow / embers over this shot
                "move": s.get("move") or "hold"}              # push in / pull out / locked off
        # the approved still image (if any) — the smooth fallback for the "images only" toggle
        imgf = (img.get("approved_file") or img.get("file")) if s.get("approved") else None
        if imgf and (d / imgf).exists():
            item["img"] = d / imgf
        if vid.get("approved") and vid.get("status") == "ready" and vid.get("file") and (d / vid["file"]).exists():
            item.update(kind="video", path=d / vid["file"])
        elif item["img"]:
            item.update(kind="image", path=item["img"])
        out_scenes.append(item)

    # An episode should dip away rather than stop dead: hold the last shot a few seconds past the last
    # spoken word and let the picture and the music fade over it. Done here, so the preview shows the
    # same ending the render produces, and the music segmentation covers the tail.
    outro = 0.0
    try:
        outro = float(doc.get("outro_fade", OUTRO_FADE_SEC) or 0.0)
    except (TypeError, ValueError):
        outro = 0.0
    if outro > 0.05 and out_scenes:
        out_scenes[-1]["end"] = qf(out_scenes[-1]["end"] + outro)
        total = round(total + outro, 3)

    # split captions at scene boundaries so a caption and its scene switch together
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    caps = premiere_export.split_captions_at_scenes(cues, scene_starts, cue_tok_times)
    # same frame-quantizer as the scenes → caption starts land on the exact scene-start frame
    # Close the small gaps the aligner leaves between cues. A subtitle that blinks off for two frames
    # and back on reads as a fault; each line simply runs until the next one starts.
    for _a, _b in zip(caps, caps[1:]):
        _g = _b["start"] - _a["end"]
        if 0 < _g <= 0.6:
            _a["end"] = _b["start"]
    captions = [{"start": qf(c["start"]), "end": qf(c["end"]), "text": c["text"]}
                for c in caps if qf(c["end"]) > qf(c["start"])]

    music = []
    tracks_by_emotion = _emotion_tracks()
    try:
        segs = _resolve_music(project, doc, cues, total)     # saved/overridable plan
    except Exception:
        segs = []
    for i, seg in enumerate(segs):
        p = seg.get("path")
        emo = seg["emotion"]
        music.append({"index": i, "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                      "emotion": emo, "track": (Path(p).name if p else None),
                      "path": Path(p) if p else None,
                      "level": round(premiere_export.music_level(seg.get("lufs"), seg.get("tp"), youtube=is_youtube(doc)), 3),
                      "options": tracks_by_emotion.get(emo, [])})

    return {"total": round(total, 3), "vo": vo, "dir": d, "outro": round(outro, 3),
            "scenes": out_scenes, "captions": captions, "music": music,
            "youtube": is_youtube(doc),                 # which product: decides zoom, music and sfx
            "dust": bool(doc.get("film_dust")),          # the film look, over the whole episode
            "cam_float": bool(doc.get("cam_float")),     # handheld drift on the stills
            # Depth parallax is a YOUTUBE feature. A VSL is hand-cut in Premiere from the XML, which
            # cannot express a depth warp at all, so the effect would only ever exist in a preview
            # the user never ships - and it must not differ between the preview and the timeline.
            # Gated HERE because _build_timeline feeds the render, the preview and the XML alike.
            "parallax": bool(doc.get("cam_parallax")) and is_youtube(doc),
            "grade": bool(doc.get("film_grade")),        # one colour grade + vignette
            "sub_style": doc.get("subtitle_style") or None}


# ---------------------------------------------------------------- YouTube: sign in and upload
_YT_JOBS = {}
_YT_LOCK = threading.Lock()


@app.route("/api/youtube/state")
def api_youtube_state():
    """?check=1 actually asks Google whether the sign-in is still alive.

    Worth the round trip when Assemble opens: while the app is in Testing, Google throws the refresh
    token away every 7 days, and finding that out at the START of a 118 MB upload is a poor time.
    """
    cfg = _load_config()
    tok = cfg.get("youtube_token") or {}
    out = {"configured": bool(cfg.get("youtube_client_id") and cfg.get("youtube_client_secret")),
           "connected": bool(tok.get("refresh_token")),
           "channel": cfg.get("youtube_channel") or "", "stale": False,
           "keys": sum(1 for k in ("youtube_api_key", "youtube_api_key2") if (cfg.get(k) or "").strip()),
           "ytdlp": bool(youtube.ytdlp_exe())}
    if out["connected"] and request.args.get("check"):
        try:
            youtube.access_token(cfg)
            _save_config(cfg)                       # keep the token it just refreshed
        except youtube.SignInExpired:
            _save_config(cfg)                       # youtube.py already dropped the dead one
            out.update(connected=False, channel="", stale=True)
        except Exception as _qe:
            quiet(_qe, "api_youtube_state")                                    # offline or Google having a moment - say nothing
    return jsonify(out)


@app.route("/api/youtube/keys", methods=["POST"])
def api_youtube_keys():
    b = request.get_json(force=True) or {}
    cfg = _load_config()
    for k, v in (("youtube_client_id", b.get("client_id")), ("youtube_client_secret", b.get("client_secret")),
                 ("youtube_api_key", b.get("api_key")), ("youtube_api_key2", b.get("api_key2"))):
        if v is not None:
            cfg[k] = str(v).strip()
    _save_config(cfg)
    return jsonify({"ok": True})


@app.route("/api/youtube/connect", methods=["POST"])
def api_youtube_connect():
    """Open Google's consent page. The reply lands on a loopback port this process is listening on."""
    cfg = _load_config()
    done = {}

    def on_done(tok, err):
        if tok:
            c = _load_config()
            c["youtube_token"] = tok
            try:
                c["youtube_channel"] = youtube.channel_name(c)
            except Exception:
                c["youtube_channel"] = ""
            _save_config(c)
        done["err"] = err
    url = youtube.start_sign_in(cfg.get("youtube_client_id"), cfg.get("youtube_client_secret"), on_done)
    if not url:
        return jsonify({"error": done.get("err") or "Add the Google client ID and secret first."}), 400
    return jsonify({"ok": True, "url": url})


@app.route("/api/youtube/disconnect", methods=["POST"])
def api_youtube_disconnect():
    cfg = _load_config()
    cfg.pop("youtube_token", None); cfg.pop("youtube_channel", None)
    _save_config(cfg)
    return jsonify({"ok": True})


def _yt_worker(jid, project):
    j = _YT_JOBS[jid]
    cfg = None
    try:
        doc = load_doc(project) or {}
        d, _ = proj_dir(project)
        p = _pub_get(doc)
        video = d / "export" / "render.mp4"
        if not video.exists():
            raise youtube.YouTubeError("There is no render to upload yet.")
        cfg = _load_config()
        title = (p.get("title") or doc.get("title") or project)[:100]
        tags = [t.strip() for t in (p.get("tags") or "").split(",") if t.strip()][:60]
        # Telling YouTube the language is not cosmetic: automatic dubbing needs to know what it is
        # translating FROM, and auto-captions and translated metadata key off it too. Guessing is on
        # YouTube otherwise, and a wrong guess makes the dub nonsense.
        lang = ((doc.get("script_opts") or {}).get("lang") or "en").split("-")[0].lower()[:5] or "en"
        snippet = {"title": title, "description": (p.get("description") or "")[:5000],
                   "tags": tags, "categoryId": "27",      # 27 = Education
                   "defaultLanguage": lang, "defaultAudioLanguage": lang}
        privacy = (p.get("privacy") or "schedule").lower()
        sched = privacy == "schedule"
        if privacy not in ("private", "unlisted", "public"):
            privacy = "private"
        status = {"privacyStatus": privacy, "selfDeclaredMadeForKids": (p.get("kids") == "kids")}
        when = p.get("scheduled_for") or ""
        # Only the "Scheduled" choice books a time. Public/Unlisted/Private mean exactly what they say,
        # even when a date happens to be sitting in the boxes - publishAt always ends in PUBLIC, so
        # applying it to an Unlisted episode would quietly do the opposite of what was asked.
        if sched and when:
            try:
                dt = datetime.fromisoformat(when)
            except Exception:
                dt = None
            if dt and dt > datetime.now():
                # publishAt only means anything on a private video; YouTube rejects it otherwise
                status["privacyStatus"] = "private"
                status["publishAt"] = dt.astimezone().astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with _YT_LOCK:
            j.update(step="Uploading the video", pct=1)
        vid = youtube.upload(cfg, video, snippet, status,
                             on_progress=lambda n: j.update(pct=max(1, min(96, n)), step="Uploading the video"))
        _save_config(cfg)                                  # a refreshed access token is worth keeping
        thumb = d / (p.get("thumb") or "export/thumbnail.png")
        if thumb.exists():
            with _YT_LOCK:
                j.update(step="Setting the thumbnail", pct=97)
            try:
                youtube.set_thumbnail(cfg, vid, thumb)
            except Exception as e:
                _yt_note(j, str(e)[:200])
        pid = p.get("playlist")
        if pid:
            with _YT_LOCK:
                j.update(step="Adding it to the playlist", pct=98)
            try:
                youtube.add_to_playlist(cfg, pid, vid)
            except Exception as e:
                _yt_note(j, "The video is up but it did not go into the playlist: " + str(e)[:160])
        doc = load_doc(project) or doc
        pub = _pub_get(doc)
        pub["video_id"] = vid
        pub["status"] = "scheduled" if status.get("publishAt") else "published"
        pub["uploaded_at"] = int(time.time())
        doc["publish"] = pub
        save_doc(project, doc)
        with _YT_LOCK:
            j.update(status="done", pct=100, step="Done", video_id=vid,
                     url="https://youtu.be/" + vid if vid else "")
    except youtube.SignInExpired as e:
        if cfg is not None:
            _save_config(cfg)          # youtube.py dropped the dead token from it; make that stick
        with _YT_LOCK:
            j.update(status="error", error=str(e))
    except Exception as e:
        with _YT_LOCK:
            j.update(status="error", error=str(e)[:400])


def _yt_note(j, msg):
    with _YT_LOCK:
        j.setdefault("notes", []).append(msg)


@app.route("/api/youtube/upload/<project>", methods=["POST"])
def api_youtube_upload(project):
    if load_doc(project) is None:
        abort(404)
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"error": "Connect your YouTube channel in Settings first."}), 400
    jid = "yt-%d" % int(time.time() * 1000)
    with _YT_LOCK:
        _YT_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting...", "error": None, "notes": []}
    _KeyThread(target=_yt_worker, daemon=True, args=(jid, project)).start()
    return jsonify({"ok": True, "job": jid})


_YT_PL_CACHE = {"at": 0, "items": None}


@app.route("/api/youtube/playlists")
def api_youtube_playlists():
    """The channel's playlists. Cached for a minute - the Publish panel asks on every load and the
    list only changes when someone makes a playlist."""
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"items": [], "connected": False})
    fresh = request.args.get("fresh")
    if not fresh and _YT_PL_CACHE["items"] is not None and time.time() - _YT_PL_CACHE["at"] < 60:
        return jsonify({"items": _YT_PL_CACHE["items"], "connected": True})
    try:
        items = youtube.playlists(cfg)
    except youtube.SignInExpired as e:
        _save_config(cfg)
        return jsonify({"items": [], "connected": False, "error": str(e)})
    except Exception as e:
        return jsonify({"items": [], "connected": True, "error": str(e)[:300]})
    _save_config(cfg)
    _YT_PL_CACHE.update(at=time.time(), items=items)
    return jsonify({"items": items, "connected": True})


@app.route("/api/youtube/playlists", methods=["POST"])
def api_youtube_playlist_new():
    b = request.get_json(force=True) or {}
    title = (b.get("title") or "").strip()
    if not title:
        return jsonify({"error": "Give the playlist a name."}), 400
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"error": "Connect your YouTube channel in Settings first."}), 400
    try:
        pid = youtube.create_playlist(cfg, title, (b.get("description") or "").strip(),
                                      (b.get("privacy") or "public"))
    except Exception as e:
        return jsonify({"error": str(e)[:300]}), 400
    _save_config(cfg)
    _YT_PL_CACHE.update(at=0, items=None)              # the list just changed
    return jsonify({"ok": True, "id": pid, "title": title})


@app.route("/api/youtube/playlist-add/<project>", methods=["POST"])
def api_youtube_playlist_add(project):
    """Put an episode that is already up into its playlist - the same second chance Set Thumbnail gives."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"error": "Connect your YouTube channel in Settings first."}), 400
    p = _pub_get(doc)
    vid, pid = p.get("video_id"), p.get("playlist")
    if not vid:
        return jsonify({"error": "This episode is not on your channel yet."}), 400
    if not pid:
        return jsonify({"error": "Pick a playlist first."}), 400
    try:
        if youtube.playlist_has(cfg, pid, vid):
            _save_config(cfg)
            return jsonify({"ok": True, "already": True})
        youtube.add_to_playlist(cfg, pid, vid)
    except Exception as e:
        return jsonify({"error": str(e)[:300]}), 400
    _save_config(cfg)
    return jsonify({"ok": True})


_DEMAND_SYSTEM = (
    "You turn one episode idea into the YouTube searches a viewer would actually type to find a video "
    "like it. Give 2 or 3 short searches: one for the plain subject, one for the specific story or "
    "claim, and if the idea has a well-known name or event, one for that. No quotes, no boolean "
    "operators, no channel names - just the words a person types.\n"
    "EVERY search must be about the SAME subject as this episode. Do NOT widen it to a related "
    "technology, product or general skill: an episode about the pinhole beside a phone camera "
    "searches for that hole, never for noise cancelling microphones. A search that drifts brings "
    "back videos competing with nothing, and the whole check becomes meaningless.\n"
    'Reply with ONLY a JSON object: {"queries":["barber pole history","why barber poles are red"]}')


def _demand_pick(project, doc, candidates, minutes, log=None):
    """Score candidate episode titles on real YouTube numbers and return the best one.

    A title nobody searches for, or one whose every winner is a twenty-minute documentary, produces a
    video that is never found. Checking costs one search each (100 quota units of 10,000 a day), which
    is nothing next to generating sixty images for an episode that sinks.
    """
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return None, []                       # not signed in - fall through to the plain choice
    order = {"good": 0, "risky": 1, "weak": 2, "wrong-length": 3, "unknown": 4, "avoid": 5}
    scored = []
    for c in candidates[:5]:
        title = (c.get("title") or "").strip() if isinstance(c, dict) else str(c).strip()
        if not title:
            continue
        idea = (c.get("idea") or "") if isinstance(c, dict) else ""
        try:
            d = youtube.demand(cfg, _demand_queries(title, idea), our_minutes=minutes,
                               keep=_demand_filter(title, idea),
                               note=(lambda m: log(m)) if log else None)
        except youtube.QuotaSpent as e:
            if log:
                log(str(e))                     # every later check would fail the same way
            break
        except Exception as e:
            if log:
                log("Could not check '%s' on YouTube (%s)." % (title[:60], str(e)[:80]))
            continue
        best = max((r["ratio"] for r in d.get("outliers") or []), default=0.0)
        scored.append((order.get(d["verdict"], 4), -best, title, idea, d))
        if log:
            log("%s  ->  %s. %s" % (title[:64], d["verdict"].upper(), d["why"]))
    _save_config(cfg)
    if not scored:
        return None, []
    scored.sort(key=lambda x: (x[0], x[1]))
    top = scored[0]
    if top[0] >= order["avoid"] and log:
        log("Every angle checked looks crowded. Going with the least bad one; consider a different "
            "subject next time.")
    return {"title": top[2], "idea": top[3], "demand": top[4]}, scored


FACTCHECK_SYSTEM = """You are the last person to read this script before it is filmed, and your only job
is to find what is NOT TRUE. Not the writing, not the pacing, not the structure - somebody else already
did that. You are looking for claims that would make a viewer who knows the subject stop the video and
write a correction underneath it.

Read every sentence and ask: is this actually so?

WHAT TO FLAG, and be strict:
- WRONG. A statement about how something works, where something goes, what causes what, that is simply
  incorrect. This is the one that matters most. A plumbing video that puts a pipe on the wrong side of
  a trap, a physics video with the force backwards, a history video with the wrong century.
- INVENTED. A date, a place, a name, a law, a court case, a study or a number that reads as specific
  but is not something you can actually confirm. Confident detail nobody can source is worse than no
  detail, because it is the part people check.
- OVERSTATED. A superlative or an absolute the evidence does not carry: "the most common", "everyone",
  "always", "never", "the only". Usually true in spirit and indefensible as written.
- TOO BROAD. True of the common case, stated as though true of all cases. "Every X works this way" when
  many do not.

DO NOT flag: opinions, framing, dramatic phrasing, simplification that is still correct, or anything
you merely dislike. If a sentence is true, leave it alone. A false alarm costs the writer trust in you.

For each problem give:
- "quote": the exact sentence from the script, copied character for character so it can be found.
- "problem": what is wrong with it, in one plain sentence, said to the writer not about them.
- "fix": the same sentence rewritten so it is true. Keep the voice, the rhythm and roughly the length -
  this replaces the original word for word. If the claim cannot be saved, cut it down to what IS true.
- "severity": "wrong" for a definite factual error or an invented specific, "soft" for an overstatement
  or an over-broad claim that is arguable rather than false.

Reply with ONLY a JSON object:
{"issues":[{"quote":"...","problem":"...","fix":"...","severity":"wrong"}]}
An empty list is a perfectly good answer if the script is sound."""


def factcheck_script(script, title="", idea=""):
    """Every checkable claim in the script, read by someone whose only job is doubt.

    The craft review scores structure and pacing; it has no opinion on whether a sentence is TRUE. That
    gap let a script say a bath overflow joins the drain BELOW the trap - which would vent the sewer
    into the bathroom - because the brief it was written from said so and nobody asked.
    """
    script = (script or "").strip()
    if len(script.split()) < 30:
        return []
    user = ("TITLE: %s\n\nWHAT THE EPISODE IS MEANT TO SAY:\n%s\n\nTHE SCRIPT:\n%s"
            % (title or "(untitled)", (idea or "(nothing given)")[:1500], script[:14000]))
    try:
        out = _ask_json(FACTCHECK_SYSTEM, user,
                        want=lambda v: isinstance(v.get("issues"), list))
    except Exception:
        return []
    issues = []
    for it in out["issues"][:12]:
        q, fx = str(it.get("quote") or "").strip(), str(it.get("fix") or "").strip()
        if not q or q not in script:           # a quote we cannot find cannot be repaired
            continue
        issues.append({"quote": q, "fix": fx,
                       "problem": " ".join(str(it.get("problem") or "").split())[:300],
                       "severity": "wrong" if str(it.get("severity")).lower().startswith("wrong")
                                   else "soft"})
    return issues


def apply_factchecks(script, issues, only_wrong=True):
    """Put the corrections into the script. Returns (new_script, what_changed).

    Only the definite errors are applied on their own. An overstatement is a judgement call, and a
    machine quietly rewriting the writer's judgement is worse than leaving it: those are reported at
    the money gate instead, where somebody is already reading.
    """
    changed = []
    for it in issues:
        if only_wrong and it["severity"] != "wrong":
            continue
        if not it["fix"] or it["quote"] not in script:
            continue
        script = script.replace(it["quote"], it["fix"], 1)
        changed.append(it)
    return script, changed


def _demand_queries(title, idea=""):
    """What would someone search for to find this? Falls back to the title itself."""
    try:
        out = _ask_json(_DEMAND_SYSTEM, ("TITLE: %s\nIDEA: %s" % (title, idea[:900])).strip(),
                        want=lambda v: isinstance(v.get("queries"), list) and v["queries"])
        qs = [str(q).strip() for q in out["queries"] if str(q).strip()][:3]
        return qs or [title]
    except Exception:
        return [title]


# Asking a model to hand back a filtered subset does not work: told in plain words to throw out
# plumbing tutorials, and shown that exact example, it kept all eight of them. Labelling each item
# one at a time is a job models do reliably, so the model labels and the filtering happens here.
_RELEVANT_SYSTEM = (
    "You are given one episode and a numbered list of YouTube videos from a search. Label EVERY video "
    "with what KIND of video it is. Judge the kind from the title.\n"
    "The labels, use exactly these words:\n"
    "  explainer  - explains why or how something is the way it is, or tells the story behind it\n"
    "  tutorial   - how to do, fix, install, replace, clean or make something\n"
    "  review     - a product review, comparison, unboxing or buying advice\n"
    "  news       - a news report or clip about a current event\n"
    "  music      - a song, soundtrack, performance or audio track\n"
    "  film       - a full documentary, lecture, podcast, compilation or sleep/background video\n"
    "  other      - anything else, including a video about a DIFFERENT subject than this episode\n"
    "Anything not about this episode's subject is 'other', whatever else it looks like.\n"
    "Reply with ONLY a JSON object holding one label per video, IN ORDER, the same count as the list: "
    '{"kinds":["explainer","tutorial","other"]}')

_RIVAL_KINDS = {"explainer"}


def _demand_filter(title, idea):
    """Keep only videos a viewer would watch INSTEAD of this episode.

    Two searches showed why this is needed: one for a phone's microphone pinhole counted a film
    soundtrack and two Windows tutorials as rivals, and one for a bathtub's overflow hole came back as
    eight plumbing repair guides. Neither set competes with an episode explaining why the thing exists,
    and counting them made the whole reading meaningless.
    """
    def keep(rows):
        if len(rows) < 3:
            return rows
        use = rows[:45]
        listing = "\n".join("%d. %s" % (i + 1, r["title"][:120]) for i, r in enumerate(use))
        out = _ask_json(_RELEVANT_SYSTEM,
                        "EPISODE: %s\nWHAT IT IS ABOUT: %s\n\nVIDEOS:\n%s"
                        % (title, (idea or "")[:600], listing),
                        want=lambda v: isinstance(v.get("kinds"), list) and v["kinds"])
        kinds = [str(k).strip().lower() for k in out["kinds"]]
        if len(kinds) < len(use) * 0.6:        # it did not really label them - do not trust the result
            return rows
        return [r for r, k in zip(use, kinds) if k in _RIVAL_KINDS]
    return keep


@app.route("/api/factcheck/<project>", methods=["POST"])
def api_factcheck(project):
    """Read the script for claims that are untrue. The same pass Auto Episode runs, on demand, because
    every step of the pipeline has to be reachable by hand as well as inside the one-button run."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    b = request.get_json(silent=True) or {}
    so = doc.get("script_opts") or {}
    script = (b.get("script") or doc.get("script") or "").strip()
    if len(script.split()) < 30:
        return jsonify({"error": "There is no script to check yet."}), 400
    try:
        issues = factcheck_script(script, b.get("title") or so.get("title") or doc.get("title") or "",
                                  b.get("idea") or so.get("idea") or "")
    except Exception as e:
        return jsonify({"error": str(e)[:300]}), 502
    if b.get("apply"):
        only_wrong = not b.get("apply_all")
        fixed, changed = apply_factchecks(script, issues, only_wrong=only_wrong)
        if changed:
            doc = load_doc(project) or doc
            # BOTH fields, or the correction is invisible: the Script box reads script_draft and only
            # falls back to script, so writing one of them leaves the user staring at the old wording.
            doc["script"] = fixed
            doc["script_draft"] = fixed
            save_doc(project, doc)
        return jsonify({"ok": True, "applied": len(changed), "script": fixed,
                        "issues": issues, "changed": changed})
    return jsonify({"issues": issues,
                    "wrong": sum(1 for i in issues if i["severity"] == "wrong")})


@app.route("/api/youtube/demand", methods=["POST"])
def api_youtube_demand():
    """Has anyone WATCHED a video like this, and did a small channel ever win with it?"""
    b = request.get_json(force=True) or {}
    title = (b.get("title") or "").strip()
    if not title:
        return jsonify({"error": "Write a title or a topic first."}), 400
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"error": "Connect your YouTube channel in Settings first - the check uses it "
                                 "to read YouTube."}), 400
    qs = b.get("queries") or _demand_queries(title, b.get("idea") or "")
    try:
        notes = []
        d = youtube.demand(cfg, qs, our_minutes=float(b.get("minutes") or 4),
                           keep=_demand_filter(title, b.get("idea") or ""), note=notes.append)
        d["notes"] = notes[:1]
    except youtube.SignInExpired as e:
        _save_config(cfg)
        return jsonify({"error": str(e)}), 400
    except youtube.QuotaSpent as e:
        return jsonify({"error": str(e)}), 429
    except Exception as e:
        return jsonify({"error": str(e)[:300]}), 400
    _save_config(cfg)
    d["queries"] = qs
    d["title"] = title
    return jsonify(d)


@app.route("/api/youtube/thumb/<project>", methods=["POST"])
def api_youtube_thumb(project):
    """Put the thumbnail on an episode that is ALREADY up. YouTube refuses custom thumbnails until the
    channel is phone-verified, and without this the only way back would be uploading the whole file
    again - which would leave a duplicate video on the channel."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    cfg = _load_config()
    if not (cfg.get("youtube_token") or {}).get("refresh_token"):
        return jsonify({"error": "Connect your YouTube channel in Settings first."}), 400
    p = _pub_get(doc)
    vid = p.get("video_id")
    if not vid:
        return jsonify({"error": "This episode is not on your channel yet."}), 400
    d, _ = proj_dir(project)
    thumb = d / (p.get("thumb") or "export/thumbnail.png")
    if not thumb.exists():
        return jsonify({"error": "There is no thumbnail attached to this episode."}), 400
    try:
        youtube.set_thumbnail(cfg, vid, thumb)
    except youtube.SignInExpired as e:
        _save_config(cfg)
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)[:400]}), 400
    _save_config(cfg)
    return jsonify({"ok": True, "url": "https://youtu.be/" + vid})


@app.route("/api/youtube/job/<jid>")
def api_youtube_job(jid):
    with _YT_LOCK:
        return jsonify(dict(_YT_JOBS.get(jid) or {"status": "error", "error": "no such job"}))


def _px_clip_for(project, sc):
    """The cached depth clip for one timeline scene, or None. Built with EXACTLY the key the render
    uses, so the preview plays the very file the render will - never a second, slightly different one."""
    try:
        import parallax as _px
    except Exception:
        return None
    if sc.get("kind") != "image" or not sc.get("path") or sc.get("no_zoom"):
        return None
    try:
        d, _ = proj_dir(project)
        work = d / "export" / "_render_tmp"
        dur = float(sc["end"]) - float(sc["start"]) + 0.8      # the same tail the render adds
        key = _px.clip_key(sc["path"], dur, sc.get("move") or "hold", sc.get("id") or 0,
                           1920, 1080, render_video.FPS)
        p = work / ("_px_%s.mp4" % key)
        return p if p.exists() else None
    except Exception:
        return None


def _requirement_rows():
    """Every outside thing the app leans on, what breaks without it, and whether we can fetch it."""
    import shutil
    rows = []

    def add(key, label, ok, impact, fix="manual", how="", note=""):
        rows.append({"key": key, "label": label, "ok": bool(ok), "impact": impact,
                     "fix": fix if not ok else "", "how": how if not ok else "", "note": note})

    ff = shutil.which("ffmpeg")
    add("ffmpeg", "ffmpeg", ff, "Rendering and audio cannot run at all.",
        how="Install ffmpeg and make sure it is on PATH, or copy the ffmpeg folder from the working PC.",
        note=ff or "")
    add("ffprobe", "ffprobe", shutil.which("ffprobe"), "Clip lengths cannot be read, so the render mistimes.",
        how="Comes with ffmpeg - installing that fixes this too.")

    try:
        from caption_layer import edge_exe
        br = edge_exe()
    except Exception:
        br = None
    add("browser", "Headless Edge or Chrome", br,
        "Burnt-in captions cannot be drawn; the render finishes WITHOUT them.",
        how="Install Microsoft Edge or Google Chrome. Windows normally ships Edge already.",
        note=br or "")

    for mod, why in (("cv2", "image work and the depth warp"), ("numpy", "every image operation"),
                     ("PIL", "thumbnails, cards and overlays"), ("onnxruntime", "the depth model")):
        try:
            __import__(mod)
            good = True
        except Exception:
            good = False
        add("py:" + mod, "Python module: " + mod, good, "Needed for %s." % why,
            how="Reinstall the packaged app - these ship inside its own runtime.")

    try:
        import parallax as _px
        add("depthmodel", "Depth model (parallax)", _px.have_model(),
            "Depth parallax is skipped and stills get a flat zoom instead.",
            fix="auto", how="About 99 MB, downloaded once and checked against a known SHA-256.")
    except Exception as e:
        add("depthmodel", "Depth model (parallax)", False,
            "Depth parallax is skipped: " + str(e)[:80], how="Reinstall the packaged app.")

    add("ytdlp", "yt-dlp", shutil.which("yt-dlp"),
        "Check Topic loses its fallback when the YouTube API allowance runs out.",
        how="Optional. Install yt-dlp and put it on PATH.")
    return rows


@app.route("/api/requirements")
def api_requirements():
    """What is missing on THIS machine. Called on start so a second PC is never silently degraded."""
    rows = _requirement_rows()
    missing = [r for r in rows if not r["ok"]]
    return jsonify({"rows": rows, "missing": len(missing),
                    "fixable": len([r for r in missing if r["fix"] == "auto"])})


@app.route("/api/requirements/fix", methods=["POST"])
def api_requirements_fix():
    """Fetch the one thing we may fetch on our own: the depth model, into the app's own models folder."""
    key = ((request.get_json(silent=True) or {}).get("key") or "").strip()
    if key != "depthmodel":
        return jsonify({"error": "That one has to be installed on the machine - the app will not do it for you."}), 400
    try:
        import parallax as _px
        if _px.have_model():
            return jsonify({"ok": True, "state": "done"})
        st = _px.download_state()
        if st.get("state") != "downloading":
            _KeyThread(target=_px.ensure_model, daemon=True).start()
        return jsonify({"ok": True, "state": "downloading"})
    except Exception as e:
        return jsonify({"error": str(e)[:200]}), 500


@app.route("/api/depth-model")
def api_depth_model():
    """Is the depth model here, and if it is being fetched, how far along."""
    try:
        import parallax as _px
        st = _px.download_state()
        return jsonify({"have": _px.have_model(), "runnable": _px.runnable(),
                        "state": st["state"], "pct": st["pct"], "error": st["error"]})
    except Exception as e:
        return jsonify({"have": False, "runnable": False, "state": "error", "pct": 0, "error": str(e)[:200]})


@app.route("/api/preview/<project>")
def api_preview(project):
    """Manifest for the in-dashboard rough-cut player. The client plays it synced — no
    server-side render (that's /api/render, which consumes the same timeline)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    try:
        tl = _build_timeline(project, doc)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    try:
        tl = _apply_custom_testimonial_vo(project, doc, tl)   # preview plays the same spliced VO the render will
    except Exception as _qe:
        quiet(_qe, "api_preview")
    d = tl["dir"]

    # Remember that this project has a watchable preview, so re-opening it later can
    # restore the player without the user clicking Build Preview again. Re-read right before
    # writing so this GET can't clobber a concurrent scene edit (e.g. on-screen text just added)
    # that was saved between our load_doc above and here — only the flag is persisted.
    if not doc.get("preview_built"):
        fresh = load_doc(project) or doc
        fresh["preview_built"] = True
        save_doc(project, fresh)
        doc["preview_built"] = True

    def murl(p):
        return f"/media/{project}/{Path(p).relative_to(d).as_posix()}"

    out_scenes = []
    for s in tl["scenes"]:
        item = {"id": s["id"], "start": s["start"], "end": s["end"], "label": s["label"],
                "type": s["kind"],
                "url": murl(s["path"]) if s["path"] else None,
                "img": murl(s["img"]) if s["img"] else None}
        item["texts"] = s.get("texts") or []   # on-screen text overlays for this scene
        item["icons"] = s.get("icons") or []   # overlay icons (static preview of their XML placement)
        item["transition"] = s.get("transition") or "none"
        # A still the render will show with depth: play the render's OWN warped clip, so the preview is
        # the same picture in motion rather than a flat stand-in. Keep `img` - Images Only still works.
        if tl.get("parallax"):
            _pxp = _px_clip_for(project, s)
            if _pxp:
                item["type"] = "video"
                item["url"] = murl(_pxp)
                item["px"] = True
        # the look the render will apply, so the Assemble tab can say what is and is not being shown
        item["move"] = s.get("move") or "hold"
        item["atmo"] = s.get("atmo") or ""
        item["grain"] = bool(s.get("grain"))
        out_scenes.append(item)
    music = []
    for m in tl["music"]:
        e = {k: m[k] for k in ("index", "start", "end", "emotion", "track", "level", "options")}
        e["url"] = ("/bgm/" + m["path"].resolve().relative_to(BGM_ROOT.resolve()).as_posix()
                    ) if m["path"] else None
        music.append(e)

    _px_have = sum(1 for s in out_scenes if s.get("px"))
    _px_want = sum(1 for s in tl["scenes"]
                   if s.get("kind") == "image" and s.get("path") and not s.get("no_zoom")) if tl.get("parallax") else 0
    return jsonify({"duration": tl["total"], "vo": murl(tl["vo"]),
                    "scenes": out_scenes, "captions": tl["captions"], "music": music,
                    # what the render will do on top of what you are watching
                    "look": {"parallax": bool(tl.get("parallax")), "px_ready": _px_have, "px_total": _px_want,
                             "dust": bool(tl.get("dust")), "grade": bool(tl.get("grade")),
                             "cam_float": bool(tl.get("cam_float"))},
                    "custom_vo": sorted(tl.get("_tvo_ids") or []),   # scenes whose VO was spliced to a custom clip → client karaoke uses the clip's words
                    "words": tl.get("words_remapped")})              # REMAPPED word times (present only after a splice) so client karaoke stays synced past the shift


PXBUILD_JOBS, _PXB_LOCK = {}, threading.Lock()


def _pxbuild_worker(jid, project):
    """Warp every still the preview will show, into the render's own cache."""
    j = PXBUILD_JOBS[jid]
    try:
        import parallax as _px
        doc = load_doc(project) or {}
        try:
            tl = _build_timeline(project, doc)
        except Exception as e:               # no voice-over / subtitle yet: nothing to warp; the preview says why
            with _PXB_LOCK:
                j.update(status="done", pct=100, made=0, note=str(e)[:200])
            return
        if not tl.get("parallax"):
            with _PXB_LOCK:
                j.update(status="done", pct=100, made=0,
                         note="Depth parallax is off for this project - run the effects pass first.")
            return
        if not _px.have_model():
            with _PXB_LOCK: j.update(step="Downloading the depth model (99 MB, once)…")
            _px.ensure_model(progress=lambda p: PXBUILD_JOBS[jid].update(pct=int(p * 0.3)))
        if not _px.available():
            raise RuntimeError("the depth model is not usable on this PC")
        d, _ = proj_dir(project)
        work = d / "export" / "_render_tmp"
        work.mkdir(parents=True, exist_ok=True)
        todo = [s for s in (tl.get("scenes") or [])
                if s.get("kind") == "image" and s.get("path") and not s.get("no_zoom")]
        made = 0
        for n, sc in enumerate(todo):
            if j.get("cancel"):
                break
            with _PXB_LOCK:
                j.update(pct=30 + int(70 * n / max(1, len(todo))),
                         step="Adding depth to the stills… %d/%d" % (n + 1, len(todo)))
            dur = float(sc["end"]) - float(sc["start"]) + 0.8
            if _px.build_clip(sc["path"], work / ("_px_%s.mp4" % _px.clip_key(
                    sc["path"], dur, sc.get("move") or "hold", sc.get("id") or n,
                    1920, 1080, render_video.FPS)),
                    dur, render_video.FPS, 1920, 1080,
                    move=sc.get("move") or "hold", seed=int(sc.get("id") or n), cache=work):
                made += 1
        with _PXB_LOCK:
            j.update(status="cancelled" if j.get("cancel") else "done", pct=100, made=made,
                     step="Done - %d still(s) now carry depth." % made)
    except Exception as e:
        with _PXB_LOCK:
            j.update(status="error", error=str(e)[:250])


@app.route("/api/preview/<project>/build-depth", methods=["POST"])
def api_preview_build_depth(project):
    """Warp the stills so the preview shows the same depth the render will. Cached - the render reuses it."""
    if load_doc(project) is None:
        abort(404)
    with _PXB_LOCK:
        for jid0, j0 in PXBUILD_JOBS.items():          # one build per project - a second press joins it
            if j0.get("project") == project and j0.get("status") == "running":
                return jsonify({"ok": True, "job": jid0, "joined": True})
        jid = "px-%d" % int(time.time() * 1000)
        PXBUILD_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting…", "error": None,
                             "made": 0, "cancel": False, "project": project}
    _KeyThread(target=_pxbuild_worker, daemon=True, args=(jid, project)).start()
    return jsonify({"ok": True, "job": jid})


def _pxbuild_stop(project, wait=180):
    """Stop a background depth build for this project and wait for it to let go. The render is about
    to warp the same stills into the same cache; it takes over rather than racing for the files."""
    with _PXB_LOCK:
        live = [j for j in PXBUILD_JOBS.values() if j.get("project") == project and j.get("status") == "running"]
        for j in live:
            j["cancel"] = True
    t0 = time.time()
    while live and any(j.get("status") == "running" for j in live) and time.time() - t0 < wait:
        time.sleep(0.5)


@app.route("/api/preview/build-depth/<jid>")
def api_preview_build_depth_job(jid):
    return jsonify(PXBUILD_JOBS.get(jid) or {"status": "error", "error": "no such job"})


@app.route("/api/words/<project>")
def api_words(project):
    """Word-level forced-alignment timings [{s,e,w}] cached by the subtitle aligner (words_*.tsv,
    each line 'start<TAB>end<TAB>word'). Powers the karaoke highlight in the testimonial cards and
    the Assemble preview. Returns {"words": []} if no alignment has been run yet."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, _safe = proj_dir(project)
    sd = d / "subtitle"
    words = []
    if sd.exists():
        # prefer the medium-model VAD cache (the one the final SRT is built from), then any words_*.tsv
        cands = [sd / "words_medium_en_vad.tsv", sd / "words_medium_en.tsv"] + sorted(sd.glob("words_*.tsv"))
        wp = next((p for p in cands if p.exists()), None)
        if wp:
            try:
                for ln in wp.read_text(encoding="utf-8").splitlines():
                    if not ln.strip():
                        continue
                    parts = ln.split("\t", 2)
                    if len(parts) >= 3:
                        words.append({"s": float(parts[0]), "e": float(parts[1]), "w": parts[2]})
            except Exception:
                words = []
    return jsonify({"words": words})


# ---- routes: server-side MP4 render ----------------------------------------
RENDER_STATUS, RENDER_LOCK = {}, threading.Lock()
RENDER_PROCS = {}                 # project -> the running ffmpeg Popen (so a cancel can kill it)
RENDER_CANCEL = set()             # projects whose current render was cancelled by the user


def set_render_status(project, **kw):
    with RENDER_LOCK:
        st = RENDER_STATUS.get(project, {})
        st.update(kw); st["updated"] = time.time()
        RENDER_STATUS[project] = st
    return st


RENDER_HISTORY_KEEP = 8

def _archive_render(out_path, fast, doc, project, dur):
    """Keep a named copy of a finished render so it isn't lost when the next render overwrites
    render.mp4 / render_test.mp4. Real renders go to export/renders/, quick test renders to
    export/test-renders/. Filenames carry the project + date; test renders also carry their length in
    seconds (e.g. MyVSL_VSL_Test_26072026-143512_30s.mp4, or _YouTube_ on a YouTube project). Each
    folder is pruned to RENDER_HISTORY_KEEP."""
    try:
        export = Path(out_path).parent
        slug = fname_slug((doc or {}).get("title") or project)
        tag = _kind_tag(doc)
        stamp, clock = today_ddmmyyyy(), time.strftime("%H%M%S")
        if fast:
            hist = export / "test-renders"
            fname = f"{slug}_{tag}_Test_{stamp}-{clock}_{max(1, int(round(dur or 0)))}s.mp4"
        else:
            hist = export / "renders"
            fname = f"{slug}_{tag}_Video_{stamp}-{clock}.mp4"
        hist.mkdir(exist_ok=True)
        shutil.copy2(out_path, hist / fname)
        files = sorted(hist.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[RENDER_HISTORY_KEEP:]:
            try:
                old.unlink()
            except OSError as _qe:
                quiet(_qe, "_archive_render")
    except Exception as _qe:
        quiet(_qe, "_archive_render")

_RENDER_CACHE_CAP = 3 * 1024 ** 3        # bytes of export/_render_tmp kept per project
_RENDER_CACHE_YOUNG = 3600               # a file made this recently may still be in use - never remove it


def _prune_render_cache(work, cap=_RENDER_CACHE_CAP, young=_RENDER_CACHE_YOUNG):
    """Keep the render cache under `cap` bytes, oldest files first. Everything in it is rebuilt on
    demand, so the only cost of removing a file is the time to make it again. Returns bytes freed."""
    try:
        files = []
        for p in Path(work).rglob("*"):
            if p.is_file():
                st = p.stat()
                files.append((st.st_mtime, st.st_size, p))
    except OSError:
        return 0
    total = sum(sz for _, sz, _ in files)
    if total <= cap:
        return 0
    now, freed = time.time(), 0
    for mt, sz, p in sorted(files):
        if total - freed <= cap:
            break
        if now - mt < young:
            continue
        try:
            p.unlink()
            freed += sz
        except OSError as _qe:
            quiet(_qe, "_prune_render_cache")
    return freed


def run_render_job(project, doc, out_path, name, opts):
    """Background thread: build the timeline, hand it to ffmpeg, track progress."""
    with RENDER_LOCK:
        RENDER_CANCEL.discard(project)          # fresh run — clear any stale cancel flag
    try:
        set_render_status(project, status="running", pct=0, step="Preparing timeline…", error=None)
        tl = _build_timeline(project, doc)
        try:
            tl = _apply_custom_testimonial_vo(project, doc, tl)   # splice any custom testimonial voice-overs into the VO + reflow times (guarded; no-op without custom voices)
        except Exception as _qe:
            quiet(_qe, "run_render_job")
        try:
            set_render_status(project, step="Rendering testimonial karaoke…")
            _inject_testimonial_karaoke(project, doc, tl, out_path.parent / "_render_tmp")   # burn karaoke into written-testimonial scenes (guarded)
        except Exception as _qe:
            quiet(_qe, "run_render_job")
        set_render_status(project, step="Rendering video…", duration=tl["total"])
        _pxbuild_stop(project)
        _prune_render_cache(out_path.parent / "_render_tmp")

        def on_progress(pct, done):
            set_render_status(project, pct=pct, step="Rendering video…")

        def on_status(text):
            set_render_status(project, step=text)

        def on_proc(p):
            with RENDER_LOCK:
                RENDER_PROCS[project] = p
                cancel_now = project in RENDER_CANCEL   # cancel arrived before ffmpeg started
            if cancel_now:
                try: p.terminate()
                except Exception as _qe: quiet(_qe, "on_proc")

        def should_cancel():
            with RENDER_LOCK:
                return project in RENDER_CANCEL

        render_video.render(tl, out_path, out_path.parent / "_render_tmp", opts,
                            on_progress, on_proc, on_status, should_cancel)
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL        # cancel that raced past the kill
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()
            except OSError as _qe: quiet(_qe, "run_render_job")
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
            return
        size = out_path.stat().st_size
        _rng = opts.get("range")
        _rendered_dur = (_rng[1] - _rng[0]) if _rng else float(tl.get("total") or 0)
        _archive_render(out_path, bool(opts.get("fast")), doc, project, _rendered_dur)   # named copy in the render history
        set_render_status(project, status="done", pct=100, step="Done",
                          file=f"export/{out_path.name}", name=name, size=size,
                          subs=opts.get("burnsubs", True), fast=bool(opts.get("fast")), error=None)
    except Exception as e:
        # a cancel kills ffmpeg -> render() raises; report that as "cancelled", not an error
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()               # drop the half-written file
            except OSError as _qe: quiet(_qe, "run_render_job")
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
        else:
            set_render_status(project, status="error", error=str(e))
    finally:
        with RENDER_LOCK:
            RENDER_PROCS.pop(project, None)


@app.route("/api/render/<project>", methods=["POST"])
def api_render_start(project):
    """Kick off the MP4 render (captions burned in, voice-over + music mixed)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if get_render_status(project).get("status") == "running":
        return jsonify({"error": "A render is already running for this project."}), 409
    d, _ = proj_dir(project)
    try:
        _build_timeline(project, doc)          # fail fast with a clear message
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    body = request.get_json(silent=True) or {}
    fast = bool(body.get("fast"))          # quick low-res test render (720p30, ultrafast) to check sync/timing
    music = body.get("music", True) is not False
    opts = {"kenburns": bool(body.get("kenburns")),
            "kenburns_video": bool(body.get("kenburns_video")),   # off by default: clips already move
            "music": music,
            "crossfade": music,          # cross-fade only matters when music is present
            "burnsubs": body.get("burnsubs", True) is not False,
            "onscreentext": body.get("onscreentext", True) is not False,
            "transitions": body.get("transitions", True) is not False,
            "outro_fade": float(body.get("outro_fade", OUTRO_FADE_SEC) or 0),   # closing dip-to-black
            "gpu": bool(body.get("gpu")),                 # encode with the GPU (NVENC) if available
            "low_priority": bool(body.get("low_priority")),  # run ffmpeg below-normal + fewer threads
            "fast": fast}
    # optional partial render: only encode [range_start, range_end] seconds of the timeline
    try:
        rs, re_ = body.get("range_start"), body.get("range_end")
        if rs is not None and re_ is not None and float(re_) > float(rs):
            opts["range"] = (float(rs), float(re_))
    except (TypeError, ValueError) as _qe:
        quiet(_qe, "api_render_start")
    name = _vsl_name(doc, project, "Test-Video" if fast else "Video", "mp4")
    out = d / "export" / ("render_test.mp4" if fast else "render.mp4")
    set_render_status(project, status="running", pct=0, step="Queued…", file=None, error=None)
    _KeyThread(target=run_render_job, args=(project, doc, out, name, opts), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/renders/<project>")
def api_list_renders(project):
    """List the timestamped render-history files (newest first)."""
    d, _ = proj_dir(project)
    out = []
    for sub, is_test in (("renders", False), ("test-renders", True)):
        hist = d / "export" / sub
        if not hist.exists():
            continue
        for p in hist.glob("*.mp4"):
            st = p.stat()
            out.append({"name": p.name, "file": f"export/{sub}/{p.name}",
                        "size": st.st_size, "mtime": st.st_mtime, "test": is_test})
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return jsonify({"renders": out})

@app.route("/api/renders/<project>/<name>/delete", methods=["POST"])
def api_delete_render(project, name):
    """Delete one render-history file (guarded to the project's renders/ + test-renders/ folders)."""
    d, _ = proj_dir(project)
    for sub in ("renders", "test-renders"):
        hist = (d / "export" / sub).resolve()
        p = (hist / name).resolve()
        if p.suffix == ".mp4" and p.parent == hist and p.exists():
            try:
                p.unlink()
            except OSError as _qe:
                quiet(_qe, "api_delete_render")
            break
    return jsonify({"ok": True})

@app.route("/api/reveal/<project>", methods=["POST"])
def api_reveal(project):
    """Open the folder containing a render (in Explorer, file selected). Local desktop use — the server
    runs on the same machine as the window. Guarded to files under the project's export/ folder."""
    d, _ = proj_dir(project)
    rel = (request.get_json(silent=True) or {}).get("file") or ""
    p = (d / rel).resolve()
    ok = False
    try:
        if d.resolve() in p.parents and p.exists():
            subprocess.Popen(["explorer", "/select,", str(p)])   # explorer returns 1 even on success — don't check
            ok = True
    except Exception as _qe:
        quiet(_qe, "api_reveal")
    return jsonify({"ok": ok})


@app.route("/api/render/<project>/cancel", methods=["POST"])
def api_render_cancel(project):
    """Stop an in-progress render: mark it cancelled and kill the ffmpeg process."""
    if get_render_status(project).get("status") != "running":
        return jsonify({"error": "No render is running for this project."}), 409
    with RENDER_LOCK:
        RENDER_CANCEL.add(project)
        proc = RENDER_PROCS.get(project)
    if proc and proc.poll() is None:
        try:
            proc.terminate()                     # ends ffmpeg -> the render thread finishes as "cancelled"
        except Exception as _qe:
            quiet(_qe, "api_render_cancel")
    set_render_status(project, step="Cancelling…")
    return jsonify({"ok": True})


def get_render_status(project):
    with RENDER_LOCK:
        return dict(RENDER_STATUS.get(project) or {"status": "idle"})


@app.route("/api/render/<project>")
def api_render_status(project):
    return jsonify(get_render_status(project))

# ================= STUDIO: project-independent + per-project image workshop =================
# Scope: "_global" (used with NO project open) or a project name. Data is fully isolated per scope:
# global work never shows inside a project and vice-versa. Reuses the same Kie image pipeline as scenes.
STUDIO_JOBS = {}
_STUDIO_JLOCK = threading.Lock()


def _scope_parts(scope):
    """A scope may carry a sub-store after "::" - e.g. "CitruSlim::thumb". A project name can never
    contain a colon (proj_dir strips it), so the separator can never collide with a real project."""
    base, _, sub = str(scope or "").partition("::")
    return base, re.sub(r"[^a-z0-9_-]", "", sub.lower())[:20]


def _studio_scope_project(scope):
    base, _ = _scope_parts(scope)
    return None if (not base or base == "_global") else base

def _studio_dir(scope):
    project = _studio_scope_project(scope)
    if project:
        d, _ = proj_dir(project)
        base = d / "studio"
    else:
        base = PROJECTS.parent / "studio"       # the active user's global studio (sibling of projects/)
    _, sub = _scope_parts(scope)
    if sub:
        base = base / sub                        # Thumbnail is the same workshop with its own gallery
    (base / "refs").mkdir(parents=True, exist_ok=True)
    return base

def _studio_items(scope):
    p = _studio_dir(scope) / "studio.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8")).get("items", [])
        except Exception as _qe:
            quiet(_qe, "_studio_items")
    return []

def _studio_write(scope, items):
    (_studio_dir(scope) / "studio.json").write_text(json.dumps({"items": items}, ensure_ascii=False), encoding="utf-8")

def _studio_pub(base, rel):
    """Upload a local studio ref to Cloudinary -> public URL for i2i. None on failure."""
    try:
        fp = (base / rel).resolve()
        if not str(fp).startswith(str(base.resolve())) or not fp.exists():
            return None
        return cloudinary_upload(fp, f"studio/{fp.stem}")
    except Exception:
        return None

def _studio_worker(job_id, scope, tasks):
    base = _studio_dir(scope)
    job = STUDIO_JOBS[job_id]
    for t in tasks:
        if job.get("cancel"):
            break
        try:
            refs = []
            for rel in (t.get("inputs") or []):
                u = _studio_pub(base, rel)
                if u:
                    refs.append(u)
            rel, err = _run_char_candidate(base, job_id[3:11], t["prompt"], refs, prefix="studio",
                                           family=t.get("model") or IMAGE_MODEL, aspect=t.get("aspect", "16:9"),
                                           resolution=t.get("resolution", "2K"),
                                           cancel_check=lambda: job.get("cancel"))
        except Exception as e:
            rel, err = None, str(e)
        with _STUDIO_JLOCK:
            if rel:
                item = {"id": hashlib.md5(rel.encode()).hexdigest()[:10], "kind": t.get("kind", "gen"),
                        "prompt": (t.get("label") or t["prompt"])[:400], "file": rel,
                        "aspect": t.get("aspect", "16:9"), "ts": time.time()}
                if t.get("kind") != "mockup":       # mockups are CANDIDATES -> only reach the gallery when the user approves one
                    items = _studio_items(scope); items.insert(0, item); _studio_write(scope, items)
                job["items"].append(item)
            else:
                job["errors"].append(err or "failed")
            job["done"] += 1
    with _STUDIO_JLOCK:
        job["status"] = "cancelled" if job.get("cancel") else "done"

def _studio_start(scope, tasks, kind):
    job_id = "sj_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    STUDIO_JOBS[job_id] = {"status": "running", "total": len(tasks), "done": 0, "items": [], "errors": [], "kind": kind, "ts": time.time()}
    _KeyThread(target=_studio_worker, args=(job_id, scope, tasks), daemon=True).start()
    return job_id

def _studio_video_worker(job_id, scope, task):
    base = _studio_dir(scope); job = STUDIO_JOBS[job_id]
    try:
        if job.get("cancel"):
            raise RuntimeError("cancelled")
        inputs = task.get("inputs") or [task.get("input")]
        img_urls = [u for u in (_studio_pub(base, it) for it in inputs if it) if u]
        if not img_urls:
            raise RuntimeError("input image upload failed (check Cloudinary keys / quota)")
        api, mid, payload = build_video_request(task["model"], img_urls, task.get("prompt", ""),
                                                task["duration"], task["resolution"])
        tid, cerr = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
        if not tid:
            raise RuntimeError(cerr or "could not start the video")
        url = None
        for _ in range(210):                     # poll up to ~7 minutes
            if job.get("cancel"):
                raise RuntimeError("cancelled")
            time.sleep(2)
            try:
                rec = kie_veo_record(tid) if api == "veo" else kie_record(tid)
            except Exception:
                rec = {}
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec); break
            if state == "fail":
                raise RuntimeError((rec.get("data") or {}).get("failMsg", "video generation failed"))
        if not url:
            raise RuntimeError("video generation timed out")
        (base / "refs").mkdir(parents=True, exist_ok=True)
        fname = f"studio_vid_{job_id[3:11]}_{int(time.time() * 1000)}.mp4"
        download_as_mp4(url, base / "refs" / fname)
        rel = f"refs/{fname}"
        with _STUDIO_JLOCK:
            item = {"id": hashlib.md5(rel.encode()).hexdigest()[:10], "kind": "video",
                    "prompt": task.get("label") or "Image to Video", "file": rel,
                    "aspect": "16:9", "ts": time.time()}
            items = _studio_items(scope); items.insert(0, item); _studio_write(scope, items)
            job["items"].append(item); job["done"] = 1; job["status"] = "done"
    except Exception as e:
        with _STUDIO_JLOCK:
            job["done"] = 1
            if str(e) == "cancelled":
                job["status"] = "cancelled"
            else:
                job["errors"].append(str(e)); job["status"] = "done"

def _studio_start_video(scope, task):
    job_id = "sj_" + hashlib.md5(f"{scope}v{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    STUDIO_JOBS[job_id] = {"status": "running", "total": 1, "done": 0, "items": [], "errors": [], "kind": "video", "ts": time.time()}
    _KeyThread(target=_studio_video_worker, args=(job_id, scope, task), daemon=True).start()
    return job_id

def _studio_safe(name):
    return re.sub(r"[^A-Za-z0-9._-]", "_", (name or "img"))[:48]

@app.route("/api/studio/upload/<scope>", methods=["POST"])
def api_studio_upload(scope):
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "no file"}), 400
    base = _studio_dir(scope)
    ext = (Path(f.filename).suffix or ".png").lower()
    fname = f"in_{int(time.time() * 1000)}_{_studio_safe(Path(f.filename).stem)}{ext}"
    f.save(base / "refs" / fname)
    return jsonify({"ref": f"refs/{fname}"})

@app.route("/api/studio/generate", methods=["POST"])
def api_studio_generate():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    prompt = (b.get("prompt") or "").strip()
    inputs = [r for r in (b.get("inputs") or []) if r]
    if not prompt and not inputs:
        return jsonify({"error": "write a prompt or add an image"}), 400
    need = ("kie", "cloud") if inputs else ("kie",)
    err = _keys_ok(need)
    if err:
        return err
    aspect = b.get("aspect") or "16:9"
    resolution = "4K" if b.get("quality") == "4K" else "2K"
    mode = b.get("mode") or ("i2i" if inputs else "text")
    model = b.get("model") if b.get("model") in IMAGE_MODEL_KEYS else IMAGE_MODEL
    if mode == "edit":
        model = "nano-banana-2"                          # edit = NanoBanana edit (cheap, ref-based)
    n = max(1, min(int(b.get("count") or 1), 8))         # optional N variations of the same prompt
    p = prompt or "Recreate and refine the attached reference image faithfully."
    if _scope_parts(scope)[1] == "thumb":          # the Thumbnail tab: brief the model for a thumbnail
        aspect = "16:9"
        p = _THUMB_PREAMBLE % _THUMB_SIDE.get(b.get("textpos"), "LEFT THIRD") + p
        # ...in the channel's own look. Without this a 2D channel got a photograph on the front of it.
        _tstyle = _doc_scene_style(load_doc(_scope_parts(scope)[0]) or {})
        if _tstyle and STYLE_PRESETS.get(_tstyle):
            p += "\n\n" + STYLE_PRESETS[_tstyle]
    if inputs:
        p += ("\nUse the attached reference image(s) faithfully: combine / place / edit them exactly as described, "
              "keeping the objects, screens, labels and text they show accurate.")
    tasks = [{"prompt": p, "label": prompt or "(from image)", "inputs": inputs, "aspect": aspect,
              "model": model, "resolution": resolution, "kind": "gen"} for _ in range(n)]
    return jsonify({"job": _studio_start(scope, tasks, "gen")})

# A thumbnail is not just an image at 16:9. It is looked at 200px wide in a crowded feed, so it needs one
# subject, one idea, brutal contrast and empty space where the text will go. The model is told all of that
# instead of the user having to remember it every time.
_THUMB_PREAMBLE = (
    "YOUTUBE THUMBNAIL. It will be judged at 210 by 118 pixels in a crowded feed, so: ONE subject filling a "
    "large part of the frame, one single idea, and nothing small or fiddly anywhere. Very high contrast "
    "between the subject and the background, strong saturated colour, clean simple background with no "
    "clutter. If a person is shown, they face the camera with one clear, readable emotion. "
    "Leave the %s of the frame visually calm and uncluttered - large text will be placed there afterwards. "
    "Put NOTHING in the bottom-right corner (the duration badge sits there). "
    "Absolutely NO lettering, words, numbers, captions, logos or watermarks anywhere in the image.\n\n"
    "THE SHOT: ")
_THUMB_SIDE = {"left": "LEFT THIRD", "right": "RIGHT THIRD", "bottom": "BOTTOM THIRD",
               "center": "MIDDLE BAND"}
# Only faces we can actually EMBED. Naming one the browser does not have would fall back to Impact
# without a word, and the thumbnail would come out in a face nobody chose.
_THUMB_FONTS = ("Poppins", "Geomini", "Google Sans", "Inter", "Montserrat", "Open Sans",
                "Roboto", "Noto Serif", "Flatshoes")


# A thumbnail is not decorated after the fact - it is argued from the same material as the video. Both
# of these read the project itself (title, idea, the script's own opening, the channel brief, the target
# viewer) so the suggestion belongs to THIS episode, not to thumbnails in general.
_TI_SHOT = """You are the art director on a channel, deciding the single still that will sell one episode.

Describe ONE image. Not a montage, not a concept, not a poster - one single frame.

Never name a medium: no 'photo', no 'photograph', no 'cartoon', no 'illustration', no 'render'. The
channel's look is applied separately and is not yours to choose. Describe only what is in the frame.

WHAT MAKES IT WORK, and you are being judged on all five:
- ONE subject, filling a lot of the frame. A thumbnail is looked at two centimetres wide.
- ONE readable emotion or ONE readable action. If you cannot name it in a word, it is too complicated.
- It comes from the EPISODE. Something a viewer who watched it would recognise; not a stock metaphor.
- Brutal contrast: the subject must separate from its background at a glance.
- Room to breathe on one side or along the bottom, because large text goes there afterwards.

Write it as a plain shot description: the subject, what they are doing, where they are, the light, what
is behind them. Two or three sentences. Concrete nouns, no adjectives doing the work of a noun.

Do NOT mention: text, words, letters, numbers, logos, captions, arrows, borders, collages, split screens,
'thumbnail', 'YouTube', camera brands, or lens jargon. Return ONLY the description - no preamble, no
quotation marks, no title, no explanation."""

_TI_TEXT = """You write the words that go ON a thumbnail - the two to five that make someone stop.

RULES:
- Two to five words. Five is already long.
- It is NOT the title. The title is above the thumbnail already; repeating it wastes the picture. Say the
  part the title cannot: the surprise, the number, the cost, the thing they had wrong.
- Plain spoken words, the ones the viewer would use. No jargon, no brand names, no hashtags.
- No punctuation except a question mark when the line is genuinely a question. Never ALL CAPS in your
  answer - the app sets the case itself.
- Say something TRUE about this episode. A tease the video does not pay off is the fastest way to lose
  a channel.

Return ONLY the words. No quotation marks, no alternatives, no explanation."""


def _thumb_context(project):
    """What the suggestion has to be true to: this episode, and the channel it belongs to."""
    doc = load_doc(project) or {}
    so = doc.get("script_opts") or {}
    script = (doc.get("script") or doc.get("script_draft") or "").strip()
    parts = []
    if so.get("title") or doc.get("title"):
        parts.append("EPISODE TITLE: %s" % (so.get("title") or doc.get("title")))
    if so.get("idea"):
        parts.append("WHAT IT IS ABOUT:\n%s" % " ".join(so["idea"].split())[:1200])
    if doc.get("brief"):
        parts.append("THE CHANNEL:\n%s" % " ".join(doc["brief"].split())[:700])
    aud = _gs_audience(project).strip()
    if aud:
        parts.append(aud)
    if script:
        # the opening carries the hook and the closing carries the payoff; the middle is the argument
        head = " ".join(script.split()[:320])
        tail = " ".join(script.split()[-120:])
        parts.append("HOW IT OPENS:\n%s" % head)
        if len(script.split()) > 500:
            parts.append("HOW IT ENDS:\n%s" % tail)
    if not parts:
        return ""
    return "\n\n".join(parts)


_PUBMETA_SYSTEM = """You write the description and the tags for a YouTube video. You are given the
channel, the audience, the episode's title and its script.

THE DESCRIPTION
- Open with 2-3 sentences that make someone who is still hovering press play. Say what happens in the
  video and what they get out of it. No "in this video we will", no "hey guys", no filler.
- Then 2-4 short paragraphs of real substance from the script: the specific facts, names, dates,
  numbers and turns the episode actually contains. Somebody reading only this should learn something.
- YouTube reads the first 150 characters hardest, and so does the viewer - put the strongest wording
  and the main search phrase there, in a sentence a person would actually write.
- Work the natural search phrases in where they belong. Never a keyword list, never repetition, never
  a phrase that a reader would notice as SEO.
- CHAPTERS: only when you are told the video is long enough to need them. When you are, give 4-8 lines,
  each "M:SS " and a short label, starting at 0:00, following the script's real turning points and
  spread across the runtime you are given. NEVER write a time at or past the end of the video, and
  never invent a runtime - if you were not told one, write no chapters at all.
- Close with one line inviting a comment about something specific in the episode.
- Plain text. Emoji only as small section markers, sparingly. No markdown, no asterisks, no headings
  in caps unless the language calls for it.

THE TAGS
- 12-18 of them, comma separated, lower case.
- Ordered: the exact title phrase first, then the specific subject (people, places, events, objects
  named in the script), then the broad category, then the channel's own name.
- Every tag has to be something a person would really type into the search box. No spam, no
  single letters, no repeats, nothing that is not in the video.

Reply with JSON only: {"description": "...", "tags": "tag one, tag two, ..."}"""


CHAPTERS_MIN_SEC = 480          # under eight minutes, chapters are clutter rather than navigation


def _strip_bad_chapters(desc, secs):
    """Drop any chapter line the video cannot support: a time at or past the end, or the whole block
    on a video too short to want one. Asking nicely in a prompt is not the same as knowing."""
    lines = desc.split(chr(10))
    ch = re.compile(r"^\s*(?:(\d+):)?(\d{1,2}):(\d{2})\s+\S")

    def at(m):
        return (int(m.group(1) or 0) * 3600) + int(m.group(2)) * 60 + int(m.group(3))

    hits = [(i, at(m)) for i, l in enumerate(lines) for m in [ch.match(l)] if m]
    if not hits:
        return desc
    if not secs or secs < CHAPTERS_MIN_SEC:
        drop = {i for i, _ in hits}                    # too short to carry chapters at all
    else:
        drop = {i for i, t in hits if t >= secs - 1}   # a chapter that starts after the video ends
        if len(hits) - len(drop) < 3:
            drop = {i for i, _ in hits}                # under three left - YouTube shows none anyway
    if not drop:
        return desc
    kept, out = [l for i, l in enumerate(lines) if i not in drop], []
    for l in kept:                                    # removing a block leaves a hole; close it up
        if not l.strip() and out and not out[-1].strip():
            continue
        out.append(l)
    while out and not out[-1].strip():
        out.pop()
    return chr(10).join(out).strip()


def _channel_sign_off(doc):
    """The contact block that goes under every description, from Settings -> Channel Links."""
    ch = doc.get("channel") or {}
    rows = []
    if ch.get("mail"):
        rows.append("\U0001F4E7 Business enquiries: %s" % ch["mail"])
    if ch.get("social"):
        rows.append("\U0001F4F1 Follow: %s" % ch["social"])
    if ch.get("site"):
        rows.append("\U0001F310 Website: %s" % ch["site"])
    if not rows:
        return ""
    return "\n".join(rows)


@app.route("/api/publish/<project>/meta", methods=["POST"])
def api_publish_meta(project):
    """Write the description and the tags from what this episode actually is: the channel, who watches
    it, the title, and the script. The contact links from Settings are appended verbatim - they are the
    user's own details and no model should be inventing or rewording them."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    b = request.get_json(silent=True) or {}
    want = b.get("want") if b.get("want") in ("description", "tags") else None   # None = both
    ctx = _thumb_context(project)
    ch = doc.get("channel") or {}
    p = _pub_get(doc)
    title = (b.get("title") or p.get("title") or "").strip()
    if not (ctx or title):
        return jsonify({"error": "write the script (or at least the title) first"}), 400
    # The real runtime, from the assembled timeline - the voice-over decides it. Summing a 'dur' field
    # off the scenes gave 0 (no such field exists), so the prompt was told nothing and the model
    # cheerfully wrote chapters out to 7:30 for a 1:52 video.
    secs = 0.0
    try:
        secs = float(_build_timeline(project, doc).get('total') or 0)
    except Exception:
        secs = 0.0
    user = ""
    if ch.get("name"):
        user += "CHANNEL NAME: %s\n\n" % ch["name"]
    if title:
        user += "EPISODE TITLE: %s\n\n" % title
    if secs:
        user += ("RUNTIME: %d:%02d (%.0f seconds). Never write a chapter time at or past this.\n\n"
                 % (int(secs // 60), int(secs % 60), secs))
    # Chapters are for a video somebody would actually skip around in. On a short one they are clutter:
    # they push the lines that sell the video below the fold, and nobody uses them.
    if secs and secs < CHAPTERS_MIN_SEC:
        user += ("This video is only %d:%02d long. Do NOT write chapters - no timecodes anywhere.\n\n"
                 % (int(secs // 60), int(secs % 60)))
    elif not secs:
        user += "The runtime is unknown, so do NOT write chapters.\n\n"
    user += ctx
    lang = _doc_lang_name(doc) if "_doc_lang_name" in globals() else ""
    if lang:
        user += "\n\nWrite it in %s - the language the video is in." % lang
    try:
        out = _ask_json(_PUBMETA_SYSTEM, user,
                        want=lambda d: bool(str(d.get("description") or "").strip()) and bool(str(d.get("tags") or "").strip()))
    except Exception as e:
        return jsonify({"error": "could not write it: %s" % str(e)[:160]}), 502
    desc = _strip_bad_chapters(str(out.get("description") or "").strip(), secs)
    tags = str(out.get("tags") or "").strip()
    sign = _channel_sign_off(doc)
    if sign and desc:
        desc = desc.rstrip() + "\n\n" + sign
    res = {"ok": True}
    if want in (None, "description"):
        res["description"] = desc
    if want in (None, "tags"):
        res["tags"] = tags
    return jsonify(res)


@app.route("/api/studio/thumbstate/<path:scope>", methods=["GET", "POST"])
def api_thumb_state(scope):
    """The thumbnail bench's own memory: which picture is open, the words on it, and where and how they
    sit. Leaving the tab and coming back should show the thumbnail you were working on, not an empty
    frame - and the placement is worth keeping because it is the part you fiddle with."""
    p = _studio_dir(scope) / "thumb_state.json"
    if request.method == "POST":
        b = request.get_json(force=True) or {}
        keep = {k: b.get(k) for k in ("ref", "baked", "baked_sig", "text", "prompt", "st", "img", "x", "y",
                                      "width", "font", "size", "color", "outline", "ow", "oc", "align") if k in b}
        cur = {}
        if p.exists():
            try:
                cur = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                cur = {}
        cur.update(keep)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(cur, ensure_ascii=False), encoding="utf-8")
        return jsonify({"ok": True})
    d = {}
    if p.exists():
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            d = {}
    for k in ("ref", "baked"):          # either picture may have been deleted from the gallery meanwhile
        if d.get(k) and not (_studio_dir(scope) / d[k]).exists():
            d.pop(k, None)
    d["fonts"] = list(_THUMB_FONTS)     # the faces the plate renderer can actually draw
    return jsonify(d)


@app.route("/api/studio/thumbidea", methods=["POST"])
def api_studio_thumbidea():
    """Suggest the shot, or the words, for this episode's thumbnail. Pressing again must give something
    genuinely different, so everything already offered is sent back and ruled out by name."""
    b = request.get_json(silent=True) or {}
    project = (b.get("project") or "").strip()
    kind = "text" if b.get("kind") == "text" else "shot"
    ctx = _thumb_context(project) if project else ""
    if not ctx:
        return jsonify({"error": "there is nothing to work from yet - give the project a title, an idea "
                                 "or a script first"}), 400
    avoid = [str(x).strip() for x in (b.get("avoid") or []) if str(x).strip()][-8:]
    user = ctx
    if kind == "text":
        user += "\n\nWrite the words for the thumbnail."
    else:
        user += "\n\nDescribe the photograph for the thumbnail."
        side = {"left": "the LEFT third", "right": "the RIGHT third", "bottom": "the BOTTOM third",
                "center": "the MIDDLE"}.get(b.get("textpos"), "the LEFT third")
        user += " Leave %s of the frame calm - the text goes there." % side
        if (b.get("text") or "").strip():
            user += "\nThe words that will sit on it: %s" % " ".join(b["text"].split())[:120]
    if avoid:
        user += ("\n\nYou have already suggested these. Do not repeat them, do not reword them, and do "
                 "not take the same angle again - go somewhere else in the episode:\n"
                 + "\n".join("- " + " ".join(a.split())[:300] for a in avoid))
    try:
        out = _claude_text(_TI_TEXT if kind == "text" else _TI_SHOT, user,
                           max_tokens=700 if kind == "shot" else 120, model="opus")
    except Exception as e:
        return jsonify({"error": "could not reach Claude: %s" % str(e)[:160]}), 502
    txt = " ".join((out or "").strip().split())
    txt = txt.strip('"\u201c\u201d\'')
    if not txt:
        return jsonify({"error": "nothing came back - try again"}), 502
    if kind == "text":
        txt = " ".join(txt.split()[:6])
    return jsonify({"ok": True, "text": txt[:900]})


def _thumb_img_css(g):
    """The CSS that frames the picture inside the plate.

    MIRRORS thImgCss() in app.js - percentages rather than pixels, so the bench preview, the full-screen
    editor and this 1280-wide plate all frame the shot identically. A value outside the sane range is
    dropped rather than trusted, because it arrives from the browser.
    """
    if not isinstance(g, dict):
        return ""
    try:
        z = max(1.0, min(4.0, float(g.get("zoom") or 1)))
        lim = (z - 1) * 50.0
        ox = max(-lim, min(lim, float(g.get("ox") or 0)))
        oy = max(-lim, min(lim, float(g.get("oy") or 0)))
    except (TypeError, ValueError):
        return ""
    if z == 1.0 and ox == 0.0 and oy == 0.0:
        return ""
    return ";transform:translate(%.3f%%,%.3f%%) scale(%.4f);transform-origin:center" % (ox, oy, z)


@app.route("/api/studio/thumbtext", methods=["POST"])
def api_studio_thumbtext():
    """Put the headline on a finished thumbnail. The text is composited by us at 1280x720 rather than asked
    of the image model, because image models garble lettering - and this way it stays crisp and re-editable."""
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    ref = (b.get("ref") or "").strip()
    text = (b.get("text") or "").strip()
    if not ref:
        return jsonify({"error": "generate or pick an image first"}), 400
    if not text:
        return jsonify({"error": "write the thumbnail text first"}), 400
    base = _studio_dir(scope)
    src = (base / ref).resolve()
    try:
        src.relative_to(base.resolve())
    except Exception:
        return jsonify({"error": "bad image path"}), 400
    if not src.exists():
        return jsonify({"error": "that image is not there any more"}), 400

    pos = b.get("pos") if b.get("pos") in ("left", "right", "bottom") else "left"
    color = b.get("color") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(b.get("color") or "")) else "#ffffff"
    ocol = b.get("oc") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(b.get("oc") or "")) else "#000000"
    stroke = ocol if b.get("outline", True) else "transparent"
    words = [w for w in text.split() if w]

    def _f(v, d):
        try:
            return float(v)
        except (TypeError, ValueError):
            return d

    # a thumbnail headline is 2-5 words; the fewer there are the bigger they go - unless a size was set
    size = int(_f(b.get("size"), 0)) or (
        200 if len(words) <= 2 else 165 if len(words) == 3 else 135 if len(words) <= 5 else 108)
    size = max(28, min(320, size))
    fam = str(b.get("font") or "Poppins")[:60]
    if fam not in _THUMB_FONTS:
        fam = "Poppins"
    align = b.get("align") if b.get("align") in ("left", "center", "right") else None
    # x/y are the text block's CENTRE as a fraction of the frame - that is what dragging produces. The
    # three named positions stay as the starting points, and as the fallback for an older saved state.
    if b.get("x") is not None and b.get("y") is not None:
        x, y = max(0.0, min(1.0, _f(b.get("x"), .5))), max(0.0, min(1.0, _f(b.get("y"), .5)))
        al = align or ("center" if 0.34 < x < 0.66 else ("left" if x <= 0.34 else "right"))
        # The block hangs off its own centre, so its width has to stop at the nearer edge or the words get
        # guillotined by the frame. `width` is the one the user dragged on the preview; without it, a
        # sensible default. THIS RULE IS MIRRORED IN app.js (thHalfOf) - change both or the workshop lies.
        edge = max(0.06, min(x, 1.0 - x) - 0.02)
        w = _f(b.get("width"), 0)
        half = min(edge, max(0.06, w / 2.0)) if w > 0 else min(edge, max(0.15, min(0.33, min(x - 0.04, 0.96 - x))))
        box = ("left:%.4f%%;top:%.4f%%;transform:translate(-50%%,-50%%);width:%.3f%%;text-align:%s"
               % (x * 100, y * 100, half * 200, al))
    else:
        box = {"left": "left:5.5%;right:52%;top:50%;transform:translateY(-50%);text-align:left",
               "right": "right:5.5%;left:52%;top:50%;transform:translateY(-50%);text-align:right",
               "bottom": "left:5.5%;right:5.5%;bottom:6%;text-align:center"}[pos]
    import html as _html
    try:
        import caption_layer as _cl
        faces = _cl._font_face_css(Path(__file__).parent / "static" / "fonts",
                                   families=[(b.get("st") or {}).get("ost_font") or fam])
    except Exception:
        _cl, faces = None, ""

    st = b.get("st") if isinstance(b.get("st"), dict) else None
    if st and _cl:
        # THE THUMBNAIL HEADLINE IS A CAPTION. Same style vocabulary (ost_*), same two CSS builders the
        # burnt-in subtitles use - so the bench, the video captions and this plate cannot drift apart.
        # Authored on a 1920 stage like everything else, then the whole text layer is scaled to the
        # 1280-wide plate, which keeps the PNG small enough for YouTube's 2 MB limit.
        st = {k: v for k, v in st.items() if isinstance(k, str) and k.startswith(("ost_", "sub_"))}
        if st.get("ost_font") not in _THUMB_FONTS:
            st["ost_font"] = "Poppins"
        k = 1280.0 / 1920.0
        al = st.get("ost_align") if st.get("ost_align") in ("left", "center", "right") else "center"
        # _inner_css / _outer_css always centre (a subtitle does); a headline can sit left or right, and
        # it can be tilted. Both are appended here and mirrored by thAlignBlock() in app.js.
        inner = _cl._inner_css(st, "caption") + ";text-align:%s" % al
        outer = _cl._outer_css({"kind": "caption", "place": st.get("ost_place") or "center",
                                "x": st.get("ost_x"), "y": st.get("ost_y"),
                                "rotation": st.get("ost_rotation"),
                                "sub_width": st.get("sub_width", 70)}) + ";text-align:%s" % al
        html = ("<style>%s</style>" % faces
                + "<div style=\"position:fixed;inset:0;overflow:hidden;background:#000\">"
                "<img src=\"%s\" style=\"position:absolute;inset:0;width:100%%;height:100%%;object-fit:cover%s\">"
                "<div style=\"position:absolute;left:0;top:0;width:1920px;height:1080px;"
                "transform:scale(%.6f);transform-origin:top left\">"
                "<div style=\"%s\"><span style=\"%s\">%s</span></div></div></div>"
                % (src.resolve().as_uri(), _thumb_img_css(b.get("img")), k, outer, inner,
                   _html.escape(text).replace("\n", "<br>")))
    else:
        html = ("<style>%s</style>" % faces
                + "<div style=\"position:fixed;inset:0;overflow:hidden\">"
                "<img src=\"%s\" style=\"position:absolute;inset:0;width:100%%;height:100%%;object-fit:cover%s\">"
                "<div style=\"position:absolute;%s;font:900 %dpx/1.0 '%s',Impact,'Arial Black',sans-serif;"
                "color:%s;-webkit-text-stroke:%dpx %s;paint-order:stroke fill;letter-spacing:-.02em;"
                "text-transform:uppercase;text-shadow:0 8px 30px rgba(0,0,0,.45)\">%s</div></div>"
                % (src.resolve().as_uri(), _thumb_img_css(b.get("img")), box, size, fam, color,
                   max(0, min(40, int(_f(b.get("ow"), 0)))) or max(6, size // 14), stroke,
                   _html.escape(text).replace("\n", "<br>")))
    out = base / ("thumb_%d.png" % int(time.time() * 1000))
    ok, err = _render_html_png(html, out, 1280, 720, scale=1)
    if not ok:
        return jsonify({"error": "could not draw the text: %s" % (err or "render failed")}), 502
    rel = out.name
    item = {"id": hashlib.md5(rel.encode()).hexdigest()[:10], "kind": "gen",
            "prompt": "thumbnail text: " + text[:120], "file": rel, "aspect": "16:9", "ts": time.time()}
    items = _studio_items(scope)
    items.insert(0, item)
    _studio_write(scope, items)
    return jsonify({"ok": True, "item": item})


@app.route("/api/studio/mockup", methods=["POST"])
def api_studio_mockup():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    product = (b.get("product") or "").strip()
    if not product:
        return jsonify({"error": "upload a product image first"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    count = max(1, min(int(b.get("count") or 5), 20))
    aspect = b.get("aspect") or "1:1"
    resolution = "4K" if b.get("quality") == "4K" else "2K"
    model = b.get("model") if b.get("model") in IMAGE_MODEL_KEYS else IMAGE_MODEL
    tasks = []
    aoff = os.urandom(1)[0] % len(MOCKUP_ANGLES)      # rotate the angle pairing each generation -> fresh combos on regenerate
    for i in range(count):
        setting = MOCKUP_SETTINGS[i % len(MOCKUP_SETTINGS)]
        angle = MOCKUP_ANGLES[(i + aoff) % len(MOCKUP_ANGLES)]   # each shot gets its OWN distinct camera/composition
        p = (f"A realistic product photo of the EXACT product shown in the attached reference image. "
             f"SETTING: {setting}. CAMERA & COMPOSITION: {angle}. "
             "This shot must be CLEARLY DIFFERENT from every other mockup — its own environment, its own camera "
             "angle and its own composition; vary the framing and lighting, never a repeat of a plain front-on view. "
             "Reproduce the product's label, wording, colours, shape and number of units EXACTLY as in the reference "
             "(do NOT redesign, rename or restyle it). Natural real-world lighting and a believable size; a clean, "
             "appealing, authentic photo. No added text, captions or watermarks.")
        tasks.append({"prompt": p, "label": f"Mockup: {setting}", "inputs": [product], "aspect": aspect,
                      "model": model, "resolution": resolution, "kind": "mockup"})
    return jsonify({"job": _studio_start(scope, tasks, "mockup")})

@app.route("/api/studio/edit", methods=["POST"])
def api_studio_edit():
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    ref = (b.get("ref") or "").strip()
    instr = (b.get("instruction") or "").strip()
    if not ref or not instr:
        return jsonify({"error": "need an image and an instruction"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    if looks_turkish(instr):
        try: instr = translate_to_english(instr)
        except Exception as _qe: quiet(_qe, "api_studio_edit")
    aspect = b.get("aspect") or "16:9"
    tasks = [{"prompt": instr, "label": instr[:120], "inputs": [ref], "aspect": aspect, "kind": "edit"}]
    return jsonify({"job": _studio_start(scope, tasks, "edit")})

@app.route("/api/studio/video", methods=["POST"])
def api_studio_video():
    """Image to Video — turn one uploaded image into a short clip (Seedance / Veo / Grok)."""
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    inp = (b.get("input") or "").strip()
    if not inp:
        return jsonify({"error": "upload an image first"}), 400
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    mkey = b.get("model") if b.get("model") in VIDEO_MODEL_BY_KEY else DEFAULT_VIDEO_MODEL
    cfg = VIDEO_MODEL_BY_KEY[mkey]
    try:
        dur = int(b.get("duration"))
    except Exception:
        dur = cfg["defaultDur"]
    res = b.get("quality") or cfg["defaultRes"]
    prompt = (b.get("prompt") or "").strip()
    # camera lock (default ON, same as the Videos tab): spell out a static locked-off camera unless the user
    # freed it or already described camera movement, so the model doesn't drift/zoom on its own.
    if b.get("cam_lock", True) and not _mentions_camera(prompt):
        prompt += (" " if prompt else "") + "The camera stays completely still (locked-off tripod): no camera movement, no zoom, no pan, no push-in."
    inputs = [str(x).strip() for x in (b.get("inputs") or []) if str(x).strip()] or [inp]
    task = {"input": inp, "inputs": inputs, "prompt": prompt, "label": prompt[:120] or "Image to Video",
            "model": mkey, "duration": dur, "resolution": res}
    return jsonify({"job": _studio_start_video(scope, task)})

@app.route("/api/studio/job/<jid>")
def api_studio_job(jid):
    j = STUDIO_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _STUDIO_JLOCK:
        return jsonify({"status": j["status"], "total": j["total"], "done": j["done"],
                        "items": list(j["items"]), "errors": list(j["errors"]), "kind": j["kind"]})

@app.route("/api/studio/cancel/<jid>", methods=["POST"])
def api_studio_cancel(jid):
    """Stop a running Studio job — the worker breaks out of its loop before the next candidate."""
    j = STUDIO_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _STUDIO_JLOCK:
        j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/studio/save/<scope>", methods=["POST"])
def api_studio_save(scope):
    """Approve a candidate (e.g. a mockup) into the gallery — insert it at the front of the index."""
    item = (request.get_json(force=True) or {}).get("item")
    if not isinstance(item, dict) or not item.get("id") or not item.get("file"):
        return jsonify({"error": "bad item"}), 400
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        if not any(it.get("id") == item["id"] for it in items):
            items.insert(0, item); _studio_write(scope, items)
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/gallery/<scope>")
def api_studio_gallery(scope):
    return jsonify({"items": _studio_items(scope)})

@app.route("/api/studio/fav/<scope>", methods=["POST"])
def api_studio_fav(scope):
    """Toggle a gallery item's favourite (Approve = ★) flag; persisted in the index."""
    b = request.get_json(force=True) or {}
    iid = b.get("id"); fav = bool(b.get("fav"))
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        hit = next((it for it in items if it.get("id") == iid), None)
        if not hit:
            return jsonify({"error": "not found"}), 404
        hit["fav"] = fav
        _studio_write(scope, items)
    return jsonify({"ok": True, "fav": fav})

@app.route("/api/studio/delete/<scope>", methods=["POST"])
def api_studio_delete(scope):
    # Remove only from the index — KEEP the file on disk so an Undo can restore it (see /api/studio/restore).
    sid = (request.get_json(force=True) or {}).get("id")
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        _studio_write(scope, [it for it in items if it.get("id") != sid])
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/restore/<scope>", methods=["POST"])
def api_studio_restore(scope):
    """Undo a gallery delete: re-insert a previously-removed item at a given position (its file was kept)."""
    b = request.get_json(force=True) or {}
    item = b.get("item"); at = b.get("at")
    if not isinstance(item, dict) or not item.get("id"):
        return jsonify({"error": "bad item"}), 400
    with _STUDIO_JLOCK:
        items = _studio_items(scope)
        if not any(it.get("id") == item["id"] for it in items):   # avoid a dup if it's somehow still there
            idx = at if isinstance(at, int) and 0 <= at <= len(items) else 0
            items.insert(idx, item)
            _studio_write(scope, items)
    return jsonify({"ok": True, "items": _studio_items(scope)})

@app.route("/api/studio/to-new-scene", methods=["POST"])
def api_studio_to_new_scene():
    """Append a NEW blank scene (empty vo/prompt) to ANY target project, with its image set to a studio
    image. Source comes from the current studio SCOPE; destination is the chosen project."""
    b = request.get_json(force=True) or {}
    scope = b.get("scope") or "_global"
    ref = (b.get("ref") or "").strip()
    project = (b.get("project") or "").strip()
    if not project:
        return jsonify({"error": "no project chosen"}), 400
    base = _studio_dir(scope)
    src = (base / ref).resolve()
    if not str(src).startswith(str(base.resolve())) or not src.exists():
        return jsonify({"error": "image not found"}), 400
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            return jsonify({"error": "project not found"}), 404
        scenes = doc.setdefault("scenes", [])
        sc = new_scene(len(scenes) + 1)
        d, _ = proj_dir(project)
        (d / "images").mkdir(parents=True, exist_ok=True)
        dest_rel = f"images/sc_{sc['uid']}_studio{int(time.time() * 1000)}.png"
        shutil.copyfile(src, d / dest_rel)
        img = sc.setdefault("image", {})
        img["versions"] = [dest_rel]
        img["version_models"] = [sc.get("model") or IMAGE_MODEL]
        img["current"] = 0
        img["status"] = "ready"
        scenes.append(sc)
        for i, s in enumerate(scenes, 1):
            s["id"] = i
        norm_scene(sc)
        save_doc(project, doc)
        return jsonify({"ok": True, "sceneId": len(scenes), "title": doc.get("title") or project})

# -------- FAQ: white-bg, centred, VO-synced captions with red keywords (Studio-scoped) --------
FAQ_JOBS = {}
FAQ_RENDER_JOBS = {}
_FAQ_LOCK = threading.Lock()

def _probe_dur(path):
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                              "-of", "default=nw=1:nk=1", str(path)],
                             capture_output=True, text=True, creationflags=_NO_WINDOW, timeout=30).stdout.strip()
        return float(out)
    except Exception:
        return 0.0

def _faq_word_core(seg):
    """The click-key for a token: lowercased, edge punctuation stripped (keep % $ £ € and internal - so
    'non-GMO'/'180-day'/'100%' stay one unit). Mirrors the client faqWordCore EXACTLY."""
    s = (seg or "").lower()
    s = re.sub(r"^[^a-z0-9%$£€]+", "", s)
    s = re.sub(r"[^a-z0-9%$£€]+$", "", s)
    return s

def _faq_highlight(text, kws, reds=None, blacks=None):
    """Server mirror of the client faqHighlight — WORD-LEVEL so it honours the user's manual clicks:
    a word is red if it's a manual red, or covered by an auto keyword phrase and NOT a manual black.
    Wraps red words in <span class='faq-kw'>. `reds`/`blacks` are lowercased word cores."""
    import html as _h
    text = text or ""
    text = re.sub(r"(\d)\s+([%‰°€$£])", "\\1\u00A0\\2", text)   # keep "100 %" (number + unit) on ONE line (nbsp)
    reds = set(reds or []); blacks = set(blacks or [])
    ks = sorted([str(k) for k in (kws or []) if k and str(k).strip()], key=lambda s: -len(s))
    cover = [False] * len(text)
    for k in ks:   # mark each keyword INDEPENDENTLY so overlapping phrases (e.g. "96,400 men and women"
        for m in re.finditer(re.escape(k), text, flags=re.I):   # vs "over 96,400 men") both fully colour
            for i in range(m.start(), m.end()):
                cover[i] = True
    out = []
    for m in re.finditer(r"\s+|\S+", text):
        seg = m.group(0)
        if not seg.strip():
            out.append(_h.escape(seg)); continue
        c = _faq_word_core(seg)
        if not c:
            red = False
        elif c in blacks:
            red = False
        elif c in reds:
            red = True
        else:
            red = any(cover[i] for i in range(m.start(), m.end()))
        out.append(('<span class="faq-kw">' + _h.escape(seg) + "</span>") if red else _h.escape(seg))
    return "".join(out)

_FAQ_NUTRIENTS = [
    "vitamin a", "vitamin b", "vitamin b3", "vitamin b6", "vitamin b12", "vitamin c", "vitamin d", "vitamin d3",
    "vitamin e", "vitamin k", "magnesium", "zinc", "calcium", "iron", "potassium", "selenium", "chromium", "iodine",
    "copper", "manganese", "phosphorus", "omega-3", "omega 3", "folate", "folic acid", "biotin", "collagen",
    "probiotics", "prebiotics", "caffeine", "l-carnitine", "green tea extract", "green tea", "cayenne", "capsaicin",
    "garcinia", "garcinia cambogia", "glucomannan", "chromium picolinate", "ashwagandha", "berberine", "resveratrol",
    "coenzyme q10", "coq10", "turmeric", "curcumin", "guarana", "chlorogenic acid", "ketones", "electrolytes",
]
_FAQ_KW_PATTERNS = [
    r"[£$€]\s?\d[\d.,]*",                                              # money / prices
    r"\b\d+%(?:\s+[a-z]+){0,2}",                                       # 100% natural formula (up to 2 following words)
    r"\brisk[- ]free\b",
    r"\b(?:money[- ]back|satisfaction|lifetime|100%\s+satisfaction)\s+guarantee\b",
    r"\b\d+[- ]day(?:\s+money[- ]back\s+guarantee)?\b",
    r"\b\d+[- ]day supply\b",
    r"\bcompletely free\b", r"\bfree shipping\b", r"\bfree delivery\b",
    # packs / supply — ANY unit (bottle / month / day / week), any count word
    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve)[- ](?:bottle|month|day|week)\s+(?:pack|packs|package|packages|supply|bundle)\b",
    r"\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve)[- ](?:bottle|month|day|week)\b",
    # certifications / dietary claims
    r"\bISO\s?\d{3,}\b", r"\bEcocert(?:\s+standards)?\b", r"\bGMP(?:[- ]certified)?\b", r"\bFDA[- ]approved\b",
    r"\bnon[- ]?GMO\b", r"\bplant[- ]based\b", r"\bdairy[- ]free\b", r"\bgluten[- ]free\b", r"\bsugar[- ]free\b",
    r"\bsoy[- ]free\b", r"\bcruelty[- ]free\b", r"\bvegan\b",
    # calls-to-action / punchy answers
    r"\b(?:order now|order today|try it today|get started(?:\s+today)?|claim your[a-z ]{0,20}|buy now|act now|don'?t wait|add to cart)\b",
    r"\bclick (?:below|here|the (?:button|link)(?:\s+below)?)\b", r"\btap (?:below|here)\b",
    r"\b(?:get|grab|reserve|secure|order) your[a-z ]{0,20}\b", r"\bselect your (?:package|plan|pack)\b",
    r"\babsolutely\s+(?:yes|not)\b",
    # science: receptors / mechanisms
    r"\bbeta-?\d+\s+receptors?\b", r"\b[a-z]*thermogenesis\b", r"\b\w+(?:genesis|lysis)\b", r"\bmetabolism\b",
    # punchy weight-loss topic phrases
    r"\bstubborn\s+(?:body\s+)?(?:belly\s+fat|body\s+weight|body\s+fat|fat|weight)\b",
    # impressive statistics WITH their noun (53,000 men and women / over 10,000 customers / 2 stone lost)
    r"\b\d[\d,\.]*\+?\s+(?:men and women|men|women|people|customers|clients|users|adults|patients|reviews|"
    r"happy customers|five[- ]star reviews|countries|pounds|lbs|kg|kilos|stone)\b",
    r"\b(?:over|more than|nearly|up to|almost|around)\s+[\d,\.]+(?:\s+[a-z]+){0,2}\b",
]

# connectives / filler that must NEVER be red-bold on their own, and are trimmed from phrase edges
_FAQ_STOP = {"is", "and", "or", "but", "so", "yet", "nor", "for", "if", "of", "the", "a", "an", "to", "our",
             "your", "with", "that", "this", "it", "are", "you", "we", "in", "on", "at", "as", "by", "be",
             "then", "than", "when", "while", "because", "also", "however", "therefore", "from", "into",
             "very", "just", "really", "actually", "course", "am", "was", "were", "will", "can", "do", "does"}

# capitalised words that are NOT proper nouns — never treat a mid-sentence one of these as a location/brand
_FAQ_PN_SKIP = {"The", "This", "That", "These", "Those", "Our", "Your", "You", "We", "They", "It", "He",
                "She", "And", "But", "Or", "So", "If", "When", "While", "Then", "Now", "Here", "There",
                "Also", "However", "Yes", "No", "Not", "Why", "How", "What", "Who", "Whom", "Which",
                "Because", "Since", "After", "Before", "For", "With", "Without", "Every", "Each", "All",
                "Some", "Most", "Many", "More", "Less", "Just", "Only", "Even", "Still", "Well", "Once"}

def _faq_trim_kw(s):
    parts = (s or "").split()
    while parts and parts[0].lower().strip(".,!?;:\"'()") in _FAQ_STOP:
        parts.pop(0)
    while parts and parts[-1].lower().strip(".,!?;:\"'()") in _FAQ_STOP:
        parts.pop()
    return " ".join(parts).strip()

def _faq_clean_kws(kws):
    """Trim connective words off phrase edges, drop pure conjunctions/filler and 1-char tokens, dedup —
    applied to the FULL union (LLM + rules + project) so 'and'/'or'/'of course' never go red."""
    seen, out = set(), []
    for k in kws:
        k = _faq_trim_kw(str(k or ""))
        kl = k.lower()
        if not kl or len(kl) < 2 or kl in _FAQ_STOP or kl in seen:
            continue
        seen.add(kl); out.append(k)
    return out

# The patterns above are English. Everything the user asks to see in red — the CTA, the guarantee, the
# pack size, the time window — is written differently in every other language, so an English-only net
# caught none of it on a German or French script and the highlighting fell back to whatever the LLM
# happened to return. One block per language, same categories.
_FAQ_KW_LANG = {
    "de": [
        # guarantees — German builds these as one compound and as an ADJECTIVE ("180-tägigen"), which a
        # "180-Tage" pattern never sees. Checked against a real script before writing these.
        r"\b\d+[- ]?täg\w+\s+(?:[A-ZÄÖÜ][\wäöüß-]*\s+){0,2}?(?:Geld[- ]zurück[- ]Garantie|Zufriedenheitsgarantie|Garantie)\b",
        r"\bGeld[- ]zurück[- ]Garantie\b", r"\bZufriedenheitsgarantie\b", r"\b\d+[- ]?täg\w+\b",
        r"\b(?:ohne|kein)\s+Risiko\b", r"\brisikofrei\b", r"\b(?:volle|vollständige)\s+Rückerstattung\b",
        r"\bkostenlos(?:e[rnms]?)?\b", r"\bGratis[a-zäöüß]*\b", r"\bgratis\b",
        r"\bkostenlose[rn]?\s+(?:Versand|Lieferung)\b",
        # packs — including the "3- oder 6-Monats-Paket" form, which the user wants highlighted WHOLE
        r"\b\d+[-–]?\s*(?:oder|und|bis)\s*\d+[- ]?(?:Monats|Flaschen|Wochen|Tages)[- ]?"
        r"(?:Paket|Pakete|Packung|Packungen|Vorrat|Bundle)\b",
        r"\b(?:\d+|zwei|drei|vier|fünf|sechs|zehn|zwölf)[- ](?:Flaschen|Monats|Wochen|Tages)[- ]?"
        r"(?:Paket|Pakete|Packung|Packungen|Vorrat|Bundle)\b",
        r"\b(?:\d+|zwei|drei|vier|fünf|sechs|zehn|zwölf)[- ](?:Flaschen|Monate|Monaten|Wochen)\b",
        r"\bjetzt (?:bestellen|sichern|starten|zugreifen|kaufen)\b", r"\bhier klicken\b",
        r"\bKlicken Sie(?:\s+einfach)?(?:\s+(?:auf|hier|unten))?\b", r"\bsichern Sie sich\b",
        r"\b(?:nicht|nicht länger) warten\b", r"\bWarten Sie nicht\b", r"\bBestellen Sie\b",
        r"\babsolut (?:ja|sicher|kein)\b", r"\bin den Warenkorb\b",
        r"\b(?:ohne|keine?|garantiert kein)\s+(?:Abo|Abonnement|Abonnements|Nachlieferungen|"
        r"versteckten? Kosten|Zusatzkosten|Verpflichtung)\b",
        r"\bEinmalzahlung\b", r"\beinmalige Zahlung\b",
        r"\bklinisch (?:geprüft|belegt|erwiesen|getestet)\b",
        r"\b(?:zu\s+)?100\s?%\s?natürlich[a-zäöüß]*(?:\s+Formel)?\b",
        r"\b\d+[- ]?(?:Werktage|Werktagen|Tagen|Tage|Wochen|Monaten|Monate)\b",
        r"\b(?:über|mehr als|fast|bis zu|rund)\s+[\d.,]+(?:\s+[A-Za-zÄÖÜäöüß]+){0,2}",
    ],
    "fr": [
        r"\bgarantie (?:de )?\d+[- ]jours?\b", r"\bgarantie satisfait ou remboursé\b",
        r"\bsatisfait ou remboursé\b", r"\bsans risque\b", r"\bremboursement (?:intégral|total)\b",
        r"\b(?:\d+|deux|trois|quatre|cinq|six|dix|douze)[- ](?:flacons?|mois|semaines?)\b",
        r"\b(?:lot|pack|coffret) de (?:\d+|deux|trois|quatre|cinq|six|dix|douze)\b",
        r"\bcommandez (?:maintenant|aujourd'hui)\b", r"\bcliquez (?:ci-dessous|ici)\b",
        r"\bn'attendez plus\b", r"\bprofitez[- ]en\b", r"\bréservez (?:votre|le vôtre)\b",
        r"\blivraison (?:gratuite|offerte)\b", r"\bgratuit(?:e|s|es)?\b", r"\bpaiement unique\b",
        r"\bsans (?:abonnement|frais cachés|engagement)\b", r"\bcliniquement (?:prouvé|testé)\b",
        r"\b100\s?%\s?naturel(?:le)?\b", r"\b\d+\s+(?:jours?|semaines?|mois)\s+ouvrés?\b",
        r"\b(?:plus de|près de|jusqu'à|environ)\s+[\d ,.]+(?:\s+[a-zà-ÿ]+){0,2}",
    ],
    "es": [
        r"\bgarantía de \d+ días\b", r"\bgarantía de devolución(?: del dinero)?\b", r"\bsin riesgo\b",
        r"\breembolso (?:completo|total)\b", r"\bpaquete de (?:\d+|dos|tres|cuatro|cinco|seis|diez|doce)\b",
        r"\b(?:\d+|dos|tres|cuatro|cinco|seis|diez|doce)\s+(?:frascos?|botellas?|meses?|semanas?)\b",
        r"\bpide (?:ahora|hoy)\b", r"\bhaz clic (?:aquí|abajo)\b", r"\bno esperes\b",
        r"\benvío gratis\b", r"\bgratis\b", r"\bpago único\b", r"\bsin suscripción\b",
        r"\bclínicamente (?:probado|comprobado)\b", r"\b100\s?%\s?natural\b",
        r"\b(?:más de|casi|hasta|cerca de)\s+[\d.,]+(?:\s+[a-zá-ú]+){0,2}",
    ],
    "it": [
        r"\bgaranzia di \d+ giorni\b", r"\bsoddisfatti o rimborsati\b", r"\bsenza rischi\b",
        r"\brimborso (?:completo|totale)\b",
        r"\b(?:\d+|due|tre|quattro|cinque|sei|dieci|dodici)\s+(?:flaconi?|bottiglie?|mesi?|settimane?)\b",
        r"\bordina (?:ora|oggi)\b", r"\bclicca (?:qui|sotto)\b", r"\bnon aspettare\b",
        r"\bspedizione gratuita\b", r"\bgratis\b", r"\bpagamento unico\b", r"\bsenza abbonamento\b",
        r"\bclinicamente (?:testato|provato)\b", r"\b100\s?%\s?naturale\b",
        r"\b(?:oltre|quasi|fino a|circa)\s+[\d.,]+(?:\s+[a-zà-ù]+){0,2}",
    ],
    "pt": [
        r"\bgarantia de \d+ dias\b", r"\bgarantia de devolução(?: do dinheiro)?\b", r"\bsem risco\b",
        r"\breembolso (?:integral|total)\b",
        r"\b(?:\d+|dois|três|quatro|cinco|seis|dez|doze)\s+(?:frascos?|garrafas?|meses?|semanas?)\b",
        r"\bpeça (?:agora|hoje)\b", r"\bclique (?:aqui|abaixo)\b", r"\bnão espere\b",
        r"\bfrete grátis\b", r"\bgrátis\b", r"\bpagamento único\b", r"\bsem assinatura\b",
        r"\bclinicamente (?:comprovado|testado)\b", r"\b100\s?%\s?natural\b",
        r"\b(?:mais de|quase|até|cerca de)\s+[\d.,]+(?:\s+[a-zá-ú]+){0,2}",
    ],
    "nl": [
        r"\b\d+[- ]dagen[- ](?:niet[- ]goed[- ])?geld[- ]terug[- ]garantie\b", r"\bgeld[- ]terug[- ]garantie\b",
        r"\bzonder risico\b", r"\bvolledige terugbetaling\b",
        r"\b(?:\d+|twee|drie|vier|vijf|zes|tien|twaalf)[- ](?:flessen|maanden|weken)\b",
        r"\bbestel (?:nu|vandaag)\b", r"\bklik (?:hier|hieronder)\b", r"\bwacht niet\b",
        r"\bgratis verzending\b", r"\bgratis\b", r"\beenmalige betaling\b", r"\bgeen abonnement\b",
        r"\bklinisch (?:bewezen|getest)\b", r"\b100\s?%\s?natuurlijk\b",
        r"\b(?:meer dan|bijna|tot|ongeveer)\s+[\d.,]+(?:\s+[a-zà-ÿ]+){0,2}",
    ],
}
# Languages that capitalise ordinary nouns. There, a Title-Case word says nothing about being a name —
# German turned "Zweifel", "Antworten", "Fragen", "Sport" into "proper nouns" and painted half the caption
# red. CamelCase and ALLCAPS still mean something (CitruSlim, ISO), so those stay on.
_FAQ_CAPS_NOUNS = {"de", "lb"}


def _faq_deterministic_kw(text, lang="en"):
    """Rule-based keyword extraction so highlighting is ROBUST regardless of the LLM: offers/guarantees,
    packs (any unit), %/prices, certifications/dietary claims, CTAs, vitamins/minerals/elements/nutrients,
    science terms, and proper nouns (Title-Case runs / CamelCase / ALLCAPS). `lang` picks the phrase
    patterns and decides whether Title-Case is evidence of a name at all."""
    T = text or ""
    lang = (lang or "en").strip().lower()[:2]
    kws = []
    # the English list stays on for every language: VSL scripts carry English offer and brand terms
    # mid-sentence (ISO 9001, non-GMO, Ecocert, CitruSlim), and money/percent patterns are universal
    for p in _FAQ_KW_PATTERNS + _FAQ_KW_LANG.get(lang, []):
        for m in re.finditer(p, T, flags=re.I):
            kws.append(m.group(0))
    low = T.lower()
    for n in _FAQ_NUTRIENTS:
        i = low.find(n)
        if i >= 0:
            kws.append(T[i:i + len(n)])                                # verbatim slice (preserve casing)
    if lang not in _FAQ_CAPS_NOUNS:            # see _FAQ_CAPS_NOUNS — in German this is not evidence of a name
        for m in re.finditer(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", T):  # proper-noun runs: Royal Mail, New York
            kws.append(m.group(1))
        # single-word proper nouns (Sicily, Sweden, Amazon) — a Title-Case word that is NOT at the sentence
        # start (so we don't flag every sentence's first word) and is not a common capitalised function word
        for m in re.finditer(r"[A-Za-z][A-Za-z'’\-]*", T):
            w = m.group(0)
            if not re.match(r"^[A-Z][a-z]{2,}$", w) or w in _FAQ_PN_SKIP:
                continue
            j = m.start() - 1
            while j >= 0 and T[j] in " \t\r\n\"'(“‘":
                j -= 1
            if j < 0 or T[j] in ".!?:;":   # sentence-initial → skip (could just be a capitalised first word)
                continue
            kws.append(w)
    for w in T.split():
        c = w.strip(".,!?;:\"'()[]{}…")                               # trim ENDS only (keep internal, so 'non-GMO' stays)
        if re.search(r"[a-z][A-Z]", c) or re.match(r"^[A-Z]{3,}$", c): # CamelCase / ALLCAPS (CitruSlim, ISO)
            kws.append(c)
    return _faq_clean_kws(kws)

def _faq_bg_segments(cues, n_imgs, target=12.0):
    """Assign a background image index to each ~target-second block, switching only on a sentence (cue) START,
    cycling through the images and looping. Returns [(start_time, img_index), …] (mirrors the client)."""
    segs = []; idx = 0; last = -1e9
    for i, c in enumerate(cues):
        st = float(c["start"])
        if i == 0 or (st - last) >= target:
            segs.append((st, idx % max(1, n_imgs))); idx += 1; last = st
    return segs

def _faq_bg_filter(wd, images, cues, total_dur, W, H, fps, start_idx):
    """Build the rotating mockup-background as filter graph parts to be INLINED into the main FAQ render (so
    there is only ONE final RGB->YUV conversion — an intermediate .mp4 double-encode was washing the colours /
    stealing saturation). Each still is cover-scaled and given a slow, jitter-free (2x-supersampled) zoom, with
    2s crossfades on the sentence starts, looping to fill total_dur — all kept in planar RGB (gbrp, full range).
    Returns (input_args, filter_parts, n_images) where the images are inputs start_idx..start_idx+n-1 and the
    graph outputs [bgv]; or None on any problem (caller falls back to a solid colour)."""
    if not images:
        return None
    _rel = lambda p: os.path.relpath(str(p), str(wd))
    segs = _faq_bg_segments(cues, len(images))
    if not segs:
        return None
    starts = [s for s, _ in segs] + [total_dur]
    XF = 2.0
    inp, filt, clip_lens = [], [], []
    SS = 2                                         # supersample: zoompan on a 2x canvas -> sub-pixel pan -> no jitter
    W2, H2 = W * SS, H * SS
    for i, (st, imi) in enumerate(segs):
        seg_dur = max(XF + 0.6, starts[i + 1] - starts[i])
        clip_len = seg_dur + (XF if i < len(segs) - 1 else 0.0)
        clip_lens.append(clip_len)
        fp = wd / images[imi]
        inp += ["-i", _rel(fp)]                    # ONE still frame; zoompan (d=frames) sets the clip length
        frames = max(1, int(round(clip_len * fps)))
        gi = start_idx + i                         # this image's ffmpeg input index
        # supersampled (2x) jitter-free zoom; keep the whole chain in packed RGB (rgb24) so there is NO
        # intermediate chroma subsampling — the old yuv420p here + a second yuv420p at encode DOUBLE-subsampled
        # the photos, and the dark matte made that blockiness look like "low resolution". drawbox/overlay both
        # behave correctly on rgb24 (unlike gbrp, which drawbox desaturates).
        filt.append(
            f"[{gi}:v]scale={W2}:{H2}:force_original_aspect_ratio=increase,crop={W2}:{H2},"
            f"zoompan=z='min(1+0.08*on/{frames},1.08)':d={frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"s={W2}x{H2}:fps={fps},scale={W}:{H}:flags=bicubic,setsar=1,format=rgb24[c{i}]")
    if len(segs) == 1:
        last = "c0"
    else:
        combined = clip_lens[0]; prev = "c0"
        for i in range(1, len(segs)):
            offset = max(0.0, combined - XF)
            out = f"x{i}"
            filt.append(f"[{prev}][c{i}]xfade=transition=fade:duration={XF}:offset={offset:.3f}[{out}]")
            combined += clip_lens[i] - XF; prev = out
        last = prev
    filt.append(f"[{last}]trim=0:{total_dur:.3f},setpts=PTS-STARTPTS,format=rgb24[bgv]")
    return inp, filt, len(segs)

def _faq_render_worker(jid, scope, bg=True, bgcolor="0xffffff", hlcolor="#e5322d"):
    import caption_layer, html as _h
    j = FAQ_RENDER_JOBS[jid]; wd = _faq_dir(scope)
    try:
        auds = list(wd.glob("audio.*")); audio = auds[0] if auds else None
        if not audio:
            raise RuntimeError("no voice-over uploaded")
        state = {}
        if (wd / "faq.json").exists():
            try: state = json.loads((wd / "faq.json").read_text(encoding="utf-8"))
            except Exception: state = {}
        cues = state.get("cues") or (premiere_export.parse_srt((wd / "faq.srt").read_text(encoding="utf-8")) if (wd / "faq.srt").exists() else [])
        if not cues:
            raise RuntimeError("no captions yet — Analyze & Sync first")
        style = state.get("style") or {}
        # robust keywords: whatever was saved UNION the deterministic pass over the script (so even old
        # builds pick up ingredient/vitamin/element/offer/proper-noun terms without re-Analyzing)
        kws = _faq_clean_kws(list(state.get("keywords") or []) +
                             _faq_deterministic_kw(state.get("script") or " ".join(c.get("text", "") for c in cues)))
        reds = {_faq_word_core(w) for w in (state.get("red_words") or []) if w}
        blacks = {_faq_word_core(w) for w in (state.get("black_words") or []) if w}
        hl_on = state.get("hl_on", True)          # Highlight toggle OFF -> every caption word plain (no red/bold)
        gallery = [g for g in (state.get("gallery") or []) if g and g.get("active") is not False and g.get("file")]
        bg_opacity = state.get("bg_opacity", 100)
        try: bg_opacity = max(0, min(100, int(bg_opacity)))
        except Exception: bg_opacity = 100
        dur = _probe_dur(audio) or (max(float(c["end"]) for c in cues) + 0.5)
        fps, W, H = 30, 1920, 1080
        one = str(style.get("sub_lines") or "auto") == "1"
        _mk_html = (lambda txt: _faq_highlight(txt, kws, reds, blacks)) if hl_on else (lambda txt: _h.escape(txt))
        items = [{
            "html": _mk_html(c.get("text") or ""), "text": c.get("text") or "", "style": style, "kind": "caption",
            "place": style.get("ost_place") or "center", "x": style.get("ost_x", 0), "y": style.get("ost_y", 0),
            "rotation": style.get("ost_rotation", 0), "sub_width": style.get("sub_width", 86), "oneline": one,
            "anim": style.get("ost_anim", "fade"), "out_anim": style.get("ost_out_anim", "none"),
            "start": float(c["start"]), "end": float(c["end"]),
        } for c in cues]
        def prog(done, total):
            with _FAQ_LOCK: j["pct"] = int(done / max(1, total) * 80); j["step"] = f"Rendering captions… {done}/{total}"
        clips = caption_layer.build_clips(items, wd, fps, W, H, progress=prog, should_cancel=lambda: j.get("cancel"), hl_color=hlcolor)
        if j.get("cancel"):
            with _FAQ_LOCK: j["status"] = "cancelled"
            return
        with _FAQ_LOCK: j["step"] = "Encoding…"; j["pct"] = 88
        for _o in ("faq_video.mp4", "faq_video.mov"):      # clear BOTH so the video route serves the fresh one
            try: (wd / _o).unlink()
            except OSError as _qe: quiet(_qe, "_faq_render_worker")
        # RELATIVE paths + cwd=wd: a punchy FAQ can have hundreds of caption clips (one "-i" each); with absolute
        # paths the command line blows past the Windows ~32k limit -> WinError 206. Relative names keep it short.
        _rel = lambda p: os.path.relpath(str(p), str(wd))
        # mockup images sent to the FAQ become a rotating, slow-zooming, cross-faded BACKGROUND (bg ON / .mp4 only).
        # Built INLINE into this single render pass (planar RGB) so there is only ONE final RGB->YUV conversion —
        # the old intermediate .mp4 double-encoded and washed the photo colours / stole their saturation.
        bg_imgs = []
        if bg and gallery:
            bg_imgs = [(g["file"][4:] if g["file"].startswith("faq/") else g["file"]) for g in gallery]  # -> relative to wd
        bg_parts = _faq_bg_filter(wd, bg_imgs, cues, dur, W, H, fps, 0) if bg_imgs else None
        # bg ON -> flatten onto the colour (or the mockup montage), H.264 .mp4. bg OFF -> composite onto a
        # TRANSPARENT base and encode a ProRes 4444 .mov (real alpha) so Premiere drops the background.
        filt = []
        if not bg:
            out = wd / "faq_video.mov"; base_in = f"color=c=black:s={W}x{H}:r={fps}:d={dur:.3f}"
            inp = ["-f", "lavfi", "-i", base_in, "-i", _rel(audio)]
            filt.append("[0:v]format=rgba,colorchannelmixer=aa=0[base]")   # FORCE a fully TRANSPARENT base (alpha 0)
            last = "base"; audio_idx = 1; idx = 2
        elif bg_parts:
            with _FAQ_LOCK: j["step"] = "Building background…"
            bg_inp, bg_filt, _n = bg_parts       # images = inputs 0..n-1, audio = input n, caption clips = n+1..
            out = wd / "faq_video.mp4"
            inp = list(bg_inp) + ["-i", _rel(audio)]
            filt.extend(bg_filt)                  # -> [bgv]
            _aa = format(max(0, min(255, round(bg_opacity / 100.0 * 255))), "02x")   # matte alpha as RRGGBBAA hex
            # apply the matte in RGB, NOT yuv: blending toward black in YUV also pulls the chroma to neutral and
            # DESATURATES the photo (the "stolen colours" bug). In RGB it only darkens, keeping the colours vivid.
            filt.append(f"[bgv]format=rgb24,drawbox=x=0:y=0:w={W}:h={H}:color={bgcolor}{_aa}:t=fill[base]")
            last = "base"; audio_idx = _n; idx = _n + 1
        else:
            out = wd / "faq_video.mp4"; base_in = f"color=c={bgcolor}:s={W}x{H}:r={fps}:d={dur:.3f}"
            inp = ["-f", "lavfi", "-i", base_in, "-i", _rel(audio)]
            last = "0:v"; audio_idx = 1; idx = 2
        for cl in clips:
            if not cl:
                continue
            mov, s, e, x, y = cl
            inp += ["-i", _rel(mov)]
            # shift each animated clip so ITS t=0 (the fade/pop/slide start) lands at the cue start,
            # then gate visibility to [start,end] (mirrors render_video's caption compositing)
            filt.append(f"[{idx}:v]setpts=PTS-STARTPTS+{float(s):.4f}/TB[cc{idx}]")
            filt.append(f"[{last}][cc{idx}]overlay=x={int(x)}:y={int(y)}:eof_action=pass:enable='between(t,{float(s):.3f},{float(e):.3f})'[v{idx}]")
            last = f"v{idx}"; idx += 1
        cmd = ["ffmpeg", "-y", *inp]
        if filt:
            fscript = wd / "_faq_filter.txt"; fscript.write_text(";".join(filt), encoding="utf-8")
            cmd += ["-filter_complex_script", fscript.name, "-map", f"[{last}]"]
        else:
            cmd += ["-map", "0:v"]
        if bg:
            cmd += ["-map", f"{audio_idx}:a", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "veryfast",
                    "-c:a", "aac", "-b:a", "192k", "-shortest", out.name]
        else:
            cmd += ["-map", f"{audio_idx}:a", "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
                    "-c:a", "pcm_s16le", "-shortest", out.name]
        r = subprocess.run(cmd, cwd=str(wd), creationflags=_NO_WINDOW, capture_output=True, timeout=1800)
        if j.get("cancel"):
            with _FAQ_LOCK: j["status"] = "cancelled"
            return
        if r.returncode != 0 or not out.exists():
            (wd / "faq_render.log").write_bytes((r.stderr or b"")[-4000:])
            raise RuntimeError("ffmpeg failed — see faq_render.log")
        with _FAQ_LOCK: j["status"] = "done"; j["pct"] = 100; j["file"] = out.name
    except Exception as e:
        # keep the toast ENGLISH (raw Windows OS errors come localized, e.g. Turkish)
        msg = "ffmpeg failed — see faq_render.log" if "ffmpeg failed" in str(e) else (
            f"Render failed (system error {getattr(e, 'winerror', '') or ''}). Please try again." if isinstance(e, OSError)
            else f"Render failed: {str(e)[:160]}")
        with _FAQ_LOCK: j["status"] = "error"; j["error"] = msg

def _faq_render_start(scope, bg=True, bgcolor="0xffffff", hlcolor="#e5322d"):
    jid = "fr_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    FAQ_RENDER_JOBS[jid] = {"status": "running", "pct": 0, "step": "Starting…", "error": None, "file": None, "cancel": False}
    _KeyThread(target=_faq_render_worker, args=(jid, scope, bg, bgcolor, hlcolor), daemon=True).start()
    return jid

def _faq_dir(scope):
    base = _studio_dir(scope) / "faq"
    base.mkdir(parents=True, exist_ok=True)
    return base

@app.route("/api/faq/keywords", methods=["POST"])
def api_faq_keywords():
    b = request.get_json(force=True) or {}
    script = (b.get("script") or "").strip()
    scope = b.get("scope") or "_global"
    # The picked FAQ language, so the rule layer matches THIS language's offer/CTA/guarantee wording and
    # knows whether Title-Case means anything here. Without it every non-English script fell back to the
    # English patterns, which match nothing, plus a proper-noun guess that fires on every German noun.
    lang = (b.get("lang") or "").strip().lower()[:5] or "en"
    if not script:
        return jsonify({"error": "empty script"}), 400
    # The AI (Claude) pass is REQUIRED — the user does NOT want a degraded rules-only result. If Kie is
    # unreachable we FAIL LOUDLY (503) so the client shows an error toast and aborts, rather than saving
    # fragmented keywords. (The deterministic + project layers below only ADD coverage on top of the AI's
    # full phrases — they never fragment, so a whole ingredient like "lemon zest extract" stays whole.)
    err = _keys_ok(("kie",))
    if err:
        return err                                                   # no Kie key → 400 "add API keys"
    try:
        arr = _parse_json_array(_claude_text(FAQ_KEYWORD_SYSTEM, script, max_tokens=2000, model=PROMPT_MODEL, tries=10))
    except Exception as e:
        return jsonify({"error": "ai_unavailable", "detail": str(e)[:200]}), 503
    kws = [str(x).strip() for x in arr if str(x).strip()]
    if not kws:
        return jsonify({"error": "ai_unavailable", "detail": "empty AI result"}), 503
    # deterministic rules (offers/packs/%/certs/CTAs/nutrients/science/proper-nouns) — additive safety net
    kws += _faq_deterministic_kw(script, lang)
    # the project's ingredient / molecule / product names that appear in the script
    proj = _studio_scope_project(scope)
    if proj:
        doc = load_doc(proj) or {}
        extra = [(i.get("name") or "").strip() for i in (doc.get("ingredients") or [])]
        extra += [(doc.get("product") or {}).get("name", ""), doc.get("title", "")]
        low = script.lower()
        for n in extra:
            n = (n or "").strip()
            if n and n.lower() in low:
                kws.append(n)
    return jsonify({"keywords": _faq_clean_kws(kws)})

def _faq_align_pass(wd, audio, docx, out, model, job, lang="en"):
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out), VSL_LANG=lang)
    exe = _sys.executable
    si = None
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(c):
                exe = c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    args = [exe, str(SRT_SCRIPT), model, "--vad", "--faq"]   # FAQ = short, punchy, single-line captions
    with open(wd / "align.log", "a", encoding="utf-8") as log:
        p = subprocess.Popen(args, cwd=str(wd), env=env, stdout=log, stderr=subprocess.STDOUT, startupinfo=si)
        with _FAQ_LOCK: job["proc"] = p
        p.wait()
        with _FAQ_LOCK: job["proc"] = None
        return p.returncode

def _faq_transcribe_pass(wd, audio, out_txt, model, job, lang="en"):
    """Run the aligner in --transcribe mode → plain text of what the voice-over ACTUALLY says, into out_txt."""
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(wd / "script.docx"), VSL_OUT=str(out_txt), VSL_LANG=lang)
    exe = _sys.executable
    si = None
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            c = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(c): exe = c
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow = 0
    args = [exe, str(SRT_SCRIPT), model, "--vad", "--transcribe"]
    with open(wd / "align.log", "a", encoding="utf-8") as log:
        p = subprocess.Popen(args, cwd=str(wd), env=env, stdout=log, stderr=subprocess.STDOUT, startupinfo=si)
        with _FAQ_LOCK: job["proc"] = p
        p.wait()
        with _FAQ_LOCK: job["proc"] = None
    try: return out_txt.read_text(encoding="utf-8").strip() if out_txt.exists() else ""
    except Exception: return ""


def _faq_reconcile_script(script, transcription):
    """Have Claude rewrite the script to match the real voice-over. Returns '' on any problem (caller keeps
    the original script)."""
    if not (script and transcription):
        return ""
    try:
        out = _claude_text(FAQ_RECONCILE_SYSTEM,
                           f"SCRIPT:\n{script}\n\nVOICE-OVER TRANSCRIPTION (the truth):\n{transcription}",
                           max_tokens=8000)
        return (out or "").strip()
    except Exception:
        return ""

def _faq_worker(jid, scope, lang=None):
    j = FAQ_JOBS[jid]; wd = _faq_dir(scope)
    auds = list(wd.glob("audio.*")); audio = auds[0] if auds else None
    docx = wd / "script.docx"; out = wd / "faq.srt"
    proj = _studio_scope_project(scope)
    # the user's picked voice-over language wins; else fall back to the project's audience language, else English.
    lang = lang or (audience_lang((load_doc(proj) or {}).get("audience")) if proj else "en")
    try:
        # STEP 0 — reconcile the script to the ACTUAL voice-over first (the audio is the truth). Transcribe the
        # VO, let Claude correct the script to match what's really spoken, and re-write script.docx. This stops
        # extra / mismatched script text from derailing the alignment (the "sync breaks after N min" bug). All
        # best-effort: any failure leaves the user's script unchanged.
        if audio and not j.get("cancel"):
            try:
                with _FAQ_LOCK: j["step"] = "Reconciling script with the voice-over…"
                trans = _faq_transcribe_pass(wd, audio, wd / "_vo_transcript.txt", _align_models(lang)[0], j, lang)
                if trans and not j.get("cancel"):
                    import docx as _docxlib
                    script_txt = " ".join(p.text for p in _docxlib.Document(str(docx)).paragraphs).strip()
                    corrected = _faq_reconcile_script(script_txt, trans)
                    _ok, _why = _reconcile_sane(script_txt, corrected) if corrected else (False, "")
                    if corrected and len(corrected) >= 20 and _ok:
                        text_to_docx(corrected, docx)
                        print("[faq] script reconciled to the voice-over", flush=True)
                    elif _why:
                        # same guard as the VSL path: a correction has to still BE the script. Without it a
                        # bad transcript rewrites the text and the captions come out saying something the
                        # user never wrote — R4 then happily verifies them against the rewritten script.
                        print("[faq] reconcile rejected — %s" % _why, flush=True)
                        with _FAQ_LOCK: j["note"] = "Script left unchanged — " + _why
            except Exception as _e:
                print(f"[faq] reconcile skipped: {_e}", flush=True)
        # One pass. This looped over both models so the second could patch the first's alignment
        # collapses — a Whisper workaround that MMS-FA made pointless (see run_subtitle_job).
        if not j.get("cancel"):
            with _FAQ_LOCK: j["step"] = "Syncing captions…"
            rc = _faq_align_pass(wd, audio, docx, out, _align_models(lang)[1], j, lang)
            if j.get("cancel"):
                with _FAQ_LOCK: j["status"] = "cancelled"
                return
            if rc != 0:
                with _FAQ_LOCK: j["status"] = "error"; j["error"] = f"sync failed (exit {rc}); see align.log"
                return
        else:
            with _FAQ_LOCK: j["status"] = "cancelled"
            return
        if not out.exists():
            with _FAQ_LOCK: j["status"] = "error"; j["error"] = "no captions were produced; see align.log"
            return
        cues = premiere_export.parse_srt(out.read_text(encoding="utf-8"))
        with _FAQ_LOCK: j["status"] = "done"; j["cues"] = cues; j["step"] = "Done"
    except Exception as e:
        with _FAQ_LOCK: j["status"] = "error"; j["error"] = str(e)

@app.route("/api/faq/build", methods=["POST"])
def api_faq_build():
    scope = request.form.get("scope") or "_global"
    script = (request.form.get("script") or "").strip()
    wd = _faq_dir(scope)
    audio = request.files.get("audio")
    if audio and audio.filename:
        for old in wd.glob("audio.*"):
            try: old.unlink()
            except OSError as _qe: quiet(_qe, "api_faq_build")
        audio.save(wd / ("audio" + (Path(audio.filename).suffix or ".mp3").lower()))
    if not list(wd.glob("audio.*")):
        return jsonify({"error": "upload a voice-over first"}), 400
    docx = request.files.get("docx")
    if script:
        text_to_docx(script, wd / "script.docx")
    elif docx and docx.filename:
        fn = docx.filename.lower()
        if fn.endswith(".txt"):
            text_to_docx(docx.read().decode("utf-8", "ignore"), wd / "script.docx")
        else:
            docx.save(wd / "script.docx")
    if not (wd / "script.docx").exists():
        return jsonify({"error": "add a script — type it or upload a file"}), 400
    lang = (request.form.get("lang") or "").strip().lower() or None   # user-picked voice-over language (aligner model)
    jid = "fq_" + hashlib.md5(f"{scope}{time.time()}".encode() + os.urandom(4)).hexdigest()[:12]
    FAQ_JOBS[jid] = {"status": "running", "step": "Starting…", "cues": [], "error": None, "cancel": False, "proc": None}
    _KeyThread(target=_faq_worker, args=(jid, scope, lang), daemon=True).start()
    return jsonify({"job": jid})

@app.route("/api/faq/job/<jid>")
def api_faq_job(jid):
    j = FAQ_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        return jsonify({"status": j["status"], "step": j.get("step"), "cues": j.get("cues", []),
                        "error": j.get("error"), "note": j.get("note")})

@app.route("/api/faq/cancel/<jid>", methods=["POST"])
def api_faq_cancel(jid):
    """Stop an in-progress FAQ caption sync (kills the alignment subprocess)."""
    j = FAQ_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        j["cancel"] = True
        p = j.get("proc")
    if p:
        try: p.terminate()
        except Exception as _qe: quiet(_qe, "api_faq_cancel")
    return jsonify({"ok": True})

@app.route("/api/faq/state/<scope>", methods=["GET", "POST"])
def api_faq_state(scope):
    """Persist/restore a scope's FAQ work (script, keywords, caption style, cues) so it survives leaving Studio."""
    wd = _faq_dir(scope); p = wd / "faq.json"
    if request.method == "POST":
        b = request.get_json(force=True) or {}
        keep = {k: b.get(k) for k in ("script", "keywords", "style", "cues", "red_words", "black_words", "bg_color", "hl_color", "hl_on", "bg_opacity") if k in b}
        # MERGE into the existing doc (never full-overwrite) so the gallery + anything managed by the dedicated
        # gallery endpoints is preserved across a routine caption/style save.
        cur = {}
        if p.exists():
            try: cur = json.loads(p.read_text(encoding="utf-8"))
            except Exception: cur = {}
        cur.update(keep)
        p.write_text(json.dumps(cur, ensure_ascii=False), encoding="utf-8")
        return jsonify({"ok": True})
    data = {}
    if p.exists():
        try: data = json.loads(p.read_text(encoding="utf-8"))
        except Exception: data = {}
    if not data.get("cues"):
        srt = wd / "faq.srt"
        if srt.exists():
            try: data["cues"] = premiere_export.parse_srt(srt.read_text(encoding="utf-8"))
            except Exception as _qe: quiet(_qe, "api_faq_state")
    data["hasAudio"] = bool(list(wd.glob("audio.*")))
    data["hasScript"] = (wd / "script.docx").exists()   # a voice-over / script was uploaded before -> remember it in the UI
    return jsonify(data)

def _faq_gallery_read(wd):
    p = wd / "faq.json"
    if p.exists():
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception as _qe: quiet(_qe, "_faq_gallery_read")
    return {}

def _faq_gallery_write(wd, data, gallery):
    data["gallery"] = gallery
    (wd / "faq.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

@app.route("/api/faq/gallery/<scope>", methods=["GET"])
def api_faq_gallery(scope):
    return jsonify({"gallery": _faq_gallery_read(_faq_dir(scope)).get("gallery") or []})

@app.route("/api/faq/gallery-add/<scope>", methods=["POST"])
def api_faq_gallery_add(scope):
    """Copy Studio images (paths relative to the studio dir, e.g. a mockup 'refs/mk_x.png') into the FAQ's
    own gallery folder and register them. Mockups sent from the Studio gallery land here as caption backgrounds."""
    b = request.get_json(force=True) or {}
    files = [str(f) for f in (b.get("items") or b.get("files") or []) if f]
    if not files:
        return jsonify({"error": "no images"}), 400
    sbase = _studio_dir(scope); wd = _faq_dir(scope); gdir = wd / "gallery"; gdir.mkdir(parents=True, exist_ok=True)
    data = _faq_gallery_read(wd); gallery = data.get("gallery") or []
    added = 0
    for rel in files:
        src = (sbase / rel).resolve()
        if not str(src).startswith(str(sbase.resolve())) or not src.exists():
            continue
        name = f"g_{hashlib.md5((rel + str(time.time())).encode()).hexdigest()[:10]}{src.suffix or '.png'}"
        try: shutil.copyfile(src, gdir / name)
        except Exception: continue
        gallery.append({"file": f"faq/gallery/{name}", "active": False}); added += 1   # arrives INACTIVE — user clicks "Add to FAQ" to use it as a background
    _faq_gallery_write(wd, data, gallery)
    return jsonify({"ok": True, "added": added, "gallery": gallery})

@app.route("/api/faq/gallery-update/<scope>", methods=["POST"])
def api_faq_gallery_update(scope):
    """Set the `active` flag on gallery items (Add to FAQ), or REMOVE / CLEAR them. `files` = list of gallery
    file paths; `op` in {active, inactive, remove, clear}."""
    b = request.get_json(force=True) or {}
    op = b.get("op") or "active"
    sel = set(b.get("files") or [])
    wd = _faq_dir(scope); data = _faq_gallery_read(wd); gallery = data.get("gallery") or []
    if op == "clear":
        for it in gallery:
            try: (_studio_dir(scope) / it.get("file", "")).unlink()
            except Exception as _qe: quiet(_qe, "api_faq_gallery_update")
        gallery = []
    elif op == "remove":
        keep = []
        for it in gallery:
            if it.get("file") in sel:
                try: (_studio_dir(scope) / it.get("file", "")).unlink()
                except Exception as _qe: quiet(_qe, "api_faq_gallery_update")
            else:
                keep.append(it)
        gallery = keep
    else:  # active / inactive
        want = (op == "active")
        for it in gallery:
            if it.get("file") in sel:
                it["active"] = want
    _faq_gallery_write(wd, data, gallery)
    return jsonify({"ok": True, "gallery": gallery})

@app.route("/api/faq/render/<scope>", methods=["POST"])
def api_faq_render(scope):
    """Render the FAQ preview: bg=true -> solid-colour .mp4 (bg_color); bg=false -> TRANSPARENT ProRes 4444 .mov."""
    b = request.get_json(silent=True) or {}
    bg = b.get("bg", True) is not False
    hexc = re.sub(r"[^0-9a-fA-F]", "", str(b.get("bg_color") or ""))[:6] or "ffffff"   # -> ffmpeg 0xRRGGBB
    hlx  = re.sub(r"[^0-9a-fA-F]", "", str(b.get("hl_color") or ""))[:6] or "e5322d"   # red-keyword colour (CSS #RRGGBB)
    return jsonify({"job": _faq_render_start(scope, bg, "0x" + hexc, "#" + hlx)})

@app.route("/api/faq/render-job/<jid>")
def api_faq_render_job(jid):
    j = FAQ_RENDER_JOBS.get(jid)
    if not j:
        return jsonify({"error": "unknown job"}), 404
    with _FAQ_LOCK:
        return jsonify({k: j.get(k) for k in ("status", "pct", "step", "error", "file")})

@app.route("/api/faq/render-cancel/<jid>", methods=["POST"])
def api_faq_render_cancel(jid):
    j = FAQ_RENDER_JOBS.get(jid)
    if j:
        with _FAQ_LOCK: j["cancel"] = True
    return jsonify({"ok": True})

@app.route("/api/faq/video/<scope>")
def api_faq_video(scope):
    d = _faq_dir(scope)
    mov, mp4 = d / "faq_video.mov", d / "faq_video.mp4"       # serve whichever the last render produced
    if mov.exists():
        return send_file(mov, mimetype="video/quicktime", as_attachment=True, download_name="faq.mov")
    if mp4.exists():
        return send_file(mp4, mimetype="video/mp4", as_attachment=True, download_name="faq.mp4")
    abort(404)

@app.route("/api/faq/audio/<scope>")
def api_faq_audio(scope):
    auds = list(_faq_dir(scope).glob("audio.*"))
    if not auds:
        abort(404)
    return send_file(auds[0])

@app.route("/api/studio/img/<scope>/<path:relpath>")
def api_studio_img(scope, relpath):
    base = _studio_dir(scope)
    fp = (base / relpath).resolve()
    if not str(fp).startswith(str(base.resolve())) or not fp.exists():
        abort(404)
    if request.args.get("dl"):
        return send_file(fp, as_attachment=True, download_name=request.args.get("dl"))
    return send_file(fp)

@app.route("/api/studio/download-zip/<scope>", methods=["POST"])
def api_studio_download_zip(scope):
    """Bundle the picked studio images (e.g. selected mockups) into ONE mockups.zip in the studio dir, then
    return its relative name so the client downloads it through the normal (desktop-friendly) image route."""
    import zipfile
    base = _studio_dir(scope); baser = str(base.resolve())
    rels = (request.get_json(silent=True) or {}).get("files") or []
    picks = []
    for rel in rels:
        fp = (base / str(rel)).resolve()
        if str(fp).startswith(baser) and fp.exists() and fp.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
            picks.append(fp)
    if not picks:
        return jsonify({"error": "nothing selected to download"}), 400
    zp = base / "mockups.zip"
    try: zp.unlink()
    except OSError as _qe: quiet(_qe, "api_studio_download_zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for i, fp in enumerate(picks, 1):
            z.write(fp, f"mockup_{i:02d}{fp.suffix.lower()}")
    return jsonify({"file": "mockups.zip", "count": len(picks)})

# An Auto Episode run outlives the window it was started from, but not the process. Anything still
# marked "running" when we boot died with the last one - relabel it now, before the first project
# is opened, so the app can offer to finish it instead of pretending it is still going.
_auto_mark_interrupted()

if __name__ == "__main__":
    print(f"KIE key: {'set' if _key('KIE_API_KEY') else 'MISSING'} | projects dir: {PROJECTS}")
    # Prefer port 80 (so the URL needs no ':port' → http://vsldashboard / http://localhost).
    # Fall back to 8000 if 80 is taken, so the dashboard always comes up.
    _port = int(os.environ.get("VSL_PORT", "80"))
    # Bind to 127.0.0.1 (this PC only) by default. Set VSL_HOST=0.0.0.0 to also serve it to other
    # machines on the network / over a Tailscale or tunnel connection. Only do that on a trusted
    # network or behind Tailscale — the dashboard has NO login and holds your API keys.
    _host = os.environ.get("VSL_HOST", "127.0.0.1")
    try:
        print(f"Serving on http://localhost:{_port}/  (http://vsldashboard/ after setup-vsldashboard.bat)")
        app.run(host=_host, port=_port, threaded=True, debug=False)
    except OSError:
        print("port 80 unavailable -- falling back to http://localhost:8000/")
        app.run(host=_host, port=8000, threaded=True, debug=False)
