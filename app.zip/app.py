"""
VSL Scene Dashboard — local control panel for the script -> prompt -> image -> video pipeline.

Everything is driven by one file per project: projects/<name>/scenes.json
Both this app and Claude Code read/write that file, so prompts authored in Claude Code
show up here instantly, and edits made here are visible to Claude Code.

Run:  python app.py    ->  http://localhost:8000
"""
import os, re, json, time, hashlib, io, threading, shutil, zipfile, subprocess, uuid
from urllib.parse import quote as _urlquote, unquote as _urlunquote, urlparse as _urlparse
from pathlib import Path
from datetime import datetime, timedelta
import requests
from PIL import Image
from flask import Flask, request, jsonify, send_file, abort, render_template, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import premiere_export
import render_video

# The dashboard runs windowless (pythonw), so every child process would otherwise pop up
# its own console — a black box flashing over the screen once per ffmpeg/ffprobe call.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

BASE = Path(__file__).resolve().parent
# All user-writable data (projects, keys, login, voices) lives under DATA_DIR. It defaults to BASE
# so a plain dev checkout is unchanged; the packaged desktop app sets VSL_DATA_DIR to its portable
# data/ folder so everything the user creates stays in one place next to the .exe.
DATA_DIR = Path(os.environ["VSL_DATA_DIR"]).resolve() if os.environ.get("VSL_DATA_DIR") else BASE
DATA_DIR.mkdir(parents=True, exist_ok=True)
ENV_PATH = (DATA_DIR / ".env") if os.environ.get("VSL_DATA_DIR") else (BASE.parent / ".env")   # API keys
PROJECTS = DATA_DIR / "projects"
PROJECTS.mkdir(exist_ok=True)
BGM_ROOT = BASE / "Background Music"      # app resource (read-only) — ships with the app, not data

# ---- config / secrets -------------------------------------------------------
def load_env():
    env = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env

def write_env(updates):
    """Update/insert KEY=VALUE lines in the .env, preserving every other line (comments, spacing,
    unrelated keys). Used by the in-app API-keys editor so a new user can plug in their own keys."""
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    seen, out = set(), []
    for line in lines:
        s = line.strip()
        if s and not s.startswith("#") and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in updates:
                out.append(f"{k}={updates[k]}"); seen.add(k); continue
        out.append(line)
    for k, v in updates.items():
        if k not in seen:
            out.append(f"{k}={v}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")

ENV = load_env()

# ---- local login (no internet / no domain needed) ---------------------------
# auth.json lives next to the app (part of the copied folder). The admin sets per-person
# credentials by editing it; passwords typed in plaintext are hashed on first load, so the
# file ends up storing only hashes. A random session secret is generated once and persisted
# so logins survive server restarts.
AUTH_PATH = DATA_DIR / "auth.json"

def _is_hashed(v):
    v = str(v)
    return v.startswith("pbkdf2:") or v.startswith("scrypt:") or v.startswith("argon2")

def load_auth():
    if AUTH_PATH.exists():
        try:
            data = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    else:
        data = {}
    users = data.get("users") or {}
    if not users:                                   # first run: seed a default admin/admin
        users = {"admin": "admin"}
        data["users"] = users
    changed = False
    # hash any plaintext passwords the admin typed by hand
    for u, p in list(users.items()):
        if not _is_hashed(p):
            users[u] = generate_password_hash(str(p))
            changed = True
    if not data.get("secret"):                      # persistent session secret
        data["secret"] = os.urandom(24).hex()
        changed = True
    if changed or not AUTH_PATH.exists():
        try:
            AUTH_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass
    return data

AUTH = load_auth()

def check_login(username, password):
    h = (AUTH.get("users") or {}).get((username or "").strip())
    if not h:
        return False
    try:
        return check_password_hash(h, password or "")
    except Exception:
        return False

KIE_KEY = ENV.get("KIE_API_KEY", "")
CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
ELEVEN_MODEL = "eleven_multilingual_v2"   # good multilingual quality; matches script language automatically
VOICES_PATH = DATA_DIR / "voices.json"    # frequently-used ElevenLabs voices (name -> voice_id); user-editable → data
OST_PRESETS_PATH = DATA_DIR / "ost_presets.json"   # saved on-screen-text style presets (shared across projects)

KIE_BASE = "https://api.kie.ai/api/v1/jobs"
IMAGE_MODEL = "nano-banana-2"
# selectable per-scene image model families (label shown in the UI dropdown). Each family
# auto-resolves to a text-to-image or image-to-image Kie model id depending on whether the
# scene has reference images — see build_kie_image_request().
IMAGE_MODELS = [
    {"key": "nano-banana-2", "label": "NanoBanana 2"},
    {"key": "gpt-image-2", "label": "GPT Image 2"},
    {"key": "seedream-5-pro", "label": "Seedream 5.0 Pro"},
]
IMAGE_MODEL_KEYS = {m["key"] for m in IMAGE_MODELS}
IMAGE_MODELS_READY = IMAGE_MODEL_KEYS     # all wired

def build_kie_image_request(family, prompt, refs):
    """Map a dropdown model family (+ whether refs exist) to the exact Kie model id and input
    body. Reference images -> image-to-image variant; none -> text-to-image. All 16:9 / 2K."""
    refs = refs or []
    has = bool(refs)
    if family == "gpt-image-2":
        if has:
            return "gpt-image-2-image-to-image", {"prompt": prompt, "input_urls": refs[:16], "aspect_ratio": "16:9", "resolution": "2K"}
        return "gpt-image-2-text-to-image", {"prompt": prompt, "aspect_ratio": "16:9", "resolution": "2K"}
    if family == "seedream-5-pro":
        if has:
            return "seedream/5-pro-image-to-image", {"prompt": prompt, "image_urls": refs[:10], "aspect_ratio": "16:9", "quality": "high", "output_format": "png"}
        return "seedream/5-pro-text-to-image", {"prompt": prompt, "aspect_ratio": "16:9", "quality": "high", "output_format": "png"}
    # default: nano-banana-2 (one model id, optional image_input)
    inp = {"prompt": prompt, "aspect_ratio": "16:9", "resolution": "2K", "output_format": "png"}
    if has:
        inp["image_input"] = refs
    return "nano-banana-2", inp
# ---- video models --------------------------------------------------------
# Each family: durations (seconds the model supports) + resolutions, so the UI can adapt
# the dropdowns per model. `api` = which endpoint/flow to use ("jobs" = unified createTask,
# "veo" = the separate /api/v1/veo endpoint). `id` = the Kie model id (or veo model tier).
VIDEO_MODELS = [
    {"key": "seedance-2-fast", "label": "Seedance 2.0 Fast", "id": "bytedance/seedance-2-fast", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2", "label": "Seedance 2.0", "id": "bytedance/seedance-2", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p", "1080p", "4k"], "defaultDur": 5, "defaultRes": "1080p"},
    {"key": "veo-3-1", "label": "Veo 3.1", "id": "veo3_fast", "api": "veo",
     "durations": [4, 6, 8], "resolutions": ["720p", "1080p", "4k"], "defaultDur": 8, "defaultRes": "1080p"},
    {"key": "grok-imagine", "label": "Grok Imagine", "id": "grok-imagine/image-to-video", "api": "jobs",
     "durations": [6, 8, 10, 12, 15, 20, 25, 30], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
]
VIDEO_MODEL_BY_KEY = {m["key"]: m for m in VIDEO_MODELS}
DEFAULT_VIDEO_MODEL = "seedance-2-fast"
VIDEO_CONFIGURED = True

def _clamp_video_opts(cfg, duration, resolution):
    dur = duration if duration in cfg["durations"] else cfg["defaultDur"]
    res = resolution if resolution in cfg["resolutions"] else cfg["defaultRes"]
    return dur, res

def build_video_request(model_key, img_url, prompt, duration, resolution):
    """Return (api_type, model_id, payload) for the chosen video model. jobs -> {model,input}
    body for kie_create; veo -> flat body for /api/v1/veo/generate."""
    cfg = VIDEO_MODEL_BY_KEY.get(model_key) or VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
    dur, res = _clamp_video_opts(cfg, duration, resolution)
    mid = cfg["id"]
    if cfg["api"] == "veo":
        return "veo", mid, {"prompt": prompt, "imageUrls": [img_url], "model": mid,
                            "aspect_ratio": "16:9", "resolution": res, "duration": dur}
    if model_key == "grok-imagine":
        return "jobs", mid, {"prompt": prompt, "image_urls": [img_url], "mode": "normal",
                             "duration": str(dur), "resolution": res, "aspect_ratio": "16:9"}
    # seedance family
    return "jobs", mid, {"prompt": prompt, "first_frame_url": img_url, "generate_audio": False,
                         "duration": dur, "resolution": res, "aspect_ratio": "16:9"}

def kie_veo_create(payload):
    r = requests.post("https://api.kie.ai/api/v1/veo/generate",
                      headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                      json=payload, timeout=60)
    d = r.json()
    if d.get("code") == 200 and d.get("data"):
        return d["data"].get("taskId"), None
    return None, d.get("msg", "unknown error")

def kie_veo_record(task_id):
    r = requests.get("https://api.kie.ai/api/v1/veo/record-info", params={"taskId": task_id},
                     headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=60)
    return r.json()

# Prompt generation runs through Kie.ai's Anthropic-native Claude endpoint,
# so it uses the SAME KIE_API_KEY — no separate Anthropic key needed.
KIE_CLAUDE_URL = "https://api.kie.ai/claude/v1/messages"
# Quality-first, right-tool-per-task:
#  - SMART_MODEL = Fable 5 (Anthropic's most capable model) for the single hardest pass (whole-script
#    analyze). Thinking is always on and can run long, but it's one call per split, so it pays off.
#  - PROMPT_MODEL = Opus 4.8 for everything high-volume/fast (split cut, camera, per-scene image/video
#    prompt, music). Fable there would make "Generate All" very slow and can return empty on tight budgets.
PROMPT_MODEL = "claude-opus-4-8"
SMART_MODEL = "claude-fable-5"

# Per-scene visual style. Preset text (injected into the image prompt) is left
# EMPTY for now — the user will provide the exact wording later.
STYLE_KEYS = ["natural", "2d", "broll", "scientific"]
DEFAULT_STYLE = "natural"   # every new/split scene starts Natural/Realistic; the user flips it per scene as needed
# PLACEHOLDER preset texts (the "how it's shot": medium + camera + lighting + composition + quality).
# The user will replace these with their own wording (task #4).
STYLE_PRESETS = {
    "natural": "Photorealistic but candid and slightly amateur — like a real everyday photo taken by an ordinary person on a normal phone or consumer camera, NOT a polished stock photo and NOT a studio shot. Natural available light only (window or ordinary room light), soft and a little uneven, no studio lighting or softboxes, gentle real-world shadows. Ordinary everyday camera angles and framing, slightly imperfect, handheld feel. Natural true-to-life colors, not over-saturated or heavily color-graded. Real ordinary people (not models) with authentic skin texture — visible pores, fine lines, minor blemishes; absolutely no skin smoothing, airbrushing, or retouching. Believable, unposed, documentary/candid snapshot feel. Avoid glossy stock-photo perfection, studio lighting, cinematic color grading, and flawless model faces.",
    "2d": "2D hand-drawn cartoon illustration, like a still frame from a 2D animated explainer. Bold clean dark outlines with visible illustrative line strokes, flat colors with simple soft cel-shading, warm friendly palette, simplified cartoon character design. COMPOSITION (important): place the subject on a plain solid WHITE (or very light) background with the character(s) centered and isolated, and keep props/environment minimal — include ONLY the one or two objects essential to the action; NO full detailed room, NO busy scenery, NO edge-to-edge environment, no floor/wall/furniture filling the frame. Leave plenty of empty white space around the subject — a clean, uncluttered explainer frame. The ONLY exception, where a full-frame edge-to-edge illustration may cover the whole background, is anatomical / inside-the-body / organ / medical-diagram content; everything else stays centered on white. Clean illustrative/vector cartoon look — NOT photorealistic, NOT a 3D render, NOT a photo.",
    "broll": "Premium high-end commercial b-roll — flawless, polished, professional photography/cinematography of the highest quality, like a shot from a big-budget commercial or a top stock-footage library. Beautiful controlled studio-grade lighting: soft, deliberate, well-shaped light with elegant highlights and clean shadows (golden-hour warmth or crisp softbox light as fits the scene). Shallow depth of field with creamy background blur (bokeh), sharp perfectly-focused subject, professional lens look. Rich cinematic color grading, immaculate composition, tack-sharp fine detail, pristine and clean. Everything looks perfect and expensive — no amateur or phone-camera feel, no imperfections, no noise. When the subject is anatomical or microscopic (inside the body, cells, organs), render it as a hyper-detailed photorealistic 3D CGI medical visualization with the same premium cinematic lighting and depth of field.",
    "scientific": "Photorealistic 3D medical / anatomical visualization, like a high-end CGI medical animation still. Show the human body (or a body region) as semi-transparent — a translucent x-ray-like outer body through which the internal organs are clearly visible, or a detailed close-up rendering of a specific organ and its inner structures. Realistic 3D-rendered organs with accurate anatomy, soft glossy wet surfaces, subtle sub-surface glow, and warm glowing particles/points of light to highlight areas of interest (e.g. gut bacteria, inflammation, nutrients). Clean clinical rendering with smooth studio lighting, either a dark background with luminous organs or a soft light clinical/medical background. Precise, informative, science-documentary look — hyper-detailed 3D CGI, NOT a flat diagram, NOT a hand-drawn illustration, NOT a real photograph. If a real person is shown, keep them photoreal but overlay the glowing translucent anatomy/organs onto their body.",
}

# Camera framing/angle. The scene prompt itself stays framing-free (see PROMPT_SYSTEM); the chosen
# angle's phrasing is appended to the final image prompt so it can't conflict. A few common,
# sensible angles only.
CAMERA_ANGLES = [
    {"key": "closeup", "label": "Close-up",          "prompt": "Framed as a close-up shot: the camera is tight on the main subject, filling most of the frame."},
    {"key": "extreme", "label": "Extreme Close-up",  "prompt": "Framed as an extreme close-up: a very tight macro framing on a small detail of the subject, filling the frame."},
    {"key": "medium",  "label": "Medium Shot",       "prompt": "Framed as a medium shot: the main subject shown from roughly the waist up."},
    {"key": "wide",    "label": "Wide Shot",         "prompt": "Framed as a wide establishing shot: the full subject and the surrounding environment are visible in frame."},
    {"key": "ots",     "label": "Over the Shoulder", "prompt": "Framed as an over-the-shoulder shot: viewed from behind a foreground person's shoulder toward the subject."},
    {"key": "top",     "label": "Top View",          "prompt": "Shot from a top-down overhead angle, looking straight down on the scene (bird's-eye view)."},
    {"key": "side",    "label": "Side View",         "prompt": "Shot from a side profile angle, with the camera at ninety degrees to the subject."},
]
CAMERA_ANGLES_BY_KEY = {c["key"]: c for c in CAMERA_ANGLES}
CAMERA_KEYS = [c["key"] for c in CAMERA_ANGLES]
DEFAULT_CAMERA = "medium"

# Per-scene transition: how this scene hands off to the NEXT one (preview + render; not the Premiere XML).
TRANSITIONS = ["none", "crossfade", "dip-black", "dip-white",
               "slide-left", "slide-right", "slide-up", "slide-down"]
DEFAULT_TRANSITION = "none"

# Country -> language used for any visible text/signage in generated images
COUNTRY_LANG = {
    "United States": "English", "United Kingdom": "English",
    "France": "French", "Germany": "German",
}
def country_language(aud):
    locs = (aud or {}).get("locations") or []
    return COUNTRY_LANG.get(locs[0], "English") if locs else "English"

def looks_turkish(t):
    return any(ch in "çğıışöüÇĞİÖŞÜ" for ch in (t or ""))

def slugify(t, n=40):
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"

def fname_slug(t):
    """Underscore-joined name for output filenames, e.g. 'CitruSlim VSL' -> 'CitruSlim_VSL'."""
    return re.sub(r"[^A-Za-z0-9]+", "_", (t or "").strip()).strip("_") or "project"

def today_ddmmyyyy():
    return datetime.now().strftime("%d%m%Y")

def speaker_slug(voice_id):
    """Map a voice_id back to a saved voice name (underscored), or '' if not a saved voice."""
    for v in load_voices():
        if v.get("voice_id") == voice_id and v.get("name"):
            return fname_slug(v["name"])
    return ""

app = Flask(__name__)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0   # always serve fresh static assets during dev
app.config["TEMPLATES_AUTO_RELOAD"] = True    # pick up index.html edits without restart
# The desktop "Save As" (save_download in desktop.py) authenticates the local /media request with the
# cookie read from document.cookie — which excludes an HttpOnly session cookie, so the download 401'd
# ("login required") on some machines. This is a localhost-only app, so expose the session cookie to JS.
app.config["SESSION_COOKIE_HTTPONLY"] = False
# VSL_FRESH_SESSION (set by the desktop launcher) → a new key every run, so a previous session
# cookie no longer validates and the login gate always shows on launch. Dev/browser keeps the
# persisted key so it stays logged in across server restarts.
app.secret_key = os.urandom(24).hex() if os.environ.get("VSL_FRESH_SESSION") else (AUTH.get("secret") or os.urandom(24).hex())
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)   # stay logged in for a month

# ---- per-user data isolation ------------------------------------------------
# Each account gets its OWN projects + API keys under data/users/<name>/. One user is "active" per
# running instance (the desktop app signs one person in per launch); before_request re-points the
# project/key globals whenever the signed-in user changes, so baran and merih never see each other's
# projects or keys. voices.json / ost_presets.json stay shared (they hold no per-user secrets).
USERS_ROOT = DATA_DIR / "users"
try:
    USERS_ROOT.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

def _safe_user(u):
    return re.sub(r"[^a-zA-Z0-9_-]", "-", (u or "").strip()).strip("-") or "user"

def user_root(u):
    return USERS_ROOT / _safe_user(u)

_ACTIVE_USER = None
_ACTIVE_GUARD = threading.Lock()

def _activate_user(u):
    """Point PROJECTS/ENV_PATH at this user's private folder and reload their API keys. The key
    globals (KIE_KEY, …) are read by name at call time throughout the app, so reassigning them here
    switches every downstream request to the active user's credentials with no restart."""
    global _ACTIVE_USER, PROJECTS, ENV_PATH, ENV, KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY
    root = user_root(u)
    try:
        (root / "projects").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    PROJECTS = root / "projects"
    ENV_PATH = root / ".env"
    ENV = load_env()
    KIE_KEY = ENV.get("KIE_API_KEY", "")
    CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
    CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
    _ACTIVE_USER = u

# Everything requires a local login EXCEPT the login page itself and the static assets it needs
# (CSS/JS/fonts hold no secrets). Page requests redirect to /login; API/media requests get 401.
@app.before_request
def _require_login():
    u = session.get("user")
    if u:
        if u != _ACTIVE_USER:                    # signed-in user changed → point data at their folder
            with _ACTIVE_GUARD:
                if u != _ACTIVE_USER:
                    _activate_user(u)
        return None
    # Not logged in: gate only the data endpoints. Pages/static still load so the single-page
    # login gate (rendered inside "/") can show over the home, then reveal it after sign-in.
    if request.path.startswith("/api/") or request.path.startswith("/media/"):
        return ("login required", 401)
    return None

@app.after_request
def _no_cache(resp):
    if request.path == "/" or request.path.startswith("/static/"):
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

_lock = threading.Lock()   # serialize scenes.json writes

# Per-project lock so an endpoint's load→modify→save runs atomically. Without it, the 6s poll
# loop (which does its own load→save) can overwrite a scene that a concurrent Generate just
# marked "generating" with its own stale copy — the second scene appears to start then stop.
_PROJECT_LOCKS = {}
_PROJECT_LOCKS_GUARD = threading.Lock()
def _project_lock(name):
    with _PROJECT_LOCKS_GUARD:
        lk = _PROJECT_LOCKS.get(name)
        if lk is None:
            lk = threading.RLock()
            _PROJECT_LOCKS[name] = lk
        return lk

# ---- helpers ----------------------------------------------------------------
def proj_dir(name):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", name).strip("-") or "project"
    d = PROJECTS / safe
    return d, safe

def scenes_path(name):
    d, _ = proj_dir(name)
    return d / "scenes.json"

# on-screen text overlay defaults — burned onto preview + render, NOT sent to the image AI.
# Grouped: type / geometry / stroke / background / effects+animation.
# per-overlay style fields (each overlay = onscreen text + these). ost_on is section-level (see norm_scene).
# Default look = the user's saved "Montserrat White" style: Montserrat Extrabold 115px, UPPERCASE,
# centered, white fill, no stroke / no background / no drop shadow, slide-from-bottom in + fade out.
OST_OVERLAY_DEFAULTS = {
    "onscreen": "",
    "ost_fill": True, "ost_color": "#ffffff", "ost_font": "Montserrat", "ost_size": 115, "ost_weight": "800",
    "ost_bold": False, "ost_italic": False, "ost_upper": True, "ost_underline": False,
    "ost_letter": 0, "ost_leading": 0.85,
    "ost_place": "center", "ost_x": 0, "ost_y": 0, "ost_rotation": 0,
    "ost_stroke": False, "ost_stroke_w": 4, "ost_stroke_color": "#000000", "ost_stroke_pos": "outer",
    "ost_bg": False, "ost_bg_color": "#000000", "ost_bg_opacity": 60, "ost_bg_pad": 12, "ost_bg_radius": 8,
    "ost_shadow": False, "ost_shadow_color": "#000000", "ost_shadow_opacity": 80, "ost_shadow_size": 6, "ost_shadow_dir": 135,
    "ost_anim": "slide-bottom", "ost_out_anim": "fade",
    "ost_in": 0.0, "ost_out": 1.0,   # when the text shows, as a fraction of its scene (0=scene start, 1=scene end)
}

def new_overlay():
    return dict(OST_OVERLAY_DEFAULTS)

def _overlay_timeline(ov):
    """Map ONE overlay's ost_* fields to the text_* keys the renderer + preview consume."""
    return {
        "text": (ov.get("onscreen") or "").strip(),
        "text_fill": bool(ov.get("ost_fill", True)),
        "text_color": ov.get("ost_color") or "#ffffff",
        "text_font": ov.get("ost_font") or "Arial",
        "text_size": int(ov.get("ost_size") or 56),
        "text_weight": str(ov.get("ost_weight") or "400"),
        "text_bold": bool(ov.get("ost_bold")),
        "text_italic": bool(ov.get("ost_italic")),
        "text_upper": bool(ov.get("ost_upper")),
        "text_underline": bool(ov.get("ost_underline")),
        "text_letter": int(ov.get("ost_letter") or 0),
        "text_leading": float(ov.get("ost_leading") or 1.15),
        "text_place": ov.get("ost_place") or "top",
        "text_x": int(ov.get("ost_x") or 0),
        "text_y": int(ov.get("ost_y") or 0),
        "text_rotation": int(ov.get("ost_rotation") or 0),
        "text_stroke": bool(ov.get("ost_stroke", True)),
        "text_stroke_w": int(ov.get("ost_stroke_w") or 0),
        "text_stroke_color": ov.get("ost_stroke_color") or "#000000",
        "text_stroke_pos": ov.get("ost_stroke_pos") or "outer",
        "text_bg": bool(ov.get("ost_bg")),
        "text_bg_color": ov.get("ost_bg_color") or "#000000",
        "text_bg_opacity": int(ov.get("ost_bg_opacity") or 0),
        "text_bg_pad": int(ov.get("ost_bg_pad") or 0),
        "text_bg_radius": int(ov.get("ost_bg_radius") or 0),
        "text_shadow": bool(ov.get("ost_shadow", True)),
        "text_shadow_color": ov.get("ost_shadow_color") or "#000000",
        "text_shadow_opacity": int(ov.get("ost_shadow_opacity") or 0),
        "text_shadow_size": int(ov.get("ost_shadow_size") or 0),
        "text_shadow_dir": int(ov.get("ost_shadow_dir") or 0),
        "text_anim": ov.get("ost_anim") or "fade",
        "text_out_anim": ov.get("ost_out_anim") or "none",
        "text_in": _ost_frac(ov.get("ost_in"), 0.0),      # show window as a fraction of the scene
        "text_out": _ost_frac(ov.get("ost_out"), 1.0),
    }

def _ost_frac(v, default):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, f))

def _scene_overlays(s):
    """List of text_* dicts for a scene's overlays (empty when the section is off)."""
    if not s.get("ost_on"):
        return []
    return [_overlay_timeline(ov) for ov in (s.get("overlays") or []) if (ov.get("onscreen") or "").strip()]

def norm_scene(s):
    """Normalize a scene to the versioned-image model + defaults (backward compatible)."""
    s.setdefault("style", None)
    s.setdefault("no_cast", False)
    s.setdefault("model", IMAGE_MODEL)
    if s.get("model") not in IMAGE_MODEL_KEYS:   # migrate removed/old model keys (e.g. gpt-4o)
        s["model"] = IMAGE_MODEL
    s.setdefault("refs", [])
    s.setdefault("ref_free", [])      # ref paths whose STYLE (clothing/hair) is unlocked (default: locked)
    s.setdefault("cast", [])          # ids of doc.characters present in this scene
    s.setdefault("cont_of", None)     # uid of an earlier scene this one visually continues (same place+people)
    s.setdefault("camera", DEFAULT_CAMERA)          # camera framing/angle key
    if s.get("camera") not in CAMERA_ANGLES_BY_KEY and s.get("camera") not in ("", None, "none"):
        s["camera"] = DEFAULT_CAMERA   # "none" is a valid choice → no camera-angle text in the prompt
    s.setdefault("transition", DEFAULT_TRANSITION)  # transition into the NEXT scene
    if s.get("transition") not in TRANSITIONS:
        s["transition"] = DEFAULT_TRANSITION
    # on-screen text overlays: migrate legacy flat fields → overlays[0], normalize the list
    fresh = "overlays" not in s
    if fresh:
        s["overlays"] = [{k: s.get(k, OST_OVERLAY_DEFAULTS[k]) for k in OST_OVERLAY_DEFAULTS}]
    if not isinstance(s.get("overlays"), list) or not s["overlays"]:
        s["overlays"] = [new_overlay()]
    for ov in s["overlays"]:
        for k, v in OST_OVERLAY_DEFAULTS.items():
            ov.setdefault(k, v)
        ov["ost_in"] = _ost_frac(ov.get("ost_in"), 0.0)          # show window within the scene, 0..1
        ov["ost_out"] = _ost_frac(ov.get("ost_out"), 1.0)
        if ov["ost_out"] <= ov["ost_in"]:                        # keep at least a sliver visible
            ov["ost_out"] = min(1.0, ov["ost_in"] + 0.05)
    has_text = any((ov.get("onscreen") or "").strip() for ov in s["overlays"])
    if fresh:
        s["ost_on"] = has_text                       # legacy scenes with text migrate to ON
    else:
        s.setdefault("ost_on", has_text)
    for lk in list(OST_OVERLAY_DEFAULTS) + ["onscreen"]:   # drop legacy flat copies (now inside overlays)
        s.pop(lk, None)
    # video model + options (clamp to the selected model's supported values)
    if s.get("video_model") not in VIDEO_MODEL_BY_KEY:
        s["video_model"] = DEFAULT_VIDEO_MODEL
    _vcfg = VIDEO_MODEL_BY_KEY[s["video_model"]]
    if s.get("video_dur") not in _vcfg["durations"]:
        s["video_dur"] = _vcfg["defaultDur"]
    if s.get("video_res") not in _vcfg["resolutions"]:
        s["video_res"] = _vcfg["defaultRes"]
    s.setdefault("video", {"status": "empty", "taskId": None, "file": None, "error": None})
    s["video"].setdefault("approved", False)
    s["video"].setdefault("api", "jobs")
    img = s.setdefault("image", {})
    if "versions" not in img:
        vers = list(img.get("history") or [])
        if img.get("file"):
            vers.append(img["file"])
        img["versions"] = vers
        img["current"] = len(vers) - 1
    img.setdefault("current", len(img.get("versions", [])) - 1)
    for k, dv in (("status", "empty"), ("taskId", None), ("error", None)):
        img.setdefault(k, dv)
    vs, cur = img.get("versions", []), img.get("current", -1)
    img["file"] = vs[cur] if (vs and 0 <= cur < len(vs)) else None   # "file" = current (shown) version
    av = img.get("approved_version")
    img["approved_file"] = vs[av] if (isinstance(av, int) and 0 <= av < len(vs)) else None
    return s

def new_uid():
    """A short, permanent per-scene identity. Media files are named by this (NOT the 1..N display id),
    so inserting/splitting/deleting/reordering scenes — which renumbers ids — never renames files,
    never collides two scenes on one filename, and never detaches a video from its scene."""
    return hashlib.md5(f"{time.time()}".encode() + os.urandom(6)).hexdigest()[:8]

def load_doc(name):
    p = scenes_path(name)
    if not p.exists():
        return None
    doc = json.loads(p.read_text(encoding="utf-8"))
    doc.setdefault("characters", [])     # per-project cast: [{id, name, url}]
    doc.setdefault("brief", "")          # free-text project brief/context fed to the split + prompt LLM passes
    changed = False
    used = set()
    for s in doc.get("scenes", []):
        u = s.get("uid")
        if not u or u in used:           # one-time migration: give every existing scene a stable uid
            u = new_uid(); s["uid"] = u; changed = True
        used.add(u)
        norm_scene(s)
    if changed:
        save_doc(name, doc)              # persist the assigned uids once
    return doc

def save_doc(name, doc):
    d, _ = proj_dir(name)
    (d / "images").mkdir(parents=True, exist_ok=True)
    (d / "videos").mkdir(parents=True, exist_ok=True)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    with _lock:
        scenes_path(name).write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

def new_scene(i):
    return {
        "id": i, "uid": new_uid(), "vo": "", "prompt": "", "refs": [], "cast": [], "camera": DEFAULT_CAMERA, "transition": DEFAULT_TRANSITION, "style": DEFAULT_STYLE, "no_cast": False, "model": IMAGE_MODEL,
        "ost_on": False, "overlays": [new_overlay()],   # on-screen text (section toggle + overlay list)
        "image": {"status": "empty", "taskId": None, "error": None,
                  "versions": [], "current": -1, "file": None, "approved_version": None},
        "approved": False,
        "video_desc": "", "video_prompt": "",
        "video_model": DEFAULT_VIDEO_MODEL,
        "video_dur": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultDur"],
        "video_res": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultRes"],
        "video": {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False, "api": "jobs"},
    }

# ---- Cloudinary (for uploading local refs -> public URL for Kie) ------------
def cloudinary_upload(local_path, public_id):
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{CL_SECRET}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    with open(local_path, "rb") as fh:
        r = requests.post(
            f"https://api.cloudinary.com/v1_1/{CL_CLOUD}/image/upload",
            files={"file": fh},
            data={"public_id": public_id, "timestamp": ts, "api_key": CL_KEY, "signature": sig},
            timeout=120,
        )
    d = r.json()
    url = d.get("secure_url")
    # deliver a size-limited PNG so Kie always gets a valid, <25MP image
    if url:
        url = url.replace("/upload/", "/upload/c_limit,w_1600,f_png/")
        url = re.sub(r"\.(webp|jpg|jpeg)$", ".png", url)
    return url

# Reference images are stored LOCALLY on add (fast, no network/quota). Only when a scene is
# actually generated do we upload each local ref to Cloudinary to get the public URL Kie fetches.
_REF_URL_CACHE = {}   # (path, mtime_ns) -> cloudinary url, so a ref uploads at most once per session

def ref_public_url(d, safe, ref):
    """Public URL Kie can fetch for a stored reference. A local path ('refs/…') is uploaded to
    Cloudinary now; an http URL passes through — EXCEPT a Cloudinary URL from a different (old)
    account, which Kie can no longer fetch: we re-upload the local copy to the CURRENT account so
    old references self-heal instead of failing with 'image fetch failed'. Returns None if it can't."""
    if not ref:
        return None
    if ref.startswith("http://") or ref.startswith("https://"):
        if CL_CLOUD and "res.cloudinary.com/" in ref and f"res.cloudinary.com/{CL_CLOUD}/" not in ref:
            local = _local_ref_for_url(d, ref)          # find the on-disk copy by filename
            if local is not None:
                return ref_public_url(d, safe, str(local))   # re-upload it to the new account
        return ref
    p = d / ref
    if not p.is_file():
        p = d / "refs" / Path(ref).name
    if not p.is_file():
        return None
    try:
        key = (str(p), p.stat().st_mtime_ns)
    except OSError:
        key = (str(p), 0)
    if key in _REF_URL_CACHE:
        return _REF_URL_CACHE[key]
    url = cloudinary_upload(p, f"{safe}/refs/{p.stem}")
    if url:
        _REF_URL_CACHE[key] = url
    return url

def resolve_refs(d, safe, refs):
    """Turn stored refs into public URLs for Kie. Raises ValueError if a local ref can't upload
    (e.g. Cloudinary over quota) so generation fails with a clear message instead of silently
    dropping the reference."""
    out = []
    for r in (refs or []):
        u = ref_public_url(d, safe, r)
        if u is None:
            raise ValueError("reference image upload failed (check Cloudinary account)")
        out.append(u)
    return out

# ---- Kie.ai ----------------------------------------------------------------
def kie_create(model, inp):
    r = requests.post(f"{KIE_BASE}/createTask",
                      headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                      json={"model": model, "input": inp}, timeout=60)
    d = r.json()
    if d.get("code") == 200 and d.get("data"):
        return d["data"]["taskId"], None
    return None, d.get("msg", "unknown error")

def kie_record(task_id):
    r = requests.get(f"{KIE_BASE}/recordInfo", params={"taskId": task_id},
                     headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=60)
    return r.json()

def result_url(record):
    try:
        rj = record["data"].get("resultJson") or ""
        if rj:
            urls = json.loads(rj).get("resultUrls") or []
            if urls:
                return urls[0]
    except Exception:
        pass
    return None

def download_as_png(url, dest_path):
    """Download bytes and save as a *real* PNG regardless of what Kie actually returns."""
    r = requests.get(url, timeout=180)
    r.raise_for_status()
    img = Image.open(io.BytesIO(r.content)).convert("RGB")
    img.save(dest_path, "PNG")

def download_as_mp4(url, dest_path):
    r = requests.get(url, timeout=600, stream=True)
    r.raise_for_status()
    with open(dest_path, "wb") as fh:
        for chunk in r.iter_content(65536):
            fh.write(chunk)

# ---- subtitle / SRT (local forced alignment, no API) -----------------------
# Wraps the tested standalone tool subtitle/vsl_align_srt.py. Runs entirely on
# this machine (stable-whisper + ffmpeg) — no Kie.ai, no Claude Code tokens.
import sys as _sys
SRT_SCRIPT = BASE.parent / "subtitle" / "vsl_align_srt.py"
SUB_STATUS = {}            # {project: {status, step, srt, error, updated}}
SUB_LOCK = threading.Lock()

def sub_dir(name):
    d, _ = proj_dir(name)
    return d / "subtitle"

def sub_status_path(name):
    return sub_dir(name) / "status.json"

def set_sub_status(name, **kw):
    with SUB_LOCK:
        st = SUB_STATUS.get(name, {})
        st.update(kw); st["updated"] = time.time()
        SUB_STATUS[name] = st
    try:
        sub_dir(name).mkdir(parents=True, exist_ok=True)
        sub_status_path(name).write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return st

def get_sub_status(name):
    with SUB_LOCK:
        if name in SUB_STATUS:
            return dict(SUB_STATUS[name])
    p = sub_status_path(name)
    if p.exists():
        try:
            st = json.loads(p.read_text(encoding="utf-8"))
            # A persisted "running" with no live in-process job = the server was restarted mid-job
            # (which kills it). Report it as stopped so the UI never hangs on a dead job, and clear
            # the stale file so it doesn't resurface.
            if st.get("status") == "running":
                st = {"status": "error", "step": "",
                      "error": "Subtitle generation was interrupted (the server restarted). Please run it again."}
                try:
                    p.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
            return st
        except Exception:
            pass
    return {"status": "idle"}

# silence trimming (ffmpeg silenceremove). Each mode = how much gap to KEEP between sentences.
TRIM_MODES = {
    "fast":    {"sd": 0.15, "ss": 0.08},   # aggressive — very tight
    "natural": {"sd": 0.20, "ss": 0.28},   # keep a normal pause
    "slow":    {"sd": 0.25, "ss": 0.45},   # keep a gentle pause
}
def trim_silences(src, dst, mode="natural"):
    """Shorten silences (below -35dB) between sentences to the mode's target gap. Also trims
    leading/trailing silence. Returns True on success."""
    m = TRIM_MODES.get(mode, TRIM_MODES["natural"])
    thr = "-35dB"
    af = (f"silenceremove=start_periods=1:start_threshold={thr}:start_duration=0.1:start_silence=0.05:"
          f"stop_periods=-1:stop_threshold={thr}:stop_duration={m['sd']}:stop_silence={m['ss']}:detection=peak")
    try:
        subprocess.run(["ffmpeg", "-y", "-i", str(src), "-af", af, str(dst)],
                       check=True, capture_output=True, creationflags=_NO_WINDOW)
        return True
    except Exception:
        return False

def _run_align(name, wd, audio, docx, out, model, vad, step):
    """Run one alignment pass of vsl_align_srt.py as a subprocess (its own CWD = wd,
    so all caches — words_*.tsv, silence_all.log — land in the project subtitle dir)."""
    set_sub_status(name, status="running", step=step, error=None)
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out))
    # Run under console python inside a HIDDEN console (not CREATE_NO_WINDOW): the aligner's OWN
    # child processes (whisper's ffmpeg) then inherit that hidden console and never pop a black
    # window. CREATE_NO_WINDOW would leave the parent console-less, so each grandchild ffmpeg
    # allocates its own visible console instead.
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _cand = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_cand):
                exe = _cand
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0   # SW_HIDE
    args = [exe, str(SRT_SCRIPT), model]
    if vad:
        args.append("--vad")
    log_path = wd / "align.log"
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"\n===== {step} =====\n"); log.flush()
        proc = subprocess.run(args, cwd=str(wd), env=env,
                              stdout=log, stderr=subprocess.STDOUT,
                              startupinfo=si, creationflags=cf)
    return proc.returncode

def run_subtitle_job(name, audio, docx, out, trimmed_rel=None):
    """Ensemble flow the user runs manually: small.en --vad first (builds the secondary
    cache), then medium.en --vad which merges it → final SRT."""
    wd = sub_dir(name)
    try:
        rc = _run_align(name, wd, audio, docx, out, "small.en", True, "Synchronizing subtitles…")
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the first pass (exit {rc}); see align.log")
            return
        rc = _run_align(name, wd, audio, docx, out, "medium.en", True, "Finalizing subtitles…")
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the final pass (exit {rc}); see align.log")
            return
        if not Path(out).exists():
            set_sub_status(name, status="error", error="alignment finished but no SRT was produced; see align.log")
            return
        rel = f"subtitle/{Path(out).name}"
        set_sub_status(name, status="done", step="Done", srt=rel,
                       srt_name=Path(out).name, trimmed=trimmed_rel, error=None)
    except Exception as e:
        set_sub_status(name, status="error", error=str(e))

# ---- routes: auth -----------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    # The login UI is now an overlay inside the home page (single page), submitted via fetch.
    if request.method == "GET":
        return redirect(url_for("index"))
    u = request.form.get("username", "").strip()
    p = request.form.get("password", "")
    if check_login(u, p):
        session.permanent = True
        session["user"] = u
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Wrong username or password."}), 401

@app.route("/logout")
def logout():
    session.clear()
    # Redirect straight to "/" (the home shows the login gate when signed out) and forbid caching —
    # a cached 302 was letting a repeat sign-out skip the server, so the session never cleared.
    resp = redirect("/")
    resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

# ---- routes: pages ----------------------------------------------------------
@app.route("/")
def index():
    static = BASE / "static"
    try:
        v = str(int(max((static / "app.js").stat().st_mtime, (static / "style.css").stat().st_mtime)))
    except Exception:
        v = "1"
    return render_template("index.html", v=v, authed=bool(session.get("user")))

# ---- routes: API keys (let a new user plug in their own keys from the UI) ----
_KEY_MAP = {   # UI field -> .env variable
    "kie": "KIE_API_KEY", "cloud_name": "CLOUDINARY_CLOUD_NAME",
    "cloud_key": "CLOUDINARY_API_KEY", "cloud_secret": "CLOUDINARY_API_SECRET",
    "elevenlabs": "ELEVENLABS_API_KEY",
}
@app.route("/api/keys")
def api_get_keys():
    return jsonify({"kie": KIE_KEY, "cloud_name": CL_CLOUD, "cloud_key": CL_KEY,
                    "cloud_secret": CL_SECRET, "elevenlabs": ELEVEN_KEY})

@app.route("/api/keys", methods=["POST"])
def api_set_keys():
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY
    data = request.get_json(force=True) or {}
    updates = {_KEY_MAP[k]: (str(data[k]).strip()) for k in _KEY_MAP if k in data}
    if not updates:
        return jsonify({"error": "no keys provided"}), 400
    try:
        write_env(updates)
    except Exception as e:
        return jsonify({"error": f"could not write .env: {e}"}), 500
    # apply immediately so no server restart is needed
    if "KIE_API_KEY" in updates: KIE_KEY = updates["KIE_API_KEY"]
    if "CLOUDINARY_CLOUD_NAME" in updates: CL_CLOUD = updates["CLOUDINARY_CLOUD_NAME"]
    if "CLOUDINARY_API_KEY" in updates: CL_KEY = updates["CLOUDINARY_API_KEY"]
    if "CLOUDINARY_API_SECRET" in updates: CL_SECRET = updates["CLOUDINARY_API_SECRET"]
    if "ELEVENLABS_API_KEY" in updates: ELEVEN_KEY = updates["ELEVENLABS_API_KEY"]
    if any(k.startswith("CLOUDINARY") for k in updates):
        _REF_URL_CACHE.clear()   # old-account ref URLs would be stale after switching Cloudinary
    return jsonify({"ok": True})

# ---- routes: translate VO lines to Turkish (faint reference under each scene's sentence) ----
_TRANSLATE_SYSTEM = (
    "You are a professional translator. Translate each numbered line into natural, faithful Turkish. "
    "Preserve meaning and tone; do not add or omit content. Return ONLY a JSON array of strings — one "
    "Turkish translation per input line, in the SAME order and SAME count. No commentary, no numbering."
)

@app.route("/api/translate", methods=["POST"])
def api_translate():
    data = request.get_json(force=True) or {}
    texts = data.get("texts") or []
    source = (data.get("source") or "").strip()
    if not isinstance(texts, list) or not texts:
        return jsonify({"translations": []})
    numbered = "\n".join(f"{i+1}. {str(t)}" for i, t in enumerate(texts))
    user = (f"Source language: {source}.\nTranslate to Turkish:\n{numbered}" if source
            else f"Translate to Turkish:\n{numbered}")
    try:
        arr = _parse_json_array(_claude_text(_TRANSLATE_SYSTEM, user, max_tokens=6000))
        trs = [str(x) for x in arr][:len(texts)]
        while len(trs) < len(texts):
            trs.append("")
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"translations": trs})

# ---- routes: sync folder (Google Drive/OneDrive/Dropbox desktop) + export/import ----
# A single machine-level "sync folder" (a folder that a cloud-sync app mirrors between PCs). Export
# writes a project .zip there; the other PC lists + imports those zips. No API keys, no size limits.
APP_CONFIG_PATH = DATA_DIR / "app_config.json"

def _load_config():
    try:
        return json.loads(APP_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_config(cfg):
    try:
        APP_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

def _sync_dir():
    p = (_load_config().get("sync_dir") or "").strip()
    return Path(p) if p else None

@app.route("/api/config")
def api_get_config():
    sd = (_load_config().get("sync_dir") or "").strip()
    return jsonify({"sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir())})

@app.route("/api/config", methods=["POST"])
def api_set_config():
    data = request.get_json(force=True) or {}
    cfg = _load_config()
    if "sync_dir" in data:
        cfg["sync_dir"] = str(data["sync_dir"]).strip()
    _save_config(cfg)
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"ok": True, "sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir())})

_MANIFEST_NAME = "__vsl_manifest__.json"
_MUSIC_PREFIX = "__music__/"            # bundled Background Music tracks live here inside the zip

def _bundled_music(doc):
    """(src_path, arcname) for every Background Music track this project's plan uses — so the export
    is self-contained and plays/renders identically even on a PC that lacks that track."""
    out, seen = [], set()
    for seg in (doc.get("music_plan") or []):
        emo, track = seg.get("emotion"), seg.get("track")
        key = f"{emo}/{track}"
        if emo and track and key not in seen:
            seen.add(key)
            src = BGM_ROOT / emo / track
            if src.exists():
                out.append((src, f"{_MUSIC_PREFIX}{emo}/{track}"))
    return out

_EXPORT_JOBS = {}                        # job_id -> {pct, done, error, file, title, scenes}
_EXPORT_GUARD = threading.Lock()

def _run_export(job_id, d, safe, manifest, sd):
    tmp = sd / (safe + ".zip.part")
    final = sd / (safe + ".zip")
    try:
        files = []                       # (src, arcname) project files under <safe>/…
        for root, _dirs, fns in os.walk(d):
            if "__pycache__" in root:
                continue
            for fn in fns:
                fp = Path(root) / fn
                files.append((fp, str(Path(safe) / fp.relative_to(d))))
        try:
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
        except Exception:
            doc = {}
        files += _bundled_music(doc)     # self-contained: carry the music too
        total = sum(fp.stat().st_size for fp, _ in files) or 1
        written = 0
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED, allowZip64=True) as z:
            z.writestr(_MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
            for fp, arc in files:
                z.write(fp, arc)
                written += fp.stat().st_size
                _EXPORT_JOBS[job_id]["pct"] = min(99, int(written * 100 / total))
        if final.exists():
            final.unlink()
        tmp.replace(final)
        _EXPORT_JOBS[job_id].update(pct=100, done=True, file=final.name)
    except Exception as e:
        try:
            tmp.unlink()
        except Exception:
            pass
        _EXPORT_JOBS[job_id].update(done=True, error=str(e))

@app.route("/api/projects/<project>/export", methods=["POST"])
def api_export_project(project):
    """Kick off a background zip of the project folder (+ its music) into the sync folder as <name>.zip
    (stored = fast copy since media is already compressed). Returns a job id to poll for progress."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    sd = _sync_dir()
    if not sd:
        return jsonify({"error": "no-sync-dir"}), 400
    if not sd.is_dir():
        return jsonify({"error": "sync-dir-missing"}), 400
    try:
        doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
    except Exception:
        doc = {}
    manifest = {"name": safe, "title": doc.get("title", safe), "scenes": len(doc.get("scenes", [])),
                "exported_by": _ACTIVE_USER or "", "exported_at": datetime.now().isoformat(timespec="seconds")}
    job_id = uuid.uuid4().hex
    _EXPORT_JOBS[job_id] = {"pct": 0, "done": False, "error": None, "file": None, "title": manifest["title"]}
    threading.Thread(target=_run_export, args=(job_id, d, safe, manifest, sd), daemon=True).start()
    return jsonify({"ok": True, "job": job_id, "title": manifest["title"]})

@app.route("/api/export-status/<job>")
def api_export_status(job):
    j = _EXPORT_JOBS.get(job)
    if not j:
        return jsonify({"error": "not-found"}), 404
    return jsonify(j)

@app.route("/api/imports")
def api_list_imports():
    """List the project zips sitting in the sync folder (with manifest metadata for the picker)."""
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"sync_ok": False, "items": []})
    items = []
    for zp in sorted(sd.glob("*.zip")):
        info = {"file": zp.name, "title": zp.stem, "name": zp.stem, "scenes": None,
                "exported_by": "", "exported_at": "", "size": zp.stat().st_size}
        try:
            with zipfile.ZipFile(zp) as z:
                if _MANIFEST_NAME in z.namelist():
                    m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                    info.update({"title": m.get("title", info["title"]), "name": m.get("name", info["name"]),
                                 "scenes": m.get("scenes"), "exported_by": m.get("exported_by", ""),
                                 "exported_at": m.get("exported_at", "")})
        except Exception:
            pass
        items.append(info)
    return jsonify({"sync_ok": True, "items": items})

@app.route("/api/imports/delete", methods=["POST"])
def api_delete_import():
    """Delete one export zip from the sync folder (housekeeping from the import window)."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    try:
        if zp.exists():
            zp.unlink()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True})

@app.route("/api/import", methods=["POST"])
def api_import_project():
    """Pull one zip from the sync folder into THIS user's projects. overwrite=True replaces a project
    of the same name (2-PC round-trip); otherwise it's auto-renamed so nothing is clobbered. Bundled
    music (__music__/…) is restored into the local Background Music folder."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))     # basename → no path traversal
    overwrite = bool(data.get("overwrite"))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    if not zp.exists():
        return jsonify({"error": "not-found"}), 404
    base = zp.stem
    try:
        with zipfile.ZipFile(zp) as z:
            if _MANIFEST_NAME in z.namelist():
                m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                base = m.get("name") or base
    except Exception:
        pass
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", base).strip("-") or "project"
    if overwrite and (PROJECTS / safe).exists():
        target = safe                            # replace the existing same-named project
    else:
        target, n = safe, 1
        while (PROJECTS / target).exists():      # never clobber unless explicitly overwriting
            n += 1
            target = f"{safe}-import" + ("" if n == 2 else str(n))
    dest = PROJECTS / target
    tmp = PROJECTS / (target + ".importing")
    try:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(zp) as z:
            for nm in z.namelist():
                if nm == _MANIFEST_NAME:
                    continue
                if nm.startswith(_MUSIC_PREFIX):        # restore bundled music into Background Music/
                    rel = nm[len(_MUSIC_PREFIX):]
                    if not rel or nm.endswith("/"):
                        continue
                    mp = (BGM_ROOT / rel)
                    try:
                        if not mp.exists():             # never overwrite a shipped track
                            mp.parent.mkdir(parents=True, exist_ok=True)
                            with z.open(nm) as src, open(mp, "wb") as f:
                                shutil.copyfileobj(src, f)
                    except Exception:
                        pass
                    continue
                rel = nm.split("/", 1)[1] if "/" in nm else nm   # strip the top folder (original name)
                if not rel:
                    continue
                outp = tmp / rel
                if nm.endswith("/"):
                    outp.mkdir(parents=True, exist_ok=True)
                    continue
                outp.parent.mkdir(parents=True, exist_ok=True)
                with z.open(nm) as src, open(outp, "wb") as f:
                    shutil.copyfileobj(src, f)
        sp = tmp / "scenes.json"                 # retarget the project id to its new folder name
        if sp.exists():
            try:
                jdoc = json.loads(sp.read_text(encoding="utf-8"))
                jdoc["name"] = target
                sp.write_text(json.dumps(jdoc, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                pass
        if dest.exists():                        # overwrite: swap in the fresh copy atomically-ish
            shutil.rmtree(dest, ignore_errors=True)
        tmp.replace(dest)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({"error": str(e)}), 500
    title = target
    try:
        title = json.loads((dest / "scenes.json").read_text(encoding="utf-8")).get("title", target)
    except Exception:
        pass
    return jsonify({"ok": True, "name": target, "title": title, "overwritten": overwrite and dest == PROJECTS / safe})

# ---- routes: projects -------------------------------------------------------
@app.route("/api/projects")
def api_projects():
    out = []
    for d in sorted(PROJECTS.iterdir()):
        if (d / "scenes.json").exists():
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
            out.append({"name": d.name, "title": doc.get("title", d.name),
                        "scenes": len(doc.get("scenes", []))})
    return jsonify(out)

@app.route("/api/projects", methods=["POST"])
def api_create_project():
    body = request.get_json(force=True)
    name = body.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    d, safe = proj_dir(name)
    if (d / "scenes.json").exists():
        return jsonify({"error": "project exists", "name": safe}), 409
    doc = {"name": safe, "title": name, "created": datetime.now().isoformat(timespec="seconds"),
           "audience": body.get("audience", {}), "brief": body.get("brief", ""), "refs": [], "characters": [], "scenes": []}
    save_doc(safe, doc)
    return jsonify({"name": safe})

@app.route("/api/projects/<project>/rename", methods=["POST"])
def api_rename_project(project):
    """Rename a project's display title (the folder / id stays the same)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    title = (request.get_json(force=True).get("title") or "").strip()
    if not title:
        return jsonify({"error": "title required"}), 400
    doc["title"] = title
    save_doc(project, doc)
    return jsonify({"ok": True, "title": title})

@app.route("/api/projects/<project>", methods=["DELETE"])
def api_delete_project(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True})

@app.route("/api/projects/<project>/duplicate", methods=["POST"])
def api_duplicate_project(project):
    """Deep-copy a project (all files + scenes.json) into a NEW, fully independent project. The folder
    gets the next -vN version; the display title gets a bumped ' vN'. Editing one never touches the other."""
    src, safe = proj_dir(project)
    if not (src / "scenes.json").exists():
        abort(404)
    doc = load_doc(project)
    # unique folder name: bump a trailing -vN (or add -v2), skipping any that already exist
    m = re.match(r"^(.*?)[-_ ]v(\d+)$", safe, re.I)
    stem, n = (m.group(1), int(m.group(2))) if m else (safe, 1)
    while True:
        n += 1
        new_name = f"{stem}-v{n}"
        if not (PROJECTS / new_name).exists():
            break
    # display title: bump a trailing vN, else append ' v2'
    tm = re.match(r"^(.*?)[-_ ]v(\d+)$", (doc.get("title") or "").strip(), re.I)
    new_title = (f"{tm.group(1).strip()} v{int(tm.group(2)) + 1}" if tm
                 else f"{(doc.get('title') or stem).strip()} v2")
    shutil.copytree(src, PROJECTS / new_name)
    d2 = json.loads((PROJECTS / new_name / "scenes.json").read_text(encoding="utf-8"))
    d2["name"], d2["title"] = new_name, new_title
    (PROJECTS / new_name / "scenes.json").write_text(json.dumps(d2, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"name": new_name, "title": new_title})

# ---- routes: scenes ---------------------------------------------------------
@app.route("/api/scenes/<project>")
def api_get_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    return jsonify(doc)

@app.route("/api/scenes/<project>", methods=["PUT"])
def api_save_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    # only allow editable fields to be overwritten from the UI
    incoming = {s["id"]: s for s in body.get("scenes", [])}
    for s in doc["scenes"]:
        u = incoming.get(s["id"])
        if not u:
            continue
        # NOTE: "approved" is intentionally NOT here — it's managed only by the /approve endpoint.
        # Including it let a routine full-doc save (from a text edit) with a stale value clobber a
        # concurrent approve, silently un-approving images.
        for f in ("vo", "vo_tr", "note", "prompt", "refs", "cast", "camera", "transition", "video_desc", "video_prompt", "style", "no_cast", "model", "video_model", "video_dur", "video_res", "ost_on", "overlays"):
            if f in u:
                s[f] = u[f]
    if "title" in body:
        doc["title"] = body["title"]
    if "script" in body:
        doc["script"] = body["script"]
    if "audience" in body:
        doc["audience"] = body["audience"]
    if "brief" in body:
        doc["brief"] = body["brief"]
    if "subtitle_style" in body:
        doc["subtitle_style"] = body["subtitle_style"]   # global caption look (applies to all subtitles)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/video-models")
def api_video_models():
    return jsonify(VIDEO_MODELS)

@app.route("/api/scenes/<project>/insert", methods=["POST"])
def api_insert_scene(project):
    """Insert a blank scene after the given id (0 = at the start), then renumber."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    after = request.get_json(force=True).get("after", 0)
    scenes = doc["scenes"]
    idx = 0
    for i, s in enumerate(scenes):
        if s["id"] == after:
            idx = i + 1
            break
    scenes.insert(idx, new_scene(0))
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/duplicate", methods=["POST"])
def api_duplicate_scene(project, sid):
    """Clone a scene (all settings + overlays; the copy shares the original's image/video file
    references — regenerating either later just writes new files, so they never clash) and insert
    it right after, then renumber 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc["scenes"]
    idx = next((i for i, s in enumerate(scenes) if s["id"] == sid), None)
    if idx is None:
        return jsonify(doc)
    copy = json.loads(json.dumps(scenes[idx]))   # deep copy
    copy["uid"] = new_uid()                       # its OWN identity — so regenerating it can't overwrite the original's files
    scenes.insert(idx + 1, copy)
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/delete-scene", methods=["POST"])
def api_delete_scene(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] != sid]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/reorder", methods=["POST"])
def api_reorder(project):
    """Reorder scenes to the given list of ids, then RENUMBER 1..N (so output filenames follow)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    order = request.get_json(force=True).get("order", [])
    by_id = {s["id"]: s for s in doc["scenes"]}
    new = [by_id[i] for i in order if i in by_id]
    new += [s for s in doc["scenes"] if s["id"] not in order]   # safety: keep any missing
    for i, s in enumerate(new, 1):
        s["id"] = i
    doc["scenes"] = new
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/restore", methods=["POST"])
def api_restore(project):
    """Undo support: replace the editable doc state (scenes/audience/characters/refs/script) from a
    client snapshot and save it wholesale. Keeps name/title/created."""
    cur = load_doc(project)
    if cur is None:
        abort(404)
    snap = request.get_json(force=True) or {}
    for k in ("scenes", "audience", "characters", "refs", "script", "brief"):
        if k in snap:
            cur[k] = snap[k]
    for s in cur.get("scenes", []):
        norm_scene(s)
    save_doc(project, cur)
    return jsonify(cur)

SPLIT_SYSTEM = """You segment a VSL (video sales letter) script into scenes for a video.
Each scene is the chunk of narration (VO) that is spoken while ONE image/clip is on screen.

Rules:
- Cut at natural visual/meaning shifts, NOT at every period. A long sentence containing two distinct visual ideas may be split; very short fragments that clearly belong to the same shot may be merged.
- Do NOT change, add, remove, rephrase, reorder, or translate ANY words. Only decide where the cuts go. Keep the original wording, punctuation, and casing exactly.
- Each scene should be roughly one idea / one breath (often one sentence, sometimes a clause or two short sentences).
- Output ONLY the scenes, ONE per line, in order. No numbering, no bullet points, no blank lines, no commentary."""

def split_script(script):
    """Split via Claude (Kie.ai). Raises on failure — NO naive fallback (bad splits)."""
    script = (script or "").strip()
    if not script:
        return []
    text = _claude_text(SPLIT_SYSTEM, script, max_tokens=8000)   # may raise
    parts = [re.sub(r"^\s*\d+[\.\)\-:]\s*", "", ln.strip()) for ln in text.splitlines() if ln.strip()]
    parts = [p for p in parts if p]
    if not parts:
        raise RuntimeError("splitter returned no scenes")
    return parts

CAMERA_SYSTEM = """You choose the best camera framing for each scene of a video sales letter.
For each numbered scene (its spoken narration), pick ONE camera angle key from this exact list:
{keys}

Guidance:
- closeup / extreme  -> emotion, a face, hands, a small detail, or a product held up
- medium             -> one person talking or doing an everyday action (a safe default)
- wide               -> a location, a group of people, or establishing a whole setting
- ots                -> two people together, a conversation, or someone looking at something
- top                -> things arranged/laid out, seen from directly above
- side               -> walking, movement, or a profile view

Output ONLY the chosen key for each scene, ONE per line, in the same order, nothing else."""

def assign_camera_angles(scene_texts):
    """Pick a camera angle per scene via Claude, by meaning. Falls back to DEFAULT_CAMERA on any
    problem so it never fails the split."""
    n = len(scene_texts)
    if not n:
        return []
    try:
        numbered = "\n".join(f"{i+1}. {t}" for i, t in enumerate(scene_texts))
        sys = CAMERA_SYSTEM.replace("{keys}", ", ".join(CAMERA_KEYS))
        text = _claude_text(sys, numbered, max_tokens=2000)
        out = []
        for ln in text.splitlines():
            if not ln.strip():
                continue
            norm = re.sub(r"[^a-z]", "", ln.lower())
            if norm in CAMERA_ANGLES_BY_KEY:
                out.append(norm)
            else:
                out.append(next((k for k in CAMERA_KEYS if k in norm), DEFAULT_CAMERA))
        return (out + [DEFAULT_CAMERA] * n)[:n]
    except Exception:
        return [DEFAULT_CAMERA] * n

# Whole-script "director" pass: reads ALL scenes at once (+ the project cast) and, understanding the
# story's continuity, decides for each scene (a) which named cast members appear, (b) the transition
# INTO the next scene, and (c) whether it visually continues an earlier scene (same place + people).
ANALYZE_SYSTEM = """You are the director of a video sales letter (VSL). You get the full script already cut into numbered scenes, in order, plus the list of named CAST members (people who each have a reference photo). Think about the WHOLE story and its continuity first, then output one decision object per scene.

For EACH scene decide four things:
1. "cast": the CAST names visually present as a subject in that scene. Resolve pronouns and continuity across the whole script — if "Paula" is introduced in scene 2 and scene 5 says "she went to her doctor", scene 5's cast is ["Paula"] (plus the doctor, if the doctor is a named cast member). Use ONLY names from the CAST list, spelled exactly as given; NEVER invent a name. If no cast member is clearly a subject, use [].
2. "transition": how this scene cuts to the NEXT one. Exactly one of: none, crossfade, dip-black, dip-white, slide-left, slide-right, slide-up, slide-down.
   - none = a clean hard cut. This is the DEFAULT and should be the MAJORITY of scenes — a VSL is punchy.
   - slide-left / slide-right = moving through a list or sequence of items (e.g. "a pill, an injection, a herbal tea"), or step-by-step progression.
   - crossfade = a soft emotional beat or a passage of time between two related moments.
   - dip-black = a hard chapter break, a dramatic low point, or a stark before/after.
   - dip-white = a moment of realization, hope or relief.
   - slide-up / slide-down = a reveal or a vertical shift of focus.
   Only use a non-"none" transition when it clearly earns its place. Keep it balanced and tasteful.
3. "continues": if this scene shows the SAME place with the SAME people as an EARLIER scene — simply continuing that exact moment (e.g. scene 6 "Doctor Carolina told me…", then scene 7 "…and I answered her": same room, same two people) — put that earlier scene's number so its image can be reused for visual continuity. Otherwise 0. Only set it when BOTH the setting AND the people clearly carry over from that earlier scene.
4. "style": the visual style for this scene. Almost every scene is "natural". Use "scientific" ONLY when the shot depicts the INSIDE of the body or microscopic biology — organs (heart, liver, gut, brain, lungs…), blood vessels / veins / arteries, cells (fat cells, gut bacteria, neurons), tissue, or any internal anatomical / medical visualization. Everyday scenes, people, products, lifestyle, someone taking a pill or drinking tea — all stay "natural". Only the actual internal-body / anatomy visuals get "scientific".

CAST members available: {cast}
(If the CAST list is "(none)", every "cast" must be [].)

Output ONLY a JSON array — one object per scene, in order, nothing else:
[{"scene":1,"cast":[],"transition":"none","continues":0,"style":"natural"}]
No prose, no markdown, no code fences."""

def _parse_json_array(text):
    """Best-effort parse of a JSON array from an LLM reply (tolerates ```json fences / stray prose)."""
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("["), t.rfind("]")
    if a < 0 or b < a:
        raise ValueError("no JSON array")
    return json.loads(t[a:b + 1])

def analyze_scenes(scene_texts, characters, brief=""):
    """One Claude pass over the whole script → per-scene {cast:[ids], transition, continues:<1-based #>}.
    Never raises: any problem yields empty dicts so the split still succeeds (cast/transition just stay default)."""
    n = len(scene_texts)
    if not n:
        return []
    chars = [c for c in (characters or []) if c.get("name")]
    names = [c["name"].strip() for c in chars]
    name_by_lower = {c["name"].strip().lower(): c for c in chars}
    cast_label = ", ".join(names) if names else "(none)"
    try:
        numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(scene_texts))
        if (brief or "").strip():
            numbered = (f"PROJECT CONTEXT (background about the whole project — may be written in Turkish; "
                        f"use it to understand who's who, the setting and where these scenes fall in the story, "
                        f"especially if the script starts mid-story):\n{brief.strip()}\n\nSCENES:\n" + numbered)
        sys = ANALYZE_SYSTEM.replace("{cast}", cast_label)
        data = _parse_json_array(_claude_text(sys, numbered, max_tokens=8000, model=SMART_MODEL))   # headroom for Fable 5's always-on thinking + the JSON
    except Exception:
        return [{"cast": [], "transition": "none", "continues": 0, "style": DEFAULT_STYLE} for _ in range(n)]
    out = []
    for i in range(n):
        item = data[i] if i < len(data) and isinstance(data[i], dict) else {}
        cids = []
        for nm in (item.get("cast") or []):
            c = name_by_lower.get(str(nm).strip().lower())
            if c and c.get("id") is not None and c["id"] not in cids:
                cids.append(c["id"])
        tr = item.get("transition")
        tr = tr if tr in TRANSITIONS else "none"
        try:
            cont = int(item.get("continues") or 0)
        except (TypeError, ValueError):
            cont = 0
        if not (1 <= cont <= i):        # must point to an EARLIER scene (1-based); else drop
            cont = 0
        st = str(item.get("style") or "").strip().lower()
        st = st if st in ("natural", "scientific") else DEFAULT_STYLE   # only these two are auto-picked; everything else → natural
        out.append({"cast": cids, "transition": tr, "continues": cont, "style": st})
    out[-1]["transition"] = "none"       # the last scene never transitions to a "next"
    return out

@app.route("/api/scenes/<project>/split", methods=["POST"])
def api_split(project):
    """Split the script into meaningful scenes via Claude (Kie.ai). Surfaces errors; no fallback.
    Then a whole-script director pass auto-assigns camera framing, transitions, cast, and continuity."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = request.get_json(force=True).get("script", "")
    try:
        parts = split_script(script)
    except Exception as e:
        return jsonify({"error": f"Split failed: {e}"}), 502
    cams = assign_camera_angles(parts)               # auto-pick a framing per scene, by meaning
    analysis = analyze_scenes(parts, doc.get("characters"), doc.get("brief", ""))   # cast + transition + continuity, by meaning (brief-aware)
    doc["scenes"] = []
    for i, sent in enumerate(parts, 1):
        sc = new_scene(i)
        sc["vo"] = sent
        sc["camera"] = cams[i - 1] if i - 1 < len(cams) else DEFAULT_CAMERA
        a = analysis[i - 1] if i - 1 < len(analysis) else {}
        sc["cast"] = a.get("cast") or []
        sc["transition"] = a.get("transition") or DEFAULT_TRANSITION
        sc["style"] = a.get("style") or DEFAULT_STYLE   # natural, except scientific for internal-body/anatomy scenes
        sc["_cont"] = a.get("continues") or 0        # temp: 1-based source scene #, resolved to a uid below
        doc["scenes"].append(sc)
    for sc in doc["scenes"]:                          # resolve continuity #→uid now that every scene has a uid
        c = sc.pop("_cont", 0)
        sc["cont_of"] = doc["scenes"][c - 1]["uid"] if 1 <= c <= len(doc["scenes"]) else None
    save_doc(project, doc)
    return jsonify(doc)

# ---- routes: prompt generation (Anthropic) ---------------------------------
PROMPT_SYSTEM = """You describe what is SHOWN on screen for ONE scene of a VSL (video sales letter).
You get the spoken sentence (VO) and, optionally, an on-screen note. Output a vivid description of the CONTENT of the shot only.

INCLUDE:
- the subject(s) and their action, the setting/location, and the key objects in view
- concrete, specific, visual detail that illustrates the sentence's meaning

DO NOT INCLUDE (other layers own these — including them causes conflicts):
- ANY framing, shot size, camera angle or viewpoint (no "close-up", "wide view", "over the shoulder", "top view", "from the side", "in the foreground") — a separate Camera Angle layer owns this
- camera/lens/aperture/shot technicalities (no "85mm", "f/2.0", "DSLR", "drone shot")
- lighting descriptions (no "soft light", "golden hour")
- image-quality or medium words (no "photorealistic", "cinematic", "4k", "HDR", "amateur", "2D", "animation", "render", "illustration")
- the person's age, ethnicity, hair, or skin — describe people only by role/action ("a woman", "a doctor", "her hands"), UNLESS the user lists named characters present in the scene, in which case use their name for that person (e.g. "Loretta") instead of a generic role
- any on-screen text, captions, logos, or watermarks

Also choose the single best STYLE for this moment:
- natural    = real people / lifestyle
- 2d         = animation / illustration / motion-graphics
- broll      = objects, food, product, or scenery (no talking people)
- scientific = medical / diagram / data visualization

OUTPUT FORMAT: the FIRST line must be exactly "STYLE: <key>" (natural|2d|broll|scientific).
Then, on the following line(s), output ONLY the content description — no preamble, no quotes, no explanation.
If a required STYLE is given by the user, you MUST use that one."""

def char_urls(c):
    """Every reference image of a character. New characters store `urls` (a list); legacy ones a
    single `url` — normalise both to a list so a character can carry several reference images."""
    if c.get("urls"):
        return [u for u in c["urls"] if u]
    return [c["url"]] if c.get("url") else []

def scene_characters(scene, doc):
    """Resolve a scene's `cast` (character ids) against doc.characters → list of character dicts."""
    by_id = {c.get("id"): c for c in (doc.get("characters") or [])}
    return [by_id[cid] for cid in (scene.get("cast") or []) if cid in by_id]

def _cont_source(scene, doc):
    """The earlier scene this one visually continues (same place + people), by stable uid, or None."""
    u = scene.get("cont_of")
    return next((x for x in doc.get("scenes", []) if x.get("uid") == u), None) if u else None


def cast_directive(scene, aud, has_ref=False):
    """Per-scene casting from the SELECTED audience options only, rotated so scenes vary.
    Appearance is an EXCLUSION list: avoid those looks, leave everything else unrestricted."""
    if not aud:
        return ""
    def pick(key, off=0):
        opts = aud.get(key) or []
        return opts[(scene.get("id", 1) - 1 + off) % len(opts)] if opts else None
    parts = []
    # If a reference image / named character is attached, IT defines the person — do not force
    # gender/appearance, else the casting text overrides the reference (a male ref came out female).
    if not has_ref:
        who = []
        g, a = pick("genders"), pick("ages", 1)
        if g:
            who.append(g.lower())
        if a:
            who.append("aged " + a)
        if who:
            parts.append("If a person appears, they are " + ", ".join(who) + ".")
        excl = aud.get("appearance") or []
        if excl:
            parts.append("Casting exclusion — if a person appears, do NOT depict these looks at all: "
                         + ", ".join(excl) + ". Any other appearance is fine; do not otherwise restrict "
                         "ethnicity, skin tone, or hair color.")
    if aud.get("locations"):
        parts.append("Set in / people look local to " + ", ".join(aud["locations"]) + ".")
    if aud.get("currencies"):
        parts.append("Any money, price, or packaging uses " + " / ".join(aud["currencies"]) + ".")
    return " ".join(parts)

def _claude_text(system, user, max_tokens=1024, model=None):
    r = requests.post(KIE_CLAUDE_URL,
                      headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                      json={"model": model or PROMPT_MODEL, "max_tokens": max_tokens, "system": system,
                            "messages": [{"role": "user", "content": user}]},
                      timeout=120)
    d = r.json()
    blocks = d.get("content") or []
    text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
    if not text:
        raise RuntimeError(d.get("msg") or d.get("error") or "no text returned")
    return text

def claude_prompt(vo, onscreen, aud=None, forced_style=None, cast_names=None, brief=""):
    """Ask Claude (via Kie.ai) for (image_prompt, style_key)."""
    user = f"VO sentence: {vo}"
    if onscreen:
        user += f"\nOn-screen note: {onscreen}"
    if (brief or "").strip():
        user += (f"\n\nPROJECT CONTEXT (background about the whole project — may be in Turkish; for CONSISTENCY only): "
                 f"{brief.strip()}\nUse it to keep people, places, product and style consistent across scenes, but depict "
                 f"ONLY what THIS scene's VO describes — do NOT add the product, characters, or details the VO doesn't "
                 f"mention. Always write the final description in English.")
    if cast_names:
        user += (f"\nNamed characters present in THIS scene: {', '.join(cast_names)}. "
                 "When one of them appears, refer to them by their name (e.g. write the name, not "
                 "'a woman' / 'a man'). Do NOT invent characters who aren't in the sentence.")
    if forced_style:
        user += f"\nRequired STYLE: {forced_style}"
        if forced_style == "2d":
            user += ("\nThis scene will be drawn as a SIMPLE flat 2D cartoon, so describe it simply and iconically: "
                     "the key subject(s), their action, and only the one or two essential objects. Do NOT pile on fine "
                     "realistic micro-detail, intricate textures, or photographic specifics — those don't suit a flat cartoon.")
        elif forced_style == "scientific":
            user += ("\nThis scene is a medical / scientific visualization (inside the body, an organ, cells, etc.), so "
                     "describe the anatomical subject and what it shows clearly and specifically.")
    text = _claude_text(PROMPT_SYSTEM, user)
    style = None
    m = re.match(r"\s*STYLE:\s*([a-zA-Z0-9]+)", text)
    if m:
        k = m.group(1).lower()
        if k in STYLE_KEYS:
            style = k
        text = text[m.end():].lstrip("\n").strip()
    if forced_style:
        style = forced_style
    return text, style

def translate_to_english(text):
    return _claude_text(
        "Translate the user's image-generation prompt into natural English. "
        "Keep it as one single prompt with the same meaning. Output ONLY the translation.",
        text)

def localize_prompt(prompt, aud):
    """Translate Turkish prompts to English; require on-image text in the country's language."""
    p = prompt or ""
    if looks_turkish(p):
        try:
            p = translate_to_english(p)
        except Exception:
            pass
    lang = country_language(aud)
    if lang and lang != "English":
        p = p.rstrip() + f" If any text, signage, or packaging appears, it must be written in {lang}."
    return p

def build_image_prompt(scene, aud, chars=None):
    """Assemble the final Nano Banana prompt: STYLE (how) + SCENE (what, localized) + CASTING + No text.
    `chars` = the named characters present in this scene (each with a reference image)."""
    chars = chars or []
    parts = []
    preset = STYLE_PRESETS.get(scene.get("style") or "natural", "")
    if preset:
        parts.append(preset.strip())
    parts.append(localize_prompt(scene.get("prompt") or "", aud))
    cam = CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))    # camera framing owns the shot angle (prompt stays framing-free)
    if cam:
        parts.append(cam["prompt"])
    if chars:
        # the character reference images are appended to the request as i2i inputs (see api_generate);
        # name them here so the model maps each reference to the right person in the scene.
        names = ", ".join(c["name"] for c in chars if c.get("name"))
        parts.append(f"The reference image(s) show named character(s): {names}. Depict each of them "
                     "with the SAME face, gender, age, build and overall appearance as in their reference.")
    elif scene.get("refs"):
        refs = scene.get("refs") or []
        free = set(scene.get("ref_free") or [])          # refs whose STYLE (clothing/hair) is unlocked
        if free & set(refs):                              # user unlocked a reference → allow clothing/hair variation
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face and identity faithful to the reference, but you MAY change their clothing "
                         "and hairstyle to suit this scene.")
        else:
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face, hair, clothing/outfit and overall appearance faithful to the reference.")
    # per-scene "Ignore audience casting" toggle: skip ALL audience directives so a hand-written
    # multi-person prompt has full control (audience casting was collapsing everyone to one look).
    if not scene.get("no_cast"):
        cast = cast_directive(scene, aud, has_ref=bool(scene.get("refs") or chars))
        if cast:
            parts.append(cast)
    parts.append("No text.")
    return "\n".join(p for p in parts if p and p.strip())

@app.route("/api/scenes/<project>/genprompt", methods=["POST"])
def api_genprompt(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    targets = doc["scenes"] if ids == "all" else [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        vo = (s.get("vo") or "").strip()
        if not vo:
            continue
        try:
            cast_names = [c["name"] for c in scene_characters(s, doc) if c.get("name")]
            # on-screen text is a video overlay now, NOT an image hint → do not send it to the AI
            prompt, style = claude_prompt(vo, "", doc.get("audience"), s.get("style"), cast_names, doc.get("brief", ""))
            s["prompt"] = prompt
            if style:
                s["style"] = style
            s["prompt_error"] = None
        except Exception as e:
            s["prompt_error"] = str(e)
    save_doc(project, doc)
    return jsonify(doc)

# ---- routes: video-prompt generation ---------------------------------------
VIDEO_PROMPT_SYSTEM = """You write a SHORT image-to-video MOTION prompt for ONE shot of a VSL.
You are given the description of a STILL image. Describe subtle, realistic motion that brings that
still to life WITHOUT changing what it shows — a "living photo".

INCLUDE:
- ONE gentle camera move (a slow push-in, a slow pan, or a slight parallax/zoom)
- natural small subject/ambient motion that fits the scene (breathing, a slight head or hand movement,
  a blink, hair or clothing shifting, steam/liquid/light/particles drifting, leaves moving)

DO NOT:
- add or remove people or objects, change the setting, morph or transform anything
- cut to another shot, add on-screen text, or use fast, dramatic, or unrealistic motion
Keep it calm, minimal and grounded — it must stay faithful to the still image.

OUTPUT: 1-2 short sentences, ONLY the motion description. No preamble, no quotes."""

def video_prompt_for(scene):
    """Generate a subtle, image-consistent motion prompt for a scene from its image prompt/VO."""
    base = (scene.get("prompt") or "").strip() or (scene.get("vo") or "").strip()
    return _claude_text(VIDEO_PROMPT_SYSTEM, f"Still image: {base}")

@app.route("/api/scenes/<project>/gen-video-prompt", methods=["POST"])
def api_gen_video_prompt(project):
    """Write an AI motion prompt into each eligible scene's video_desc (the Videos-tab textbox)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = request.get_json(force=True).get("ids", "all")
    def eligible(s):
        return s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))
    targets = [s for s in doc["scenes"] if eligible(s) and (ids == "all" or s["id"] in ids)]
    for s in targets:
        try:
            s["video_desc"] = video_prompt_for(s)
            s["video_prompt_error"] = None
        except Exception as e:
            s["video_prompt_error"] = str(e)
    save_doc(project, doc)
    return jsonify(doc)

# ---- routes: image generation ----------------------------------------------
# ---- generation QUEUE: cap how many jobs are submitted/in-flight at once so a big "Generate All"
# doesn't fire 40+ API calls simultaneously (which the provider rate-limits → failures). Extra
# scenes wait as status "queued" and are submitted by the poll loop as running jobs finish.
IMG_CONCURRENCY = 6
VID_CONCURRENCY = 3

def _submit_image(s, doc, d, safe):
    if not s.get("prompt"):
        s["image"].update(status="error", error="no prompt")
        return
    family = s.get("model") or IMAGE_MODEL
    if family not in IMAGE_MODELS_READY:
        family = IMAGE_MODEL
    chars = scene_characters(s, doc)
    try:
        # scene refs AND every character image are stored locally now; upload each to Cloudinary here
        refs = resolve_refs(d, safe, s.get("refs")) + resolve_refs(d, safe, [u for c in chars for u in char_urls(c)])
    except ValueError as e:
        s["image"].update(status="error", error=str(e))
        return
    prompt = build_image_prompt(s, doc.get("audience"), chars)
    # scene-continuity: if this scene continues an earlier one (same place + people) and that scene
    # already has an image, feed it as an extra reference so the setting stays consistent. If the
    # source image isn't ready yet, we just skip it (regenerate this scene once the source exists).
    cont = _cont_source(s, doc)
    if cont is not None:
        rel = (cont.get("image") or {}).get("approved_file") or (cont.get("image") or {}).get("file")
        if rel and (d / rel).exists():
            try:
                refs = refs + resolve_refs(d, safe, [rel])
                prompt += ("\nOne of the reference images is a frame from the PREVIOUS moment in this SAME "
                           "scene — keep the same location, background, lighting and the same people's "
                           "appearance for visual continuity; only the action and framing change as described.")
            except ValueError:
                pass
    model_id, inp = build_kie_image_request(family, prompt, refs)
    tid, err = kie_create(model_id, inp)
    if tid:
        s["image"].update(status="generating", taskId=tid, error=None)
    else:
        s["image"].update(status="error", error=err)

def _drain_image_queue(doc, d, safe):
    """Submit queued image jobs up to IMG_CONCURRENCY. Returns True if anything was submitted."""
    gen = sum(1 for s in doc["scenes"] if s["image"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= IMG_CONCURRENCY:
            break
        if s["image"]["status"] != "queued":
            continue
        _submit_image(s, doc, d, safe)
        changed = True
        if s["image"]["status"] == "generating":
            gen += 1
    return changed

def _submit_video(s, d, safe, doc):
    frame = s["image"].get("approved_file") or s["image"].get("file")
    if not frame:
        s["video"].update(status="error", error="approve an image version first")
        return
    img_url = cloudinary_upload(d / frame, f"{safe}/frames/{s.setdefault('uid', new_uid())}")
    if not img_url:
        s["video"].update(status="error", error="frame upload failed")
        return
    prompt = s.get("video_prompt") or s.get("video_desc") or ""
    api, mid, payload = build_video_request(s.get("video_model") or DEFAULT_VIDEO_MODEL, img_url,
                                            prompt, s.get("video_dur"), s.get("video_res"))
    tid, err = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
    if tid:
        # remember WHICH approved image this video is being made from, so the Videos tab can flag a
        # video as stale once the scene's approved image is changed/re-approved to a different one.
        s["video"].update(status="generating", taskId=tid, error=None, api=api, source=frame)
    else:
        s["video"].update(status="error", error=err)

def _drain_video_queue(doc, d, safe):
    gen = sum(1 for s in doc["scenes"] if s["video"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= VID_CONCURRENCY:
            break
        if s["video"]["status"] != "queued":
            continue
        _submit_video(s, d, safe, doc)
        changed = True
        if s["video"]["status"] == "generating":
            gen += 1
    return changed

@app.route("/api/scenes/<project>/generate", methods=["POST"])
def api_generate(project):
    with _project_lock(project):
        return _api_generate(project)


def _api_generate(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    targets = doc["scenes"] if ids == "all" else [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        if not s.get("prompt"):
            s["image"].update(status="error", error="no prompt")
        else:
            s["image"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_image_queue(doc, d, safe)                                       # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/poll", methods=["POST"])
def api_poll(project):
    with _project_lock(project):
        return _api_poll(project)


def _api_poll(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    changed = False
    for s in doc["scenes"]:
        # images
        if s["image"]["status"] == "generating" and s["image"]["taskId"]:
            rec = kie_record(s["image"]["taskId"])
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec)
                if url:
                    ver = len(s["image"].get("versions", [])) + 1
                    fname = f"sc_{s.setdefault('uid', new_uid())}_v{ver}.png"
                    try:
                        download_as_png(url, d / "images" / fname)
                        s["image"].setdefault("versions", []).append(f"images/{fname}")
                        s["image"]["current"] = len(s["image"]["versions"]) - 1
                        s["image"].update(status="ready", file=f"images/{fname}", error=None)
                    except Exception as e:
                        s["image"].update(status="error", error=f"download: {e}")
                else:
                    s["image"].update(status="error", error="no result url")
                changed = True
            elif state == "fail":
                fm = (rec.get("data") or {}).get("failMsg", "generation failed")
                s["image"].update(status="error", error=fm)
                changed = True
        # videos
        if s["video"]["status"] == "generating" and s["video"]["taskId"]:
            if s["video"].get("api") == "veo":
                rec = kie_veo_record(s["video"]["taskId"])
                data = rec.get("data") or {}
                sf = data.get("successFlag")
                if sf == 1:
                    resp = data.get("response") or {}
                    urls = resp.get("fullResultUrls") or resp.get("resultUrls") or resp.get("originUrls") or []
                    url = urls[0] if urls else None
                    if url:
                        fname = f"sc_{s.setdefault('uid', new_uid())}.mp4"
                        try:
                            download_as_mp4(url, d / "videos" / fname)
                            s["video"].update(status="ready", file=f"videos/{fname}", error=None)
                        except Exception as e:
                            s["video"].update(status="error", error=f"download: {e}")
                    else:
                        s["video"].update(status="error", error="no result url")
                    changed = True
                elif sf in (2, 3):
                    s["video"].update(status="error", error=data.get("errorMessage") or "generation failed")
                    changed = True
            else:
                rec = kie_record(s["video"]["taskId"])
                state = (rec.get("data") or {}).get("state")
                if state == "success":
                    url = result_url(rec)
                    if url:
                        fname = f"sc_{s.setdefault('uid', new_uid())}.mp4"
                        try:
                            download_as_mp4(url, d / "videos" / fname)
                            s["video"].update(status="ready", file=f"videos/{fname}", error=None)
                        except Exception as e:
                            s["video"].update(status="error", error=f"download: {e}")
                    else:
                        s["video"].update(status="error", error="no result url")
                    changed = True
                elif state == "fail":
                    fm = (rec.get("data") or {}).get("failMsg", "generation failed")
                    s["video"].update(status="error", error=fm)
                    changed = True
    # a running job finished → submit the next queued image/video jobs (keeps in-flight ≤ the limit)
    if _drain_image_queue(doc, d, safe):
        changed = True
    if _drain_video_queue(doc, d, safe):
        changed = True
    if changed:
        save_doc(project, doc)
    return jsonify(doc)

# ---- routes: video generation ----------------------------------------------
@app.route("/api/scenes/<project>/generate-video", methods=["POST"])
def api_generate_video(project):
    with _project_lock(project):
        return _api_generate_video(project)


def _api_generate_video(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if not VIDEO_CONFIGURED:
        return jsonify({"error": "Seedance video model not configured yet (need exact model id/params)."}), 503
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", [])
    if ids == "all":
        targets = [s for s in doc["scenes"] if s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))]
    else:
        targets = [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        s["video"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_video_queue(doc, d, safe)                                   # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

def build_video_input(scene, image_url):
    """Input schema for Seedance Fast 2.0 (bytedance/seedance-2-fast) image-to-video.
    Fast model tops out at 720p; deliver native (no upscale)."""
    prompt = scene.get("video_prompt") or scene.get("video_desc") or ""
    return {
        "prompt": prompt,
        "first_frame_url": image_url,
        "aspect_ratio": "16:9",
        "resolution": "720p",
    }

# ---- local thumbnails for reference images ---------------------------------
# Every reference image exists twice: on disk under projects/<name>/refs/ (the original
# upload) and on Cloudinary (the public URL Kie fetches at generation time). Drawing the
# panel straight from Cloudinary re-downloaded every full-size ref on each render, which
# is what exhausted the account's bandwidth quota. The UI now asks for the local copy and
# only falls back to the remote URL when the file is missing.
def _norm_stem(s):
    """Loose filename key: scene refs are 's1-0-name' on Cloudinary but 's1_0_name' on disk."""
    return re.sub(r"[-_\s]+", " ", s).strip().lower()

def _local_ref_for_url(d, url):
    """Find the on-disk file a reference points to, or None."""
    refs = d / "refs"
    if not url or not refs.is_dir():
        return None
    # new-style refs are a local relative path stored directly (e.g. "refs/s1_0_name.png")
    if not url.startswith("http://") and not url.startswith("https://"):
        p = d / _urlunquote(url)
        if p.is_file():
            return p
        p = refs / Path(_urlunquote(url)).name
        return p if p.is_file() else None
    # old-style refs are a Cloudinary URL → match the local file by filename stem
    path = _urlunquote(_urlparse(url).path)
    stem = Path(path).stem
    # characters upload as <safe>/characters/<cid>, but are stored as char_<cid>_<original>
    if "/characters/" in path:
        hit = next((p for p in sorted(refs.glob(f"char_{stem}_*")) if p.is_file()), None)
        if hit:
            return hit
    want = _norm_stem(stem)
    for p in sorted(refs.iterdir()):
        if p.is_file() and _norm_stem(p.stem) == want:
            return p
    return None

@app.route("/api/ref-thumb/<project>")
def api_ref_thumb(project):
    """Serve a small cached thumbnail of a reference image straight from local disk."""
    d, safe = proj_dir(project)
    src = _local_ref_for_url(d, request.args.get("u", ""))
    if src is None:
        abort(404)                      # the UI falls back to the remote URL
    tdir = d / ".thumbs"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(src.name.encode("utf-8")).hexdigest() + ".jpg")
    if not thumb.exists() or thumb.stat().st_mtime < src.stat().st_mtime:
        try:
            im = Image.open(src)
            im = im.convert("RGB")
            im.thumbnail((360, 360))
            im.save(thumb, "JPEG", quality=82)
        except Exception:
            return send_file(src)       # not readable by PIL -> hand over the original
    return send_file(thumb, mimetype="image/jpeg")

# ---- routes: refs -----------------------------------------------------------
@app.route("/api/refs/<project>", methods=["POST"])
def api_upload_ref(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    local = d / "refs" / f.filename
    f.save(local)
    pid = f"{safe}/refs/{Path(f.filename).stem}"
    url = cloudinary_upload(local, pid)
    if not url:
        return jsonify({"error": "cloudinary upload failed"}), 500
    ref = {"name": f.filename, "url": url}
    doc.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify(ref)

# ---- routes: per-scene reference images ------------------------------------
@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["POST"])
def api_scene_ref(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    idx = len(scene.get("refs", []))
    fname = f"s{sid}_{idx}_{int(time.time())}_{f.filename}"
    f.save(d / "refs" / fname)
    # store the LOCAL path only — the Cloudinary upload is deferred to generation time (see
    # ref_public_url), so adding references never needs the network or the Cloudinary quota
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"]})

@app.route("/api/scenes/<project>/<int:sid>/ref-scene", methods=["POST"])
def api_scene_ref_scene(project, sid):
    """Add another scene's APPROVED image as a reference on scene <sid> — a snapshot copy into refs/.
    The filename carries the source scene number (sceneref-<N>-…) so the UI can badge it 'Scene N'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    from_id = (request.get_json(force=True) or {}).get("from")
    src_scene = next((s for s in doc["scenes"] if s["id"] == from_id), None)
    if src_scene is None:
        return jsonify({"error": "scene not found"}), 404
    im = src_scene.get("image", {}) or {}
    rel = im.get("approved_file") or im.get("file")     # prefer the approved image
    if not rel:
        return jsonify({"error": "that scene has no image yet"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not src.exists():
        return jsonify({"error": "source image missing"}), 400
    (d / "refs").mkdir(parents=True, exist_ok=True)
    fname = f"sceneref-{from_id}-{int(time.time())}{src.suffix or '.png'}"
    shutil.copy2(src, d / "refs" / fname)
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"], "doc": doc})

# ---- routes: named characters (per-project cast) ---------------------------
@app.route("/api/characters/<project>", methods=["POST"])
def api_add_character(project):
    """Add a named character: form fields `name` + `file` (reference image). The image is saved
    LOCALLY; the upload to Cloudinary (needed as an i2i reference for Kie) is deferred to image
    generation — so adding a character never needs the network or the Cloudinary quota."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "character name is required"}), 400
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a reference image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    cid = hashlib.md5(f"{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate(files):
        fname = f"char_{cid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ch = {"id": cid, "name": name, "urls": urls}   # local paths; Cloudinary upload happens at generation
    doc.setdefault("characters", []).append(ch)
    save_doc(project, doc)
    return jsonify(ch)


def _norm_char(ch):
    """Migrate a legacy single-`url` character to the multi-image `urls` shape in place."""
    if "urls" not in ch:
        ch["urls"] = [ch["url"]] if ch.get("url") else []
    ch.pop("url", None)
    return ch


@app.route("/api/characters/<project>/<cid>", methods=["POST"])
def api_update_character(project, cid):
    """Edit a character: optional rename (form `name`) and/or append reference image(s) (form `file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    name = (request.form.get("name") or "").strip()
    if name:
        ch["name"] = name
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"char_{cid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ch["urls"].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>/remove-image", methods=["POST"])
def api_remove_character_image(project, cid):
    """Drop one reference image from a character (keeps at least one)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    url = (request.get_json(force=True) or {}).get("url")
    if url in ch["urls"] and len(ch["urls"]) > 1:
        ch["urls"].remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception:
            pass
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>", methods=["DELETE"])
def api_del_character(project, cid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["characters"] = [c for c in doc.get("characters", []) if c.get("id") != cid]
    for s in doc.get("scenes", []):        # remove it from every scene's cast
        if cid in (s.get("cast") or []):
            s["cast"] = [x for x in s["cast"] if x != cid]
    save_doc(project, doc)
    return jsonify({"ok": True, "characters": doc["characters"]})

# ---- routes: image edit / versions / downloads -----------------------------
def _find_scene(doc, sid):
    return next((s for s in doc["scenes"] if s["id"] == sid), None)

@app.route("/api/scenes/<project>/<int:sid>/edit", methods=["POST"])
def api_edit_image(project, sid):
    """Edit the CURRENT version using it as the reference (image-to-image), keep history."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    instr = (request.get_json(force=True).get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    img = s["image"]
    vs, cur = img.get("versions", []), img.get("current", -1)
    if not vs or not (0 <= cur < len(vs)):
        return jsonify({"error": "generate an image first"}), 400
    d, safe = proj_dir(project)
    # Stable public_id per scene (no timestamp) so re-editing OVERWRITES the same Cloudinary asset
    # instead of piling up a new permanent one every edit. Signed uploads overwrite by default, and
    # Cloudinary returns a version-busted secure_url so Kie always fetches the fresh base — one
    # edit-base asset per scene, ever. (frames/ and refs/ were already stable-id, so only edits leaked.)
    base_url = cloudinary_upload(d / vs[cur], f"{safe}/edits/s{sid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    # Build an EDIT command, not a scene description. Do NOT prepend the big style preset here:
    # the base image already carries the style, and dumping ~150 words of "keep this exact look"
    # in front of a one-line instruction buries the edit — the model just reproduces the same
    # image. Make the change DOMINANT and forceful; over-preserving "the same subject" is what
    # blocks appearance edits (e.g. "make them thinner"), so we only protect the setting/style/faces
    # and explicitly ALLOW the subject's body/appearance to change to satisfy the instruction.
    # If the instruction is written in Turkish, translate ONLY the user's words to English first,
    # so the forceful English directives below reach the model verbatim. (Running the whole prompt
    # through the translator, as localize_prompt would, could soften the "apply it strongly" wording.)
    instr_en = instr
    if looks_turkish(instr):
        try:
            instr_en = translate_to_english(instr)
        except Exception:
            instr_en = instr
    p = (f"Edit this image. Required change: {instr_en}. "
         "This change is the single most important requirement — apply it strongly and make it "
         "clearly and obviously visible in the result; do NOT return an image where the change is "
         "absent or barely noticeable. "
         "You MAY alter the people's body shape, size, clothing and appearance as needed to achieve "
         "the requested change. Keep the same overall scene, background, camera framing, lighting and "
         "visual style, and keep each person recognizable as the same individual, but change everything "
         "the instruction asks for.")
    # Edit ALWAYS uses NanoBanana image-to-image. Feed ONLY the current image as the base — adding the
    # scene's cast reference photos here over-anchors each person's identity so hard that appearance
    # edits (body shape, etc.) can't take, making the result look identical. Prompt is already English.
    image_input = [base_url]
    model_id, inp = build_kie_image_request("nano-banana-2", p, image_input)
    tid, err = kie_create(model_id, inp)
    if tid:
        img.update(status="generating", taskId=tid, error=None)
    else:
        img.update(status="error", error=err)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/current", methods=["POST"])
def api_set_current(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    idx = request.get_json(force=True).get("index")
    vs = s["image"].get("versions", [])
    if isinstance(idx, int) and 0 <= idx < len(vs):
        s["image"]["current"] = idx
        save_doc(project, doc)
    return jsonify(s["image"])

@app.route("/api/scenes/<project>/<int:sid>/reset-image", methods=["POST"])
def api_reset_image(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["image"] = {"status": "empty", "taskId": None, "error": None, "versions": [], "current": -1, "file": None}
    s["approved"] = False
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-image", methods=["POST"])
def api_cancel_image(project, sid):
    """Stop an in-progress (queued OR generating) image generation for ONE scene.
    Keeps any existing versions — we just abandon the new task so poll/queue ignore it.
    A Kie task already submitted keeps running on their side; we simply stop tracking it."""
    with _project_lock(project):     # same atomic load→modify→save as generate/poll so we don't race the 6s poll
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        img = s["image"]
        if img.get("status") in ("queued", "generating"):
            vs = img.get("versions", [])
            if vs:                                            # regen over an existing image → keep the old one
                cur = img.get("current", len(vs) - 1)
                cur = cur if 0 <= cur < len(vs) else len(vs) - 1
                img.update(status="ready", taskId=None, error=None, file=vs[cur])
            else:                                             # first-time generation → back to empty
                img.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/delete-version", methods=["POST"])
def api_delete_version(project, sid):
    """Delete ONLY the shown image version (not all). The file is left on disk so Undo can restore it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    img = s["image"]
    vs = img.get("versions", [])
    idx = request.get_json(force=True).get("index", img.get("current", -1))
    if not (0 <= idx < len(vs)):
        return jsonify(doc)
    vs.pop(idx)
    av = img.get("approved_version")
    if isinstance(av, int):
        if av == idx:
            img["approved_version"] = None
            s["approved"] = False
        elif av > idx:
            img["approved_version"] = av - 1
    if not vs:
        s["image"] = {"status": "empty", "taskId": None, "error": None,
                      "versions": [], "current": -1, "file": None, "approved_version": None}
        s["approved"] = False
    else:
        img["versions"] = vs
        img["current"] = min(img.get("current", 0), len(vs) - 1)
    norm_scene(s)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/approve", methods=["POST"])
def api_approve(project, sid):
    """Approve/unapprove the scene. On approve, LOCK the currently-shown version."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    body = request.get_json(force=True)
    approved = bool(body.get("approved"))
    s["approved"] = approved
    if approved:
        # optional explicit version to approve (from the lightbox) — set it as current too,
        # so approving is atomic and race-free regardless of pending setCurrent calls.
        ver = body.get("version")
        vs = s["image"].get("versions", [])
        if isinstance(ver, int) and 0 <= ver < len(vs):
            s["image"]["current"] = ver
        s["image"]["approved_version"] = s["image"].get("current", len(vs) - 1)
    norm_scene(s)   # recompute approved_file so the response is current
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-video", methods=["POST"])
def api_reset_video(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"] = {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False}
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/video-approve", methods=["POST"])
def api_video_approve(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"]["approved"] = bool(request.get_json(force=True).get("approved"))
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/zip-images")
def api_zip_images(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            if not s.get("approved"):
                continue
            f = s["image"].get("approved_file") or s["image"].get("file")
            if f and (d / f).exists():
                z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-images.zip")

@app.route("/api/scenes/<project>/zip-videos")
def api_zip_videos(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-videos.zip")

# ---- routes: media serving --------------------------------------------------
@app.route("/api/subtitle/<project>", methods=["GET"])
def api_subtitle_status(project):
    return jsonify(get_sub_status(project))

def text_to_docx(text, path):
    """Wrap plain UI script text as a minimal .docx (one paragraph per non-empty line) so the
    aligner's docx reader consumes it through the exact same code path as an uploaded .docx."""
    import xml.sax.saxutils as sx
    paras = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{sx.escape(ln.strip())}</w:t></w:r></w:p>'
        for ln in text.splitlines() if ln.strip())
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           '<w:body>' + paras + '</w:body></w:document>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)

@app.route("/api/subtitle/<project>", methods=["POST"])
def api_subtitle_run(project):
    doc = load_doc(project)
    if not doc:
        return jsonify({"error": "unknown project"}), 404
    st = get_sub_status(project)
    if st.get("status") == "running":
        return jsonify({"error": "a subtitle job is already running"}), 409
    d, safe = proj_dir(project)
    def truthy(v): return str(v).lower() in ("1", "true", "on", "yes")
    use_gen_vo = truthy(request.form.get("use_generated_vo"))
    use_script = truthy(request.form.get("use_script"))
    trim = truthy(request.form.get("trim"))
    trim_mode = request.form.get("trim_mode") or "natural"
    trimmed_rel = None
    audio = request.files.get("audio")
    docx = request.files.get("docx")
    # fresh workdir each run so stale alignment caches never leak into a new job
    wd = sub_dir(project)
    if wd.exists():
        shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True, exist_ok=True)
    docx_path = wd / "script.docx"

    # ---- audio source (accepts any common audio type; ffmpeg/whisper sniff by content) ----
    if use_gen_vo:
        gen = d / "voiceover" / "voiceover.mp3"
        if not gen.exists():
            return jsonify({"error": "no generated voice-over yet — generate it above first"}), 400
        audio_path = wd / "audio.mp3"
        shutil.copyfile(gen, audio_path)
    else:
        if not audio or not audio.filename:
            return jsonify({"error": "a voice-over audio file is required"}), 400
        ext = (Path(audio.filename).suffix or ".mp3").lower()
        audio_path = wd / ("audio" + ext)
        audio.save(str(audio_path))
        # trim silences on the uploaded audio, then align to the TRIMMED audio + offer it for download
        if trim:
            trimmed = wd / "voiceover_trimmed.mp3"
            if trim_silences(audio_path, trimmed, trim_mode):
                audio_path = trimmed
                trimmed_rel = f"subtitle/{trimmed.name}"

    # ---- script source (.docx or plain-text .txt) ----
    if use_script:
        script_text = (request.form.get("script_text") or "").strip()
        if not script_text:
            return jsonify({"error": "the script box on the left is empty"}), 400
        text_to_docx(script_text, docx_path)
    else:
        if not docx or not docx.filename:
            return jsonify({"error": "a script file (.docx or .txt) is required"}), 400
        fn = docx.filename.lower()
        if fn.endswith(".txt"):
            text_to_docx(docx.read().decode("utf-8", "ignore"), docx_path)
        elif fn.endswith(".docx"):
            docx.save(str(docx_path))
        else:
            return jsonify({"error": "script must be a .docx or .txt file"}), 400

    proj = fname_slug(doc.get("title") or project)
    date = today_ddmmyyyy()
    out_path = wd / f"{proj}_Subtitle_{date}.srt"
    trimmed_name = f"{proj}_Voiceover_Trimmed_{date}.mp3" if trimmed_rel else None
    set_sub_status(project, status="running", step="Starting…", srt=None,
                   trimmed=None, trimmed_name=trimmed_name, error=None)
    threading.Thread(target=run_subtitle_job,
                     args=(project, audio_path, docx_path, out_path, trimmed_rel), daemon=True).start()
    return jsonify({"status": "running"})

# ---- routes: voice-over (ElevenLabs) ---------------------------------------
DEFAULT_VOICES = [
    {"name": "Loretta Jophlin", "voice_id": "DiWaolzR7aFbwU2MJGyD"},
    {"name": "Daniel Sandrin", "voice_id": "EC7t0LPc9MtRU1r33xNj"},
]
def load_voices():
    if VOICES_PATH.exists():
        try:
            return json.loads(VOICES_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    VOICES_PATH.write_text(json.dumps(DEFAULT_VOICES, indent=2), encoding="utf-8")
    return list(DEFAULT_VOICES)

def save_voices(voices):
    VOICES_PATH.write_text(json.dumps(voices, indent=2, ensure_ascii=False), encoding="utf-8")

@app.route("/api/ost-presets", methods=["GET"])
def api_get_ost_presets():
    if OST_PRESETS_PATH.exists():
        try:
            return jsonify(json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8")))
        except Exception:
            return jsonify([])
    return jsonify([])

@app.route("/api/ost-presets", methods=["POST"])
def api_save_ost_presets():
    data = request.get_json(force=True)
    if not isinstance(data, list):
        return jsonify({"error": "expected a list"}), 400
    OST_PRESETS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"ok": True})

@app.route("/api/voices", methods=["GET"])
def api_voices():
    return jsonify(load_voices())

@app.route("/api/voices", methods=["POST"])
def api_voices_add():
    body = request.get_json(force=True)
    name = (body.get("name") or "").strip()
    vid = (body.get("voice_id") or "").strip()
    if not name or not vid:
        return jsonify({"error": "name and voice_id required"}), 400
    voices = load_voices()
    for v in voices:              # update if the name already exists
        if v.get("name", "").lower() == name.lower():
            v["voice_id"] = vid
            break
    else:
        voices.append({"name": name, "voice_id": vid})
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voices/<name>", methods=["DELETE"])
def api_voices_del(name):
    voices = [v for v in load_voices() if v.get("name", "").lower() != name.lower()]
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voiceover/<project>", methods=["POST"])
def api_voiceover(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    if not ELEVEN_KEY:
        return jsonify({"error": "ELEVENLABS_API_KEY is not set in .env"}), 400
    doc = load_doc(project)
    body = request.get_json(force=True)
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": ELEVEN_KEY, "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL,
                  "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": f"request failed: {e}"}), 502
    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("detail", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except Exception:
            msg = r.text[:300]
        return jsonify({"error": f"ElevenLabs {r.status_code}: {msg}"}), 502
    (d / "voiceover").mkdir(exist_ok=True)
    out = d / "voiceover" / "voiceover.mp3"
    # trim silences between sentences if requested (the saved voiceover.mp3 becomes the trimmed one,
    # so "use the voice-over generated above" in subtitles picks up the trimmed audio)
    if body.get("trim"):
        raw = d / "voiceover" / "voiceover_raw.mp3"
        raw.write_bytes(r.content)
        if not trim_silences(raw, out, body.get("trim_mode") or "natural"):
            out.write_bytes(r.content)   # fall back to untrimmed on ffmpeg failure
    else:
        out.write_bytes(r.content)
    proj = fname_slug((doc or {}).get("title") or project)
    spk = speaker_slug(voice_id)
    name = f"{proj}_{spk + '_' if spk else ''}Voiceover_{today_ddmmyyyy()}.mp3"
    return jsonify({"ok": True, "file": "voiceover/voiceover.mp3", "name": name})

# ---- routes: Premiere project export (FCP7 XML) ----------------------------
def _find_srt(d):
    """Locate the project's SRT: the one the subtitle job produced, else any *.srt."""
    sd = d / "subtitle"
    if not sd.exists():
        return None
    named = sorted(sd.glob("*_Subtitle_*.srt"))
    if named:
        return named[-1]
    any_srt = sorted(sd.glob("*.srt"))
    return any_srt[-1] if any_srt else None


def _find_vo_audio(d):
    """The audio the SRT was aligned to: prefer the trimmed take, then the subtitle-job
    audio, then the generated voice-over."""
    sd = d / "subtitle"
    cand = [sd / "voiceover_trimmed.mp3"]
    if sd.exists():
        cand += sorted(sd.glob("audio.*"))
    cand.append(d / "voiceover" / "voiceover.mp3")
    for p in cand:
        if p.exists():
            return p
    return None


def _normalized_vo(d):
    """The voice-over loudness-normalized to a consistent VSL level (cached in export/;
    rebuilt only when the source changes). Falls back to the raw VO if ffmpeg fails."""
    src = _find_vo_audio(d)
    if not src:
        return None
    dst = d / "export" / "voiceover_norm.mp3"
    try:
        fresh = dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime
    except Exception:
        fresh = False
    if fresh:
        return dst
    return premiere_export.normalize_loudness(src, dst) or src


@app.route("/api/export-premiere/<project>", methods=["POST"])
def api_export_premiere(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt:
        return jsonify({"error": "No subtitle (.srt) found — generate subtitles first "
                                 "(the timeline is timed from the SRT)."}), 400
    if not _find_vo_audio(d):
        return jsonify({"error": "No voice-over audio found — generate or upload the voice-over first."}), 400
    vo = _normalized_vo(d)                     # loudness-normalized VO for a consistent VSL level
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = premiere_export.build_premiere_xml(
            doc.get("title") or project, d, doc, _srt_text, vo,
            BGM_ROOT, claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
    except Exception as e:
        return jsonify({"error": f"Export failed: {e}"}), 500
    out_name = f"{fname_slug(doc.get('title') or project)}_Premiere_{today_ddmmyyyy()}.xml"
    (d / "export").mkdir(parents=True, exist_ok=True)
    (d / "export" / out_name).write_text(xml, encoding="utf-8")
    return jsonify({"ok": True, "file": f"export/{out_name}", "name": out_name, "info": info})


# ---- routes: named downloads (Export tab) ----------------------------------
def _vsl_name(doc, project, typ, ext):
    """Filename convention: <Project>_VSL_<Type>_<DDMMYYYY>.<ext>."""
    return f"{fname_slug(doc.get('title') or project)}_VSL_{typ}_{today_ddmmyyyy()}.{ext}"


def _used_bgm_paths(info):
    """Reconstruct the on-disk paths of the background-music tracks the export actually used."""
    out = []
    for m in (info or {}).get("music", []):
        if m.get("track"):
            p = BGM_ROOT / m["emotion"] / m["track"]
            if p.exists():
                out.append(p)
    return out


@app.route("/api/download/<project>/<kind>")
def api_download(project, kind):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    if kind == "subtitle":
        srt = _find_srt(d)
        if not srt:
            return jsonify({"error": "No subtitle (.srt) yet — generate it in the Script & Voiceover tab."}), 404
        # split at scene boundaries + frame-quantize so captions and clips switch together in Premiere
        q = _delivery_srt(d, doc, srt)
        return send_file(io.BytesIO(q.encode("utf-8")), mimetype="application/x-subrip",
                         as_attachment=True, download_name=_vsl_name(doc, project, "Subtitle", "srt"))
    if kind == "voiceover":
        if not _find_vo_audio(d):
            return jsonify({"error": "No voice-over yet — generate it in the Script & Voiceover tab."}), 404
        vo = _normalized_vo(d)                  # deliver the level-normalized voice-over
        return send_file(vo, as_attachment=True, download_name=_vsl_name(doc, project, "Voiceover", "mp3"))
    if kind == "script":
        txt = (doc.get("script") or "").strip()
        if not txt:
            return jsonify({"error": "No script yet — paste it in the Script & Voiceover tab."}), 404
        (d / "export").mkdir(parents=True, exist_ok=True)
        p = d / "export" / "_script.docx"
        text_to_docx(txt, p)
        return send_file(p, as_attachment=True, download_name=_vsl_name(doc, project, "Script", "docx"))
    if kind == "premiere":
        srt = _find_srt(d)
        if not srt or not _find_vo_audio(d):
            return jsonify({"error": "Need a subtitle (.srt) and a voice-over first."}), 400
        vo = _normalized_vo(d)
        try:
            _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
            xml, _info = premiere_export.build_premiere_xml(
                doc.get("title") or project, d, doc, _srt_text, vo, BGM_ROOT,
                claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
        except Exception as e:
            return jsonify({"error": f"Assembly failed: {e}"}), 500
        out_name = _vsl_name(doc, project, "Premiere_Project", "xml")
        (d / "export").mkdir(parents=True, exist_ok=True)
        (d / "export" / out_name).write_text(xml, encoding="utf-8")
        return send_file(d / "export" / out_name, as_attachment=True, download_name=out_name)
    if kind in ("images", "videos"):
        # skip phantom scenes (manual lines not in the voice-over) when an SRT exists to detect them
        srtp = _find_srt(d)
        phantom = premiere_export.excluded_scene_ids(
            doc["scenes"], premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))) if srtp else set()
        buf = io.BytesIO()
        n = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for s in doc["scenes"]:
                if s.get("id") in phantom:
                    continue
                if kind == "images":
                    if not s.get("approved"):
                        continue
                    f = s["image"].get("approved_file") or s["image"].get("file")
                    if f and (d / f).exists():
                        z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png"); n += 1
                else:
                    v = s.get("video", {})
                    if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                        z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4"); n += 1
        if not n:
            return jsonify({"error": f"No approved {kind} to download."}), 404
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name=_vsl_name(doc, project, kind.capitalize(), "zip"))
    abort(404)


@app.route("/api/download/<project>/all")
def api_download_all(project):
    """One ZIP with the whole deliverable: Premiere .xml, SRT, voice-over, script .docx, each
    scene's approved video (or its approved image where no video), and the used music tracks."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt or not _find_vo_audio(d):
        return jsonify({"error": "Need at least a subtitle (.srt) and a voice-over first."}), 400
    vo = _normalized_vo(d)                      # level-normalized VO (same file the timeline uses)
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = premiere_export.build_premiere_xml(
            doc.get("title") or project, d, doc, _srt_text, vo, BGM_ROOT,
            claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
    except Exception as e:
        return jsonify({"error": f"Assembly failed: {e}"}), 500
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(_vsl_name(doc, project, "Premiere_Project", "xml"), xml)
        # SRT split at scene boundaries + frame-quantized so captions/clips switch together in Premiere
        z.writestr(_vsl_name(doc, project, "Subtitle", "srt"), _delivery_srt(d, doc, srt))
        z.write(vo, _vsl_name(doc, project, "Voiceover", vo.suffix.lstrip(".") or "mp3"))
        txt = (doc.get("script") or "").strip()
        if txt:
            sp = d / "export" / "_script.docx"
            (d / "export").mkdir(parents=True, exist_ok=True)
            text_to_docx(txt, sp)
            z.write(sp, _vsl_name(doc, project, "Script", "docx"))
        # per scene: approved video, else approved image (only for approved scenes). Phantom scenes
        # (manual lines not in the voice-over) are skipped so the bundle matches the timeline.
        phantom = premiere_export.excluded_scene_ids(doc["scenes"],
                                                     premiere_export.parse_srt(srt.read_text(encoding="utf-8", errors="ignore")))
        dl_video = dl_image = 0
        for s in doc["scenes"]:
            if s.get("id") in phantom:
                continue
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
                dl_video += 1
            elif s.get("approved"):
                f = s["image"].get("approved_file") or s["image"].get("file")
                if f and (d / f).exists():
                    z.write(d / f, f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.png")
                    dl_image += 1
        for p in _used_bgm_paths(info):
            z.write(p, f"music/{p.name}")
    # counts of what was ACTUALLY put in the zip (video where approved, else approved image)
    info["dl_video"] = dl_video
    info["dl_image"] = dl_image
    buf.seek(0)
    resp = send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=_vsl_name(doc, project, "All_Files", "zip"))
    resp.headers["X-Export-Info"] = _urlquote(json.dumps(info))   # content summary for the UI
    resp.headers["Access-Control-Expose-Headers"] = "X-Export-Info"
    return resp


@app.route("/media/<project>/<path:relpath>")
def api_media(project, relpath):
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not str(fp).startswith(str(d.resolve())) or not fp.exists():
        abort(404)
    dl = request.args.get("dl")
    if dl:  # force a download with a specific filename
        return send_file(fp, as_attachment=True, download_name=dl)
    return send_file(fp)


@app.route("/bgm/<path:relpath>")
def api_bgm(relpath):
    """Serve a background-music track (lives outside any project, under BGM_ROOT) for the preview."""
    fp = (BGM_ROOT / relpath).resolve()
    if not str(fp).startswith(str(BGM_ROOT.resolve())) or not fp.exists():
        abort(404)
    return send_file(fp)


def _delivery_srt(d, doc, srt_path):
    """The SRT we hand to the user: captions split at scene boundaries + frame-quantized (matches the
    exported clip cuts and the preview). Falls back to the plain quantized SRT on any problem."""
    srt_text = srt_path.read_text(encoding="utf-8", errors="ignore")
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return premiere_export.quantize_srt_to_frames(srt_text)
        vo = _find_vo_audio(d)
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        words = premiere_export.load_word_tsv(d / "subtitle")
        return premiere_export.delivery_srt(doc.get("scenes", []), cues, total, words)
    except Exception:
        return premiere_export.quantize_srt_to_frames(srt_text)


def _emotion_tracks():
    """{EMOTION: [track filenames]} across the Background Music folders."""
    out = {}
    for emo in premiere_export.EMOTIONS:
        folder = BGM_ROOT / emo
        out[emo] = sorted(p.name for p in folder.iterdir()
                          if p.suffix.lower() in (".wav", ".mp3")) if folder.exists() else []
    return out


def _resolve_music(project, doc, cues, total, save=True):
    """Build-ready music segments that honor the SAVED plan + per-segment track overrides. The plan
    (Claude emotion-segmentation + auto-picked tracks) is computed ONCE and cached in doc.music_plan;
    later builds reuse it (so overrides stick and Claude isn't re-called every time)."""
    plan = doc.get("music_plan")
    valid = isinstance(plan, list) and plan and abs((plan[-1].get("end") or 0) - total) < 4.0
    if not valid:
        picked = premiere_export.pick_music(premiere_export.segment_emotions(cues, total, _claude_text), BGM_ROOT)
        plan = [{"start": round(s["start"], 3), "end": round(s["end"], 3), "emotion": s["emotion"],
                 "track": (Path(s["path"]).name if s.get("path") else None)} for s in picked]
        doc["music_plan"] = plan
        if save:
            save_doc(project, doc)
    cache_path = BGM_ROOT / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    out = []
    for seg in plan:
        emo, track = seg.get("emotion"), seg.get("track")
        path = (BGM_ROOT / emo / track) if (track and (BGM_ROOT / emo / track).exists()) else None
        if path is None:                                    # track missing → any track in the folder
            folder = BGM_ROOT / emo
            files = sorted(p for p in folder.iterdir() if p.suffix.lower() in (".wav", ".mp3")) if folder.exists() else []
            path = files[0] if files else None
        lufs, tp = premiere_export.measure_lufs(path, cache) if path else (None, None)
        out.append({"start": seg["start"], "end": seg["end"], "emotion": emo, "path": path,
                    "src_dur": premiere_export.audio_duration(path) if path else None, "lufs": lufs, "tp": tp})
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception:
        pass
    return out


def _export_music(project, doc, srt_text, vo):
    """The music segments (saved/overridable plan) for the Premiere export — same plan as the preview."""
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return None
        total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
        return _resolve_music(project, doc, cues, total)
    except Exception:
        return None


@app.route("/api/music-tracks")
def api_music_tracks(project=None):
    return jsonify(_emotion_tracks())


@app.route("/api/music-override/<project>", methods=["POST"])
def api_music_override(project):
    """Set a specific segment's track (index into doc.music_plan)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx, track = body.get("index"), body.get("track")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    emo = plan[idx].get("emotion")
    if track and not (BGM_ROOT / emo / track).exists():
        return jsonify({"error": "track not found in that mood folder"}), 400
    plan[idx]["track"] = track
    save_doc(project, doc)
    resp = {"ok": True, "url": None, "level": None}
    if track:
        path = BGM_ROOT / emo / track
        cache_path = BGM_ROOT / ".loudness_cache.json"
        try:
            cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
        except Exception:
            cache = {}
        lufs, tp = premiere_export.measure_lufs(path, cache)
        try:
            cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
        except Exception:
            pass
        resp["level"] = round(premiere_export.music_level(lufs, tp), 3)
        resp["url"] = "/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()
    return jsonify(resp)


@app.route("/api/music-resegment/<project>", methods=["POST"])
def api_music_resegment(project):
    """Forget the cached plan so the next build re-segments the music from scratch."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["music_plan"] = []
    save_doc(project, doc)
    return jsonify({"ok": True})


def _build_timeline(project, doc):
    """The single source of truth for 'the assembled VSL': each scene's media + audio-driven
    time range, the scene-split caption cues, the normalized voice-over, and the emotion-
    segmented music with per-segment levels. Uses the SAME timing/music logic as the Premiere
    export, so preview == rendered MP4 == exported timeline.

    Media are LOCAL PATHS here; api_preview maps them to /media URLs for the browser and
    render_video feeds them straight to ffmpeg. Raises ValueError if the inputs aren't ready.
    """
    d, _ = proj_dir(project)
    srtp = _find_srt(d)
    vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    vo_dur = premiere_export.audio_duration(vo) or 0.0
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # accurate spoken-word onsets for mid-cue scenes (same as the export uses)
    words = premiere_export.load_word_tsv(d / "subtitle")
    word_starts = premiere_export.word_scene_starts(scenes, words) if words else None
    ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
    cue_tok_times = premiere_export.accurate_cue_token_times(cues, words) if words else None

    # Snap every boundary to a whole video frame. Both scene starts and caption starts get the
    # SAME quantizer, so a scene and its caption switch on the exact same frame in the preview,
    # AND the rendered clip durations become integer frames (no ffmpeg cumulative-rounding drift).
    _FPS = premiere_export.FPS
    def qf(t):
        return round(round(t * _FPS) / _FPS, 5)   # 5 dp keeps the exact frame value (frame/60 repeats)

    out_scenes = []
    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc or t1 <= t0:
            continue
        vid = s.get("video") or {}
        img = s.get("image") or {}
        item = {"id": s.get("id"), "start": qf(t0), "end": qf(t1),
                "label": premiere_export.scene_label(s), "kind": "blank", "path": None, "img": None,
                # on-screen text overlays (burned onto the video, shown in preview + render)
                "texts": _scene_overlays(s),
                "transition": s.get("transition") or "none"}   # how this scene hands off to the next
        # the approved still image (if any) — the smooth fallback for the "images only" toggle
        imgf = (img.get("approved_file") or img.get("file")) if s.get("approved") else None
        if imgf and (d / imgf).exists():
            item["img"] = d / imgf
        if vid.get("approved") and vid.get("status") == "ready" and vid.get("file") and (d / vid["file"]).exists():
            item.update(kind="video", path=d / vid["file"])
        elif item["img"]:
            item.update(kind="image", path=item["img"])
        out_scenes.append(item)

    # split captions at scene boundaries so a caption and its scene switch together
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    caps = premiere_export.split_captions_at_scenes(cues, scene_starts, cue_tok_times)
    # same frame-quantizer as the scenes → caption starts land on the exact scene-start frame
    captions = [{"start": qf(c["start"]), "end": qf(c["end"]), "text": c["text"]}
                for c in caps if qf(c["end"]) > qf(c["start"])]

    music = []
    tracks_by_emotion = _emotion_tracks()
    try:
        segs = _resolve_music(project, doc, cues, total)     # saved/overridable plan
    except Exception:
        segs = []
    for i, seg in enumerate(segs):
        p = seg.get("path")
        emo = seg["emotion"]
        music.append({"index": i, "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                      "emotion": emo, "track": (Path(p).name if p else None),
                      "path": Path(p) if p else None,
                      "level": round(premiere_export.music_level(seg.get("lufs"), seg.get("tp")), 3),
                      "options": tracks_by_emotion.get(emo, [])})

    return {"total": round(total, 3), "vo": vo, "dir": d,
            "scenes": out_scenes, "captions": captions, "music": music,
            "sub_style": doc.get("subtitle_style") or None}


@app.route("/api/preview/<project>")
def api_preview(project):
    """Manifest for the in-dashboard rough-cut player. The client plays it synced — no
    server-side render (that's /api/render, which consumes the same timeline)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    try:
        tl = _build_timeline(project, doc)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    d = tl["dir"]

    # Remember that this project has a watchable preview, so re-opening it later can
    # restore the player without the user clicking Build Preview again. Re-read right before
    # writing so this GET can't clobber a concurrent scene edit (e.g. on-screen text just added)
    # that was saved between our load_doc above and here — only the flag is persisted.
    if not doc.get("preview_built"):
        fresh = load_doc(project) or doc
        fresh["preview_built"] = True
        save_doc(project, fresh)
        doc["preview_built"] = True

    def murl(p):
        return f"/media/{project}/{Path(p).relative_to(d).as_posix()}"

    out_scenes = []
    for s in tl["scenes"]:
        item = {"id": s["id"], "start": s["start"], "end": s["end"], "label": s["label"],
                "type": s["kind"],
                "url": murl(s["path"]) if s["path"] else None,
                "img": murl(s["img"]) if s["img"] else None}
        item["texts"] = s.get("texts") or []   # on-screen text overlays for this scene
        item["transition"] = s.get("transition") or "none"
        out_scenes.append(item)
    music = []
    for m in tl["music"]:
        e = {k: m[k] for k in ("index", "start", "end", "emotion", "track", "level", "options")}
        e["url"] = ("/bgm/" + m["path"].resolve().relative_to(BGM_ROOT.resolve()).as_posix()
                    ) if m["path"] else None
        music.append(e)

    return jsonify({"duration": tl["total"], "vo": murl(tl["vo"]),
                    "scenes": out_scenes, "captions": tl["captions"], "music": music})


# ---- routes: server-side MP4 render ----------------------------------------
RENDER_STATUS, RENDER_LOCK = {}, threading.Lock()
RENDER_PROCS = {}                 # project -> the running ffmpeg Popen (so a cancel can kill it)
RENDER_CANCEL = set()             # projects whose current render was cancelled by the user


def set_render_status(project, **kw):
    with RENDER_LOCK:
        st = RENDER_STATUS.get(project, {})
        st.update(kw); st["updated"] = time.time()
        RENDER_STATUS[project] = st
    return st


RENDER_HISTORY_KEEP = 8

def _archive_render(out_path, fast, doc, project, dur):
    """Keep a named copy of a finished render so it isn't lost when the next render overwrites
    render.mp4 / render_test.mp4. Real renders go to export/renders/, quick test renders to
    export/test-renders/. Filenames carry the project + date; test renders also carry their length in
    seconds (e.g. MyVSL_VSL_Test_26072026-143512_30s.mp4). Each folder is pruned to RENDER_HISTORY_KEEP."""
    try:
        export = Path(out_path).parent
        slug = fname_slug((doc or {}).get("title") or project)
        stamp, clock = today_ddmmyyyy(), time.strftime("%H%M%S")
        if fast:
            hist = export / "test-renders"
            fname = f"{slug}_VSL_Test_{stamp}-{clock}_{max(1, int(round(dur or 0)))}s.mp4"
        else:
            hist = export / "renders"
            fname = f"{slug}_VSL_Video_{stamp}-{clock}.mp4"
        hist.mkdir(exist_ok=True)
        shutil.copy2(out_path, hist / fname)
        files = sorted(hist.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[RENDER_HISTORY_KEEP:]:
            try:
                old.unlink()
            except OSError:
                pass
    except Exception:
        pass

def run_render_job(project, doc, out_path, name, opts):
    """Background thread: build the timeline, hand it to ffmpeg, track progress."""
    with RENDER_LOCK:
        RENDER_CANCEL.discard(project)          # fresh run — clear any stale cancel flag
    try:
        set_render_status(project, status="running", pct=0, step="Preparing timeline…", error=None)
        tl = _build_timeline(project, doc)
        set_render_status(project, step="Rendering video…", duration=tl["total"])

        def on_progress(pct, done):
            set_render_status(project, pct=pct, step="Rendering video…")

        def on_status(text):
            set_render_status(project, step=text)

        def on_proc(p):
            with RENDER_LOCK:
                RENDER_PROCS[project] = p
                cancel_now = project in RENDER_CANCEL   # cancel arrived before ffmpeg started
            if cancel_now:
                try: p.terminate()
                except Exception: pass

        render_video.render(tl, out_path, out_path.parent / "_render_tmp", opts, on_progress, on_proc, on_status)
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL        # cancel that raced past the kill
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
            return
        size = out_path.stat().st_size
        _rng = opts.get("range")
        _rendered_dur = (_rng[1] - _rng[0]) if _rng else float(tl.get("total") or 0)
        _archive_render(out_path, bool(opts.get("fast")), doc, project, _rendered_dur)   # named copy in the render history
        set_render_status(project, status="done", pct=100, step="Done",
                          file=f"export/{out_path.name}", name=name, size=size,
                          subs=opts.get("burnsubs", True), fast=bool(opts.get("fast")), error=None)
    except Exception as e:
        # a cancel kills ffmpeg -> render() raises; report that as "cancelled", not an error
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()               # drop the half-written file
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
        else:
            set_render_status(project, status="error", error=str(e))
    finally:
        with RENDER_LOCK:
            RENDER_PROCS.pop(project, None)


@app.route("/api/render/<project>", methods=["POST"])
def api_render_start(project):
    """Kick off the MP4 render (captions burned in, voice-over + music mixed)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if get_render_status(project).get("status") == "running":
        return jsonify({"error": "A render is already running for this project."}), 409
    d, _ = proj_dir(project)
    try:
        _build_timeline(project, doc)          # fail fast with a clear message
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    body = request.get_json(silent=True) or {}
    fast = bool(body.get("fast"))          # quick low-res test render (720p30, ultrafast) to check sync/timing
    music = body.get("music", True) is not False
    opts = {"kenburns": bool(body.get("kenburns")),
            "music": music,
            "crossfade": music,          # cross-fade only matters when music is present
            "burnsubs": body.get("burnsubs", True) is not False,
            "onscreentext": body.get("onscreentext", True) is not False,
            "transitions": body.get("transitions", True) is not False,
            "gpu": bool(body.get("gpu")),                 # encode with the GPU (NVENC) if available
            "low_priority": bool(body.get("low_priority")),  # run ffmpeg below-normal + fewer threads
            "fast": fast}
    # optional partial render: only encode [range_start, range_end] seconds of the timeline
    try:
        rs, re_ = body.get("range_start"), body.get("range_end")
        if rs is not None and re_ is not None and float(re_) > float(rs):
            opts["range"] = (float(rs), float(re_))
    except (TypeError, ValueError):
        pass
    name = _vsl_name(doc, project, "Test-Video" if fast else "Video", "mp4")
    out = d / "export" / ("render_test.mp4" if fast else "render.mp4")
    set_render_status(project, status="running", pct=0, step="Queued…", file=None, error=None)
    threading.Thread(target=run_render_job, args=(project, doc, out, name, opts), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/renders/<project>")
def api_list_renders(project):
    """List the timestamped render-history files (newest first)."""
    d, _ = proj_dir(project)
    out = []
    for sub, is_test in (("renders", False), ("test-renders", True)):
        hist = d / "export" / sub
        if not hist.exists():
            continue
        for p in hist.glob("*.mp4"):
            st = p.stat()
            out.append({"name": p.name, "file": f"export/{sub}/{p.name}",
                        "size": st.st_size, "mtime": st.st_mtime, "test": is_test})
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return jsonify({"renders": out})

@app.route("/api/renders/<project>/<name>/delete", methods=["POST"])
def api_delete_render(project, name):
    """Delete one render-history file (guarded to the project's renders/ + test-renders/ folders)."""
    d, _ = proj_dir(project)
    for sub in ("renders", "test-renders"):
        hist = (d / "export" / sub).resolve()
        p = (hist / name).resolve()
        if p.suffix == ".mp4" and p.parent == hist and p.exists():
            try:
                p.unlink()
            except OSError:
                pass
            break
    return jsonify({"ok": True})

@app.route("/api/render/<project>/cancel", methods=["POST"])
def api_render_cancel(project):
    """Stop an in-progress render: mark it cancelled and kill the ffmpeg process."""
    if get_render_status(project).get("status") != "running":
        return jsonify({"error": "No render is running for this project."}), 409
    with RENDER_LOCK:
        RENDER_CANCEL.add(project)
        proc = RENDER_PROCS.get(project)
    if proc and proc.poll() is None:
        try:
            proc.terminate()                     # ends ffmpeg -> the render thread finishes as "cancelled"
        except Exception:
            pass
    set_render_status(project, step="Cancelling…")
    return jsonify({"ok": True})


def get_render_status(project):
    with RENDER_LOCK:
        return dict(RENDER_STATUS.get(project) or {"status": "idle"})


@app.route("/api/render/<project>")
def api_render_status(project):
    return jsonify(get_render_status(project))

if __name__ == "__main__":
    print(f"KIE key: {'set' if KIE_KEY else 'MISSING'} | projects dir: {PROJECTS}")
    # Prefer port 80 (so the URL needs no ':port' → http://vsldashboard / http://localhost).
    # Fall back to 8000 if 80 is taken, so the dashboard always comes up.
    _port = int(os.environ.get("VSL_PORT", "80"))
    # Bind to 127.0.0.1 (this PC only) by default. Set VSL_HOST=0.0.0.0 to also serve it to other
    # machines on the network / over a Tailscale or tunnel connection. Only do that on a trusted
    # network or behind Tailscale — the dashboard has NO login and holds your API keys.
    _host = os.environ.get("VSL_HOST", "127.0.0.1")
    try:
        print(f"Serving on http://localhost:{_port}/  (http://vsldashboard/ after setup-vsldashboard.bat)")
        app.run(host=_host, port=_port, threaded=True, debug=False)
    except OSError:
        print("port 80 unavailable -- falling back to http://localhost:8000/")
        app.run(host=_host, port=8000, threaded=True, debug=False)
