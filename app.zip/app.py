"""
VSL Scene Dashboard — local control panel for the script -> prompt -> image -> video pipeline.

Everything is driven by one file per project: projects/<name>/scenes.json
Both this app and Claude Code read/write that file, so prompts authored in Claude Code
show up here instantly, and edits made here are visible to Claude Code.

Run:  python app.py    ->  http://localhost:8000
"""
import os, re, json, time, hashlib, io, threading, shutil, zipfile, subprocess, uuid
from urllib.parse import quote as _urlquote, unquote as _urlunquote, urlparse as _urlparse
from pathlib import Path
from datetime import datetime, timedelta
import requests
from PIL import Image
from flask import Flask, request, jsonify, send_file, abort, render_template, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import premiere_export
import render_video

# The dashboard runs windowless (pythonw), so every child process would otherwise pop up
# its own console — a black box flashing over the screen once per ffmpeg/ffprobe call.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

BASE = Path(__file__).resolve().parent
# All user-writable data (projects, keys, login, voices) lives under DATA_DIR. It defaults to BASE
# so a plain dev checkout is unchanged; the packaged desktop app sets VSL_DATA_DIR to its portable
# data/ folder so everything the user creates stays in one place next to the .exe.
DATA_DIR = Path(os.environ["VSL_DATA_DIR"]).resolve() if os.environ.get("VSL_DATA_DIR") else BASE
DATA_DIR.mkdir(parents=True, exist_ok=True)
ENV_PATH = (DATA_DIR / ".env") if os.environ.get("VSL_DATA_DIR") else (BASE.parent / ".env")   # API keys
PROJECTS = DATA_DIR / "projects"
PROJECTS.mkdir(exist_ok=True)
BGM_ROOT = BASE / "Background Music"      # app resource (read-only) — ships with the app, not data

# ---- config / secrets -------------------------------------------------------
def load_env():
    env = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env

def write_env(updates):
    """Update/insert KEY=VALUE lines in the .env, preserving every other line (comments, spacing,
    unrelated keys). Used by the in-app API-keys editor so a new user can plug in their own keys."""
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    seen, out = set(), []
    for line in lines:
        s = line.strip()
        if s and not s.startswith("#") and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in updates:
                out.append(f"{k}={updates[k]}"); seen.add(k); continue
        out.append(line)
    for k, v in updates.items():
        if k not in seen:
            out.append(f"{k}={v}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")

ENV = load_env()

# ---- local login (no internet / no domain needed) ---------------------------
# auth.json lives next to the app (part of the copied folder). The admin sets per-person
# credentials by editing it; passwords typed in plaintext are hashed on first load, so the
# file ends up storing only hashes. A random session secret is generated once and persisted
# so logins survive server restarts.
AUTH_PATH = DATA_DIR / "auth.json"

def _is_hashed(v):
    v = str(v)
    return v.startswith("pbkdf2:") or v.startswith("scrypt:") or v.startswith("argon2")

def load_auth():
    if AUTH_PATH.exists():
        try:
            data = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    else:
        data = {}
    users = data.get("users") or {}
    if not users:                                   # first run: seed a default admin/admin
        users = {"admin": "admin"}
        data["users"] = users
    changed = False
    # hash any plaintext passwords the admin typed by hand
    for u, p in list(users.items()):
        if not _is_hashed(p):
            users[u] = generate_password_hash(str(p))
            changed = True
    if not data.get("secret"):                      # persistent session secret
        data["secret"] = os.urandom(24).hex()
        changed = True
    if changed or not AUTH_PATH.exists():
        try:
            AUTH_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass
    return data

AUTH = load_auth()

def check_login(username, password):
    h = (AUTH.get("users") or {}).get((username or "").strip())
    if not h:
        return False
    try:
        return check_password_hash(h, password or "")
    except Exception:
        return False

KIE_KEY = ENV.get("KIE_API_KEY", "")
CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
ELEVEN_MODEL = "eleven_multilingual_v2"   # good multilingual quality; matches script language automatically
VOICES_PATH = DATA_DIR / "voices.json"    # frequently-used ElevenLabs voices (name -> voice_id); user-editable → data
OST_PRESETS_PATH = DATA_DIR / "ost_presets.json"   # saved on-screen-text style presets (shared across projects)

KIE_BASE = "https://api.kie.ai/api/v1/jobs"
IMAGE_MODEL = "nano-banana-2"
# selectable per-scene image model families (label shown in the UI dropdown). Each family
# auto-resolves to a text-to-image or image-to-image Kie model id depending on whether the
# scene has reference images — see build_kie_image_request().
IMAGE_MODELS = [
    {"key": "nano-banana-2", "label": "NanoBanana 2"},
    {"key": "gpt-image-2", "label": "GPT Image 2"},
    {"key": "seedream-5-pro", "label": "Seedream 5.0 Pro"},
]
IMAGE_MODEL_KEYS = {m["key"] for m in IMAGE_MODELS}
IMAGE_MODELS_READY = IMAGE_MODEL_KEYS     # all wired

def build_kie_image_request(family, prompt, refs):
    """Map a dropdown model family (+ whether refs exist) to the exact Kie model id and input
    body. Reference images -> image-to-image variant; none -> text-to-image. All 16:9 / 2K."""
    refs = refs or []
    has = bool(refs)
    if family == "gpt-image-2":
        if has:
            return "gpt-image-2-image-to-image", {"prompt": prompt, "input_urls": refs[:16], "aspect_ratio": "16:9", "resolution": "2K"}
        return "gpt-image-2-text-to-image", {"prompt": prompt, "aspect_ratio": "16:9", "resolution": "2K"}
    if family == "seedream-5-pro":
        if has:
            return "seedream/5-pro-image-to-image", {"prompt": prompt, "image_urls": refs[:10], "aspect_ratio": "16:9", "quality": "high", "output_format": "png"}
        return "seedream/5-pro-text-to-image", {"prompt": prompt, "aspect_ratio": "16:9", "quality": "high", "output_format": "png"}
    # default: nano-banana-2 (one model id, optional image_input)
    inp = {"prompt": prompt, "aspect_ratio": "16:9", "resolution": "2K", "output_format": "png"}
    if has:
        inp["image_input"] = refs
    return "nano-banana-2", inp
# ---- video models --------------------------------------------------------
# Each family: durations (seconds the model supports) + resolutions, so the UI can adapt
# the dropdowns per model. `api` = which endpoint/flow to use ("jobs" = unified createTask,
# "veo" = the separate /api/v1/veo endpoint). `id` = the Kie model id (or veo model tier).
VIDEO_MODELS = [
    {"key": "seedance-2-fast", "label": "Seedance 2.0 Fast", "id": "bytedance/seedance-2-fast", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
    {"key": "seedance-2", "label": "Seedance 2.0", "id": "bytedance/seedance-2", "api": "jobs",
     "durations": [4, 5, 6, 7, 8, 9, 10, 11, 12], "resolutions": ["480p", "720p", "1080p", "4k"], "defaultDur": 5, "defaultRes": "1080p"},
    {"key": "veo-3-1", "label": "Veo 3.1", "id": "veo3_fast", "api": "veo",
     "durations": [4, 6, 8], "resolutions": ["720p", "1080p", "4k"], "defaultDur": 8, "defaultRes": "1080p"},
    {"key": "grok-imagine", "label": "Grok Imagine", "id": "grok-imagine/image-to-video", "api": "jobs",
     "durations": [6, 8, 10, 12, 15, 20, 25, 30], "resolutions": ["480p", "720p"], "defaultDur": 6, "defaultRes": "720p"},
]
VIDEO_MODEL_BY_KEY = {m["key"]: m for m in VIDEO_MODELS}
DEFAULT_VIDEO_MODEL = "seedance-2-fast"
VIDEO_CONFIGURED = True

def _clamp_video_opts(cfg, duration, resolution):
    dur = duration if duration in cfg["durations"] else cfg["defaultDur"]
    res = resolution if resolution in cfg["resolutions"] else cfg["defaultRes"]
    return dur, res

def build_video_request(model_key, img_url, prompt, duration, resolution):
    """Return (api_type, model_id, payload) for the chosen video model. jobs -> {model,input}
    body for kie_create; veo -> flat body for /api/v1/veo/generate."""
    cfg = VIDEO_MODEL_BY_KEY.get(model_key) or VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]
    dur, res = _clamp_video_opts(cfg, duration, resolution)
    mid = cfg["id"]
    if cfg["api"] == "veo":
        return "veo", mid, {"prompt": prompt, "imageUrls": [img_url], "model": mid,
                            "aspect_ratio": "16:9", "resolution": res, "duration": dur}
    if model_key == "grok-imagine":
        return "jobs", mid, {"prompt": prompt, "image_urls": [img_url], "mode": "normal",
                             "duration": str(dur), "resolution": res, "aspect_ratio": "16:9"}
    # seedance family
    return "jobs", mid, {"prompt": prompt, "first_frame_url": img_url, "generate_audio": False,
                         "duration": dur, "resolution": res, "aspect_ratio": "16:9"}

def kie_veo_create(payload):
    def _do():
        r = requests.post("https://api.kie.ai/api/v1/veo/generate",
                          headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                          json=payload, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"].get("taskId"), None
    return None, d.get("msg", "unknown error")

def kie_veo_record(task_id):
    def _do():
        r = requests.get("https://api.kie.ai/api/v1/veo/record-info", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=60)
        return r.json()
    return _retry(_do)

# Prompt generation runs through Kie.ai's Anthropic-native Claude endpoint,
# so it uses the SAME KIE_API_KEY — no separate Anthropic key needed.
KIE_CLAUDE_URL = "https://api.kie.ai/claude/v1/messages"
# Quality-first, right-tool-per-task:
#  - SMART_MODEL = Fable 5 (Anthropic's most capable model) for the single hardest pass (whole-script
#    analyze). Thinking is always on and can run long, but it's one call per split, so it pays off.
#  - PROMPT_MODEL = Opus 4.8 for everything high-volume/fast (split cut, camera, per-scene image/video
#    prompt, music). Fable there would make "Generate All" very slow and can return empty on tight budgets.
PROMPT_MODEL = "claude-opus-4-8"
SMART_MODEL = "claude-fable-5"

# Per-scene visual style. The preset text below is injected into the image prompt as the "how it looks"
# layer (medium + lighting + composition + quality); the scene text stays style-free so they can't conflict.
STYLE_KEYS = ["natural", "2d", "scientific"]
DEFAULT_STYLE = "natural"   # every new/split scene starts Realistic; the user flips it per scene as needed
STYLE_PRESETS = {
    "natural": "Photorealistic but candid and slightly amateur — like a real everyday photo taken by an ordinary person on a normal phone or consumer camera, NOT a polished stock photo and NOT a studio shot. Natural available light only (window or ordinary room light), soft and a little uneven, no studio lighting or softboxes, gentle real-world shadows. Ordinary everyday camera angles and framing, slightly imperfect, handheld feel. Natural true-to-life colors, not over-saturated or heavily color-graded. Real ordinary people (not models) with authentic skin texture — visible pores, fine lines, minor blemishes; absolutely no skin smoothing, airbrushing, or retouching. Believable, unposed, documentary/candid snapshot feel. Avoid glossy stock-photo perfection, studio lighting, cinematic color grading, and flawless model faces.",
    "2d": "2D cartoon illustration in a modern Western TV / adult-animation explainer style (a clean, friendly cartoon still). BOLD, clean, evenly-weighted dark outlines around every shape; FLAT colors with simple soft cel-shading (a few gentle gradient bands, NOT realistic rendering); soft glossy highlights on rounded or curved surfaces. Warm, friendly, slightly muted palette. Characters are simplified and expressive with large clear cartoon eyes and clean simple features. COMPOSITION (important): place the subject on a plain solid WHITE background, centered and isolated, with ONLY the one or two props essential to the action — NO full detailed room, NO busy scenery, NO edge-to-edge environment, no floor/wall/furniture filling the frame. Leave generous empty white space around the subject — a clean, uncluttered explainer frame. The ONLY exception, where a detailed full-frame illustration may cover the whole background, is anatomical / inside-the-body / organ / cellular / medical-diagram content — render THOSE as a clean CARTOON cross-section with the same bold outlines, flat cel-shading and soft glowing accents (still a cartoon, not a realistic render). Clean hand-drawn / vector cartoon look — NOT photorealistic, NOT a 3D CGI render, NOT a photo.",
    "scientific": "Photorealistic 3D CGI medical / anatomical visualization — the look of a high-end medical stock animation still (a Blender/Cinema-4D render), NOT a diagram, NOT a cartoon, NOT a real photo. Hyper-detailed, realistically 3D-rendered anatomy with glossy, wet, sub-surface-scattering surfaces, realistic materials, soft reflections, and cinematic lighting with a shallow depth of field (background softly blurred). Two typical looks: (1) a specific organ (brain, heart, liver, gut…) glowing luminously inside a translucent, semi-transparent X-RAY-like body silhouette on a dark, moody background; or (2) a rich CLOSE-UP of internal biology — blood vessels / arteries in cross-section, flowing red blood cells, fat cells, cholesterol / plaque, gut bacteria — with translucent membranes, warm golden or clinical-blue tones, and gentle glowing highlights on the area of interest. Deep, dimensional, premium science-documentary feel with soft shadows and depth. NOT flat, NOT hand-drawn, NOT a 2D illustration, NOT a photograph of a real person.",
}

# Camera framing/angle. The scene prompt itself stays framing-free (see PROMPT_SYSTEM); the chosen
# angle's phrasing is appended to the final image prompt so it can't conflict. A few common,
# sensible angles only.
CAMERA_ANGLES = [
    {"key": "closeup", "label": "Close-up",          "prompt": "Framed as a CLOSE-UP shot: the camera is pushed in TIGHT on the main subject (a face or a single key detail), which fills most of the frame. Crop in close — the wider setting and any secondary people fall largely out of frame. This tight framing is REQUIRED and OVERRIDES the scene's default wider composition; reframe closer even if the scene reads as broader."},
    {"key": "extreme", "label": "Extreme Close-up",  "prompt": "Framed as an EXTREME CLOSE-UP (macro): the camera is EXTREMELY tight on ONE small detail, and that single detail FILLS THE ENTIRE FRAME. Crop out everything else — no wider scene, no room, no other people, no background context; only the one detail is visible, edge to edge. This is REQUIRED and OVERRIDES the scene's default composition; reframe drastically closer even if the described scene is much broader."},
    {"key": "medium",  "label": "Medium Shot",       "prompt": "Framed as a medium shot: the main subject shown from roughly the waist up."},
    {"key": "wide",    "label": "Wide Shot",         "prompt": "Framed as a wide establishing shot: the full subject and the surrounding environment are visible in frame."},
    {"key": "ots",     "label": "Over the Shoulder", "prompt": "Framed as an over-the-shoulder shot: the camera looks past the shoulder of ONE of the people ALREADY described in this scene toward whoever they are facing. Use ONLY those people — do NOT add, invent or insert any extra or anonymous person, and do NOT put a stranger's back in the foreground; the foreground shoulder MUST belong to one of the existing subjects. If the scene has only one person, keep a normal framing instead of forcing this."},
    {"key": "top",     "label": "Top View",          "prompt": "Shot from a top-down overhead angle, looking straight down on the scene (bird's-eye view)."},
    {"key": "side",    "label": "Side View",         "prompt": "Shot from a side profile angle, with the camera at ninety degrees to the subject."},
]
CAMERA_ANGLES_BY_KEY = {c["key"]: c for c in CAMERA_ANGLES}
CAMERA_KEYS = [c["key"] for c in CAMERA_ANGLES]
DEFAULT_CAMERA = "medium"

# Per-scene transition: how this scene hands off to the NEXT one (preview + render; not the Premiere XML).
TRANSITIONS = ["none", "crossfade", "dip-black", "dip-white",
               "slide-left", "slide-right", "slide-up", "slide-down"]
DEFAULT_TRANSITION = "none"

# Country -> language used for any visible text/signage in generated images
COUNTRY_LANG = {
    "United States": "English", "United Kingdom": "English",
    "France": "French", "Germany": "German",
}
def country_language(aud):
    locs = (aud or {}).get("locations") or []
    return COUNTRY_LANG.get(locs[0], "English") if locs else "English"

def looks_turkish(t):
    return any(ch in "çğıışöüÇĞİÖŞÜ" for ch in (t or ""))

def slugify(t, n=40):
    t = re.sub(r"[^a-zA-Z0-9]+", "-", (t or "").strip().lower()).strip("-")
    return t[:n] or "scene"

def fname_slug(t):
    """Underscore-joined name for output filenames, e.g. 'CitruSlim VSL' -> 'CitruSlim_VSL'."""
    return re.sub(r"[^A-Za-z0-9]+", "_", (t or "").strip()).strip("_") or "project"

def today_ddmmyyyy():
    return datetime.now().strftime("%d%m%Y")

def speaker_slug(voice_id):
    """Map a voice_id back to a saved voice name (underscored), or '' if not a saved voice."""
    for v in load_voices():
        if v.get("voice_id") == voice_id and v.get("name"):
            return fname_slug(v["name"])
    return ""

app = Flask(__name__)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0   # always serve fresh static assets during dev
app.config["TEMPLATES_AUTO_RELOAD"] = True    # pick up index.html edits without restart
# The desktop "Save As" (save_download in desktop.py) authenticates the local /media request with the
# cookie read from document.cookie — which excludes an HttpOnly session cookie, so the download 401'd
# ("login required") on some machines. This is a localhost-only app, so expose the session cookie to JS.
app.config["SESSION_COOKIE_HTTPONLY"] = False
# VSL_FRESH_SESSION (set by the desktop launcher) → a new key every run, so a previous session
# cookie no longer validates and the login gate always shows on launch. Dev/browser keeps the
# persisted key so it stays logged in across server restarts.
app.secret_key = os.urandom(24).hex() if os.environ.get("VSL_FRESH_SESSION") else (AUTH.get("secret") or os.urandom(24).hex())
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)   # stay logged in for a month

# ---- per-user data isolation ------------------------------------------------
# Each account gets its OWN projects + API keys under data/users/<name>/. One user is "active" per
# running instance (the desktop app signs one person in per launch); before_request re-points the
# project/key globals whenever the signed-in user changes, so baran and merih never see each other's
# projects or keys. voices.json / ost_presets.json stay shared (they hold no per-user secrets).
USERS_ROOT = DATA_DIR / "users"
try:
    USERS_ROOT.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

def _safe_user(u):
    return re.sub(r"[^a-zA-Z0-9_-]", "-", (u or "").strip()).strip("-") or "user"

def user_root(u):
    return USERS_ROOT / _safe_user(u)

_ACTIVE_USER = None
_ACTIVE_GUARD = threading.Lock()

def _activate_user(u):
    """Point PROJECTS/ENV_PATH at this user's private folder and reload their API keys. The key
    globals (KIE_KEY, …) are read by name at call time throughout the app, so reassigning them here
    switches every downstream request to the active user's credentials with no restart."""
    global _ACTIVE_USER, PROJECTS, ENV_PATH, ENV, KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY
    root = user_root(u)
    try:
        (root / "projects").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    PROJECTS = root / "projects"
    ENV_PATH = root / ".env"
    ENV = load_env()
    KIE_KEY = ENV.get("KIE_API_KEY", "")
    CL_CLOUD = ENV.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = ENV.get("CLOUDINARY_API_KEY", "")
    CL_SECRET = ENV.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = ENV.get("ELEVENLABS_API_KEY", "")
    _ACTIVE_USER = u
    global _KEYS_PROJECT
    _KEYS_PROJECT = None                              # force per-project keys to re-activate for the new user

# ---- per-PROJECT API keys ---------------------------------------------------
# Keys live in <project>/keys.json so they travel with export/import — each project carries its own Kie /
# Cloudinary / ElevenLabs credentials, independent of which membership (baran/merih) opens it.
_KEY_ENV_NAMES = ["KIE_API_KEY", "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET", "ELEVENLABS_API_KEY"]
_KEYS_PROJECT = None                                 # name of the project whose keys are currently in the globals

def _proj_keys_path(project):
    d, _safe = proj_dir(project)
    return d / "keys.json"

def _read_proj_keys(project):
    p = _proj_keys_path(project)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return None                                      # None = no keys.json yet (legacy project)

def _write_proj_keys(project, keys):
    d, _safe = proj_dir(project)
    d.mkdir(parents=True, exist_ok=True)
    _proj_keys_path(project).write_text(json.dumps(keys, ensure_ascii=False, indent=2), encoding="utf-8")

def _activate_project_keys(project):
    """Point the key globals at THIS project's keys.json for the current request. A legacy project (no
    keys.json) is migrated once by seeding from the active user's account keys, so nothing breaks; new
    projects start empty and must be filled in Settings -> API Keys."""
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY, _KEYS_PROJECT
    if project == _KEYS_PROJECT:
        return                                       # already active — keep the ref-upload cache warm
    keys = _read_proj_keys(project)
    if keys is None:                                 # migrate legacy project → seed from the user's .env
        keys = {n: ENV.get(n, "") for n in _KEY_ENV_NAMES}
        try:
            _write_proj_keys(project, keys)
        except Exception:
            pass
    KIE_KEY = keys.get("KIE_API_KEY", "")
    CL_CLOUD = keys.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = keys.get("CLOUDINARY_API_KEY", "")
    CL_SECRET = keys.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = keys.get("ELEVENLABS_API_KEY", "")
    _REF_URL_CACHE.clear()                           # ref URLs are per-Cloudinary-account — drop them when switching project
    _KEYS_PROJECT = project

def _keys_ok(need):
    """Guard a generation route: if this project is missing a required key, return a clear error the UI
    turns into a 'add API keys for this project' warning (instead of a confusing provider error later)."""
    miss = []
    if "kie" in need and not KIE_KEY:
        miss.append("Kie")
    if "cloud" in need and not (CL_CLOUD and CL_KEY and CL_SECRET):
        miss.append("Cloudinary")
    if "eleven" in need and not ELEVEN_KEY:
        miss.append("ElevenLabs")
    if miss:
        return jsonify({"error": "This project has no " + " / ".join(miss) + " API key yet. "
                        "Open Settings → API Keys and add it for this project."}), 400
    return None

# Everything requires a local login EXCEPT the login page itself and the static assets it needs
# (CSS/JS/fonts hold no secrets). Page requests redirect to /login; API/media requests get 401.
@app.before_request
def _require_login():
    u = session.get("user")
    if u:
        if u != _ACTIVE_USER:                    # signed-in user changed → point data at their folder
            with _ACTIVE_GUARD:
                if u != _ACTIVE_USER:
                    _activate_user(u)
        proj = (request.view_args or {}).get("project")   # a <project> in the URL → use THAT project's own keys
        if proj:
            try:
                _activate_project_keys(proj)
            except Exception:
                pass
        return None
    # Not logged in: gate only the data endpoints. Pages/static still load so the single-page
    # login gate (rendered inside "/") can show over the home, then reveal it after sign-in.
    if request.path.startswith("/api/") or request.path.startswith("/media/"):
        return ("login required", 401)
    return None

@app.after_request
def _no_cache(resp):
    if request.path == "/" or request.path.startswith("/static/"):
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

_lock = threading.Lock()   # serialize scenes.json writes

# Per-project lock so an endpoint's load→modify→save runs atomically. Without it, the 6s poll
# loop (which does its own load→save) can overwrite a scene that a concurrent Generate just
# marked "generating" with its own stale copy — the second scene appears to start then stop.
_PROJECT_LOCKS = {}
_PROJECT_LOCKS_GUARD = threading.Lock()
def _project_lock(name):
    with _PROJECT_LOCKS_GUARD:
        lk = _PROJECT_LOCKS.get(name)
        if lk is None:
            lk = threading.RLock()
            _PROJECT_LOCKS[name] = lk
        return lk

def _locked(fn):
    """Serialize a route's whole load→modify→save against the 6s poll (which also holds this lock).
    Without it a poll that loaded the doc BEFORE the user's approve/save can write its stale copy back
    afterward and revert the change ('geriye atma'). Applies to every route whose first arg is `project`."""
    import functools
    @functools.wraps(fn)
    def _w(project, *a, **kw):
        with _project_lock(project):
            return fn(project, *a, **kw)
    return _w

# ---- helpers ----------------------------------------------------------------
def proj_dir(name):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", name).strip("-") or "project"
    d = PROJECTS / safe
    return d, safe

def scenes_path(name):
    d, _ = proj_dir(name)
    return d / "scenes.json"

# on-screen text overlay defaults — burned onto preview + render, NOT sent to the image AI.
# Grouped: type / geometry / stroke / background / effects+animation.
# per-overlay style fields (each overlay = onscreen text + these). ost_on is section-level (see norm_scene).
# Default look = the user's saved "Montserrat White" style: Montserrat Extrabold 115px, UPPERCASE,
# centered, white fill, no stroke / no background / no drop shadow, slide-from-bottom in + fade out.
OST_OVERLAY_DEFAULTS = {
    "onscreen": "",
    "ost_fill": True, "ost_color": "#ffffff", "ost_font": "Montserrat", "ost_size": 115, "ost_weight": "800",
    "ost_bold": False, "ost_italic": False, "ost_upper": True, "ost_underline": False,
    "ost_letter": 0, "ost_leading": 0.85,
    "ost_place": "center", "ost_x": 0, "ost_y": 0, "ost_rotation": 0,
    "ost_stroke": False, "ost_stroke_w": 4, "ost_stroke_color": "#000000", "ost_stroke_pos": "outer",
    "ost_bg": False, "ost_bg_color": "#000000", "ost_bg_opacity": 60, "ost_bg_pad": 12, "ost_bg_radius": 8,
    "ost_shadow": False, "ost_shadow_color": "#000000", "ost_shadow_opacity": 80, "ost_shadow_size": 6, "ost_shadow_dir": 135,
    "ost_anim": "slide-bottom", "ost_out_anim": "fade",
    "ost_in": 0.0, "ost_out": 1.0,   # when the text shows, as a fraction of its scene (0=scene start, 1=scene end)
}

def new_overlay():
    return dict(OST_OVERLAY_DEFAULTS)

def _overlay_timeline(ov):
    """Map ONE overlay's ost_* fields to the text_* keys the renderer + preview consume."""
    return {
        "text": (ov.get("onscreen") or "").strip(),
        "text_fill": bool(ov.get("ost_fill", True)),
        "text_color": ov.get("ost_color") or "#ffffff",
        "text_font": ov.get("ost_font") or "Arial",
        "text_size": int(ov.get("ost_size") or 56),
        "text_weight": str(ov.get("ost_weight") or "400"),
        "text_bold": bool(ov.get("ost_bold")),
        "text_italic": bool(ov.get("ost_italic")),
        "text_upper": bool(ov.get("ost_upper")),
        "text_underline": bool(ov.get("ost_underline")),
        "text_letter": int(ov.get("ost_letter") or 0),
        "text_leading": float(ov.get("ost_leading") or 1.15),
        "text_place": ov.get("ost_place") or "top",
        "text_x": int(ov.get("ost_x") or 0),
        "text_y": int(ov.get("ost_y") or 0),
        "text_rotation": int(ov.get("ost_rotation") or 0),
        "text_stroke": bool(ov.get("ost_stroke", True)),
        "text_stroke_w": int(ov.get("ost_stroke_w") or 0),
        "text_stroke_color": ov.get("ost_stroke_color") or "#000000",
        "text_stroke_pos": ov.get("ost_stroke_pos") or "outer",
        "text_bg": bool(ov.get("ost_bg")),
        "text_bg_color": ov.get("ost_bg_color") or "#000000",
        "text_bg_opacity": int(ov.get("ost_bg_opacity") or 0),
        "text_bg_pad": int(ov.get("ost_bg_pad") or 0),
        "text_bg_radius": int(ov.get("ost_bg_radius") or 0),
        "text_shadow": bool(ov.get("ost_shadow", True)),
        "text_shadow_color": ov.get("ost_shadow_color") or "#000000",
        "text_shadow_opacity": int(ov.get("ost_shadow_opacity") or 0),
        "text_shadow_size": int(ov.get("ost_shadow_size") or 0),
        "text_shadow_dir": int(ov.get("ost_shadow_dir") or 0),
        "text_anim": ov.get("ost_anim") or "fade",
        "text_out_anim": ov.get("ost_out_anim") or "none",
        "text_in": _ost_frac(ov.get("ost_in"), 0.0),      # show window as a fraction of the scene
        "text_out": _ost_frac(ov.get("ost_out"), 1.0),
    }

def _ost_frac(v, default):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, f))

def _scene_overlays(s):
    """List of text_* dicts for a scene's overlays (empty when the section is off)."""
    if not s.get("ost_on"):
        return []
    return [_overlay_timeline(ov) for ov in (s.get("overlays") or []) if (ov.get("onscreen") or "").strip()]

def norm_scene(s):
    """Normalize a scene to the versioned-image model + defaults (backward compatible)."""
    s.setdefault("style", None)
    s.setdefault("no_cast", False)
    s.setdefault("model", IMAGE_MODEL)
    if s.get("model") not in IMAGE_MODEL_KEYS:   # migrate removed/old model keys (e.g. gpt-4o)
        s["model"] = IMAGE_MODEL
    s.setdefault("refs", [])
    s.setdefault("ref_free", [])      # ref paths whose STYLE (clothing/hair) is unlocked (default: locked)
    s.setdefault("cast", [])          # ids of doc.characters present in this scene
    s.setdefault("cont_of", None)     # uid of an earlier scene this one visually continues (same place+people)
    s.setdefault("camera", DEFAULT_CAMERA)          # camera framing/angle key
    if s.get("camera") not in CAMERA_ANGLES_BY_KEY and s.get("camera") not in ("", None, "none"):
        s["camera"] = DEFAULT_CAMERA   # "none" is a valid choice → no camera-angle text in the prompt
    s.setdefault("transition", DEFAULT_TRANSITION)  # transition into the NEXT scene
    if s.get("transition") not in TRANSITIONS:
        s["transition"] = DEFAULT_TRANSITION
    # on-screen text overlays: migrate legacy flat fields → overlays[0], normalize the list
    fresh = "overlays" not in s
    if fresh:
        s["overlays"] = [{k: s.get(k, OST_OVERLAY_DEFAULTS[k]) for k in OST_OVERLAY_DEFAULTS}]
    if not isinstance(s.get("overlays"), list) or not s["overlays"]:
        s["overlays"] = [new_overlay()]
    for ov in s["overlays"]:
        for k, v in OST_OVERLAY_DEFAULTS.items():
            ov.setdefault(k, v)
        ov["ost_in"] = _ost_frac(ov.get("ost_in"), 0.0)          # show window within the scene, 0..1
        ov["ost_out"] = _ost_frac(ov.get("ost_out"), 1.0)
        if ov["ost_out"] <= ov["ost_in"]:                        # keep at least a sliver visible
            ov["ost_out"] = min(1.0, ov["ost_in"] + 0.05)
    has_text = any((ov.get("onscreen") or "").strip() for ov in s["overlays"])
    if fresh:
        s["ost_on"] = has_text                       # legacy scenes with text migrate to ON
    else:
        s.setdefault("ost_on", has_text)
    for lk in list(OST_OVERLAY_DEFAULTS) + ["onscreen"]:   # drop legacy flat copies (now inside overlays)
        s.pop(lk, None)
    # video model + options (clamp to the selected model's supported values)
    if s.get("video_model") not in VIDEO_MODEL_BY_KEY:
        s["video_model"] = DEFAULT_VIDEO_MODEL
    _vcfg = VIDEO_MODEL_BY_KEY[s["video_model"]]
    if s.get("video_dur") not in _vcfg["durations"]:
        s["video_dur"] = _vcfg["defaultDur"]
    if s.get("video_res") not in _vcfg["resolutions"]:
        s["video_res"] = _vcfg["defaultRes"]
    s.setdefault("video_cam_lock", True)            # image→video keeps the camera static unless the user unlocks it
    s.setdefault("video", {"status": "empty", "taskId": None, "file": None, "error": None})
    s["video"].setdefault("approved", False)
    s["video"].setdefault("api", "jobs")
    img = s.setdefault("image", {})
    if "versions" not in img:
        vers = list(img.get("history") or [])
        if img.get("file"):
            vers.append(img["file"])
        img["versions"] = vers
        img["current"] = len(vers) - 1
    img.setdefault("current", len(img.get("versions", [])) - 1)
    for k, dv in (("status", "empty"), ("taskId", None), ("error", None)):
        img.setdefault(k, dv)
    vs, cur = img.get("versions", []), img.get("current", -1)
    img["file"] = vs[cur] if (vs and 0 <= cur < len(vs)) else None   # "file" = current (shown) version
    av = img.get("approved_version")
    img["approved_file"] = vs[av] if (isinstance(av, int) and 0 <= av < len(vs)) else None
    # MODEL PER VERSION: keep version_models aligned with versions (legacy versions → best-guess = last selection).
    # The DROPDOWN is reconciled to the shown image's model on the FRONTEND at project-open (NOT here) — doing it
    # server-side would also clobber the model the user just picked for the NEXT generation.
    vm = img.setdefault("version_models", [])
    while len(vm) < len(vs):
        vm.append(s.get("model") or IMAGE_MODEL)
    if len(vm) > len(vs):
        del vm[len(vs):]
    return s

def new_uid():
    """A short, permanent per-scene identity. Media files are named by this (NOT the 1..N display id),
    so inserting/splitting/deleting/reordering scenes — which renumbers ids — never renames files,
    never collides two scenes on one filename, and never detaches a video from its scene."""
    return hashlib.md5(f"{time.time()}".encode() + os.urandom(6)).hexdigest()[:8]

def load_doc(name):
    p = scenes_path(name)
    if not p.exists():
        return None
    doc = json.loads(p.read_text(encoding="utf-8"))
    doc.setdefault("characters", [])     # per-project cast: [{id, name, url}]
    doc.setdefault("product", {"urls": []})   # per-project PRODUCT reference image(s) — attached (i2i) to scenes flagged show-product
    doc.setdefault("brief", "")          # free-text project brief/context fed to the split + prompt LLM passes
    changed = False
    used = set()
    for s in doc.get("scenes", []):
        u = s.get("uid")
        if not u or u in used:           # one-time migration: give every existing scene a stable uid
            u = new_uid(); s["uid"] = u; changed = True
        used.add(u)
        norm_scene(s)
    if changed:
        save_doc(name, doc)              # persist the assigned uids once
    return doc

def save_doc(name, doc):
    d, _ = proj_dir(name)
    (d / "images").mkdir(parents=True, exist_ok=True)
    (d / "videos").mkdir(parents=True, exist_ok=True)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    with _lock:
        scenes_path(name).write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

def new_scene(i):
    return {
        "id": i, "uid": new_uid(), "vo": "", "prompt": "", "refs": [], "cast": [], "states": {}, "camera": "none", "transition": DEFAULT_TRANSITION, "style": DEFAULT_STYLE, "no_cast": False, "split": False, "model": IMAGE_MODEL,
        "ost_on": False, "overlays": [new_overlay()],   # on-screen text (section toggle + overlay list)
        "image": {"status": "empty", "taskId": None, "error": None,
                  "versions": [], "current": -1, "file": None, "approved_version": None},
        "approved": False,
        "video_desc": "", "video_prompt": "", "video_cam_lock": True,
        "video_model": DEFAULT_VIDEO_MODEL,
        "video_dur": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultDur"],
        "video_res": VIDEO_MODEL_BY_KEY[DEFAULT_VIDEO_MODEL]["defaultRes"],
        "video": {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False, "api": "jobs"},
    }

# ---- Cloudinary (for uploading local refs -> public URL for Kie) ------------
def cloudinary_upload(local_path, public_id):
    ts = str(int(time.time()))
    to_sign = f"public_id={public_id}&timestamp={ts}{CL_SECRET}"
    sig = hashlib.sha1(to_sign.encode()).hexdigest()
    with open(local_path, "rb") as fh:
        r = requests.post(
            f"https://api.cloudinary.com/v1_1/{CL_CLOUD}/image/upload",
            files={"file": fh},
            data={"public_id": public_id, "timestamp": ts, "api_key": CL_KEY, "signature": sig},
            timeout=120,
        )
    d = r.json()
    url = d.get("secure_url")
    # deliver a size-limited PNG so Kie always gets a valid, <25MP image
    if url:
        url = url.replace("/upload/", "/upload/c_limit,w_1600,f_png/")
        url = re.sub(r"\.(webp|jpg|jpeg)$", ".png", url)
    return url

# Reference images are stored LOCALLY on add (fast, no network/quota). Only when a scene is
# actually generated do we upload each local ref to Cloudinary to get the public URL Kie fetches.
_REF_URL_CACHE = {}   # (path, mtime_ns) -> cloudinary url, so a ref uploads at most once per session

def ref_public_url(d, safe, ref):
    """Public URL Kie can fetch for a stored reference. A local path ('refs/…') is uploaded to
    Cloudinary now; an http URL passes through — EXCEPT a Cloudinary URL from a different (old)
    account, which Kie can no longer fetch: we re-upload the local copy to the CURRENT account so
    old references self-heal instead of failing with 'image fetch failed'. Returns None if it can't."""
    if not ref:
        return None
    if ref.startswith("http://") or ref.startswith("https://"):
        if CL_CLOUD and "res.cloudinary.com/" in ref and f"res.cloudinary.com/{CL_CLOUD}/" not in ref:
            local = _local_ref_for_url(d, ref)          # find the on-disk copy by filename
            if local is not None:
                return ref_public_url(d, safe, str(local))   # re-upload it to the new account
        return ref
    p = d / ref
    if not p.is_file():
        p = d / "refs" / Path(ref).name
    if not p.is_file():
        return None
    try:
        key = (str(p), p.stat().st_mtime_ns)
    except OSError:
        key = (str(p), 0)
    if key in _REF_URL_CACHE:
        return _REF_URL_CACHE[key]
    url = cloudinary_upload(p, f"{safe}/refs/{p.stem}")
    if url:
        _REF_URL_CACHE[key] = url
    return url

def resolve_refs(d, safe, refs):
    """Turn stored refs into public URLs for Kie. Raises ValueError if a local ref can't upload
    (e.g. Cloudinary over quota) so generation fails with a clear message instead of silently
    dropping the reference."""
    out = []
    for r in (refs or []):
        u = ref_public_url(d, safe, r)
        if u is None:
            raise ValueError("reference image upload failed (check Cloudinary account)")
        out.append(u)
    return out

# ---- Kie.ai ----------------------------------------------------------------
def _retry(fn, tries=3, base=0.6, cap=5.0):
    """Call fn(); on ANY exception retry up to `tries` times with exponential backoff (capped at `cap`s so a
    high retry count can't explode into minute-long waits). Rides out transient blips / provider 500s.
    Raises the last error only if every attempt fails."""
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            last = e
            if i < tries - 1:
                time.sleep(min(base * (2 ** i), cap))
    raise last

def kie_create(model, inp):
    def _do():
        r = requests.post(f"{KIE_BASE}/createTask",
                          headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                          json={"model": model, "input": inp}, timeout=60)
        return r.json()
    d = _retry(_do)
    if d.get("code") == 200 and d.get("data"):
        return d["data"]["taskId"], None
    return None, d.get("msg", "unknown error")

def kie_record(task_id):
    def _do():
        r = requests.get(f"{KIE_BASE}/recordInfo", params={"taskId": task_id},
                         headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=60)
        return r.json()
    return _retry(_do)

def result_url(record):
    try:
        rj = record["data"].get("resultJson") or ""
        if rj:
            urls = json.loads(rj).get("resultUrls") or []
            if urls:
                return urls[0]
    except Exception:
        pass
    return None

def download_as_png(url, dest_path):
    """Download bytes and save as a *real* PNG regardless of what Kie actually returns.
    Retried so a transient blip doesn't discard an image Kie already generated."""
    def _do():
        r = requests.get(url, timeout=180)
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGB")
        img.save(dest_path, "PNG")
    _retry(_do)

def download_as_mp4(url, dest_path):
    def _do():
        r = requests.get(url, timeout=600, stream=True)
        r.raise_for_status()
        with open(dest_path, "wb") as fh:
            for chunk in r.iter_content(65536):
                fh.write(chunk)
    _retry(_do)

# ---- subtitle / SRT (local forced alignment, no API) -----------------------
# Wraps the tested standalone tool subtitle/vsl_align_srt.py. Runs entirely on
# this machine (stable-whisper + ffmpeg) — no Kie.ai, no Claude Code tokens.
import sys as _sys
SRT_SCRIPT = BASE.parent / "subtitle" / "vsl_align_srt.py"
SUB_STATUS = {}            # {project: {status, step, srt, error, updated}}
SUB_LOCK = threading.Lock()

def sub_dir(name):
    d, _ = proj_dir(name)
    return d / "subtitle"

def sub_status_path(name):
    return sub_dir(name) / "status.json"

def set_sub_status(name, **kw):
    with SUB_LOCK:
        st = SUB_STATUS.get(name, {})
        st.update(kw); st["updated"] = time.time()
        SUB_STATUS[name] = st
    try:
        sub_dir(name).mkdir(parents=True, exist_ok=True)
        sub_status_path(name).write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return st

def get_sub_status(name):
    with SUB_LOCK:
        if name in SUB_STATUS:
            return dict(SUB_STATUS[name])
    p = sub_status_path(name)
    if p.exists():
        try:
            st = json.loads(p.read_text(encoding="utf-8"))
            # A persisted "running" with no live in-process job = the server was restarted mid-job
            # (which kills it). Report it as stopped so the UI never hangs on a dead job, and clear
            # the stale file so it doesn't resurface.
            if st.get("status") == "running":
                st = {"status": "error", "step": "",
                      "error": "Subtitle generation was interrupted (the server restarted). Please run it again."}
                try:
                    p.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
            return st
        except Exception:
            pass
    return {"status": "idle"}

# silence trimming (ffmpeg silenceremove). Each mode = how much gap to KEEP between sentences.
TRIM_MODES = {
    "fast":    {"sd": 0.15, "ss": 0.08},   # aggressive — very tight
    "natural": {"sd": 0.20, "ss": 0.28},   # keep a normal pause
    "slow":    {"sd": 0.25, "ss": 0.45},   # keep a gentle pause
}
def trim_silences(src, dst, mode="natural"):
    """Shorten silences (below -35dB) between sentences to the mode's target gap. Also trims
    leading/trailing silence. Returns True on success."""
    m = TRIM_MODES.get(mode, TRIM_MODES["natural"])
    thr = "-35dB"
    af = (f"silenceremove=start_periods=1:start_threshold={thr}:start_duration=0.1:start_silence=0.05:"
          f"stop_periods=-1:stop_threshold={thr}:stop_duration={m['sd']}:stop_silence={m['ss']}:detection=peak")
    try:
        subprocess.run(["ffmpeg", "-y", "-i", str(src), "-af", af, str(dst)],
                       check=True, capture_output=True, creationflags=_NO_WINDOW)
        return True
    except Exception:
        return False

# live subtitle jobs, so the UI's "⏹ Stop" can kill the running aligner subprocess (+ its child
# whisper/ffmpeg tree) immediately. _SUB_PROCS: project → Popen; _SUB_CANCEL: projects asked to stop.
_SUB_PROCS = {}
_SUB_CANCEL = set()

def _kill_proc_tree(proc):
    if not proc or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           creationflags=_NO_WINDOW, capture_output=True)
        else:
            proc.terminate()
    except Exception:
        pass

def _run_align(name, wd, audio, docx, out, model, vad, step):
    """Run one alignment pass of vsl_align_srt.py as a subprocess (its own CWD = wd,
    so all caches — words_*.tsv, silence_all.log — land in the project subtitle dir)."""
    set_sub_status(name, status="running", step=step, error=None)
    env = dict(os.environ, VSL_AUDIO=str(audio), VSL_DOCX=str(docx), VSL_OUT=str(out))
    # Run under console python inside a HIDDEN console (not CREATE_NO_WINDOW): the aligner's OWN
    # child processes (whisper's ffmpeg) then inherit that hidden console and never pop a black
    # window. CREATE_NO_WINDOW would leave the parent console-less, so each grandchild ffmpeg
    # allocates its own visible console instead.
    exe = _sys.executable
    si, cf = None, 0
    if os.name == "nt":
        if exe.lower().endswith("pythonw.exe"):
            _cand = exe[:-len("pythonw.exe")] + "python.exe"
            if os.path.exists(_cand):
                exe = _cand
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0   # SW_HIDE
    args = [exe, str(SRT_SCRIPT), model]
    if vad:
        args.append("--vad")
    log_path = wd / "align.log"
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"\n===== {step} =====\n"); log.flush()
        # Popen (not run) so a Stop request can kill this + its child whisper/ffmpeg tree mid-pass.
        proc = subprocess.Popen(args, cwd=str(wd), env=env,
                                stdout=log, stderr=subprocess.STDOUT,
                                startupinfo=si, creationflags=cf)
        _SUB_PROCS[name] = proc
        try:
            proc.wait()
        finally:
            _SUB_PROCS.pop(name, None)
    return proc.returncode

def run_subtitle_job(name, audio, docx, out, trimmed_rel=None):
    """Ensemble flow the user runs manually: small.en --vad first (builds the secondary
    cache), then medium.en --vad which merges it → final SRT."""
    wd = sub_dir(name)
    _SUB_CANCEL.discard(name)
    def _cancelled():
        if name in _SUB_CANCEL:
            _SUB_CANCEL.discard(name)
            set_sub_status(name, status="idle", step="", error=None, srt=None)   # user stopped it
            return True
        return False
    try:
        rc = _run_align(name, wd, audio, docx, out, "small.en", True, "Synchronizing subtitles…")
        if _cancelled():
            return
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the first pass (exit {rc}); see align.log")
            return
        rc = _run_align(name, wd, audio, docx, out, "medium.en", True, "Finalizing subtitles…")
        if _cancelled():
            return
        if rc != 0:
            set_sub_status(name, status="error", error=f"Subtitle sync failed on the final pass (exit {rc}); see align.log")
            return
        if not Path(out).exists():
            set_sub_status(name, status="error", error="alignment finished but no SRT was produced; see align.log")
            return
        rel = f"subtitle/{Path(out).name}"
        set_sub_status(name, status="done", step="Done", srt=rel,
                       srt_name=Path(out).name, trimmed=trimmed_rel, error=None)
    except Exception as e:
        set_sub_status(name, status="error", error=str(e))

# ---- routes: auth -----------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    # The login UI is now an overlay inside the home page (single page), submitted via fetch.
    if request.method == "GET":
        return redirect(url_for("index"))
    u = request.form.get("username", "").strip()
    p = request.form.get("password", "")
    if check_login(u, p):
        session.permanent = True
        session["user"] = u
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Wrong username or password."}), 401

@app.route("/logout")
def logout():
    session.clear()
    # Redirect straight to "/" (the home shows the login gate when signed out) and forbid caching —
    # a cached 302 was letting a repeat sign-out skip the server, so the session never cleared.
    resp = redirect("/")
    resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp

# ---- routes: pages ----------------------------------------------------------
@app.route("/")
def index():
    static = BASE / "static"
    try:
        v = str(int(max((static / "app.js").stat().st_mtime, (static / "style.css").stat().st_mtime)))
    except Exception:
        v = "1"
    try:
        appver = (BASE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        appver = ""
    return render_template("index.html", v=v, authed=bool(session.get("user")), appver=appver)

# ---- routes: API keys (let a new user plug in their own keys from the UI) ----
_KEY_MAP = {   # UI field -> .env variable
    "kie": "KIE_API_KEY", "cloud_name": "CLOUDINARY_CLOUD_NAME",
    "cloud_key": "CLOUDINARY_API_KEY", "cloud_secret": "CLOUDINARY_API_SECRET",
    "elevenlabs": "ELEVENLABS_API_KEY",
}
@app.route("/api/keys/<project>")
def api_get_keys(project):
    # before_request already activated this project's keys into the globals
    return jsonify({"kie": KIE_KEY, "cloud_name": CL_CLOUD, "cloud_key": CL_KEY,
                    "cloud_secret": CL_SECRET, "elevenlabs": ELEVEN_KEY})

@app.route("/api/keys/<project>", methods=["POST"])
def api_set_keys(project):
    """Save API keys FOR THIS PROJECT (into <project>/keys.json), so they travel with export/import and
    are used whenever this project is open — regardless of which membership opens it."""
    global KIE_KEY, CL_CLOUD, CL_KEY, CL_SECRET, ELEVEN_KEY, _KEYS_PROJECT
    data = request.get_json(force=True) or {}
    updates = {_KEY_MAP[k]: str(data[k]).strip() for k in _KEY_MAP if k in data}
    if not updates:
        return jsonify({"error": "no keys provided"}), 400
    keys = _read_proj_keys(project) or {n: "" for n in _KEY_ENV_NAMES}
    keys.update(updates)
    try:
        _write_proj_keys(project, keys)
    except Exception as e:
        return jsonify({"error": f"could not save keys: {e}"}), 500
    KIE_KEY = keys.get("KIE_API_KEY", ""); CL_CLOUD = keys.get("CLOUDINARY_CLOUD_NAME", "")
    CL_KEY = keys.get("CLOUDINARY_API_KEY", ""); CL_SECRET = keys.get("CLOUDINARY_API_SECRET", "")
    ELEVEN_KEY = keys.get("ELEVENLABS_API_KEY", "")
    _REF_URL_CACHE.clear()
    _KEYS_PROJECT = project
    return jsonify({"ok": True})

# ---- Kie.ai credit balance + a small spend ledger (real spend = the drop between balance snapshots) ----
KIE_CREDIT_URL = "https://api.kie.ai/api/v1/chat/credit"

def _ledger_path():
    return DATA_DIR / "credit_ledger.json"     # global, shared across users/projects (keyed by the account key)

def _read_ledger():
    p = _ledger_path()
    if p.exists():
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return {}
    return {}

def _write_ledger(d):
    try: _ledger_path().write_text(json.dumps(d), encoding="utf-8")
    except Exception: pass

def _key_hash():
    return hashlib.md5(KIE_KEY.encode()).hexdigest()[:10] if KIE_KEY else None

def fetch_kie_balance():
    def _do():
        r = requests.get(KIE_CREDIT_URL, headers={"Authorization": f"Bearer {KIE_KEY}"}, timeout=30)
        d = r.json()
        if d.get("code") == 200 and isinstance(d.get("data"), (int, float)):
            return float(d["data"])
        raise RuntimeError(d.get("msg") or "could not read balance")
    return _retry(_do, tries=3)

@app.route("/api/credits/<project>")
def api_credits(project):
    """Live Kie.ai balance for THIS project's key, plus a spend history derived from balance snapshots.
    Each check appends a {t, balance} snapshot to a per-account ledger; the drop between snapshots = spend."""
    if not KIE_KEY:
        return jsonify({"keyPresent": False})
    try:
        bal = fetch_kie_balance()
    except Exception as e:
        return jsonify({"keyPresent": True, "error": str(e)}), 502
    kh = _key_hash()
    now = int(time.time())
    led = _read_ledger()
    arr = led.get(kh, [])
    # record a snapshot when the balance moved, or the last one is older than 20s (throttle duplicates)
    if not arr or abs(arr[-1].get("balance", -1) - bal) >= 0.001 or (now - arr[-1].get("t", 0)) > 20:
        arr.append({"t": now, "balance": bal})
        arr = arr[-80:]
        led[kh] = arr
        _write_ledger(led)
    spends = []
    for i in range(1, len(arr)):
        drop = arr[i - 1]["balance"] - arr[i]["balance"]     # positive = credits spent
        if drop >= 0.001:
            spends.append({"t": arr[i]["t"], "spent": round(drop, 2), "balance": round(arr[i]["balance"], 2)})
    spends.reverse()                                          # newest first
    total_tracked = round(sum(s["spent"] for s in spends), 2)
    return jsonify({"keyPresent": True, "balance": round(bal, 2), "history": spends[:25],
                    "tracked_spend": total_tracked, "since": (arr[0]["t"] if arr else now)})

# ---- routes: translate VO lines to Turkish (faint reference under each scene's sentence) ----
_TRANSLATE_SYSTEM = (
    "You are a professional translator. Translate each numbered line into natural, faithful Turkish. "
    "Preserve meaning and tone; do not add or omit content. Return ONLY a JSON array of strings — one "
    "Turkish translation per input line, in the SAME order and SAME count. No commentary, no numbering."
)

@app.route("/api/translate", methods=["POST"])
def api_translate():
    data = request.get_json(force=True) or {}
    texts = data.get("texts") or []
    source = (data.get("source") or "").strip()
    if not isinstance(texts, list) or not texts:
        return jsonify({"translations": []})
    numbered = "\n".join(f"{i+1}. {str(t)}" for i, t in enumerate(texts))
    user = (f"Source language: {source}.\nTranslate to Turkish:\n{numbered}" if source
            else f"Translate to Turkish:\n{numbered}")
    try:
        arr = _parse_json_array(_claude_text(_TRANSLATE_SYSTEM, user, max_tokens=6000))
        trs = [str(x) for x in arr][:len(texts)]
        while len(trs) < len(texts):
            trs.append("")
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"translations": trs})

# ---- routes: sync folder (Google Drive/OneDrive/Dropbox desktop) + export/import ----
# A single machine-level "sync folder" (a folder that a cloud-sync app mirrors between PCs). Export
# writes a project .zip there; the other PC lists + imports those zips. No API keys, no size limits.
APP_CONFIG_PATH = DATA_DIR / "app_config.json"

def _load_config():
    try:
        return json.loads(APP_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_config(cfg):
    try:
        APP_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

def _sync_dir():
    p = (_load_config().get("sync_dir") or "").strip()
    return Path(p) if p else None

@app.route("/api/config")
def api_get_config():
    sd = (_load_config().get("sync_dir") or "").strip()
    return jsonify({"sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir())})

@app.route("/api/config", methods=["POST"])
def api_set_config():
    data = request.get_json(force=True) or {}
    cfg = _load_config()
    if "sync_dir" in data:
        cfg["sync_dir"] = str(data["sync_dir"]).strip()
    _save_config(cfg)
    sd = (cfg.get("sync_dir") or "").strip()
    return jsonify({"ok": True, "sync_dir": sd, "sync_ok": bool(sd and Path(sd).is_dir())})

_MANIFEST_NAME = "__vsl_manifest__.json"
_MUSIC_PREFIX = "__music__/"            # bundled Background Music tracks live here inside the zip

def _bundled_music(doc):
    """(src_path, arcname) for every Background Music track this project's plan uses — so the export
    is self-contained and plays/renders identically even on a PC that lacks that track."""
    out, seen = [], set()
    for seg in (doc.get("music_plan") or []):
        emo, track = seg.get("emotion"), seg.get("track")
        key = f"{emo}/{track}"
        if emo and track and key not in seen:
            seen.add(key)
            src = BGM_ROOT / emo / track
            if src.exists():
                out.append((src, f"{_MUSIC_PREFIX}{emo}/{track}"))
    return out

_EXPORT_JOBS = {}                        # job_id -> {pct, done, error, file, title, scenes}
_EXPORT_GUARD = threading.Lock()

def _run_export(job_id, d, safe, manifest, sd):
    tmp = sd / (safe + ".zip.part")
    final = sd / (safe + ".zip")
    try:
        files = []                       # (src, arcname) project files under <safe>/…
        for root, _dirs, fns in os.walk(d):
            if "__pycache__" in root:
                continue
            for fn in fns:
                fp = Path(root) / fn
                files.append((fp, str(Path(safe) / fp.relative_to(d))))
        try:
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
        except Exception:
            doc = {}
        files += _bundled_music(doc)     # self-contained: carry the music too
        total = sum(fp.stat().st_size for fp, _ in files) or 1
        written = 0
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED, allowZip64=True) as z:
            z.writestr(_MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
            for fp, arc in files:
                z.write(fp, arc)
                written += fp.stat().st_size
                _EXPORT_JOBS[job_id]["pct"] = min(99, int(written * 100 / total))
        if final.exists():
            final.unlink()
        tmp.replace(final)
        _EXPORT_JOBS[job_id].update(pct=100, done=True, file=final.name)
    except Exception as e:
        try:
            tmp.unlink()
        except Exception:
            pass
        _EXPORT_JOBS[job_id].update(done=True, error=str(e))

@app.route("/api/projects/<project>/export", methods=["POST"])
def api_export_project(project):
    """Kick off a background zip of the project folder (+ its music) into the sync folder as <name>.zip
    (stored = fast copy since media is already compressed). Returns a job id to poll for progress."""
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    sd = _sync_dir()
    if not sd:
        return jsonify({"error": "no-sync-dir"}), 400
    if not sd.is_dir():
        return jsonify({"error": "sync-dir-missing"}), 400
    try:
        doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
    except Exception:
        doc = {}
    manifest = {"name": safe, "title": doc.get("title", safe), "scenes": len(doc.get("scenes", [])),
                "exported_by": _ACTIVE_USER or "", "exported_at": datetime.now().isoformat(timespec="seconds")}
    job_id = uuid.uuid4().hex
    _EXPORT_JOBS[job_id] = {"pct": 0, "done": False, "error": None, "file": None, "title": manifest["title"]}
    threading.Thread(target=_run_export, args=(job_id, d, safe, manifest, sd), daemon=True).start()
    return jsonify({"ok": True, "job": job_id, "title": manifest["title"]})

@app.route("/api/export-status/<job>")
def api_export_status(job):
    j = _EXPORT_JOBS.get(job)
    if not j:
        return jsonify({"error": "not-found"}), 404
    return jsonify(j)

@app.route("/api/imports")
def api_list_imports():
    """List the project zips sitting in the sync folder (with manifest metadata for the picker)."""
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"sync_ok": False, "items": []})
    items = []
    for zp in sorted(sd.glob("*.zip")):
        info = {"file": zp.name, "title": zp.stem, "name": zp.stem, "scenes": None,
                "exported_by": "", "exported_at": "", "size": zp.stat().st_size}
        try:
            with zipfile.ZipFile(zp) as z:
                if _MANIFEST_NAME in z.namelist():
                    m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                    info.update({"title": m.get("title", info["title"]), "name": m.get("name", info["name"]),
                                 "scenes": m.get("scenes"), "exported_by": m.get("exported_by", ""),
                                 "exported_at": m.get("exported_at", "")})
        except Exception:
            pass
        items.append(info)
    return jsonify({"sync_ok": True, "items": items})

@app.route("/api/imports/delete", methods=["POST"])
def api_delete_import():
    """Delete one export zip from the sync folder (housekeeping from the import window)."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    try:
        if zp.exists():
            zp.unlink()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True})

@app.route("/api/import", methods=["POST"])
def api_import_project():
    """Pull one zip from the sync folder into THIS user's projects. overwrite=True replaces a project
    of the same name (2-PC round-trip); otherwise it's auto-renamed so nothing is clobbered. Bundled
    music (__music__/…) is restored into the local Background Music folder."""
    data = request.get_json(force=True) or {}
    fname = os.path.basename(str(data.get("file") or ""))     # basename → no path traversal
    overwrite = bool(data.get("overwrite"))
    if not fname.endswith(".zip"):
        return jsonify({"error": "bad-file"}), 400
    sd = _sync_dir()
    if not sd or not sd.is_dir():
        return jsonify({"error": "no-sync-dir"}), 400
    zp = sd / fname
    if not zp.exists():
        return jsonify({"error": "not-found"}), 404
    base = zp.stem
    try:
        with zipfile.ZipFile(zp) as z:
            if _MANIFEST_NAME in z.namelist():
                m = json.loads(z.read(_MANIFEST_NAME).decode("utf-8"))
                base = m.get("name") or base
    except Exception:
        pass
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", base).strip("-") or "project"
    if overwrite and (PROJECTS / safe).exists():
        target = safe                            # replace the existing same-named project
    else:
        target, n = safe, 1
        while (PROJECTS / target).exists():      # never clobber unless explicitly overwriting
            n += 1
            target = f"{safe}-import" + ("" if n == 2 else str(n))
    dest = PROJECTS / target
    tmp = PROJECTS / (target + ".importing")
    try:
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(zp) as z:
            for nm in z.namelist():
                if nm == _MANIFEST_NAME:
                    continue
                if nm.startswith(_MUSIC_PREFIX):        # restore bundled music into Background Music/
                    rel = nm[len(_MUSIC_PREFIX):]
                    if not rel or nm.endswith("/"):
                        continue
                    mp = (BGM_ROOT / rel)
                    try:
                        if not mp.exists():             # never overwrite a shipped track
                            mp.parent.mkdir(parents=True, exist_ok=True)
                            with z.open(nm) as src, open(mp, "wb") as f:
                                shutil.copyfileobj(src, f)
                    except Exception:
                        pass
                    continue
                rel = nm.split("/", 1)[1] if "/" in nm else nm   # strip the top folder (original name)
                if not rel:
                    continue
                outp = tmp / rel
                if nm.endswith("/"):
                    outp.mkdir(parents=True, exist_ok=True)
                    continue
                outp.parent.mkdir(parents=True, exist_ok=True)
                with z.open(nm) as src, open(outp, "wb") as f:
                    shutil.copyfileobj(src, f)
        sp = tmp / "scenes.json"                 # retarget the project id to its new folder name
        if sp.exists():
            try:
                jdoc = json.loads(sp.read_text(encoding="utf-8"))
                jdoc["name"] = target
                sp.write_text(json.dumps(jdoc, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                pass
        if dest.exists():                        # overwrite: swap in the fresh copy atomically-ish
            shutil.rmtree(dest, ignore_errors=True)
        tmp.replace(dest)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({"error": str(e)}), 500
    title = target
    try:
        title = json.loads((dest / "scenes.json").read_text(encoding="utf-8")).get("title", target)
    except Exception:
        pass
    return jsonify({"ok": True, "name": target, "title": title, "overwritten": overwrite and dest == PROJECTS / safe})

# ---- routes: projects -------------------------------------------------------
@app.route("/api/projects")
def api_projects():
    out = []
    for d in sorted(PROJECTS.iterdir()):
        if (d / "scenes.json").exists():
            doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
            out.append({"name": d.name, "title": doc.get("title", d.name),
                        "scenes": len(doc.get("scenes", []))})
    return jsonify(out)

@app.route("/api/projects", methods=["POST"])
def api_create_project():
    body = request.get_json(force=True)
    name = body.get("name", "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    d, safe = proj_dir(name)
    if (d / "scenes.json").exists():
        return jsonify({"error": "project exists", "name": safe}), 409
    doc = {"name": safe, "title": name, "created": datetime.now().isoformat(timespec="seconds"),
           "audience": body.get("audience", {}), "brief": body.get("brief", ""), "refs": [], "characters": [], "scenes": []}
    save_doc(safe, doc)
    try:
        _write_proj_keys(safe, {n: "" for n in _KEY_ENV_NAMES})   # start EMPTY (no seeding) → user fills keys per project
    except Exception:
        pass
    return jsonify({"name": safe})

@app.route("/api/projects/<project>/rename", methods=["POST"])
def api_rename_project(project):
    """Rename a project's display title (the folder / id stays the same)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    title = (request.get_json(force=True).get("title") or "").strip()
    if not title:
        return jsonify({"error": "title required"}), 400
    doc["title"] = title
    save_doc(project, doc)
    return jsonify({"ok": True, "title": title})

def trash_dir():
    """Per-user recycle bin, sibling of the projects folder so it's never listed as a project."""
    return PROJECTS.parent / "_trash"

def _safe_trash_child(tname):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", tname).strip("-") or "project"
    return trash_dir() / safe, safe

@app.route("/api/projects/<project>", methods=["DELETE"])
def api_delete_project(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    mode = (request.args.get("mode") or "disk").lower()
    if mode == "dashboard":
        # SOFT delete — move the folder into _trash (files stay on disk, fully restorable).
        td = trash_dir(); td.mkdir(parents=True, exist_ok=True)
        title = safe
        try:
            title = json.loads((d / "scenes.json").read_text(encoding="utf-8")).get("title", safe)
        except Exception:
            pass
        dest = td / safe
        n = 2
        while dest.exists():
            dest = td / f"{safe}-{n}"; n += 1
        shutil.move(str(d), str(dest))
        try:
            (dest / "__trashinfo__.json").write_text(json.dumps(
                {"orig": safe, "title": title, "deleted": datetime.now().isoformat(timespec="seconds")}),
                encoding="utf-8")
        except Exception:
            pass
        return jsonify({"ok": True, "mode": "dashboard", "trash": dest.name})
    # HARD delete — remove the folder from disk permanently.
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True, "mode": "disk"})

@app.route("/api/trash")
def api_trash():
    out = []
    td = trash_dir()
    if td.exists():
        for d in sorted(td.iterdir()):
            if not d.is_dir() or not (d / "scenes.json").exists():
                continue
            info = {}
            ip = d / "__trashinfo__.json"
            if ip.exists():
                try: info = json.loads(ip.read_text(encoding="utf-8"))
                except Exception: info = {}
            try:
                doc = json.loads((d / "scenes.json").read_text(encoding="utf-8"))
                nsc = len(doc.get("scenes", []))
                title = info.get("title") or doc.get("title", d.name)
            except Exception:
                nsc = 0; title = info.get("title") or d.name
            out.append({"name": d.name, "orig": info.get("orig", d.name),
                        "title": title, "scenes": nsc, "deleted": info.get("deleted", "")})
    out.sort(key=lambda x: x.get("deleted", ""), reverse=True)
    return jsonify(out)

@app.route("/api/trash/<tname>/restore", methods=["POST"])
def api_trash_restore(tname):
    d, safe = _safe_trash_child(tname)
    if not (d / "scenes.json").exists():
        abort(404)
    orig = safe
    ip = d / "__trashinfo__.json"
    if ip.exists():
        try: orig = json.loads(ip.read_text(encoding="utf-8")).get("orig", safe)
        except Exception: pass
    dest = PROJECTS / (re.sub(r"[^a-zA-Z0-9_-]", "-", orig).strip("-") or "project")
    base = dest
    n = 2
    while dest.exists():
        dest = base.parent / f"{base.name}-{n}"; n += 1
    shutil.move(str(d), str(dest))
    try: (dest / "__trashinfo__.json").unlink()
    except Exception: pass
    title = dest.name
    try:
        sp = dest / "scenes.json"
        doc = json.loads(sp.read_text(encoding="utf-8"))
        doc["name"] = dest.name
        title = doc.get("title", dest.name)
        sp.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception: pass
    return jsonify({"ok": True, "name": dest.name, "title": title})

@app.route("/api/trash/<tname>", methods=["DELETE"])
def api_trash_delete(tname):
    d, safe = _safe_trash_child(tname)
    if not d.exists():
        abort(404)
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"ok": True})

@app.route("/api/projects/<project>/duplicate", methods=["POST"])
def api_duplicate_project(project):
    """Deep-copy a project (all files + scenes.json) into a NEW, fully independent project. The folder
    gets the next -vN version; the display title gets a bumped ' vN'. Editing one never touches the other."""
    src, safe = proj_dir(project)
    if not (src / "scenes.json").exists():
        abort(404)
    doc = load_doc(project)
    # unique folder name: bump a trailing -vN (or add -v2), skipping any that already exist
    m = re.match(r"^(.*?)[-_ ]v(\d+)$", safe, re.I)
    stem, n = (m.group(1), int(m.group(2))) if m else (safe, 1)
    while True:
        n += 1
        new_name = f"{stem}-v{n}"
        if not (PROJECTS / new_name).exists():
            break
    # display title: bump a trailing vN, else append ' v2'
    tm = re.match(r"^(.*?)[-_ ]v(\d+)$", (doc.get("title") or "").strip(), re.I)
    new_title = (f"{tm.group(1).strip()} v{int(tm.group(2)) + 1}" if tm
                 else f"{(doc.get('title') or stem).strip()} v2")
    shutil.copytree(src, PROJECTS / new_name)
    d2 = json.loads((PROJECTS / new_name / "scenes.json").read_text(encoding="utf-8"))
    d2["name"], d2["title"] = new_name, new_title
    (PROJECTS / new_name / "scenes.json").write_text(json.dumps(d2, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"name": new_name, "title": new_title})

# ---- routes: scenes ---------------------------------------------------------
@app.route("/api/scenes/<project>")
def api_get_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    return jsonify(doc)

@app.route("/api/scenes/<project>", methods=["PUT"])
@_locked
def api_save_scenes(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    # only allow editable fields to be overwritten from the UI
    incoming = {s["id"]: s for s in body.get("scenes", [])}
    for s in doc["scenes"]:
        u = incoming.get(s["id"])
        if not u:
            continue
        # NOTE: "approved" is intentionally NOT here — it's managed only by the /approve endpoint.
        # Including it let a routine full-doc save (from a text edit) with a stale value clobber a
        # concurrent approve, silently un-approving images.
        for f in ("vo", "vo_tr", "note", "prompt", "refs", "cast", "ref_free", "product", "product_suggested", "split", "split_suggested", "states", "camera", "transition", "video_desc", "video_prompt", "video_cam_lock", "style", "no_cast", "model", "video_model", "video_dur", "video_res", "ost_on", "overlays"):
            if f in u:
                s[f] = u[f]
    if "title" in body:
        doc["title"] = body["title"]
    if "script" in body:
        doc["script"] = body["script"]
    if "audience" in body:
        doc["audience"] = body["audience"]
    if "brief" in body:
        doc["brief"] = body["brief"]
    if "subtitle_style" in body:
        doc["subtitle_style"] = body["subtitle_style"]   # global caption look (applies to all subtitles)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/video-models")
def api_video_models():
    return jsonify(VIDEO_MODELS)

@app.route("/api/scenes/<project>/insert", methods=["POST"])
def api_insert_scene(project):
    """Insert a blank scene after the given id (0 = at the start), then renumber."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    after = request.get_json(force=True).get("after", 0)
    scenes = doc["scenes"]
    idx = 0
    for i, s in enumerate(scenes):
        if s["id"] == after:
            idx = i + 1
            break
    scenes.insert(idx, new_scene(0))
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/duplicate", methods=["POST"])
def api_duplicate_scene(project, sid):
    """Clone a scene (all settings + overlays; the copy shares the original's image/video file
    references — regenerating either later just writes new files, so they never clash) and insert
    it right after, then renumber 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc["scenes"]
    idx = next((i for i, s in enumerate(scenes) if s["id"] == sid), None)
    if idx is None:
        return jsonify(doc)
    copy = json.loads(json.dumps(scenes[idx]))   # deep copy
    copy["uid"] = new_uid()                       # its OWN identity — so regenerating it can't overwrite the original's files
    scenes.insert(idx + 1, copy)
    for i, s in enumerate(scenes, 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/delete-scene", methods=["POST"])
def api_delete_scene(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] != sid]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/delete-scenes", methods=["POST"])
def api_delete_scenes(project):
    """Delete several scenes at once (multi-select). Removes all given ids, then renumbers 1..N."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = set(request.get_json(force=True).get("ids", []) or [])
    doc["scenes"] = [s for s in doc["scenes"] if s["id"] not in ids]
    for i, s in enumerate(doc["scenes"], 1):
        s["id"] = i
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/reorder", methods=["POST"])
def api_reorder(project):
    """Reorder scenes to the given list of ids, then RENUMBER 1..N (so output filenames follow)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    order = request.get_json(force=True).get("order", [])
    by_id = {s["id"]: s for s in doc["scenes"]}
    new = [by_id[i] for i in order if i in by_id]
    new += [s for s in doc["scenes"] if s["id"] not in order]   # safety: keep any missing
    for i, s in enumerate(new, 1):
        s["id"] = i
    doc["scenes"] = new
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/restore", methods=["POST"])
def api_restore(project):
    """Undo support: replace the editable doc state (scenes/audience/characters/refs/script) from a
    client snapshot and save it wholesale. Keeps name/title/created."""
    cur = load_doc(project)
    if cur is None:
        abort(404)
    snap = request.get_json(force=True) or {}
    for k in ("scenes", "audience", "characters", "product", "refs", "script", "brief"):
        if k in snap:
            cur[k] = snap[k]
    for s in cur.get("scenes", []):
        norm_scene(s)
    save_doc(project, cur)
    return jsonify(cur)

SPLIT_SYSTEM = """You segment a VSL (video sales letter) script into scenes for a video.
Each scene is the chunk of narration (VO) that is spoken while ONE image/clip is on screen.

Rules:
- DEFAULT to ONE sentence per scene — the large majority of scenes are a single sentence.
- You MAY split even a single sentence into two scenes when it clearly holds two DISTINCT visual ideas (e.g. a cause and its effect, or two separate actions, joined by "and"/"but"/a comma).
- MERGE two adjacent sentences into ONE scene ONLY when one of them is VERY SHORT (a few words) or a connective fragment that cannot stand on its own as an image — e.g. "And that's when it hit me.", "But it was too late.", "Here's the truth.", "Until now." Attach such a short fragment to the neighbouring sentence it belongs with.
- NEVER put three or more full sentences in one scene. A scene is AT MOST two sentences, and two only when one of them is very short.
- Do NOT change, add, remove, rephrase, reorder, or translate ANY words. Only decide where the cuts go. Keep the original wording, punctuation, and casing exactly.
- Output ONLY the scenes, ONE per line, in order. No numbering, no bullet points, no blank lines, no commentary."""

def split_script(script):
    """Split via Claude (Kie.ai). Raises on failure — NO naive fallback (bad splits)."""
    script = (script or "").strip()
    if not script:
        return []
    text = _claude_text(SPLIT_SYSTEM, script, max_tokens=8000)   # may raise
    parts = [re.sub(r"^\s*\d+[\.\)\-:]\s*", "", ln.strip()) for ln in text.splitlines() if ln.strip()]
    parts = [p for p in parts if p]
    if not parts:
        raise RuntimeError("splitter returned no scenes")
    return parts

def _parse_json_array(text):
    """Best-effort parse of a JSON array from an LLM reply (tolerates ```json fences / stray prose)."""
    t = (text or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\s*", "", t).rstrip("`").strip()
    a, b = t.find("["), t.rfind("]")
    if a < 0 or b < a:
        raise ValueError("no JSON array")
    return json.loads(t[a:b + 1])

# ---- NEW prompt pipeline (whole-script, conflict-free) --------------------------------------------
# 1) CAST DETECTION: read the whole script, list ONLY the recurring/central people so they can be kept
#    consistent (same face/look) across scenes. Generic one-off people are deliberately ignored.
CAST_SYSTEM = """You are a casting director for a VSL (video sales letter) advertisement. Read the ENTIRE script.

Identify ONLY the people who RECUR or are central to the story and therefore must look the SAME every time they appear — a specific named person, a protagonist whose journey we follow, a specific doctor/expert, the first-person narrator if they are ever shown.

IGNORE one-off or generic/background people who do NOT need to stay consistent (crowds, an anonymous passer-by, generic "people who struggle with X", a random patient shown once).

Carefully resolve pronouns and references across the WHOLE script to decide who each "she/he/they" is (the same pronoun can point to different people in different lines — e.g. the doctor in one place, the wife in another).

For EACH recurring person output:
- "label": a short stable name — their name if the script gives one (e.g. "Sophie", "Dr Carbonell"), else their role ("Narrator", "Doctor").
- "role": one or two words (e.g. "wife / patient", "doctor", "narrator").
- "desc": a concise FIXED physical description to keep them consistent (apparent gender, age range, 2-3 key visual traits). Infer sensibly from context; if unknown give a natural default that fits.

Output ONLY a JSON array, nothing else:
[{"label":"Sophie","role":"wife / patient","desc":"woman, 40s, warm but tired, shoulder-length brown hair"}]
If nobody recurs, output []."""


def _detect_cast_raw(script, brief=""):
    """Whole-script cast pass. RAISES on an LLM/parse failure so callers can tell a real error apart from a
    genuine 'nobody recurs' ([]). Use detect_cast() where a silent [] fallback is wanted (e.g. split)."""
    script = (script or "").strip()
    if not script:
        return []
    user = script
    if (brief or "").strip():
        user = "PROJECT CONTEXT (background, may be Turkish):\n" + brief.strip() + "\n\nSCRIPT:\n" + script
    data = _parse_json_array(_claude_text(CAST_SYSTEM, user, max_tokens=4000, model=PROMPT_MODEL))   # Opus 4.8: cast detection is a simple extraction — near-lossless vs Fable 5, and far fewer Kie overloads
    out, seen = [], set()
    for it in data:
        if not isinstance(it, dict):
            continue
        label = str(it.get("label") or "").strip()
        if not label or label.lower() in seen:
            continue
        seen.add(label.lower())
        out.append({"label": label, "role": str(it.get("role") or "").strip(), "desc": str(it.get("desc") or "").strip()})
    return out

def detect_cast(script, brief=""):
    """Whole-script pass → recurring people [{label, role, desc}]. Never raises (returns [] on any problem)."""
    try:
        return _detect_cast_raw(script, brief)
    except Exception:
        return []


# 2) DIRECTOR: ONE whole-script pass that replaces the old camera + analyze + per-scene-prompt passes.
#    For each scene it decides who's present (from the roster), any generic person, the on-screen CONTENT
#    (no camera/appearance/quality words — those are separate layers), camera, transition, continuity, style.
DIRECTOR_SYSTEM = """You are the director of a VSL (video sales letter) ad — a persuasion film, not a slideshow. You get the CAST roster (recurring people, each with a fixed description), an AUDIENCE note, and the full script cut into numbered scenes in order. First read the WHOLE script and map its persuasion arc; then design the single most persuasive IMAGE for each scene.

THINK about the arc first (do NOT output it). A VSL moves through stages — roughly: HOOK (grab attention, break a false belief), AGITATE (stack the pain, make it visceral and specific), ROOT CAUSE (why nothing has worked), ROCK BOTTOM (the emotional low / cost of inaction), SOLUTION (introduce the product/mechanism as the hero), PROOF (results, credibility, social proof), CTA (a calm, confident nudge to act). Infer each scene's role from its position and its line.

Then design each shot to ADVANCE persuasion at that moment — not a literal illustration of the words. Make each image VISUALLY DISTINCT from its neighbours and EMOTIONALLY SPECIFIC:
- Hook: a pattern-interrupt — an unexpected, arresting image that stops the scroll.
- Agitate / rock bottom: make the pain concrete and human — a telling gesture, a small revealing object, a real lived moment (never a generic "worried person in a room").
- Root cause: one simple, striking visual that explains WHY (a comparison, a hidden culprit).
- Solution: make the product/mechanism the clear HERO of the frame — appealing and unmistakable.
- Proof: something tangible — a result, a before/after, a credential, a real person's genuine reaction.
- CTA: one clear, confident focal subject, uncluttered.
Reach for a concrete object, a specific action, or a simple visual metaphor when it lands harder than a literal scene. VARY the compositions across the video — do not repeat the same setup shot after shot. But stay TRUE to what each scene's line is actually about: never introduce the product, a character, or a claim the line itself doesn't cover (e.g. don't show the product before the script brings it in).

For EACH scene output an object with:
- "present": the exact CAST labels visually present in this shot. Resolve pronouns/continuity across the whole script (the same "she" can be different people in different lines — read who each refers to). Use ONLY labels from the roster, spelled exactly. [] if only generic/ordinary people, or no person.
- "generic": if the shot shows an ordinary/one-off person who is NOT a roster character, a short description of them; else null. Never put a roster person here. AUDIENCE gender/age/look describes the RELATABLE, stand-in "viewer" people — use it ONLY as the DEFAULT for a person the line leaves unspecified (e.g. audience = women → an unspecified ordinary person is "a tired middle-aged woman at home"). If the sentence ITSELF fixes who the person is — a man, her husband, a father, a male doctor, a boy, or any explicitly-gendered role — depict EXACTLY that gender and NEVER flip them to match the audience. The audience default fills in only the people the line doesn't already gender; it never overrides an explicitly male (or explicitly female) person the script calls for.
- "shows": the image content — setting + subject + action + the key object(s) — vivid, specific and persuasion-advancing, in ONE or TWO sentences. CONTENT ONLY: describe WHAT is in the frame, never HOW it is shot. Do NOT mention camera / shot-size / angle / viewpoint, lighting, image quality or medium (photoreal/cartoon/3D/etc.), or a person's age/ethnicity/hair/skin (a roster person's look comes from their reference; refer to them by their label). Honor the AUDIENCE's location/currency for any signage, packaging, or setting.
- "camera": one key from: closeup, extreme, medium, wide, ots, top, side — pick the framing that best serves the shot's emotional job (closeup for an emotional beat / detail, wide to establish a place or group, ots for two people or someone regarding something, medium for one person acting, top for a laid-out comparison, side for movement/profile). FRAMING COHERENCE (critical): a closeup/extreme frame can only hold ONE localized region — either a face (head-and-shoulders) OR a single detail (e.g. hands on one object), NEVER both at once. If the shot needs the person's FACE / expression AND an action happening lower on the body at the same moment (at the waist / belt / trousers / stomach / hips / lap / knees / feet, or hands manipulating something down there), that spans two vertically-distant regions — do NOT use closeup or extreme, because the tight crop crushes the two regions together into distorted anatomy (a face landing on the belly). Use medium (or wider) so both fit naturally. Reserve closeup/extreme for when ONLY one region truly matters.
- "transition": how this scene cuts to the NEXT: one of none, crossfade, dip-black, dip-white, slide-left, slide-right, slide-up, slide-down. "none" (a clean hard cut) is the DEFAULT and should be the MAJORITY — a VSL is punchy. Use others only when clearly earned (slide = moving through a list/steps; crossfade = soft emotional/time beat; dip-black = hard chapter break / low point; dip-white = realization/hope).
- "continues": if this shot is the SAME place with the SAME people simply continuing an EARLIER scene, that earlier scene's number; else 0. Only when BOTH setting AND people carry over.
- "style": "natural" for everyday people/lifestyle/products; "scientific" ONLY for inside-the-body / microscopic biology (organs, cells, blood vessels, anatomy). Everyday scenes stay "natural".
- "product": true if this shot should prominently show the ADVERTISED PRODUCT ITSELF — the finished, branded bottle/package/supplement being sold (named in the PROJECT CONTEXT / brief), e.g. the product held, on a table, or as a hero shot. false for everything else (raw ingredients, generic props, or shots with no product). Use true only for the actual sold product. When true, in "shows" name the product by its ACTUAL brand name from the brief (e.g. "a bottle of CitruSlim" / "the CitruSlim bottle"), never a generic "a bottle" or "a supplement".
- INGREDIENTS vs PILLS (important for "shows"): when the line is about ingredients, extracts, herbs, fruits, roots, botanicals or a natural remedy — and it is NOT the finished branded product — depict them in their NATURAL, RAW form: the actual plant / fruit / root / seeds / leaves / peel, or a natural blend, mixture, powder, tea, tincture or liquid being prepared or measured out. Do NOT draw them as capsules, pills, tablets, softgels or a supplement bottle. Capsules / pills / tablets appear ONLY when the script itself is about the finished pill-form product. So "taking extracts" → the raw extract or the ingredient it comes from (e.g. sliced blood oranges, a dropper of extract), NOT a capsule.
- "split": true ONLY if this line pairs distinct visual ideas that are best shown as side-by-side panels in ONE image — e.g. an ingredient AND its effect, a cause AND its result, a problem AND its solution, a direct comparison, or before/after. Use SPARINGLY; the vast MAJORITY of scenes are a single unified image (false). When true, count the distinct ideas the line pairs: TWO ideas → two halves, THREE ideas → three thirds (only if the line genuinely names three things — e.g. three ingredients, three steps, before/during/after; NEVER pad two ideas into three). Write "shows" as those panels explicitly, in order: for two use "LEFT: <left>. RIGHT: <right>."; for three use "LEFT: <left>. MIDDLE: <middle>. RIGHT: <right>." — and STATE THE LOOK of each panel inline (photorealistic photo / 2D cartoon / scientific 3D medical illustration), because a split has no global style. Panels MAY use DIFFERENT looks when the content calls for it (e.g. "LEFT, photorealistic: a doctor examining a patient. RIGHT, scientific 3D medical illustration: a cross-section of the liver breaking down fat."). Do NOT mention any dividing line (there is none).

- "states": include this ONLY when a CAST member marked [TRANSFORMS …] in the roster is present in THIS shot. It is an object mapping that character's exact label to their STAGE at this point of the script: "start" (before the change has visibly begun), "mid" (partway through — the change is clearly visible but not complete), or "end" (fully transformed). Judge the stage from WHERE this scene sits in the arc and what the line implies (respect flashbacks — an early flashback to their finished state is "end"; a late memory of the old them is "start"). When such a character is present, ALSO describe their current stage inside "shows" (e.g. "noticeably slimmer", "visibly leaner and more energetic"). Omit this field entirely when no transforming character is present.

Output ONLY a JSON array, one object per scene IN ORDER (position = scene number; do not add a number field), nothing else. No prose, no code fences:
[{"present":["Dr Carbonell"],"generic":null,"shows":"...","camera":"ots","transition":"none","continues":0,"style":"natural","product":false,"split":false,"states":{}}]"""


def _audience_note(aud):
    if not aud:
        return "(no specific audience set)"
    bits = []
    for k, lbl in (("genders", "gender(s)"), ("ages", "age(s)"), ("locations", "location/market"), ("currencies", "currency")):
        v = aud.get(k)
        if v:
            bits.append(f"{lbl}: {', '.join(v)}")
    excl = aud.get("appearance")
    if excl:
        bits.append("avoid these looks for ordinary people: " + ", ".join(excl))
    return "; ".join(bits) if bits else "(no specific audience set)"


DIRECTOR_CHUNK = 25   # scenes described per director call — bounds the JSON OUTPUT so a long script never truncates

# A closeup/extreme crop can hold only ONE localized region. When a shot's description asks for BOTH a
# face/expression AND an action lower on the body (waist/belt/trousers/stomach/hips/lap/knees/feet, or
# hands working down there), those two regions sit too far apart vertically for a tight crop — the image
# model collapses them into mangled anatomy (the classic 'face landing on the belly', scene #91). We
# detect that co-occurrence to widen the director's AUTO camera pick to a medium shot. Both cues are
# required, so a plain face closeup (emotional beat) or a single-object detail macro never trips it.
_FRAMING_FACE_CUES = re.compile(
    r"\b(face|smil\w+|grin\w+|laugh\w+|frown\w+|expression|eyes?|cheeks?|mouth|tearful|crying|beaming|wink\w*)\b",
    re.I)
_FRAMING_LOWER_CUES = re.compile(
    r"\b(belt|waist\w*|trousers?|pants|jeans|belly|stomach|tummy|midriff|hips?|buckle|notch|"
    r"lap|knees?|thighs?|shoelaces?|laces|ankles?|hem|crotch|groin)\b",
    re.I)
def _framing_conflict(text):
    """True when a shot demands BOTH a face/expression and a waist-or-lower / hands-down-there action —
    the co-occurrence a tight crop can't hold without distorting anatomy. Used only to widen the
    director's auto camera pick; never touches a camera the user set by hand."""
    t = text or ""
    return bool(_FRAMING_FACE_CUES.search(t) and _FRAMING_LOWER_CUES.search(t))

def direct_scenes(scene_texts, characters, aud=None, brief="", targets=None, split_overrides=None):
    """Whole-script director, processed in CHUNKS. Every call sees the ENTIRE script (so the arc and
    pronoun continuity stay correct) but only OUTPUTS a slice of scenes — that keeps each reply's JSON
    small enough to never truncate, even on a 100-scene VSL. Per scene:
    {cast:[ids], generic, prompt, camera, transition, continues, style, product_suggested, director_failed}.
    director_failed=True means the director could NOT produce that scene — the caller surfaces it instead of
    silently pasting the raw voice-over line into the prompt (the old, invisible failure mode).

    `targets` (0-based indices) → produce output ONLY for those scenes (still with the FULL script as context).
    Used when re-generating a hand-picked subset: ~30× cheaper and seconds instead of a whole-script pass, and
    picking a contiguous set (e.g. one long line the user cut into 3) gets them designed together → distinct."""
    n = len(scene_texts)
    if not n:
        return [], {"model_label": "", "fable_down": False, "fable_err": None}
    chars = [c for c in (characters or []) if c.get("name")]
    id_by_lower = {c["name"].strip().lower(): c.get("id") for c in chars}
    trans_ids = {c.get("id") for c in chars if c.get("transforms")}   # characters whose look changes across the video
    roster = "\n".join(f"- {c['name']}"
                       + (f" ({c.get('role')})" if c.get("role") else "")
                       + (f": {c.get('desc')}" if c.get("desc") else "")
                       + (f" [TRANSFORMS across the video — {(c.get('transform_note') or '').strip() or 'their appearance changes gradually over the script'}; for each shot they appear in, decide their stage: start / mid / end]" if c.get("transforms") else "")
                       for c in chars) or "(none — every scene's people are generic/ordinary)"
    has_transformers = any(c.get("transforms") for c in chars)
    numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(scene_texts))
    base = f"CAST roster:\n{roster}\n\nAUDIENCE: {_audience_note(aud)}\n"
    if (brief or "").strip():
        base += f"\nPROJECT CONTEXT (may be Turkish; use it to understand the product/story, do NOT copy it into scenes):\n{brief.strip()}\n"
    base += f"\nFULL SCRIPT — all {n} scenes in order, for arc & pronoun continuity (CONTEXT ONLY):\n{numbered}\n"
    if has_transformers:
        base += ("\nNOTE: one or more cast are marked [TRANSFORMS …]. For EVERY shot such a character appears in, you MUST set "
                 "\"states\" with their stage (start/mid/end) judged from the arc, and describe that stage in \"shows\".\n")

    # which scenes to actually OUTPUT, grouped into director calls (each call ≤ DIRECTOR_CHUNK scenes)
    if targets is None:
        out_idx = list(range(n))
    else:
        out_idx = sorted({i for i in targets if 0 <= i < n})
    groups = [out_idx[x:x + DIRECTOR_CHUNK] for x in range(0, len(out_idx), DIRECTOR_CHUNK)]

    raw = [None] * n   # parsed director object per scene, or None if that scene wasn't produced / its chunk failed
    use_fable = True                     # prefer Fable 5 (best at the whole-script arc pass)…
    used = set()                         # …but Kie's Fable capacity is flaky ("Resources are tight"): on the
    fable_err = None                     #    first Fable CALL failure, drop to Opus 4.8 for the rest of this run
    for idxs in groups:
        if not idxs:
            continue
        nums = [i + 1 for i in idxs]     # 1-based scene numbers this call must output
        k = len(idxs)
        contiguous = (nums == list(range(nums[0], nums[-1] + 1)))
        which = (f"SCENES {nums[0]}–{nums[-1]}" if contiguous else "SCENES " + ", ".join(map(str, nums)))
        ask = base + (f"\nNow write the director objects for {which} ONLY: a JSON array of EXACTLY {k} object(s), "
                      f"in that exact order — the 1st object is scene {nums[0]} and the last is scene {nums[-1]}. "
                      f"Do NOT include any other scene, and do NOT add a scene-number field. JSON array only.")
        if split_overrides:   # the user has forced split on/off for some scenes → the director MUST honour it
            fs = [i + 1 for i in idxs if split_overrides.get(i) is True]
            fo = [i + 1 for i in idxs if split_overrides.get(i) is False]
            notes = []
            if fs:
                notes.append(f"Scene(s) {', '.join(map(str, fs))}: the user REQUIRES a SPLIT here. Writing a single image is FORBIDDEN. "
                             f"You MUST split the line into complementary panels — put the main subject/cause on one side and its "
                             f"effect, result, context or a contrasting view on the other. Use THREE panels only if the line genuinely "
                             f"names three distinct things (three ingredients/steps, before/during/after); otherwise TWO. Write \"shows\" "
                             f"starting EXACTLY with \"LEFT: … RIGHT: …\" (two panels) or \"LEFT: … MIDDLE: … RIGHT: …\" (three panels), "
                             f"stating each panel's look. There is ALWAYS a way to split a line; find it. Set split=true for these.")
            if fo:
                notes.append(f"Scene(s) {', '.join(map(str, fo))} MUST be split=false — a single unified image (no LEFT/RIGHT).")
            if notes:
                ask += "\nUSER OVERRIDES (obey exactly): " + " ".join(notes)
        budget = min(16000, max(6000, 2500 + 260 * k))
        data = None
        for model in ([SMART_MODEL, PROMPT_MODEL] if use_fable else [PROMPT_MODEL]):
            tries = 2 if model == SMART_MODEL else 8   # give flaky Fable only a quick shot, then lean on reliable Opus
            for _attempt in range(2):                  # one clean retry for a garbled/parse reply (model DID respond)
                try:
                    txt = _claude_text(DIRECTOR_SYSTEM, ask, max_tokens=budget, model=model, tries=tries)
                except Exception as e:                 # the CALL failed (overload / 500 / network) — don't hammer it
                    if model == SMART_MODEL:
                        use_fable = False              # Fable is down → stop trying it for the remaining chunks
                        fable_err = str(e)
                    break
                try:
                    got = _parse_json_array(txt)
                except Exception:
                    continue                           # replied but unparseable → retry once
                if isinstance(got, list) and got:
                    data = got
                    used.add(model)
                    break
            if isinstance(data, list):
                break
        if not isinstance(data, list):
            continue
        seg = data
        if len(data) == n and n != k:      # model ignored the slice and returned the WHOLE array → take our window
            seg = [data[i] for i in idxs]
        for j, i in enumerate(idxs):
            raw[i] = seg[j] if (j < len(seg) and isinstance(seg[j], dict)) else None

    out = []
    for i in range(n):
        item = raw[i]
        desc = ""
        if isinstance(item, dict):
            desc = str(item.get("shows") or item.get("scene") or item.get("scene_desc") or "").strip()
        if not desc:            # no usable shot description → FAIL LOUD, never fall back to the raw VO line
            out.append({"cast": [], "generic": None, "prompt": "", "camera": DEFAULT_CAMERA,
                        "transition": "none", "continues": 0, "style": DEFAULT_STYLE,
                        "product_suggested": False, "director_failed": True})
            continue
        cids = []
        for nm in (item.get("present") or []):
            cid = id_by_lower.get(str(nm).strip().lower())
            if cid is not None and cid not in cids:
                cids.append(cid)
        cam = str(item.get("camera") or "").strip().lower()
        cam = cam if cam in CAMERA_ANGLES_BY_KEY else DEFAULT_CAMERA
        # Safety net for the director's AUTO pick (a user's manual camera is saved on its own path and
        # never reaches here): a closeup/extreme frame holds one region — if the shot needs the face AND
        # a waist/lower-body action, widen to medium so the model doesn't crush them into bad anatomy.
        if cam in ("closeup", "extreme") and _framing_conflict(desc):
            cam = "medium"
        tr = item.get("transition")
        tr = tr if tr in TRANSITIONS else "none"
        try:
            cont = int(item.get("continues") or 0)
        except (TypeError, ValueError):
            cont = 0
        if not (1 <= cont <= i):
            cont = 0
        st = str(item.get("style") or "").strip().lower()
        st = st if st in ("natural", "scientific") else DEFAULT_STYLE
        gen = item.get("generic")
        gen = str(gen).strip() if gen else None
        states = {}                       # per-scene stage (start/mid/end) for any transforming cast present → keyed by char id
        raw_states = item.get("states")
        if trans_ids and isinstance(raw_states, dict):
            for lbl, v in raw_states.items():
                cid = id_by_lower.get(str(lbl).strip().lower())
                v = str(v or "").strip().lower()
                if cid in trans_ids and cid in cids and v in ("start", "mid", "end"):
                    states[cid] = v
        out.append({"cast": cids, "generic": gen, "prompt": desc, "camera": cam,
                    "transition": tr, "continues": cont, "style": st,
                    "product_suggested": bool(item.get("product")), "split": bool(item.get("split")),
                    "states": states, "director_failed": False})
    if targets is None:
        out[-1]["transition"] = "none"   # last scene of a FULL pass never transitions out (targeted subset leaves others alone)
    labels = {SMART_MODEL: "Fable 5", PROMPT_MODEL: "Opus 4.8"}
    model_label = " + ".join(labels[m] for m in (SMART_MODEL, PROMPT_MODEL) if m in used)
    meta = {"model_label": model_label,          # which model(s) actually produced the scenes (for a toast)
            "fable_down": fable_err is not None,  # True if Fable 5 was tried and failed → we fell back to Opus
            "fable_err": fable_err}
    return out, meta


@app.route("/api/scenes/<project>/analyze", methods=["POST"])
def api_analyze(project):
    """Whole-script cast detection → fills the project's character roster (name/role/desc) so the user can
    add a reference photo to each BEFORE splitting. Keeps existing characters + their photos."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = (request.get_json(force=True).get("script") or "").strip()
    if not script:
        return jsonify({"error": "No script to analyze."}), 400
    try:
        detected = _detect_cast_raw(script, doc.get("brief", ""))
    except Exception as e:
        # surface the real reason instead of a silent empty roster
        msg = str(e).lower()
        if "internal error" in msg or "try again" in msg or "500" in msg or "timeout" in msg or "timed out" in msg:
            return jsonify({"error": "The AI service (Kie.ai) is temporarily overloaded and returned a server "
                            "error. Nothing is wrong with your script — just click Analyze Cast again in a "
                            "moment."}), 503
        return jsonify({"error": f"Cast analysis failed: {e}. If this keeps happening, check this project's "
                        f"Kie API key and credit balance."}), 502
    chars = doc.setdefault("characters", [])
    by_lower = {c.get("name", "").strip().lower(): c for c in chars}
    added = 0
    for d in detected:
        ex = by_lower.get(d["label"].strip().lower())
        if ex:                                   # keep the user's photos/edits, just refresh role/desc if empty
            ex.setdefault("role", d["role"]); ex.setdefault("desc", d["desc"])
        else:
            chars.append({"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"],
                          "urls": [], "auto": True})
            added += 1
    save_doc(project, doc)
    return jsonify({"doc": doc, "detected": detected, "added": added})


@app.route("/api/scenes/<project>/split", methods=["POST"])
def api_split(project):
    """Split the script into meaningful scenes via Claude (Kie.ai). Surfaces errors; no fallback.
    Then a whole-script director pass auto-assigns camera framing, transitions, cast, and continuity."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    script = request.get_json(force=True).get("script", "")
    try:
        parts = split_script(script)
    except Exception as e:
        return jsonify({"error": f"Split failed: {e}"}), 502
    # Make sure a cast roster exists so the director can keep recurring people consistent. If the user
    # already ran "Analyze Script" (and maybe added photos) we KEEP that roster; otherwise detect now.
    if not [c for c in (doc.get("characters") or []) if c.get("name")]:
        for d in detect_cast(script, doc.get("brief", "")):
            doc.setdefault("characters", []).append(
                {"id": new_uid(), "name": d["label"], "role": d["role"], "desc": d["desc"], "urls": [], "auto": True})
    # ONE whole-script director pass: who's present, generic person, on-screen content, camera, transition,
    # continuity, style — all resolved together so nothing conflicts and identity stays consistent.
    plan, dmeta = direct_scenes(parts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""))
    doc["scenes"] = []
    for i, sent in enumerate(parts, 1):
        sc = new_scene(i)
        sc["vo"] = sent
        a = plan[i - 1] if i - 1 < len(plan) else {}
        sc["prompt"] = a.get("prompt") or ""          # the director already wrote the on-screen content
        sc["cast"] = a.get("cast") or []
        sc["generic"] = a.get("generic")              # a non-roster ordinary person for this shot (or None)
        sc["camera"] = a.get("camera") or DEFAULT_CAMERA
        sc["transition"] = a.get("transition") or DEFAULT_TRANSITION
        sc["style"] = a.get("style") or DEFAULT_STYLE
        sc["product_suggested"] = bool(a.get("product_suggested"))   # director thinks the product belongs in this shot → hint the user
        sc["split"] = bool(a.get("split"))                           # two-panel/diptych composition (director decided)
        sc["split_suggested"] = bool(a.get("split"))                 # director chose split here → pulse the button green until the user touches it
        sc["states"] = a.get("states") or {}                         # transforming cast → stage (start/mid/end) at this scene
        bind_named_cast(sc, doc)                                     # any roster character NAMED in the prompt → face-lock them too
        sc["_cont"] = a.get("continues") or 0        # temp: 1-based source scene #, resolved to a uid below
        doc["scenes"].append(sc)
    for sc in doc["scenes"]:                          # resolve continuity #→uid now that every scene has a uid
        c = sc.pop("_cont", 0)
        sc["cont_of"] = doc["scenes"][c - 1]["uid"] if 1 <= c <= len(doc["scenes"]) else None
    save_doc(project, doc)
    failed = [i + 1 for i, a in enumerate(plan) if a.get("director_failed")]   # never silently ship raw-VO prompts
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)                              # which model actually ran (toast)
    if failed:
        resp["director_warning"] = (f"The director could not write a shot description for {len(failed)} scene(s): "
                                    f"{', '.join(map(str, failed))}. Their prompts are left empty — use “Re-run "
                                    f"director” or write/Generate a prompt for those scenes.")
    return jsonify(resp)

def _looks_multi(vo):
    """Cheap check: does this voice-over hold more than one sentence? (a sentence-ender with more text after
    it). Lets re-split skip single-sentence scenes entirely — no LLM call, nothing touched."""
    return bool(re.search(r"[.!?…]['\"”’)]?\s+\S", (vo or "").strip()))

@app.route("/api/scenes/<project>/resplit", methods=["POST"])
@_locked
def api_resplit_scenes(project):
    """WORK-PRESERVING re-split: break only the scenes whose voice-over holds several sentences into one
    sentence each. Single-sentence scenes are left 100% untouched (prompt, image, cast, approval all kept).
    For a multi-sentence scene, the FIRST sentence stays on the original scene (keeping its media/prompt);
    the extra sentences become NEW blank scenes right after it. Fixes old 3-4-sentence scenes without
    rebuilding the whole project. (New splits already follow the one-sentence rule, so this is a one-off tidy.)"""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    out, split_count, added, kept_approved = [], 0, 0, 0
    for s in scenes:
        vo = (s.get("vo") or "").strip()
        if s.get("approved"):                 # finalized scene → NEVER disturb it (unapprove first if you want it re-split)
            out.append(s)
            if _looks_multi(vo):
                kept_approved += 1
            continue
        if not _looks_multi(vo):
            out.append(s)                     # single sentence → untouched
            continue
        try:
            parts = [p for p in split_script(vo) if p.strip()]
        except Exception:
            out.append(s)                     # splitter hiccup → leave this scene as-is
            continue
        if len(parts) <= 1:
            out.append(s)
            continue
        s["vo"] = parts[0]                    # first sentence stays on THIS scene (keeps its image/prompt/cast)
        out.append(s)
        for extra in parts[1:]:
            ns = new_scene(0)
            ns["vo"] = extra
            ns["uid"] = new_uid()
            out.append(ns)
            added += 1
        split_count += 1
    for i, s in enumerate(out, 1):
        s["id"] = i
    doc["scenes"] = out
    save_doc(project, doc)
    resp = dict(doc)
    resp["resplit"] = {"split": split_count, "added": added, "total": len(out), "kept_approved": kept_approved}
    return jsonify(resp)

def _director_note(meta):
    """One-line 'which model ran the director' message for a toast (e.g. 'Director: Opus 4.8 — Fable 5 was
    unavailable (Resources are tight)'). Returns '' if the director produced nothing."""
    meta = meta or {}
    label = meta.get("model_label") or ""
    if not label:
        return ""
    note = f"Director: {label}"
    if meta.get("fable_down"):
        err = (meta.get("fable_err") or "").strip()
        note += " — Fable 5 was unavailable" + (f" ({err})" if err else "") + ", used Opus 4.8"
    return note

@app.route("/api/scenes/<project>/redirect", methods=["POST"])
def api_redirect_scenes(project):
    """Re-run the whole-script director over the EXISTING scenes.
    - No selection (whole-doc): REPAIR only — rewrite prompts that are empty or just the raw voice-over line,
      and KEEP any prompt you wrote yourself. Voice-over, images and order are always preserved.
    - With `ids` (a selection): a FULL redo of just those scenes — the director re-decides EVERYTHING
      (prompt, cast, camera, transition, style, product/split hints, transformation stage), overwriting them.
      RAW ("My prompt") scenes are still left untouched."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scenes = doc.get("scenes") or []
    if not scenes:
        return jsonify({"error": "No scenes yet — Split the script first."}), 400
    body = request.get_json(silent=True) or {}
    ids = body.get("ids")
    sel = set(ids) if ids else None            # a selection → FULL redo of those scenes; else whole-doc repair
    texts = [(s.get("vo") or "") for s in scenes]
    if sel is not None:
        targets = {i for i, s in enumerate(scenes) if s.get("id") in sel}
        split_overrides = {i: bool(scenes[i].get("split")) for i in targets if not scenes[i].get("no_cast")}
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides)
    else:
        plan, dmeta = direct_scenes(texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""))
    fixed, failed, kept = 0, [], 0
    for i, s in enumerate(scenes):
        a = plan[i] if i < len(plan) else {}
        if sel is not None:
            if s.get("id") not in sel:
                continue
            if s.get("no_cast"):               # RAW scene → the user's own prompt; never overwrite it
                kept += 1
                continue
        else:
            vo = (s.get("vo") or "").strip()
            cur = (s.get("prompt") or "").strip()
            broken = (cur == "" or cur == vo)  # empty, or the raw VO pasted in by the old fallback
            if not broken:
                kept += 1                      # a real, hand-written/earlier-good prompt → never touch it
                continue
        if a.get("director_failed"):
            failed.append(i + 1)
            continue
        s["prompt"] = a.get("prompt") or ""
        s["cast"] = a.get("cast") or []
        s["generic"] = a.get("generic")
        s["camera"] = a.get("camera") or DEFAULT_CAMERA
        s["transition"] = a.get("transition") or DEFAULT_TRANSITION
        s["style"] = a.get("style") or DEFAULT_STYLE
        s["product_suggested"] = bool(a.get("product_suggested"))
        s["split"] = bool(a.get("split"))
        s["split_suggested"] = bool(a.get("split"))
        s["states"] = a.get("states") or {}
        bind_named_cast(s, doc)                     # face-lock any roster character the prompt names
        s["_cont"] = a.get("continues") or 0
        fixed += 1
    for s in scenes:                           # resolve continuity #→uid for the scenes we rewrote
        c = s.pop("_cont", 0)
        if c:
            s["cont_of"] = scenes[c - 1]["uid"] if 1 <= c <= len(scenes) else None
    save_doc(project, doc)
    return jsonify({"fixed": fixed, "kept": kept, "failed": failed, "total": len(scenes),
                    "note": _director_note(dmeta)})

# ---- routes: prompt generation (Anthropic) ---------------------------------
PROMPT_SYSTEM = """You describe what is SHOWN on screen for ONE scene of a VSL (video sales letter).
You get the spoken sentence (VO) and, optionally, an on-screen note. Output a vivid description of the CONTENT of the shot only.

INCLUDE:
- the subject(s) and their action, the setting/location, and the key objects in view
- concrete, specific, visual detail that illustrates the sentence's meaning

DO NOT INCLUDE (other layers own these — including them causes conflicts):
- ANY framing, shot size, camera angle or viewpoint (no "close-up", "wide view", "over the shoulder", "top view", "from the side", "in the foreground") — a separate Camera Angle layer owns this
- camera/lens/aperture/shot technicalities (no "85mm", "f/2.0", "DSLR", "drone shot")
- lighting descriptions (no "soft light", "golden hour")
- image-quality or medium words (no "photorealistic", "cinematic", "4k", "HDR", "amateur", "2D", "animation", "render", "illustration")
- the person's age, ethnicity, hair, or skin — describe people only by role/action ("a woman", "a doctor", "her hands"), UNLESS the user lists named characters present in the scene, in which case use their name for that person (e.g. "Loretta") instead of a generic role
- any on-screen text, captions, logos, or watermarks

Also choose the single best STYLE for this moment:
- natural    = real people / lifestyle / everyday objects, food, product, scenery
- 2d         = animation / illustration / motion-graphics
- scientific = inside-the-body / anatomy / microscopic biology / medical visualization

OUTPUT FORMAT: the FIRST line must be exactly "STYLE: <key>" (natural|2d|scientific).
Then, on the following line(s), output ONLY the content description — no preamble, no quotes, no explanation.
If a required STYLE is given by the user, you MUST use that one."""

def char_has_photo(c):
    """A USER-provided reference photo exists (not the auto-anchor)."""
    return bool((c.get("urls") and any(c.get("urls"))) or c.get("url"))

def char_urls(c):
    """Every reference image used to keep a character's face consistent: user-provided photos PLUS the
    auto-anchor (the first approved frame we adopted for a photo-less recurring person). New characters
    store `urls` (a list); legacy ones a single `url` — normalise both to a list."""
    urls = [u for u in (c.get("urls") or []) if u]
    if not urls and c.get("url"):
        urls = [c["url"]]
    if c.get("anchor"):
        urls = urls + [c["anchor"]]
    return urls

def scene_characters(scene, doc):
    """Resolve a scene's `cast` (character ids) against doc.characters → list of character dicts."""
    by_id = {c.get("id"): c for c in (doc.get("characters") or [])}
    return [by_id[cid] for cid in (scene.get("cast") or []) if cid in by_id]

# --- transforming characters (e.g. someone who slims down across the video) ------------------------
# A character marked `transforms` has TWO reference buckets: `urls` = START look (e.g. heavier) and
# `urls_end` = END look (e.g. slim). The director tags each scene with the character's STAGE at that
# point (start / mid / end); we then attach the matching photo(s) and word the face-lock accordingly,
# so the SAME face stays consistent while the body changes gradually over the script.
def _char_state(c, s):
    """This transforming character's stage in THIS scene: 'start' | 'mid' | 'end' (None if not transforming)."""
    if not c.get("transforms"):
        return None
    v = str((s.get("states") or {}).get(c.get("id")) or "").strip().lower()
    return v if v in ("start", "mid", "end") else "start"   # default to START (the original reference)

def char_end_urls(c):
    return [u for u in (c.get("urls_end") or []) if u]

def char_urls_for(c, s):
    """The reference image(s) to attach for this character IN THIS scene. Normal characters → all their
    photos. A transforming character → the photo(s) for their stage here (start / mid=both / end)."""
    base = char_urls(c)
    if not c.get("transforms"):
        return base
    end = char_end_urls(c)
    if not end:                       # slim photo not uploaded yet → behave like a normal character
        return base
    st = _char_state(c, s)
    if st == "end":
        return end or base
    if st == "mid":
        return base + end             # both looks → the model interpolates a believable in-between
    return base                       # start

def _transform_who(c, s):
    """Face-lock wording for a transforming character at its current stage: keep the SAME face, but let the
    BODY match this scene's stage (so a single set of photos still yields a gradual, on-model transformation)."""
    name = c.get("name") or "the character"
    st = _char_state(c, s)
    has_end = bool(char_end_urls(c))
    if st == "end":
        return (f"{name}: keep the EXACT SAME face, hair and identity as in the reference image; her body is at the "
                f"END of her transformation — slim, toned and fit, matching the slim reference. Only the body changes, never the face.")
    if st == "mid" and has_end:
        return (f"{name}: keep the EXACT SAME face, hair and identity as in the reference images. Her body is MID-transformation "
                f"— clearly and noticeably slimmer than the heavier (start) reference, but not yet as lean as the slim (end) reference. "
                f"Render a believable in-between weight. Only the body changes, never the face.")
    if st == "mid":
        return (f"{name}: keep the EXACT SAME face and hair as in the reference; her body is MID-transformation — clearly and "
                f"noticeably slimmer than in the reference (do NOT copy the reference's fuller body). Only the body changes, never the face.")
    return (f"{name}: depict with the SAME face and overall appearance as in the reference — she is at the START, before her transformation.")

def _auto_anchor(doc, s):
    """AUTO-ANCHOR: when a scene is approved and it contains EXACTLY ONE recurring cast character that
    has no reference photo AND no anchor yet, adopt this approved frame as that character's anchor. From
    then on later scenes with that character use it as an i2i face-lock, so a photo-less recurring person
    stays the same face across the whole video. Ambiguous shots (2+ un-anchored photo-less people) are
    skipped — we can't attribute a single face. Mutates the shared character dict in doc (persisted on save)."""
    approved = (s.get("image") or {}).get("approved_file") or (s.get("image") or {}).get("file")
    if not approved:
        return
    fresh = [c for c in scene_characters(s, doc) if not char_has_photo(c) and not c.get("anchor")]
    if len(fresh) == 1:
        fresh[0]["anchor"] = approved

def _cont_source(scene, doc):
    """The earlier scene this one visually continues (same place + people), by stable uid, or None."""
    u = scene.get("cont_of")
    return next((x for x in doc.get("scenes", []) if x.get("uid") == u), None) if u else None


def _claude_text(system, user, max_tokens=1024, model=None, tries=8):
    # The Kie.ai Claude endpoint intermittently returns HTTP 500 ("Internal error, please try again later").
    # A single blip used to fail the whole call (empty cast, failed split, etc.), so retry with backoff —
    # every LLM pass (cast detect, split, director, per-scene prompts) rides out these transient errors.
    def _do():
        r = requests.post(KIE_CLAUDE_URL,
                          headers={"Authorization": f"Bearer {KIE_KEY}", "Content-Type": "application/json"},
                          json={"model": model or PROMPT_MODEL, "max_tokens": max_tokens, "system": system,
                                "messages": [{"role": "user", "content": user}]},
                          timeout=120)
        d = r.json()
        blocks = d.get("content") or []
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
        if not text:
            err = d.get("msg") or d.get("error") or f"HTTP {r.status_code}"
            if isinstance(err, dict):
                err = err.get("message") or err.get("type") or json.dumps(err)
            raise RuntimeError(err)
        return text
    return _retry(_do, tries=tries, base=0.8)   # Kie's Claude endpoint 500s in bursts — retry (backoff capped at 5s) so it self-heals; callers pass a small `tries` when they have a fallback model ready

def claude_prompt(vo, onscreen, aud=None, forced_style=None, cast_names=None, brief=""):
    """Ask Claude (via Kie.ai) for (image_prompt, style_key)."""
    user = f"VO sentence: {vo}"
    if onscreen:
        user += f"\nOn-screen note: {onscreen}"
    if (brief or "").strip():
        user += (f"\n\nPROJECT CONTEXT (background about the whole project — may be in Turkish; for CONSISTENCY only): "
                 f"{brief.strip()}\nUse it to keep people, places, product and style consistent across scenes, but depict "
                 f"ONLY what THIS scene's VO describes — do NOT add the product, characters, or details the VO doesn't "
                 f"mention. Always write the final description in English.")
    if cast_names:
        user += (f"\nNamed characters present in THIS scene: {', '.join(cast_names)}. "
                 "When one of them appears, refer to them by their name (e.g. write the name, not "
                 "'a woman' / 'a man'). Do NOT invent characters who aren't in the sentence.")
    if forced_style:
        user += f"\nRequired STYLE: {forced_style}"
        if forced_style == "2d":
            user += ("\nThis scene will be drawn as a SIMPLE flat 2D cartoon, so describe it simply and iconically: "
                     "the key subject(s), their action, and only the one or two essential objects. Do NOT pile on fine "
                     "realistic micro-detail, intricate textures, or photographic specifics — those don't suit a flat cartoon.")
        elif forced_style == "scientific":
            user += ("\nThis scene is a medical / scientific visualization (inside the body, an organ, cells, etc.), so "
                     "describe the anatomical subject and what it shows clearly and specifically.")
    text = _claude_text(PROMPT_SYSTEM, user)
    style = None
    m = re.match(r"\s*STYLE:\s*([a-zA-Z0-9]+)", text)
    if m:
        k = m.group(1).lower()
        if k in STYLE_KEYS:
            style = k
        text = text[m.end():].lstrip("\n").strip()
    if forced_style:
        style = forced_style
    return text, style

def translate_to_english(text):
    return _claude_text(
        "Translate the user's image-generation prompt into natural English. "
        "Keep it as one single prompt with the same meaning. Output ONLY the translation.",
        text)

def localize_prompt(prompt, aud, translate=True, signage=False):
    """Translate Turkish prompts to English. `translate=False` keeps the user's exact wording.
    `signage=True` also requires any on-image text to be in the country's language — OFF by default
    because image prompts end with 'No text.', so a signage-language clause would only contradict it."""
    p = prompt or ""
    if translate and looks_turkish(p):
        try:
            p = translate_to_english(p)
        except Exception:
            pass
    if signage:
        lang = country_language(aud)
        if lang and lang != "English":
            p = p.rstrip() + f" If any text, signage, or packaging appears, it must be written in {lang}."
    return p

_CURRENCY_HINT = {
    "pound": "British pounds — the £ symbol", "gbp": "British pounds — the £ symbol", "sterling": "British pounds — the £ symbol",
    "euro": "euros — the € symbol", "eur": "euros — the € symbol",
    "dollar": "US dollars — the $ symbol", "usd": "US dollars — the $ symbol",
    "lira": "Turkish lira — the ₺ symbol", "try": "Turkish lira — the ₺ symbol",
    "yen": "Japanese yen — the ¥ symbol", "rupee": "Indian rupees — the ₹ symbol",
}
# Money/price cues (English + Turkish). The currency directive below is emitted ONLY when the shot
# actually depicts money — so its "£ symbol" tokens can't leak onto money-less scenes. Image models
# ignore the "if any money appears" conditional and would otherwise sprinkle a £ into e.g. a phone-call
# shot (scene #58). Precision-tuned: 'sipariş'/'al'/'öde-'stem excluded so 'paragraf','ödev' don't trip it.
_MONEY_CUES = re.compile(
    r"[£$€₺]"
    r"|\b(money|cash|price[ds]?|pricing|cost|costs|costly|pay|paying|payment|payments|paid"
    r"|buy|buying|bought|purchas\w+|checkout|check-out|receipt|invoice|wallet|coin|coins"
    r"|dollar|dollars|euro|euros|currency|discount|discounts|afford|affordable|budget"
    r"|fee|fees|subscription|refund|refunds|coupon|price[- ]?tag)\b"
    r"|\bpara(lar|m|n|sı|yı|ya|yla|nın)?\b"
    r"|\bfiyat\w*|\bücret\w*|\bödeme\b|\bsatın\b|\balışveriş\w*"
    r"|\bsepet\w*|\bfatura\w*|\bmakbuz\w*|\bcüzdan\w*|\bnakit\b|\blira\b|\bsterlin\b"
    r"|\bkuruş\b|\bindirim\w*|\btaksit\w*|\bbütçe\w*|\bpahalı\b|\bucuz\b",
    re.I)
def _mentions_money(text):
    """True if the shot description plausibly depicts money/prices (English or Turkish)."""
    return bool(_MONEY_CUES.search(text or ""))

def _currency_clause(aud, text=""):
    """Currency directive for the final image prompt — emitted ONLY when `text` (the shot description)
    actually shows money/prices. Gating on money content stops the "£ symbol" tokens leaking onto
    money-less scenes. Fixes the model defaulting to US dollars when the audience is e.g. UK/£."""
    curs = [str(c).strip() for c in ((aud or {}).get("currencies") or []) if str(c).strip()]
    if not curs or not _mentions_money(text):
        return ""
    hint = _CURRENCY_HINT.get(curs[0].lower(), curs[0])
    return (f"If any money, prices, price tags or currency appear anywhere in the image, they MUST be shown in "
            f"{hint} — NOT US dollars or any other currency.")

def _raw_audience_note(aud, text=""):
    """Compact Target-Audience reminder appended to a RAW (user-written) prompt: market/location, age band,
    excluded looks, and currency. Kept short so it never rewrites the user's own wording — used ONLY in raw mode.
    `text` is the shot description; the currency line is added only if it actually depicts money/prices."""
    if not aud:
        return ""
    bits = []
    locs = [str(x).strip() for x in (aud.get("locations") or []) if str(x).strip()]
    if locs:
        bits.append(f"Set it in a {', '.join(locs)} context — signage, packaging, products and surroundings "
                    f"appropriate to {', '.join(locs)}.")
    ages = [str(a).strip() for a in (aud.get("ages") or []) if str(a).strip()]
    if ages:
        bits.append(f"Any ordinary people shown should be adults roughly in the {' or '.join(ages)} age range.")
    excl = aud.get("appearance")
    if excl:
        bits.append("Do NOT depict ordinary people who look " + ", ".join(excl) + ".")
    cc = _currency_clause(aud, text)
    if cc:
        bits.append(cc)
    return " ".join(bits)

def bind_named_cast(s, doc):
    """Ensure every roster character NAMED in the scene's prompt is in the scene's cast, so their reference
    face actually attaches (fixes e.g. a split's LEFT half naming 'Dr Carbonell' but her not being cast).
    Additive only — never removes a cast the user picked. Skipped for RAW scenes. Returns True if it changed."""
    if s.get("no_cast"):
        return False
    prompt = (s.get("prompt") or "")
    if not prompt.strip():
        return False
    low = prompt.lower()
    cast = s.setdefault("cast", [])
    changed = False
    for c in (doc.get("characters") or []):
        cid = c.get("id")
        name = (c.get("name") or "").strip()
        if not cid or not name or cid in cast:
            continue
        if re.search(r"(?<![a-z])" + re.escape(name.lower()) + r"(?![a-z])", low):   # whole-name match, case-insensitive
            cast.append(cid)
            changed = True
    return changed

SPLIT_CLAUSE = ("Compose this as ONE single image split into two side-by-side panels of EQUAL width — a seamless "
                "diptych with NO dividing line, bar, border or frame between the two halves. The description gives a "
                "LEFT half and a RIGHT half; render each subject in its own half of the same frame. Each half is drawn "
                "in the LOOK stated for it — the two halves MAY use DIFFERENT styles (e.g. a photorealistic photo on one "
                "side and a scientific 3D medical illustration on the other); follow exactly the look written for each half.")

SPLIT_CLAUSE_3 = ("Compose this as ONE single image split into three side-by-side panels of EQUAL width — a seamless "
                  "triptych with NO dividing line, bar, border or frame between the panels. The description gives a "
                  "LEFT, a MIDDLE and a RIGHT panel; render each subject in its own third of the same frame, in that "
                  "left-to-right order. Each panel is drawn in the LOOK stated for it — the panels MAY use DIFFERENT "
                  "styles; follow exactly the look written for each panel.")

# A panel marker is the label word (left/middle/right) optionally followed by its inline look, then a colon —
# e.g. "LEFT:" OR "LEFT, photorealistic:" OR "RIGHT, scientific 3D medical illustration:".
def _panel_mark_re(key):
    return r"(?<![a-z])" + key + r"\b[^:\n]{0,40}:"

def _split_clause(prompt_text):
    """Pick the two- vs three-panel wording from what the prompt actually describes (a MIDDLE panel → triptych)."""
    return SPLIT_CLAUSE_3 if re.search(_panel_mark_re("middle"), (prompt_text or "").lower()) else SPLIT_CLAUSE

def _split_default_look(style):
    """A split skips the single global STYLE preset (each panel can state its own look). But the bare word
    'photorealistic' in a panel is a WEAK anchor — the model drifts to a glossy CGI/stock look. So re-apply
    the chosen style's FULL guidance as the DEFAULT look for any panel that doesn't explicitly call for a
    different medium. This is what pulls a 'photorealistic' panel back to a real, candid photo."""
    preset = STYLE_PRESETS.get(style or "natural", "")
    if not preset:
        return ""
    return ("DEFAULT LOOK — apply this to EVERY panel whose own description does not explicitly call for a "
            "different medium (a panel that literally says it is a 2D cartoon, or a scientific 3D medical "
            "illustration, keeps that): " + preset.strip())

def _panel_side_of(prompt_text, name):
    """Which panel (LEFT / MIDDLE / RIGHT) a named person is described in, by reading the split prompt. None
    if it can't be determined."""
    low = (prompt_text or "").lower()
    marks = []
    for key, disp in (("left", "LEFT"), ("middle", "MIDDLE"), ("right", "RIGHT")):
        m = re.search(_panel_mark_re(key), low)
        if m:
            marks.append((m.start(), disp))
    marks.sort()
    idx = low.find((name or "").lower())
    if idx < 0 or not marks:
        return None
    cur = None
    for p, disp in marks:
        if p <= idx:
            cur = disp
        else:
            break
    return cur

def _split_who(scene, chars):
    """WHO wording for a SPLIT with named cast: bind EACH person to their OWN reference face and their OWN
    panel, and forbid duplicating one face across panels. Fixes the bug where two different people (each with
    a photo) collapsed to the same face in both halves."""
    prompt = scene.get("prompt") or ""
    bits = []
    for c in chars:
        nm = c.get("name")
        if not nm:
            continue
        sd = _panel_side_of(prompt, nm)
        bits.append(f"{nm} (the {sd} panel)" if sd else nm)
    who = "; ".join(bits)
    return ("The reference images show DIFFERENT people, one per panel: " + who + ". Give EACH named person "
            "their OWN face and appearance from their OWN reference image — they are DISTINCT individuals and "
            "MUST look clearly different. Do NOT reuse or duplicate the same face across panels: the person in "
            "one panel must NOT also appear in another panel.")

def _gender_word(desc):
    """Confidently read a person's gender from their roster description, or None if unclear. Used only to
    ADD a gender anchor so a cast member keeps their gender even when the face is turned away / seen from
    behind (a reference photo can't lock gender when the face isn't visible). Never guesses when ambiguous."""
    d = " " + (desc or "").lower() + " "
    fem = bool(re.search(r"\b(woman|women|female|lady|girl|mother|wife|daughter|actress|businesswoman|grandmother|mom|mum)\b", d))
    masc = bool(re.search(r"\b(man|men|male|boy|father|husband|son|gentleman|businessman|grandfather|dad)\b", d))
    if fem and not masc:
        return "a woman"
    if masc and not fem:
        return "a man"
    return None

def _wants_text(prompt):
    """True if the prompt explicitly asks for specific text/numbers to be SHOWN in the image (a quoted phrase,
    a screen/label/sign reading something, 'show this number', etc.). Used to relax the blanket 'No text.' rule
    so the requested text survives while stray captions/watermarks are still blocked."""
    p = prompt or ""
    if re.search(r"[\"'“”‘’][^\"'“”‘’\n]{1,60}[\"'“”‘’]", p):   # any quoted phrase → they want it shown
        return True
    return bool(re.search(r"(reads?|reading|it says|that says|labell?ed|caption|on (the|its|her|his) screen|screen (show|display|read)|display(s|ing)?|billboard|headline|"
                          r"show(s|ing)? (this|these|the) (number|numbers|text|word|words|price|label|message|time|date))", p, re.I))

def build_image_prompt(scene, aud, chars=None, chars_desc=None):
    """Assemble the final Nano Banana prompt from NON-OVERLAPPING layers, each owning ONE thing so they
    can't conflict:  STYLE (how it looks) + SCENE (what's shown) + CAMERA (framing) + WHO (identity of
    recurring characters, via their reference image) + "No text".

    Audience gender/age/appearance is NOT bolted on here anymore (that collapsed everyone to one look and
    flipped genders scene-to-scene). Recurring people get their identity from the roster/reference; any
    ordinary/one-off person is already described (audience-appropriate) inside the scene text by the
    director. `chars` = the roster characters present in this scene that carry a reference image.
    The per-scene "no_cast" toggle = "MY PROMPT — raw": generate from the user's exact words like a direct
    manual generation (as if handed straight to the image model). It drops ALL auto layers — style preset,
    camera, roster characters, audience, auto-translate — and sends only the prompt (+ any reference image
    the user themselves attached to this scene) + "No text"."""
    chars = chars or []
    hand = bool(scene.get("no_cast"))
    if hand:
        # RAW mode ("My prompt"): send the user's prompt VERBATIM (their words, their language — not
        # translated, no style preset / camera / audience-diversity / "No text" layers). We add only:
        #   (a) FACE-LOCK for any cast in this scene that HAS a reference photo → the person still looks right,
        #   (b) a short AUDIENCE reminder (market/location, age band, excluded looks).
        # Any reference image the user attached is still sent as i2i.
        parts = [(scene.get("prompt") or "").strip()]
        if scene.get("split"):
            parts.append(_split_clause(scene.get("prompt")))
        rcam = None if scene.get("split") else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))   # honour the camera angle in RAW too (user asked)
        if rcam:
            parts.append(rcam["prompt"])
        if chars:
            normal = [c for c in chars if not c.get("transforms")]
            trans = [c for c in chars if c.get("transforms")]
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference image(s) show: {names}. Depict each of them with the SAME face and "
                             "overall appearance as in their reference.")
            for c in trans:
                parts.append(_transform_who(c, scene))
        extra = _raw_audience_note(aud, scene.get("prompt"))
        if extra:
            parts.append(extra)
        return "\n".join(p for p in parts if p and p.strip())
    parts = []
    split = bool(scene.get("split"))
    preset = STYLE_PRESETS.get(scene.get("style") or "natural", "")
    if preset and not split:   # a SPLIT styles each half from the prompt (director writes each half's look, possibly DIFFERENT) → no single global style preset
        parts.append(preset.strip())
    if split:
        parts.append(_split_clause(scene.get("prompt")))
        dl = _split_default_look(scene.get("style"))   # top style = DEFAULT look for the panels (so "photorealistic" = a real candid photo, not stock 3D)
        if dl:
            parts.append(dl)
    # SCENE content. Auto-translate Turkish → English (this is not the raw/hand path).
    parts.append(localize_prompt(scene.get("prompt") or "", aud, translate=True))
    cam = None if split else CAMERA_ANGLES_BY_KEY.get(scene.get("camera"))   # a split/diptych composition owns the framing → skip camera
    if cam:
        parts.append(cam["prompt"])
    # WHO (identity). Reference images are attached as i2i inputs elsewhere; name them so each maps right.
    if chars:
        normal = [c for c in chars if not c.get("transforms")]
        trans = [c for c in chars if c.get("transforms")]
        if split and len(normal) >= 2:        # a split with 2+ named people → bind each to their OWN panel + face (no face-mixing)
            parts.append(_split_who(scene, normal))
        else:
            names = ", ".join(c["name"] for c in normal if c.get("name"))
            if names:
                parts.append(f"The reference image(s) show: {names}. Depict each of them with the SAME face and "
                             "overall appearance as in their reference.")
        # Gender anchor (additive): a reference photo can't lock gender when the face is turned away / seen from
        # behind (e.g. an over-the-shoulder shot), so state it in text for any cast whose gender is CLEAR from
        # their roster description. Only fires when confident — otherwise nothing is added (no behaviour change).
        gnotes = [f"{c['name']} is {_gender_word(c.get('desc'))}" for c in normal
                  if c.get("name") and _gender_word(c.get("desc"))]
        if gnotes:
            parts.append("Keep each person's gender correct even if their face is turned away or seen from behind: "
                         + "; ".join(gnotes) + ".")
        for c in trans:                       # a person mid-transformation: same face, body per this scene's stage
            parts.append(_transform_who(c, scene))
    elif scene.get("refs"):
        refs = scene.get("refs") or []
        free = set(scene.get("ref_free") or [])
        if free & set(refs):
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face and identity faithful to the reference; their hairstyle may stay the same, "
                         "but they MUST wear DIFFERENT clothing/outfit that fits THIS scene — do NOT reuse "
                         "the same clothes as in the reference image.")
        else:
            parts.append("Depict the same person(s) shown in the provided reference image(s): keep their "
                         "face, hair, clothing/outfit and overall appearance faithful to the reference.")
    # recurring people WITHOUT a reference photo → inject their fixed roster description so they at least
    # stay look-consistent scene to scene (adding a reference photo later gives the exact same face).
    if chars_desc:
        who = "; ".join(f"{c['name']} ({c['desc']})" for c in chars_desc if c.get("name") and c.get("desc"))
        if who:
            parts.append("Keep these recurring people's appearance consistent every time: " + who + ".")
    # ORDINARY / one-off / background people: keep them a believable, DIVERSE mix so the video doesn't
    # show the same repeated face. This targets ONLY unnamed everyday people, never the referenced cast
    # above (whose look comes from their reference/description). Realistic style only. Also carries the
    # audience's "appearance to exclude" so unwanted looks are actually kept out at the image level (the
    # director alone can't enforce it — its scene text is barred from naming ethnicity/skin).
    # ORDINARY / one-off / background people: a DIVERSE mix (varied so the video doesn't repeat one face),
    # constrained to the audience AGE band, honouring the audience's excluded looks. Applies to people
    # styles (photoreal + 2D cartoon) — NOT scientific (inside-the-body anatomy has no ordinary people).
    # Targets only unnamed everyday people, never the named/recurring cast (whose look comes from their reference).
    if (scene.get("style") or "natural") != "scientific":
        excl = (aud or {}).get("appearance") if aud else None
        ages = [str(a).strip() for a in ((aud or {}).get("ages") or []) if str(a).strip()]
        age_phrase = " or ".join(ages) if ages else None
        # HARD rule first: never invent people. Only then, IF the scene itself calls for incidental people, vary them.
        line = ("Include ONLY the people the scene describes. Do NOT add any extra, background, bystander or random "
                "person who is not explicitly called for — no filling the scene with incidental people. ")
        if age_phrase:
            line += (f"IF (and only if) the scene naturally calls for ordinary/background people, they (NOT the "
                     f"named/recurring character(s) above) should be adults roughly in the {age_phrase} age range — not "
                     f"younger or older — and look like DIFFERENT individuals, naturally varied in body type, hair and "
                     f"ethnicity (not all the same look, not all grey-haired).")
        else:
            line += ("IF (and only if) the scene naturally calls for ordinary/background people, they (NOT the "
                     "named/recurring character(s) above) should look like DIFFERENT individuals — varied in age, body "
                     "type, hair and ethnicity.")
        if excl:
            line += " Do NOT depict ordinary people who look " + ", ".join(excl) + "."
        parts.append(line)
    cc = _currency_clause(aud, scene.get("prompt"))   # emitted only if the shot itself shows money/prices (e.g. UK → £, not $)
    if cc:
        parts.append(cc)
    # "No text" normally keeps out stray captions/watermarks — but if the prompt asks for specific text/numbers
    # (a scale reading "9 st 6 lb", a sign, a screen), a blanket "No text" fights it. In that case, allow the
    # requested text and block only the rest.
    if _wants_text(scene.get("prompt")):
        parts.append("Render the specific text/numbers described above ACCURATELY and legibly. Do NOT add any OTHER "
                     "text, captions, watermarks, logos or UI beyond what is explicitly described.")
    else:
        parts.append("No text.")
    return "\n".join(p for p in parts if p and p.strip())

@app.route("/api/scenes/<project>/genprompt", methods=["POST"])
def api_genprompt(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    scenes = doc.get("scenes", [])
    target_ids = None if ids == "all" else set(ids)
    # Re-generate uses the SAME whole-script director as Split (arc-aware, reads every scene together) —
    # not the old single-sentence pass — then applies ONLY the image prompt (+ style) to the target
    # scene(s). The user's camera / cast / transition / continuity are left exactly as they set them.
    scene_texts = [(s.get("vo") or "").strip() for s in scenes]
    # only the TARGETED scenes need director output — pass their indices so we don't burn a whole-script pass
    # (and ~30× the credits) to regenerate a handful. Full script still travels as context. "all" → whole pass.
    targets = None if target_ids is None else {i for i, s in enumerate(scenes) if s.get("id") in target_ids}
    # honour the user's SPLIT toggle when re-generating: force the director to write the target scene as two
    # halves (split on) or a single image (split off), so a manual Split choice actually shapes the prompt.
    tset = set(range(len(scenes))) if targets is None else targets
    split_overrides = {i: bool(scenes[i].get("split")) for i in tset if not scenes[i].get("no_cast")}
    dmeta = None
    try:
        plan, dmeta = direct_scenes(scene_texts, doc.get("characters"), doc.get("audience"), doc.get("brief", ""),
                                    targets=targets, split_overrides=split_overrides)
    except Exception:
        plan = None                                            # director failed → per-scene fallback below
    for i, s in enumerate(scenes):
        if target_ids is not None and s["id"] not in target_ids:
            continue
        if s.get("no_cast"):          # RAW ("My prompt") scene → it's the user's own text; never overwrite it
            continue
        vo = (s.get("vo") or "").strip()
        if not vo:
            continue
        try:
            if plan and i < len(plan) and (plan[i].get("prompt") or "").strip():
                s["prompt"] = plan[i]["prompt"]               # ONLY the image content — KEEP the user's chosen style
                # (style is a separate layer the user controls; re-generating the prompt must not revert it)
                # bind the recurring characters the director detected — but ONLY when the scene has no cast yet
                # (never overwrite a cast the user picked). Fixes manually-added scenes whose face wasn't locked.
                if not s.get("no_cast") and not (s.get("cast") or []):
                    if plan[i].get("cast"):
                        s["cast"] = plan[i]["cast"]
                    if plan[i].get("generic") and not s.get("generic"):
                        s["generic"] = plan[i]["generic"]
                if plan[i].get("states"):                      # transforming cast → their stage at this scene
                    s["states"] = plan[i]["states"]
            else:
                # fallback: the old single-sentence pass, so the button still works if the director errors
                cast_names = [c["name"] for c in scene_characters(s, doc) if c.get("name")]
                prompt, style = claude_prompt(vo, "", doc.get("audience"), s.get("style"), cast_names, doc.get("brief", ""))
                s["prompt"] = prompt
                if style:
                    s["style"] = style
            bind_named_cast(s, doc)   # ADD (never remove) any roster character the new prompt names — e.g. a split's
                                      # LEFT half names Dr Carbonell while the existing cast only had Dr Vasquez
            s["prompt_error"] = None
        except Exception as e:
            s["prompt_error"] = str(e)
    save_doc(project, doc)
    resp = dict(doc)
    resp["director_note"] = _director_note(dmeta)   # which model ran (toast) — Fable 5 / Opus 4.8
    return jsonify(resp)

# ---- routes: video-prompt generation ---------------------------------------
VIDEO_PROMPT_SYSTEM = """You write a SHORT image-to-video MOTION prompt for ONE shot of a VSL.
You are given the description of a STILL image. Describe subtle, realistic motion that brings that
still to life WITHOUT changing what it shows — a "living photo".

INCLUDE:
- ONE gentle camera move (a slow push-in, a slow pan, or a slight parallax/zoom)
- natural small subject/ambient motion that fits the scene (breathing, a slight head or hand movement,
  a blink, hair or clothing shifting, steam/liquid/light/particles drifting, leaves moving)

DO NOT:
- add or remove people or objects, change the setting, morph or transform anything
- cut to another shot, add on-screen text, or use fast, dramatic, or unrealistic motion
Keep it calm, minimal and grounded — it must stay faithful to the still image.

OUTPUT: 1-2 short sentences, ONLY the motion description. No preamble, no quotes."""

# Camera-LOCKED variant (the default): the camera does NOT move at all — only the subject/ambient moves.
VIDEO_PROMPT_SYSTEM_STATIC = """You write a SHORT image-to-video MOTION prompt for ONE shot of a VSL.
You are given the description of a STILL image. Describe subtle, realistic motion that brings that
still to life WITHOUT changing what it shows — a "living photo".

THE CAMERA IS LOCKED OFF (on a tripod) and does NOT move: NO push-in, NO pan, NO zoom, NO parallax,
NO tracking. Only the SUBJECT and AMBIENT elements move:
- natural small subject motion (breathing, a slight head or hand movement, a blink, hair or clothing
  shifting) and ambient motion (steam/liquid/light/particles drifting, leaves moving).

DO NOT: move the camera in any way; add or remove people or objects; change the setting; morph anything;
cut to another shot; add on-screen text; or use fast/dramatic/unrealistic motion.
Keep it calm, minimal and grounded, faithful to the still image, with a completely still camera.

OUTPUT: 1-2 short sentences, ONLY the motion description. No preamble, no quotes."""

_CAM_WORDS = ("camera", "zoom", "pan ", "push-in", "push in", "dolly", "tilt", "tracking", "parallax",
              "crane", "handheld", "orbit", "pull back", "pull-back", "kamera", "yakınlaş", "uzaklaş")


def _mentions_camera(text):
    t = (text or "").lower()
    return any(w in t for w in _CAM_WORDS)


def _apply_cam_lock(prompt, scene):
    """If this scene's camera is locked (default) AND the motion text doesn't already talk about the
    camera, spell out a completely static camera so the video model doesn't drift/zoom on its own."""
    if scene.get("video_cam_lock", True) and not _mentions_camera(prompt):
        prompt = (prompt or "").rstrip()
        prompt += (" " if prompt else "") + "The camera stays completely still (locked-off tripod): no camera movement, no zoom, no pan, no push-in."
    return prompt


def video_prompt_for(scene):
    """Generate a subtle, image-consistent motion prompt for a scene from its image prompt/VO.
    Uses the camera-locked (static) instruction by default; the free-camera one only if the lock is off."""
    base = (scene.get("prompt") or "").strip() or (scene.get("vo") or "").strip()
    sys = VIDEO_PROMPT_SYSTEM_STATIC if scene.get("video_cam_lock", True) else VIDEO_PROMPT_SYSTEM
    return _claude_text(sys, f"Still image: {base}")

@app.route("/api/scenes/<project>/gen-video-prompt", methods=["POST"])
def api_gen_video_prompt(project):
    """Write an AI motion prompt into each eligible scene's video_desc (the Videos-tab textbox)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ids = request.get_json(force=True).get("ids", "all")
    def eligible(s):
        return s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))
    targets = [s for s in doc["scenes"] if eligible(s) and (ids == "all" or s["id"] in ids)]
    for s in targets:
        try:
            s["video_desc"] = video_prompt_for(s)
            s["video_prompt_error"] = None
        except Exception as e:
            s["video_prompt_error"] = str(e)
    save_doc(project, doc)
    return jsonify(doc)

# ---- routes: image generation ----------------------------------------------
# ---- generation QUEUE: cap how many jobs are submitted/in-flight at once so a big "Generate All"
# doesn't fire 40+ API calls simultaneously (which the provider rate-limits → failures). Extra
# scenes wait as status "queued" and are submitted by the poll loop as running jobs finish.
IMG_CONCURRENCY = 6
VID_CONCURRENCY = 3

def _scene_product_url(s, doc):
    """The ONE product image chosen for this scene (e.g. the 1-bottle / 3-pack / 6-pack render), or None.
    scene['product'] holds the chosen url; legacy True means the first product image. Attaches in RAW mode
    too (like a scene reference) — only the extra product WORDING is skipped in raw (see assemble)."""
    prod_urls = (doc.get("product") or {}).get("urls") or []
    if not prod_urls:
        return None
    chosen = s.get("product")
    if not chosen:
        return None
    if chosen is True:
        return prod_urls[0]
    return chosen if chosen in prod_urls else None

def assemble_image_prompt(s, doc, d):
    """SINGLE SOURCE OF TRUTH for the final image prompt text — used by both the real generation
    (_submit_image) and the dry-run preview, so what the user previews is byte-identical to what gets
    sent. No network / no Cloudinary. Returns (prompt, cont_rel, info): `cont_rel` is the continuity
    frame to attach (or None); `info` is a human-readable list of which reference images would attach."""
    all_chars = scene_characters(s, doc)
    # RAW ("My prompt") = your prompt only, NO auto cast (as the toggle promises: "no characters"). So a lingering
    # cast member is NOT face-locked in raw — only reference images YOU attached to the scene are used.
    chars_ref = [] if s.get("no_cast") else [c for c in all_chars if char_urls(c)]          # cast WITH a reference photo → i2i (same face)
    chars_desc = [] if s.get("no_cast") else [c for c in all_chars if not char_urls(c)]     # photo-less cast: description block only in normal mode
    prompt = build_image_prompt(s, doc.get("audience"), chars_ref, chars_desc)
    info = []
    if s.get("no_cast"):
        n = len(s.get("refs") or [])
        bits = ["your prompt (verbatim)"]
        if chars_ref:
            bits.append("face-locked: " + ", ".join(c.get("name", "?") for c in chars_ref))
        bits.append("Target Audience reminder (location / age / excluded looks)")
        if n:
            bits.append(f"{n} reference image(s) you attached")
        info.append("RAW mode — " + " + ".join(bits))
    else:
        if chars_ref:
            _fl = []
            for c in chars_ref:
                nm = c.get("name", "?")
                if c.get("transforms") and char_end_urls(c):
                    _fl.append(f"{nm} [transform: {_char_state(c, s)}]")
                else:
                    _fl.append(nm)
            info.append("Face-locked (reference photo): " + ", ".join(_fl))
        if chars_desc:
            info.append("Kept consistent by description: " + ", ".join(c.get("name", "?") for c in chars_desc))
        if s.get("refs"):
            info.append(f"{len(s.get('refs'))} scene reference image(s)")
    # scene-continuity: if this scene continues an earlier one (same place + people) whose image exists,
    # feed that frame as an extra reference. Skipped entirely in raw mode.
    cont_rel = None
    if not s.get("no_cast"):
        cont = _cont_source(s, doc)
        if cont is not None:
            rel = (cont.get("image") or {}).get("approved_file") or (cont.get("image") or {}).get("file")
            if rel and (d / rel).exists():
                cont_rel = rel
                prompt += ("\nOne of the reference images is a frame from the PREVIOUS moment in this SAME "
                           "scene — keep the same location, background, lighting and the same people's "
                           "appearance for visual continuity; only the action and framing change as described.")
                info.append(f"Continuity frame from scene {cont.get('id')}")
    # PRODUCT: this scene is flagged to show the product → attach the product image (i2i) and demand an
    # exact, label-accurate depiction (this is what makes clean mockup / product-in-use shots).
    prod_url = _scene_product_url(s, doc)
    if prod_url:
        if not s.get("no_cast"):   # normal mode → add the label-accuracy wording; RAW stays verbatim (image still attaches as a reference)
            plabel = ((doc.get("product") or {}).get("names") or {}).get(prod_url, "").strip()
            pack = f" (this is the '{plabel}' pack)" if plabel else ""
            prompt += ("\nOne of the reference images is the PRODUCT" + pack + ". Depict it EXACTLY as in that reference: the "
                       "SAME bottle/package shape, label, wording, colours, and the SAME number of bottles/units — do "
                       "NOT redesign, rename or restyle it, and do NOT add or remove bottles. Place it naturally in the "
                       "scene (held in a hand, on a surface, or in use). The 'No text' rule above applies ONLY to added "
                       "captions/watermarks — the product's OWN printed label and text MUST stay exactly as in the reference.")
        info.append("Product reference" + (" (raw: image only)" if s.get("no_cast") else ""))
    if s.get("split"):
        n = "three" if re.search(_panel_mark_re("middle"), (s.get("prompt") or "").lower()) else "two"
        info.append(f"Split composition — {n} side-by-side panels (no divider); camera framing disabled")
    return prompt, cont_rel, info

def _submit_image(s, doc, d, safe):
    if not s.get("prompt"):
        s["image"].update(status="error", error="no prompt")
        return
    family = s.get("model") or IMAGE_MODEL
    if family not in IMAGE_MODELS_READY:
        family = IMAGE_MODEL
    s["image"]["pending_model"] = family   # remember which model THIS generation uses → recorded per version on completion
    chars_ref = [] if s.get("no_cast") else [c for c in scene_characters(s, doc) if char_urls(c)]   # RAW = no auto cast; only user-attached scene refs
    prompt, cont_rel, _info = assemble_image_prompt(s, doc, d)   # same text the preview shows
    try:
        # scene refs AND every character image are stored locally now; upload each to Cloudinary here
        refs = resolve_refs(d, safe, s.get("refs")) + resolve_refs(d, safe, [u for c in chars_ref for u in char_urls_for(c, s)])
    except ValueError as e:
        s["image"].update(status="error", error=str(e))
        return
    prod_url = _scene_product_url(s, doc)   # attach the ONE chosen PRODUCT image (1-bottle / 3-pack / 6-pack) as an i2i input
    if prod_url:
        try:
            refs = refs + resolve_refs(d, safe, [prod_url])
        except ValueError:
            pass
    if cont_rel:                                                 # continuity frame is optional — never fail the gen for it
        try:
            refs = refs + resolve_refs(d, safe, [cont_rel])
        except ValueError:
            pass
    try:
        model_id, inp = build_kie_image_request(family, prompt, refs)
        tid, err = kie_create(model_id, inp)
        if tid:
            s["image"].update(status="generating", taskId=tid, error=None)
        else:
            s["image"].update(status="error", error=err)
    except Exception as e:                                  # any unexpected failure → visible error, never a silent 500
        s["image"].update(status="error", error=f"image submit failed: {e}")

def _drain_image_queue(doc, d, safe):
    """Submit queued image jobs up to IMG_CONCURRENCY. Returns True if anything was submitted."""
    gen = sum(1 for s in doc["scenes"] if s["image"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= IMG_CONCURRENCY:
            break
        if s["image"]["status"] != "queued":
            continue
        _submit_image(s, doc, d, safe)
        changed = True
        if s["image"]["status"] == "generating":
            gen += 1
    return changed

def _submit_video(s, d, safe, doc):
    # Never let an exception escape: any failure becomes a VISIBLE "error" on the video card with the
    # reason. Otherwise a raise here (missing frame file after import, Cloudinary/Kie network error…)
    # would 500 the request and the UI would show nothing at all ("clicked, nothing happened").
    try:
        frame = s["image"].get("approved_file") or s["image"].get("file")
        if not frame:
            s["video"].update(status="error", error="approve an image version first")
            return
        if not (d / frame).exists():                       # e.g. an imported project whose image file didn't come across
            s["video"].update(status="error", error="image file missing on disk — re-generate this image, then retry")
            return
        img_url = cloudinary_upload(d / frame, f"{safe}/frames/{s.setdefault('uid', new_uid())}")
        if not img_url:
            s["video"].update(status="error", error="frame upload failed (check Cloudinary keys / quota)")
            return
        prompt = s.get("video_prompt") or s.get("video_desc") or ""
        prompt = _apply_cam_lock(prompt, s)   # keep the camera static by default (lock on) unless off / user asked for movement
        api, mid, payload = build_video_request(s.get("video_model") or DEFAULT_VIDEO_MODEL, img_url,
                                                prompt, s.get("video_dur"), s.get("video_res"))
        tid, err = (kie_veo_create(payload) if api == "veo" else kie_create(mid, payload))
        if tid:
            # remember WHICH approved image this video is being made from, so the Videos tab can flag a
            # video as stale once the scene's approved image is changed/re-approved to a different one.
            s["video"].update(status="generating", taskId=tid, error=None, api=api, source=frame)
        else:
            s["video"].update(status="error", error=err)
    except Exception as e:
        s["video"].update(status="error", error=f"video submit failed: {e}")

def _drain_video_queue(doc, d, safe):
    gen = sum(1 for s in doc["scenes"] if s["video"]["status"] == "generating")
    changed = False
    for s in doc["scenes"]:
        if gen >= VID_CONCURRENCY:
            break
        if s["video"]["status"] != "queued":
            continue
        _submit_video(s, d, safe, doc)
        changed = True
        if s["video"]["status"] == "generating":
            gen += 1
    return changed

@app.route("/api/scenes/<project>/generate", methods=["POST"])
def api_generate(project):
    with _project_lock(project):
        return _api_generate(project)


def _api_generate(project):
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", "all")
    targets = doc["scenes"] if ids == "all" else [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        if not s.get("prompt"):
            s["image"].update(status="error", error="no prompt")
        else:
            s["image"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_image_queue(doc, d, safe)                                       # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/poll", methods=["POST"])
def api_poll(project):
    return _api_poll(project)


def _api_poll(project):
    # Phase 1 — Kie polling + downloads run WITHOUT the project lock, so a concurrent approve/save
    # never waits on Kie network I/O (this was the "freeze while generating" cause). We only collect
    # results here; nothing shared is mutated. Phase 2 then reloads a fresh doc under the lock and
    # applies the results atomically (so a stale poll can never revert a just-made change).
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    updates = {}   # sid -> {"image": {...}, "video": {...}}, each tagged with its taskId

    def _img_result(img, uid):
        rec = kie_record(img["taskId"])
        state = (rec.get("data") or {}).get("state")
        if state == "success":
            url = result_url(rec)
            if not url:
                return {"ok": False, "error": "no result url"}
            ver = len(img.get("versions", [])) + 1
            fname = f"sc_{uid}_v{ver}.png"
            try:
                download_as_png(url, d / "images" / fname)
                return {"ok": True, "path": f"images/{fname}"}
            except Exception as e:
                return {"ok": False, "error": f"download: {e}"}
        elif state == "fail":
            return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
        return None   # still running

    def _vid_result(v, uid):
        fname = f"sc_{uid}.mp4"
        if v.get("api") == "veo":
            rec = kie_veo_record(v["taskId"])
            data = rec.get("data") or {}
            sf = data.get("successFlag")
            if sf == 1:
                resp = data.get("response") or {}
                urls = resp.get("fullResultUrls") or resp.get("resultUrls") or resp.get("originUrls") or []
                url = urls[0] if urls else None
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif sf in (2, 3):
                return {"ok": False, "error": data.get("errorMessage") or "generation failed"}
            return None
        else:
            rec = kie_record(v["taskId"])
            state = (rec.get("data") or {}).get("state")
            if state == "success":
                url = result_url(rec)
                if not url:
                    return {"ok": False, "error": "no result url"}
                try:
                    download_as_mp4(url, d / "videos" / fname)
                    return {"ok": True, "path": f"videos/{fname}"}
                except Exception as e:
                    return {"ok": False, "error": f"download: {e}"}
            elif state == "fail":
                return {"ok": False, "error": (rec.get("data") or {}).get("failMsg", "generation failed")}
            return None

    for s in doc["scenes"]:
        uid = s.setdefault("uid", new_uid())
        img = s["image"]
        if img["status"] == "generating" and img.get("taskId"):
            r = _img_result(img, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["image"] = {"taskId": img["taskId"], **r}
        v = s["video"]
        if v["status"] == "generating" and v.get("taskId"):
            r = _vid_result(v, uid)
            if r is not None:
                updates.setdefault(s["id"], {})["video"] = {"taskId": v["taskId"], **r}

    # Phase 2 — apply atomically under the lock (reload fresh so we merge onto the current truth).
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        changed = False
        for s in doc["scenes"]:
            u = updates.get(s["id"])
            if not u:
                continue
            iu = u.get("image")
            # only apply if the scene is STILL awaiting the SAME task (user didn't cancel/reset meanwhile)
            if iu and s["image"].get("status") == "generating" and s["image"].get("taskId") == iu["taskId"]:
                if iu["ok"]:
                    s["image"].setdefault("versions", []).append(iu["path"])
                    vm = s["image"].setdefault("version_models", [])   # keep aligned with versions
                    while len(vm) < len(s["image"]["versions"]) - 1:    # backfill any legacy versions with no recorded model
                        vm.append(s.get("model") or IMAGE_MODEL)
                    vm.append(s["image"].get("pending_model") or s.get("model") or IMAGE_MODEL)   # the model that made THIS version
                    s["image"]["current"] = len(s["image"]["versions"]) - 1
                    s["image"].update(status="ready", file=iu["path"], error=None)
                else:
                    s["image"].update(status="error", error=iu["error"])
                changed = True
            vu = u.get("video")
            if vu and s["video"].get("status") == "generating" and s["video"].get("taskId") == vu["taskId"]:
                if vu["ok"]:
                    s["video"].update(status="ready", file=vu["path"], error=None)
                else:
                    s["video"].update(status="error", error=vu["error"])
                changed = True
        # a running job finished → submit the next queued image/video jobs (keeps in-flight ≤ the limit)
        if _drain_image_queue(doc, d, safe):
            changed = True
        if _drain_video_queue(doc, d, safe):
            changed = True
        if changed:
            save_doc(project, doc)
        return jsonify(doc)

# ---- routes: video generation ----------------------------------------------
@app.route("/api/scenes/<project>/generate-video", methods=["POST"])
def api_generate_video(project):
    with _project_lock(project):
        return _api_generate_video(project)


def _api_generate_video(project):
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if not VIDEO_CONFIGURED:
        return jsonify({"error": "Seedance video model not configured yet (need exact model id/params)."}), 503
    d, safe = proj_dir(project)
    body = request.get_json(force=True)
    ids = body.get("ids", [])
    if ids == "all":
        targets = [s for s in doc["scenes"] if s.get("approved") and (s["image"].get("approved_file") or s["image"].get("file"))]
    else:
        targets = [s for s in doc["scenes"] if s["id"] in ids]
    for s in targets:
        s["video"].update(status="queued", error=None, taskId=None)   # enter the queue
    _drain_video_queue(doc, d, safe)                                   # submit up to the limit now
    save_doc(project, doc)
    return jsonify(doc)

# ---- local thumbnails for reference images ---------------------------------
# Every reference image exists twice: on disk under projects/<name>/refs/ (the original
# upload) and on Cloudinary (the public URL Kie fetches at generation time). Drawing the
# panel straight from Cloudinary re-downloaded every full-size ref on each render, which
# is what exhausted the account's bandwidth quota. The UI now asks for the local copy and
# only falls back to the remote URL when the file is missing.
def _norm_stem(s):
    """Loose filename key: scene refs are 's1-0-name' on Cloudinary but 's1_0_name' on disk."""
    return re.sub(r"[-_\s]+", " ", s).strip().lower()

def _local_ref_for_url(d, url):
    """Find the on-disk file a reference points to, or None."""
    refs = d / "refs"
    if not url or not refs.is_dir():
        return None
    # new-style refs are a local relative path stored directly (e.g. "refs/s1_0_name.png")
    if not url.startswith("http://") and not url.startswith("https://"):
        p = d / _urlunquote(url)
        if p.is_file():
            return p
        p = refs / Path(_urlunquote(url)).name
        return p if p.is_file() else None
    # old-style refs are a Cloudinary URL → match the local file by filename stem
    path = _urlunquote(_urlparse(url).path)
    stem = Path(path).stem
    # characters upload as <safe>/characters/<cid>, but are stored as char_<cid>_<original>
    if "/characters/" in path:
        hit = next((p for p in sorted(refs.glob(f"char_{stem}_*")) if p.is_file()), None)
        if hit:
            return hit
    want = _norm_stem(stem)
    for p in sorted(refs.iterdir()):
        if p.is_file() and _norm_stem(p.stem) == want:
            return p
    return None

@app.route("/api/ref-thumb/<project>")
def api_ref_thumb(project):
    """Serve a small cached thumbnail of a reference image straight from local disk."""
    d, safe = proj_dir(project)
    src = _local_ref_for_url(d, request.args.get("u", ""))
    if src is None:
        abort(404)                      # the UI falls back to the remote URL
    tdir = d / ".thumbs"
    tdir.mkdir(parents=True, exist_ok=True)
    thumb = tdir / (hashlib.md5(src.name.encode("utf-8")).hexdigest() + ".jpg")
    if not thumb.exists() or thumb.stat().st_mtime < src.stat().st_mtime:
        try:
            im = Image.open(src)
            im = im.convert("RGB")
            im.thumbnail((360, 360))
            im.save(thumb, "JPEG", quality=82)
        except Exception:
            return send_file(src)       # not readable by PIL -> hand over the original
    return send_file(thumb, mimetype="image/jpeg")

# ---- routes: refs -----------------------------------------------------------
@app.route("/api/refs/<project>", methods=["POST"])
def api_upload_ref(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    local = d / "refs" / f.filename
    f.save(local)
    pid = f"{safe}/refs/{Path(f.filename).stem}"
    url = cloudinary_upload(local, pid)
    if not url:
        return jsonify({"error": "cloudinary upload failed"}), 500
    ref = {"name": f.filename, "url": url}
    doc.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify(ref)

# ---- routes: per-scene reference images ------------------------------------
@app.route("/api/scenes/<project>/<int:sid>/ref", methods=["POST"])
def api_scene_ref(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    f = request.files["file"]
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    idx = len(scene.get("refs", []))
    fname = f"s{sid}_{idx}_{int(time.time())}_{f.filename}"
    f.save(d / "refs" / fname)
    # store the LOCAL path only — the Cloudinary upload is deferred to generation time (see
    # ref_public_url), so adding references never needs the network or the Cloudinary quota
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"]})

@app.route("/api/scenes/<project>/<int:sid>/ref-scene", methods=["POST"])
def api_scene_ref_scene(project, sid):
    """Add another scene's APPROVED image as a reference on scene <sid> — a snapshot copy into refs/.
    The filename carries the source scene number (sceneref-<N>-…) so the UI can badge it 'Scene N'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    scene = next((s for s in doc["scenes"] if s["id"] == sid), None)
    if scene is None:
        abort(404)
    if len(scene.get("refs", [])) >= 14:
        return jsonify({"error": "max 14 reference images per scene"}), 400
    from_id = (request.get_json(force=True) or {}).get("from")
    src_scene = next((s for s in doc["scenes"] if s["id"] == from_id), None)
    if src_scene is None:
        return jsonify({"error": "scene not found"}), 404
    im = src_scene.get("image", {}) or {}
    rel = im.get("approved_file") or im.get("file")     # prefer the approved image
    if not rel:
        return jsonify({"error": "that scene has no image yet"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not src.exists():
        return jsonify({"error": "source image missing"}), 400
    (d / "refs").mkdir(parents=True, exist_ok=True)
    fname = f"sceneref-{from_id}-{int(time.time())}{src.suffix or '.png'}"
    shutil.copy2(src, d / "refs" / fname)
    ref = f"refs/{fname}"
    scene.setdefault("refs", []).append(ref)
    save_doc(project, doc)
    return jsonify({"url": ref, "refs": scene["refs"], "doc": doc})

# ---- routes: PRODUCT reference image (per-project) --------------------------
@app.route("/api/product/<project>", methods=["POST"])
def api_add_product(project):
    """Add product reference image(s) for THIS project (saved locally; Cloudinary upload deferred to
    generation). These get attached (i2i) to any scene flagged show-product, keeping the real label/design."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a product image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    prod = doc.setdefault("product", {"urls": []})
    prod.setdefault("urls", [])
    prod.setdefault("names", {})
    for i, f in enumerate(files):
        fname = f"product_{int(time.time() * 1000)}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        rel = f"refs/{fname}"
        prod["urls"].append(rel)
        prod["names"][rel] = _product_default_name(f.filename)   # seed a label from the file name ("3 bottle.png" -> "3 bottle")
    save_doc(project, doc)
    return jsonify(prod)

def _product_default_name(filename):
    """A friendly default label from the uploaded file name — the user usually names the file by pack
    size ('3 bottle.png'), so that becomes the dropdown label right away, still editable in the panel."""
    stem = os.path.splitext(os.path.basename(filename or ""))[0]
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    return stem[:40] or "Product"

@app.route("/api/product/<project>/rename", methods=["POST"])
def api_rename_product(project):
    """Set the human label for one product image (e.g. '1 bottle', '3 bottle') — shown in the per-scene
    Product dropdown so the user picks the right pack by name instead of 'Product 1 / 2 / 3'."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True) or {}
    url = (body.get("url") or "").strip()
    name = (body.get("name") or "").strip()[:40]
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod.setdefault("names", {})[url] = name or "Product"
    save_doc(project, doc)
    return jsonify(prod)

@app.route("/api/product/<project>/remove", methods=["POST"])
def api_remove_product(project):
    """Drop one product reference image."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    url = ((request.get_json(force=True) or {}).get("url") or "").strip()
    prod = doc.setdefault("product", {"urls": []})
    if url in (prod.get("urls") or []):
        prod["urls"].remove(url)
    (prod.get("names") or {}).pop(url, None)
    save_doc(project, doc)
    return jsonify(prod)

# ---- routes: named characters (per-project cast) ---------------------------
@app.route("/api/characters/<project>", methods=["POST"])
def api_add_character(project):
    """Add a named character: form fields `name` + `file` (reference image). The image is saved
    LOCALLY; the upload to Cloudinary (needed as an i2i reference for Kie) is deferred to image
    generation — so adding a character never needs the network or the Cloudinary quota."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "character name is required"}), 400
    files = [f for f in request.files.getlist("file") if f and f.filename]
    if not files:
        return jsonify({"error": "a reference image is required"}), 400
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    cid = hashlib.md5(f"{name}{time.time()}".encode()).hexdigest()[:8]
    urls = []
    for i, f in enumerate(files):
        fname = f"char_{cid}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        urls.append(f"refs/{fname}")
    ch = {"id": cid, "name": name, "urls": urls}   # local paths; Cloudinary upload happens at generation
    doc.setdefault("characters", []).append(ch)
    save_doc(project, doc)
    return jsonify(ch)


def _norm_char(ch):
    """Migrate a legacy single-`url` character to the multi-image `urls` shape in place."""
    if "urls" not in ch:
        ch["urls"] = [ch["url"]] if ch.get("url") else []
    ch.pop("url", None)
    return ch


def _role_outfit(name, role):
    """Map a character's role/name to a specific, unambiguous outfit so the profession reads at a glance —
    a 'Dr' or a doctor gets a WHITE COAT, not a suit. Returns a phrase or None."""
    r = (role or "").lower()
    n = (name or "").lower()
    is_dr = n.startswith("dr ") or n.startswith("dr.") or (" dr " in f" {n} ")
    if is_dr or any(k in r for k in ("doctor", "physician", "surgeon", "medical", "clinician", "gp")):
        return "a white medical doctor's coat worn over their clothes (a stethoscope is fine) — clearly a doctor"
    if "nurse" in r:
        return "medical nurse scrubs"
    if any(k in r for k in ("research", "scientist", "biolog", "botan", "chemist", "lab", "professor")):
        return "a white lab coat — clearly a scientist/researcher"
    if any(k in r for k in ("chef", "cook")):
        return "a chef's white uniform"
    if any(k in r for k in ("farmer", "grower")):
        return "practical rustic outdoor work clothes"
    return None

def _char_portrait_prompt(ch, aud):
    """Text-to-image prompt for a clean, reusable casting portrait of ONE character, built from the
    character's fixed description (falling back to name/role) + a role-appropriate outfit + a location hint."""
    desc = (ch.get("desc") or "").strip()
    role = (ch.get("role") or "").strip()
    name = (ch.get("name") or "a person").strip()
    who = desc or (name + (f", {role}" if role else ""))
    parts = [f"A clean casting reference portrait of ONE single person: {who}."]
    outfit = _role_outfit(name, role)
    if outfit:
        # forceful, specific — don't bury it in a menu of examples, or the model defaults to a generic suit
        parts.append(f"IMPORTANT: they MUST be clearly shown wearing {outfit}, so their profession is obvious at a glance.")
    elif role:
        parts.append(f"Dress them in clothing appropriate for their role ({role}).")
    loc = None
    try:
        locs = (aud or {}).get("locations")
        if isinstance(locs, list) and locs:
            loc = str(locs[0])
        elif isinstance(locs, str) and locs.strip():
            loc = locs.strip()
    except Exception:
        loc = None
    if loc:
        parts.append(f"If the appearance above doesn't already fix it, make them look like an ordinary person from {loc}.")
    parts.append("Waist-up, facing the camera, calm friendly neutral expression, plain uncluttered light-grey "
                 "background, only this one person in the frame and nothing else, no other people, no props, no "
                 "logos. This is a face/appearance reference to reuse across scenes — keep it simple and clear.")
    parts.append(STYLE_PRESETS.get("natural", ""))
    return "\n".join(p for p in parts if p and p.strip())


def _run_char_candidate(d, cid, model_id, inp):
    """Create a Kie task, poll to completion, download the result as a candidate PNG.
    Returns (rel_url, None) on success or (None, error_message)."""
    tid, cerr = kie_create(model_id, inp)
    if not tid:
        return None, (cerr or "could not start generation")
    url = fail = None
    for _ in range(60):                                # poll up to ~2 minutes
        time.sleep(2)
        rec = kie_record(tid)
        state = (rec.get("data") or {}).get("state")
        if state == "success":
            url = result_url(rec); break
        if state == "fail":
            fail = (rec.get("data") or {}).get("failMsg", "generation failed"); break
    if fail:
        return None, fail
    if not url:
        return None, "generation timed out — please try again"
    fname = f"charcand_{cid}_{int(time.time() * 1000)}.png"   # ms so rapid regen/edit never collide
    try:
        download_as_png(url, d / "refs" / fname)
    except Exception as e:
        return None, f"download failed: {e}"
    return f"refs/{fname}", None


@app.route("/api/characters/<project>/<cid>/generate", methods=["POST"])
def api_generate_character(project, cid):
    """Generate a portrait CANDIDATE (never auto-committed). `fresh` (first open) clears old candidates;
    a regenerate keeps them so the user can flip between versions. Same model/resolution as scene images."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    if (request.get_json(silent=True) or {}).get("fresh"):
        for p in d.glob(f"refs/charcand_{cid}_*"):
            try: p.unlink()
            except Exception: pass
    prompt = _char_portrait_prompt(ch, doc.get("audience"))
    model_id, inp = build_kie_image_request(IMAGE_MODEL, prompt, [])   # text-to-image, no reference
    rel, cerr = _run_char_candidate(d, cid, model_id, inp)
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel})


@app.route("/api/characters/<project>/<cid>/edit-candidate", methods=["POST"])
def api_edit_char_candidate(project, cid):
    """Edit a candidate with a typed instruction (image-to-image, NanoBanana) → a NEW candidate version."""
    err = _keys_ok(("kie", "cloud"))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    body = request.get_json(force=True) or {}
    rel = (body.get("url") or "").strip()
    instr = (body.get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"charcand_{cid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    base_url = cloudinary_upload(src, f"{safe}/charedit/{cid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    instr_en = instr
    if looks_turkish(instr):
        try: instr_en = translate_to_english(instr)
        except Exception: instr_en = instr
    model_id, inp = build_kie_image_request("nano-banana-2", instr_en, [base_url])
    rel2, cerr = _run_char_candidate(d, cid, model_id, inp)
    if cerr:
        return jsonify({"error": cerr}), 502
    return jsonify({"ok": True, "url": rel2})


@app.route("/api/characters/<project>/<cid>/use-candidate", methods=["POST"])
def api_use_char_candidate(project, cid):
    """Accept a candidate → rename it into a normal character image, add to roster, drop the other candidates."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    rel = ((request.get_json(force=True) or {}).get("url") or "").strip()
    d, safe = proj_dir(project)
    src = d / rel
    if not (rel.startswith("refs/") and f"charcand_{cid}_" in rel and src.exists()):
        return jsonify({"error": "candidate not found"}), 400
    newname = f"char_{cid}_{int(time.time() * 1000)}_gen.png"
    try:
        src.rename(d / "refs" / newname)
    except Exception:
        shutil.copyfile(src, d / "refs" / newname)
        try: src.unlink()
        except Exception: pass
    for p in d.glob(f"refs/charcand_{cid}_*"):          # committed one → drop the rest
        try: p.unlink()
        except Exception: pass
    _norm_char(ch)
    ch["urls"].append(f"refs/{newname}")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>/discard-candidate", methods=["POST"])
def api_discard_char_candidate(project, cid):
    """Throw away un-accepted candidate(s). `all` clears every candidate for this character (on Cancel)."""
    body = request.get_json(silent=True) or {}
    d, safe = proj_dir(project)
    if body.get("all"):
        for p in d.glob(f"refs/charcand_{cid}_*"):
            try: p.unlink()
            except Exception: pass
    else:
        rel = (body.get("url") or "").strip()
        if rel.startswith("refs/") and f"charcand_{cid}_" in rel:
            try: (d / rel).unlink()
            except Exception: pass
    return jsonify({"ok": True})


@app.route("/api/characters/<project>/<cid>", methods=["POST"])
def api_update_character(project, cid):
    """Edit a character: optional rename (form `name`) and/or append reference image(s) (form `file`)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    name = (request.form.get("name") or "").strip()
    if name:
        ch["name"] = name
    # transforming character (e.g. slims down across the video): a flag + an optional note + a SECOND photo
    # bucket (`urls_end` = the END look). `bucket=end` routes uploads to that bucket; default is the start bucket.
    if "transforms" in request.form:
        ch["transforms"] = request.form.get("transforms") in ("1", "true", "on", "yes")
    if "transform_note" in request.form:
        ch["transform_note"] = (request.form.get("transform_note") or "").strip()
    bucket = "urls_end" if (request.form.get("bucket") == "end") else "urls"
    ch.setdefault(bucket, [])
    d, safe = proj_dir(project)
    (d / "refs").mkdir(parents=True, exist_ok=True)
    for i, f in enumerate([f for f in request.files.getlist("file") if f and f.filename]):
        fname = f"char_{cid}_{int(time.time())}_{i}_{f.filename}"
        f.save(d / "refs" / fname)
        ch[bucket].append(f"refs/{fname}")
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>/remove-image", methods=["POST"])
def api_remove_character_image(project, cid):
    """Drop one reference image from a character (keeps at least one)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    ch = next((c for c in doc.get("characters", []) if c.get("id") == cid), None)
    if ch is None:
        return jsonify({"error": "character not found"}), 404
    _norm_char(ch)
    body = request.get_json(force=True) or {}
    url = body.get("url")
    bucket = "urls_end" if (body.get("bucket") == "end") else "urls"
    lst = ch.setdefault(bucket, [])
    # start bucket must keep at least one photo; the END bucket is optional so it may go empty
    if url in lst and (bucket == "urls_end" or len(lst) > 1):
        lst.remove(url)
        d, safe = proj_dir(project)
        try:
            (d / url).unlink()
        except Exception:
            pass
    save_doc(project, doc)
    return jsonify(ch)


@app.route("/api/characters/<project>/<cid>", methods=["DELETE"])
def api_del_character(project, cid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["characters"] = [c for c in doc.get("characters", []) if c.get("id") != cid]
    for s in doc.get("scenes", []):        # remove it from every scene's cast
        if cid in (s.get("cast") or []):
            s["cast"] = [x for x in s["cast"] if x != cid]
    save_doc(project, doc)
    return jsonify({"ok": True, "characters": doc["characters"]})

# ---- routes: image edit / versions / downloads -----------------------------
def _find_scene(doc, sid):
    return next((s for s in doc["scenes"] if s["id"] == sid), None)

@app.route("/api/scenes/<project>/<int:sid>/preview-prompt", methods=["GET"])
def api_preview_prompt(project, sid):
    """Dry-run: return the EXACT final image prompt this scene would send (+ a summary of the reference
    images that would attach), WITHOUT generating. Lets the user catch conflicts before spending a job."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    d, _safe = proj_dir(project)
    if not (s.get("prompt") or "").strip():
        return jsonify({"prompt": "", "info": ["This scene has no prompt yet — Generate or type one first."]})
    prompt, _cont_rel, info = assemble_image_prompt(s, doc, d)
    return jsonify({"prompt": prompt, "info": info, "raw": bool(s.get("no_cast"))})

@app.route("/api/scenes/<project>/<int:sid>/edit", methods=["POST"])
def api_edit_image(project, sid):
    """Edit the CURRENT version using it as the reference (image-to-image), keep history."""
    err = _keys_ok(("kie",))
    if err:
        return err
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    instr = (request.get_json(force=True).get("instructions") or "").strip()
    if not instr:
        return jsonify({"error": "no edit instructions"}), 400
    img = s["image"]
    vs, cur = img.get("versions", []), img.get("current", -1)
    if not vs or not (0 <= cur < len(vs)):
        return jsonify({"error": "generate an image first"}), 400
    d, safe = proj_dir(project)
    # Stable public_id per scene (no timestamp) so re-editing OVERWRITES the same Cloudinary asset
    # instead of piling up a new permanent one every edit. Signed uploads overwrite by default, and
    # Cloudinary returns a version-busted secure_url so Kie always fetches the fresh base — one
    # edit-base asset per scene, ever. (frames/ and refs/ were already stable-id, so only edits leaked.)
    base_url = cloudinary_upload(d / vs[cur], f"{safe}/edits/s{sid}")
    if not base_url:
        return jsonify({"error": "could not upload base image"}), 500
    # Build an EDIT command, not a scene description. Do NOT prepend the big style preset here:
    # the base image already carries the style, and dumping ~150 words of "keep this exact look"
    # in front of a one-line instruction buries the edit — the model just reproduces the same
    # image. Make the change DOMINANT and forceful; over-preserving "the same subject" is what
    # blocks appearance edits (e.g. "make them thinner"), so we only protect the setting/style/faces
    # and explicitly ALLOW the subject's body/appearance to change to satisfy the instruction.
    # If the instruction is written in Turkish, translate ONLY the user's words to English first,
    # so the forceful English directives below reach the model verbatim. (Running the whole prompt
    # through the translator, as localize_prompt would, could soften the "apply it strongly" wording.)
    instr_en = instr
    if looks_turkish(instr):
        try:
            instr_en = translate_to_english(instr)
        except Exception:
            instr_en = instr
    # RAW edit: send ONLY the user's instruction to the image-to-image edit — nothing added, exactly what
    # they typed (translated to English if written in Turkish, since the model reads English best). The
    # current image is the base, so the model edits it directly.
    p = instr_en
    # Edit ALWAYS uses NanoBanana image-to-image. Feed ONLY the current image as the base — adding the
    # scene's cast reference photos here over-anchors each person's identity so hard that appearance
    # edits (body shape, etc.) can't take, making the result look identical. Prompt is already English.
    image_input = [base_url]
    model_id, inp = build_kie_image_request("nano-banana-2", p, image_input)
    tid, err = kie_create(model_id, inp)
    if tid:
        img.update(status="generating", taskId=tid, error=None)
    else:
        img.update(status="error", error=err)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/current", methods=["POST"])
@_locked
def api_set_current(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    idx = request.get_json(force=True).get("index")
    vs = s["image"].get("versions", [])
    if isinstance(idx, int) and 0 <= idx < len(vs):
        s["image"]["current"] = idx
        save_doc(project, doc)
    return jsonify(s["image"])

@app.route("/api/scenes/<project>/sync-approved-current", methods=["POST"])
@_locked
def api_sync_approved_current(project):
    """On (re)opening a project, snap every APPROVED scene's shown version back to its APPROVED version —
    so flipping through versions and then leaving doesn't leave a non-approved frame showing next time.
    Persisted so a later poll can't snap it forward again."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    changed = False
    for s in doc.get("scenes", []):
        im = s.get("image") or {}
        av = im.get("approved_version")
        vers = im.get("versions") or []
        if s.get("approved") and isinstance(av, int) and 0 <= av < len(vers) and im.get("current") != av:
            im["current"] = av
            im["file"] = vers[av]
            changed = True
    if changed:
        save_doc(project, doc)
        doc = load_doc(project)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-image", methods=["POST"])
@_locked
def api_reset_image(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["image"] = {"status": "empty", "taskId": None, "error": None, "versions": [], "current": -1, "file": None}
    s["approved"] = False
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-image", methods=["POST"])
def api_cancel_image(project, sid):
    """Stop an in-progress (queued OR generating) image generation for ONE scene.
    Keeps any existing versions — we just abandon the new task so poll/queue ignore it.
    A Kie task already submitted keeps running on their side; we simply stop tracking it."""
    with _project_lock(project):     # same atomic load→modify→save as generate/poll so we don't race the 6s poll
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        img = s["image"]
        if img.get("status") in ("queued", "generating"):
            vs = img.get("versions", [])
            if vs:                                            # regen over an existing image → keep the old one
                cur = img.get("current", len(vs) - 1)
                cur = cur if 0 <= cur < len(vs) else len(vs) - 1
                img.update(status="ready", taskId=None, error=None, file=vs[cur])
            else:                                             # first-time generation → back to empty
                img.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/cancel-video", methods=["POST"])
def api_cancel_video(project, sid):
    """Stop an in-progress (queued OR generating) VIDEO generation for ONE scene. Keeps any existing
    video; we just abandon the new task so poll/queue ignore it (the Kie task, if already sent, keeps
    running on their side — we simply stop tracking it)."""
    with _project_lock(project):
        doc = load_doc(project)
        if doc is None:
            abort(404)
        s = _find_scene(doc, sid)
        if s is None:
            abort(404)
        v = s.get("video") or {}
        if v.get("status") in ("queued", "generating"):
            if v.get("file"):                         # regen over an existing video → keep the old one
                v.update(status="ready", taskId=None, error=None)
            else:
                v.update(status="empty", taskId=None, error=None, file=None)
        save_doc(project, doc)
        return jsonify(doc)


@app.route("/api/scenes/<project>/<int:sid>/delete-version", methods=["POST"])
@_locked
def api_delete_version(project, sid):
    """Delete ONLY the shown image version (not all). The file is left on disk so Undo can restore it."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    img = s["image"]
    vs = img.get("versions", [])
    idx = request.get_json(force=True).get("index", img.get("current", -1))
    if not (0 <= idx < len(vs)):
        return jsonify(doc)
    vs.pop(idx)
    vm = img.get("version_models")               # keep the per-version model list aligned
    if isinstance(vm, list) and 0 <= idx < len(vm):
        vm.pop(idx)
    av = img.get("approved_version")
    if isinstance(av, int):
        if av == idx:
            img["approved_version"] = None
            s["approved"] = False
        elif av > idx:
            img["approved_version"] = av - 1
    if not vs:
        s["image"] = {"status": "empty", "taskId": None, "error": None,
                      "versions": [], "current": -1, "file": None, "approved_version": None}
        s["approved"] = False
    else:
        img["versions"] = vs
        img["current"] = min(img.get("current", 0), len(vs) - 1)
    norm_scene(s)
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/approve", methods=["POST"])
@_locked
def api_approve(project, sid):
    """Approve/unapprove the scene. On approve, LOCK the currently-shown version."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    body = request.get_json(force=True)
    approved = bool(body.get("approved"))
    s["approved"] = approved
    if approved:
        # optional explicit version to approve (from the lightbox) — set it as current too,
        # so approving is atomic and race-free regardless of pending setCurrent calls.
        ver = body.get("version")
        vs = s["image"].get("versions", [])
        if isinstance(ver, int) and 0 <= ver < len(vs):
            s["image"]["current"] = ver
        s["image"]["approved_version"] = s["image"].get("current", len(vs) - 1)
    norm_scene(s)   # recompute approved_file so the response is current
    if approved:
        _auto_anchor(doc, s)   # photo-less recurring character → adopt this frame as their face-lock for later scenes
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/reset-video", methods=["POST"])
@_locked
def api_reset_video(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"] = {"status": "empty", "taskId": None, "file": None, "error": None, "approved": False}
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/<int:sid>/video-approve", methods=["POST"])
@_locked
def api_video_approve(project, sid):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    s = _find_scene(doc, sid)
    if s is None:
        abort(404)
    s["video"]["approved"] = bool(request.get_json(force=True).get("approved"))
    save_doc(project, doc)
    return jsonify(doc)

@app.route("/api/scenes/<project>/zip-images")
def api_zip_images(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            if not s.get("approved"):
                continue
            f = s["image"].get("approved_file") or s["image"].get("file")
            if f and (d / f).exists():
                z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-images.zip")

@app.route("/api/scenes/<project>/zip-videos")
def api_zip_videos(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in doc["scenes"]:
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}-videos.zip")

# ---- routes: media serving --------------------------------------------------
@app.route("/api/subtitle/<project>", methods=["GET"])
def api_subtitle_status(project):
    return jsonify(get_sub_status(project))

@app.route("/api/subtitle/<project>/cancel", methods=["POST"])
def api_subtitle_cancel(project):
    """Stop a running subtitle job: flag it, then kill the live aligner subprocess tree so it halts
    at once. run_subtitle_job sees the flag between passes and finishes as 'idle' (not error)."""
    _SUB_CANCEL.add(project)
    _kill_proc_tree(_SUB_PROCS.get(project))
    set_sub_status(project, status="idle", step="", error=None, srt=None)
    return jsonify({"ok": True})

def text_to_docx(text, path):
    """Wrap plain UI script text as a minimal .docx (one paragraph per non-empty line) so the
    aligner's docx reader consumes it through the exact same code path as an uploaded .docx."""
    import xml.sax.saxutils as sx
    paras = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{sx.escape(ln.strip())}</w:t></w:r></w:p>'
        for ln in text.splitlines() if ln.strip())
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           '<w:body>' + paras + '</w:body></w:document>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)

@app.route("/api/subtitle/<project>", methods=["POST"])
def api_subtitle_run(project):
    doc = load_doc(project)
    if not doc:
        return jsonify({"error": "unknown project"}), 404
    st = get_sub_status(project)
    if st.get("status") == "running":
        return jsonify({"error": "a subtitle job is already running"}), 409
    d, safe = proj_dir(project)
    def truthy(v): return str(v).lower() in ("1", "true", "on", "yes")
    use_gen_vo = truthy(request.form.get("use_generated_vo"))
    use_script = truthy(request.form.get("use_script"))
    trim = truthy(request.form.get("trim"))
    trim_mode = request.form.get("trim_mode") or "natural"
    trimmed_rel = None
    audio = request.files.get("audio")
    docx = request.files.get("docx")
    # fresh workdir each run so stale alignment caches never leak into a new job
    wd = sub_dir(project)
    if wd.exists():
        shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True, exist_ok=True)
    docx_path = wd / "script.docx"

    # ---- audio source (accepts any common audio type; ffmpeg/whisper sniff by content) ----
    if use_gen_vo:
        gen = d / "voiceover" / "voiceover.mp3"
        if not gen.exists():
            return jsonify({"error": "no generated voice-over yet — generate it above first"}), 400
        audio_path = wd / "audio.mp3"
        shutil.copyfile(gen, audio_path)
    else:
        if not audio or not audio.filename:
            return jsonify({"error": "a voice-over audio file is required"}), 400
        ext = (Path(audio.filename).suffix or ".mp3").lower()
        audio_path = wd / ("audio" + ext)
        audio.save(str(audio_path))
        # trim silences on the uploaded audio, then align to the TRIMMED audio + offer it for download
        if trim:
            trimmed = wd / "voiceover_trimmed.mp3"
            if trim_silences(audio_path, trimmed, trim_mode):
                audio_path = trimmed
                trimmed_rel = f"subtitle/{trimmed.name}"

    # ---- script source (.docx or plain-text .txt) ----
    if use_script:
        script_text = (request.form.get("script_text") or "").strip()
        if not script_text:
            return jsonify({"error": "the script box on the left is empty"}), 400
        text_to_docx(script_text, docx_path)
    else:
        if not docx or not docx.filename:
            return jsonify({"error": "a script file (.docx or .txt) is required"}), 400
        fn = docx.filename.lower()
        if fn.endswith(".txt"):
            text_to_docx(docx.read().decode("utf-8", "ignore"), docx_path)
        elif fn.endswith(".docx"):
            docx.save(str(docx_path))
        else:
            return jsonify({"error": "script must be a .docx or .txt file"}), 400

    proj = fname_slug(doc.get("title") or project)
    date = today_ddmmyyyy()
    out_path = wd / f"{proj}_Subtitle_{date}.srt"
    trimmed_name = f"{proj}_Voiceover_Trimmed_{date}.mp3" if trimmed_rel else None
    set_sub_status(project, status="running", step="Starting…", srt=None,
                   trimmed=None, trimmed_name=trimmed_name, error=None)
    threading.Thread(target=run_subtitle_job,
                     args=(project, audio_path, docx_path, out_path, trimmed_rel), daemon=True).start()
    return jsonify({"status": "running"})

# ---- routes: voice-over (ElevenLabs) ---------------------------------------
DEFAULT_VOICES = [
    {"name": "Loretta Jophlin", "voice_id": "DiWaolzR7aFbwU2MJGyD"},
    {"name": "Daniel Sandrin", "voice_id": "EC7t0LPc9MtRU1r33xNj"},
]
def load_voices():
    if VOICES_PATH.exists():
        try:
            return json.loads(VOICES_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    VOICES_PATH.write_text(json.dumps(DEFAULT_VOICES, indent=2), encoding="utf-8")
    return list(DEFAULT_VOICES)

def save_voices(voices):
    VOICES_PATH.write_text(json.dumps(voices, indent=2, ensure_ascii=False), encoding="utf-8")

@app.route("/api/ost-presets", methods=["GET"])
def api_get_ost_presets():
    if OST_PRESETS_PATH.exists():
        try:
            return jsonify(json.loads(OST_PRESETS_PATH.read_text(encoding="utf-8")))
        except Exception:
            return jsonify([])
    return jsonify([])

@app.route("/api/ost-presets", methods=["POST"])
def api_save_ost_presets():
    data = request.get_json(force=True)
    if not isinstance(data, list):
        return jsonify({"error": "expected a list"}), 400
    OST_PRESETS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return jsonify({"ok": True})

@app.route("/api/voices", methods=["GET"])
def api_voices():
    return jsonify(load_voices())

@app.route("/api/voices", methods=["POST"])
def api_voices_add():
    body = request.get_json(force=True)
    name = (body.get("name") or "").strip()
    vid = (body.get("voice_id") or "").strip()
    if not name or not vid:
        return jsonify({"error": "name and voice_id required"}), 400
    voices = load_voices()
    for v in voices:              # update if the name already exists
        if v.get("name", "").lower() == name.lower():
            v["voice_id"] = vid
            break
    else:
        voices.append({"name": name, "voice_id": vid})
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voices/<name>", methods=["DELETE"])
def api_voices_del(name):
    voices = [v for v in load_voices() if v.get("name", "").lower() != name.lower()]
    save_voices(voices)
    return jsonify(voices)

@app.route("/api/voiceover/<project>", methods=["POST"])
def api_voiceover(project):
    d, safe = proj_dir(project)
    if not (d / "scenes.json").exists():
        abort(404)
    err = _keys_ok(("eleven",))
    if err:
        return err
    doc = load_doc(project)
    body = request.get_json(force=True)
    voice_id = (body.get("voice_id") or "").strip()
    text = (body.get("text") or "").strip()
    if not voice_id:
        return jsonify({"error": "voice ID required"}), 400
    if not text:
        return jsonify({"error": "script is empty"}), 400
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": ELEVEN_KEY, "Content-Type": "application/json", "Accept": "audio/mpeg"},
            params={"output_format": "mp3_44100_128"},
            json={"text": text, "model_id": ELEVEN_MODEL,
                  "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}},
            timeout=300)
    except Exception as e:
        return jsonify({"error": f"request failed: {e}"}), 502
    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("detail", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except Exception:
            msg = r.text[:300]
        return jsonify({"error": f"ElevenLabs {r.status_code}: {msg}"}), 502
    (d / "voiceover").mkdir(exist_ok=True)
    out = d / "voiceover" / "voiceover.mp3"
    # trim silences between sentences if requested (the saved voiceover.mp3 becomes the trimmed one,
    # so "use the voice-over generated above" in subtitles picks up the trimmed audio)
    if body.get("trim"):
        raw = d / "voiceover" / "voiceover_raw.mp3"
        raw.write_bytes(r.content)
        if not trim_silences(raw, out, body.get("trim_mode") or "natural"):
            out.write_bytes(r.content)   # fall back to untrimmed on ffmpeg failure
    else:
        out.write_bytes(r.content)
    proj = fname_slug((doc or {}).get("title") or project)
    spk = speaker_slug(voice_id)
    name = f"{proj}_{spk + '_' if spk else ''}Voiceover_{today_ddmmyyyy()}.mp3"
    return jsonify({"ok": True, "file": "voiceover/voiceover.mp3", "name": name})

# ---- routes: Premiere project export (FCP7 XML) ----------------------------
def _find_srt(d):
    """Locate the project's SRT: the one the subtitle job produced, else any *.srt."""
    sd = d / "subtitle"
    if not sd.exists():
        return None
    named = sorted(sd.glob("*_Subtitle_*.srt"))
    if named:
        return named[-1]
    any_srt = sorted(sd.glob("*.srt"))
    return any_srt[-1] if any_srt else None


def _find_vo_audio(d):
    """The audio the SRT was aligned to: prefer the trimmed take, then the subtitle-job
    audio, then the generated voice-over."""
    sd = d / "subtitle"
    cand = [sd / "voiceover_trimmed.mp3"]
    if sd.exists():
        cand += sorted(sd.glob("audio.*"))
    cand.append(d / "voiceover" / "voiceover.mp3")
    for p in cand:
        if p.exists():
            return p
    return None


def _normalized_vo(d):
    """The voice-over loudness-normalized to a consistent VSL level (cached in export/;
    rebuilt only when the source changes). Falls back to the raw VO if ffmpeg fails."""
    src = _find_vo_audio(d)
    if not src:
        return None
    dst = d / "export" / "voiceover_norm.mp3"
    try:
        fresh = dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime
    except Exception:
        fresh = False
    if fresh:
        return dst
    return premiere_export.normalize_loudness(src, dst) or src


@app.route("/api/export-premiere/<project>", methods=["POST"])
def api_export_premiere(project):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt:
        return jsonify({"error": "No subtitle (.srt) found — generate subtitles first "
                                 "(the timeline is timed from the SRT)."}), 400
    if not _find_vo_audio(d):
        return jsonify({"error": "No voice-over audio found — generate or upload the voice-over first."}), 400
    vo = _normalized_vo(d)                     # loudness-normalized VO for a consistent VSL level
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = premiere_export.build_premiere_xml(
            doc.get("title") or project, d, doc, _srt_text, vo,
            BGM_ROOT, claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
    except Exception as e:
        return jsonify({"error": f"Export failed: {e}"}), 500
    out_name = f"{fname_slug(doc.get('title') or project)}_Premiere_{today_ddmmyyyy()}.xml"
    (d / "export").mkdir(parents=True, exist_ok=True)
    (d / "export" / out_name).write_text(xml, encoding="utf-8")
    return jsonify({"ok": True, "file": f"export/{out_name}", "name": out_name, "info": info})


# ---- routes: named downloads (Export tab) ----------------------------------
def _vsl_name(doc, project, typ, ext):
    """Filename convention: <Project>_VSL_<Type>_<DDMMYYYY>.<ext>."""
    return f"{fname_slug(doc.get('title') or project)}_VSL_{typ}_{today_ddmmyyyy()}.{ext}"


def _used_bgm_paths(info):
    """Reconstruct the on-disk paths of the background-music tracks the export actually used."""
    out = []
    for m in (info or {}).get("music", []):
        if m.get("track"):
            p = BGM_ROOT / m["emotion"] / m["track"]
            if p.exists():
                out.append(p)
    return out


@app.route("/api/download/<project>/<kind>")
def api_download(project, kind):
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    if kind == "subtitle":
        srt = _find_srt(d)
        if not srt:
            return jsonify({"error": "No subtitle (.srt) yet — generate it in the Script & Voiceover tab."}), 404
        # split at scene boundaries + frame-quantize so captions and clips switch together in Premiere
        q = _delivery_srt(d, doc, srt)
        return send_file(io.BytesIO(q.encode("utf-8")), mimetype="application/x-subrip",
                         as_attachment=True, download_name=_vsl_name(doc, project, "Subtitle", "srt"))
    if kind == "voiceover":
        if not _find_vo_audio(d):
            return jsonify({"error": "No voice-over yet — generate it in the Script & Voiceover tab."}), 404
        vo = _normalized_vo(d)                  # deliver the level-normalized voice-over
        return send_file(vo, as_attachment=True, download_name=_vsl_name(doc, project, "Voiceover", "mp3"))
    if kind == "script":
        txt = (doc.get("script") or "").strip()
        if not txt:
            return jsonify({"error": "No script yet — paste it in the Script & Voiceover tab."}), 404
        (d / "export").mkdir(parents=True, exist_ok=True)
        p = d / "export" / "_script.docx"
        text_to_docx(txt, p)
        return send_file(p, as_attachment=True, download_name=_vsl_name(doc, project, "Script", "docx"))
    if kind == "premiere":
        srt = _find_srt(d)
        if not srt or not _find_vo_audio(d):
            return jsonify({"error": "Need a subtitle (.srt) and a voice-over first."}), 400
        vo = _normalized_vo(d)
        try:
            _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
            xml, _info = premiere_export.build_premiere_xml(
                doc.get("title") or project, d, doc, _srt_text, vo, BGM_ROOT,
                claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
        except Exception as e:
            return jsonify({"error": f"Assembly failed: {e}"}), 500
        out_name = _vsl_name(doc, project, "Premiere_Project", "xml")
        (d / "export").mkdir(parents=True, exist_ok=True)
        (d / "export" / out_name).write_text(xml, encoding="utf-8")
        return send_file(d / "export" / out_name, as_attachment=True, download_name=out_name)
    if kind in ("images", "videos"):
        # skip phantom scenes (manual lines not in the voice-over) when an SRT exists to detect them
        srtp = _find_srt(d)
        phantom = premiere_export.excluded_scene_ids(
            doc["scenes"], premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))) if srtp else set()
        buf = io.BytesIO()
        n = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for s in doc["scenes"]:
                if s.get("id") in phantom:
                    continue
                if kind == "images":
                    if not s.get("approved"):
                        continue
                    f = s["image"].get("approved_file") or s["image"].get("file")
                    if f and (d / f).exists():
                        z.write(d / f, f"{s['id']:02d}_{slugify(s.get('vo'))}.png"); n += 1
                else:
                    v = s.get("video", {})
                    if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                        z.write(d / v["file"], f"{s['id']:02d}_{slugify(s.get('vo'))}.mp4"); n += 1
        if not n:
            return jsonify({"error": f"No approved {kind} to download."}), 404
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name=_vsl_name(doc, project, kind.capitalize(), "zip"))
    abort(404)


@app.route("/api/download/<project>/all")
def api_download_all(project):
    """One ZIP with the whole deliverable: Premiere .xml, SRT, voice-over, script .docx, each
    scene's approved video (or its approved image where no video), and the used music tracks."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    d, safe = proj_dir(project)
    srt = _find_srt(d)
    if not srt or not _find_vo_audio(d):
        return jsonify({"error": "Need at least a subtitle (.srt) and a voice-over first."}), 400
    vo = _normalized_vo(d)                      # level-normalized VO (same file the timeline uses)
    try:
        _srt_text = srt.read_text(encoding="utf-8", errors="ignore")
        xml, info = premiere_export.build_premiere_xml(
            doc.get("title") or project, d, doc, _srt_text, vo, BGM_ROOT,
            claude_fn=_claude_text, music_segments=_export_music(project, doc, _srt_text, vo))
    except Exception as e:
        return jsonify({"error": f"Assembly failed: {e}"}), 500
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(_vsl_name(doc, project, "Premiere_Project", "xml"), xml)
        # SRT split at scene boundaries + frame-quantized so captions/clips switch together in Premiere
        z.writestr(_vsl_name(doc, project, "Subtitle", "srt"), _delivery_srt(d, doc, srt))
        z.write(vo, _vsl_name(doc, project, "Voiceover", vo.suffix.lstrip(".") or "mp3"))
        txt = (doc.get("script") or "").strip()
        if txt:
            sp = d / "export" / "_script.docx"
            (d / "export").mkdir(parents=True, exist_ok=True)
            text_to_docx(txt, sp)
            z.write(sp, _vsl_name(doc, project, "Script", "docx"))
        # per scene: approved video, else approved image (only for approved scenes). Phantom scenes
        # (manual lines not in the voice-over) are skipped so the bundle matches the timeline.
        phantom = premiere_export.excluded_scene_ids(doc["scenes"],
                                                     premiere_export.parse_srt(srt.read_text(encoding="utf-8", errors="ignore")))
        dl_video = dl_image = 0
        for s in doc["scenes"]:
            if s.get("id") in phantom:
                continue
            v = s.get("video", {})
            if v.get("approved") and v.get("status") == "ready" and v.get("file") and (d / v["file"]).exists():
                z.write(d / v["file"], f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.mp4")
                dl_video += 1
            elif s.get("approved"):
                f = s["image"].get("approved_file") or s["image"].get("file")
                if f and (d / f).exists():
                    z.write(d / f, f"clips/{s['id']:02d}_{slugify(s.get('vo'))}.png")
                    dl_image += 1
        for p in _used_bgm_paths(info):
            z.write(p, f"music/{p.name}")
    # counts of what was ACTUALLY put in the zip (video where approved, else approved image)
    info["dl_video"] = dl_video
    info["dl_image"] = dl_image
    buf.seek(0)
    resp = send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=_vsl_name(doc, project, "All_Files", "zip"))
    resp.headers["X-Export-Info"] = _urlquote(json.dumps(info))   # content summary for the UI
    resp.headers["Access-Control-Expose-Headers"] = "X-Export-Info"
    return resp


@app.route("/media/<project>/<path:relpath>")
def api_media(project, relpath):
    d, _ = proj_dir(project)
    fp = (d / relpath).resolve()
    if not str(fp).startswith(str(d.resolve())) or not fp.exists():
        abort(404)
    dl = request.args.get("dl")
    if dl:  # force a download with a specific filename
        return send_file(fp, as_attachment=True, download_name=dl)
    return send_file(fp)


@app.route("/bgm/<path:relpath>")
def api_bgm(relpath):
    """Serve a background-music track (lives outside any project, under BGM_ROOT) for the preview."""
    fp = (BGM_ROOT / relpath).resolve()
    if not str(fp).startswith(str(BGM_ROOT.resolve())) or not fp.exists():
        abort(404)
    return send_file(fp)


def _delivery_srt(d, doc, srt_path):
    """The SRT we hand to the user: captions split at scene boundaries + frame-quantized (matches the
    exported clip cuts and the preview). Falls back to the plain quantized SRT on any problem."""
    srt_text = srt_path.read_text(encoding="utf-8", errors="ignore")
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return premiere_export.quantize_srt_to_frames(srt_text)
        vo = _find_vo_audio(d)
        total = max((premiere_export.audio_duration(vo) or 0.0) if vo else 0.0, cues[-1]["end"])
        words = premiere_export.load_word_tsv(d / "subtitle")
        return premiere_export.delivery_srt(doc.get("scenes", []), cues, total, words)
    except Exception:
        return premiere_export.quantize_srt_to_frames(srt_text)


def _emotion_tracks():
    """{EMOTION: [track filenames]} across the Background Music folders."""
    out = {}
    for emo in premiere_export.EMOTIONS:
        folder = BGM_ROOT / emo
        out[emo] = sorted(p.name for p in folder.iterdir()
                          if p.suffix.lower() in (".wav", ".mp3")) if folder.exists() else []
    return out


def _resolve_music(project, doc, cues, total, save=True):
    """Build-ready music segments that honor the SAVED plan + per-segment track overrides. The plan
    (Claude emotion-segmentation + auto-picked tracks) is computed ONCE and cached in doc.music_plan;
    later builds reuse it (so overrides stick and Claude isn't re-called every time)."""
    plan = doc.get("music_plan")
    valid = isinstance(plan, list) and plan and abs((plan[-1].get("end") or 0) - total) < 4.0
    if not valid:
        picked = premiere_export.pick_music(premiere_export.segment_emotions(cues, total, _claude_text), BGM_ROOT)
        plan = [{"start": round(s["start"], 3), "end": round(s["end"], 3), "emotion": s["emotion"],
                 "track": (Path(s["path"]).name if s.get("path") else None)} for s in picked]
        doc["music_plan"] = plan
        if save:
            save_doc(project, doc)
    cache_path = BGM_ROOT / ".loudness_cache.json"
    try:
        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    except Exception:
        cache = {}
    out = []
    for seg in plan:
        emo, track = seg.get("emotion"), seg.get("track")
        path = (BGM_ROOT / emo / track) if (track and (BGM_ROOT / emo / track).exists()) else None
        if path is None:                                    # track missing → any track in the folder
            folder = BGM_ROOT / emo
            files = sorted(p for p in folder.iterdir() if p.suffix.lower() in (".wav", ".mp3")) if folder.exists() else []
            path = files[0] if files else None
        lufs, tp = premiere_export.measure_lufs(path, cache) if path else (None, None)
        out.append({"start": seg["start"], "end": seg["end"], "emotion": emo, "path": path,
                    "src_dur": premiere_export.audio_duration(path) if path else None, "lufs": lufs, "tp": tp})
    try:
        cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    except Exception:
        pass
    return out


def _export_music(project, doc, srt_text, vo):
    """The music segments (saved/overridable plan) for the Premiere export — same plan as the preview."""
    try:
        cues = premiere_export.parse_srt(srt_text)
        if not cues:
            return None
        total = max((premiere_export.audio_duration(vo) or 0.0), cues[-1]["end"])
        return _resolve_music(project, doc, cues, total)
    except Exception:
        return None


@app.route("/api/music-tracks")
def api_music_tracks(project=None):
    return jsonify(_emotion_tracks())


@app.route("/api/music-override/<project>", methods=["POST"])
def api_music_override(project):
    """Set a specific segment's track (index into doc.music_plan)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    body = request.get_json(force=True)
    idx, track = body.get("index"), body.get("track")
    plan = doc.get("music_plan") or []
    if not isinstance(idx, int) or not (0 <= idx < len(plan)):
        return jsonify({"error": "bad segment index"}), 400
    emo = plan[idx].get("emotion")
    if track and not (BGM_ROOT / emo / track).exists():
        return jsonify({"error": "track not found in that mood folder"}), 400
    plan[idx]["track"] = track
    save_doc(project, doc)
    resp = {"ok": True, "url": None, "level": None}
    if track:
        path = BGM_ROOT / emo / track
        cache_path = BGM_ROOT / ".loudness_cache.json"
        try:
            cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
        except Exception:
            cache = {}
        lufs, tp = premiere_export.measure_lufs(path, cache)
        try:
            cache_path.write_text(json.dumps(cache, indent=0), encoding="utf-8")
        except Exception:
            pass
        resp["level"] = round(premiere_export.music_level(lufs, tp), 3)
        resp["url"] = "/bgm/" + path.resolve().relative_to(BGM_ROOT.resolve()).as_posix()
    return jsonify(resp)


@app.route("/api/music-resegment/<project>", methods=["POST"])
def api_music_resegment(project):
    """Forget the cached plan so the next build re-segments the music from scratch."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    doc["music_plan"] = []
    save_doc(project, doc)
    return jsonify({"ok": True})


def _build_timeline(project, doc):
    """The single source of truth for 'the assembled VSL': each scene's media + audio-driven
    time range, the scene-split caption cues, the normalized voice-over, and the emotion-
    segmented music with per-segment levels. Uses the SAME timing/music logic as the Premiere
    export, so preview == rendered MP4 == exported timeline.

    Media are LOCAL PATHS here; api_preview maps them to /media URLs for the browser and
    render_video feeds them straight to ffmpeg. Raises ValueError if the inputs aren't ready.
    """
    d, _ = proj_dir(project)
    srtp = _find_srt(d)
    vo = _normalized_vo(d)
    if not srtp or not vo:
        raise ValueError("Need a subtitle (.srt) and a voice-over first.")
    cues = premiere_export.parse_srt(srtp.read_text(encoding="utf-8", errors="ignore"))
    if not cues:
        raise ValueError("The subtitle has no readable cues.")
    vo_dur = premiere_export.audio_duration(vo) or 0.0
    total = max(vo_dur, cues[-1]["end"])
    scenes = doc.get("scenes", [])
    # accurate spoken-word onsets for mid-cue scenes (same as the export uses)
    words = premiere_export.load_word_tsv(d / "subtitle")
    word_starts = premiere_export.word_scene_starts(scenes, words) if words else None
    ranges, included = premiere_export.scene_time_ranges(scenes, cues, total, word_starts)
    cue_tok_times = premiere_export.accurate_cue_token_times(cues, words) if words else None

    # Snap every boundary to a whole video frame. Both scene starts and caption starts get the
    # SAME quantizer, so a scene and its caption switch on the exact same frame in the preview,
    # AND the rendered clip durations become integer frames (no ffmpeg cumulative-rounding drift).
    _FPS = premiere_export.FPS
    def qf(t):
        return round(round(t * _FPS) / _FPS, 5)   # 5 dp keeps the exact frame value (frame/60 repeats)

    out_scenes = []
    for s, (t0, t1), inc in zip(scenes, ranges, included):
        if not inc or t1 <= t0:
            continue
        vid = s.get("video") or {}
        img = s.get("image") or {}
        item = {"id": s.get("id"), "start": qf(t0), "end": qf(t1),
                "label": premiere_export.scene_label(s), "kind": "blank", "path": None, "img": None,
                # on-screen text overlays (burned onto the video, shown in preview + render)
                "texts": _scene_overlays(s),
                "transition": s.get("transition") or "none"}   # how this scene hands off to the next
        # the approved still image (if any) — the smooth fallback for the "images only" toggle
        imgf = (img.get("approved_file") or img.get("file")) if s.get("approved") else None
        if imgf and (d / imgf).exists():
            item["img"] = d / imgf
        if vid.get("approved") and vid.get("status") == "ready" and vid.get("file") and (d / vid["file"]).exists():
            item.update(kind="video", path=d / vid["file"])
        elif item["img"]:
            item.update(kind="image", path=item["img"])
        out_scenes.append(item)

    # split captions at scene boundaries so a caption and its scene switch together
    scene_starts = [t0 for (t0, t1), inc in zip(ranges, included) if inc and t1 > t0]
    caps = premiere_export.split_captions_at_scenes(cues, scene_starts, cue_tok_times)
    # same frame-quantizer as the scenes → caption starts land on the exact scene-start frame
    captions = [{"start": qf(c["start"]), "end": qf(c["end"]), "text": c["text"]}
                for c in caps if qf(c["end"]) > qf(c["start"])]

    music = []
    tracks_by_emotion = _emotion_tracks()
    try:
        segs = _resolve_music(project, doc, cues, total)     # saved/overridable plan
    except Exception:
        segs = []
    for i, seg in enumerate(segs):
        p = seg.get("path")
        emo = seg["emotion"]
        music.append({"index": i, "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                      "emotion": emo, "track": (Path(p).name if p else None),
                      "path": Path(p) if p else None,
                      "level": round(premiere_export.music_level(seg.get("lufs"), seg.get("tp")), 3),
                      "options": tracks_by_emotion.get(emo, [])})

    return {"total": round(total, 3), "vo": vo, "dir": d,
            "scenes": out_scenes, "captions": captions, "music": music,
            "sub_style": doc.get("subtitle_style") or None}


@app.route("/api/preview/<project>")
def api_preview(project):
    """Manifest for the in-dashboard rough-cut player. The client plays it synced — no
    server-side render (that's /api/render, which consumes the same timeline)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    try:
        tl = _build_timeline(project, doc)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    d = tl["dir"]

    # Remember that this project has a watchable preview, so re-opening it later can
    # restore the player without the user clicking Build Preview again. Re-read right before
    # writing so this GET can't clobber a concurrent scene edit (e.g. on-screen text just added)
    # that was saved between our load_doc above and here — only the flag is persisted.
    if not doc.get("preview_built"):
        fresh = load_doc(project) or doc
        fresh["preview_built"] = True
        save_doc(project, fresh)
        doc["preview_built"] = True

    def murl(p):
        return f"/media/{project}/{Path(p).relative_to(d).as_posix()}"

    out_scenes = []
    for s in tl["scenes"]:
        item = {"id": s["id"], "start": s["start"], "end": s["end"], "label": s["label"],
                "type": s["kind"],
                "url": murl(s["path"]) if s["path"] else None,
                "img": murl(s["img"]) if s["img"] else None}
        item["texts"] = s.get("texts") or []   # on-screen text overlays for this scene
        item["transition"] = s.get("transition") or "none"
        out_scenes.append(item)
    music = []
    for m in tl["music"]:
        e = {k: m[k] for k in ("index", "start", "end", "emotion", "track", "level", "options")}
        e["url"] = ("/bgm/" + m["path"].resolve().relative_to(BGM_ROOT.resolve()).as_posix()
                    ) if m["path"] else None
        music.append(e)

    return jsonify({"duration": tl["total"], "vo": murl(tl["vo"]),
                    "scenes": out_scenes, "captions": tl["captions"], "music": music})


# ---- routes: server-side MP4 render ----------------------------------------
RENDER_STATUS, RENDER_LOCK = {}, threading.Lock()
RENDER_PROCS = {}                 # project -> the running ffmpeg Popen (so a cancel can kill it)
RENDER_CANCEL = set()             # projects whose current render was cancelled by the user


def set_render_status(project, **kw):
    with RENDER_LOCK:
        st = RENDER_STATUS.get(project, {})
        st.update(kw); st["updated"] = time.time()
        RENDER_STATUS[project] = st
    return st


RENDER_HISTORY_KEEP = 8

def _archive_render(out_path, fast, doc, project, dur):
    """Keep a named copy of a finished render so it isn't lost when the next render overwrites
    render.mp4 / render_test.mp4. Real renders go to export/renders/, quick test renders to
    export/test-renders/. Filenames carry the project + date; test renders also carry their length in
    seconds (e.g. MyVSL_VSL_Test_26072026-143512_30s.mp4). Each folder is pruned to RENDER_HISTORY_KEEP."""
    try:
        export = Path(out_path).parent
        slug = fname_slug((doc or {}).get("title") or project)
        stamp, clock = today_ddmmyyyy(), time.strftime("%H%M%S")
        if fast:
            hist = export / "test-renders"
            fname = f"{slug}_VSL_Test_{stamp}-{clock}_{max(1, int(round(dur or 0)))}s.mp4"
        else:
            hist = export / "renders"
            fname = f"{slug}_VSL_Video_{stamp}-{clock}.mp4"
        hist.mkdir(exist_ok=True)
        shutil.copy2(out_path, hist / fname)
        files = sorted(hist.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[RENDER_HISTORY_KEEP:]:
            try:
                old.unlink()
            except OSError:
                pass
    except Exception:
        pass

def run_render_job(project, doc, out_path, name, opts):
    """Background thread: build the timeline, hand it to ffmpeg, track progress."""
    with RENDER_LOCK:
        RENDER_CANCEL.discard(project)          # fresh run — clear any stale cancel flag
    try:
        set_render_status(project, status="running", pct=0, step="Preparing timeline…", error=None)
        tl = _build_timeline(project, doc)
        set_render_status(project, step="Rendering video…", duration=tl["total"])

        def on_progress(pct, done):
            set_render_status(project, pct=pct, step="Rendering video…")

        def on_status(text):
            set_render_status(project, step=text)

        def on_proc(p):
            with RENDER_LOCK:
                RENDER_PROCS[project] = p
                cancel_now = project in RENDER_CANCEL   # cancel arrived before ffmpeg started
            if cancel_now:
                try: p.terminate()
                except Exception: pass

        def should_cancel():
            with RENDER_LOCK:
                return project in RENDER_CANCEL

        render_video.render(tl, out_path, out_path.parent / "_render_tmp", opts,
                            on_progress, on_proc, on_status, should_cancel)
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL        # cancel that raced past the kill
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
            return
        size = out_path.stat().st_size
        _rng = opts.get("range")
        _rendered_dur = (_rng[1] - _rng[0]) if _rng else float(tl.get("total") or 0)
        _archive_render(out_path, bool(opts.get("fast")), doc, project, _rendered_dur)   # named copy in the render history
        set_render_status(project, status="done", pct=100, step="Done",
                          file=f"export/{out_path.name}", name=name, size=size,
                          subs=opts.get("burnsubs", True), fast=bool(opts.get("fast")), error=None)
    except Exception as e:
        # a cancel kills ffmpeg -> render() raises; report that as "cancelled", not an error
        with RENDER_LOCK:
            cancelled = project in RENDER_CANCEL
            RENDER_CANCEL.discard(project)
        if cancelled:
            try: out_path.unlink()               # drop the half-written file
            except OSError: pass
            set_render_status(project, status="cancelled", pct=0, step="Cancelled", error=None)
        else:
            set_render_status(project, status="error", error=str(e))
    finally:
        with RENDER_LOCK:
            RENDER_PROCS.pop(project, None)


@app.route("/api/render/<project>", methods=["POST"])
def api_render_start(project):
    """Kick off the MP4 render (captions burned in, voice-over + music mixed)."""
    doc = load_doc(project)
    if doc is None:
        abort(404)
    if get_render_status(project).get("status") == "running":
        return jsonify({"error": "A render is already running for this project."}), 409
    d, _ = proj_dir(project)
    try:
        _build_timeline(project, doc)          # fail fast with a clear message
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    body = request.get_json(silent=True) or {}
    fast = bool(body.get("fast"))          # quick low-res test render (720p30, ultrafast) to check sync/timing
    music = body.get("music", True) is not False
    opts = {"kenburns": bool(body.get("kenburns")),
            "music": music,
            "crossfade": music,          # cross-fade only matters when music is present
            "burnsubs": body.get("burnsubs", True) is not False,
            "onscreentext": body.get("onscreentext", True) is not False,
            "transitions": body.get("transitions", True) is not False,
            "gpu": bool(body.get("gpu")),                 # encode with the GPU (NVENC) if available
            "low_priority": bool(body.get("low_priority")),  # run ffmpeg below-normal + fewer threads
            "fast": fast}
    # optional partial render: only encode [range_start, range_end] seconds of the timeline
    try:
        rs, re_ = body.get("range_start"), body.get("range_end")
        if rs is not None and re_ is not None and float(re_) > float(rs):
            opts["range"] = (float(rs), float(re_))
    except (TypeError, ValueError):
        pass
    name = _vsl_name(doc, project, "Test-Video" if fast else "Video", "mp4")
    out = d / "export" / ("render_test.mp4" if fast else "render.mp4")
    set_render_status(project, status="running", pct=0, step="Queued…", file=None, error=None)
    threading.Thread(target=run_render_job, args=(project, doc, out, name, opts), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/renders/<project>")
def api_list_renders(project):
    """List the timestamped render-history files (newest first)."""
    d, _ = proj_dir(project)
    out = []
    for sub, is_test in (("renders", False), ("test-renders", True)):
        hist = d / "export" / sub
        if not hist.exists():
            continue
        for p in hist.glob("*.mp4"):
            st = p.stat()
            out.append({"name": p.name, "file": f"export/{sub}/{p.name}",
                        "size": st.st_size, "mtime": st.st_mtime, "test": is_test})
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return jsonify({"renders": out})

@app.route("/api/renders/<project>/<name>/delete", methods=["POST"])
def api_delete_render(project, name):
    """Delete one render-history file (guarded to the project's renders/ + test-renders/ folders)."""
    d, _ = proj_dir(project)
    for sub in ("renders", "test-renders"):
        hist = (d / "export" / sub).resolve()
        p = (hist / name).resolve()
        if p.suffix == ".mp4" and p.parent == hist and p.exists():
            try:
                p.unlink()
            except OSError:
                pass
            break
    return jsonify({"ok": True})

@app.route("/api/reveal/<project>", methods=["POST"])
def api_reveal(project):
    """Open the folder containing a render (in Explorer, file selected). Local desktop use — the server
    runs on the same machine as the window. Guarded to files under the project's export/ folder."""
    d, _ = proj_dir(project)
    rel = (request.get_json(silent=True) or {}).get("file") or ""
    p = (d / rel).resolve()
    ok = False
    try:
        if d.resolve() in p.parents and p.exists():
            subprocess.Popen(["explorer", "/select,", str(p)])   # explorer returns 1 even on success — don't check
            ok = True
    except Exception:
        pass
    return jsonify({"ok": ok})


@app.route("/api/render/<project>/cancel", methods=["POST"])
def api_render_cancel(project):
    """Stop an in-progress render: mark it cancelled and kill the ffmpeg process."""
    if get_render_status(project).get("status") != "running":
        return jsonify({"error": "No render is running for this project."}), 409
    with RENDER_LOCK:
        RENDER_CANCEL.add(project)
        proc = RENDER_PROCS.get(project)
    if proc and proc.poll() is None:
        try:
            proc.terminate()                     # ends ffmpeg -> the render thread finishes as "cancelled"
        except Exception:
            pass
    set_render_status(project, step="Cancelling…")
    return jsonify({"ok": True})


def get_render_status(project):
    with RENDER_LOCK:
        return dict(RENDER_STATUS.get(project) or {"status": "idle"})


@app.route("/api/render/<project>")
def api_render_status(project):
    return jsonify(get_render_status(project))

if __name__ == "__main__":
    print(f"KIE key: {'set' if KIE_KEY else 'MISSING'} | projects dir: {PROJECTS}")
    # Prefer port 80 (so the URL needs no ':port' → http://vsldashboard / http://localhost).
    # Fall back to 8000 if 80 is taken, so the dashboard always comes up.
    _port = int(os.environ.get("VSL_PORT", "80"))
    # Bind to 127.0.0.1 (this PC only) by default. Set VSL_HOST=0.0.0.0 to also serve it to other
    # machines on the network / over a Tailscale or tunnel connection. Only do that on a trusted
    # network or behind Tailscale — the dashboard has NO login and holds your API keys.
    _host = os.environ.get("VSL_HOST", "127.0.0.1")
    try:
        print(f"Serving on http://localhost:{_port}/  (http://vsldashboard/ after setup-vsldashboard.bat)")
        app.run(host=_host, port=_port, threaded=True, debug=False)
    except OSError:
        print("port 80 unavailable -- falling back to http://localhost:8000/")
        app.run(host=_host, port=8000, threaded=True, debug=False)
