# -*- coding: utf-8 -*-
r"""
FULL SYSTEM SELF-TEST  ---  "Hersey calisiyor mu?" tek komut.

Amac: BASKA BIR PC'ye kopyaladiktan sonra, HIC proje acmadan / hic manuel test yapmadan tum sistemin
saglikli oldugunu dogrulamak. Odemeli hicbir API cagirmaz, hicbir dosya bozmaz, ag gerektirmez.

Neyi test eder:
  A. Calisma ortami + bagimliliklar  (Python, ffmpeg/ffprobe, torch+CUDA, OpenCV, Pillow, whisper, LaMa)
  B. Dosyalar + varliklar            (kod modulleri derlenir, statikler, sablon, gecis .mov/.wav, AI modelleri, data, auth.json)
  C. Uygulama AYAKTA MI              (Flask'i gercek HTTP stack ile calistirir: index.html render olur, tum sekmeler/statikler servis edilir, guvenli GET rotalari 200 doner)
  D. Kablolamalar                    (smoke_test.py: her butonun/sekmenin fetch'i gercek bir @app.route'a bagli mi)
  E. Yapilandirma                    (KIE anahtari, Claude CLI girisi)  -> sadece UYARI

Calistirma (paketli PC'de):   runtime\python.exe app\self_test.py
Cikis kodu: 0 = kritik hata yok, 1 = en az bir FAIL.
"""
import os
import sys
import json
import subprocess
import importlib
from pathlib import Path

# cp1254 konsolunda tuhaf karakter yuzunden CIKMESIN diye ciktilari encoding-korumali yap.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent          # app/  (dev: dashboard/)
ROOT = HERE.parent                              # VSLDashboard/  (dev: video-agent-template/)

# ------------------------------------------------------------------------------------------------
# desktop.py'nin import aninda kurdugu ORTAMI birebir kur (boylece app'in GERCEK kosullarini test ederiz):
#   bundled ffmpeg -> PATH,  whisper modelleri -> XDG_CACHE_HOME,  kullanici verisi -> VSL_DATA_DIR
# ------------------------------------------------------------------------------------------------
PACKAGED = (ROOT / "runtime").exists() or (ROOT / "ffmpeg").exists()
if PACKAGED:
    _ff = ROOT / "ffmpeg"
    if _ff.exists():
        os.environ["PATH"] = str(_ff) + os.pathsep + os.environ.get("PATH", "")
    _data = ROOT / "data"
    _data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VSL_DATA_DIR", str(_data))
    _cache = ROOT / "cache"
    if (_cache / "whisper").exists():
        os.environ.setdefault("XDG_CACHE_HOME", str(_cache))

# ------------------------------------------------------------------------------------------------
# Rapor toplayici: PASS / WARN / FAIL  (FAIL -> cikis 1; WARN -> ozellik eksik ama cekirdek calisir)
# ------------------------------------------------------------------------------------------------
RESULTS = []  # (level, name, detail)
_ICON = {"PASS": "  ok  ", "WARN": " WARN ", "FAIL": " FAIL "}


def rec(level, name, detail=""):
    RESULTS.append((level, name, detail))
    line = _ICON[level] + name
    if detail and level != "PASS":
        line += "   -> " + detail
    print(line)


def ok(name, cond, fail_level="FAIL", detail_ok="", detail_bad=""):
    """cond True -> PASS; False -> FAIL (veya WARN). Tek satirlik kontroller icin."""
    if cond:
        rec("PASS", name, detail_ok)
    else:
        rec(fail_level, name, detail_bad)
    return cond


def section(title):
    print("\n" + "=" * 78 + "\n  " + title + "\n" + "=" * 78)


# ================================================================================================
section("A) CALISMA ORTAMI + BAGIMLILIKLAR")
# ================================================================================================
rec("PASS", f"Python {sys.version.split()[0]}  ({'PAKETLI runtime' if PACKAGED else 'DEV'})")

# --- ffmpeg / ffprobe (render + ses + altyazi hepsi buna bagli) ---
def _tool(binname):
    try:
        p = subprocess.run([binname, "-version"], capture_output=True, text=True, timeout=20)
        first = (p.stdout or p.stderr or "").splitlines()[0] if (p.stdout or p.stderr) else ""
        return p.returncode == 0, first
    except Exception as e:
        return False, repr(e)

_ffok, _ffver = _tool("ffmpeg")
ok("ffmpeg calisiyor", _ffok, detail_bad="ffmpeg PATH'te yok / calismadi", detail_ok="")
if _ffok:
    print("        " + _ffver)
_fpok, _fpver = _tool("ffprobe")
ok("ffprobe calisiyor", _fpok, fail_level="WARN", detail_bad="ffprobe yok (bazi sure olcumleri bundan etkilenebilir)")

# --- Python paketleri: CEKIRDEK (yoksa app hic acilmaz) vs OZELLIK (yoksa o ozellik calismaz) ---
def _imp(mod, level, label=None, want_attr=None):
    label = label or mod
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "") or getattr(m, "version", "")
        if callable(ver):
            ver = ""
        rec("PASS", f"{label} yuklu" + (f"  (v{ver})" if ver else ""))
        return m
    except Exception as e:
        rec(level, f"{label} EKSIK", repr(e).split("(")[0])
        return None

# cekirdek: bunlar yoksa app zaten import edilemez
for mod, lbl in [("flask", "Flask"), ("werkzeug", "Werkzeug"), ("requests", "requests"),
                 ("PIL", "Pillow"), ("numpy", "NumPy")]:
    _imp(mod, "FAIL", lbl)

# ozellik bagimliliklari: eksikse cekirdek app calisir ama o ozellik calismaz -> WARN
_cv = _imp("cv2", "WARN", "OpenCV (silme/erase + render)")
_torch = _imp("torch", "WARN", "PyTorch (LaMa erase + Whisper altyazi)")
if _torch is not None:
    try:
        cuda = bool(_torch.cuda.is_available())
        name = _torch.cuda.get_device_name(0) if cuda else ""
        ok("CUDA (GPU hizlandirma)", cuda, fail_level="WARN",
           detail_ok=name, detail_bad="GPU yok/gorunmuyor -> LaMa erase + Whisper CPU'da COK yavas olur")
        if cuda:
            print("        GPU: " + name)
    except Exception as e:
        rec("WARN", "CUDA sorgulanamadi", repr(e).split("(")[0])
# whisper (stable-ts VEYA openai-whisper)
if _imp("stable_whisper", "WARN", "stable-whisper (VSL altyazi hizalama)") is None:
    _imp("whisper", "WARN", "openai-whisper (altyazi)")
_imp("simple_lama_inpainting", "WARN", "simple-lama (nesne silme)")


# ================================================================================================
section("B) DOSYALAR + VARLIKLAR")
# ================================================================================================
import py_compile
# --- her .py derlenir mi (bu klasor) ---
_ncomp = 0
for py in sorted(HERE.glob("*.py")):
    if py.name in ("self_test.py",):
        continue
    try:
        py_compile.compile(str(py), doraise=True)
        _ncomp += 1
    except py_compile.PyCompileError as e:
        rec("FAIL", f"derleme HATASI {py.name}", str(e).splitlines()[-1])
rec("PASS", f"{_ncomp} Python modulu derlendi (app/desktop/render_video/premiere_export/...)")
# subtitle scriptleri (ayri klasor)
_sub = ROOT / "subtitle"
if _sub.exists():
    _ns = 0
    for py in sorted(_sub.glob("*.py")):
        try:
            py_compile.compile(str(py), doraise=True); _ns += 1
        except py_compile.PyCompileError as e:
            rec("FAIL", f"derleme HATASI subtitle/{py.name}", str(e).splitlines()[-1])
    rec("PASS", f"{_ns} altyazi modulu derlendi (subtitle/)")
else:
    rec("WARN", "subtitle/ klasoru yok", "VSL altyazi hizalama scriptleri bulunamadi")

# --- statikler + sablon (arayuzun kendisi) ---
for rel in ["static/app.js", "static/style.css", "static/logo.png", "templates/index.html"]:
    ok(f"var: {rel}", (HERE / rel).exists(), detail_bad="EKSIK")

# --- gecis (transition) medyasi: 3 .mov + 3 .wav ---
_tdir = HERE / "Transitions"
if _tdir.exists():
    for fn in ["Corporate.mov", "Film.mov", "Light Leak.mov",
               "corporate_sfx.wav", "film_sfx.wav", "lightleak_sfx.wav"]:
        f = _tdir / fn
        ok(f"gecis medyasi: {fn}", f.exists() and f.stat().st_size > 0,
           fail_level="WARN", detail_bad="yok -> bu gecis atlanir (app cokmeaz)")
else:
    rec("WARN", "Transitions/ klasoru yok", "Corporate/Film/Light Leak gecisleri calismaz (app cokmez)")

# --- AI modelleri (cache) ---
_cache = ROOT / "cache"
_lama = _cache / "torch" / "hub" / "checkpoints" / "big-lama.pt"
ok("model: big-lama.pt (nesne silme)", _lama.exists() and _lama.stat().st_size > 1_000_000,
   fail_level="WARN", detail_bad="yok -> LaMa erase calismaz (OpenCV Telea yedek devreye girer)")
_wdir = _cache / "whisper"
if _wdir.exists():
    pts = [p.name for p in _wdir.glob("*.pt")]
    ok("model: whisper *.pt (altyazi)", len(pts) > 0,
       fail_level="WARN", detail_ok=", ".join(sorted(pts)), detail_bad="whisper modeli yok -> altyazi hizalama calismaz")
    if pts:
        print("        " + ", ".join(sorted(pts)))
else:
    rec("WARN", "cache/whisper yok", "altyazi modelleri bulunamadi")

# --- kullanici verisi + giris veritabani ---
_data = Path(os.environ.get("VSL_DATA_DIR", str(ROOT / "data")))
# Paketli kurulumda data/ MUTLAKA olmali (yoksa FAIL). DEV'de yoksa sadece bilgi (WARN).
ok("data/ klasoru var", _data.exists(),
   fail_level=("FAIL" if PACKAGED else "WARN"), detail_bad=str(_data) + " yok")
_auth = _data / "auth.json"
if _auth.exists():
    try:
        _a = json.loads(_auth.read_text(encoding="utf-8"))
        _users = list((_a.get("users") or {}).keys()) if isinstance(_a, dict) else []
        ok("auth.json gecerli + kullanicilar var", len(_users) > 0,
           detail_ok="kullanicilar: " + ", ".join(_users), detail_bad="auth.json'da kullanici yok")
        if _users:
            print("        kullanicilar: " + ", ".join(_users))
    except Exception as e:
        rec("FAIL", "auth.json BOZUK", repr(e).split("(")[0])
else:
    rec("WARN", "auth.json yok", "ilk giriste olusturulur (varsayilan)")


# ================================================================================================
section("C) UYGULAMA AYAKTA MI  (gercek Flask HTTP stack, test istemcisi)")
# ================================================================================================
sys.path.insert(0, str(HERE))
_app = None
try:
    import app as _app
    _routes = list(_app.app.url_map.iter_rules())
    rec("PASS", f"app import edildi + {len(_routes)} rota kayitli")
except Exception as e:
    rec("FAIL", "app IMPORT EDILEMEDI", repr(e).split("\n")[0][:120])

if _app is not None:
    client = _app.app.test_client()

    # index.html gercekten RENDER oluyor mu? (Jinja hatasi olsa 500 gelir)  -> arayuzun / sekmelerin yuklendigi kanit
    try:
        r = client.get("/", follow_redirects=True)
        body = r.get_data(as_text=True)
        ok("index.html render oldu (arayuz + sekmeler yukleniyor)",
           r.status_code == 200 and ("<!doctype" in body.lower() or "<html" in body.lower()),
           detail_bad=f"HTTP {r.status_code}")
    except Exception as e:
        rec("FAIL", "index.html render CRASH", repr(e).split("\n")[0][:120])

    # statik dosyalar servis ediliyor mu?
    for rel in ["/static/app.js", "/static/style.css", "/static/logo.png"]:
        try:
            r = client.get(rel)
            ok(f"servis: {rel}", r.status_code == 200, detail_bad=f"HTTP {r.status_code}")
        except Exception as e:
            rec("FAIL", f"servis CRASH {rel}", repr(e).split("\n")[0][:80])

    # PARAMETRESIZ + GUVENLI (yalnizca-okuma) GET rotalarinin hepsini otomatik vur -> hicbiri 500 vermemeli.
    # (agi/yavas olanlari disla: claude durum sorgusu subprocess+ag yapar; credit param ister zaten.)
    _EXCLUDE = ("claude", "credit", "logout", "download", "reveal")
    _get_hit = 0
    _get_fail = 0
    for rule in _routes:
        path = str(rule.rule)
        if "<" in path:                       # parametreli (proje vb.) -> atla
            continue
        if "GET" not in (rule.methods or set()):
            continue
        if path in ("/", "/static/<path:filename>"):
            continue
        if any(x in path for x in _EXCLUDE):
            continue
        try:
            r = client.get(path)
            _get_hit += 1
            if r.status_code >= 500:
                _get_fail += 1
                rec("FAIL", f"GET {path}", f"HTTP {r.status_code} (sunucu hatasi)")
        except Exception as e:
            _get_fail += 1
            rec("FAIL", f"GET {path} CRASH", repr(e).split('\n')[0][:80])
    ok(f"parametresiz GET rotalari saglikli ({_get_hit} rota, {_get_fail} hata)", _get_fail == 0)


# ================================================================================================
section("D) KABLOLAMALAR  (smoke_test.py: her sekme/buton bir backend rotaya bagli mi)")
# ================================================================================================
_smoke = HERE / "smoke_test.py"
if _smoke.exists():
    try:
        p = subprocess.run([sys.executable, str(_smoke)], capture_output=True, text=True, timeout=180)
        outtail = (p.stdout or "").strip().splitlines()
        passed = p.returncode == 0 and any("SMOKE TEST PASSED" in l for l in outtail)
        ok("smoke_test: tum fetch URL'leri -> gercek rota; prompt/whitelist degismeleri saglam", passed,
           detail_bad="smoke_test BASARISIZ (asagidaki ayrinti):")
        if not passed:
            for l in outtail[-15:]:
                print("        " + l)
    except Exception as e:
        rec("WARN", "smoke_test calistirilmadi", repr(e).split("(")[0])
else:
    rec("WARN", "smoke_test.py yok", "kablolama dogrulamasi atlandi")


# ================================================================================================
section("E) YAPILANDIRMA  (sadece bilgi / uyari)")
# ================================================================================================
if _app is not None:
    # KIE anahtari (goruntu + video uretimi buna bagli)
    _kie = getattr(_app, "KIE_KEY", "")
    ok("KIE_API_KEY ayarli (goruntu/video uretimi)", bool(_kie), fail_level="WARN",
       detail_ok="(...%s)" % (_kie[-4:] if _kie else ""),
       detail_bad="anahtar yok -> Ayarlar > Keys'ten girilmeli (app icinde de girilebilir)")
    # Claude CLI girisi (tum metin/senaryo AI'i kullanicinin Claude aboneligiyle calisir)
    try:
        _exe = _app._claude_exe() if hasattr(_app, "_claude_exe") else None
        ok("Claude Code CLI kurulu (metin/senaryo AI)", bool(_exe), fail_level="WARN",
           detail_ok=str(_exe), detail_bad="claude bulunamadi -> app icinde 'Connect Claude' ile kurulur/giris yapilir")
    except Exception as e:
        rec("WARN", "Claude CLI sorgulanamadi", repr(e).split("(")[0])


# ================================================================================================
# OZET
# ================================================================================================
nf = sum(1 for l, _, _ in RESULTS if l == "FAIL")
nw = sum(1 for l, _, _ in RESULTS if l == "WARN")
npass = sum(1 for l, _, _ in RESULTS if l == "PASS")
print("\n" + "=" * 78)
print(f"  OZET:  {npass} PASS   |   {nw} WARN   |   {nf} FAIL")
print("=" * 78)
if nf:
    print("\n  KRITIK HATALAR (bunlar duzelmeden sistem tam calismaz):")
    for l, name, detail in RESULTS:
        if l == "FAIL":
            print("   X  " + name + (("  -> " + detail) if detail else ""))
if nw:
    print("\n  UYARILAR (cekirdek calisir; sadece ilgili OZELLIK etkilenir):")
    for l, name, detail in RESULTS:
        if l == "WARN":
            print("   !  " + name + (("  -> " + detail) if detail else ""))
if not nf:
    print("\n  >>> SISTEM SAGLIKLI. Cekirdek + arayuz + tum rotalar calisiyor." +
          ("" if not nw else " (Yukaridaki uyarilardaki ozellikler icin ilgili parca/anahtar gerekir.)"))
else:
    print("\n  >>> KRITIK HATA VAR. Yukaridaki X'leri gider.")
print()

# Makine-okur cikti: /self-test route'u bu satiri ayiklayip modalda gosterir.
if "--json" in sys.argv:
    print("##JSON## " + json.dumps({
        "ok": nf == 0,
        "summary": {"pass": npass, "warn": nw, "fail": nf},
        "results": [{"level": lvl, "name": nm, "detail": dt} for lvl, nm, dt in RESULTS],
    }, ensure_ascii=False))

sys.exit(1 if nf else 0)
