# -*- coding: utf-8 -*-
r"""
FULL SYSTEM SELF-TEST  ---  "Does everything work?" in one command.

Goal: after copying VSLDashboard to ANOTHER PC, confirm the whole system is healthy WITHOUT opening a
project or doing manual tests. Calls NO paid API, corrupts no files, needs no network.

What it checks:
  A. Runtime + dependencies  (Python, ffmpeg/ffprobe, torch+CUDA, OpenCV, Pillow, Whisper, LaMa)
  B. Files + assets          (every .py compiles, statics, template, transition .mov/.wav, AI models, data, auth.json)
  C. Is the app alive        (boots Flask over the real HTTP stack: index.html renders, every tab/static is served,
                              safe GET routes return 200)
  D. Wiring                  (smoke_test.py: every button/tab fetch maps to a real @app.route)
  E. Configuration           (KIE key, Claude CLI login)  -> WARN only

Run (on the packaged PC):   runtime\python.exe app\self_test.py
Exit code: 0 = no critical error, 1 = at least one FAIL.
"""
import os
import sys
import json
import subprocess
import importlib
from pathlib import Path

# The console can be cp1254; make prints encoding-proof so a stray non-ASCII char can never crash the run.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent          # app/  (dev: dashboard/)
ROOT = HERE.parent                              # VSLDashboard/  (dev: video-agent-template/)

# ------------------------------------------------------------------------------------------------
# Reproduce EXACTLY the environment desktop.py sets up at import (so we test the app's REAL conditions):
#   bundled ffmpeg -> PATH,  whisper models -> XDG_CACHE_HOME,  user data -> VSL_DATA_DIR
# ------------------------------------------------------------------------------------------------
PACKAGED = (ROOT / "runtime").exists() or (ROOT / "ffmpeg").exists()
if PACKAGED:
    _ff = ROOT / "ffmpeg"
    if _ff.exists():
        os.environ["PATH"] = str(_ff) + os.pathsep + os.environ.get("PATH", "")
    _data = ROOT / "data"
    _data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VSL_DATA_DIR", str(_data))
    _cache = ROOT / "cache"
    if (_cache / "whisper").exists():
        os.environ.setdefault("XDG_CACHE_HOME", str(_cache))

# ------------------------------------------------------------------------------------------------
# Report collector: PASS / WARN / FAIL  (FAIL -> exit 1; WARN -> feature missing but core still works)
# ------------------------------------------------------------------------------------------------
RESULTS = []  # (level, name, detail)
_ICON = {"PASS": "  ok  ", "WARN": " WARN ", "FAIL": " FAIL "}


def rec(level, name, detail=""):
    RESULTS.append((level, name, detail))
    line = _ICON[level] + name
    if detail and level != "PASS":
        line += "   -> " + detail
    print(line)


def ok(name, cond, fail_level="FAIL", detail_ok="", detail_bad=""):
    """cond True -> PASS; False -> FAIL (or WARN). For one-line checks."""
    if cond:
        rec("PASS", name, detail_ok)
    else:
        rec(fail_level, name, detail_bad)
    return cond


def section(title):
    print("\n" + "=" * 78 + "\n  " + title + "\n" + "=" * 78)


# ================================================================================================
section("A) RUNTIME + DEPENDENCIES")
# ================================================================================================
rec("PASS", f"Python {sys.version.split()[0]}  ({'PACKAGED runtime' if PACKAGED else 'DEV'})")

# --- ffmpeg / ffprobe (render + audio + subtitles all depend on these) ---
def _tool(binname):
    try:
        p = subprocess.run([binname, "-version"], capture_output=True, text=True, timeout=20)
        first = (p.stdout or p.stderr or "").splitlines()[0] if (p.stdout or p.stderr) else ""
        return p.returncode == 0, first
    except Exception as e:
        return False, repr(e)

_ffok, _ffver = _tool("ffmpeg")
ok("ffmpeg works", _ffok, detail_bad="ffmpeg not on PATH / failed to run")
if _ffok:
    print("        " + _ffver)
_fpok, _fpver = _tool("ffprobe")
ok("ffprobe works", _fpok, fail_level="WARN", detail_bad="ffprobe missing (some duration probing may be affected)")

# --- Python packages: CORE (missing -> the app cannot even start) vs FEATURE (missing -> that feature is off) ---
def _imp(mod, level, label=None):
    label = label or mod
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "") or getattr(m, "version", "")
        if callable(ver):
            ver = ""
        rec("PASS", f"{label} installed" + (f"  (v{ver})" if ver else ""))
        return m
    except Exception as e:
        rec(level, f"{label} MISSING", repr(e).split("(")[0])
        return None

# core: without these the app can't be imported at all
for mod, lbl in [("flask", "Flask"), ("werkzeug", "Werkzeug"), ("requests", "requests"),
                 ("PIL", "Pillow"), ("numpy", "NumPy")]:
    _imp(mod, "FAIL", lbl)

# feature dependencies: missing -> core app runs but that feature won't -> WARN
_cv = _imp("cv2", "WARN", "OpenCV (erase + render)")
_torch = _imp("torch", "WARN", "PyTorch (LaMa erase + subtitle alignment)")
if _torch is not None:
    try:
        cuda = bool(_torch.cuda.is_available())
        name = _torch.cuda.get_device_name(0) if cuda else ""
        ok("CUDA (GPU acceleration)", cuda, fail_level="WARN",
           detail_ok=name, detail_bad="no GPU visible -> LaMa erase + Whisper run VERY slowly on CPU")
        if cuda:
            print("        GPU: " + name)
    except Exception as e:
        rec("WARN", "CUDA query failed", repr(e).split("(")[0])
# MMS-FA is what TIMES the subtitles and the karaoke now. Whisper is still needed, but only to
# TRANSCRIBE (the reconcile step) — an aligner cannot do that. So both are checked, separately.
_ta = _imp("torchaudio", "WARN", "torchaudio (subtitle + karaoke timing)")
if _ta is not None:
    try:
        _has = hasattr(_ta.pipelines, "MMS_FA")
        ok("MMS-FA forced aligner", _has, fail_level="WARN",
           detail_ok="torchaudio " + getattr(_ta, "__version__", "?"),
           detail_bad="torchaudio is too old for MMS_FA -> subtitle and karaoke timing will fail; "
                      "upgrade torchaudio (2.1+)")
    except Exception as e:
        rec("WARN", "MMS-FA query failed", repr(e).split("(")[0])
# whisper (stable-ts OR openai-whisper) — transcription only, for script reconcile
if _imp("stable_whisper", "WARN", "stable-whisper (script reconcile transcription)") is None:
    _imp("whisper", "WARN", "openai-whisper (transcription)")
_imp("simple_lama_inpainting", "WARN", "simple-lama (object erase)")


# ================================================================================================
section("B) FILES + ASSETS")
# ================================================================================================
import py_compile
# --- does every .py compile (this folder) ---
_ncomp = 0
for py in sorted(HERE.glob("*.py")):
    if py.name in ("self_test.py",):
        continue
    try:
        py_compile.compile(str(py), doraise=True)
        _ncomp += 1
    except py_compile.PyCompileError as e:
        rec("FAIL", f"COMPILE ERROR {py.name}", str(e).splitlines()[-1])
rec("PASS", f"{_ncomp} Python modules compiled (app/desktop/render_video/premiere_export/...)")
# subtitle scripts (separate folder)
_sub = ROOT / "subtitle"
if _sub.exists():
    _ns = 0
    for py in sorted(_sub.glob("*.py")):
        try:
            py_compile.compile(str(py), doraise=True); _ns += 1
        except py_compile.PyCompileError as e:
            rec("FAIL", f"COMPILE ERROR subtitle/{py.name}", str(e).splitlines()[-1])
    rec("PASS", f"{_ns} subtitle modules compiled (subtitle/)")
else:
    rec("WARN", "subtitle/ folder missing", "VSL subtitle alignment scripts not found")

# --- statics + template (the UI itself) ---
for rel in ["static/app.js", "static/style.css", "static/logo.png", "templates/index.html"]:
    ok(f"present: {rel}", (HERE / rel).exists(), detail_bad="MISSING")

# --- transition media: 3 .mov + 3 .wav ---
_tdir = HERE / "Transitions"
if _tdir.exists():
    for fn in ["Corporate.mov", "Film.mov", "Light Leak.mov",
               "corporate_sfx.wav", "film_sfx.wav", "lightleak_sfx.wav"]:
        f = _tdir / fn
        ok(f"transition media: {fn}", f.exists() and f.stat().st_size > 0,
           fail_level="WARN", detail_bad="missing -> this transition is skipped (app won't crash)")
else:
    rec("WARN", "Transitions/ folder missing", "Corporate/Film/Light Leak transitions won't run (app won't crash)")

# --- AI models (cache) ---
_cache = ROOT / "cache"
_lama = _cache / "torch" / "hub" / "checkpoints" / "big-lama.pt"
ok("model: big-lama.pt (object erase)", _lama.exists() and _lama.stat().st_size > 1_000_000,
   fail_level="WARN", detail_bad="missing -> LaMa erase off (OpenCV Telea fallback kicks in)")
# The aligner model (MMS-FA) is what subtitle and karaoke TIMING needs. It is downloaded on first
# launch rather than shipped, so report it plainly instead of leaving the user to guess.
try:
    import assets as _assets
    for _a in _assets.status():
        ok("model: " + _a["name"], _a["ready"], fail_level="WARN",
           detail_ok="%.2f GB" % (_a["have"] / 1073741824.0),
           detail_bad="not downloaded yet -> %s unavailable (the app fetches it on launch)" % _a["why"])
except Exception as _e:
    rec("WARN", "aligner model check failed", repr(_e).split("(")[0])

# Whisper models are for TRANSCRIPTION only now (the script-reconcile step), not for timing —
# missing ones no longer mean "no subtitles".
_wdir = _cache / "whisper"
if _wdir.exists():
    pts = [p.name for p in _wdir.glob("*.pt")]
    ok("model: whisper *.pt (script reconcile)", len(pts) > 0,
       fail_level="WARN", detail_ok=", ".join(sorted(pts)),
       detail_bad="no whisper model -> 'reconcile script to voice-over' off (subtitles still work)")
    if pts:
        print("        " + ", ".join(sorted(pts)))
else:
    rec("WARN", "cache/whisper missing",
        "script-reconcile transcription unavailable (subtitle timing is unaffected)")

# --- user data + login database ---
_data = Path(os.environ.get("VSL_DATA_DIR", str(ROOT / "data")))
# On a packaged install data/ MUST exist (else FAIL). In DEV, just informational (WARN).
ok("data/ folder present", _data.exists(),
   fail_level=("FAIL" if PACKAGED else "WARN"), detail_bad=str(_data) + " missing")
_auth = _data / "auth.json"
if _auth.exists():
    try:
        _a = json.loads(_auth.read_text(encoding="utf-8"))
        _users = list((_a.get("users") or {}).keys()) if isinstance(_a, dict) else []
        ok("auth.json valid + has users", len(_users) > 0,
           detail_ok="users: " + ", ".join(_users), detail_bad="no users in auth.json")
        if _users:
            print("        users: " + ", ".join(_users))
    except Exception as e:
        rec("FAIL", "auth.json CORRUPT", repr(e).split("(")[0])
else:
    rec("WARN", "auth.json missing", "created on first sign-in (default)")


# ================================================================================================
section("C) IS THE APP ALIVE  (real Flask HTTP stack, test client)")
# ================================================================================================
sys.path.insert(0, str(HERE))
_app = None
try:
    import app as _app
    _routes = list(_app.app.url_map.iter_rules())
    rec("PASS", f"app imported + {len(_routes)} routes registered")
except Exception as e:
    rec("FAIL", "app COULD NOT BE IMPORTED", repr(e).split("\n")[0][:120])

if _app is not None:
    client = _app.app.test_client()

    # does index.html actually RENDER? (a Jinja error would 500)  -> proof the UI / tabs load
    try:
        r = client.get("/", follow_redirects=True)
        body = r.get_data(as_text=True)
        ok("index.html rendered (UI + tabs load)",
           r.status_code == 200 and ("<!doctype" in body.lower() or "<html" in body.lower()),
           detail_bad=f"HTTP {r.status_code}")
    except Exception as e:
        rec("FAIL", "index.html render CRASHED", repr(e).split("\n")[0][:120])

    # are static files served?
    for rel in ["/static/app.js", "/static/style.css", "/static/logo.png"]:
        try:
            r = client.get(rel)
            ok(f"served: {rel}", r.status_code == 200, detail_bad=f"HTTP {r.status_code}")
        except Exception as e:
            rec("FAIL", f"serve CRASHED {rel}", repr(e).split("\n")[0][:80])

    # Hit every PARAM-LESS + SAFE (read-only) GET route -> none may return 500.
    # (exclude slow/networked ones: claude status does subprocess+network; credit needs a param anyway.)
    _EXCLUDE = ("claude", "credit", "logout", "download", "reveal")
    _get_hit = 0
    _get_fail = 0
    for rule in _routes:
        path = str(rule.rule)
        if "<" in path:                       # parameterized (project etc.) -> skip
            continue
        if "GET" not in (rule.methods or set()):
            continue
        if path in ("/", "/static/<path:filename>"):
            continue
        if any(x in path for x in _EXCLUDE):
            continue
        try:
            r = client.get(path)
            _get_hit += 1
            if r.status_code >= 500:
                _get_fail += 1
                rec("FAIL", f"GET {path}", f"HTTP {r.status_code} (server error)")
        except Exception as e:
            _get_fail += 1
            rec("FAIL", f"GET {path} CRASHED", repr(e).split('\n')[0][:80])
    ok(f"param-less GET routes healthy ({_get_hit} routes, {_get_fail} failed)", _get_fail == 0)


# ================================================================================================
section("D) WIRING  (smoke_test.py: every tab/button maps to a backend route)")
# ================================================================================================
_smoke = HERE / "smoke_test.py"
if _smoke.exists():
    try:
        p = subprocess.run([sys.executable, str(_smoke)], capture_output=True, text=True, timeout=180)
        outtail = (p.stdout or "").strip().splitlines()
        passed = p.returncode == 0 and any("SMOKE TEST PASSED" in l for l in outtail)
        ok("smoke_test: every fetch URL -> real route; prompt/whitelist invariants intact", passed,
           detail_bad="smoke_test FAILED (details below):")
        if not passed:
            for l in outtail[-15:]:
                print("        " + l)
    except Exception as e:
        rec("WARN", "smoke_test did not run", repr(e).split("(")[0])
else:
    rec("WARN", "smoke_test.py missing", "wiring verification skipped")


# ================================================================================================
section("E) CONFIGURATION  (info / warning only)")
# ================================================================================================
if _app is not None:
    # KIE key (image + video generation depend on it)
    _kie = getattr(_app, "KIE_KEY", "")
    ok("KIE_API_KEY set (image/video generation)", bool(_kie), fail_level="WARN",
       detail_ok="(...%s)" % (_kie[-4:] if _kie else ""),
       detail_bad="no key -> enter it in Settings > Keys (can be done inside the app)")
    # Claude CLI login (all text/script AI runs on the user's Claude subscription)
    try:
        _exe = _app._claude_exe() if hasattr(_app, "_claude_exe") else None
        ok("Claude Code CLI installed (text/script AI)", bool(_exe), fail_level="WARN",
           detail_ok=str(_exe), detail_bad="claude not found -> set up via 'Connect Claude' inside the app")
    except Exception as e:
        rec("WARN", "Claude CLI query failed", repr(e).split("(")[0])


# ================================================================================================
# SUMMARY
# ================================================================================================
nf = sum(1 for l, _, _ in RESULTS if l == "FAIL")
nw = sum(1 for l, _, _ in RESULTS if l == "WARN")
npass = sum(1 for l, _, _ in RESULTS if l == "PASS")
print("\n" + "=" * 78)
print(f"  SUMMARY:  {npass} PASS   |   {nw} WARN   |   {nf} FAIL")
print("=" * 78)
if nf:
    print("\n  CRITICAL FAILURES (system won't fully work until these are fixed):")
    for l, name, detail in RESULTS:
        if l == "FAIL":
            print("   X  " + name + (("  -> " + detail) if detail else ""))
if nw:
    print("\n  WARNINGS (core works; only the related FEATURE is affected):")
    for l, name, detail in RESULTS:
        if l == "WARN":
            print("   !  " + name + (("  -> " + detail) if detail else ""))
if not nf:
    print("\n  >>> SYSTEM HEALTHY. Core + UI + all routes are working." +
          ("" if not nw else " (Features in the warnings above need their component/key.)"))
else:
    print("\n  >>> CRITICAL FAILURE. Fix the X items above.")
print()

# Machine-readable output: the /self-test route extracts this line and renders it in the modal.
if "--json" in sys.argv:
    print("##JSON## " + json.dumps({
        "ok": nf == 0,
        "summary": {"pass": npass, "warn": nw, "fail": nf},
        "results": [{"level": lvl, "name": nm, "detail": dt} for lvl, nm, dt in RESULTS],
    }, ensure_ascii=False))

sys.exit(1 if nf else 0)
