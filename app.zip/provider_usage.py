"""Read subscription quotas only: no inference, token refresh, or login changes.

Codex uses its supported local app-server account/rateLimits/read RPC and must
match the account selected in this Dashboard profile. Claude uses the existing
Claude Code account's read-only usage endpoint. Secrets never enter responses.
"""
from pathlib import Path
from datetime import datetime
import hashlib,json,math,os,queue,shutil,subprocess,threading,time
import requests
import codex_provider

_CACHE={}
_LOCK=threading.RLock()
_FETCH_LOCKS={}
_URLS={'codex':'https://chatgpt.com/settings/usage','claude':'https://claude.ai/settings/usage'}

def _window(label,used,reset,minutes):
    if isinstance(used,bool) or not isinstance(used,(int,float)) or not math.isfinite(used):return None
    if isinstance(reset,str):
        try:reset=datetime.fromisoformat(reset.replace('Z','+00:00')).timestamp()
        except ValueError:reset=None
    if isinstance(reset,bool) or not isinstance(reset,(int,float)) or not math.isfinite(reset):reset=None
    return dict(label=label,remaining=max(0,min(100,100-used)),used=max(0,min(100,used)),resets_at=reset,minutes=minutes)

def normalize_codex(data):
    if not isinstance(data,dict):return []
    groups=data.get('rateLimitsByLimitId') or {}
    if not isinstance(groups,dict):groups={}
    primary=groups.get('codex') or data.get('rateLimits') or {}
    if not isinstance(primary,dict):return []
    out=[]
    for name in ('primary','secondary'):
        row=primary.get(name) or {}
        if not isinstance(row,dict):continue
        mins=row.get('windowDurationMins')
        if not isinstance(mins,(int,float)) or isinstance(mins,bool):mins=None
        label={300:'5-hour session',1440:'Daily',10080:'Weekly'}.get(mins,'Usage window')
        item=_window(label,row.get('usedPercent'),row.get('resetsAt'),mins)
        if item:out.append(item)
    return out

def normalize_claude(data):
    if not isinstance(data,dict):return []
    out=[]
    for key,label,mins in [('five_hour','5-hour session',300),('seven_day','Weekly',10080),('seven_day_opus','Weekly · Opus',10080),('seven_day_sonnet','Weekly · Sonnet',10080)]:
        row=data.get(key) or {}
        if not isinstance(row,dict):continue
        item=_window(label,row.get('utilization'),row.get('resets_at'),mins)
        if item:out.append(item)
    return out

def _codex_exe():
    found=shutil.which('codex')
    if found:return found
    root=Path(os.environ.get('ProgramFiles','C:/Program Files'))/'WindowsApps'
    try:
        candidates=list(root.glob('OpenAI.Codex_*/app/resources/codex.exe'))
        return str(max(candidates,key=lambda p:p.stat().st_mtime)) if candidates else None
    except OSError:return None

def _codex_rpc(exe):
    p=subprocess.Popen([exe,'app-server','--stdio'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                       stderr=subprocess.DEVNULL,text=True,encoding='utf8',
                       creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    responses=queue.Queue();deadline=time.monotonic()+20
    def reader():
        try:
            for line in p.stdout:
                try:responses.put(json.loads(line))
                except ValueError:pass
        finally:responses.put(None)
    threading.Thread(target=reader,daemon=True).start()
    def call(i,method,params):
        p.stdin.write(json.dumps(dict(id=i,method=method,params=params))+'\n');p.stdin.flush()
        while True:
            answer=responses.get(timeout=max(.01,deadline-time.monotonic()))
            if answer is None:raise RuntimeError('Codex usage connection closed.')
            if answer.get('id')==i:
                if 'error' in answer:raise RuntimeError('Codex could not report account usage.')
                return answer.get('result') or {}
    try:
        call(1,'initialize',dict(clientInfo=dict(name='vsl_dashboard_usage',version='1.0')))
        account=call(2,'account/read',{}).get('account') or {}
        if account.get('type')!='chatgpt':raise RuntimeError('Sign in to the Codex desktop app with your ChatGPT account.')
        limits=call(3,'account/rateLimits/read',{})
        return account,limits
    finally:
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=3)
            except subprocess.TimeoutExpired:p.kill();p.wait(timeout=3)
        for stream in (p.stdin,p.stdout):
            try:stream.close()
            except OSError:pass

def _codex_identity(root):
    # DPAPI decryption is performed by the existing account vault; no tokens
    # are read from the Codex CLI or copied between applications.
    state=codex_provider.service(root).vault.read()
    selected=state.get('accounts',{}).get(state.get('active'),{})
    if not selected.get('connected'):raise RuntimeError('Connect Codex in Settings → AI Provider.')
    return state.get('active'),selected.get('email') or ''

def _claude_credentials():
    return Path(os.environ.get('CLAUDE_CONFIG_DIR') or Path.home()/'.claude')/'.credentials.json'

def _fetch(provider,root,identity):
    if provider=='codex':
        exe=_codex_exe()
        if not exe:raise RuntimeError('Install or open Codex on this computer to read its usage limits.')
        account,limits=_codex_rpc(exe)
        if not identity[1] or account.get('email','').casefold()!=identity[1].casefold():
            raise RuntimeError('Codex desktop is signed in to a different account. Select the same account as AI Provider.')
        return normalize_codex(limits),'Connected ChatGPT account'
    try:record=json.loads(_claude_credentials().read_text('utf8')).get('claudeAiOauth') or {}
    except (OSError,ValueError):raise RuntimeError('Sign in to Claude Code on this computer.') from None
    token=record.get('accessToken')
    if not isinstance(token,str) or not token:raise RuntimeError('Sign in to Claude Code on this computer.')
    with requests.get('https://api.anthropic.com/api/oauth/usage',
            headers={'Authorization':'Bearer '+token,'anthropic-beta':'oauth-2025-04-20','User-Agent':'VSLDashboard/usage'},
            timeout=(6,10),allow_redirects=False) as response:
        if response.status_code in (401,403):raise RuntimeError('Open Claude Code and check your sign-in, then refresh usage.')
        if response.status_code==429:raise RuntimeError('Claude usage checks are temporarily limited. Try again shortly.')
        if response.status_code!=200:raise RuntimeError('Claude could not report usage. Try again shortly.')
        data=response.json()
    return normalize_claude(data),'Claude Code account on this computer'

def read(provider,root):
    if provider not in _URLS:raise ValueError('Unknown provider')
    result=dict(provider=provider,windows=[],usage_url=_URLS[provider],checked_at=time.time(),available=False)
    try:
        if provider=='codex':identity=_codex_identity(root)
        else:
            path=_claude_credentials();stat=path.stat()
            identity=(str(path),stat.st_mtime_ns,stat.st_size)
        key=(provider,str(Path(root).resolve()),hashlib.sha256(repr(identity).encode()).hexdigest())
        with _LOCK:lock=_FETCH_LOCKS.setdefault(key,threading.Lock())
        with lock:
            with _LOCK:cached=_CACHE.get(key)
            if cached and time.time()-cached['checked_at']<45:return dict(cached)
            windows,account=_fetch(provider,root,identity)
            result.update(windows=windows,account=account,available=bool(windows))
            if not windows:result['message']='Usage limits are not reported for this account.'
            elif not any(w['minutes'] in (300,1440) for w in windows):result['message']='A separate daily or session limit is not reported for this account.'
            with _LOCK:
                if len(_CACHE)>32:_CACHE.clear();_FETCH_LOCKS.clear()
                _CACHE[key]=dict(result)
    except (requests.RequestException,queue.Empty,subprocess.SubprocessError,OSError,ValueError):
        result['message']='Usage is temporarily unavailable. Refresh or check the provider’s usage page.'
    except RuntimeError as error:result['message']=str(error)
    return result
