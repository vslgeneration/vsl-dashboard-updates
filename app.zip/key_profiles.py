"""Account-local credential profiles and explicit per-visit Studio billing selection."""
import copy,hashlib,json,os,re,tempfile,threading,uuid
from pathlib import Path
from flask import request,session,has_request_context,jsonify

FIELDS={'cloud_name':'CLOUDINARY_CLOUD_NAME','cloud_key':'CLOUDINARY_API_KEY','cloud_secret':'CLOUDINARY_API_SECRET','kie':'KIE_API_KEY','elevenlabs':'ELEVENLABS_API_KEY','wavespeed':'WAVESPEED_API_KEY'}
LOCK=threading.RLock()
SELECTIONS={}
HEADER='X-VSL-Studio-Visit'

def read(root):
 p=Path(root)/'key-profiles.json'
 if not p.exists():return {'version':1,'profiles':[]}
 value=json.loads(p.read_text('utf8'))
 if not isinstance(value,dict) or value.get('version')!=1 or not isinstance(value.get('profiles'),list):raise ValueError('The saved key profile list is unreadable.')
 return value

def write(root,value):
 root=Path(root);root.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix='.key-profiles-',dir=root)
 try:
  with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
  os.replace(tmp,root/'key-profiles.json')
 finally:Path(tmp).unlink(missing_ok=True)

def public(row):return {'id':row['id'],'name':row['name'],'revision':row.get('revision',0)}

def validate_name(name):
 if not isinstance(name,str) or not name.strip() or len(name.strip())>80:raise ValueError('Enter a profile name of 1–80 characters.')
 return name.strip()

def validate_keys(keys,base=None):
 if not isinstance(keys,dict) or any(not isinstance(v,str) for k,v in keys.items() if k in FIELDS.values()):raise ValueError('Invalid key values.')
 values={k:keys.get(k,(base or {}).get(k,'')).strip() for k in FIELDS.values()}
 if not any(values.values()):raise ValueError('Enter at least one key before saving a profile.')
 if any(len(v)>8192 for v in values.values()):raise ValueError('A key value is too long.')
 return values

def create(root,name,keys):
 name=validate_name(name);keys=validate_keys(keys)
 with LOCK:
  store=read(root)
  if any(p['name'].casefold()==name.casefold() for p in store['profiles']):raise ValueError('That name is already saved. Select that profile to update it, or choose a different name.')
  row=dict(id=uuid.uuid4().hex,name=name,keys=keys,revision=1);store['profiles'].append(row);write(root,store)
  return public(row)

def update(root,pid,keys,expected_revision):
 with LOCK:
  row=get(root,pid)
  if type(expected_revision) is not int or expected_revision!=row.get('revision',0):
   raise ValueError('This profile changed since it was loaded. Select it again before saving.')
  row['keys']=validate_keys(keys,row['keys']);row['revision']=row.get('revision',0)+1
  store=read(root)
  store['profiles']=[row if p['id']==pid else p for p in store['profiles']]
  write(root,store)
  return public(row)

def get(root,pid):
 if not isinstance(pid,str) or not re.fullmatch(r'[a-f0-9]{32}',pid):raise ValueError('Choose a saved key profile.')
 with LOCK:
  row=next((p for p in read(root)['profiles'] if p['id']==pid),None)
  if not row:raise ValueError('That key profile is unavailable.')
  return copy.deepcopy(row)

def profile_for_keys(root,pid,keys):
 if not pid:return ''
 row=get(root,pid)
 return pid if all(row['keys'].get(n,'')==keys.get(n,'') for n in FIELDS.values()) else ''


# Display-only migration for the already-transferred owner profile. No keys are
# copied into an account profile and no credential is replaced on the recipient.
_PORTABLE_NAMES = {'0bf9b10efd7f85b9c7bdcfddd75b6f30d7477ca3cb77da9ccc664eb0d4055bd8': 'Baran'}

def portable_profile(root, keys):
 pid=keys.get('_KEY_PROFILE_ID','')
 if not isinstance(pid,str) or not re.fullmatch(r'[a-f0-9]{32}',pid):return None
 if not any(keys.get(k) for k in FIELDS.values()):return None
 if any(p.get('id')==pid for p in read(root)['profiles']):return None
 name=keys.get('_KEY_PROFILE_NAME') or _PORTABLE_NAMES.get(hashlib.sha256(pid.encode()).hexdigest())
 if not isinstance(name,str) or not name.strip() or len(name)>80:return None
 return dict(id=pid,name=name.strip())

def global_request():
 if not has_request_context():return False
 args=request.view_args or {};p=args.get('project')
 if p is not None:return p in ('_global','_studio','_subtitle_video')
 if not request.path.startswith(('/api/studio/','/api/faq/','/api/upsell/')):return False
 body=request.get_json(silent=True) if request.is_json else request.form
 scope=args.get('scope') or (body or {}).get('scope') or '_global'
 return str(scope).split('::')[0]=='_global'

def selection(ns):
 if not has_request_context():return None
 token=request.headers.get(HEADER,'');owner=str(ns['PROJECTS'].parent.resolve())
 with LOCK:
  item=SELECTIONS.get((owner,token))
  return copy.deepcopy(item) if item else None

def require_selection(ns):
 if global_request() and not selection(ns):
  return jsonify(error='Choose the customer/company keys for this Studio visit.',code='studio_key_selection_required'),428
 return None

def register(app,ns):
 root=lambda:ns['PROJECTS'].parent
 @app.get('/api/key-profiles')
 def key_profiles_list():
  try:return jsonify(profiles=[public(p) for p in read(root())['profiles']])
  except (OSError,ValueError):return jsonify(error='Could not read saved key profiles.'),500
 @app.post('/api/key-profiles')
 def key_profiles_create():
  b=request.get_json(silent=True) or {}
  try:
   if not isinstance(b,dict):raise ValueError('Invalid key profile.')
   raw=b.get('keys') or {}
   if not isinstance(raw,dict):raise ValueError('Invalid key values.')
   return jsonify(profile=create(root(),b.get('name'),{env:raw.get(ui,'') for ui,env in FIELDS.items()})),201
  except ValueError as e:return jsonify(error=str(e)),409
  except OSError:return jsonify(error='Could not save the key profile. Existing profiles were kept.'),500
 @app.get('/api/key-profiles/<pid>')
 def key_profiles_get(pid):
  try:
   row=get(root(),pid);return jsonify(profile=public(row),keys={ui:row['keys'].get(env,'') for ui,env in FIELDS.items()})
  except ValueError as e:return jsonify(error=str(e)),404
 @app.put('/api/key-profiles/<pid>')
 def key_profiles_update(pid):
  b=request.get_json(silent=True) or {}
  try:
   if not isinstance(b,dict) or not isinstance(b.get('keys'),dict):raise ValueError('Invalid key values.')
   raw=b['keys']
   return jsonify(profile=update(root(),pid,{env:raw[ui] for ui,env in FIELDS.items() if ui in raw},b.get('revision')))
  except ValueError as e:return jsonify(error=str(e)),409
  except OSError:return jsonify(error='Could not save the key profile. Existing profiles were kept.'),500
 @app.route('/api/studio-key-selection',methods=['GET','POST','DELETE'])
 def studio_key_selection():
  token=request.headers.get(HEADER,'')
  if not re.fullmatch(r'[a-f0-9-]{32,36}',token):return jsonify(error='Open Studio again before choosing keys.'),400
  owner=str(root().resolve());key=(owner,token)
  with LOCK:
   if request.method=='GET':
    item=SELECTIONS.get(key)
    if not item:return jsonify(profile=None)
    return jsonify(profile=copy.deepcopy(item['profile']),keys={ui:item['keys'].get(env,'') for ui,env in FIELDS.items()})
   if request.method=='DELETE':SELECTIONS.pop(key,None);return jsonify(ok=True)
   try:row=get(root(),(request.get_json(silent=True) or {}).get('profile_id'))
   except ValueError as e:return jsonify(error=str(e)),400
   SELECTIONS[key]=dict(profile=public(row),keys=row['keys'])
  return jsonify(ok=True,profile=public(row))
 @app.before_request
 def studio_paid_selection_guard():
  if not session.get('user') or request.method!='POST' or not global_request():return
  endpoint=request.endpoint
  paid={'api_studio_generate','api_studio_mockup','api_studio_edit','api_studio_video','api_ud_voiceover','api_tv_gen_image','api_tv_voiceover','api_tv_gen_video','api_generate_tperson','api_edit_tperson_candidate','api_generate_character','api_edit_char_candidate','api_generate_ingredient','api_edit_ingredient_candidate','api_voiceover','api_edit_image'}
  if endpoint in paid:return require_selection(ns)
  body=request.get_json(silent=True) or {}
  if endpoint in ('loc_start','loc_resume'):
   if endpoint=='loc_resume' or body.get('kind')=='localise':return require_selection(ns)
  if ns.get('TEXT_PROVIDER')=='kie' and endpoint in ('loc_start','loc_resume','loc_prepare','loc_import_project','api_faq_keywords','api_faq_build','api_studio_thumbidea','api_subtitle_run','subtitle_studio_generate','subtitle_studio_scan_ost','api_prompt_english','api_prompt_clean_dictation'):
   return require_selection(ns)
