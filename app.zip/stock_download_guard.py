"""A per-request Claude hook: exactly one call for exactly the user's selected stock item."""
import json
import os
from pathlib import Path
import sys


def decide(directory, event):
    root = Path(directory)
    try:
        expected = json.loads((root / "expected.json").read_text(encoding="utf-8"))
        if event.get("tool_name") != expected["tool"] or event.get("tool_input") != expected["input"]:
            return False
        # x mode also rejects two parallel calls. Never release this claim for this request.
        with (root / "called.json").open("x", encoding="utf-8") as f:
            json.dump({"tool_use_id": event.get("tool_use_id"), "input": expected["input"]}, f)
            f.flush(); os.fsync(f.fileno())
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def main():
    try:
        allowed = decide(sys.argv[1], json.loads(sys.stdin.read()))
    except Exception:
        allowed = False
    print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse",
        "permissionDecision": "allow" if allowed else "deny",
        "permissionDecisionReason": "One call for the selected stock item." if allowed else "This request permits only one call for the selected item. Do not retry."}}))


if __name__ == "__main__":
    main()
