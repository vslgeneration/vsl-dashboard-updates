"""Publish an app update so every copied PC auto-updates on next launch.

What it does (run on the MAIN dev PC):
  1. bumps dashboard/version.txt (or use --version X)
  2. zips the app/ CODE (app.py, desktop.py, render_video.py, premiere_export.py, static/,
     templates/, voices.json, version.txt, update.json, vsllogo.*) into app.zip
     — NOT Background Music/, projects/, .env, auth.json (those aren't shipped in updates)
  3. copies app.zip + version.txt into a local clone of the update repo and git-push-es them

The repo comes from dashboard/update.json ({"repo": "user/name", "enabled": true}).
First push opens a browser once (Git Credential Manager) — after that it's non-interactive.

Note: covers app/ code (the usual case). Changes to runtime/, ffmpeg/, cache/ or subtitle/ still
need a one-time full folder copy.
"""
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

DASH = Path(__file__).resolve().parent
REPO_CLONE = DASH.parent / "update-repo"          # local working clone of the GitHub update repo

FILES = ["app.py", "desktop.py", "render_video.py", "caption_layer.py", "parallax.py", "youtube.py", "premiere_export.py", "suno_music.py",
         "inpaint.py", "self_test.py", "smoke_test.py", "prompts.py", "assets.py", "ai_baran.py",
         "undefined_names.py", "quietlog.py",
         "voices.json", "version.txt", "update.json", "changelog.json", "vsllogo.png", "vsllogo.ico",
         "Create Desktop Icon.vbs"]
DIRS = ["static", "templates"]
# The aligner scripts live one level ABOVE the dashboard, but they have to travel with the app: without
# them another PC pulls a new app.py and keeps running whatever aligner it had, which is how a machine
# ends up silently a release behind on subtitle timing. The zip extracts into app/, so they ship as
# app/subtitle/ and app.py prefers that copy over the old side-by-side one (see _subtitle_tools_dir).
EXTRA_DIRS = [(DASH.parent / "subtitle", "subtitle")]


def _load_repo():
    cfg = json.loads((DASH / "update.json").read_text(encoding="utf-8"))
    repo = (cfg.get("repo") or "").strip()
    if not repo:
        sys.exit("update.json has no 'repo' yet — set it to \"user/reponame\" first.")
    return repo


def _bump(explicit=None):
    vf = DASH / "version.txt"
    cur = vf.read_text(encoding="utf-8").strip() if vf.exists() else "0"
    new = explicit or str(int(cur) + 1)
    vf.write_text(new, encoding="utf-8")
    return new


def _read_notes(argv):
    """--notes "sentence one" "sentence two" ...  → the list of sentences (until the next --flag)."""
    if "--notes" not in argv:
        return None
    out = []
    i = argv.index("--notes") + 1
    while i < len(argv) and not argv[i].startswith("--"):
        s = argv[i].strip()
        if s:
            out.append(s)
        i += 1
    return out or None


def _write_changelog(version, notes):
    """Record this version's change notes so the other PCs show them right after they update."""
    cf = DASH / "changelog.json"
    data = {}
    if cf.exists():
        try:
            data = json.loads(cf.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data[str(version)] = notes
    # Only the last 200 versions travel with the app; the full history is in git. The file had
    # reached 634 entries and 315 KB, all shipped in every update.
    keep = sorted(data, key=lambda k: int(k) if str(k).isdigit() else -1)[-200:]
    data = {k: data[k] for k in keep}
    cf.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _make_zip(dst):
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for f in FILES:
            p = DASH / f
            if p.exists():
                z.write(p, f)
        for d in DIRS:
            base = DASH / d
            for root, _dirs, files in os.walk(base):
                if "__pycache__" in root:
                    continue
                for fn in files:
                    fp = Path(root) / fn
                    z.write(fp, str(fp.relative_to(DASH)))
        for src, arc in EXTRA_DIRS:
            for root, _dirs, files in os.walk(src):
                if "__pycache__" in root:
                    continue
                for fn in files:
                    if fn.endswith((".bak", ".pyc")):
                        continue
                    fp = Path(root) / fn
                    z.write(fp, str(Path(arc) / fp.relative_to(src)))


def _git(*args):
    subprocess.run(["git", "-C", str(REPO_CLONE), *args], check=True)


def _run_smoke():
    """Gate: never ship a broken build to the other PCs. Runs the fast, network-free smoke test and
    aborts the publish on failure. Bypass only in a real emergency with --skip-smoke."""
    smoke = DASH / "smoke_test.py"
    if not smoke.exists():
        print("WARNING: smoke_test.py missing — skipping pre-publish checks.")
        return
    print("running pre-publish smoke test…")
    r = subprocess.run([sys.executable, str(smoke)])
    if r.returncode != 0:
        sys.exit("PUBLISH ABORTED: smoke test failed (see above). Fix it, or bypass with --skip-smoke.")
    print("smoke test passed — proceeding.\n")


def main():
    explicit = None
    if "--version" in sys.argv:
        explicit = sys.argv[sys.argv.index("--version") + 1]
    if "--skip-smoke" not in sys.argv:
        _run_smoke()
    repo = _load_repo()

    if not REPO_CLONE.exists():
        print(f"cloning https://github.com/{repo}.git -> {REPO_CLONE}")
        subprocess.run(["git", "clone", f"https://github.com/{repo}.git", str(REPO_CLONE)], check=True)

    new = _bump(explicit)
    print("new version:", new)
    notes = _read_notes(sys.argv)
    if notes:
        _write_changelog(new, notes)
        print(f"changelog v{new}:")
        for s in notes:
            print("   -", s)
    else:
        print("NOTE: no --notes given, this update will show no 'what's new' list. "
              'Add e.g.  --notes "Yeni buton eklendi." "Ses hatasi duzeltildi."')
    _make_zip(REPO_CLONE / "app.zip")
    import hashlib
    digest = hashlib.sha256((REPO_CLONE / "app.zip").read_bytes()).hexdigest()
    (REPO_CLONE / "app.zip.sha256").write_text(digest + "  app.zip\n", encoding="utf-8")
    (REPO_CLONE / "version.txt").write_text(new, encoding="utf-8")

    _git("add", "app.zip", "app.zip.sha256", "version.txt")
    _git("commit", "-m", f"update to v{new}")
    _git("push")
    print(f"published v{new} to {repo}. Other PCs update on next launch.")


if __name__ == "__main__":
    main()
