"""Scene-local, content-addressed final-preview pieces from the production renderer.

Complete scene neighborhoods preserve source speed, camera phase and transitions.
Only the small neighborhood is decoded; the finished cores concatenate losslessly.
Audio has one independent continuous master, so chunk boundaries have no AAC seams.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import os
import subprocess
import uuid

VERSION = 'preview-chunks-1000-1'
FPS = 60
CODE = ('preview_chunks.py','final_preview.py','render_video.py','premiere_export.py',
        'caption_layer.py','project_canvas.py','media_delivery.py','effect_timing.py',
        'icon_geometry.py','icon_motion.py','ost_rich.py','static/ost-rich.js','static/subtitle_motion.js',
        'static/style.css')
VIDEO_OPTIONS = ('kenburns','kenburns_video','crossfade','transitions','burnsubs',
                 'onscreentext','outro_fade','final_preview','fast','_live_overlay_base')
AUDIO_OPTIONS = ('music','transitions','outro_fade','vo_gain_db')

def frame(value):
    return int(float(value)*FPS+.5+1e-9)

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,default=str,
                                     separators=(',',':')).encode('utf8')).hexdigest()

def _file(path):
    p=Path(path)
    try:
        s=p.stat()
        return [str(p.resolve()),s.st_size,s.st_mtime_ns] if p.is_file() else None
    except (OSError,ValueError): return None

def _files(value):
    out={}
    def visit(v):
        if isinstance(v,dict):
            for item in v.values(): visit(item)
        elif isinstance(v,(tuple,list)):
            for item in v: visit(item)
        elif isinstance(v,(str,Path)) and len(str(v))<512:
            try:
                if Path(v).is_absolute():
                    got=_file(v)
                    if got:out[got[0]]=got[1:]
            except (OSError,ValueError):pass
    visit(value)
    return out

def _renderer_files(runtime):
    return [_file(Path(runtime)/name) for name in CODE]

def _visual_assets(timeline,runtime):
    """Selected media/art only; an unused library asset cannot invalidate a core."""
    import premiere_export as pe
    root=Path(runtime);out=_files(timeline)
    paths=[]
    for scene in timeline.get('scenes',[]):
        for icon in scene.get('icons') or []:
            kind=(icon.get('type') or icon.get('icon') or '').lower()
            if kind in pe._VFX: paths.append(root/'Icons'/pe._VFX[kind][1])
            elif pe.is_logo(kind):
                paths.extend(root/'static/logos'/('icon_'+kind+tail+'.png') for tail in ('','_art_v1'))
            else:
                name='ring' if kind=='burst' else 'arrow_flip' if kind=='arrow' and icon.get('flip') else kind
                paths.append(root/'Icons'/('icon_'+name+'.png'))
    for event in timeline.get('_user_transition_events',[]):
        spec=pe._UTX.get(event['key']) or {}
        if spec.get('file'): paths.append(root/'Transitions'/spec['file'])
    # Font changes can alter glyph geometry; only text-bearing chunks depend on fonts.
    if timeline.get('captions') or any(s.get('texts') for s in timeline.get('scenes',[])):
        paths.extend((root/'static/fonts').glob('*'))
    for path in paths:
        got=_file(path)
        if got:out[got[0]]=got[1:]
    return out

def _camera_indices(scenes):
    """Indices after the renderer's speaker joining, including real black gaps."""
    import render_video as rv
    raw=[];cursor=0
    for n,sc in enumerate(scenes):
        start,end=frame(sc['start']),frame(sc['end'])
        if start>cursor:raw.append(dict(kind='black',src=None,dur=(start-cursor)/FPS,trans='none'))
        cursor=end
        if end<=start:continue
        kind=sc.get('kind') if sc.get('path') else 'black'
        raw.append(dict(kind=kind,src=sc.get('path'),dur=(end-start)/FPS,
                        trans=sc.get('transition') or 'none',speaker_clip=sc.get('speaker_clip'),
                        framing=sc.get('framing'),no_zoom=bool(sc.get('no_zoom')) or sc.get('framing') is not None,
                        _scene=n))
    return {s['_scene']:i for i,s in enumerate(rv._join_speaker_segments(raw)) if '_scene' in s}

def _speaker_runs(scenes):
    """Native continuous takes are atomic: restarting FPS midway changes cadence."""
    import render_video as rv
    def proxy(sc):
        return dict(kind=sc.get('kind'),src=sc.get('path'),speaker_clip=sc.get('speaker_clip'),
                    framing=sc.get('framing'),no_zoom=bool(sc.get('no_zoom')) or sc.get('framing') is not None,
                    trans=sc.get('transition') or 'none',dur=(frame(sc['end'])-frame(sc['start']))/FPS)
    runs=[];first=0
    for i in range(1,len(scenes)):
        left,right=scenes[i-1],scenes[i]
        joined=(frame(left['end'])==frame(right['start']) and
                len(rv._join_speaker_segments([proxy(left),proxy(right)]))==1)
        if not joined:
            if i-first>1:runs.append((first,i-1))
            first=i
    if len(scenes)-first>1:runs.append((first,len(scenes)-1))
    return runs

def _shift_event(event,origin):
    out=deepcopy(event)
    for key in ('start','end','peak','hold_until','base_start','base_end'):
        if isinstance(out.get(key),(int,float)):out[key]=round(float(out[key])-origin,9)
    for word in out.get('words') or []:
        if isinstance(word,dict):
            for key in ('start','end'):
                if isinstance(word.get(key),(int,float)):word[key]=round(float(word[key])-origin,9)
    return out

def plan(timeline,options=None,target_seconds=30):
    """Return complete scene-local timelines and frame-exact output core ranges."""
    import premiere_export as pe
    opts=options or {};scenes=timeline.get('scenes') or [];total=frame(timeline['total'])
    if not scenes or total<=0:raise ValueError('Nothing to preview.')
    runs=_speaker_runs(scenes)
    internal={frame(scenes[i]['end']) for lo,hi in runs for i in range(lo,hi)}
    edges=sorted({0,total,*[frame(s['end']) for s in scenes if 0<frame(s['end'])<total and frame(s['end']) not in internal]})
    cores=[];start=0;target=max(FPS,frame(target_seconds))
    for end in edges[1:]:
        if end-start>=target or end==total:cores.append((start,end));start=end
    seeds=_camera_indices(scenes)
    dips=pe.dip_windows(scenes,total/FPS) if opts.get('transitions',True) and not opts.get('_live_overlay_base') else []
    user=[]
    if opts.get('transitions',True) and not opts.get('_live_overlay_base'):
        for scene in scenes[:-1]:
            window=pe.transition_window(scene.get('transition'),scene['end'],total/FPS)
            if window:user.append(dict(key=scene['transition'],cut=scene['end'],start=window[0],end=window[1]))
    events={
        'captions':(timeline.get('captions') or []) if opts.get('burnsubs',True) else [],
        'visuals':timeline.get('visuals') or [],
        'ost_plates':(timeline.get('ost_plates') or []) if opts.get('onscreentext',True) else [],
        '_dip_windows':dips,'_user_transition_events':user}
    result=[]
    for number,(a,b) in enumerate(cores):
        touching=[i for i,s in enumerate(scenes) if frame(s['end'])>a and frame(s['start'])<b]
        if touching:
            lo=max(0,min(touching)-1);hi=min(len(scenes)-1,max(touching)+1)
            ca=min(a,frame(scenes[lo]['start']));cb=max(b,frame(scenes[hi]['end']))
        else:ca,cb=a,b
        selected={k:[e for e in value if frame(e['end'])>a and frame(e['start'])<b] for k,value in events.items()}
        # Include a crossing event from its own first frame: never restart its
        # animated text, loop, fade, or hold phase at an arbitrary chunk boundary.
        # Captions need their authored animation clock, and custom transitions
        # need both complete neighbors. Long looping effects/plates carry an
        # explicit elapsed phase instead of pulling in unrelated earlier scenes.
        for kind,values in selected.items():
            if kind in ('visuals','ost_plates'):continue
            for e in values:ca=min(ca,frame(e['start']));cb=max(cb,frame(e['end']))
        for lo,hi in runs:
            left,right=frame(scenes[lo]['start']),frame(scenes[hi]['end'])
            if right>ca and left<cb:ca=min(ca,left);cb=max(cb,right)
        selected_scenes=[(i,s) for i,s in enumerate(scenes) if frame(s['end'])>ca and frame(s['start'])<cb]
        if selected_scenes:
            ca=min(ca,frame(selected_scenes[0][1]['start']));cb=max(cb,frame(selected_scenes[-1][1]['end']))
        ca=max(0,ca);cb=min(total,cb);origin=ca/FPS
        local={k:deepcopy(v) for k,v in timeline.items() if k not in
               ('scenes','captions','visuals','ost_plates','vo','voiceover','music','sfx','transition_sfx','total','music_revision','music_catalog','media_notes')}
        local.update(total=(cb-ca)/FPS,_timeline_origin=origin,_full_total=total/FPS,scenes=[])
        for i,scene in selected_scenes:
            s=_shift_event(scene,origin);s['_camera_index']=seeds.get(i,i)
            native=scene.get('editorial_timing') or {}
            narration=scene.get('narration_origin',native.get('start_frame',0)/native.get('fps',60) if native else scene['start'])
            s['narration_origin']=narration-origin
            if not opts.get('onscreentext',True):s['texts']=[]
            local['scenes'].append(s)
        for k,values in selected.items():
            local[k]=[_shift_event(e,origin) for e in values]
            if k=='_user_transition_events':
                for e in local[k]:e['cut']=round(e['cut']-origin,9)
        result.append(dict(index=number,start_frame=a,end_frame=b,context_start_frame=ca,
                           context_end_frame=cb,range=[(a-ca)/FPS,(b-ca)/FPS],timeline=local))
    return result

def video_key(chunk,options,runtime):
    local=deepcopy(chunk['timeline']);full=local.pop('_full_total');origin=local.pop('_timeline_origin')
    # Program length matters only where its closing fade actually affects the core.
    outro=0 if options.get('_live_overlay_base') else float(options.get('outro_fade') or 0)
    local['_outro_at']=(full-outro-origin) if outro>.05 and full>outro+1 and chunk['end_frame']/FPS>full-outro else None
    return digest((VERSION,'video',local,chunk['range'],
                   {k:(0 if k=='outro_fade' and options.get('_live_overlay_base') else options[k]) for k in VIDEO_OPTIONS if k in options},
                   _visual_assets(local,runtime),_renderer_files(runtime)))

def audio_key(timeline,options,runtime):
    data={k:timeline.get(k) for k in ('vo','total','music','sfx','transition_sfx','youtube')}
    from editorial_policy import delivery_sfx
    data['sfx']=delivery_sfx(data.get('sfx'),options)
    if not options.get('music',True):data['music']=[]
    if not options.get('transitions',True):data['transition_sfx']=[]
    return digest((VERSION,'audio',data,{k:options[k] for k in AUDIO_OPTIONS if k in options},
                   _files(data),[_file(Path(runtime)/name) for name in ('preview_chunks.py','render_video.py','premiere_export.py')]))

def _ready(path,key):
    p=Path(path)
    try:
        meta=json.loads(p.with_suffix(p.suffix+'.json').read_text('utf8'));s=p.stat()
        return meta.get('version')==VERSION and meta.get('key')==key and s.st_size>0 and meta.get('size')==s.st_size and meta.get('mtime_ns')==s.st_mtime_ns
    except (OSError,ValueError,TypeError):return False

def _commit(path,key):
    p=Path(path);s=p.stat()
    if not s.st_size:raise RuntimeError('Empty preview cache output.')
    data=dict(version=VERSION,key=key,size=s.st_size,mtime_ns=s.st_mtime_ns)
    dest=p.with_suffix(p.suffix+'.json');tmp=p.parent/('m-'+uuid.uuid4().hex[:12]+'.tmp')
    tmp.write_text(json.dumps(data,sort_keys=True),'utf8');os.replace(tmp,dest)

def _retain(root,video_keys,audio_id):
    """Keep the last three successful build inventories; never touch pending/user files."""
    root=Path(root);keys=[*video_keys,audio_id];name='h-'+digest(keys)[:24]+'.json'
    inventory=dict(version=VERSION,keys=keys)
    temp=root/('m-'+uuid.uuid4().hex[:12]+'.tmp');temp.write_text(json.dumps(inventory),'utf8')
    os.replace(temp,root/name)
    histories=[]
    for p in root.glob('h-*.json'):
        try:
            value=json.loads(p.read_text('utf8'))
            if value.get('version')==VERSION and p.name=='h-'+digest(value['keys'])[:24]+'.json':histories.append((p,value))
        except (OSError,ValueError,TypeError,KeyError):pass
    histories.sort(key=lambda item:item[0].stat().st_mtime_ns,reverse=True)
    keep={k for _,value in histories[:3] for k in value['keys']}
    for p,value in histories[3:]:
        try:p.unlink()
        except OSError:pass
    for meta in root.glob('*.*.json'):
        try:
            value=json.loads(meta.read_text('utf8'));key=value.get('key');asset=Path(str(meta)[:-5])
            if not isinstance(key,str) or key in keep or value.get('version')!=VERSION:continue
            expected=('v-'+key[:24]+'.mp4','a-'+key[:24]+'.m4a')
            if asset.name not in expected or not _ready(asset,key):continue
            asset.unlink();meta.unlink()
        except (OSError,ValueError,TypeError):pass

def _run_mux(parts,audio,target,workdir,total,on_proc,should_cancel):
    wd=Path(workdir);wd.mkdir(parents=True,exist_ok=True)
    concat=wd/'concat.txt'
    def quote(path):return str(Path(path).resolve()).replace('\\','/').replace("'","'\\''")
    concat.write_text(''.join("file '"+quote(p)+"'\n" for p in parts),'utf8')
    cmd=['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(concat),'-i',str(audio),
         '-map','0:v:0','-map','1:a:0','-c','copy','-t',f'{total:.9f}','-movflags','+faststart',str(target)]
    log=wd/'mux.log'
    if should_cancel and should_cancel():raise RuntimeError('cancelled')
    with log.open('w',encoding='utf8') as err:
        proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if on_proc:on_proc(proc)
        while proc.poll() is None:
            if should_cancel and should_cancel():proc.terminate()
            try:proc.wait(timeout=.1)
            except subprocess.TimeoutExpired:pass
    if should_cancel and should_cancel():raise RuntimeError('cancelled')
    if proc.returncode:raise RuntimeError('Preview assembly failed: '+log.read_text('utf8',errors='replace')[-1000:])

def render(timeline,out_path,workdir,options=None,progress=None,on_proc=None,on_status=None,should_cancel=None):
    import render_video
    opts=dict(options or {});opts.pop('range',None)
    root=Path(workdir)/'pcache';root.mkdir(parents=True,exist_ok=True)
    runtime=Path(__file__).parent
    chunks=plan(timeline,opts);keys=[video_key(c,opts,runtime) for c in chunks]
    audio_id=audio_key(timeline,opts,runtime);audio=root/('a-'+audio_id[:24]+'.m4a')
    stats=dict(version=VERSION,video_total=len(chunks),video_rendered=0,video_reused=0,audio_reused=_ready(audio,audio_id),chunks=[])
    paths=[]
    def cancelled():
        if should_cancel and should_cancel():raise RuntimeError('cancelled')
    for c,key in zip(chunks,keys):
        cancelled();target=root/('v-'+key[:24]+'.mp4');ready=_ready(target,key)
        if on_status:on_status(f"{'Reusing' if ready else 'Rendering'} preview section {c['index']+1}/{len(chunks)}…")
        if not ready:
            pending=root/('p-'+uuid.uuid4().hex[:12]+'.mp4')
            try:
                def part_progress(pct,done):
                    if progress:progress(int((c['index']+pct/100)/len(chunks)*90),done)
                render_video.render(c['timeline'],pending,workdir,
                    {**opts,'_video_only':True,'range':c['range']},part_progress,on_proc,on_status,should_cancel)
                cancelled();os.replace(pending,target);_commit(target,key)
            finally:pending.unlink(missing_ok=True)
        stats['video_reused' if ready else 'video_rendered']+=1;paths.append(target)
        stats['chunks'].append({k:v for k,v in c.items() if k!='timeline'}|dict(key=key,reused=ready))
    cancelled()
    if not stats['audio_reused']:
        if on_status:on_status('Preparing continuous preview audio…')
        pending=root/('p-'+uuid.uuid4().hex[:12]+'.m4a')
        try:
            render_video.render_audio(timeline,pending,workdir,opts,None,on_proc,on_status,should_cancel)
            cancelled();os.replace(pending,audio);_commit(audio,audio_id)
        finally:pending.unlink(missing_ok=True)
    if on_status:on_status('Assembling preview…')
    _run_mux(paths,audio,out_path,workdir,frame(timeline['total'])/FPS,on_proc,should_cancel)
    cancelled()
    stats['audio_key']=audio_id
    (Path(workdir)/'preview-cache-results.json').write_text(json.dumps(stats,indent=2),'utf8')
    _retain(root,keys,audio_id)
    if progress:progress(100,float(timeline['total']))
    return Path(out_path)
