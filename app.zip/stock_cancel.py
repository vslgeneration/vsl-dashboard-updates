"""Cancellation scoped to one stock-search thread, never to other model/render jobs."""
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

_local=threading.local()

class Cancelled(BaseException):
    # Provider/JSON retry handlers catch Exception. Cancellation must bypass those retries.
    pass

@contextlib.contextmanager
def scope(event):
    previous=getattr(_local,'event',None);_local.event=event
    try:yield
    finally:_local.event=previous

def active():return getattr(_local,'event',None) is not None

def check():
    event=getattr(_local,'event',None)
    if event is not None and event.is_set():raise Cancelled()

def _terminate(proc):
    if proc.poll() is not None:return
    if os.name=='nt':
        try:
            subprocess.run([str(Path(os.environ['SystemRoot'])/'System32/taskkill.exe'),'/F','/T','/PID',str(proc.pid)],
                           capture_output=True,timeout=2,creationflags=subprocess.CREATE_NO_WINDOW)
        except (OSError,subprocess.TimeoutExpired):pass
    if proc.poll() is None:proc.kill()

def run(args, *, input=None, timeout=None, capture_output=False, **kwargs):
    if not active():return subprocess.run(args,input=input,timeout=timeout,capture_output=capture_output,**kwargs)
    check()
    if input is not None:kwargs['stdin']=subprocess.PIPE
    if capture_output:kwargs.update(stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    started=time.monotonic()
    with subprocess.Popen(args,**kwargs) as proc:
        pending=input
        try:
            while True:
                check()
                if timeout is not None and time.monotonic()-started>=timeout:raise subprocess.TimeoutExpired(args,timeout)
                try:
                    out,err=proc.communicate(input=pending,timeout=.1)
                    check()
                    return subprocess.CompletedProcess(args,proc.returncode,out,err)
                except subprocess.TimeoutExpired:pending=None
        finally:
            if proc.poll() is None:
                _terminate(proc)
                proc.communicate(timeout=5)

def envato_request(payload):
    """Own the HTTP connection in a small process so Stop also interrupts a blocked socket."""
    result=run([sys.executable,str(Path(__file__).resolve()),'envato'],input=json.dumps(payload).encode('utf-8'),
               capture_output=True,timeout=50,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode:raise ValueError('Envato could not complete this search.')
    return result.stdout

def _http_main():
    import requests
    payload=json.loads(sys.stdin.buffer.read(32768))
    with requests.post('https://mcp.envato.com/mcp',json=payload,
                       headers={'Accept':'application/json, text/event-stream'},timeout=(10,35),stream=True) as response:
        response.raise_for_status();raw=bytearray()
        for chunk in response.iter_content(65536):
            raw.extend(chunk)
            if len(raw)>2*1024*1024:raise ValueError('Response too large')
    sys.stdout.buffer.write(raw)

if __name__=='__main__':
    if sys.argv[1:]!=['envato']:raise SystemExit(2)
    _http_main()
