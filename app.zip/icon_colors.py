"""Authored overlay colours, baked identically for editor, render and XML.

Colour never changes canvas, alpha, placement or animation timing. Originals
remain immutable; derived assets are content-stamped and written atomically.
"""
from pathlib import Path
import colorsys,hashlib,json,math,os,re,subprocess,threading,uuid

VERSION=1
KINDS=frozenset(('x','arrow','burst','xv1','xv2','cancel','va1','va2','va3','va4','movarrow','hw1','hw4','hw6','hw9'))
KEYS=frozenset(('movarrow','hw1','hw4','hw6','hw9'))
_LOCK=threading.RLock()

def normalize(value):
    if isinstance(value,str) and re.fullmatch(r'#[0-9a-fA-F]{6}',value):return value.lower()
    return None

def allowed(kind):
    return kind in KINDS or bool(re.fullmatch(r'bdg(?:1y|360|mb|ship|stock)_[a-z]{2}',str(kind or '')))

def choice(item):
    color=normalize(item.get('color'))
    if color and allowed(item.get('type') or item.get('icon')):return color
    try:
        hue=float(item.get('hue') or 0)
        return hue if math.isfinite(hue) else 0
    except (TypeError,ValueError):return 0

def kind_from_name(name):
    stem=Path(name).stem
    if not stem.startswith('icon_'):return ''
    stem=stem[5:]
    for suffix in ('_t','_c'):
        if stem.endswith(suffix):stem=stem[:-len(suffix)]
    if stem=='ring':return 'burst'
    if stem=='arrow_flip':return 'arrow'
    return stem

def rgb(color):
    color=normalize(color)
    if not color:raise ValueError('Invalid overlay colour')
    return tuple(int(color[i:i+2],16) for i in (1,3,5))

def _target(source,color,mode,extension):
    source=Path(source);st=source.stat()
    key=hashlib.sha256(json.dumps([VERSION,str(source.resolve()),st.st_size,st.st_mtime_ns,color,mode]).encode()).hexdigest()[:20]
    folder=source.parent/'_colors';folder.mkdir(exist_ok=True)
    return folder/(source.stem+'_'+color[1:]+'_'+key+extension)

def png(source,color,mode='solid'):
    color=normalize(color)
    if not color:return Path(source)
    out=_target(source,color,mode,'.png')
    with _LOCK:
        if out.is_file():return out
        import numpy as np
        from PIL import Image
        with Image.open(source) as image:
            original=np.array(image.convert('RGBA'));result=original.copy()
            if mode=='badge':
                hsv=np.array(image.convert('RGB').convert('HSV'))
                # Neutral lettering, black/charcoal ribbons and their shadows
                # are not part of the theme. Transparent RGB is untouched too.
                mask=(hsv[:,:,1]>=76)&(hsv[:,:,2]>=32)&((hsv[:,:,2]>=96)|(hsv[:,:,1]>=145))&(original[:,:,3]>0)
                h,s,v=colorsys.rgb_to_hsv(*(x/255 for x in rgb(color)))
                themed=hsv.copy();themed[:,:,0]=round(h*255)%256
                themed[:,:,1]=np.rint(hsv[:,:,1].astype(float)*s).astype('uint8')
                themed[:,:,2]=np.rint(hsv[:,:,2].astype(float)*v).astype('uint8')
                mapped=np.array(Image.fromarray(themed,'HSV').convert('RGB'))
                result[:,:,:3][mask]=mapped[mask]
            else:
                value=original[:,:,:3].max(axis=2).astype(float)/255 if mode!='key' else np.ones(original.shape[:2])
                result[:,:,:3]=np.rint(value[:,:,None]*np.array(rgb(color))).astype('uint8')
            temp=out.with_name('.'+uuid.uuid4().hex+'.png')
            try:
                Image.fromarray(result,'RGBA').save(temp);os.replace(temp,out)
            finally:temp.unlink(missing_ok=True)
    return out

def key_filter(color):
    r,g,b=rgb(color)
    return f"format=rgba,geq=r='{r}':g='{g}':b='{b}':a='clip(0.7*(r(X\\,Y)+g(X\\,Y)+b(X\\,Y))\\,0\\,255)'"

def video(source,color,key=False,extension='.mov'):
    color=normalize(color)
    if not color:return Path(source)
    if extension not in ('.mov','.webm'):raise ValueError('Invalid overlay format')
    source=Path(source);out=_target(source,color,'key' if key else 'alpha',extension)
    with _LOCK:
        if out.is_file() and out.stat().st_size:return out
        r,g,b=rgb(color)
        strength='max(max(r(X\\,Y)\\,g(X\\,Y))\\,b(X\\,Y))/255'
        filt=key_filter(color) if key else f"format=rgba,geq=r='{r}*({strength})':g='{g}*({strength})':b='{b}*({strength})':a='alpha(X\\,Y)'"
        temp=out.with_name('.'+uuid.uuid4().hex+extension)
        command=['ffmpeg','-nostdin','-y','-v','error','-threads','2','-filter_threads','1']
        if source.suffix.lower()=='.webm':command+=['-c:v','libvpx-vp9']
        command+=['-i',str(source),'-map','0:v:0','-an','-vf',filt,'-fps_mode','passthrough','-threads','2']
        command+=['-c:v','libvpx-vp9','-lossless','1','-pix_fmt','yuva420p','-auto-alt-ref','0','-deadline','good','-cpu-used','4'] if extension=='.webm' else ['-c:v','prores_ks','-profile:v','4444','-pix_fmt','yuva444p10le']
        try:
            result=subprocess.run(command+[str(temp)],capture_output=True,timeout=240,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            if result.returncode or not temp.is_file() or not temp.stat().st_size:raise RuntimeError('Could not prepare this icon colour. Try again.')
            os.replace(temp,out)
        finally:temp.unlink(missing_ok=True)
    return out
