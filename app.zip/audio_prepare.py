"""Independent, offline voice-over preparation. Originals and completed outputs are immutable."""
from pathlib import Path
import json, os, re, shutil, subprocess, sys, threading, time, uuid, wave

MODES = {'slow': .60, 'natural': .40, 'fast': .30}
_LOCK = threading.RLock()
_RUNS = {}

def atomic(path, data):
    p = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    try:
        with p.open('w', encoding='utf8') as f:
            json.dump(data, f, ensure_ascii=False); f.flush(); os.fsync(f.fileno())
        # Windows readers/AV can briefly deny replacement while the status is being polled.
        for attempt in range(30):
            try: os.replace(p, path); break
            except PermissionError:
                if attempt == 29: raise
                time.sleep(.02)
    finally:
        p.unlink(missing_ok=True)

def read(path, default=None):
    try: return json.loads(path.read_text('utf8'))
    except FileNotFoundError: return default if default is not None else {}

def state(root):
    root = Path(root)
    with _LOCK:
        s = read(root/'state.json')
        if s.get('status') == 'running':
            run = _RUNS.get(str(root.resolve()))
            if not run:
                s.update(status='error', error='Trim was interrupted. The original recording is available.')
            else:
                p = read(root/s['id']/'progress.json')
                s.update(step=p.get('step', 'Preparing Audio…'), pct=p.get('pct', 0))
        if s.get('id'):
            s['ref'] = s['id'] + ('-t' if s.get('selected') == 'trimmed' else '-o')
        return s

def upload(root, file):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    ext = Path(file.filename or '').suffix.lower()
    if ext not in ('.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac', '.opus', '.wma'):
        raise ValueError('Choose an audio file (MP3, WAV, M4A, AAC, OGG, FLAC or WMA).')
    with _LOCK:
        if str(root.resolve()) in _RUNS: raise ValueError('Stop the current trim before replacing the audio.')
        ident = uuid.uuid4().hex; owned = root/ident; owned.mkdir()
        try:
            file.save(owned/('original'+ext))
            if not (owned/('original'+ext)).stat().st_size: raise ValueError('The audio file is empty.')
            s = dict(id=ident, name=Path(file.filename.replace('\\','/')).name[:200], ext=ext,
                     status='ready', selected='original', has_trimmed=False, pct=0, error=None)
            atomic(root/'state.json', s)
        except Exception:
            shutil.rmtree(owned); raise
        return state(root)

def selected(root, ref):
    root = Path(root)
    with _LOCK:
        s = state(root)
        if s.get('status') == 'running': raise ValueError('Wait for Trim to finish, or stop it first.')
        if not ref or ref != s.get('ref'): raise ValueError('The selected audio changed. Review it and try again.')
        p = root/s['id']/('trimmed.wav' if s.get('selected') == 'trimmed' else 'original'+s['ext'])
        if not p.is_file(): raise ValueError('The prepared recording is missing. Upload it again.')
        name = Path(s['name']).stem + '_Trimmed.wav' if s.get('selected') == 'trimmed' else s['name']
        return p, name

def copy_selected(root, ref, directory):
    with _LOCK:
        source, name = selected(root, ref)
        dst = Path(directory)/('audio'+source.suffix)
        shutil.copyfile(source, dst)
        return dst, name

def select(root, ref, which):
    with _LOCK:
        s = state(root)
        if s.get('status') == 'running': raise ValueError('Stop Trim before changing the audio selection.')
        if ref != s.get('ref'): raise ValueError('The recording changed. Reload this panel.')
        if which not in ('original','trimmed') or (which == 'trimmed' and not s.get('has_trimmed')):
            raise ValueError('That audio version is not available.')
        s.update(selected=which, error=None, status='ready');atomic(Path(root)/'state.json',s)
        return state(root)

def start(root, ref, mode, ffmpeg, vad_repo):
    root=Path(root); key=str(root.resolve())
    with _LOCK:
        selected(root, ref)
        if mode not in MODES: raise ValueError('Choose a valid pace.')
        if key in _RUNS: raise ValueError('Trim is already running.')
        s=state(root)
        # One immutable trimmed result per upload. Re-selecting Original never deletes it.
        if s.get('has_trimmed'): raise ValueError('This recording is already trimmed. Upload the original again to change the pace.')
        if not (Path(vad_repo)/'hubconf.py').is_file():
            raise ValueError('The local speech detector is missing. Original audio was kept.')
        d=root/s['id'];progress=d/'progress.json'
        atomic(progress,dict(step='Preparing Audio…',pct=0))
        log=(d/'trim.log').open('wb')
        args=[sys.executable,'-B',str(Path(__file__).resolve()),'--worker',str(d),s['ext'],mode,str(ffmpeg),str(vad_repo)]
        try: p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        finally: log.close()
        run=dict(proc=p,id=s['id'],cancel=False);_RUNS[key]=run
        s.update(status='running',step='Preparing Audio…',error=None,mode=mode);atomic(root/'state.json',s)
        threading.Thread(target=_finish,args=(root,run),daemon=True).start()
        return state(root)

def _finish(root, run):
    p=run['proc'];p.wait();key=str(root.resolve());d=root/run['id']
    with _LOCK:
        try:
            s=read(root/'state.json')
            if s.get('id')!=run['id']:return
            result=read(d/'result.json')
            if run['cancel']:
                s.update(status='ready',selected='original',has_trimmed=False,error=None,step='Stopped',pct=0)
            elif p.returncode==0 and result.get('verified') and (d/'trimmed.wav').is_file():
                s.update(status='ready',selected='trimmed',has_trimmed=True,error=None,pct=100,step='Trim Complete',**result)
            else:
                s.update(status='error',selected='original',error='Trim could not be verified. The original recording was kept.',pct=0)
            atomic(root/'state.json',s)
        finally:
            if _RUNS.get(key) is run:_RUNS.pop(key,None)
            for n in ('decoded.wav','vad.wav','trimmed.part.wav'):
                (d/n).unlink(missing_ok=True)
            if run['cancel'] or p.returncode:
                (d/'trimmed.wav').unlink(missing_ok=True)

def cancel(root):
    key=str(Path(root).resolve())
    with _LOCK:
        run=_RUNS.get(key)
        if not run:return state(root)
        run['cancel']=True;p=run['proc']
        if p.poll() is None:
            if os.name=='nt':subprocess.run(['taskkill','/F','/T','/PID',str(p.pid)],capture_output=True,timeout=10,creationflags=subprocess.CREATE_NO_WINDOW)
            else:p.terminate()
    return state(root)

def quiet_runs(wav, report):
    """Every channel must stay below -50 dBFS. A short consonant/breath ends the run."""
    import numpy as np
    runs=[];begin=None;pos=0
    with wave.open(str(wav),'rb') as w:
        sr=w.getframerate();ch=w.getnchannels();total=w.getnframes();hop=max(1,round(sr*.01))
        assert w.getsampwidth()==4
        while pos<total:
            raw=w.readframes(hop*500)
            samples=np.frombuffer(raw,dtype='<i4').reshape(-1,ch)
            if not len(samples):break
            for i in range(0,len(samples),hop):
                part=samples[i:i+hop];quiet=bool(np.max(np.abs(part.astype('int64')))<(2**31)*10**(-50/20))
                at=pos+i
                if quiet and begin is None:begin=at
                if not quiet and begin is not None:
                    if at-begin>=sr*.75:runs.append((begin/sr,at/sr))
                    begin=None
            pos+=len(samples);report('Checking Quiet Gaps…',100*pos/total)
        # No leading/trailing cuts: a terminal quiet run is deliberately ignored.
    return [r for r in runs if r[0]>0],total/sr

def plan_cuts(quiet, speech, mode, duration):
    keep=MODES[mode];guard=max(.15,keep/2);cuts=[]
    if not speech:return [] # Nothing confidently recognised as speech: preserve the entire recording.
    # Cut only gaps BOUNDED by detected speech; never before the first or after the last speech.
    for left,right in zip(speech,speech[1:]):
        for a,b in quiet:
            start=max(a+guard,left['end']/16000+.20)
            end=min(b-guard,right['start']/16000-.20)
            if end-start>=.10 and a>=left['end']/16000-.20 and b<=right['start']/16000+.20:
                cuts.append((start,end))
    return sorted(cuts)

def write_verified(src, dst, cuts, report):
    """Stream uncut PCM ranges. Re-read the output and compare each retained sample byte-for-byte."""
    import hashlib
    with wave.open(str(src),'rb') as r:
        sr=r.getframerate();total=r.getnframes();params=r.getparams();ranges=[];last=0
        for a,b in cuts:
            a,b=round(a*sr),round(b*sr)
            if not (last<=a<b<total):raise ValueError('Invalid trim interval')
            ranges.append((last,a));last=b
        ranges.append((last,total));expected=sum(b-a for a,b in ranges);digest=hashlib.sha256()
        with wave.open(str(dst),'wb') as out:
            out.setparams(params);done=0
            for a,b in ranges:
                r.setpos(a);remaining=b-a
                while remaining:
                    n=min(remaining,sr*5);raw=r.readframes(n)
                    if len(raw)!=n*r.getnchannels()*r.getsampwidth():raise ValueError('Incomplete source audio')
                    out.writeframesraw(raw);digest.update(raw);remaining-=n;done+=n
                    report('Writing Trimmed Audio…',100*done/max(1,expected))
    got=hashlib.sha256()
    with wave.open(str(dst),'rb') as r:
        if (r.getnchannels(),r.getsampwidth(),r.getframerate(),r.getnframes())!=(params.nchannels,params.sampwidth,params.framerate,expected):
            raise ValueError('Audio verification failed')
        checked=0
        report('Verifying Audio…',0)
        while True:
            block=r.readframes(sr*10)
            if not block:break
            got.update(block)
            checked+=len(block)
            report('Verifying Audio…',100*checked/max(1,expected*params.nchannels*params.sampwidth))
    if digest.digest()!=got.digest():raise ValueError('Retained samples changed')
    report('Verifying Audio…',100)
    return dict(verified=True,original_seconds=total/sr,trimmed_seconds=expected/sr,removed_seconds=(total-expected)/sr,cuts=len(cuts),pcm_sha256=got.hexdigest())

def worker(d,ext,mode,ffmpeg,vad_repo):
    import numpy as np
    import torch
    torch.set_num_threads(1)
    d=Path(d);last=[0,None]
    def report(step,pct):
        now=time.monotonic()
        if step==last[1] and now-last[0]<.2 and pct is not None and pct<100:return
        last[:]=[now,step]
        try: atomic(d/'progress.json',dict(step=step,pct=None if pct is None else max(0,min(100,int(pct))),updated=time.time()))
        except OSError: pass  # Reporting must not destroy an otherwise verified recording.
    def ff(args):
        subprocess.run([ffmpeg,'-v','error','-nostdin','-y',*args],check=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    src=d/('original'+ext);decoded=d/'decoded.wav';vw=d/'vad.wav';partial=d/'trimmed.part.wav'
    report('Reading Audio…',None)
    ff(['-i',str(src),'-vn','-c:a','pcm_s32le',str(decoded)])
    ff(['-i',str(src),'-vn','-ar','16000','-ac','1','-c:a','pcm_s16le',str(vw)])
    report('Loading Speech Detector…',None)
    # source=local explicitly forbids a repository/model download.
    model,utils=torch.hub.load(str(vad_repo),'silero_vad',source='local',onnx=False)
    with wave.open(str(vw),'rb') as f:samples=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype('float32')/32768
    speech=utils[0](torch.from_numpy(samples),model,sampling_rate=16000,threshold=.20,neg_threshold=.05,
                    min_speech_duration_ms=32,min_silence_duration_ms=150,speech_pad_ms=100,
                    progress_tracking_callback=lambda p:report('Detecting Speech…',p))
    quiet,duration=quiet_runs(decoded,report)
    cuts=plan_cuts(quiet,speech,mode,duration)
    # Validate against ALL padded speech regions; a conflicting candidate is refused, never forced.
    for a,b in cuts:
        if any(a<s['end']/16000+.15 and b>s['start']/16000-.15 for s in speech):raise ValueError('A cut overlaps protected speech')
    result=write_verified(decoded,partial,cuts,report)
    atomic(d/'cut-report.json',dict(mode=mode,intervals=cuts,speech_regions=len(speech),quiet_regions=len(quiet),**result))
    os.replace(partial,d/'trimmed.wav');atomic(d/'result.json',result)

if __name__=='__main__' and sys.argv[1:2]==['--worker']:
    worker(*sys.argv[2:])
