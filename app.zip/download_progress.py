"""Ephemeral, account-scoped download telemetry. Never starts or retries work."""
from contextvars import ContextVar
from contextlib import contextmanager
import re
import threading
import time
import zipfile

_current = ContextVar('download_progress', default=None)
_lock = threading.RLock()
_records = {}


class Progress:
    def __init__(self):
        self.lock = threading.RLock()
        self.phase = None
        self.update('Preparing File')

    def update(self, phase, completed=None, total=None, unit=None):
        now = time.monotonic()
        with self.lock:
            if self.phase != phase:
                self.started = now
                self.first_count = completed or 0
            self.phase, self.updated = phase, now
            self.completed, self.total, self.unit = completed, total, unit

    def snapshot(self):
        with self.lock:
            elapsed = max(0, time.monotonic() - self.started)
            count, total = self.completed, self.total
            measured = isinstance(count, (int, float)) and isinstance(total, (int, float)) and total > 0
            advanced = (count or 0) - self.first_count
            remaining = ((total-count)*elapsed/advanced
                         if measured and elapsed >= 3 and advanced > 0 and 0 < count < total else None)
            return dict(phase=self.phase, completed=count, total=total, unit=self.unit,
                        pct=max(0, min(100, count/total*100)) if measured else None,
                        remaining_seconds=round(remaining) if remaining is not None else None)


def valid(token):
    return isinstance(token, str) and re.fullmatch(r'[a-zA-Z0-9_-]{16,80}', token) is not None


def begin(owner, token):
    if not owner or not valid(token):
        return None
    with _lock:
        now = time.monotonic()
        for key, record in list(_records.items()):
            if now-record.updated > 3600:
                del _records[key]
        if (owner, token) in _records:
            return None  # duplicate IDs must not replace another running transfer's state
        if len(_records) >= 256:
            del _records[min(_records, key=lambda k: _records[k].updated)]
        record = Progress()
        _records[owner, token] = record
        return record


def status(owner, token):
    with _lock:
        record = _records.get((owner, token)) if valid(token) else None
        return record.snapshot() if record else None


@contextmanager
def scope(owner, token):
    record = begin(owner, token)
    saved = _current.set(record)
    try:
        yield record
    finally:
        _current.reset(saved)


def reporter():
    record = _current.get()
    return record.update if record else lambda *args, **kwargs: None


def report(phase, completed=None, total=None, unit=None):
    reporter()(phase, completed, total, unit)


def zip_files(archive, files):
    """Keep the same ZIP contents; report actual source bytes as compression reads them."""
    files = list(files)
    if _current.get() is None:
        for path, name in files:
            archive.write(path, name)
        return
    total = sum(path.stat().st_size for path, _ in files)
    completed = 0
    report('Packing Media', 0, total, 'bytes')
    for path, name in files:
        info = zipfile.ZipInfo.from_file(path, name)
        info.compress_type = archive.compression
        with path.open('rb') as src, archive.open(info, 'w', force_zip64=True) as dst:
            while chunk := src.read(1 << 20):
                dst.write(chunk)
                completed += len(chunk)
                report('Packing Media', completed, total, 'bytes')
